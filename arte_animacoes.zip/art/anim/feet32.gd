# Gerado por tools/cut_pixel.py — não editar à mão.
## Pés dos frames 32-bit (píxeis de arte entre o fundo da textura e a linha dos pés).
const FEET := {
	"strider32": [0, 0, 0, 0, 1, 1, 1, 1, 0, 0, 0, 0, 1, 1, 1, 1],
}
