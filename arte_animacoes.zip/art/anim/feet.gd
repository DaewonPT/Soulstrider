# Gerado por tools/import_art.py — não editar à mão.
## Por frame: píxeis entre o fundo da textura e a linha dos pés, para ninguém flutuar.
const FEET := {
	"player": [17, 22, 19, 20, 0, 0, 1, 0, 12, 12, 17, 14, 38, 6, 14, 0, 15, 15, 17, 15, 12, 12, 0, 16],
	"skeleton": [13, 14, 14, 10, 0, 0, 3, 0, 0, 0, 0, 2, 11, 20, 8, 14],
	"colossus": [3, 16, 4, 4, 0, 0, 5, 4, 2, 3, 0, 0, 16, 35, 40, 36],
	"specter": [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
	"warden": [4, 20, 13, 1, 4, 0, 5, 6, 11, 10, 27, 1, 23, 19, 19, 30],
	"herald": [11, 13, 13, 14, 18, 22, 0, 14, 26, 0, 2, 29, 34, 46, 45, 26],
}
