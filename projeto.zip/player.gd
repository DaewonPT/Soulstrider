extends Node2D
## Um herói do grupo: o Strider (gadanha + feitiços de alma) ou o Guardião (machado, "Bleed & Bone").
## Cada habilidade tem um Frasco de Alma de suporte.

signal died

## Frascos de Alma: os dois primeiros vêm de início; os outros caem como saque raro (main.flasks).
const SUPPORTS := ["", "parasita", "titanica", "veloz", "eco", "tumular", "colerica"]
const SUPPORT_NAMES := {
	"": "Nenhum", "parasita": "Alma Parasita", "titanica": "Alma Titânica", "veloz": "Alma Veloz",
	"eco": "Alma Eco", "tumular": "Alma Tumular", "colerica": "Alma Colérica",
}
const SUPPORT_DESC := {
	"": "Sem frasco: a habilidade tal como é.",
	"parasita": "Paga com VIDA em vez de alma: dano ×2,2 e área ×1,5.",
	"titanica": "Área ×1,8, mas a recarga demora ×1,7.",
	"veloz": "Recarga ×0,55, mas dano ×0,8.",
	"eco": "Repete-se sozinha meio segundo depois, com 60% do dano.",
	"tumular": "Quem morrer com ela ergue-se como esqueleto teu durante 12 s.",
	"colerica": "Até +80% de dano quanto menos vida tiveres.",
}
const POTION_MAX := 3.0
const RING_CD := 2.0  # habilidades com recarga a partir disto aparecem no anel à volta dos pés
const READY_T := 0.4
const ATTACK_T := 0.32
const SPIN_T := 0.4
const CAST_T := 0.3
const NOVA_T := 0.45
const Feet := preload("res://art/anim/feet.gd")
const HEROES := {
	"strider": {"name": "Strider", "order": ["scythe", "bolt", "nova"], "scale": 0.34, "portrait": preload("res://art/ui/portrait_strider.png")},
	"warden": {"name": "Guardião", "order": ["chop", "cleave", "bonearmor"], "scale": 0.27, "portrait": preload("res://art/ui/portrait_warden.png")},
}
## Strider: 0-3 andar, 4-7 gadanha, 8-9 parado, 10-11 ferido, 12 a cair, 13 caído, 14-15 reanimado,
## 16-19 Lança de Almas, 20-23 Nova. Guardião: 0-3 andar, 4-7 machadada, 8-9 parado, 10 caído, 11 reanimado, 12-15 giro.
static var FRAMES := {
	"strider": range(24).map(func(i): return load("res://art/anim/player_%d.png" % i)),
	"warden": range(16).map(func(i): return load("res://art/anim/warden_%d.png" % i)),
}
## 32-bit (a arte chega parte a parte): por agora o Strider a andar (0-7) e com a gadanha (8-15)
static var FRAMES32 := range(16).map(func(i): return load("res://art/anim/strider32_%d.png" % i))
const Feet32 := preload("res://art/anim/feet32.gd")
const SHEET := {"strider": "player", "warden": "warden"}  # nome dos ficheiros (e da tabela de pés)
const RING := [preload("res://art/fx/ring_p1.png"), preload("res://art/fx/ring_p2.png")]
const REVIVE_TEX := preload("res://art/fx/revive.png")

var main
var hero := "strider"
var order: Array = HEROES.strider.order
var pfx := ""  # prefixo das ações de input: "" = jogador 1, "p2_" = jogador 2
var slot := 0
var hero_name := "Strider"
var tint := Color(0.4, 1.0, 0.6)  # cor do jogador no HUD
var portrait: Texture2D = HEROES.strider.portrait
var passives := ["raiz"]
var points := 0
var revive_t := 0.0
var revived_t := 0.0
var lock_skills := false  # depois de fechar um painel, espera que larguem os botões
var walk_t := 0.0
var hp_chunk := 150.0  # o HUD desenha este pedaço atrás da vida e escoa-o com atraso
var chunk_wait := 0.0
var heal_acc := 0.0
var heal_num_t := 0.0
var max_hp := 150.0
var hp := 150.0
var max_mana := 100.0
var mana := 100.0
var touch_move := Vector2.ZERO
var held := {}
var facing := Vector2.RIGHT
var cds := {}
var swing := 0.0
var spin := 0.0
var cast_t := 0.0
var nova_t := 0.0
var armor := 0.0
var hurt := 0.0
var lean_t := 9.0  # desde o último golpe ou Lança: recua, passa à frente e assenta (mola)
var lean_dir := Vector2.ZERO
var tilt := 0.0  # inclina-se para onde anda
var flip_s := -1.0  # espelho suave: vira-se como uma carta em vez de estalar
var body := Node2D.new()  # desenha o herói por cima do anel (no 32-bit sem suavizar: píxeis nítidos)
var t := 0.0
var dead := false
var potions := {"hp": POTION_MAX, "mp": POTION_MAX}  # cargas; matar enche-as
var ready_t := {}  # anel de recarga: brilho curto quando uma habilidade longa volta a estar pronta

var skills := {
	"scythe": {"name": "Ceifa Sepulcral", "mana": 0.0, "cd": 0.4, "dmg": 22.0, "area": 95.0, "support": ""},
	"bolt": {"name": "Lança de Almas", "mana": 10.0, "cd": 0.55, "dmg": 34.0, "area": 16.0, "support": ""},
	"nova": {"name": "Nova Espectral", "mana": 28.0, "cd": 2.5, "dmg": 45.0, "area": 170.0, "support": ""},
	"chop": {"name": "Golpe do Carrasco", "mana": 0.0, "cd": 0.55, "dmg": 30.0, "area": 105.0, "support": ""},
	"cleave": {"name": "Ceifa de Ossos", "mana": 16.0, "cd": 2.0, "dmg": 38.0, "area": 150.0, "support": ""},
	"bonearmor": {"name": "Armadura de Ossos", "mana": 25.0, "cd": 9.0, "dmg": 0.0, "area": 0.0, "support": ""},
}


func setup(h: String, index: int) -> void:
	hero = h
	slot = index
	order = HEROES[h].order
	hero_name = HEROES[h].name
	portrait = HEROES[h].portrait
	pfx = "" if index == 0 else "p2_"
	tint = Color(0.4, 1.0, 0.6) if index == 0 else Color(1.0, 0.75, 0.35)
	for id in order:
		cds[id] = 0.0
	body.draw.connect(_draw_body)
	add_child(body)


func stat(key: String) -> float:
	var v: float = main.stat(key)
	for id in passives:
		v += main.PASSIVES[id].stats.get(key, 0.0)
	return v


## Vida e mana máximas: base + nível do grupo + árvore.
func refresh_stats() -> void:
	max_hp = 150.0 + stat("hp_max") + (main.level - 1) * 8.0
	max_mana = 100.0 + stat("mana_max")


func allocate(id: String) -> bool:
	var n: Dictionary = main.PASSIVES[id]
	if points < 1 or id in passives or not n.req in passives:
		return false
	points -= 1
	passives.append(id)
	refresh_stats()
	return true


func _process(delta: float) -> void:
	t += delta
	revived_t = maxf(0.0, revived_t - delta)
	if dead:
		return
	var dir := Input.get_vector(pfx + "move_left", pfx + "move_right", pfx + "move_up", pfx + "move_down")
	if touch_move != Vector2.ZERO:
		dir = touch_move
	var start := position
	position += dir * 230.0 * (1.0 + stat("speed")) * delta
	position = position.clamp(main.bounds.position + Vector2(30, 30), main.bounds.end - Vector2(30, 30))
	position = main.walk(start, position)
	walk_t = walk_t + delta if dir.length() > 0.2 else 0.0
	# Durante um ataque fica virado para o alvo; parado, vira-se para o inimigo mais perto
	if swing <= 0.0 and spin <= 0.0 and cast_t <= 0.0 and nova_t <= 0.0:
		facing = dir.normalized() if dir.length() > 0.2 else _aim()
	tilt = lerpf(tilt, dir.x * 0.06, 1.0 - exp(-10.0 * delta))
	flip_s = move_toward(flip_s, -1.0 if facing.x > 0.0 else 1.0, delta * 12.0)
	mana = minf(max_mana, mana + (7.0 + stat("regen")) * delta)
	hp = minf(max_hp, hp + 1.0 * delta)
	for k in cds:
		if cds[k] > 0.0 and cds[k] <= delta and skills[k].cd >= RING_CD:
			ready_t[k] = READY_T
		cds[k] = maxf(0.0, cds[k] - delta)
		ready_t[k] = maxf(0.0, ready_t.get(k, 0.0) - delta)
	swing = maxf(0.0, swing - delta)
	spin = maxf(0.0, spin - delta)
	cast_t = maxf(0.0, cast_t - delta)
	nova_t = maxf(0.0, nova_t - delta)
	armor = maxf(0.0, armor - delta)
	hurt = maxf(0.0, hurt - delta)
	lean_t += delta
	chunk_wait -= delta
	hp_chunk = maxf(hp_chunk, hp) if chunk_wait > 0.0 else move_toward(hp_chunk, hp, max_hp * 0.8 * delta)
	heal_num_t -= delta
	if heal_num_t <= 0.0 and heal_acc >= 3.0:
		heal_num_t = 0.5
		main.number(position + Vector2(0, -90), "+%d" % int(heal_acc), 15.0, Color(0.45, 1.0, 0.55))
		heal_acc = 0.0
	var want := []
	for i in 3:
		if Input.is_action_pressed(pfx + "skill_%d" % (i + 1)) or held.get(order[i], false):
			want.append(order[i])
	if lock_skills:
		lock_skills = not want.is_empty()  # o A que fechou um painel não conta como ataque
	else:
		for id in want:
			use_skill(id)
	if Input.is_action_just_pressed(pfx + "interact"):
		main.interact()
	if Input.is_action_just_pressed(pfx + "potion_hp"):
		use_potion("hp")
	if Input.is_action_just_pressed(pfx + "potion_mp"):
		use_potion("mp")
	queue_redraw()


## Troca o frasco de uma habilidade pelo seguinte que o grupo já encontrou.
func cycle_support(id: String) -> void:
	var have: Array = SUPPORTS.filter(func(f): return f in main.flasks)
	var s: Dictionary = skills[id]
	s.support = have[(have.find(s.support) + 1) % have.size()]


## Poção de vida (40% da vida) ou de alma (60% da alma). Gasta uma carga; não se gasta cheia.
func use_potion(kind: String) -> void:
	if Net.is_guest():
		Net.tap(1 if kind == "hp" else 2)
		return
	if dead or potions[kind] < 1.0 or (hp >= max_hp if kind == "hp" else mana >= max_mana):
		return
	potions[kind] -= 1.0
	if kind == "hp":
		heal(max_hp * 0.4)
	else:
		mana = minf(max_mana, mana + max_mana * 0.6)
	main.sfx("potion")
	main.spawn_fx("glow", position + Vector2(0, -40), 55.0, Color(1.0, 0.3, 0.3) if kind == "hp" else Color(0.35, 0.7, 1.0))


func fill_potions(amount: float) -> void:
	for k in potions:
		potions[k] = minf(POTION_MAX, potions[k] + amount)


func use_skill(id: String) -> void:
	if dead or cds[id] > 0.0:
		return
	var s: Dictionary = skills[id]
	var cost: float = s.mana
	var dmg: float = s.dmg * (1.0 + stat("dmg"))
	var area: float = s.area
	var cd: float = s.cd
	if id in ["bolt", "nova"]:
		dmg *= 1.0 + stat("spell")
	if s.support == "parasita":
		var life_cost := maxf(cost * 1.5, 6.0)
		if hp <= life_cost + 1.0:
			return
		hp -= life_cost
		hurt = 0.1
		dmg *= 2.2
		area *= 1.5
	else:
		if mana < cost:
			return
		mana -= cost
	match s.support:
		"titanica":
			area *= 1.8
			cd *= 1.7
		"veloz":
			cd *= 0.55
			dmg *= 0.8
		"colerica":
			dmg *= 1.0 + 0.8 * clampf((1.0 - hp / max_hp) / 0.7, 0.0, 1.0)
	cds[id] = cd
	var aim := _aim()
	facing = aim
	flip_s = -1.0 if aim.x > 0.0 else 1.0  # ao atacar vira-se logo
	_cast(id, dmg, area, aim, s.support)
	if s.support == "eco":
		await get_tree().create_timer(0.35, false).timeout
		if is_inside_tree() and not dead:
			_cast(id, dmg * 0.6, area, _aim(), "eco")


## O efeito da habilidade (custo e recarga já pagos em use_skill; o Eco chama-o outra vez, de graça).
func _cast(id: String, dmg: float, area: float, aim: Vector2, support: String) -> void:
	var green := Color(0.35, 1.0, 0.6) if support != "parasita" else Color(0.9, 0.15, 0.25)
	main.raise_by = self if support == "tumular" else null  # quem morrer com este golpe ergue-se como aliado
	if id in ["scythe", "chop", "bolt"]:
		lean_t = 0.0
		lean_dir = aim
	match id:
		"scythe", "chop":
			swing = ATTACK_T
			main.hit_arc(position, aim, area, dmg, self)
			main.spawn_fx("arc", position + Vector2(0, -20), area, green, aim)
		"bolt":
			cast_t = CAST_T
			# Antecipação: a Lança só parte quando o braço avança (2.º frame do lançamento)
			var raise := support == "tumular"
			get_tree().create_timer(CAST_T / 4.0, false).timeout.connect(func():
				if is_inside_tree() and not dead:
					main.spawn_bolt(position + Vector2(0, -20), aim, dmg, area, self, raise))
		"nova":
			nova_t = NOVA_T
			main.hit_circle(position, area, dmg, self)
			main.spawn_fx("ring", position, area, green)
		"cleave":
			spin = SPIN_T
			main.hit_circle(position, area, dmg, self, true)
			main.spawn_fx("ring", position, area, Color(0.9, 0.25, 0.3) if support == "parasita" else Color(0.85, 0.8, 0.65))
		"bonearmor":
			armor = 5.0
			main.spawn_fx("ring", position + Vector2(0, -30), 70.0, Color(0.9, 0.85, 0.7))
	main.raise_by = null


func _aim() -> Vector2:
	var best = null
	var best_d := 480.0
	for e in main.enemies():
		var d: float = position.distance_to(e.position)
		if d < best_d:
			best_d = d
			best = e
	return facing if best == null else position.direction_to(best.position)


func heal(amount: float) -> void:
	if dead:
		return
	heal_acc += minf(amount, max_hp - hp)
	hp = minf(max_hp, hp + amount)


## Em co-op o jogador cai em vez de morrer; um aliado perto dele reanima-o (main._coop).
func revive() -> void:
	dead = false
	revive_t = 0.0
	revived_t = 0.6
	hp = max_hp * 0.5


func take_damage(amount: float) -> void:
	if dead:
		return
	if armor > 0.0:
		amount *= 0.5
	hp -= amount
	hurt = 0.2
	chunk_wait = 0.5
	main.number(position + Vector2(randf_range(-10, 10), -90), str(roundi(amount)), 15.0 + clampf(amount / 2.0, 0.0, 16.0), Color(1.0, 0.3, 0.3))
	main.shake = maxf(main.shake, 6.0)
	main.sfx("hurt")
	main.vibrate(60)
	if hp <= 0.0:
		hp = 0.0
		dead = true
		queue_redraw()
		died.emit()


func _frame() -> int:
	if hero == "warden":
		if dead:
			return 10
		if revived_t > 0.0:
			return 11
		if spin > 0.0:
			return 12 + mini(3, int((1.0 - spin / SPIN_T) * 4.0))
		if swing > 0.0:
			return 4 + mini(3, int((1.0 - swing / ATTACK_T) * 4.0))
		return int(walk_t * 8.0) % 4 if walk_t > 0.0 else 8 + int(t * 1.6) % 2
	if dead:
		return 13
	if revived_t > 0.0:
		return 14 if revived_t > 0.3 else 15
	if cast_t > 0.0:
		return 16 + mini(3, int((1.0 - cast_t / CAST_T) * 4.0))
	if nova_t > 0.0:
		return 20 + mini(3, int((1.0 - nova_t / NOVA_T) * 4.0))
	if swing > 0.0:
		return 4 + mini(3, int((1.0 - swing / ATTACK_T) * 4.0))
	if hurt > 0.1:
		return 10
	# O 2.º desenho do andar veio do Gemini sem gadanha (piscava a cada passo): fica de fora
	return [0, 2, 3, 2][int(walk_t * 8.0) % 4] if walk_t > 0.0 else 8 + int(t * 1.6) % 2


## Strider 32-bit: 0-7 andar, 8-15 gadanha; -1 = usar os desenhos pintados. As outras animações chegam na
## Parte 1 da arte: até lá a Lança e a Nova usam a gadanha, parado fica em guarda (8) e caído fica pintado.
func _frame32() -> int:
	if hero != "strider" or not main.settings.pixel or dead or revived_t > 0.0:
		return -1
	var act: float = swing / ATTACK_T if swing > 0.0 else (cast_t / CAST_T if cast_t > 0.0 else nova_t / NOVA_T)
	if act > 0.0:
		return 8 + mini(7, int((1.0 - act) * 8.0))
	return int(walk_t * 16.0) % 8 if walk_t > 0.0 else 8


func _draw() -> void:
	body.texture_filter = TEXTURE_FILTER_NEAREST if _frame32() >= 0 else TEXTURE_FILTER_PARENT_NODE
	body.queue_redraw()  # o herói desenha-se por cima do anel, no nó body
	# Anel do jogador (cor de cada jogador) e, se caiu, o círculo de reanimar
	if dead and revive_t > 0.0:
		draw_texture_rect(REVIVE_TEX, Rect2(-60, -80, 120, 138), false, Color(1, 1, 1, 0.8))
	var ring: Texture2D = RING[slot]
	draw_texture_rect(ring, Rect2(-38, -52, 76, 79), false, Color(1, 1, 1, 0.75))
	# Anel de recarga: cada habilidade longa enche um arco à volta dos pés; quando fica pronta, o arco abre-se num brilho
	if dead:
		return
	draw_set_transform(Vector2(0, -12), 0.0, Vector2(1.0, 0.45))
	var n := 0
	for id in order:
		if skills[id].cd < RING_CD:
			continue
		var r := 50.0 + n * 8.0
		n += 1
		var left: float = cds[id] / skills[id].cd
		if left > 0.0:
			draw_arc(Vector2.ZERO, r, 0.0, TAU, 48, Color(0, 0, 0, 0.3), 5.0)
			draw_arc(Vector2.ZERO, r, -PI / 2.0, -PI / 2.0 + TAU * (1.0 - minf(left, 1.0)), 48, Color(0.6, 0.9, 1.0, 0.55), 4.0)
		elif ready_t.get(id, 0.0) > 0.0:
			var k: float = ready_t[id] / READY_T
			draw_arc(Vector2.ZERO, r + (1.0 - k) * 16.0, 0.0, TAU, 48, Color(0.8, 1.0, 1.0, k), 5.0)
	draw_set_transform(Vector2.ZERO)


func _draw_body() -> void:
	var col := Color(1.0, 0.4, 0.4) if hurt > 0.0 else Color.WHITE
	if dead:
		col = Color(0.8, 0.8, 0.8, 0.95)
	# Os sprites olham para a esquerda: espelha quando olha para a direita (flip_s, a virar suave).
	var f := _frame()
	var tex: Texture2D = FRAMES[hero][f]
	var sc: float = HEROES[hero].scale
	var feet: float = Feet.FEET[SHEET[hero]][f]
	var f32 := _frame32()
	if f32 >= 0:  # 32-bit: um píxel de arte = um píxel do ecrã base (720p)
		tex = FRAMES32[f32]
		sc = 1.0
		feet = Feet32.FEET.strider32[f32]
	# Antecipação e continuação: ao atacar recua, passa um pouco à frente e assenta
	var k := exp(-lean_t * 8.0) * cos(lean_t * 22.0)
	# Fluidez: um salto a cada passo, inclinado para onde anda, e a respirar quando está parado
	var bob := 0.0 if dead else -absf(sin(walk_t * TAU * 2.0)) * 4.0
	var breath := sin(t * 2.4) * 0.015 if walk_t == 0.0 and not dead else 0.0
	body.draw_set_transform(lean_dir * -9.0 * k + Vector2(0, bob), 0.0 if dead else tilt, Vector2(sc * flip_s * (1.0 - 0.05 * k - breath * 0.5), sc * (1.0 + 0.05 * k + breath)))
	body.draw_texture(tex, Vector2(-tex.get_width() / 2.0, -tex.get_height() + feet), col)
	body.draw_set_transform(Vector2.ZERO)
	if armor > 0.0:
		var a := 0.28 + 0.12 * sin(t * 10.0)
		body.draw_arc(Vector2(0, -42), 40.0, 0, TAU, 32, Color(0.92, 0.86, 0.7, a), 3.0)
	if dead and revive_t > 0.0:
		body.draw_arc(Vector2(0, -40), 22.0, -PI / 2.0, -PI / 2.0 + TAU * revive_t / main.REVIVE_T, 32, Color(0.4, 1.0, 0.65), 5.0)
