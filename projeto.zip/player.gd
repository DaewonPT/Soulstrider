extends Node2D
## Um herói do grupo: o Strider (foice + feitiços de alma) ou o Guardião (machado, "Sangue e Osso").
## Cada habilidade tem um Frasco de Alma de suporte.

signal died

## Frascos de Alma: os dois primeiros vêm de início; os outros caem como saque raro (main.flasks).
const SUPPORTS := ["", "parasita", "titanica", "veloz", "eco", "tumular", "colerica", "roubo", "caotico", "mitotico", "martir", "gatilho", "carga", "eter", "gravidade", "meteoro", "terramoto"]
const SUPPORT_NAMES := {
	"": "Nenhum", "parasita": "Alma Parasita", "titanica": "Alma Titânica", "veloz": "Alma Veloz",
	"eco": "Alma Eco", "tumular": "Alma Tumular", "colerica": "Alma Colérica",
	"roubo": "Alma Ladra",
	"caotico": "Alma Caótica",
	"mitotico": "Alma Mitótica",
	"martir": "Alma Mártir",
	"gatilho": "Alma Gatilho",
	"carga": "Alma Sacrificial",
	"eter": "Alma de Éter",
	"gravidade": "Alma Gravitacional",
	"meteoro": "Alma Meteórica",
	"terramoto": "Alma Sísmica",
	"vinganca": "Espectro da Vingança",
	"escriba": "Escriba da Agonia",
	"cranios": "Dança dos Crânios Flamejantes",
	"donzela": "Donzela de Ferro Móvel",
}
const SUPPORT_DESC := {
	"": "Sem frasco: a habilidade tal como é.",
	"parasita": "Paga com VIDA em vez de alma: dano ×2,2 e área ×1,5.",
	"titanica": "Área ×1,8, mas a recarga demora ×1,7.",
	"veloz": "Recarga ×0,55, mas dano ×0,8.",
	"eco": "Repete-se sozinha meio segundo depois, com 60% do dano.",
	"tumular": "Quem morrer com ela ergue-se como esqueleto teu durante 12 s.",
	"colerica": "Até +80% de dano quanto menos vida tiveres.",
	"roubo": "Recarga ×0,7 enquanto tiveres poções; cada uso bebe 1/8 de uma carga.",
	"caotico": "A cada uso muda: Podridão, Necrose ou Calcificação em quem acerta.",
	"mitotico": "Quem morrer com ela ergue-se em DOIS esqueletos pequenos teus (metade do dano) durante 12 s.",
	"martir": "Sem barreira de ossos; cada abate com ela devolve logo a Esquiva.",
	"gatilho": "Gasta um abate feito perto de ti nos últimos 5 s para a área ser ×1,5.",
	"carga": "Dano ×1,3, mas sangras 1,5% da vida por segundo nos 3 s seguintes (nunca mata).",
	"eter": "Não rouba vida: 5% do dano (mais o teu roubo de vida) volta como alma.",
	"gravidade": "Puxa para ti os monstros em que acertas e o saque a 260 px.",
	"meteoro": "Frasco Titânico: só na Explosão Espectral e na Ceifa de Ossos: raio ×1,75 (área tripla) e 6 estilhaços de osso, mas recarga ×2,2 e cada uso custa 8% da vida (nunca mata).",
	"terramoto": "Frasco Titânico: só na Explosão Espectral e na Ceifa de Ossos: fissuras com braços esqueléticos petrificam 1 s os monstros em que acertas (chefes: abrandam 2 s). Dano ×0,75, recarga ×1,6.",
	"vinganca": "Um golpe que te tire mais de 20% da vida dispara flechas espectrais contra quem bateu e até 4 monstros à volta (1,5 s de recarga).",
	"escriba": "A cada 90 px andados inscreves uma runa oculta (até 6, 10 s). Um monstro que a pise rebenta-a: dano em 80 px à volta.",
	"cranios": "4 crânios em chamas orbitam-te; a cada 0,8 s, um lança-se contra um monstro a 320 px (Espectros primeiro). Volta um crânio a cada 4 s.",
	"donzela": "Quando o golpe de área de um chefe te apanha, transformas-te em couraça durante 1,5 s: esses golpes só tiram 10%. Recarga 25 s; na couraça andas a meia velocidade.",
}
## Almas Condensadas: veste-as o herói (uma de cada vez), não uma habilidade. Caem como os frascos e juntam-se à mesma
## lista (main.flasks); o nome e o que fazem estão em SUPPORT_NAMES e SUPPORT_DESC. "" = nenhuma.
const SOULS := ["", "vinganca", "escriba", "cranios", "donzela"]
const POTION_MAX := 3.0
## Chaves que se excluem (Mente Fragmentada #108 ↔ Sem Alma Própria, Lich de Ferro #140 ↔ Sangue Negro #117): quem tem uma não compra a outra.
const EXCLUSIVE := {"fragmentada": "semalma", "semalma": "fragmentada", "lich": "sangue", "sangue": "lich"}
const DASH_T := 0.18  # Esquiva Espectral: dura isto, anda DASH_SPEED * DASH_T e não leva dano
const DASH_SPEED := 1050.0
const DASH_CD := 1.1
const OVERLOAD_T := 6.0  # Sobrecarga de Alma (#1): dura isto
const RING_CD := 2.0  # habilidades com recarga a partir disto aparecem no anel à volta dos pés
const READY_T := 0.4
const ATTACK_T := 0.32
const SPIN_T := 0.4
const CAST_T := 0.3
const NOVA_T := 0.45
const GUARD_T := 0.5  # Armadura de Ossos: os ossos sobem e prendem-se (só se vê em 32-bit)
const Feet := preload("res://art/anim/feet.gd")
const HEROES := {
	"strider": {"name": "Strider", "order": ["scythe", "bolt", "nova"], "scale": 0.34, "portrait": preload("res://art/ui/portrait_strider.png")},
	"warden": {"name": "Guardião", "order": ["chop", "cleave", "bonearmor"], "scale": 0.27, "portrait": preload("res://art/ui/portrait_warden.png")},
}
## Strider: 0-3 andar, 4-7 foice, 8-9 parado, 10-11 ferido, 12 a cair, 13 caído, 14-15 reanimado,
## 16-19 Lança de Almas, 20-23 Nova. Guardião: 0-3 andar, 4-7 machadada, 8-9 parado, 10 caído, 11 reanimado, 12-15 giro.
static var FRAMES := {
	"strider": range(24).map(func(i): return load("res://art/anim/player_%d.png" % i)),
	"warden": range(16).map(func(i): return load("res://art/anim/warden_%d.png" % i)),
}
## Heróis em 32-bit (tools/cut_pixel.py), 8 desenhos por movimento: 0-7 andar, 8-15 golpe, 16-23 parado,
## 24-31 ferido, caído e a reerguer-se, 32-39 Lança (Strider) ou Ceifa de Ossos (Guardião), 40-47 Nova ou
## Armadura de Ossos, 48-55 Esquiva.
const SHEET32 := {"strider": "strider32", "warden": "warden32"}
static var FRAMES32 := {
	"strider": range(56).map(func(i): return load("res://art/anim/strider32_%d.png" % i)),
	"warden": range(56).map(func(i): return load("res://art/anim/warden32_%d.png" % i)),
}
const Feet32 := preload("res://art/anim/feet32.gd")
const SHEET := {"strider": "player", "warden": "warden"}  # nome dos ficheiros (e da tabela de pés)
const RING := [preload("res://art/fx/ring_p1.png"), preload("res://art/fx/ring_p2.png")]
const REVIVE_TEX := preload("res://art/fx/revive.png")
const GHOST := preload("res://ghost.gdshader")
const Pix := preload("res://fx_pix.gd")

var main
var hero := "strider"
var order: Array = HEROES.strider.order
var pfx := ""  # prefixo das ações de input: "" = jogador 1, "p2_" = jogador 2
var slot := 0
var hero_name := "Strider"
var tint := Color(0.4, 1.0, 0.6)  # cor do jogador no HUD
var portrait: Texture2D = HEROES.strider.portrait
var passives := ["raiz"]
var points := 0
var revive_t := 0.0
var revived_t := 0.0
var lock_skills := false  # depois de fechar um painel, espera que larguem os botões
var walk_t := 0.0
var hp_chunk := 150.0  # o HUD desenha este pedaço atrás da vida e escoa-o com atraso
var chunk_wait := 0.0
var heal_acc := 0.0
var heal_num_t := 0.0
var max_hp := 150.0
var hp := 150.0
var max_mana := 100.0
var mana := 100.0
var touch_move := Vector2.ZERO
var held := {}
var facing := Vector2.RIGHT
var cds := {}
var swing := 0.0
var spin := 0.0
var cast_t := 0.0
var nova_t := 0.0
var guard_t := 0.0
var armor := 0.0
var barrier := 0.0  # Medula Sacrificial (#15): barreira de ossos; aguenta o dano antes da vida e escoa devagar
var hurt := 0.0
var lean_t := 9.0  # desde o último golpe ou Lança: recua, passa à frente e assenta (mola)
var lean_dir := Vector2.ZERO
var tilt := 0.0  # inclina-se para onde anda
var flip_s := 1.0  # espelho suave (1 = direita, -1 = esquerda): vira-se como uma carta em vez de estalar
var body := Node2D.new()  # desenha o herói por cima do anel (no 32-bit sem suavizar: píxeis nítidos)
var trail := Node2D.new()  # fantasmas da esquiva, por baixo do herói
var ghost_tex: Texture2D  # a pose do salto: os fantasmas ficam depois de ele acabar (só local, não viaja)
var ghost_pose := Transform2D()
var pose := Transform2D()  # o desenho deste frame, para main o redesenhar como silhueta atrás de um adereço alto (#92)
var pose_tex: Texture2D
var t := 0.0
var dead := false
var potions := {"hp": POTION_MAX, "mp": POTION_MAX}  # cargas; matar enche-as
var dash_t := 0.0  # a esquivar (invulnerável)
var dash_cd := 0.0
var dash_dir := Vector2.RIGHT
var pacto_t := 0.0  # o aviso "Pacto" quando o Pacto de Carne e Ferro (#101) recusa a esquiva (não repete a cada toque)
var grace_cd := 0.0  # "Por um fio!": um golpe letal com mais de 25% de vida deixa 1 de vida; só volta 20 s depois
var respecs := 0  # quantas vezes a Árvore foi refeita (a primeira é grátis)
var boss_first := false  # a mira automática prefere chefes (Configurações; o convidado manda a dele)
var killed_by := ""  # quem deu o último golpe (o ecrã de morte mostra-o)
## Postura de Combate (#22): "guarda" (Guarda Sepulcral: -25% de dano recebido e devolve parte ao atacante) ou
## "ira" (Ira Sacrificial: +30% de dano, recargas -25%, mas cada habilidade custa 2% da vida).
var stance := "guarda"
var grito_cd := 0.0  # Grito de Guerra Fúnebre (#20): só volta a gritar 12 s depois
## Instabilidade de Alma (#1): cada habilidade com custo junta 60% dele em corrupção (escoa 3 por segundo); a 100
## vem a Sobrecarga de Alma durante OVERLOAD_T: +35% de crítico (main._damage), mas perde 3% da vida por segundo (nunca mata).
var corruption := 0.0
var overload_t := 0.0
var self_bleed_t := 0.0  # Alma Sacrificial (#161): enquanto corre, o próprio herói sangra
var ready_t := {}  # anel de recarga: brilho curto quando uma habilidade longa volta a estar pronta
var chaos_n := 0  # Alma Caótica (#147): quantas vezes já mudou; o resto por 3 diz o estado da vez
var canibal_n := 0  # Canibalismo Espiritual (#122): lacaios comidos, cada um +8% de dano (até 5); perdem-se ao cair
var simb_cd := 0.0  # Almas Simbióticas (#121): só volta a salvar 12 s depois (viaja ao convidado)
var soul := ""  # a Alma Condensada que o herói veste (uma de SOULS; viaja ao convidado e fica no jogo gravado)
var vinganca_cd := 0.0  # Espectro da Vingança (#143): só volta a disparar 1,5 s depois (viaja ao convidado)
var rune_at := Vector2.ZERO  # Escriba da Agonia (#155): onde inscreveu a última runa (a seguinte só a 90 px dela)
var skulls := 4  # Dança dos Crânios Flamejantes (#167): quantos estão em órbita (viaja ao convidado, que os desenha)
var skull_t := 0.0  # até o próximo se lançar
var skull_regrow := 4.0  # até voltar um
var iron_t := 0.0  # Donzela de Ferro Móvel (#174): em couraça (os golpes de área dos chefes só tiram 10%, anda a metade)
var iron_cd := 0.0  # e só volta 25 s depois (viaja ao convidado)
var debt := 0.0  # Sangue Negro Impenetrável (#117): a vida paga que ainda vai voltar (até 50% da vida; viaja ao convidado)
var lich := false  # Apoteose do Lich de Ferro (#140): em forma (as duas poções cheias; viaja ao convidado, que o desenha)
var lich_cd := 0.0  # e depois de beber só volta 20 s depois
var fome_n := 0  # Fome Insaciável da Terra (#137): mortos engolidos (a cada 2 ergue um esqueleto; até 6; viaja ao convidado, que os desenha)

var skills := {
	"scythe": {"name": "Ceifa Sepulcral", "mana": 0.0, "cd": 0.4, "dmg": 22.0, "area": 95.0, "support": ""},
	"bolt": {"name": "Lança de Almas", "mana": 10.0, "cd": 0.55, "dmg": 34.0, "area": 16.0, "support": ""},
	"nova": {"name": "Explosão Espectral", "mana": 28.0, "cd": 2.5, "dmg": 45.0, "area": 170.0, "support": ""},
	"chop": {"name": "Golpe do Carrasco", "mana": 0.0, "cd": 0.55, "dmg": 30.0, "area": 105.0, "support": ""},
	"cleave": {"name": "Ceifa de Ossos", "mana": 16.0, "cd": 2.0, "dmg": 38.0, "area": 150.0, "support": ""},
	"bonearmor": {"name": "Armadura de Ossos", "mana": 25.0, "cd": 9.0, "dmg": 0.0, "area": 0.0, "support": ""},
}


func setup(h: String, index: int) -> void:
	hero = h
	slot = index
	order = HEROES[h].order
	hero_name = HEROES[h].name
	portrait = HEROES[h].portrait
	pfx = "" if index == 0 else "p2_"
	tint = Color(0.4, 1.0, 0.6) if index == 0 else Color(1.0, 0.75, 0.35)
	for id in order:
		cds[id] = 0.0
	trail.material = ShaderMaterial.new()
	trail.material.shader = GHOST
	trail.draw.connect(_draw_trail)
	add_child(trail)
	body.draw.connect(_draw_body)
	add_child(body)


func stat(key: String) -> float:
	var v: float = main.stat(key)
	for id in passives:
		v += main.PASSIVES[id].stats.get(key, 0.0)
	if key == "dmg":  # Canibalismo Espiritual (#122): soma-se aos outros +% dano, como o reforço da arma em main.stat
		v += canibal_n * 0.08
	return v


## Vida e mana máximas: base + nível do grupo + árvore.
func refresh_stats() -> void:
	max_hp = (150.0 + stat("hp_max") + (main.level - 1) * 8.0) * (1.0 + stat("hp_mul"))  # a Comunhão dos Vermes-Deuses (#112) corta-a a meio
	hp = minf(hp, max_hp)  # o que passa do novo máximo sai logo (com a Árvore em pausa a barra passava do cheio)
	max_mana = 100.0 + stat("mana_max")


func allocate(id: String) -> bool:
	var n: Dictionary = main.PASSIVES[id]
	if points < 1 or id in passives or not n.req in passives or EXCLUSIVE.get(id, "") in passives:
		return false
	points -= 1
	passives.append(id)
	refresh_stats()
	return true


## Refazer a Árvore: devolve todos os pontos (a primeira vez é grátis, depois custa 1 Cinza do Purgatório).
func respec() -> String:
	if respecs > 0:
		if main.currency.ash < 1:
			return "Sem Cinzas do Purgatório."
		main.currency.ash -= 1
	respecs += 1
	passives = ["raiz"]
	points = main.level - 1
	canibal_n = 0  # o que os nós deram ao herói sai com eles
	fome_n = 0
	refresh_stats()
	mana = minf(mana, max_mana)
	return tr("Árvore refeita: %d pontos devolvidos") % points


func _process(delta: float) -> void:
	t += delta
	revived_t = maxf(0.0, revived_t - delta)
	if dead:
		return
	var dir := Input.get_vector(pfx + "move_left", pfx + "move_right", pfx + "move_up", pfx + "move_down")
	if touch_move != Vector2.ZERO:
		dir = touch_move
	var start := position
	if dash_t > 0.0:
		dash_t -= delta
		position += dash_dir * DASH_SPEED * delta
		if dash_t <= 0.0:  # chegada: um anel no sítio onde aterra
			main.spawn_fx("ring", position, 40.0, Color(0.6, 1.0, 0.9))
		if stat("teeth") > 0.0 and (main.teeth.is_empty() or main.teeth[-1][0].distance_to(position) > 30.0):
			main.teeth.append([position, 3.0])
			if main.teeth.size() > 24:  # a Alma Mártir devolve a esquiva a cada abate: sem teto a lista crescia sem fim
				main.teeth.pop_front()
	else:
		position += dir * 230.0 * (1.0 + stat("speed")) * main.blood_speed(position) * (0.5 if iron_t > 0.0 else 1.0) * delta
	position = position.clamp(main.bounds.position + Vector2(30, 30), main.bounds.end - Vector2(30, 30))
	position = main.walk(start, position)
	walk_t = walk_t + delta if dir.length() > 0.2 else 0.0
	# Durante um ataque fica virado para o alvo; parado, vira-se para o inimigo mais perto
	if dash_t > 0.0:
		facing = dash_dir
	elif swing <= 0.0 and spin <= 0.0 and cast_t <= 0.0 and nova_t <= 0.0:
		facing = dir.normalized() if dir.length() > 0.2 else _aim()
	tilt = lerpf(tilt, dir.x * 0.06, 1.0 - exp(-10.0 * delta))
	flip_s = move_toward(flip_s, 1.0 if facing.x > 0.0 else -1.0, delta * 12.0)
	if stat("fragmentada") > 0.0:  # Mente Fragmentada (#108): a mana fica a zero; quem paga as habilidades é a poção de alma
		mana = 0.0
	elif stat("semalma") <= 0.0:  # Sem Alma Própria (#132): sem regeneração; a alma vem das esferas dos abates
		mana = minf(max_mana, mana + (7.0 + stat("regen")) * delta)
	hp = minf(max_hp, hp + 1.0 * delta)
	corruption = maxf(0.0, corruption - 3.0 * delta)
	if overload_t > 0.0:  # a Sobrecarga escoa a vida, mas nunca mata
		overload_t = maxf(0.0, overload_t - delta)
		pay_life(max_hp * (0.06 if stat("imolacao") > 0.0 else 0.03) * delta)  # Imolação Funerária (#127): escoa o dobro
	if self_bleed_t > 0.0:  # Alma Sacrificial: sangra 1,5% da vida por segundo, mas nunca mata
		self_bleed_t = maxf(0.0, self_bleed_t - delta)
		pay_life(max_hp * 0.015 * delta)
		hurt = maxf(hurt, 0.06)  # fica avermelhado enquanto sangra (abaixo de 0,1 não muda o desenho)
	if debt > 0.0:  # Sangue Negro Impenetrável (#117): a vida paga volta a 3% por segundo
		var back := minf(debt, max_hp * 0.03 * delta)
		debt -= back
		heal(back)
	# Apoteose do Lich de Ferro (#140): com as duas poções cheias é o Lich; beber quebra a forma por 20 s
	lich_cd = maxf(0.0, lich_cd - delta)
	var up: bool = stat("lich") > 0.0 and lich_cd <= 0.0 and potions.hp >= POTION_MAX and potions.mp >= POTION_MAX
	if up and not lich:
		main.number(position + Vector2(0, -120), tr("Apoteose!"), 20.0, Color(0.72, 0.78, 0.9))
		main.spawn_fx("ring", position, 90.0, Color(0.72, 0.78, 0.9))
		main.vibrate(60, 0.6, self)
	lich = up
	for k in cds:
		if cds[k] > 0.0 and cds[k] <= delta and skills[k].cd >= RING_CD:
			ready_t[k] = READY_T
			if skills[k].dmg == 0.0:
				main.vibrate(40, 0.4, self)  # a defesa (Armadura de Ossos) voltou: sente-se no telemóvel de quem a tem
		cds[k] = maxf(0.0, cds[k] - delta)
		ready_t[k] = maxf(0.0, ready_t.get(k, 0.0) - delta)
	swing = maxf(0.0, swing - delta)
	dash_cd = maxf(0.0, dash_cd - delta)
	pacto_t = maxf(0.0, pacto_t - delta)
	grace_cd = maxf(0.0, grace_cd - delta)
	grito_cd = maxf(0.0, grito_cd - delta)
	simb_cd = maxf(0.0, simb_cd - delta)
	iron_t = maxf(0.0, iron_t - delta)
	iron_cd = maxf(0.0, iron_cd - delta)
	vinganca_cd = maxf(0.0, vinganca_cd - delta)
	spin = maxf(0.0, spin - delta)
	cast_t = maxf(0.0, cast_t - delta)
	nova_t = maxf(0.0, nova_t - delta)
	guard_t = maxf(0.0, guard_t - delta)
	armor = maxf(0.0, armor - delta)
	barrier = maxf(0.0, barrier - max_hp * 0.01 * delta)  # escoa devagar: 1% da vida máxima por segundo (cheia, ~25 s)
	if wears("martir"):  # Alma Mártir (#151): sem barreira de ossos, nem a que já havia
		barrier = 0.0
	hurt = maxf(0.0, hurt - delta)
	lean_t += delta
	chunk_wait -= delta
	hp_chunk = maxf(hp_chunk, hp) if chunk_wait > 0.0 else move_toward(hp_chunk, hp, max_hp * 0.8 * delta)
	heal_num_t -= delta
	if heal_num_t <= 0.0 and heal_acc >= 3.0:
		heal_num_t = 0.5
		main.number(position + Vector2(0, -90), "+%d" % int(heal_acc), 15.0, Color(0.45, 1.0, 0.55))
		heal_acc = 0.0
	if soul == "cranios":
		_skulls(delta)
	if stat("fome") > 0.0:
		_fome(delta)
	var want := []
	for i in 3:
		if Input.is_action_pressed(pfx + "skill_%d" % (i + 1)) or held.get(order[i], false):
			want.append(order[i])
	if lock_skills:
		lock_skills = not want.is_empty()  # o A que fechou um painel não conta como ataque
	else:
		for id in want:
			use_skill(id)
		if self == main.player and auto_attack():
			use_skill(order[0])
	if Input.is_action_just_pressed(pfx + "interact") and Engine.get_process_frames() > main.hud.closed_frame:  # B: interage com o que está perto; sem nada, esquiva
		if main.hud.hint_action != "":
			main.interact()
		else:
			dodge(dir)
	if Input.is_action_just_pressed(pfx + "stance"):
		toggle_stance()
	if Input.is_action_just_pressed(pfx + "potion_hp"):
		use_potion("hp")
	if Input.is_action_just_pressed(pfx + "potion_mp"):
		use_potion("mp")
	queue_redraw()


## Esquiva Espectral: um salto rápido para onde se anda (ou para a frente), sem levar dano durante o salto.
func dodge(dir: Vector2) -> void:
	if Net.is_guest():
		Net.dodge(dir)
		return
	if dead or dash_cd > 0.0:
		return
	if stat("pacto") > 0.0:  # Pacto de Carne e Ferro (#101): sem Esquiva Espectral; diz porquê em vez de não fazer nada
		if pacto_t <= 0.0:
			pacto_t = 0.5
			main.number(position + Vector2(0, -110), tr("Pacto"), 16.0, Color(0.7, 0.7, 0.75))
		return
	dash_dir = dir.normalized() if dir.length() > 0.2 else facing
	dash_t = DASH_T
	dash_cd = DASH_CD
	main.sfx("dash")
	main.vibrate(20, 0.4, self)
	if stat("sentinel") > 0.0:  # Sentinelas Tumulares (#25): finca uma lápide onde estava; no máximo 2 por herói (a mais antiga sai)
		var mine: Array = main.sentinels.filter(func(s): return s[3] == slot)
		if mine.size() >= 2:
			main.sentinels.erase(mine[0])
		main.sentinels.append([position, main.time + 10.0, main.time + 0.6, slot])
	main.spawn_decoy(self)
	main.spawn_fx("dash", position, DASH_SPEED * DASH_T, Color.WHITE, dash_dir, "bleed" if stance == "ira" else "iron" if lich else "soul")  # cinzas, riscos e derrapagem


## Guarda Sepulcral ↔ Ira Sacrificial (no convidado, quem troca é o anfitrião).
func toggle_stance() -> void:
	if Net.is_guest():
		Net.stance()
		return
	if dead:
		return
	stance = "ira" if stance == "guarda" else "guarda"
	var ira := stance == "ira"
	main.number(position + Vector2(0, -120), tr("Ira Sacrificial") if ira else tr("Guarda Sepulcral"), 20.0, Color(1.0, 0.35, 0.3) if ira else Color(0.85, 0.85, 0.75))
	main.spawn_fx("ring", position, 60.0, Color(0.9, 0.2, 0.2) if ira else Color(0.85, 0.82, 0.7))
	main.vibrate(30, 0.4, self)
	if ira and grito_cd <= 0.0 and stat("grito") > 0.0:  # Grito de Guerra Fúnebre (#20): os mortos menores à volta entram em pânico
		grito_cd = 12.0
		for e in main.enemies():
			if not e.is_boss and not e.dummy and e.position.distance_to(position) < 240.0 + e.radius:
				e.panic_t = 4.0
				e.panic_target = null
				e._number(tr("Pânico!"), 16.0, Color(1.0, 0.8, 0.4))
		main.spawn_fx("ring", position, 240.0, Color(1.0, 0.35, 0.3))
		main.sfx("roar")
		main.shake = maxf(main.shake, 8.0)
		main.vibrate(60, 0.7, self)


## Troca o frasco de uma habilidade pelo seguinte que o grupo já encontrou.
func cycle_support(id: String) -> void:
	var have: Array = SUPPORTS.filter(func(f): return f in main.flasks)
	var s: Dictionary = skills[id]
	s.support = have[(have.find(s.support) + 1) % have.size()]


## Põe na habilidade um frasco que o grupo já encontrou (a grelha do Arsenal).
func set_support(id: String, f: String) -> void:
	if id in order and f in SUPPORTS and f in main.flasks:
		skills[id].support = f


## Veste a Alma Condensada (uma que o grupo já encontrou; "" tira-a).
func set_soul(f: String) -> void:
	if f in SOULS and f in main.flasks:
		soul = f


## Alguma habilidade do herói leva este frasco?
func wears(f: String) -> bool:
	return order.any(func(id): return skills[id].support == f)


## Poção de vida (40% da vida) ou de alma (60% da alma). Gasta uma carga; não se gasta cheia.
func use_potion(kind: String) -> void:
	if Net.is_guest():
		Net.tap(1 if kind == "hp" else 2)
		return
	# Sangue Negro (#117) não bebe a de vida; Mente Fragmentada (#108) não bebe a de alma
	if dead or potions[kind] < 1.0 or (hp >= max_hp if kind == "hp" else mana >= max_mana) or stat("sangue" if kind == "hp" else "fragmentada") > 0.0:
		return
	potions[kind] -= 1.0
	lich = false  # o Lich (#140) quebra antes da cura: a poção cura vida, não vira barreira
	lich_cd = 20.0
	if kind == "hp":
		heal(max_hp * 0.4)
	else:
		mana = minf(max_mana, mana + max_mana * 0.6)
	main.sfx("potion")
	if main.effects_level() == 0:  # efeitos baixos: o brilho simples
		main.spawn_fx("glow", position + Vector2(0, -40), 55.0, Color(1.0, 0.3, 0.3) if kind == "hp" else Color(0.35, 0.7, 1.0))
	else:  # cruzes vermelhas (vida) ou gotas azuis (alma) que sobem do herói e o seguem
		main.spawn_fx("heal", position, 18.0 if kind == "hp" else 14.0, Color.WHITE, Vector2.RIGHT, "life" if kind == "hp" else "soulblue").follow = slot


func fill_potions(amount: float) -> void:
	for k in potions:
		potions[k] = minf(POTION_MAX, potions[k] + amount)


func use_skill(id: String) -> void:
	if dead or cds[id] > 0.0:
		return
	var s: Dictionary = skills[id]
	var cost: float = s.mana
	if s.support == "parasita":
		var life_cost := maxf(cost * 1.5, 6.0)
		if hp <= life_cost + 1.0:
			return
		pay_life(life_cost)
		hurt = 0.1
	elif stat("fragmentada") > 0.0:  # Mente Fragmentada (#108): bebe da poção de alma (60 de custo = 1 carga)
		if potions.mp < cost / 60.0:
			return
		potions.mp -= cost / 60.0
		if cost > 0.0:
			main.spawn_fx("sparks", position + Vector2(0, -40), 0.0, Color(0.35, 0.7, 1.0))
	else:
		if mana < cost:
			return
		mana -= cost
	if stance == "ira":  # a Ira paga-se em sangue (nunca mata)
		pay_life(max_hp * 0.02)
		hurt = 0.08
	if s.support == "carga":  # cada uso renova os 3 s de sangria (não se soma)
		self_bleed_t = 3.0
	if s.support == "meteoro" and id in ["nova", "cleave"]:  # Alma Meteórica (#159): o esmagamento paga-se em sangue, mas nunca mata
		pay_life(max_hp * 0.08)
		hurt = 0.1
	if overload_t <= 0.0:  # Instabilidade de Alma: o custo base pesa na alma, também quando a Parasita paga com vida
		add_corruption(cost * 0.6)
	var n := skill_numbers(id)
	if s.support == "gatilho" and s.area > 0.0:  # gasta o abate que deu a área maior (a Armadura de Ossos não tem área)
		var g: Array = main.grave_near(position)
		if not g.is_empty():
			main.graves.erase(g)
			main.spawn_fx("burst", g[0], 0.0, Color(0.35, 0.3, 0.3))
			main.spawn_fx("ring", g[0], 60.0, Color(0.35, 0.3, 0.3))
	cds[id] = n[2]
	var aim := _aim()
	facing = aim
	flip_s = 1.0 if aim.x > 0.0 else -1.0  # ao atacar vira-se logo
	_cast(id, n[0], n[1], aim, s.support)
	if s.support == "roubo" and potions.hp + potions.mp > 0.0:  # a Ladra bebe da poção mais cheia; este golpe já teve o bónus
		var k := "hp" if potions.hp >= potions.mp else "mp"
		potions[k] = maxf(0.0, potions[k] - 0.125)  # 1/8 e não 1/10: as cargas ficam múltiplos exatos (matar dá 1/4) e a poção cheia nunca vira 0,9999
	if s.support == "eco":
		await get_tree().create_timer(0.35, false).timeout
		if is_inside_tree() and not dead:
			_cast(id, n[0] * 0.6, n[1], _aim(), "eco")


## Dano, área e recarga de uma habilidade agora, e de onde vem o dano: [dano, área, recarga,
## [[nome, multiplicador], ...]]. O Arsenal mostra as partes (Fórmulas de dano).
func skill_numbers(id: String) -> Array:
	var s: Dictionary = skills[id]
	var area: float = s.area
	var cd: float = s.cd
	var parts := [["bónus de dano", 1.0 + stat("dmg")]]
	if stance == "ira":
		parts.append(["Ira Sacrificial", 1.3])
		cd *= 0.75
	if stat("circulacao") > 0.0:  # Circulação Negra (#119): -1% de recarga por cada 2% de vida perdida, até -35% (a Esquiva não passa aqui)
		cd *= 1.0 - 0.35 * clampf((1.0 - hp / max_hp) / 0.7, 0.0, 1.0)
	if lich:
		parts.append([main.PASSIVES.lich.name, 1.3])
	if s.mana > 0.0 and s.support != "parasita" and stat("fragmentada") > 0.0:  # a Parasita paga com vida: não bebe da poção nem ganha o bónus
		parts.append([main.PASSIVES.fragmentada.name, 1.4])
	if id in ["bolt", "nova"]:
		parts.append(["bónus de feitiços", 1.0 + stat("spell")])
	match s.support:
		"parasita":
			parts.append([SUPPORT_NAMES.parasita, 2.2])
			area *= 1.5
		"titanica":
			area *= 1.8
			cd *= 1.7
		"veloz":
			parts.append([SUPPORT_NAMES.veloz, 0.8])
			cd *= 0.55
		"colerica":
			parts.append([SUPPORT_NAMES.colerica, 1.0 + 0.8 * clampf((1.0 - hp / max_hp) / 0.7, 0.0, 1.0)])
		"roubo":  # Alma Ladra: só enquanto houver poção para roubar (quem bebe é o use_skill)
			if potions.hp + potions.mp > 0.0:
				cd *= 0.7
		"gatilho":  # Alma Gatilho: há um abate recente perto para gastar (quem o gasta é o use_skill)
			if not main.grave_near(position).is_empty():
				area *= 1.5
		"carga":
			parts.append([SUPPORT_NAMES.carga, 1.3])
		"meteoro":  # Alma Meteórica (#159): só os esmagamentos (Nova e Ceifa de Ossos); nos golpes básicos, com ataque automático, escoava a vida sem parar
			if id in ["nova", "cleave"]:
				area *= 1.75
				cd *= 2.2
		"terramoto":  # Alma Sísmica (#173): só a Nova e a Ceifa de Ossos batem no chão; nas outras não faz nada nem custa
			if id in ["nova", "cleave"]:
				parts.append([SUPPORT_NAMES.terramoto, 0.75])
				cd *= 1.6
	var dmg: float = s.dmg
	for p in parts:
		dmg *= p[1]
	return [dmg, area, cd, parts]


## O efeito da habilidade (custo e recarga já pagos em use_skill; o Eco chama-o outra vez, de graça).
func _cast(id: String, dmg: float, area: float, aim: Vector2, support: String) -> void:
	if support == "terramoto" and not id in ["nova", "cleave"]:  # Alma Sísmica: só os golpes no chão; a Lança rebenta em hit_circle e petrificava a cada 0,55 s
		support = ""
	var green := Color(0.9, 0.15, 0.25) if support in ["parasita", "carga", "meteoro"] else Color(0.35, 1.0, 0.6)
	var tone := "bleed" if support in ["parasita", "carga", "meteoro"] else ""  # a rampa do golpe em píxeis, a par do verde
	if support == "roubo" and potions.hp + potions.mp > 0.0:
		green = Color(1.0, 0.6, 0.25)  # âmbar: a Ladra está a roubar às poções
		tone = "gold"
	if support == "gravidade":
		green = Color(0.55, 0.35, 0.8)  # violeta: a Gravitacional
		tone = "necro"
	if support == "terramoto":
		green = Color(0.85, 0.8, 0.65)  # cor de osso: a Sísmica (a do anel da Ceifa de Ossos)
		tone = "bone"
	var raise := 2 if support == "mitotico" else 1 if support == "tumular" else 0  # quantos aliados se erguem de quem morrer com este golpe
	main.raise_by = self if raise > 0 else null
	main.raise_n = raise
	main.cast_support = support  # o frasco deste golpe, para main._damage (posto e limpo como o raise_by)
	if support == "caotico":  # Alma Caótica (#147): podridão, necrose, calcificação, podridão... um estado por uso
		main.cast_aff = 1 + chaos_n % 3
		chaos_n += 1
		green = main.CORPSE_COLORS[main.cast_aff]  # as cores que os crânios do #9 já ensinaram
		tone = ["", "rot", "necro", "bone"][main.cast_aff]
	if id in ["scythe", "chop", "bolt"]:
		lean_t = 0.0
		lean_dir = aim
	match id:
		"scythe", "chop":
			swing = ATTACK_T
			main.sfx("swing" if id == "scythe" else "swing_heavy")  # ouve-se a lâmina mesmo sem acertar
			main.hit_arc(position, aim, area, dmg, self)
			# foice de alma, machado de osso (gume branco nos dois); o frasco muda a cor como ao verde; o eco sai mais fraco
			if tone == "":
				tone = "soul" if id == "scythe" else "bone"
			main.spawn_fx("slash", position + Vector2(0, -20), area, Color(1, 1, 1, 0.6 if support == "eco" else 1.0), aim, tone, 20.0)
		"bolt":
			cast_t = CAST_T
			main.sfx("cast")
			main.spawn_fx("glow", position + Vector2(0, -20), 40.0, Color(0.6, 0.4, 1.0))  # a alma junta-se na mão antes de partir
			# Antecipação: a Lança só parte quando o braço avança (2.º frame do lançamento)
			var aff: int = main.cast_aff  # a Lança parte depois de o golpe acabar: leva a afinidade consigo
			get_tree().create_timer(CAST_T / 4.0, false).timeout.connect(func():
				if is_inside_tree() and not dead:
					var b = main.spawn_bolt(position + Vector2(0, -20), aim, dmg, area, self, raise)
					b.support = support
					b.aff = aff)
		"nova":
			nova_t = NOVA_T
			main.sfx("cast")
			main.hit_circle(position, area, dmg, self)
			main.spawn_fx("ring", position, area, green)
		"cleave":
			spin = SPIN_T
			main.sfx("swing_heavy")
			main.hit_circle(position, area, dmg, self, true)
			main.spawn_fx("ring", position, area, Color(0.9, 0.25, 0.3) if support in ["parasita", "carga", "meteoro"] else green if support == "caotico" else Color(0.85, 0.8, 0.65))
		"bonearmor":
			armor = 5.0
			guard_t = GUARD_T
			main.spawn_fx("ring", position + Vector2(0, -30), 70.0, Color(0.9, 0.85, 0.7))
	if support == "meteoro" and id in ["nova", "cleave"]:  # Alma Meteórica (#159): 6 estilhaços de osso a direito (sem seek: não perseguem)
		if main.fx_budget("explosion", 2, 4):  # e rebenta o chão: cratera, terra e pedras de osso, clarão de alma
			main.spawn_fx("explosion", position, 1.4, Color(0.35, 1.0, 0.6), Vector2.RIGHT, "ash")
		for i in 6:
			main.spawn_bolt(position, Vector2.from_angle(TAU * i / 6.0 + 0.3), dmg * 0.25, 10.0, self, 0, true)
	main.raise_by = null
	main.cast_support = ""
	main.cast_aff = 0


func _aim() -> Vector2:
	var best = target()
	return facing if best == null else position.direction_to(best.position)


## Ataque automático (um polegar): há um inimigo ao alcance do 1.º golpe.
func auto_attack() -> bool:
	if not main.settings.auto_attack:
		return false
	var t = target()
	return t != null and position.distance_to(t.position) < skills[order[0]].area + t.radius + 30.0


## O inimigo mais perto ao alcance da mira automática (ou null); com boss_first, um chefe ao alcance ganha.
func target():
	var best = null
	var best_d := 480.0
	for e in main.enemies():
		var d: float = position.distance_to(e.position)
		if boss_first and e.is_boss and d < 480.0:
			d -= 1000.0
		if d < best_d:
			best_d = d
			best = e
	return best


## Dança dos Crânios Flamejantes (#167): um crânio por 0,8 s lança-se ao monstro mais perto a 320 px (um Espectro ao
## alcance ganha sempre, como o chefe no boss_first) e volta um a cada 4 s. É o estilhaço teleguiado das Sentinelas, cor de fogo.
func _skulls(delta: float) -> void:
	skull_t = maxf(0.0, skull_t - delta)  # parado no 0: não viaja ao convidado a cada frame
	if skulls < 4:
		skull_regrow -= delta
		if skull_regrow <= 0.0:
			skulls += 1
			skull_regrow = 4.0
	if skulls <= 0 or skull_t > 0.0:
		return
	var best = null
	var best_d := 320.0
	for e in main.enemies():
		var d: float = position.distance_to(e.position)
		if e.kind == "specter" and d < 320.0:  # sem o "< 320" um Espectro a 1100 px ganhava
			d -= 1000.0
		if d < best_d:
			best_d = d
			best = e
	if best == null:
		return
	skulls -= 1
	skull_t = 0.8
	var from := position + Vector2(0, -30)  # do peito, não da roda: na cripta a roda podia estar dentro de uma parede
	var dir := from.direction_to(best.position + Vector2(0, -20))
	var b = main.spawn_bolt(from, dir, 12.0 + 2.0 * main.level, 11.0, self, 0, true)
	b.seek = best
	b.skull = true
	b.tint = Color(1.0, 0.55, 0.2)
	b.quiet = true
	main.spawn_fx("sparks", from, 0.0, b.tint, dir)


## Onde anda o crânio i da roda (o desenho e o lançamento usam o mesmo sítio; t viaja ao convidado).
func _skull_at(i: int) -> Vector2:
	return Vector2.from_angle(t * 3.0 + i * TAU / 4.0) * 46.0 + Vector2(0, -30)


## Fome Insaciável da Terra (#137): a cada 2 mortos engolidos ergue um esqueleto teu (com lugar no grupo); sem nenhum de pé, come-te 2% da vida por segundo até metade.
func _fome(delta: float) -> void:
	var all := get_tree().get_nodes_in_group("allies").filter(func(a): return a.life > 0.0)
	var mine := all.filter(func(a): return a.owner_p == self).size()
	if fome_n >= 2 and all.size() < main.MAX_ALLIES:
		fome_n -= 2
		mine += 1
		main.spawn_ally(main.walk(position, position + Vector2(randf_range(-50.0, 50.0), 30.0)), self)
	if mine == 0 and hp > max_hp * 0.5:
		hp = maxf(max_hp * 0.5, hp - max_hp * 0.02 * delta)
		hurt = maxf(hurt, 0.06)  # fica avermelhado enquanto o come (abaixo de 0,1 não muda o desenho)


## Vida paga (Ira, frascos, Sobrecarga): nunca mata; com o Sangue Negro (#117) fica em dívida para voltar.
func pay_life(x: float) -> void:
	var before := hp
	hp = maxf(1.0, hp - x)
	if stat("sangue") > 0.0:
		debt = minf(debt + before - hp, max_hp * 0.5)


## Instabilidade de Alma (#1): junta corrupção; a 100 rebenta na Sobrecarga de Alma.
func add_corruption(x: float) -> void:
	corruption += x
	if corruption >= 100.0:
		corruption = 0.0
		overload_t = OVERLOAD_T
		main.number(position + Vector2(0, -120), tr("Sobrecarga de Alma!"), 20.0, Color(0.75, 0.4, 1.0))
		main.spawn_fx("ring", position, 90.0, Color(0.65, 0.3, 1.0))
		main.vibrate(60, 0.6, self)


## Alma que entra (esferas, Éter, extração, execução); com a Mente Fragmentada (#108) enche a poção de alma (60 = 1 carga).
func add_mana(x: float) -> void:
	if stat("fragmentada") > 0.0:
		potions.mp = minf(POTION_MAX, potions.mp + x / 60.0)
	else:
		mana = minf(max_mana, mana + x)


func heal(amount: float) -> void:
	if dead:
		return
	if lich:  # Apoteose do Lich de Ferro (#140): toda a cura vira barreira de ossos (o tecto da Medula, #15)
		if not wears("martir"):  # a Alma Mártir (#151) não deixa nada virar barreira
			barrier = minf(barrier + amount, max_hp * 0.25)
		return
	# Sutura Biológica Instantânea (#138): a cura que passa da vida máxima vira barreira de ossos (o tecto da Medula, #15)
	var over := amount - (max_hp - hp)
	if over > 0.0 and stat("sutura") > 0.0 and not wears("martir"):  # a Alma Mártir (#151) não deixa nada virar barreira
		barrier = minf(barrier + over, max_hp * 0.25)
	heal_acc += minf(amount, max_hp - hp)
	hp = minf(max_hp, hp + amount)


## Em co-op o jogador cai em vez de morrer; um aliado perto dele reanima-o (main._coop).
func revive() -> void:
	dead = false
	revive_t = 0.0
	revived_t = 0.6
	hp = max_hp * 0.5


func take_damage(amount: float, by := "", src = null) -> void:
	if dead:
		return
	if dash_t > 0.0:  # esquiva perfeita: a alma sai do caminho e quem bateu fica exposto
		if src != null and is_instance_valid(src) and src.exposed_t <= 0.0:
			src.exposed_t = src.EXPOSE_T
			main.number(position + Vector2(0, -110), tr("Esquiva perfeita!"), 20.0, Color(0.6, 1.0, 0.9))
			main.hitstop(0.06)
			main.sfx("crit", 1.3)
			main.hud.flash(0.15)
		return
	# Presença Cadavérica Intimidatória (#131): um morto menor a 3 m falha 30% dos golpes (antes do Pacto: falhar não rebenta espinhos)
	if src != null and is_instance_valid(src) and "is_boss" in src and not src.is_boss and stat("presenca") > 0.0 and position.distance_to(src.position) <= 150.0 and main.rng.randf() < 0.3:
		main.number(position + Vector2(0, -110), tr("Falhou!"), 18.0, Color(0.7, 0.7, 0.75))
		return
	if stat("pacto") > 0.0:  # Pacto de Carne e Ferro (#101): o golpe inteiro rebenta espinhos de osso à volta e só passa 70%
		main.quiet = true  # os espinhos não param o jogo: numa horda eram uma paragem de impacto a cada golpe levado
		main.hit_circle(position, 100.0, amount * 1.5, self)
		main.quiet = false
		amount *= 0.7
	killed_by = by
	if armor > 0.0:
		amount *= 0.5
	if lich:  # Lich de Ferro (#140): -20% de dano recebido
		amount *= 0.8
	if stance == "guarda":  # Guarda Sepulcral: aguenta e devolve
		amount *= 0.75
		if src != null and is_instance_valid(src) and src.has_method("apply_rot"):
			src.take_damage(amount * 0.6, true, position.direction_to(src.position))
	if stat("ossea") > 0.0:  # Densidade Osteológica (#105): -3% por cada lacaio teu de pé (o tecto de 4 lacaios dá -12%)
		amount *= 1.0 - 0.03 * get_tree().get_nodes_in_group("allies").filter(func(a): return a.owner_p == self and a.life > 0.0).size()
	# Medula Sacrificial (#15): a barreira de ossos aguenta primeiro; do que passa, uma parte não tira vida e vira barreira
	var soak := minf(barrier, amount)
	barrier -= soak
	if barrier <= 0.0 and soak >= max_hp * 0.1 and stat("ecos") > 0.0:  # Ecos do Último Suspiro (#114): a barreira que quebra (não a que escoa) petrifica os mortos menores à volta
		for e in main.enemies():
			if not e.dummy and e.position.distance_to(position) < 250.0 + e.radius:
				if e.is_boss:
					e.slow_t = maxf(e.slow_t, 1.5)
				else:  # estátua e não quebrado: o quebrado (stagger_t) deixava extrair a Alma Ancestral a qualquer um
					e.statue_t = maxf(e.statue_t, 1.5)
		main.spawn_fx("ring", position, 250.0, Color(0.8, 0.88, 0.96))
		main.shake = maxf(main.shake, 8.0)
	amount -= soak
	if amount <= 0.0:  # a barreira aguentou tudo: número cor de osso, sem dor nem tremor
		main.number(position + Vector2(randf_range(-10, 10), -90), str(roundi(soak)), 15.0, Color(0.8, 0.88, 0.96))
		return
	var keep := 0.0 if wears("martir") else amount * stat("bone_barrier")  # a Alma Mártir (#151) não deixa nada virar barreira
	barrier = minf(barrier + keep, max_hp * 0.25)
	amount -= keep
	if overload_t <= 0.0 and stat("imolacao") > 0.0:  # Imolação Funerária (#127): 40% do golpe arde como corrupção em vez de vida (na Sobrecarga não)
		var burn := amount * 0.4
		amount -= burn
		add_corruption(burn)
		if burn >= 0.5:  # sem "0" nos golpes pequenos que a Guarda ou a barreira já comeram
			main.number(position + Vector2(22, -110), str(roundi(burn)), 14.0, Color(0.75, 0.4, 1.0))
	if hp - amount <= 0.0 and simb_cd <= 0.0 and stat("simb") > 0.0:  # Almas Simbióticas (#121): o teu lacaio mais perto leva o golpe que te matava
		var lacaio = null
		for a in get_tree().get_nodes_in_group("allies"):  # no máximo MAX_ALLIES, e só num golpe letal
			if a.owner_p == self and a.life > 0.0 and (lacaio == null or position.distance_squared_to(a.position) < position.distance_squared_to(lacaio.position)):
				lacaio = a
		if lacaio != null:
			lacaio.life = 0.0  # desfaz-se no frame seguinte: o miasma (ou o Canibalismo) acontece como sempre
			simb_cd = 12.0
			main.number(position + Vector2(randf_range(-10, 10), -90), str(roundi(amount)), 15.0, Color(0.8, 0.88, 0.96))  # cor de osso, como quando a barreira aguenta tudo
			return
	if amount >= hp and hp >= max_hp * 0.25 and grace_cd <= 0.0:  # Por um fio: quem estava bem não morre de um golpe só
		grace_cd = 20.0
		amount = hp - 1.0
		main.number(position + Vector2(0, -130), tr("Por um fio!"), 20.0, Color(1.0, 0.9, 0.6))
	hp -= amount
	hurt = 0.2
	chunk_wait = 0.5
	main.number(position + Vector2(randf_range(-10, 10), -90), str(roundi(amount)), 15.0 + clampf(amount / 2.0, 0.0, 16.0), Color(1.0, 0.3, 0.3))
	main.shake = maxf(main.shake, 6.0)
	main.sfx("hurt")
	main.vibrate(60, 0.6, self)
	if soul == "vinganca" and amount > max_hp * 0.2 and vinganca_cd <= 0.0:  # Espectro da Vingança (#143): o golpe grande dispara flechas espectrais a quem bateu e aos mais perto
		vinganca_cd = 1.5
		var quem = src if src != null and is_instance_valid(src) and src.is_in_group("enemies") else null  # quem está a morrer já saiu do grupo
		var alvos: Array = main.enemies().filter(func(e): return e != quem and position.distance_to(e.position) < 400.0)
		alvos.sort_custom(func(x, y): return position.distance_squared_to(x.position) < position.distance_squared_to(y.position))
		if quem != null:
			alvos.push_front(quem)  # quem bateu vai sempre, mesmo longe (o estilhaço voa ~700 px)
		var from := position + Vector2(0, -30)
		for e in alvos.slice(0, 5):  # quem bateu e até 4 à volta
			var dir := from.direction_to(e.position + Vector2(0, -20))
			var b = main.spawn_bolt(from, dir, 14.0 + 2.0 * main.level, 10.0, self, 0, true)
			b.seek = e
			b.tint = Color(0.7, 0.5, 1.0)
			b.quiet = true
			main.spawn_fx("sparks", from, 0.0, b.tint, dir)
	if hp <= 0.0:
		hp = 0.0
		barrier = 0.0
		corruption = 0.0  # quem cai não volta a meio de uma Sobrecarga
		overload_t = 0.0
		self_bleed_t = 0.0
		debt = 0.0  # Sangue Negro (#117): a dívida perde-se ao cair
		lich = false  # quem cai não fica a flutuar
		fome_n = 0  # a terra não guarda os mortos de quem caiu
		canibal_n = 0
		dead = true
		queue_redraw()
		died.emit()


func _frame() -> int:
	if hero == "warden":
		if dead:
			return 10
		if revived_t > 0.0:
			return 11
		if spin > 0.0:
			return 12 + mini(3, int((1.0 - spin / SPIN_T) * 4.0))
		if swing > 0.0:
			return 4 + mini(3, int((1.0 - swing / ATTACK_T) * 4.0))
		return int(walk_t * 8.0) % 4 if walk_t > 0.0 else 8 + int(t * 1.6) % 2
	if dead:
		return 13
	if revived_t > 0.0:
		return 14 if revived_t > 0.3 else 15
	if cast_t > 0.0:
		return 16 + mini(3, int((1.0 - cast_t / CAST_T) * 4.0))
	if nova_t > 0.0:
		return 20 + mini(3, int((1.0 - nova_t / NOVA_T) * 4.0))
	if swing > 0.0:
		return 4 + mini(3, int((1.0 - swing / ATTACK_T) * 4.0))
	if hurt > 0.1:
		return 10
	# O 2.º desenho do andar veio sem foice (piscava a cada passo): fica de fora
	return [0, 2, 3, 2][int(walk_t * 8.0) % 4] if walk_t > 0.0 else 8 + int(t * 1.6) % 2


## O desenho 32-bit deste momento (8 por movimento); -1 = usar os desenhos pintados.
func _frame32() -> int:
	if not main.settings.pixel32:
		return -1
	var w := hero == "warden"  # o Guardião cai deitado (26-27); o Strider ajoelha (27-28)
	if dead:  # com um aliado perto, a chama cresce
		return (26 if w else 27) if revive_t <= 0.0 else (27 if w else 28) + mini(1, int(revive_t / main.REVIVE_T * 2.0))
	if revived_t > 0.0:
		return (29 if w else 30) if revived_t > 0.3 else (30 if w else 31)
	if dash_t > 0.0:
		return 49 + mini(5, int((1.0 - dash_t / DASH_T) * 6.0))
	for a in [[cast_t, CAST_T, 32], [nova_t, NOVA_T, 40], [spin, SPIN_T, 32], [guard_t, GUARD_T, 40], [swing, ATTACK_T, 8]]:
		if a[0] > 0.0:
			return a[2] + mini(7, int((1.0 - a[0] / a[1]) * 8.0))
	if hurt > 0.1:
		return 24 if hurt > 0.15 or w else 25
	return int(walk_t * 16.0) % 8 if walk_t > 0.0 else 16 + int(t * 8.0) % 8


func _draw() -> void:
	body.queue_redraw()  # o herói desenha-se por cima do anel, no nó body
	trail.queue_redraw()
	# Anel do jogador (cor de cada jogador) e, se caiu, o círculo de reanimar
	if dead and revive_t > 0.0:
		var rv := REVIVE_TEX.get_size() * 120.0 / REVIVE_TEX.get_width()
		draw_texture_rect(REVIVE_TEX, Rect2(Vector2(-rv.x / 2.0, -11.0 - rv.y / 2.0), rv), false, Color(1, 1, 1, 0.8))
	var ring: Texture2D = RING[slot]
	var rs := ring.get_size() * 64.0 / ring.get_width()  # só o anel (SC-VFX2), deitado à volta dos pés
	draw_texture_rect(ring, Rect2(Vector2(-rs.x / 2.0, -10.0 - rs.y / 2.0), rs), false, Color(1, 1, 1, 0.75))
	if stance == "ira" and not dead:  # Ira: brasa vermelha a pulsar debaixo dos pés
		draw_set_transform(Vector2(0, -8), 0.0, Vector2(1.0, 0.45))
		draw_arc(Vector2.ZERO, 44.0, 0.0, TAU, 40, Color(1.0, 0.15, 0.1, 0.45 + 0.2 * sin(t * 8.0)), 4.0)
		draw_set_transform(Vector2.ZERO)
	# Anel de recarga: cada habilidade longa enche um arco à volta dos pés; quando fica pronta, o arco abre-se num brilho
	if dead:
		return
	if lich:  # Lich de Ferro (#140): a sombra no chão, debaixo de quem flutua
		draw_set_transform(Vector2(0, -8), 0.0, Vector2(1.0, 0.4))
		draw_circle(Vector2.ZERO, 26.0, Color(0, 0, 0, 0.35))
		draw_set_transform(Vector2.ZERO)
	if debt > 0.0:  # Sangue Negro (#117): arco de sangue escuro debaixo dos pés, do tamanho da dívida
		draw_set_transform(Vector2(0, -8), 0.0, Vector2(1.0, 0.45))
		draw_arc(Vector2.ZERO, 42.0, -PI / 2.0, -PI / 2.0 + TAU * debt / (max_hp * 0.5), 40, Color(0.55, 0.05, 0.12, 0.8), 5.0)
		draw_set_transform(Vector2.ZERO)
	if stat("fome") > 0.0:  # Fome Insaciável (#137): seis marcas à frente dos pés, cheias tantas quantos os mortos engolidos
		for i in 6:
			draw_circle(Vector2.from_angle(deg_to_rad(30.0 + 24.0 * i)) * Vector2(56.0, 24.0) + Vector2(0, -10), 3.0, Color(0.8, 0.75, 0.6, 1.0 if i < fome_n else 0.25))
	# Linha guia: pontos até ao inimigo que a mira automática escolheu
	var tg = target()
	if tg != null:
		var to: Vector2 = tg.position - position
		for i in range(1, int(to.length() / 26.0)):
			draw_circle(Vector2(0, -12) + to.normalized() * i * 26.0, 2.2, Color(tint, 0.4))
	draw_set_transform(Vector2(0, -12), 0.0, Vector2(1.0, 0.45))
	var n := 0
	for id in order:
		if skills[id].cd < RING_CD:
			continue
		var r := 50.0 + n * 8.0
		n += 1
		var left: float = cds[id] / skills[id].cd
		if left > 0.0:
			draw_arc(Vector2.ZERO, r, 0.0, TAU, 48, Color(0, 0, 0, 0.3), 5.0)
			draw_arc(Vector2.ZERO, r, -PI / 2.0, -PI / 2.0 + TAU * (1.0 - minf(left, 1.0)), 48, Color(0.6, 0.9, 1.0, 0.55), 4.0)
		elif ready_t.get(id, 0.0) > 0.0:
			var k: float = ready_t[id] / READY_T
			draw_arc(Vector2.ZERO, r + (1.0 - k) * 16.0, 0.0, TAU, 48, Color(0.8, 1.0, 1.0, k), 5.0)
	draw_set_transform(Vector2.ZERO)


## Rasto da esquiva: fantasmas largados pelo caminho (~44 px), cada um 0,4 s, a escurecer na rampa e a desfazer-se em
## pontilhado (ghost.gdshader). Vem do dash_cd (o tempo desde o salto): o convidado vê o mesmo.
func _draw_trail() -> void:
	var el := DASH_CD - dash_cd
	if ghost_tex == null or dead or el >= DASH_T + 0.4:
		return
	var C: Array = Pix.ramp("bleed" if stance == "ira" else "iron" if lich else "soul")
	for tc in [0.0, 0.1] if main.effects_level() == 0 else [0.0, 0.06, 0.1, 0.14]:
		var k: float = (el - tc) / 0.4
		if k < 0.0 or k >= 1.0:
			continue
		var i := mini(C.size() - 3, 1 + int(k * (C.size() - 3)))
		trail.draw_set_transform_matrix(Transform2D(0.0, -dash_dir * DASH_SPEED * (minf(el, DASH_T) - tc)) * ghost_pose)
		trail.draw_texture(ghost_tex, Vector2.ZERO, Color(C[i + 1], 1.0 if k < 0.45 else (1.0 - k) / 0.55))
	trail.draw_set_transform(Vector2.ZERO)


## Os desenhos olham todos para a direita, menos a folha pintada da Lança e da Nova do Strider (16-23).
static func faces_left(h: String, f: int) -> bool:
	return h == "strider" and f >= 16


func _draw_body() -> void:
	var col := Color(1.0, 0.4, 0.4) if hurt > 0.0 else Color.WHITE
	if dead:
		col = Color(0.8, 0.8, 0.8, 0.95)
	if lich:  # Lich de Ferro (#140): cor de ferro frio
		col *= Color(0.72, 0.78, 0.92)
	# Os desenhos olham para a direita: espelha quando olha para a esquerda (flip_s, a virar suave).
	var f := _frame()
	var tex: Texture2D = FRAMES[hero][f]
	var sc: float = HEROES[hero].scale
	var feet: float = Feet.FEET[SHEET[hero]][f]
	var f32 := _frame32()
	if f32 >= 0:
		tex = FRAMES32[hero][f32]
		sc = Feet32.SCALE[SHEET32[hero]]
		feet = Feet32.FEET[SHEET32[hero]][f32]
	var mirror := flip_s * (-1.0 if f32 < 0 and faces_left(hero, f) else 1.0)
	# Antecipação e continuação: ao atacar recua, passa um pouco à frente e assenta
	var k := exp(-lean_t * 8.0) * cos(lean_t * 22.0)
	# Fluidez: um salto a cada passo, inclinado para onde anda, e a respirar quando está parado
	var bob := 0.0 if dead else -absf(sin(walk_t * TAU * 2.0)) * 4.0
	if lich:  # flutua (a pose da silhueta também)
		bob -= 12.0 + 3.0 * sin(t * 4.0)
	var breath := sin(t * 2.4) * 0.015 if walk_t == 0.0 and not dead else 0.0
	# A pose fica guardada para a silhueta atrás das paredes (#92); é o mesmo que draw_set_transform(posição, rotação, escala)
	pose_tex = tex
	# Transform2D(rotação, escala, inclinação, posição): escala local, como o draw_set_transform (o .scaled() escalaria no global e a inclinação ia ao contrário)
	# Esquiva: estica-se na direção do salto e encolhe no outro eixo (vem do dash_t: o convidado vê o mesmo)
	var sq := 1.0 + 0.25 * clampf(dash_t / DASH_T, 0.0, 1.0)
	var squash := Vector2(sq, 1.0 / sq) if absf(dash_dir.x) >= absf(dash_dir.y) else Vector2(1.0 / sq, sq)
	pose = Transform2D(0.0 if dead else tilt, Vector2(sc * mirror * (1.0 - 0.05 * k - breath * 0.5), sc * (1.0 + 0.05 * k + breath)) * squash, 0.0, lean_dir * -9.0 * k + Vector2(0, bob)).translated_local(Vector2(-tex.get_width() / 2.0, -tex.get_height() + feet))
	if dash_t > 0.0:
		ghost_tex = tex
		ghost_pose = pose
	body.draw_set_transform_matrix(pose)
	body.draw_texture(tex, Vector2.ZERO, col)
	body.draw_set_transform(Vector2.ZERO)
	if armor > 0.0:
		var a := 0.28 + 0.12 * sin(t * 10.0)
		body.draw_arc(Vector2(0, -42), 40.0, 0, TAU, 32, Color(0.92, 0.86, 0.7, a), 3.0)
	if iron_t > 0.0:  # Donzela de Ferro Móvel (#174): a couraça de aço à volta do herói
		body.draw_arc(Vector2(0, -42), 46.0, 0, TAU, 32, Color(0.7, 0.76, 0.85, 0.7), 5.0)
	if overload_t > 0.0 and stat("imolacao") > 0.0:  # Imolação Funerária (#127): na Sobrecarga o herói arde
		body.draw_arc(Vector2(0, -42), 44.0 + 3.0 * sin(t * 18.0), 0, TAU, 32, Color(1.0, 0.45, 0.15, 0.6), 3.0)
	if lich:  # Lich de Ferro (#140): três lascas de osso em órbita
		for i in 3:
			body.draw_circle(Vector2.from_angle(t * 1.5 + i * TAU / 3.0) * 40.0 + Vector2(0, -50), 4.0, Color(0.85, 0.82, 0.72))
	if soul == "cranios" and not dead:  # os crânios em órbita, por cima do herói
		for i in skulls:
			var at := _skull_at(i)
			body.draw_circle(at, 6.0, Color(1.0, 0.55, 0.2))
			body.draw_circle(at, 3.0, Color(1.0, 0.9, 0.4))
	if dead and revive_t > 0.0:
		body.draw_arc(Vector2(0, -40), 22.0, -PI / 2.0, -PI / 2.0 + TAU * revive_t / main.REVIVE_T, 32, Color(0.4, 1.0, 0.65), 5.0)
