extends Node2D
## Um herói do grupo: o Strider (gadanha + feitiços de alma) ou o Guardião (machado, "Bleed & Bone").
## Cada habilidade tem um Frasco de Alma de suporte.

signal died

const SUPPORTS := ["", "parasita", "titanica"]
const SUPPORT_NAMES := {"": "Nenhum", "parasita": "Alma Parasita", "titanica": "Alma Titânica"}
const ATTACK_T := 0.32
const SPIN_T := 0.4
const CAST_T := 0.3
const NOVA_T := 0.45
const Feet := preload("res://art/anim/feet.gd")
const HEROES := {
	"strider": {"name": "Strider", "order": ["scythe", "bolt", "nova"], "scale": 0.34, "portrait": preload("res://art/ui/portrait_strider.png")},
	"warden": {"name": "Guardião", "order": ["chop", "cleave", "bonearmor"], "scale": 0.27, "portrait": preload("res://art/ui/portrait_warden.png")},
}
## Strider: 0-3 andar, 4-7 gadanha, 8-9 parado, 10-11 ferido, 12 a cair, 13 caído, 14-15 reanimado,
## 16-19 Lança de Almas, 20-23 Nova. Guardião: 0-3 andar, 4-7 machadada, 8-9 parado, 10 caído, 11 reanimado, 12-15 giro.
static var FRAMES := {
	"strider": range(24).map(func(i): return load("res://art/anim/player_%d.png" % i)),
	"warden": range(16).map(func(i): return load("res://art/anim/warden_%d.png" % i)),
}
const SHEET := {"strider": "player", "warden": "warden"}  # nome dos ficheiros (e da tabela de pés)
const RING := [preload("res://art/fx/ring_p1.png"), preload("res://art/fx/ring_p2.png")]
const REVIVE_TEX := preload("res://art/fx/revive.png")

var main
var hero := "strider"
var order: Array = HEROES.strider.order
var pfx := ""  # prefixo das ações de input: "" = jogador 1, "p2_" = jogador 2
var slot := 0
var hero_name := "Strider"
var tint := Color(0.4, 1.0, 0.6)  # cor do jogador no HUD
var portrait: Texture2D = HEROES.strider.portrait
var passives := ["raiz"]
var points := 0
var revive_t := 0.0
var revived_t := 0.0
var lock_skills := false  # depois de fechar um painel, espera que larguem os botões
var walk_t := 0.0
var hp_chunk := 150.0  # o HUD desenha este pedaço atrás da vida e escoa-o com atraso
var chunk_wait := 0.0
var heal_acc := 0.0
var heal_num_t := 0.0
var max_hp := 150.0
var hp := 150.0
var max_mana := 100.0
var mana := 100.0
var touch_move := Vector2.ZERO
var held := {}
var facing := Vector2.RIGHT
var cds := {}
var swing := 0.0
var spin := 0.0
var cast_t := 0.0
var nova_t := 0.0
var armor := 0.0
var hurt := 0.0
var t := 0.0
var dead := false

var skills := {
	"scythe": {"name": "Ceifa Sepulcral", "mana": 0.0, "cd": 0.4, "dmg": 22.0, "area": 95.0, "support": ""},
	"bolt": {"name": "Lança de Almas", "mana": 10.0, "cd": 0.55, "dmg": 34.0, "area": 16.0, "support": ""},
	"nova": {"name": "Nova Espectral", "mana": 28.0, "cd": 2.5, "dmg": 45.0, "area": 170.0, "support": ""},
	"chop": {"name": "Golpe do Carrasco", "mana": 0.0, "cd": 0.55, "dmg": 30.0, "area": 105.0, "support": ""},
	"cleave": {"name": "Ceifa de Ossos", "mana": 16.0, "cd": 2.0, "dmg": 38.0, "area": 150.0, "support": ""},
	"bonearmor": {"name": "Armadura de Ossos", "mana": 25.0, "cd": 9.0, "dmg": 0.0, "area": 0.0, "support": ""},
}


func setup(h: String, index: int) -> void:
	hero = h
	slot = index
	order = HEROES[h].order
	hero_name = HEROES[h].name
	portrait = HEROES[h].portrait
	pfx = "" if index == 0 else "p2_"
	tint = Color(0.4, 1.0, 0.6) if index == 0 else Color(1.0, 0.75, 0.35)
	for id in order:
		cds[id] = 0.0


func stat(key: String) -> float:
	var v: float = main.stat(key)
	for id in passives:
		v += main.PASSIVES[id].stats.get(key, 0.0)
	return v


## Vida e mana máximas: base + nível do grupo + árvore.
func refresh_stats() -> void:
	max_hp = 150.0 + stat("hp_max") + (main.level - 1) * 8.0
	max_mana = 100.0 + stat("mana_max")


func allocate(id: String) -> bool:
	var n: Dictionary = main.PASSIVES[id]
	if points < 1 or id in passives or not n.req in passives:
		return false
	points -= 1
	passives.append(id)
	refresh_stats()
	return true


func _process(delta: float) -> void:
	t += delta
	revived_t = maxf(0.0, revived_t - delta)
	if dead:
		return
	var dir := Input.get_vector(pfx + "move_left", pfx + "move_right", pfx + "move_up", pfx + "move_down")
	if touch_move != Vector2.ZERO:
		dir = touch_move
	var start := position
	position += dir * 230.0 * (1.0 + stat("speed")) * delta
	position = position.clamp(main.bounds.position + Vector2(30, 30), main.bounds.end - Vector2(30, 30))
	position = main.walk(start, position)
	walk_t = walk_t + delta if dir.length() > 0.2 else 0.0
	if dir.length() > 0.2:
		facing = dir.normalized()
	mana = minf(max_mana, mana + (7.0 + stat("regen")) * delta)
	hp = minf(max_hp, hp + 1.0 * delta)
	for k in cds:
		cds[k] = maxf(0.0, cds[k] - delta)
	swing = maxf(0.0, swing - delta)
	spin = maxf(0.0, spin - delta)
	cast_t = maxf(0.0, cast_t - delta)
	nova_t = maxf(0.0, nova_t - delta)
	armor = maxf(0.0, armor - delta)
	hurt = maxf(0.0, hurt - delta)
	chunk_wait -= delta
	hp_chunk = maxf(hp_chunk, hp) if chunk_wait > 0.0 else move_toward(hp_chunk, hp, max_hp * 0.8 * delta)
	heal_num_t -= delta
	if heal_num_t <= 0.0 and heal_acc >= 3.0:
		heal_num_t = 0.5
		main.number(position + Vector2(0, -90), "+%d" % int(heal_acc), 15.0, Color(0.45, 1.0, 0.55))
		heal_acc = 0.0
	var want := []
	for i in 3:
		if Input.is_action_pressed(pfx + "skill_%d" % (i + 1)) or held.get(order[i], false):
			want.append(order[i])
	if lock_skills:
		lock_skills = not want.is_empty()  # o A que fechou um painel não conta como ataque
	else:
		for id in want:
			use_skill(id)
	if Input.is_action_just_pressed(pfx + "interact"):
		main.interact()
	queue_redraw()


func cycle_support(id: String) -> void:
	var s: Dictionary = skills[id]
	s.support = SUPPORTS[(SUPPORTS.find(s.support) + 1) % SUPPORTS.size()]


## Alma Parasita: paga com vida, dano x2.2 e área x1.5. Alma Titânica: área x1.8, recarga x1.7.
func use_skill(id: String) -> void:
	if dead or cds[id] > 0.0:
		return
	var s: Dictionary = skills[id]
	var cost: float = s.mana
	var dmg: float = s.dmg * (1.0 + stat("dmg"))
	var area: float = s.area
	var cd: float = s.cd
	if id in ["bolt", "nova"]:
		dmg *= 1.0 + stat("spell")
	match s.support:
		"parasita":
			var life_cost := maxf(cost * 1.5, 6.0)
			if hp <= life_cost + 1.0:
				return
			hp -= life_cost
			hurt = 0.1
			dmg *= 2.2
			area *= 1.5
		"titanica", "":
			if mana < cost:
				return
			mana -= cost
			if s.support == "titanica":
				area *= 1.8
				cd *= 1.7
	cds[id] = cd
	var aim := _aim()
	facing = aim
	var green := Color(0.35, 1.0, 0.6) if s.support != "parasita" else Color(0.9, 0.15, 0.25)
	match id:
		"scythe", "chop":
			swing = ATTACK_T
			main.hit_arc(position, aim, area, dmg, self)
			main.spawn_fx("arc", position + Vector2(0, -20), area, green, aim)
		"bolt":
			cast_t = CAST_T
			main.spawn_bolt(position + Vector2(0, -20), aim, dmg, area, self)
		"nova":
			nova_t = NOVA_T
			main.hit_circle(position, area, dmg, self)
			main.spawn_fx("ring", position, area, green)
		"cleave":
			spin = SPIN_T
			main.hit_circle(position, area, dmg, self, true)
			main.spawn_fx("ring", position, area, Color(0.9, 0.25, 0.3) if s.support == "parasita" else Color(0.85, 0.8, 0.65))
		"bonearmor":
			armor = 5.0
			main.spawn_fx("ring", position + Vector2(0, -30), 70.0, Color(0.9, 0.85, 0.7))


func _aim() -> Vector2:
	var best = null
	var best_d := 480.0
	for e in main.enemies():
		var d: float = position.distance_to(e.position)
		if d < best_d:
			best_d = d
			best = e
	return facing if best == null else position.direction_to(best.position)


func heal(amount: float) -> void:
	if dead:
		return
	heal_acc += minf(amount, max_hp - hp)
	hp = minf(max_hp, hp + amount)


## Em co-op o jogador cai em vez de morrer; um aliado perto dele reanima-o (main._coop).
func revive() -> void:
	dead = false
	revive_t = 0.0
	revived_t = 0.6
	hp = max_hp * 0.5


func take_damage(amount: float) -> void:
	if dead:
		return
	if armor > 0.0:
		amount *= 0.5
	hp -= amount
	hurt = 0.2
	chunk_wait = 0.5
	main.number(position + Vector2(randf_range(-10, 10), -90), str(roundi(amount)), 15.0 + clampf(amount / 2.0, 0.0, 16.0), Color(1.0, 0.3, 0.3))
	main.shake = maxf(main.shake, 6.0)
	main.sfx("hurt")
	if hp <= 0.0:
		hp = 0.0
		dead = true
		queue_redraw()
		died.emit()


func _frame() -> int:
	if hero == "warden":
		if dead:
			return 10
		if revived_t > 0.0:
			return 11
		if spin > 0.0:
			return 12 + mini(3, int((1.0 - spin / SPIN_T) * 4.0))
		if swing > 0.0:
			return 4 + mini(3, int((1.0 - swing / ATTACK_T) * 4.0))
		return int(walk_t * 8.0) % 4 if walk_t > 0.0 else 8 + int(t * 1.6) % 2
	if dead:
		return 13
	if revived_t > 0.0:
		return 14 if revived_t > 0.3 else 15
	if cast_t > 0.0:
		return 16 + mini(3, int((1.0 - cast_t / CAST_T) * 4.0))
	if nova_t > 0.0:
		return 20 + mini(3, int((1.0 - nova_t / NOVA_T) * 4.0))
	if swing > 0.0:
		return 4 + mini(3, int((1.0 - swing / ATTACK_T) * 4.0))
	if hurt > 0.1:
		return 10
	return int(walk_t * 8.0) % 4 if walk_t > 0.0 else 8 + int(t * 1.6) % 2


func _draw() -> void:
	# Anel do jogador (cor de cada jogador) e, se caiu, o círculo de reanimar
	if dead and revive_t > 0.0:
		draw_texture_rect(REVIVE_TEX, Rect2(-60, -80, 120, 138), false, Color(1, 1, 1, 0.8))
	var ring: Texture2D = RING[slot]
	draw_texture_rect(ring, Rect2(-38, -52, 76, 79), false, Color(1, 1, 1, 0.75))
	var col := Color(1.0, 0.4, 0.4) if hurt > 0.0 else Color.WHITE
	if dead:
		col = Color(0.8, 0.8, 0.8, 0.95)
	# Os sprites olham para a esquerda: espelha quando olha para a direita.
	var flip := -1.0 if facing.x > 0.0 else 1.0
	var f := _frame()
	var tex: Texture2D = FRAMES[hero][f]
	var sc: float = HEROES[hero].scale
	draw_set_transform(Vector2.ZERO, 0.0, Vector2(sc * flip, sc))
	draw_texture(tex, Vector2(-tex.get_width() / 2.0, -tex.get_height() + Feet.FEET[SHEET[hero]][f]), col)
	draw_set_transform(Vector2.ZERO)
	if armor > 0.0:
		var a := 0.28 + 0.12 * sin(t * 10.0)
		draw_arc(Vector2(0, -42), 40.0, 0, TAU, 32, Color(0.92, 0.86, 0.7, a), 3.0)
	if dead and revive_t > 0.0:
		draw_arc(Vector2(0, -40), 22.0, -PI / 2.0, -PI / 2.0 + TAU * revive_t / main.REVIVE_T, 32, Color(0.4, 1.0, 0.65), 5.0)
