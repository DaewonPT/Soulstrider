extends Node2D
## Um herói do grupo: o Strider (foice + feitiços de alma) ou o Cavaleiro (id "warden": machado, "Sangue e Osso").
## Cada habilidade tem um Frasco de Alma de suporte.

signal died

## Frascos de Alma: os dois primeiros vêm de início; os outros caem como saque raro (main.flasks).
const SUPPORTS := ["", "parasita", "titanica", "veloz", "eco", "tumular", "colerica", "roubo", "caotico", "mitotico", "martir", "gatilho", "carga", "eter", "gravidade", "meteoro", "terramoto",
	"voraz", "chumbo", "biomecanica", "furia", "maldito_carcereiro", "maldito_arauto"]
## Frascos Malditos (#21): só os deixa o chefe deles (fora do sorteio dos frascos), não vão no golpe básico e ocupam também o
## engaste da outra habilidade (cursed_lock)
const CURSED := ["maldito_carcereiro", "maldito_arauto"]
const SUPPORT_NAMES := {
	"": "Nenhum", "parasita": "Alma Parasita", "titanica": "Alma Titânica", "veloz": "Alma Veloz",
	"eco": "Alma Eco", "tumular": "Alma Tumular", "colerica": "Alma Colérica",
	"roubo": "Alma Ladra",
	"caotico": "Alma Caótica",
	"mitotico": "Alma Mitótica",
	"martir": "Alma Mártir",
	"gatilho": "Alma Gatilho",
	"carga": "Alma Sacrificial",
	"eter": "Alma de Éter",
	"gravidade": "Alma Gravitacional",
	"meteoro": "Alma Meteórica",
	"terramoto": "Alma Sísmica",
	"voraz": "Alma Voraz",
	"chumbo": "Alma de Chumbo",
	"biomecanica": "Alma Biomecânica",
	"furia": "Alma da Fúria Póstuma",
	"maldito_carcereiro": "Frasco Maldito do Carcereiro",
	"maldito_arauto": "Frasco Maldito do Arauto",
	"vinganca": "Espectro da Vingança",
	"escriba": "Escriba da Agonia",
	"cranios": "Dança dos Crânios Flamejantes",
	"donzela": "Donzela de Ferro Móvel",
}
const SUPPORT_DESC := {
	"": "Sem frasco: a habilidade tal como é.",
	"parasita": "Paga com VIDA em vez de alma: dano ×2,2 e área ×1,5.",
	"titanica": "Área ×1,8, mas a recarga demora ×1,7.",
	"veloz": "Recarga ×0,55, mas dano ×0,8.",
	"eco": "Repete-se sozinha meio segundo depois, com 60% do dano.",
	"tumular": "Quem morrer com ela ergue-se como esqueleto teu durante 12 s.",
	"colerica": "Até +80% de dano quanto menos vida tiveres.",
	"roubo": "Recarga ×0,7 enquanto tiveres poções; cada uso bebe 1/8 de uma carga.",
	"caotico": "A cada uso muda: Podridão, Necrose ou Calcificação em quem acerta.",
	"mitotico": "Quem morrer com ela ergue-se em DOIS esqueletos pequenos teus (metade do dano) durante 12 s.",
	"martir": "Sem barreira de ossos; cada abate com ela devolve logo a Esquiva.",
	"gatilho": "Gasta um abate feito perto de ti nos últimos 5 s para a área ser ×1,5.",
	"carga": "Dano ×1,3, mas sangras 1,5% da vida por segundo nos 3 s seguintes (nunca mata).",
	"eter": "Não rouba vida: 5% do dano (mais o teu roubo de vida) volta como alma.",
	"gravidade": "Puxa para ti os monstros em que acertas e o saque a 260 px.",
	"meteoro": "Frasco Titânico: só em Erguer os Mortos e na Ceifa de Ossos: raio ×1,75 (área tripla) e 6 estilhaços de osso, mas recarga ×2,2 e cada uso custa 8% da vida (nunca mata).",
	"terramoto": "Frasco Titânico: só em Erguer os Mortos e na Ceifa de Ossos: fissuras com braços esqueléticos petrificam 1 s os monstros em que acertas (chefes: abrandam 2 s). Dano ×0,75, recarga ×1,6.",
	"voraz": "Os golpes furam 40% da armadura (os Colossos e o Arauto têm 40%), mas com monstros a menos de 700 px perdes 2% da vida por segundo (até metade).",
	"chumbo": "Só na foice, no machado e na Ceifa de Ossos: área ×1,6, mas andas 15% mais devagar.",
	"biomecanica": "Cada golpe solta arcos de raio necrótico do alvo para os 2 monstros mais perto (até 160 px), com 40% do dano. Na Ceifa de Ossos, os arcos ligam em cadeia todos os que o redemoinho apanha, a cada volta.",
	"furia": "O golpe que te ia matar deixa-te a 1 de vida: 5 s sem levar dano e com dano a dobrar. Mata alguém nesse tempo e voltas com 20% da vida; senão, cais. Recarga 60 s.",
	"maldito_carcereiro": "Não vai no golpe básico. Ocupa também o lugar do frasco da tua outra habilidade e tira-te a regeneração natural. A cada uso, o punho do Carcereiro cai onde miras: 120% do dano em 110 px e atordoa 0,6 s.",
	"maldito_arauto": "Não vai no golpe básico. Ocupa também o lugar do frasco da tua outra habilidade e tira-te a regeneração natural. A cada uso, o sino do Arauto toca à tua volta: 60% do dano em 220 px e ergue um esqueleto teu.",
	"vinganca": "Um golpe que te tire mais de 20% da vida dispara flechas espectrais contra quem bateu e até 4 monstros à volta (1,5 s de recarga).",
	"escriba": "A cada 90 px andados inscreves uma runa oculta (até 6, 10 s). Um monstro que a pise rebenta-a: dano em 80 px à volta.",
	"cranios": "4 crânios em chamas orbitam-te; a cada 0,8 s, um lança-se contra um monstro a 320 px (Espectros primeiro). Volta um crânio a cada 4 s.",
	"donzela": "Quando o golpe de área de um chefe te apanha, transformas-te em couraça durante 1,5 s: esses golpes só tiram 10%. Recarga 25 s; na couraça andas a meia velocidade.",
}
## Almas Condensadas: veste-as o herói (uma de cada vez), não uma habilidade. Caem como os frascos e juntam-se à mesma
## lista (main.flasks); o nome e o que fazem estão em SUPPORT_NAMES e SUPPORT_DESC. "" = nenhuma.
const SOULS := ["", "vinganca", "escriba", "cranios", "donzela"]
## Almas Transitórias (#4): a alma de um só uso que os elites e os gigantes deixam cair; dura TRANS_T s (use_trans).
const TRANS := {"lamento": "Lamento das Almas", "cataclismo": "Cataclismo"}
const TRANS_T := 60.0
const POTION_MAX := 3.0
## Chaves que se excluem (Mente Fragmentada #108 ↔ Sem Alma Própria, Lich de Ferro #140 ↔ Sangue Negro #117): quem tem uma não compra a outra.
const EXCLUSIVE := {"fragmentada": "semalma", "semalma": "fragmentada", "lich": "sangue", "sangue": "lich", "arqueiros": "guardioes", "guardioes": "arqueiros"}  # e os esqueletos especializados (#11)
const DASH_T := 0.18  # Esquiva Espectral: dura isto, anda DASH_SPEED * DASH_T e não leva dano
const DASH_SPEED := 1050.0
const DASH_CD := 1.1
const OVERLOAD_T := 6.0  # Sobrecarga de Alma (#1): dura isto
const RING_CD := 2.0  # habilidades com recarga a partir disto aparecem no anel à volta dos pés
const READY_T := 0.4
const ATTACK_T := 0.32
const SPIN_T := 0.6
const CAST_T := 0.3
const NOVA_T := 0.45
const GUARD_T := 0.5  # Armadura de Ossos: os ossos sobem e prendem-se
## O Cavaleiro (id "warden", como no jogo gravado) traz força e vida de base: "stats" soma-se em stat().
const HEROES := {
	"strider": {"name": "Strider", "order": ["scythe", "bolt", "nova"], "portrait": preload("res://art/ui/portrait_strider.png"),
		"info": "Necromante: foice, Lança de Almas e esqueletos que lutam por ti."},
	"warden": {"name": "Cavaleiro", "order": ["chop", "cleave", "bonearmor"], "portrait": preload("res://art/ui/portrait_warden.png"),
		"info": "Força e vida: +60 de vida, +10% de dano e 3% de roubo de vida.", "stats": {"hp_max": 60.0, "dmg": 0.1, "leech": 0.03}},
}
## Equipamento (0.4.8): 5 lugares por herói (o Pescoço, G2, entrou no fim: os índices dos outros 4 não mudam), uma mochila e
## peças que caem dos mortos. Cada peça é uma String
## "base:raridade:afixo:afixo" (raridade 0 comum, 1 mágica, 2 rara; os únicos "id:3"): pequena para a rede, igual no jogo
## gravado e comparável com ==. Os números saem destas tabelas, nunca da peça. G3 (Lote 10): um afixo pode acabar em "+"
## (no máximo, x1,5) ou "-" (fraco, x0,6), e no fim pode vir a qualidade "q1" a "q3" (a base +10% cada): "helm:2:crit+:dr-:q2".
const SLOTS := ["cabeca", "peito", "maos", "pes", "pescoco"]
const SLOT_NAMES := {"cabeca": "Cabeça", "peito": "Peito", "maos": "Mãos", "pes": "Pés", "pescoco": "Pescoço"}
const RARITY := ["Peça comum", "Peça mágica", "Peça rara", "Peça única"]
const RARITY_RAMP := ["bone", "soulblue", "gold", "loot_ash"]  # a cor do nome, do feixe e do voo (fx_pix.gd). A única é cor de brasa: o verde já é das Cinzas e dos Frascos (loot:216) e, no painel, quer dizer "melhor"; o violeta fica para as relíquias
## As bases: o lugar, o nome (o curto vai antes do afixo, "Botas da Lápide", e nos lugares do Equipamento), a chave que dão e quanto, pela raridade.
## Os únicos (#222, #224, #226, #56) têm stats fixos e uma regra própria; só os chefes com nome os deixam, um de cada no grupo.
const GEAR := {
	"helm": {"slot": "cabeca", "name": "Elmo de Osso", "short": "Elmo", "key": "hp_max", "base": [15.0, 20.0, 25.0]},
	"hood": {"slot": "cabeca", "name": "Capuz de Mortalha", "short": "Capuz", "key": "mana_max", "base": [15.0, 20.0, 25.0]},
	"chest_armor": {"slot": "peito", "name": "Couraça de Costelas", "short": "Couraça", "key": "dr", "base": [0.04, 0.06, 0.08]},
	"robe": {"slot": "peito", "name": "Mortalha Cinzenta", "short": "Mortalha", "key": "regen", "base": [1.0, 1.5, 2.0]},
	"gloves": {"slot": "maos", "name": "Luvas de Coveiro", "short": "Luvas", "key": "gdmg", "base": [0.04, 0.07, 0.1]},
	"boots": {"slot": "pes", "name": "Botas de Couro", "short": "Botas", "key": "speed", "base": [0.04, 0.06, 0.08]},
	"amulet": {"slot": "pescoco", "name": "Amuleto de Osso", "short": "Amuleto", "key": "crit", "base": [0.02, 0.03, 0.04]},
	"censer": {"slot": "pescoco", "name": "Incensário Fúnebre", "short": "Incensário", "key": "aura", "base": [0.03, 0.05, 0.07],  # #63: main.aura_at, sem somar dois
		"desc": "Tu e quem estiver perto (7 m) levam menos dano."},
	"coroa": {"slot": "cabeca", "name": "Coroa das Espinhas Dorsais", "short": "Coroa", "stats": {"bone_barrier": 0.2, "mana_max": -20.0, "bone_skill": 0.25},
		"desc": "O dano que levas enche uma barreira de ossos (até 25% da vida). +25% nas habilidades de ossos: Erguer os Mortos, Ceifa de Ossos e Armadura de Ossos."},
	"penitente": {"slot": "peito", "name": "Peitoral do Penitente Aberto", "short": "Peitoral", "stats": {"hp_mul": -0.2, "bleed": 0.8}},  # sem desc: os dois números dizem tudo
	"garras": {"slot": "maos", "name": "Garras do Coveiro Insone", "short": "Garras", "stats": {"gdmg": 0.05, "garras": 1.0},
		"desc": "Os golpes da foice, do machado e da Ceifa de Ossos prendem os pés: o monstro anda a 60% durante 1,5 s (menos o Arauto, o Monge e o Carrasco)."},
	"unhas": {"slot": "pes", "name": "Unhas de Carniçal", "short": "Unhas", "stats": {"speed": 0.06, "teeth": 1.0},
		"desc": "A esquiva deixa dentes que abrandam 40% (com os Dentes de Sepultura, duram o dobro)."},
	# Lote 6: as chaves sem número (elo, marcha, visor, costas, alianca) são regras: o take_damage, o _process, o main._damage e o heal leem-nas
	"elo": {"slot": "maos", "name": "Elo da Falange Quebrada", "short": "Elo", "stats": {"crit": 0.03, "elo": 1.0},
		"desc": "O golpe que te ia matar parte o anel e a vida volta cheia. Depois de partido, pode voltar a cair."},
	"marcha": {"slot": "pes", "name": "Passos da Marcha Fúnebre", "short": "Passos", "stats": {"marcha": 1.0, "hp_max": 15.0},
		"desc": "Em combate andas mais 1% depressa por segundo, até +30%. Para ao fim de 3 s sem monstros perto."},
	"visor": {"slot": "cabeca", "name": "Visor da Agonia Perpétua", "short": "Visor", "stats": {"crit_dmg": 0.5, "visor": 1.0},
		"desc": "Sem minimapa. +50% de dano crítico e o grupo ganha +30% de experiência."},
	"manoplas": {"slot": "maos", "name": "Manoplas do Ceifador Silencioso", "short": "Manoplas", "stats": {"gdmg": 0.04, "costas": 1.0},
		"desc": "Golpes em monstros que não olham para ti (a dormir, ou a lutar com outro) são sempre críticos."},
	"noivo": {"slot": "maos", "name": "Aliança do Noivo", "short": "Aliança", "stats": {"leech": 0.01, "alianca": 1.0},
		"desc": "Com a outra aliança no outro herói: 40% do dano que um leva vai para o outro (nunca o mata) e 25% de cada cura também o cura."},
	"noiva": {"slot": "maos", "name": "Aliança da Noiva", "short": "Aliança", "stats": {"leech": 0.01, "alianca": 1.0},
		"desc": "Com a outra aliança no outro herói: 40% do dano que um leva vai para o outro (nunca o mata) e 25% de cada cura também o cura."},
	# Lote 8 (#238): na Guarda, 40% de cada golpe não passa e enche o lamento (take_damage); o golpe básico seguinte solta-o (_cast)
	"parede": {"slot": "peito", "name": "A Parede dos Lamentos", "short": "Parede", "stats": {"dr": 0.04, "parede": 1.0},
		"desc": "Na Guarda, 40% de cada golpe que levas não passa e junta-se num lamento. O golpe básico seguinte solta-o num grito à tua frente, com o dobro do que juntaste."},
	# Lote 11 (#258): o minimapa dos Sepulcros (hud.map_rooms), o brilho do Cofre (main._draw_world) e a tocha (main.lights) leem a chave olho
	"olho": {"slot": "pescoco", "name": "Olho Mumificado do Primeiro Rei", "short": "Olho", "stats": {"mana_max": 15.0, "olho": 1.0},
		"desc": "Nos Sepulcros vês todas as salas, e a Capela e o Cofre brilham a azul. Na escuridão, a tua tocha vai mais longe."},
}
const BASES := ["helm", "hood", "chest_armor", "robe", "gloves", "boots", "amulet", "censer"]
const UNIQUES := ["coroa", "penitente", "garras", "unhas", "elo", "marcha", "visor", "manoplas", "noivo", "noiva", "parede", "olho"]
## Os afixos das mágicas (1) e das raras (2): [o fim do nome, o valor na mágica, o valor na rara]: o índice é a raridade.
## Nunca a chave da base, nem dois iguais na mesma peça. Nenhum fim de nome é igual a um sufixo da foice (main:22-26), que vale 4 a 6 vezes mais.
const AFFIX := {
	"hp_max": ["da Carne", 10.0, 20.0],
	"gdmg": ["da Força", 0.04, 0.06],
	"crit": ["do Golpe Certeiro", 0.02, 0.04],
	"leech": ["da Sanguessuga", 0.01, 0.015],
	"regen": ["do Fôlego", 1.0, 2.0],
	"bleed": ["das Feridas", 0.1, 0.2],
	"boss": ["dos Colossos", 0.1, 0.2],
	"kill_heal": ["do Banquete", 1.0, 2.0],
	"dr": ["da Lápide", 0.02, 0.04],
}
## G3: a força de um afixo (o sinal no fim dele) e a qualidade máxima da base (q3 = +30%)
const LEVEL := {"+": 1.5, "-": 0.6}
const Q_MAX := 3
## G4: o que cada material da Forja de Peças faz (main.mats; o Tinteiro de Sangue Negro, das moedas, também serve)
const CRAFT := {
	"enxofre": "Sobe a peça uma raridade, com um afixo novo.",  # #245
	"martelo": "Sorteia de novo a força dos afixos, sem mudar quais são.",  # #223
	"agulha": "Troca o pior afixo por outro ao calhas.",  # #221
	"cinza_maior": "Um afixo ao calhas passa ao máximo (×1,5).",  # #65
	"cinzel": "Melhora o valor da base da peça em 10% (até 30%).",  # #231
	"ink": "Afixos novos ao calhas, com a mesma raridade.",
}
const RARITY_WORD := ["comum", "mágica", "rara", "única"]
const CRAFT_FAIL := ["Já não tens esta peça.", "Não tens nenhum.", "Destranca primeiro.", "As peças únicas não se forjam.", "Já é rara: o Enxofre só sobe comuns e mágicas.",
	"A qualidade já está no máximo (+30%).", "Uma peça comum não tem afixos.", "Os afixos já estão todos no máximo."]
const BAG_MAX := 8  # a mochila sem Bolsas de Almas (#72); cada Bolsa dá mais 4 (bag_cap)
const LOCKS_MAX := 16  # Trancar peças (#78): no máximo 16 trancadas por herói (a rede e o jogo gravado ficam pequenos)
const SCRAP := [2, 3, 5, 10]  # Ossos por desfazer uma peça (#55), pela raridade: uma rara = uma reforja (main:1324-1329); nunca 1 ("+1 Ossos")
## Heróis em 32-bit (tools/cut_pixel.py), 8 desenhos por movimento: 0-7 andar, 8-15 golpe, 16-23 parado,
## 24-31 ferido, caído e a reerguer-se, 32-39 Lança (Strider) ou Ceifa de Ossos (Guardião), 40-47 Nova ou
## Armadura de Ossos, 48-55 Esquiva.
const SHEET32 := {"strider": "strider32", "warden": "warden32"}
static var FRAMES32 := {
	"strider": range(56).map(func(i): return load("res://art/anim/strider32_%d.png" % i)),
	"warden": range(56).map(func(i): return load("res://art/anim/warden32_%d.png" % i)),
}
const Feet32 := preload("res://art/anim/feet32.gd")
const SIGIL := ["soul", "life"]  # a rampa do selo aos pés de cada jogador
const GHOST := preload("res://ghost.gdshader")
const DITHER := preload("res://dither.gdshader")
const Pix := preload("res://fx_pix.gd")

var main
var hero := "strider"
var order: Array = HEROES.strider.order
var pfx := ""  # prefixo das ações de input: "" = jogador 1, "p2_" = jogador 2
var slot := 0
var hero_name := "Strider"
var tint := Color(0.4, 1.0, 0.6)  # cor do jogador no HUD
var portrait: Texture2D = HEROES.strider.portrait
var passives := ["raiz"]
var points := 0
var revive_t := 0.0
var revived_t := 0.0
var lock_skills := false  # depois de fechar um painel, espera que larguem os botões
var walk_t := 0.0
var hp_chunk := 150.0  # o HUD desenha este pedaço atrás da vida e escoa-o com atraso
var chunk_wait := 0.0
var heal_acc := 0.0
var heal_num_t := 0.0
var max_hp := 150.0
var hp := 150.0
var max_mana := 100.0
var mana := 100.0
var touch_move := Vector2.ZERO
var held := {}
var facing := Vector2.RIGHT
var cds := {}
var swing := 0.0
var swing_len := ATTACK_T  # G7: quanto dura o golpe de agora (a Lâmina do Juramento Quebrado golpeia mais depressa: os desenhos também)
var spin := 0.0
var combo := 0  # Golpe do Carrasco: golpes seguidos (menos de 1,2 s entre eles); o 3.º é um rodopio
var combo_t := 0.0
var echoing := false  # durante o eco da Alma Eco: repete o golpe, mas não conta para o rodopio nem volta a curar
var cast_t := 0.0
var nova_t := 0.0
var guard_t := 0.0
var armor := 0.0
var barrier := 0.0  # Medula Sacrificial (#15): barreira de ossos; aguenta o dano antes da vida e escoa devagar
var hurt := 0.0
var lean_t := 9.0  # desde o último golpe ou Lança: recua, passa à frente e assenta (mola)
var lean_dir := Vector2.ZERO
var tilt := 0.0  # inclina-se para onde anda
var flip_s := 1.0  # espelho suave (1 = direita, -1 = esquerda): vira-se como uma carta em vez de estalar
var body := Node2D.new()  # desenha o herói por cima do anel (no 32-bit sem suavizar: píxeis nítidos)
var trail := Node2D.new()  # fantasmas da esquiva, por baixo do herói
var halo := Node2D.new()  # a aura da Dança dos Crânios (#167), atrás de tudo o que o herói desenha, pontilhada (dither.gdshader)
var ghost_tex: Texture2D  # a pose do salto: os fantasmas ficam depois de ele acabar (só local, não viaja)
var ghost_pose := Transform2D()
var pose := Transform2D()  # o desenho deste frame, para main o redesenhar como silhueta atrás de um adereço alto (#92)
var pose_tex: Texture2D
var t := 0.0
var dead := false
var away := false  # #91: o convidado da Wi-Fi perdeu a ligação e o herói espera por ele (caído e escondido, main.player_away)
var potions := {"hp": POTION_MAX, "mp": POTION_MAX}  # cargas; matar enche-as
var dash_t := 0.0  # a esquivar (invulnerável)
var dash_cd := 0.0
var dash_dir := Vector2.RIGHT
var pacto_t := 0.0  # o aviso quando o Pacto de Carne e Ferro (#101) recusa a esquiva ou as Chamas Negras (#35) uma habilidade (não repete a cada toque)
var slide_v = Vector2.ZERO  # Cripta Submersa (#181): a velocidade de agora, que na bile escorrega até à do joystick (sem tipo: só o anfitrião)
var grace_cd := 0.0  # "Por um fio!": um golpe letal com mais de 25% de vida deixa 1 de vida; só volta 20 s depois
var respecs := 0  # quantas vezes a Árvore foi refeita (a primeira é grátis)
var boss_first := false  # a mira automática prefere chefes (Configurações; o convidado manda a dele)
var killed_by := ""  # quem deu o último golpe (o ecrã de morte mostra-o)
## Postura de Combate (#22): "guarda" (Guarda Sepulcral: -25% de dano recebido e devolve parte ao atacante) ou
## "ira" (Ira Sacrificial: +30% de dano, recargas -25%, mas cada habilidade custa 2% da vida).
var stance := "guarda"
var grito_cd := 0.0  # Grito de Guerra Fúnebre (#20): só volta a gritar 12 s depois
## Instabilidade de Alma (#1): cada habilidade com custo junta 60% dele em corrupção (escoa 3 por segundo); a 100
## vem a Sobrecarga de Alma durante OVERLOAD_T: +35% de crítico (main._damage), mas perde 3% da vida por segundo (nunca mata).
var corruption := 0.0
var overload_t := 0.0
var self_bleed_t := 0.0  # Alma Sacrificial (#161): enquanto corre, o próprio herói sangra
var ready_t := {}  # anel de recarga: brilho curto quando uma habilidade longa volta a estar pronta
var chaos_n := 0  # Alma Caótica (#147): quantas vezes já mudou; o resto por 3 diz o estado da vez
var canibal_n := 0  # Canibalismo Espiritual (#122): lacaios comidos, cada um +8% de dano (até 5); perdem-se ao cair
var simb_cd := 0.0  # Almas Simbióticas (#121): só volta a salvar 12 s depois (viaja ao convidado)
var soul := ""  # a Alma Condensada que o herói veste (uma de SOULS; viaja ao convidado e fica no jogo gravado)
var vinganca_cd := 0.0  # Espectro da Vingança (#143): só volta a disparar 1,5 s depois (viaja ao convidado)
var rune_at := Vector2.ZERO  # Escriba da Agonia (#155): onde inscreveu a última runa (a seguinte só a 90 px dela)
var skulls := 4  # Dança dos Crânios Flamejantes (#167): quantos estão em órbita (viaja ao convidado, que os desenha)
var skull_t := 0.0  # até o próximo se lançar
var skull_regrow := 4.0  # até voltar um
var iron_t := 0.0  # Donzela de Ferro Móvel (#174): em couraça (os golpes de área dos chefes só tiram 10%, anda a metade)
var iron_cd := 0.0  # e só volta 25 s depois (viaja ao convidado)
var debt := 0.0  # Sangue Negro Impenetrável (#117): a vida paga que ainda vai voltar (até 50% da vida; viaja ao convidado)
var lich := false  # Apoteose do Lich de Ferro (#140): em forma (as duas poções cheias; viaja ao convidado, que o desenha)
var lich_cd := 0.0  # e depois de beber só volta 20 s depois
var trans_kind := ""  # Almas Transitórias (#4): a que o herói tem (TRANS), até trans_until (em main.time; viajam ao convidado)
var trans_until := 0.0
var furia_until := 0.0  # Fúria Póstuma (#169): a 1 de vida e sem levar dano até aqui (em main.time; 0 = sem Fúria)
var furia_ready := 0.0  # e só volta a salvar a partir daqui
var safe_until := 0.0  # Elo da Falange Quebrada (#232): depois de o anel partir, 1 s sem levar dano (em main.time; não é a Fúria: o heal() apagava-a)
var march := 0.0  # Passos da Marcha Fúnebre (#228): segundos seguidos em combate, até 30 (+1% de velocidade cada; viaja ao convidado, que desenha a cinza)
var march_quiet = 0.0  # e há quanto tempo não há monstros perto (sem tipo: só o anfitrião)
var aura_t = 0.0  # Incensário Fúnebre (#63): a próxima baforada de cinza (sem tipo: só o anfitrião)
var falange_cd := 0.0  # Falange Espectral (#152): os escudos só voltam 1 s depois
var root_until := 0.0  # Carrasco Sem Rosto (#44): preso pela corrente até aqui (em main.time; viaja ao convidado, que a desenha)
var step_t = 0.0  # Monge Penitente Cego (#193): o próximo passo que se ouve (sem tipo: só o anfitrião)
var safe = null  # Poço da Danação (#49): o último sítio fora das lajes e dos buracos, para onde volta quem cai (sem tipo: só o anfitrião)
var used = []  # Arquivista de Crânios (#29): [habilidade, hora] do que usou nos últimos 20 s (sem tipo: só o anfitrião)
var lament := 0.0  # A Parede dos Lamentos (#238): o dano que a Guarda guardou para o grito (até à vida máxima; viaja ao convidado, que desenha as 6 marcas)
var tib_n = 0  # Disparador de Tíbias (G7): golpes básicos desde a última tíbia (sem tipo: só o anfitrião)
var toll_at = 0.0  # Sino da Agonia (G7): só volta a badalar a partir daqui (em main.time; sem tipo: só o anfitrião)
var fome_n := 0  # Fome Insaciável da Terra (#137): mortos engolidos (a cada 2 ergue um esqueleto; até 6; viaja ao convidado, que os desenha)
var stash = null  # Provação das Almas Rejeitadas (#37): [frasco de cada habilidade, alma] guardados até ao fim do Cortejo (sem tipo: só o anfitrião)
var gear := {}:  # Equipamento (0.4.8): lugar (SLOTS) -> peça posta; viaja ao convidado e fica no jogo gravado
	set(v):
		gear = v
		gear_stats = gear_sum(v)  # quem troca o Dictionary todo (o convidado em net._set_all, o _apply_hero, os testes) fica logo com os números certos
var bag := []  # e a mochila, até bag_cap() peças
var locks := []  # Trancar peças (#78): as peças trancadas (a String: duas iguais são a mesma peça, e trancar uma tranca a gémea); viaja ao convidado e fica no jogo gravado
var gear_stats = {}  # o que as peças postas dão (stat() só o lê, nunca percorre as peças). Sem tipo: não viaja (net:211), como o stash; o convidado refá-lo no setter de gear

var skills := {
	"scythe": {"name": "Ceifa Sepulcral", "mana": 0.0, "cd": 0.4, "dmg": 22.0, "area": 95.0, "support": ""},
	"bolt": {"name": "Lança de Almas", "mana": 10.0, "cd": 0.55, "dmg": 34.0, "area": 16.0, "support": ""},
	"nova": {"name": "Erguer os Mortos", "mana": 28.0, "cd": 6.0, "dmg": 45.0, "area": 170.0, "support": ""},
	"chop": {"name": "Golpe do Carrasco", "mana": 0.0, "cd": 0.55, "dmg": 30.0, "area": 105.0, "support": ""},
	"cleave": {"name": "Ceifa de Ossos", "mana": 16.0, "cd": 2.5, "dmg": 18.0, "area": 150.0, "support": ""},
	"bonearmor": {"name": "Armadura de Ossos", "mana": 25.0, "cd": 9.0, "dmg": 0.0, "area": 0.0, "support": ""},
}


func setup(h: String, index: int) -> void:
	hero = h
	slot = index
	order = HEROES[h].order
	hero_name = HEROES[h].name
	portrait = HEROES[h].portrait
	pfx = "" if index == 0 else "p2_"
	tint = Color(0.4, 1.0, 0.6) if index == 0 else Color(1.0, 0.75, 0.35)
	for id in order:
		cds[id] = 0.0
	halo.show_behind_parent = true
	halo.material = ShaderMaterial.new()
	halo.material.shader = DITHER
	halo.draw.connect(_draw_halo)
	add_child(halo)
	trail.material = ShaderMaterial.new()
	trail.material.shader = GHOST
	trail.draw.connect(_draw_trail)
	add_child(trail)
	body.draw.connect(_draw_body)
	add_child(body)


func stat(key: String) -> float:
	var v: float = main.stat(key)
	for id in passives:
		v += main.PASSIVES[id].stats.get(key, 0.0)
	v += HEROES[hero].get("stats", {}).get(key, 0.0)
	v += gear_stats.get(key, 0.0)  # Equipamento (0.4.8): as peças postas (o setter de gear e o refresh_stats somam-nas)
	if key == "dmg":  # Canibalismo Espiritual (#122): soma-se aos outros +% dano, como o reforço da arma em main.stat
		v += canibal_n * 0.08
	return v


## Vida e mana máximas: base + nível do grupo + árvore + equipamento.
func refresh_stats() -> void:
	gear_stats = gear_sum(gear)  # Equipamento (0.4.8): só o que está posto, somado uma vez (take_gear e equip_gear mudam o gear sem passar pelo setter)
	max_hp = hp_cap()
	hp = minf(hp, max_hp)  # o que passa do novo máximo sai logo (com a Árvore em pausa a barra passava do cheio)
	max_mana = 100.0 + stat("mana_max")
	mana = minf(mana, max_mana)  # tirar uma peça de alma corta o que passa do novo máximo (com Sem Alma Própria ou um Maldito, a regeneração não o corta: player:319, player:328)


## A vida máxima com o que está posto agora (o refresh_stats e o comparador do Equipamento).
func hp_cap() -> float:
	return (150.0 + stat("hp_max") + (main.level - 1) * 8.0) * (1.0 + stat("hp_mul"))  # a Comunhão dos Vermes-Deuses (#112) e o Penitente cortam-na


## O número que o comparador do Equipamento mostra para a chave k: o que o jogador sente, não o afixo.
func gear_view(k: String) -> float:
	match k:
		"hp_max", "hp_mul":
			return hp_cap()
		"mana_max":
			return 100.0 + stat("mana_max")
		"regen":
			if stat("fragmentada") > 0.0 or stat("semalma") > 0.0 or cursed_lock() != "":
				return 0.0  # sem regeneração natural (o _process): a peça não dá nada que se sinta
			return 7.0 + stat("regen")  # a base de player:329
		"gdmg":
			return skill_numbers(order[0])[0]  # o golpe básico
		"crit":
			return main.CRIT + stat("crit")
		"speed":
			return 230.0 * (1.0 + stat("speed"))  # a base de player:300
	return stat(k)


## Uma peça bem feita? O jogo gravado e a rede não são de confiança: base conhecida, raridade 0 a 2 com esse número de
## afixos diferentes (nunca a chave da base; G3: cada um com um sinal no máximo) e no fim, se vier, uma qualidade q1 a q3;
## ou um único "id:3" sem mais nada. No máximo 40 letras (a rede).
static func gear_ok(v) -> bool:
	if not v is String or v.length() > 40:
		return false
	var a: PackedStringArray = v.split(":")
	if a.size() < 2 or not GEAR.has(a[0]) or not a[1] in ["0", "1", "2", "3"]:  # só a forma certa ("+1" ou "03" passavam no is_valid_int e o == dos únicos falhava)
		return false
	var r := int(a[1])
	if GEAR[a[0]].has("stats"):
		return r == 3 and a.size() == 2
	if r > 2:
		return false
	var toks := Array(a.slice(2))
	if toks.size() == r + 1 and toks[-1] in ["q1", "q2", "q3"]:
		toks.pop_back()
	if toks.size() != r:
		return false
	var keys := toks.map(func(t): return affix_key(t))
	for k in keys:
		if not AFFIX.has(k) or k == GEAR[a[0]].key or keys.count(k) > 1:
			return false
	return true


## O que uma peça dá, {chave: valor}. Não mexer no que devolve (nos únicos é a tabela). G3: cada afixo vezes a força dele e a
## base vezes a qualidade.
static func gear_of(it: String) -> Dictionary:
	var a := it.split(":")
	var g: Dictionary = GEAR[a[0]]
	if g.has("stats"):
		return g.stats
	var r := int(a[1])
	var out := {g.key: g.base[r] * (1.0 + 0.1 * gear_q(it))}
	for t in gear_affixes(it):
		var k := affix_key(t)
		out[k] = out.get(k, 0.0) + AFFIX[k][r] * LEVEL.get(t.right(1), 1.0)
	return out


## G3: os afixos da peça com a força deles ("crit+", "dr", "hp_max-"), sem a qualidade.
static func gear_affixes(it: String) -> Array:
	return Array(it.split(":")).slice(2).filter(func(t): return not t.begins_with("q"))


## G3: a qualidade da peça, 0 a Q_MAX (a base +10% cada).
static func gear_q(it: String) -> int:
	var t := it.get_slice(":", it.get_slice_count(":") - 1)
	return int(t.substr(1)) if t.begins_with("q") else 0


## G3: o afixo sem a força ("crit+" dá "crit").
static func affix_key(t: String) -> String:
	return t.left(-1) if t.ends_with("+") or t.ends_with("-") else t


## G3: a força de um afixo novo: 12% no máximo (20% dos elites e dos chefes), 25% fraco, o resto normal (em média ~0,96 do de antes).
static func roll_level(rng: RandomNumberGenerator, strong := false) -> String:
	var x := rng.randf()
	var top := 0.2 if strong else 0.12
	return "+" if x < top else "-" if x < top + 0.25 else ""


## G4: porque é que o material kind não serve na peça it ("" = serve). have: quantos o grupo tem; locked: trancada (#78).
static func craft_why(it: String, kind: String, have: int, locked: bool) -> String:
	var r := gear_rarity(it)
	if have < 1:
		return "Não tens nenhum."
	if locked:
		return "Destranca primeiro."
	if r == 3:
		return "As peças únicas não se forjam."
	if kind == "enxofre":
		return "Já é rara: o Enxofre só sobe comuns e mágicas." if r >= 2 else ""
	if kind == "cinzel":
		return "A qualidade já está no máximo (+30%)." if gear_q(it) >= Q_MAX else ""
	if r == 0:
		return "Uma peça comum não tem afixos."
	if kind == "cinza_maior" and gear_affixes(it).all(func(t): return t.ends_with("+")):
		return "Os afixos já estão todos no máximo."
	return ""


## G4: a peça it depois do material kind (já conferido com craft_why). Os afixos novos nunca são a chave da base nem um que a
## peça já tenha. rng: o do jogo (o teste fixa-o).
static func craft(it: String, kind: String, rng: RandomNumberGenerator) -> String:
	var base := it.get_slice(":", 0)
	var r := gear_rarity(it)
	var affs := gear_affixes(it)
	var q := gear_q(it)
	var have := affs.map(func(t): return affix_key(t))
	var free: Array = AFFIX.keys().filter(func(k): return k != GEAR[base].key and not k in have)
	match kind:
		"enxofre":  # #245: mais uma raridade, com um afixo novo
			r += 1
			affs.append(free[rng.randi() % free.size()] + roll_level(rng))
		"martelo":  # #223: as mesmas chaves, forças novas
			affs = affs.map(func(t): return affix_key(t) + roll_level(rng))
		"agulha":  # #221: sai o pior (um fraco, senão um normal; um no máximo só com todos no máximo) e entra um novo
			var lvl := func(t: String) -> int: return 0 if t.ends_with("-") else 2 if t.ends_with("+") else 1
			var low: int = affs.map(lvl).min()
			var worst: Array = range(affs.size()).filter(func(i): return lvl.call(affs[i]) == low)
			affs[worst[rng.randi() % worst.size()]] = free[rng.randi() % free.size()] + roll_level(rng)
		"cinza_maior":  # #65: um afixo ao calhas que não está no máximo passa a estar
			var can: Array = range(affs.size()).filter(func(i): return not affs[i].ends_with("+"))
			var i: int = can[rng.randi() % can.size()]
			affs[i] = affix_key(affs[i]) + "+"
		"cinzel":  # #231: a base +10%
			q += 1
		"ink":  # o Tinteiro de Sangue Negro: afixos novos, a mesma raridade, forças novas
			var keys: Array = AFFIX.keys().filter(func(k): return k != GEAR[base].key)
			affs = []
			for n in r:
				affs.append(keys.pop_at(rng.randi() % keys.size()) + roll_level(rng))
	return ":".join(PackedStringArray([base, str(r)] + affs + (["q" + str(q)] if q > 0 else [])))


## O que as peças postas dão, somado.
static func gear_sum(worn: Dictionary) -> Dictionary:
	var out := {}
	for it in worn.values():
		var st := gear_of(it)
		for k in st:
			out[k] = out.get(k, 0.0) + st[k]
	return out


static func gear_slot(it: String) -> String:
	return GEAR[it.get_slice(":", 0)].slot


static func gear_rarity(it: String) -> int:
	return int(it.get_slice(":", 1))


## O nome que se vê: a base (comuns e únicos) ou a base curta e o 1.º afixo ("Botas da Lápide"). Já traduzido: estático,
## sem tr() (como gothic.gd:30).
static func gear_name(it: String) -> String:
	var a := it.split(":")
	var g: Dictionary = GEAR[a[0]]
	if a.size() < 3 or a[2].begins_with("q"):  # G3: uma comum com qualidade continua a ser só a base
		return String(TranslationServer.translate(g.name))
	return String(TranslationServer.translate(g.short)) + " " + String(TranslationServer.translate(AFFIX[affix_key(a[2])][0]))


static func rarity_color(r: int) -> Color:
	return Pix.ramp(RARITY_RAMP[r])[2]


## Uma peça apanhada (main.collect, só no anfitrião). Uma comum para um lugar ocupado vira logo Ossos, sem aviso (as comuns
## da mesma base são todas iguais). Num lugar vazio, ou mais rara do que a posta (menos os únicos, que têm custo), põe-se, e a
## de antes vai para a mochila; senão vai a nova. Com a mochila cheia desfaz-se a pior destrancada (a de menos raridade; entre
## iguais, a que acabou de chegar) em Ossos, e com todas trancadas a nova. Devolve o aviso ("" para nenhum).
func take_gear(it: String) -> String:
	var s := gear_slot(it)
	var r := gear_rarity(it)
	if gear.has(s) and r == 0:
		main.currency.bone += SCRAP[0]
		main.number(position + Vector2(0, -130), tr("+%d Ossos") % SCRAP[0], 18.0, rarity_color(0))
		return ""
	var msg := tr("Para a mochila do %s: %s. Vê-a no Arsenal > Equipamento.") % [tr(hero_name), gear_name(it)]
	var stuck: bool = bag.size() >= bag_cap() and bag.all(func(b): return b in locks)  # #78: mochila cheia e toda trancada: a posta trancada não tem para onde ir, e sai a nova
	if not gear.has(s) or (r < 3 and r > gear_rarity(gear[s]) and not (stuck and gear[s] in locks)):
		if gear.has(s):
			bag.append(gear[s])
		gear[s] = it
		refresh_stats()
		main.number(position + Vector2(0, -130), gear_name(it), 20.0, rarity_color(r))
		main.spawn_fx("ring", position, 90.0, rarity_color(r))
		msg = tr("Equipamento novo do %s: %s.") % [tr(hero_name), gear_name(it)]
	else:
		bag.append(it)
	if bag.size() <= bag_cap():
		return msg
	var worst := -1  # as trancadas (#78) nunca saem; com todas trancadas, sai a que acabou de entrar
	for i in bag.size():
		if not bag[i] in locks and (worst < 0 or gear_rarity(bag[i]) <= gear_rarity(bag[worst])):
			worst = i
	var out: String = bag.pop_at(worst if worst >= 0 else bag.size() - 1)
	main.currency.bone += SCRAP[gear_rarity(out)]
	return tr("Mochila do %s cheia: +%d Ossos (%s).") % [tr(hero_name), SCRAP[gear_rarity(out)], gear_name(out)]


## Põe a peça i da mochila (o painel do Equipamento; o convidado por net._ask). it tem de ser a que lá está: se a mochila
## mudou entretanto, não se faz nada. A que estava posta fica no lugar dela na mochila.
func equip_gear(i: int, it: String) -> bool:
	if i < 0 or i >= bag.size() or bag[i] != it:
		return false
	var s := gear_slot(it)
	if gear.has(s):
		bag[i] = gear[s]
	else:
		bag.remove_at(i)
	gear[s] = it
	refresh_stats()
	return true


## Desfaz a peça i da mochila em Ossos (#55), com a mesma guarda; uma trancada (#78) não. Devolve os Ossos (0: não fez nada).
func scrap_gear(i: int, it: String) -> int:
	if i < 0 or i >= bag.size() or bag[i] != it or it in locks:
		return 0
	bag.remove_at(i)
	main.currency.bone += SCRAP[gear_rarity(it)]
	return SCRAP[gear_rarity(it)]


## G4: a Forja de Peças. Gasta um material (main.mats, ou um Tinteiro das moedas) na peça it, posta (where = o lugar) ou na
## mochila (where = o índice, em texto; o convidado pede-o por net._ask). Como no equip_gear, it tem de ser a que lá está: se
## mudou entretanto, nada. Devolve o que aconteceu; o que não fez nada está em CRAFT_FAIL (a vermelho).
func craft_gear(where: String, it: String, kind: String) -> String:
	var worn: bool = where in SLOTS
	var i: int = int(where) if not worn and where.is_valid_int() else -1
	if not CRAFT.has(kind) or not gear_ok(it) or (gear.get(where, "") != it if worn else (i < 0 or i >= bag.size() or bag[i] != it)):  # gear_ok: um lugar vazio com it == "" passava
		return CRAFT_FAIL[0]
	var why := craft_why(it, kind, main.currency.ink if kind == "ink" else main.mats.get(kind, 0), it in locks)
	if why != "":
		return why
	var out := craft(it, kind, main.rng)
	if kind == "ink":
		main.currency.ink -= 1
	else:
		main.mats[kind] -= 1
	if worn:
		gear[where] = out
		refresh_stats()  # como o take_gear: o dicionário muda por dentro, sem passar pelo setter
	else:
		bag[i] = out
	return tr("%s » %s (%s)") % [gear_name(it), gear_name(out), tr(RARITY_WORD[gear_rarity(out)])]


## Bolsas de Almas (#72): a mochila tem 8 lugares e cada Bolsa do grupo dá mais 4 (8, 12, 16, 20).
func bag_cap() -> int:
	return BAG_MAX + 4 * main.bags


## Trancar peças (#78): tranca a peça it (posta ou na mochila) ou destranca-a. Devolve se ficou trancada (no máximo LOCKS_MAX).
func lock_gear(it: String) -> bool:
	if it in locks:
		locks.erase(it)
		return false
	if locks.size() >= LOCKS_MAX or not (it in bag or it in gear.values()):
		return false
	locks.append(it)
	return true


## Desfazer em lote (#266) e as marcadas (#280): desfaz cada peça de snapshot que ainda estiver na mochila (uma por entrada:
## duas iguais na lista são duas peças), destrancada, até à raridade max_r e nunca um único. Os Ossos vão para o grupo; devolve-os.
func scrap_many(max_r: int, snapshot: Array) -> int:
	var got := 0
	for it in snapshot.slice(0, bag.size()):  # a lista vem do painel (ou da rede): nunca mais do que a mochila tem
		var i: int = bag.find(it) if it is String and not it in locks else -1
		if i < 0 or gear_rarity(it) > mini(max_r, 2):
			continue
		bag.remove_at(i)
		got += SCRAP[gear_rarity(it)]
	main.currency.bone += got
	return got


func allocate(id: String) -> bool:
	var n: Dictionary = main.PASSIVES[id]
	# os nós de um só herói (S3, "hero") não abrem ao outro
	if points < 1 or id in passives or not n.req in passives or EXCLUSIVE.get(id, "") in passives or n.get("hero", hero) != hero:
		return false
	points -= 1
	passives.append(id)
	refresh_stats()
	return true


## Refazer a Árvore: devolve todos os pontos (a primeira vez é grátis; depois gasta um Tomo dos Nomes Esquecidos, #61,
## e só sem ele 1 Cinza do Purgatório).
func respec() -> String:
	if respecs > 0:
		if main.currency.tomo > 0:
			main.currency.tomo -= 1
		elif main.currency.ash < 1:
			return "Sem Cinzas do Purgatório."
		else:
			main.currency.ash -= 1
	respecs += 1
	passives = ["raiz"]
	points = main.level - 1 + main.relics.size()  # e as Relíquias de Família (#58)
	canibal_n = 0  # o que os nós deram ao herói sai com eles
	fome_n = 0
	refresh_stats()
	mana = minf(mana, max_mana)
	return tr("Árvore refeita: %d pontos devolvidos") % points


func _process(delta: float) -> void:
	t += delta
	revived_t = maxf(0.0, revived_t - delta)
	if dead:
		return
	if furia_until > 0.0 and main.time >= furia_until:  # Fúria Póstuma (#169): não matou ninguém a tempo, cai
		_fall()
		return
	var dir := Input.get_vector(pfx + "move_left", pfx + "move_right", pfx + "move_up", pfx + "move_down")
	if touch_move != Vector2.ZERO:
		dir = touch_move
	if root_until > main.time:  # preso pela corrente do Carrasco (#44): não anda
		dir = Vector2.ZERO
	var start := position
	if dash_t > 0.0:
		dash_t -= delta
		position += dash_dir * DASH_SPEED * delta
		if dash_t <= 0.0:  # chegada: um anel no sítio onde aterra
			main.spawn_fx("ring", position, 40.0, Color(0.6, 1.0, 0.9))
		if stat("teeth") > 0.0 and (main.teeth.is_empty() or main.teeth[-1][0].distance_to(position) > 30.0):
			main.teeth.append([position, 3.0 * stat("teeth")])  # as Unhas de Carniçal (0.4.8) com os Dentes de Sepultura: o dobro do tempo
			if main.teeth.size() > 24:  # a Alma Mártir devolve a esquiva a cada abate: sem teto a lista crescia sem fim
				main.teeth.pop_front()
	else:
		var lead := order.any(func(id): return id in ["scythe", "chop", "cleave"] and skills[id].support == "chumbo")  # Alma de Chumbo (#142): anda a 85%
		var v: Vector2 = dir * 230.0 * (1.0 + stat("speed") + 0.01 * march) * main.blood_speed(position) * (0.5 if iron_t > 0.0 else 1.0) * (0.85 if lead else 1.0) * main.terrain_speed()
		# Cripta Submersa (#181): na bile escorrega ~0,3 s até pegar no rumo novo; Lago das Lamentações (#30): a maré empurra;
		# Moinho de Carne (#202): a passadeira leva-o para a serra
		slide_v = slide_v.lerp(v, 1.0 - exp(-4.0 * delta)) if main.crypt_rule == "submersa" else v
		position += (slide_v + main.tide_push() + main.belt_push(position)) * delta
		if dir.length() >= 0.75 and main.time >= step_t:  # Monge Penitente Cego (#193): correr faz barulho, de 0,6 em 0,6 s
			step_t = main.time + 0.6
			if main.enemies().any(func(e): return e.boss == "monge"):
				main.noise(position, 0.0)
	position = position.clamp(main.bounds.position + Vector2(30, 30), main.bounds.end - Vector2(30, 30))
	position = main.walk(start, position)
	walk_t = walk_t + delta if dir.length() > 0.2 else 0.0
	# Durante um ataque fica virado para o alvo; parado, vira-se para o inimigo mais perto
	if dash_t > 0.0:
		facing = dash_dir
	elif swing <= 0.0 and spin <= 0.0 and cast_t <= 0.0 and nova_t <= 0.0:
		facing = dir.normalized() if dir.length() > 0.2 else _aim()
	tilt = lerpf(tilt, dir.x * 0.06, 1.0 - exp(-10.0 * delta))
	flip_s = move_toward(flip_s, 1.0 if facing.x > 0.0 else -1.0, delta * 12.0)
	var cursed := cursed_lock() != ""  # Frascos Malditos (#21): sem regeneração natural, nem de vida nem de alma
	var burns: bool = main.crypt_rule == "chamas"  # Necrópole em Chamas Negras (#35): fora dos abrigos a alma arde 4/s; dentro volta +4/s
	var roof: bool = burns and main.sheltered(position)
	if stat("fragmentada") > 0.0:  # Mente Fragmentada (#108): a mana fica a zero; quem paga as habilidades é a poção de alma
		mana = 0.0
	elif burns and not roof:
		mana = maxf(0.0, mana - 4.0 * delta)
	elif main.sanctum_rule == 3:  # Santuário (#50), Terceira lei: a alma esvai-se, 8 por segundo (cada morte dá 30)
		mana = maxf(0.0, mana - 8.0 * delta)
	elif stat("semalma") <= 0.0 and not cursed:  # Sem Alma Própria (#132): sem regeneração; a alma vem das esferas dos abates
		mana = minf(max_mana, mana + (7.0 + stat("regen") + (4.0 if roof else 0.0)) * delta)
	if not cursed:
		hp = minf(max_hp, hp + 1.0 * delta)
	# Alma Voraz (#141): com um monstro a menos de 700 px come 2% da vida por segundo, até metade
	if wears("voraz") and hp > max_hp * 0.5 and main.enemies().any(func(e): return not e.dummy and e.position.distance_to(position) < 700.0):
		hp = maxf(max_hp * 0.5, hp - max_hp * 0.02 * delta)
		hurt = maxf(hurt, 0.06)  # fica avermelhado enquanto o come (abaixo de 0,1 não muda o desenho)
	# Passos da Marcha Fúnebre (#228): com um monstro a menos de 700 px, +1% de velocidade por segundo até 30; 3 s sem nenhum, volta a 0
	if stat("marcha") > 0.0 and main.enemies().any(func(e): return not e.dummy and e.position.distance_to(position) < 700.0):
		march = minf(march + delta, 30.0)
		march_quiet = 0.0
	else:
		march_quiet += delta
		if march_quiet >= 3.0 or stat("marcha") <= 0.0:
			march = 0.0
	if stat("aura") > 0.0 and t >= aura_t:  # Incensário Fúnebre (#63): uma baforada de cinza a cada 1,2 s
		aura_t = t + 1.2
		main.spawn_fx("dust", position, 18.0, Color(0.7, 0.68, 0.62))
	corruption = maxf(0.0, corruption - 3.0 * delta)
	if overload_t > 0.0:  # a Sobrecarga escoa a vida, mas nunca mata
		overload_t = maxf(0.0, overload_t - delta)
		pay_life(max_hp * (0.06 if stat("imolacao") > 0.0 else 0.03) * delta)  # Imolação Funerária (#127): escoa o dobro
	if self_bleed_t > 0.0:  # Alma Sacrificial: sangra 1,5% da vida por segundo, mas nunca mata
		self_bleed_t = maxf(0.0, self_bleed_t - delta)
		pay_life(max_hp * 0.015 * delta)
		hurt = maxf(hurt, 0.06)  # fica avermelhado enquanto sangra (abaixo de 0,1 não muda o desenho)
	if debt > 0.0:  # Sangue Negro Impenetrável (#117): a vida paga volta a 3% por segundo
		var back := minf(debt, max_hp * 0.03 * delta)
		debt -= back
		heal(back)
	# Apoteose do Lich de Ferro (#140): com as duas poções cheias é o Lich; beber quebra a forma por 20 s
	lich_cd = maxf(0.0, lich_cd - delta)
	var up: bool = stat("lich") > 0.0 and lich_cd <= 0.0 and potions.hp >= POTION_MAX and potions.mp >= POTION_MAX
	if up and not lich:
		main.number(position + Vector2(0, -120), tr("Apoteose!"), 20.0, Color(0.72, 0.78, 0.9))
		main.spawn_fx("ring", position, 90.0, Color(0.72, 0.78, 0.9))
		main.vibrate(60, 0.6, self)
	lich = up
	for k in cds:
		if cds[k] > 0.0 and cds[k] <= delta and skills[k].cd >= RING_CD:
			ready_t[k] = READY_T
			if skills[k].dmg == 0.0:
				main.vibrate(40, 0.4, self)  # a defesa (Armadura de Ossos) voltou: sente-se no telemóvel de quem a tem
		cds[k] = maxf(0.0, cds[k] - delta)
		ready_t[k] = maxf(0.0, ready_t.get(k, 0.0) - delta)
	swing = maxf(0.0, swing - delta)
	dash_cd = maxf(0.0, dash_cd - delta)
	pacto_t = maxf(0.0, pacto_t - delta)
	grace_cd = maxf(0.0, grace_cd - delta)
	grito_cd = maxf(0.0, grito_cd - delta)
	simb_cd = maxf(0.0, simb_cd - delta)
	falange_cd = maxf(0.0, falange_cd - delta)
	iron_t = maxf(0.0, iron_t - delta)
	iron_cd = maxf(0.0, iron_cd - delta)
	vinganca_cd = maxf(0.0, vinganca_cd - delta)
	spin = maxf(0.0, spin - delta)
	cast_t = maxf(0.0, cast_t - delta)
	nova_t = maxf(0.0, nova_t - delta)
	guard_t = maxf(0.0, guard_t - delta)
	armor = maxf(0.0, armor - delta)
	barrier = maxf(0.0, barrier - max_hp * 0.01 * delta)  # escoa devagar: 1% da vida máxima por segundo (cheia, ~25 s)
	if wears("martir"):  # Alma Mártir (#151): sem barreira de ossos, nem a que já havia
		barrier = 0.0
	hurt = maxf(0.0, hurt - delta)
	lean_t += delta
	chunk_wait -= delta
	hp_chunk = maxf(hp_chunk, hp) if chunk_wait > 0.0 else move_toward(hp_chunk, hp, max_hp * 0.8 * delta)
	heal_num_t -= delta
	if heal_num_t <= 0.0 and heal_acc >= 3.0:
		heal_num_t = 0.5
		main.number(position + Vector2(0, -90), "+%d" % int(heal_acc), 15.0, Color(0.45, 1.0, 0.55))
		heal_acc = 0.0
	if soul == "cranios":
		_skulls(delta)
	if stat("fome") > 0.0:
		_fome(delta)
	var want := []
	for i in 3:
		if Input.is_action_pressed(pfx + "skill_%d" % (i + 1)) or held.get(order[i], false):
			want.append(order[i])
	if lock_skills:
		lock_skills = not want.is_empty()  # o A que fechou um painel não conta como ataque
	else:
		for id in want:
			use_skill(id)
		if self == main.player and auto_attack() and not main.trial_on("lamina"):  # na Lâmina Cega (#214) o golpe automático não sai
			use_skill(order[0])
	if Input.is_action_just_pressed(pfx + "interact") and Engine.get_process_frames() > main.hud.closed_frame:  # B: interage com o que está perto; sem nada, esquiva
		if main.hud.hint_action != "":
			main.interact(self)
		else:
			dodge(dir)
	if Input.is_action_just_pressed(pfx + "stance"):
		toggle_stance()
	if Input.is_action_just_pressed(pfx + "potion_hp"):
		use_potion("hp")
	if Input.is_action_just_pressed(pfx + "potion_mp"):
		use_potion("mp")
	queue_redraw()


## Esquiva Espectral: um salto rápido para onde se anda (ou para a frente), sem levar dano durante o salto.
func dodge(dir: Vector2) -> void:
	if Net.is_guest():
		Net.dodge(dir)
		return
	if dead or dash_cd > 0.0:
		return
	if stat("pacto") > 0.0:  # Pacto de Carne e Ferro (#101): sem Esquiva Espectral; diz porquê em vez de não fazer nada
		if pacto_t <= 0.0:
			pacto_t = 0.5
			main.number(position + Vector2(0, -110), tr("Pacto"), 16.0, Color(0.7, 0.7, 0.75))
		return
	if root_until > main.time:  # preso pela corrente do Carrasco (#44): nem a esquiva o solta
		if pacto_t <= 0.0:
			pacto_t = 0.5
			main.number(position + Vector2(0, -110), tr("Preso!"), 18.0, Color(0.7, 0.7, 0.78))
		return
	if not main.webs.is_empty() and main.web_at(position) >= 0:  # Covil do Tecelão (#36): numa teia de tendões não há esquiva
		if pacto_t <= 0.0:
			pacto_t = 0.5
			main.number(position + Vector2(0, -110), tr("Preso nos tendões!"), 18.0, Color(0.85, 0.45, 0.45))
		return
	dash_dir = dir.normalized() if dir.length() > 0.2 else facing
	dash_t = DASH_T
	dash_cd = DASH_CD
	main.sfx("dash")
	main.vibrate(20, 0.4, self)
	if stat("sentinel") > 0.0:  # Sentinelas Tumulares (#25): finca uma lápide onde estava; no máximo 2 por herói (a mais antiga sai)
		var mine: Array = main.sentinels.filter(func(s): return s[3] == slot)
		if mine.size() >= 2:
			main.sentinels.erase(mine[0])
		main.sentinels.append([position, main.time + 10.0, main.time + 0.6, slot])
	main.spawn_decoy(self)
	main.spawn_fx("dash", position, DASH_SPEED * DASH_T, Color.WHITE, dash_dir, "bleed" if stance == "ira" else "iron" if lich else "soul")  # cinzas, riscos e derrapagem


## Guarda Sepulcral ↔ Ira Sacrificial (no convidado, quem troca é o anfitrião).
func toggle_stance() -> void:
	if Net.is_guest():
		Net.stance()
		return
	if dead:
		return
	stance = "ira" if stance == "guarda" else "guarda"
	var ira := stance == "ira"
	main.number(position + Vector2(0, -120), tr("Ira Sacrificial") if ira else tr("Guarda Sepulcral"), 20.0, Color(1.0, 0.35, 0.3) if ira else Color(0.85, 0.85, 0.75))
	main.spawn_fx("ring", position, 60.0, Color(0.9, 0.2, 0.2) if ira else Color(0.85, 0.82, 0.7))
	main.vibrate(30, 0.4, self)
	if ira and grito_cd <= 0.0 and stat("grito") > 0.0:  # Grito de Guerra Fúnebre (#20): os mortos menores à volta entram em pânico
		grito_cd = 12.0
		for e in main.enemies():
			if not e.is_boss and not e.dummy and e.position.distance_to(position) < 240.0 + e.radius:
				e.panic_t = 4.0
				e.panic_target = null
				e._number(tr("Pânico!"), 16.0, Color(1.0, 0.8, 0.4))
		main.spawn_fx("ring", position, 240.0, Color(1.0, 0.35, 0.3))
		main.sfx("roar")
		main.shake = maxf(main.shake, 8.0)
		main.vibrate(60, 0.7, self)


## Troca o frasco de uma habilidade pelo seguinte que o grupo já encontrou.
func cycle_support(id: String) -> void:
	var have: Array = SUPPORTS.filter(func(f): return f in main.flasks and not (f in CURSED and id == order[0]))
	set_support(id, have[(have.find(skills[id].support) + 1) % have.size()])


## Põe na habilidade um frasco que o grupo já encontrou (a grelha do Arsenal). Frascos Malditos (#21): nunca no golpe
## básico; o posto numa habilidade esvazia e prende a outra (cursed_lock), e nada vai na presa. Na Provação das Almas (#37), nada.
func set_support(id: String, f: String) -> void:
	if stash == null and id in order and f in SUPPORTS and f in main.flasks and id != cursed_lock() and not (f in CURSED and id == order[0]):
		skills[id].support = f
		if f in CURSED:
			skills[cursed_lock()].support = ""


## Frascos Malditos (#21): a habilidade presa pelo frasco maldito da outra ("" sem nenhum). Vem dos frascos postos:
## tirá-lo solta-a, e o jogo gravado e o convidado não precisam de mais nada.
func cursed_lock() -> String:
	for i in [1, 2]:
		if skills[order[i]].support in CURSED:
			return order[3 - i]
	return ""


## Veste a Alma Condensada (uma que o grupo já encontrou; "" tira-a).
func set_soul(f: String) -> void:
	if stash == null and f in SOULS and f in main.flasks:  # na Provação das Almas (#37) não se veste nenhuma
		soul = f


## Alguma habilidade do herói leva este frasco?
func wears(f: String) -> bool:
	return order.any(func(id): return skills[id].support == f)


## Poção de vida (40% da vida) ou de alma (60% da alma). Gasta uma carga; não se gasta cheia.
func use_potion(kind: String) -> void:
	if Net.is_guest():
		Net.tap(1 if kind == "hp" else 2)
		return
	# Bispo dos Leprosos (#183): na névoa cáustica a de vida não cura (heal) e também não se gasta
	var fog: bool = kind == "hp" and not main.pools.is_empty() and main.pool_at(position, "nevoa")
	if (main.sanctum_rule == 4 or fog) and not dead:  # Santuário (#50), Quarta lei: só a morte cura (as poções não fazem nada)
		if pacto_t <= 0.0:
			pacto_t = 0.5
			main.number(position + Vector2(0, -110), tr("A névoa não deixa curar!") if fog else tr("Só a morte cura!"), 16.0, Color(1.0, 0.85, 0.5))
		return
	# Sangue Negro (#117) não bebe a de vida; Mente Fragmentada (#108) não bebe a de alma
	if dead or potions[kind] < 1.0 or (hp >= max_hp if kind == "hp" else mana >= max_mana) or stat("sangue" if kind == "hp" else "fragmentada") > 0.0:
		return
	potions[kind] -= 1.0
	lich = false  # o Lich (#140) quebra antes da cura: a poção cura vida, não vira barreira
	lich_cd = 20.0
	if kind == "hp":
		heal(max_hp * 0.4)
	else:
		mana = minf(max_mana, mana + max_mana * 0.6)
	main.sfx("potion")
	if main.effects_level() == 0:  # efeitos baixos: o brilho simples
		main.spawn_fx("glow", position + Vector2(0, -40), 55.0, Color(1.0, 0.3, 0.3) if kind == "hp" else Color(0.35, 0.7, 1.0))
	else:  # cruzes vermelhas (vida) ou gotas azuis (alma) que sobem do herói e o seguem
		main.spawn_fx("heal", position, 18.0 if kind == "hp" else 14.0, Color.WHITE, Vector2.RIGHT, "life" if kind == "hp" else "soulblue").follow = slot


## Almas Transitórias (#4): liberta a alma de um só uso. S = o golpe mais forte das habilidades do herói agora.
## Lamento das Almas: 12 lascas de alma teleguiadas para os 12 monstros mais perto (até 600 px), 2×S cada.
## Cataclismo: rebenta tudo a 400 px com 3×S.
func use_trans() -> void:
	if Net.is_guest():
		Net.trans()
		return
	if dead or trans_until <= main.time:
		return
	trans_until = 0.0
	var s := 0.0
	for id in order:
		s = maxf(s, skill_numbers(id)[0])
	var teal := Color(0.4, 0.95, 0.9)
	main.number(position + Vector2(0, -130), tr(TRANS[trans_kind]) + "!", 24.0, teal)
	main.vibrate(80, 0.8, self)
	if trans_kind == "lamento":
		var foes: Array = main.enemies().filter(func(e): return position.distance_to(e.position) < 600.0)
		foes.sort_custom(func(a, b): return position.distance_squared_to(a.position) < position.distance_squared_to(b.position))
		var from := position + Vector2(0, -30)
		for e in foes.slice(0, 12):
			var b = main.spawn_bolt(from, from.direction_to(e.position + Vector2(0, -20)), 2.0 * s, 12.0, self, 0, true)
			b.seek = e
			b.tint = teal
			b.quiet = true  # sem uma paragem de impacto por lasca
		main.spawn_fx("ring", position, 120.0, teal)
		main.sfx("cast")
		return
	main.hit_circle(position, 400.0, 3.0 * s, self)
	main.spawn_fx("ring", position, 400.0, teal)
	if main.fx_budget("explosion", 2, 4):
		main.spawn_fx("explosion", position, 1.8, teal, Vector2.RIGHT, "soul")
	main.shake = maxf(main.shake, 18.0)
	main.sfx("roar")


func fill_potions(amount: float) -> void:
	for k in potions:
		potions[k] = minf(POTION_MAX, potions[k] + amount)


func use_skill(id: String) -> void:
	if dead or cds[id] > 0.0:
		return
	if id == order[0] and main.trial_on("lamina"):  # Provação da Lâmina Cega (#214): os golpes básicos não saem
		if pacto_t <= 0.0:
			pacto_t = 0.5
			main.number(position + Vector2(0, -110), tr("Lâmina Cega!"), 16.0, Color(0.75, 0.75, 0.8))
		return
	var s: Dictionary = skills[id]
	var cost: float = s.mana
	var costly: bool = cost > 0.0  # paga-se em alma, na poção (Mente Fragmentada) ou em vida (Parasita); a foice e o machado com a Parasita não contam
	if costly and main.crypt_rule == "chamas" and not main.sheltered(position):  # Chamas Negras (#35): só nos abrigos de pedra
		if pacto_t <= 0.0:
			pacto_t = 0.5
			main.number(position + Vector2(0, -110), tr("Sem abrigo de pedra!"), 16.0, Color(0.75, 0.6, 1.0))
		return
	if main.sanctum_rule == 2 and costly:  # Santuário (#50), Segunda lei: a alma paga-se com sangue (nunca mata)
		pay_life(cost)
		hurt = 0.1
	elif s.support == "parasita":
		var life_cost := maxf(cost * 1.5, 6.0)
		if hp <= life_cost + 1.0:
			return
		pay_life(life_cost)
		hurt = 0.1
	elif stat("fragmentada") > 0.0:  # Mente Fragmentada (#108): bebe da poção de alma (60 de custo = 1 carga)
		if potions.mp < cost / 60.0:
			return
		potions.mp -= cost / 60.0
		if cost > 0.0:
			main.spawn_fx("sparks", position + Vector2(0, -40), 0.0, Color(0.35, 0.7, 1.0))
	else:
		if mana < cost:
			return
		mana -= cost
	if stance == "ira":  # a Ira paga-se em sangue (nunca mata)
		pay_life(max_hp * 0.02)
		hurt = 0.08
	if s.support == "carga":  # cada uso renova os 3 s de sangria (não se soma)
		self_bleed_t = 3.0
	if s.support == "meteoro" and id in ["nova", "cleave"]:  # Alma Meteórica (#159): o esmagamento paga-se em sangue, mas nunca mata
		pay_life(max_hp * 0.08)
		hurt = 0.1
	if overload_t <= 0.0:  # Instabilidade de Alma: o custo base pesa na alma, também quando a Parasita paga com vida
		add_corruption(cost * 0.6)
	# Sanctum do Silêncio (#46): acorda os mortos à volta (a foice e o machado não fazem barulho); o Monge (#193) também ouve
	if costly and (main.crypt_rule == "silencio" or main.enemies().any(func(e): return e.boss == "monge")):
		main.noise(position, 900.0)
	var n := skill_numbers(id)
	if s.support == "gatilho" and s.area > 0.0:  # gasta o abate que deu a área maior (a Armadura de Ossos não tem área)
		var g: Array = main.grave_near(position)
		if not g.is_empty():
			main.graves.erase(g)
			main.spawn_fx("burst", g[0], 0.0, Color(0.35, 0.3, 0.3))
			main.spawn_fx("ring", g[0], 60.0, Color(0.35, 0.3, 0.3))
	cds[id] = n[2]
	used = used.filter(func(u): return main.time - u[1] < 20.0)
	used.append([id, main.time])
	var aim := _aim()
	facing = aim
	flip_s = 1.0 if aim.x > 0.0 else -1.0  # ao atacar vira-se logo
	_cast(id, n[0], n[1], aim, s.support)
	if s.support == "roubo" and potions.hp + potions.mp > 0.0:  # a Ladra bebe da poção mais cheia; este golpe já teve o bónus
		var k := "hp" if potions.hp >= potions.mp else "mp"
		potions[k] = maxf(0.0, potions[k] - 0.125)  # 1/8 e não 1/10: as cargas ficam múltiplos exatos (matar dá 1/4) e a poção cheia nunca vira 0,9999
	if s.support == "eco":
		await get_tree().create_timer(0.35, false).timeout
		if is_inside_tree() and not dead:
			echoing = true
			_cast(id, n[0] * 0.6, n[1], _aim(), "eco")
			echoing = false


## Dano, área e recarga de uma habilidade agora, e de onde vem o dano: [dano, área, recarga,
## [[nome, multiplicador], ...]]. O Arsenal mostra as partes (Fórmulas de dano).
func skill_numbers(id: String) -> Array:
	var s: Dictionary = skills[id]
	var area: float = s.area
	var cd: float = s.cd
	var parts := [["bónus de dano", 1.0 + stat("dmg")]]
	if stat("gdmg") != 0.0:  # Equipamento (0.4.8): um multiplicador à parte, para se notar mesmo com a foice muito reforjada (o tier soma-se ao "dmg", main:1284)
		parts.append(["bónus do equipamento", 1.0 + stat("gdmg")])
	if stance == "ira":
		parts.append(["Ira Sacrificial", 1.3])
		cd *= 0.75
	if stat("circulacao") > 0.0:  # Circulação Negra (#119): -1% de recarga por cada 2% de vida perdida, até -35% (a Esquiva não passa aqui)
		cd *= 1.0 - 0.35 * clampf((1.0 - hp / max_hp) / 0.7, 0.0, 1.0)
	if lich:
		parts.append([main.PASSIVES.lich.name, 1.3])
	if furia_until > main.time:  # Fúria Póstuma (#169): dano a dobrar
		parts.append(["Fúria Póstuma", 2.0])
	if s.mana > 0.0 and s.support != "parasita" and stat("fragmentada") > 0.0:  # a Parasita paga com vida: não bebe da poção nem ganha o bónus
		parts.append([main.PASSIVES.fragmentada.name, 1.4])
	if id in ["bolt", "nova"]:
		parts.append(["bónus de feitiços", 1.0 + stat("spell")])
	if id in ["nova", "cleave"] and stat("bone_skill") > 0.0:  # Coroa das Espinhas Dorsais (#222): as habilidades de ossos (sem níveis: +25%)
		parts.append([GEAR.coroa.name, 1.0 + stat("bone_skill")])
	if id == order[0]:  # G7: a alma da arma no golpe básico (as Fórmulas mostram a parte dela)
		match main.form_on():
			"foice_longa":
				parts.append([main.FORMS.foice_longa[0], 1.1])
				area *= 1.4
				cd *= 1.25
			"juramento":
				area *= 0.65
				cd *= 0.5
	match s.support:
		"parasita":
			parts.append([SUPPORT_NAMES.parasita, 2.2])
			area *= 1.5
		"titanica":
			area *= 1.8
			cd *= 1.7
		"veloz":
			parts.append([SUPPORT_NAMES.veloz, 0.8])
			cd *= 0.55
		"colerica":
			parts.append([SUPPORT_NAMES.colerica, 1.0 + 0.8 * clampf((1.0 - hp / max_hp) / 0.7, 0.0, 1.0)])
		"roubo":  # Alma Ladra: só enquanto houver poção para roubar (quem bebe é o use_skill)
			if potions.hp + potions.mp > 0.0:
				cd *= 0.7
		"gatilho":  # Alma Gatilho: há um abate recente perto para gastar (quem o gasta é o use_skill)
			if not main.grave_near(position).is_empty():
				area *= 1.5
		"carga":
			parts.append([SUPPORT_NAMES.carga, 1.3])
		"meteoro":  # Alma Meteórica (#159): só os esmagamentos (Nova e Ceifa de Ossos); nos golpes básicos, com ataque automático, escoava a vida sem parar
			if id in ["nova", "cleave"]:
				area *= 1.75
				cd *= 2.2
		"terramoto":  # Alma Sísmica (#173): só a Nova e a Ceifa de Ossos batem no chão; nas outras não faz nada nem custa
			if id in ["nova", "cleave"]:
				parts.append([SUPPORT_NAMES.terramoto, 0.75])
				cd *= 1.6
		"chumbo":  # Alma de Chumbo (#142): só os golpes corpo a corpo (quem abranda o passo é o _process)
			if id in ["scythe", "chop", "cleave"]:
				area *= 1.6
	var dmg: float = s.dmg
	for p in parts:
		dmg *= p[1]
	return [dmg, area, cd, parts]


## O efeito da habilidade (custo e recarga já pagos em use_skill; o Eco chama-o outra vez, de graça).
func _cast(id: String, dmg: float, area: float, aim: Vector2, support: String) -> void:
	if support == "terramoto" and not id in ["nova", "cleave"]:  # Alma Sísmica: só os golpes no chão; a Lança rebenta em hit_circle e petrificava a cada 0,55 s
		support = ""
	var green := Color(0.9, 0.15, 0.25) if support in ["parasita", "carga", "meteoro"] else Color(0.35, 1.0, 0.6)
	var tone := "bleed" if support in ["parasita", "carga", "meteoro"] else ""  # a rampa do golpe em píxeis, a par do verde
	if support == "roubo" and potions.hp + potions.mp > 0.0:
		green = Color(1.0, 0.6, 0.25)  # âmbar: a Ladra está a roubar às poções
		tone = "gold"
	if support == "gravidade":
		green = Color(0.55, 0.35, 0.8)  # violeta: a Gravitacional
		tone = "necro"
	if support == "terramoto":
		green = Color(0.85, 0.8, 0.65)  # cor de osso: a Sísmica (a do anel da Ceifa de Ossos)
		tone = "bone"
	if support == "biomecanica":
		green = Color(0.7, 0.5, 1.0)  # violeta: o raio necrótico da Biomecânica (#144)
		tone = "necro"
	var raise := 2 if support == "mitotico" else 1 if support == "tumular" else 0  # quantos aliados se erguem de quem morrer com este golpe
	main.raise_by = self if raise > 0 else null
	main.raise_n = raise
	main.cast_support = support  # o frasco deste golpe, para main._damage (posto e limpo como o raise_by)
	if support == "caotico":  # Alma Caótica (#147): podridão, necrose, calcificação, podridão... um estado por uso
		main.cast_aff = 1 + chaos_n % 3
		chaos_n += 1
		green = main.CORPSE_COLORS[main.cast_aff]  # as cores que os crânios do #9 já ensinaram
		tone = ["", "rot", "necro", "bone"][main.cast_aff]
	if id in ["scythe", "chop", "bolt"]:
		lean_t = 0.0
		lean_dir = aim
	match id:
		"scythe", "chop":
			var form: String = main.form_on()  # G7: a alma da arma (o golpe básico é sempre um destes dois)
			swing_len = minf(ATTACK_T, skills[id].cd * 0.5) if form == "juramento" else ATTACK_T  # o golpe acaba antes do seguinte
			swing = swing_len
			main.sfx("swing" if id == "scythe" else "swing_heavy")  # ouve-se a lâmina mesmo sem acertar
			# foice de alma, machado de osso (gume branco nos dois); o frasco muda a cor como ao verde; a alma da arma também; o eco sai mais fraco
			if tone == "":
				tone = main.FORMS[form][2] if form != "" else "soul" if id == "scythe" else "bone"
			main.cast_basic = true
			main.basic_first = null
			if id == "chop" and not echoing:  # o eco repete o golpe que foi (rodopio ou não) sem avançar a conta
				combo = combo + 1 if t - combo_t < 1.2 else 1
				combo_t = t
			if id == "chop" and combo % 3 == 0:  # o 3.º golpe seguido roda: apanha tudo à volta, mais forte
				spin = SPIN_T
				# shortcut: o rodopio é um hit_circle e não bebe com a Sede Ancestral (#135, só no hit_arc); se fizer falta, passa a beber aqui também
				main.hit_circle(position, area * 1.2, dmg * 1.3, self, true, false)  # o machado não acende o piche (#166), nem com a área maior
				for d in [aim, -aim]:
					main.spawn_fx("slash", position + Vector2(0, -20), area * 1.2, Color(1, 1, 1, 0.6 if support == "eco" else 1.0), d, tone, 20.0)
			else:
				main.hit_arc(position, aim, area, dmg, self)
				# Lote 9 C (d): o Juramento (área x0,65) desenha-se do tamanho com que bate, com o gume da largura de um golpe normal
				# (mais curto e fino, mal se via; desenhado maior, parecia cortar quem ficava fora)
				# a foice verde de sempre (sem frasco, alma da arma nem eco) é a folha do pixelfx, de lado, para onde o herói se
				# virou ao atacar (o use_skill pôs o flip_s pela mira); as outras cores, os efeitos baixos e as áreas maiores (Titânica,
				# Chumbo, Gatilho: a folha só fica em células de 2x2 na área de base) ficam com o crescente
				if id == "scythe" and tone == "soul" and support != "eco" and is_equal_approx(area, Pix.REAP_AREA) and main.fx_budget("pfx_reap", 2, 6):
					main.spawn_fx("pfx_reap", position, 1.0, Color.WHITE, Vector2(1.0 if flip_s >= 0.0 else -1.0, 0))
				else:
					var fx = main.spawn_fx("slash", position + Vector2(0, -20), area, Color(1, 1, 1, 0.6 if support == "eco" else 1.0), aim, tone, 20.0)
					if form == "juramento":
						fx.thick = 1.0 / 0.65
			main.cast_basic = false
			_form_after(form, dmg, aim)
		"bolt":
			cast_t = CAST_T
			main.sfx("cast")
			main.spawn_fx("glow", position + Vector2(0, -20), 40.0, Color(0.6, 0.4, 1.0))  # a alma junta-se na mão antes de partir
			# Antecipação: a Lança só parte quando o braço avança (2.º frame do lançamento)
			var aff: int = main.cast_aff  # a Lança parte depois de o golpe acabar: leva a afinidade consigo
			var stake := stat("estacas") > 0.0  # Lança-Ossos Balística (#103): estaca de osso que atravessa 3 e os prende onde parar
			get_tree().create_timer(CAST_T / 4.0, false).timeout.connect(func():
				if is_inside_tree() and not dead:
					var b = main.spawn_bolt(position + Vector2(0, -20), aim, dmg, area, self, raise, stake)
					b.support = support
					b.aff = aff
					if stake:
						b.pierce = 3
						b.pin = true)
		"nova":  # Erguer os Mortos: a explosão e 2 esqueletos teus (o tecto de MAX_ALLIES manda embora os mais antigos)
			nova_t = NOVA_T
			main.sfx("cast")
			main.hit_circle(position, area, dmg, self)
			main.spawn_fx("ring", position, area, green)
			for s in [-1.0, 1.0]:
				main.spawn_ally(main.walk(position, position + Vector2(s * 50.0, 30.0)), self)
		"cleave":  # redemoinho: 3 voltas (0 / 0,2 / 0,4 s) que andam com ele, todas com o frasco do golpe
			spin = SPIN_T
			main.sfx("swing_heavy")
			var ring := Color(0.9, 0.25, 0.3) if support in ["parasita", "carga", "meteoro"] else green if support == "caotico" else Color(0.85, 0.8, 0.65)
			var aff: int = main.cast_aff
			var whirl := func():
				main.raise_by = self if raise > 0 else null
				main.raise_n = raise
				main.cast_support = support
				main.cast_aff = aff
				main.chain_all = true  # Correnteza Fúnebre (#153): com a Biomecânica, os arcos ligam todos os que a volta apanha
				main.hit_circle(position, area, dmg, self, true)
				main.chain_all = false
				main.raise_by = null
				main.cast_support = ""
				main.cast_aff = 0
				main.spawn_fx("ring", position, area, ring)
				for d in [aim, -aim]:
					main.spawn_fx("slash", position + Vector2(0, -20), area, Color(1, 1, 1, 0.6 if support == "eco" else 1.0), d, "bone" if tone == "" else tone, 20.0)
				flip_s = -flip_s  # vira-se a meio da volta (volta sozinho ao lado certo)
			whirl.call()
			for i in [1, 2]:
				get_tree().create_timer(0.2 * i, false).timeout.connect(func():
					if is_inside_tree() and not dead:
						whirl.call())
		"bonearmor":
			armor = 5.0 * (1.0 + stat("bone_skill"))  # a Coroa das Espinhas Dorsais (#222): +25% no tempo e na cura
			guard_t = GUARD_T
			main.spawn_fx("ring", position + Vector2(0, -30), 70.0, Color(0.9, 0.85, 0.7))
			if not echoing:  # e cura (uma vez: o eco só repete a armadura): as cruzes vermelhas da poção de vida
				heal(max_hp * 0.15 * (1.0 + stat("bone_skill")))
				if main.effects_level() == 0:
					main.spawn_fx("glow", position + Vector2(0, -40), 55.0, Color(1.0, 0.3, 0.3))
				else:
					main.spawn_fx("heal", position, 18.0, Color.WHITE, Vector2.RIGHT, "life").follow = slot
	if support == "meteoro" and id in ["nova", "cleave"]:  # Alma Meteórica (#159): 6 estilhaços de osso a direito (sem seek: não perseguem)
		if main.fx_budget("explosion", 2, 4):  # e rebenta o chão: cratera, terra e pedras de osso, clarão de alma
			main.spawn_fx("explosion", position, 1.4, Color(0.35, 1.0, 0.6), Vector2.RIGHT, "ash")
		for i in 6:
			main.spawn_bolt(position, Vector2.from_angle(TAU * i / 6.0 + 0.3), dmg * 0.25, 10.0, self, 0, true)
	main.raise_by = null
	main.cast_support = ""
	main.cast_aff = 0
	if support in CURSED:  # o dano do golpe básico, se for maior: na Armadura de Ossos (sem dano) o frasco não se perde
		_cursed(support, maxf(dmg, skill_numbers(order[0])[0]), aim)


## G7 e #238: o que o golpe básico faz depois de bater. O Sino da Agonia badala à volta do 1.º monstro em que bateu (no máximo
## uma vez em cada 0,35 s), o Disparador de Tíbias larga uma tíbia a cada 3 golpes e a Parede dos Lamentos solta o grito
## guardado (os três sem o cast_basic: não badalam nem largam mais nada).
func _form_after(form: String, dmg: float, aim: Vector2) -> void:
	var first = main.basic_first
	main.basic_first = null
	if form == "sino" and is_instance_valid(first) and main.time >= toll_at:
		toll_at = main.time + 0.35
		main.hit_circle(first.position, 200.0, dmg * 0.4, self)
		main.spawn_fx("ring", first.position, 200.0, Color(1.0, 0.82, 0.35))
		main.sfx("bell", 0.6)
	if form == "tibias" and not echoing:
		tib_n += 1
		if tib_n >= 3:
			tib_n = 0
			main.spawn_bolt(position + Vector2(0, -20), aim, dmg * 0.6, 10.0, self, 0, true).pierce = 5
	if lament >= 20.0 and stat("parede") > 0.0:
		var cry := lament * 2.0
		lament = 0.0
		main.hit_arc(position, aim, 320.0, cry, self)
		main.spawn_fx("cry", position + Vector2(0, -20), 320.0, Color.WHITE, aim)  # ondas em píxeis (o golpe "slash" a 320 era um crescente liso maior do que os heróis)
		main.sfx("roar", 1.6)


## Frascos Malditos (#21): o sino do Arauto toca à volta do herói, ou o punho do Carcereiro cai onde ele mira (o
## monstro da mira automática; sem nenhum, 180 px à frente) depois de 0,45 s de aviso no chão.
func _cursed(f: String, dmg: float, aim: Vector2) -> void:
	if f == "maldito_arauto":
		main.sfx("bell")
		main.spawn_fx("ring", position, 220.0, Color(0.4, 1.0, 0.65))
		main.hit_circle(position, 220.0, dmg * 0.6, self)
		main.spawn_ally(main.walk(position, position + Vector2(randf_range(-50.0, 50.0), 30.0)), self)
		return
	var tg = target()
	var at: Vector2 = tg.position if tg != null else position + aim * 180.0
	main.spawn_fx("ring", at, 110.0, Color(0.9, 0.1, 0.08)).dur = 0.45  # o aviso dura até o punho cair
	get_tree().create_timer(0.45, false).timeout.connect(func():
		if not is_inside_tree() or dead:
			return
		main.hit_circle(at, 110.0, dmg * 1.2, self)
		for e in main.enemies():
			if not e.dummy and e.position.distance_to(at) <= 110.0 + e.radius:
				if e.is_boss:  # os chefes só abrandam
					e.slow_t = maxf(e.slow_t, 1.0)
				else:
					e.pin_t = maxf(e.pin_t, 0.6)
		main.spawn_fx("dust", at, 70.0, Color(0.6, 0.55, 0.5))
		main.sfx("hit")
		main.shake = maxf(main.shake, 8.0))


func _aim() -> Vector2:
	var best = target()
	return facing if best == null else position.direction_to(best.position)


## Ataque automático (um polegar): há um inimigo ao alcance do 1.º golpe.
func auto_attack() -> bool:
	if not main.settings.auto_attack:
		return false
	var t = target()
	return t != null and position.distance_to(t.position) < skill_numbers(order[0])[1] + t.radius + 30.0  # a área de agora (frascos)


## O inimigo mais perto ao alcance da mira automática (ou null); com boss_first, um chefe ao alcance ganha.
func target():
	var best = null
	var best_d := 480.0
	for e in main.enemies():
		var d: float = position.distance_to(e.position)
		if boss_first and (e.is_boss or e.elite) and d < 480.0:  # e os elites (#277)
			d -= 1000.0
		if d < best_d:
			best_d = d
			best = e
	return best


## Dança dos Crânios Flamejantes (#167): um crânio por 0,8 s lança-se ao monstro mais perto a 320 px (um Espectro ao
## alcance ganha sempre, como o chefe no boss_first) e volta um a cada 4 s. É o estilhaço teleguiado das Sentinelas, cor de fogo.
func _skulls(delta: float) -> void:
	skull_t = maxf(0.0, skull_t - delta)  # parado no 0: não viaja ao convidado a cada frame
	if skulls < 4:
		skull_regrow -= delta
		if skull_regrow <= 0.0:
			skulls += 1
			skull_regrow = 4.0
	if skulls <= 0 or skull_t > 0.0:
		return
	var best = null
	var best_d := 320.0
	for e in main.enemies():
		var d: float = position.distance_to(e.position)
		if e.kind == "specter" and d < 320.0:  # sem o "< 320" um Espectro a 1100 px ganhava
			d -= 1000.0
		if d < best_d:
			best_d = d
			best = e
	if best == null:
		return
	skulls -= 1
	skull_t = 0.8
	var from := position + Vector2(0, -30)  # do peito, não da roda: na cripta a roda podia estar dentro de uma parede
	var dir := from.direction_to(best.position + Vector2(0, -20))
	var b = main.spawn_bolt(from, dir, 12.0 + 2.0 * main.level, 11.0, self, 0, true)
	b.seek = best
	b.skull = true
	b.tint = Color(1.0, 0.55, 0.2)
	b.quiet = true
	main.spawn_fx("sparks", from, 0.0, b.tint, dir)


## Dança dos Crânios (#167): a opacidade da aura atrás do herói, 0 sem ela. A folha mostra sempre os crânios todos: a
## contagem vê-se na força (crânios / 4, com a opacidade dos efeitos); com efeitos baixos ficam as bolas em órbita.
func skull_aura() -> float:
	if soul != "cranios" or dead or skulls <= 0 or main.effects_level() == 0:
		return 0.0
	return skulls / 4.0 * main.FX_ALPHA[main.settings.fx_alpha]


## Onde anda o crânio i da roda (o desenho e o lançamento usam o mesmo sítio; t viaja ao convidado).
func _skull_at(i: int) -> Vector2:
	return Vector2.from_angle(t * 3.0 + i * TAU / 4.0) * 46.0 + Vector2(0, -30)


## Fome Insaciável da Terra (#137): a cada 2 mortos engolidos ergue um esqueleto teu (com lugar no grupo); sem nenhum de pé, come-te 2% da vida por segundo até metade.
func _fome(delta: float) -> void:
	var all := get_tree().get_nodes_in_group("allies").filter(func(a): return a.life > 0.0)
	var mine := all.filter(func(a): return a.owner_p == self).size()
	if fome_n >= 2 and all.size() < main.MAX_ALLIES:
		fome_n -= 2
		mine += 1
		main.spawn_ally(main.walk(position, position + Vector2(randf_range(-50.0, 50.0), 30.0)), self)
	if mine == 0 and hp > max_hp * 0.5:
		hp = maxf(max_hp * 0.5, hp - max_hp * 0.02 * delta)
		hurt = maxf(hurt, 0.06)  # fica avermelhado enquanto o come (abaixo de 0,1 não muda o desenho)


## Vida paga (Ira, frascos, Sobrecarga): nunca mata; com o Sangue Negro (#117) fica em dívida para voltar.
func pay_life(x: float) -> void:
	var before := hp
	hp = maxf(1.0, hp - x)
	if stat("sangue") > 0.0:
		debt = minf(debt + before - hp, max_hp * 0.5)


## Instabilidade de Alma (#1): junta corrupção; a 100 rebenta na Sobrecarga de Alma.
func add_corruption(x: float) -> void:
	corruption += x
	if corruption >= 100.0:
		corruption = 0.0
		overload_t = OVERLOAD_T
		main.number(position + Vector2(0, -120), tr("Sobrecarga de Alma!"), 20.0, Color(0.75, 0.4, 1.0))
		main.spawn_fx("ring", position, 90.0, Color(0.65, 0.3, 1.0))
		main.vibrate(60, 0.6, self)


## Alma que entra (esferas, Éter, extração, execução); com a Mente Fragmentada (#108) enche a poção de alma (60 = 1 carga).
func add_mana(x: float) -> void:
	if stat("fragmentada") > 0.0:
		potions.mp = minf(POTION_MAX, potions.mp + x / 60.0)
	else:
		mana = minf(max_mana, mana + x)


## shared: a parte da cura que veio da Aliança do outro herói (#68): não volta para trás.
func heal(amount: float, shared := false) -> void:
	if dead:
		return
	if amount > 0.0 and not main.pools.is_empty() and main.pool_at(position, "nevoa"):  # Bispo dos Leprosos (#183): na névoa cáustica nada cura (nem passa pela Aliança)
		return
	var mate = null if shared else wed()
	if mate != null and amount > 0.0:  # Alianças (#68): 25% de cada cura também cura o outro
		mate.heal(amount * 0.25, true)
	if main.sanctum_rule == 1 and amount > 0.0:  # Santuário (#50), Primeira lei: a cura fere (nunca abaixo de 1)
		hp = maxf(1.0, hp - amount)
		hurt = maxf(hurt, 0.1)
		return
	if lich:  # Apoteose do Lich de Ferro (#140): toda a cura vira barreira de ossos (o tecto da Medula, #15)
		if not wears("martir"):  # a Alma Mártir (#151) não deixa nada virar barreira
			barrier = minf(barrier + amount, max_hp * 0.25)
		return
	# Sutura Biológica Instantânea (#138): a cura que passa da vida máxima vira barreira de ossos (o tecto da Medula, #15)
	var over := amount - (max_hp - hp)
	if over > 0.0 and stat("sutura") > 0.0 and not wears("martir"):  # a Alma Mártir (#151) não deixa nada virar barreira
		barrier = minf(barrier + over, max_hp * 0.25)
	heal_acc += minf(amount, max_hp - hp)
	hp = minf(max_hp, hp + amount)
	if furia_until > 0.0 and hp >= max_hp * 0.2:  # Fúria Póstuma (#169): curado até aos 20% (a poção) já não cai, como depois de um abate
		furia_until = 0.0


## Alianças (#68): o outro herói, se os dois tiverem uma aliança posta e ele estiver de pé; senão null.
func wed():
	if stat("alianca") <= 0.0:
		return null
	for q in main.players:
		if q != self and not q.dead and q.stat("alianca") > 0.0:
			return q
	return null


## Em co-op o jogador cai em vez de morrer; um aliado perto dele reanima-o (main._coop).
func revive() -> void:
	dead = false
	revive_t = 0.0
	revived_t = 0.6
	hp = max_hp * 0.5


func take_damage(amount: float, by := "", src = null) -> void:
	if dead:
		return
	if dash_t > 0.0:  # esquiva perfeita: a alma sai do caminho e quem bateu fica exposto
		if src != null and is_instance_valid(src) and src.exposed_t <= 0.0:
			src.exposed_t = src.EXPOSE_T
			main.number(position + Vector2(0, -110), tr("Esquiva perfeita!"), 20.0, Color(0.6, 1.0, 0.9))
			main.hitstop(0.06)
			main.sfx("crit", 1.3)
			main.hud.flash(0.15)
		if stat("falange") > 0.0 and falange_cd <= 0.0 and src != null:  # o ar do Miasma não é golpe
			_falange()
		return
	if furia_until > main.time or safe_until > main.time:  # Fúria Póstuma (#169): nestes 5 s não leva dano; o Elo partido (#232), 1 s
		return
	# Presença Cadavérica Intimidatória (#131): um morto menor a 3 m falha 30% dos golpes (antes do Pacto: falhar não rebenta espinhos)
	if src != null and is_instance_valid(src) and "is_boss" in src and not src.is_boss and stat("presenca") > 0.0 and position.distance_to(src.position) <= 150.0 and main.rng.randf() < 0.3:
		main.number(position + Vector2(0, -110), tr("Falhou!"), 18.0, Color(0.7, 0.7, 0.75))
		return
	if stat("pacto") > 0.0 and src != null:  # Pacto de Carne e Ferro (#101): o golpe inteiro rebenta espinhos de osso à volta e só passa 70% (o ar do Miasma não é golpe)
		main.quiet = true  # os espinhos não param o jogo: numa horda eram uma paragem de impacto a cada golpe levado
		main.hit_circle(position, 100.0, amount * 1.5, self, false, false)  # espinhos de osso: não acendem o piche (#166)
		main.quiet = false
		amount *= 0.7
	killed_by = by
	if armor > 0.0:
		amount *= 0.5
	if lich:  # Lich de Ferro (#140): -20% de dano recebido
		amount *= 0.8
	if stance == "guarda":  # Guarda Sepulcral: aguenta e devolve
		amount *= 0.75
		if src != null and is_instance_valid(src) and src.has_method("apply_rot"):
			src.take_damage(amount * 0.6, true, position.direction_to(src.position))
	amount *= 1.0 - minf(stat("dr"), 0.35)  # Equipamento: a proteção das peças, no máximo 35% (com o Pescoço, G2, passava dos 20% de antes)
	amount *= 1.0 - main.aura_at(position)  # Incensário Fúnebre (#63): o maior do grupo a 350 px (não se somam)
	if stat("ossea") > 0.0:  # Densidade Osteológica (#105): -3% por cada lacaio teu de pé (o tecto de 4 lacaios dá -12%)
		amount *= 1.0 - 0.03 * get_tree().get_nodes_in_group("allies").filter(func(a): return a.owner_p == self and a.life > 0.0).size()
	if stance == "guarda" and stat("parede") > 0.0:  # A Parede dos Lamentos (#238): 40% do que passou fica no lamento (até à vida máxima), para o grito
		lament = minf(lament + amount * 0.4, max_hp)
		amount *= 0.6
	var mate = wed()
	if mate != null:  # Alianças (#68): 40% do que passou das proteções vai para o outro herói, pela vida paga (nunca o mata)
		var share := minf(amount * 0.4, maxf(0.0, mate.hp - 1.0))  # só o que ele pode pagar: com 1 de vida, o resto não desaparecia
		mate.pay_life(share)
		mate.hurt = maxf(mate.hurt, 0.12)
		amount -= share
	# Medula Sacrificial (#15): a barreira de ossos aguenta primeiro; do que passa, uma parte não tira vida e vira barreira
	var soak := minf(barrier, amount)
	barrier -= soak
	if barrier <= 0.0 and soak >= max_hp * 0.1 and stat("ecos") > 0.0:  # Ecos do Último Suspiro (#114): a barreira que quebra (não a que escoa) petrifica os mortos menores à volta
		for e in main.enemies():
			if not e.dummy and e.position.distance_to(position) < 250.0 + e.radius:
				if e.is_boss:
					e.slow_t = maxf(e.slow_t, 1.5)
				else:  # estátua e não quebrado: o quebrado (stagger_t) deixava extrair a Alma Ancestral a qualquer um
					e.statue_t = maxf(e.statue_t, 1.5)
		main.spawn_fx("ring", position, 250.0, Color(0.8, 0.88, 0.96))
		main.shake = maxf(main.shake, 8.0)
	amount -= soak
	if amount <= 0.0:  # a barreira aguentou tudo: número cor de osso, sem dor nem tremor
		main.number(position + Vector2(randf_range(-10, 10), -90), str(roundi(soak)), 15.0, Color(0.8, 0.88, 0.96))
		return
	var keep := 0.0 if wears("martir") else amount * stat("bone_barrier")  # a Alma Mártir (#151) não deixa nada virar barreira
	barrier = minf(barrier + keep, max_hp * 0.25)
	amount -= keep
	if overload_t <= 0.0 and stat("imolacao") > 0.0:  # Imolação Funerária (#127): 40% do golpe arde como corrupção em vez de vida (na Sobrecarga não)
		var burn := amount * 0.4
		amount -= burn
		add_corruption(burn)
		if burn >= 0.5:  # sem "0" nos golpes pequenos que a Guarda ou a barreira já comeram
			main.number(position + Vector2(22, -110), str(roundi(burn)), 14.0, Color(0.75, 0.4, 1.0))
	if hp - amount <= 0.0 and simb_cd <= 0.0 and stat("simb") > 0.0:  # Almas Simbióticas (#121): o teu lacaio mais perto leva o golpe que te matava
		var lacaio = null
		for a in get_tree().get_nodes_in_group("allies"):  # no máximo MAX_ALLIES, e só num golpe letal
			if a.owner_p == self and a.life > 0.0 and (lacaio == null or position.distance_squared_to(a.position) < position.distance_squared_to(lacaio.position)):
				lacaio = a
		if lacaio != null:
			lacaio.life = 0.0  # desfaz-se no frame seguinte: o miasma (ou o Canibalismo) acontece como sempre
			simb_cd = 12.0
			main.number(position + Vector2(randf_range(-10, 10), -90), str(roundi(amount)), 15.0, Color(0.8, 0.88, 0.96))  # cor de osso, como quando a barreira aguenta tudo
			return
	if hp - amount <= 0.0 and wears("furia") and furia_ready <= main.time:  # Fúria Póstuma (#169): o golpe que matava deixa-o a 1 de vida
		hp = 1.0
		furia_until = main.time + 5.0
		furia_ready = main.time + 60.0
		hurt = 0.2
		main.number(position + Vector2(0, -130), tr("Fúria Póstuma!"), 22.0, Color(1.0, 0.25, 0.2))
		main.spawn_fx("ring", position, 90.0, Color(1.0, 0.2, 0.15))
		main.vibrate(120, 1.0, self)
		return
	if hp - amount <= 0.0 and stat("elo") > 0.0:  # Elo da Falange Quebrada (#232): o golpe que matava parte o anel e a vida volta cheia
		var ring: String = gear.get("maos", "")
		gear.erase("maos")  # partido: sai do jogo (pode voltar a cair, _unique_taken já não o vê)
		locks.erase(ring)
		refresh_stats()
		hp = max_hp
		safe_until = main.time + 1.0
		hurt = 0.2
		main.hud.toast(tr("O Elo da Falange Quebrada do %s partiu-se: vida cheia!") % tr(hero_name))
		main.spawn_fx("ring", position, 120.0, Color(1.0, 0.85, 0.4))
		main.sfx("bell")
		main.vibrate(120, 1.0, self)
		return
	if amount >= hp and hp >= max_hp * 0.25 and grace_cd <= 0.0:  # Por um fio: quem estava bem não morre de um golpe só
		grace_cd = 20.0
		amount = hp - 1.0
		main.number(position + Vector2(0, -130), tr("Por um fio!"), 20.0, Color(1.0, 0.9, 0.6))
	hp -= amount
	hurt = 0.2
	chunk_wait = 0.5
	if main.quiet:  # a Chuva de Dentes (#192): lascas pequenas, número cinzento, sem tremor, som nem vibração
		main.number(position + Vector2(randf_range(-10, 10), -90), str(roundi(amount)), 14.0, Color(0.72, 0.72, 0.72))
	else:
		main.number(position + Vector2(randf_range(-10, 10), -90), str(roundi(amount)), 15.0 + clampf(amount / 2.0, 0.0, 16.0), Color(1.0, 0.3, 0.3))
		main.shake = maxf(main.shake, 6.0)
		main.sfx("hurt")
		main.vibrate(60, 0.6, self)
	if soul == "vinganca" and amount > max_hp * 0.2 and vinganca_cd <= 0.0:  # Espectro da Vingança (#143): o golpe grande dispara flechas espectrais a quem bateu e aos mais perto
		vinganca_cd = 1.5
		var quem = src if src != null and is_instance_valid(src) and src.is_in_group("enemies") else null  # quem está a morrer já saiu do grupo
		var alvos: Array = main.enemies().filter(func(e): return e != quem and position.distance_to(e.position) < 400.0)
		alvos.sort_custom(func(x, y): return position.distance_squared_to(x.position) < position.distance_squared_to(y.position))
		if quem != null:
			alvos.push_front(quem)  # quem bateu vai sempre, mesmo longe (o estilhaço voa ~700 px)
		var from := position + Vector2(0, -30)
		for e in alvos.slice(0, 5):  # quem bateu e até 4 à volta
			var dir := from.direction_to(e.position + Vector2(0, -20))
			var b = main.spawn_bolt(from, dir, 14.0 + 2.0 * main.level, 10.0, self, 0, true)
			b.seek = e
			b.tint = Color(0.7, 0.5, 1.0)
			b.quiet = true
			main.spawn_fx("sparks", from, 0.0, b.tint, dir)
	if hp <= 0.0:
		_fall()


## Falange Espectral (#152): a esquiva perfeita ergue escudos espectrais; os monstros a 160 px voam para trás (os chefes
## menos; o Arauto nem se mexe) e ficam 0,8 s sem atacar.
func _falange() -> void:
	falange_cd = 1.0
	var cyan := Color(0.5, 1.0, 1.0)
	for e in main.enemies():
		if e.kind != "herald" and not e.dummy and not e.anchor and e.position.distance_to(position) < 160.0 + e.radius:
			e.knock = position.direction_to(e.position) * (700.0 if e.is_boss else 900.0)
			e.blind_t = maxf(e.blind_t, 0.8)
	main.spawn_fx("ring", position, 160.0, cyan)
	for i in 6:
		main.spawn_fx("glow", position + Vector2.from_angle(TAU * i / 6.0) * 120.0 + Vector2(0, -30), 40.0, cyan)
	main.sfx("swing_heavy")


## Morte certa (a guilhotina do Carrasco Sem Rosto, #44): só a esquiva safa; nem o "Por um fio" nem as Almas Simbióticas.
func slay(by: String) -> void:
	if dead or dash_t > 0.0:
		return
	killed_by = by
	_fall()


## A vida chegou a zero (um golpe, ou a Fúria Póstuma que acabou sem um abate): o herói cai.
func _fall() -> void:
	hp = 0.0
	barrier = 0.0
	corruption = 0.0  # quem cai não volta a meio de uma Sobrecarga
	overload_t = 0.0
	self_bleed_t = 0.0
	debt = 0.0  # Sangue Negro (#117): a dívida perde-se ao cair
	lich = false  # quem cai não fica a flutuar
	fome_n = 0  # a terra não guarda os mortos de quem caiu
	canibal_n = 0
	furia_until = 0.0
	march = 0.0  # a Marcha (#228) recomeça do zero ao voltar
	dead = true
	queue_redraw()
	died.emit()


## O desenho 32-bit deste momento (8 por movimento).
func _frame32() -> int:
	var w := hero == "warden"  # o Guardião cai deitado (26-27); o Strider ajoelha (27-28)
	if dead:  # com um aliado perto, a chama cresce
		return (26 if w else 27) if revive_t <= 0.0 else (27 if w else 28) + mini(1, int(revive_t / main.REVIVE_T * 2.0))
	if revived_t > 0.0:
		return (29 if w else 30) if revived_t > 0.3 else (30 if w else 31)
	if dash_t > 0.0:
		return 49 + mini(5, int((1.0 - dash_t / DASH_T) * 6.0))
	for a in [[cast_t, CAST_T, 32], [nova_t, NOVA_T, 40], [spin, SPIN_T, 32], [guard_t, GUARD_T, 40], [swing, swing_len, 8]]:
		if a[0] > 0.0:
			return a[2] + mini(7, int((1.0 - a[0] / a[1]) * 8.0))
	if hurt > 0.1:
		return 24 if hurt > 0.15 or w else 25
	return int(walk_t * 16.0) % 8 if walk_t > 0.0 else 16 + int(t * 8.0) % 8


func _draw() -> void:
	body.queue_redraw()  # o herói desenha-se por cima do anel, no nó body
	trail.queue_redraw()
	halo.queue_redraw()
	# Um só selo aos pés: o anel tem a cor de quem é e os estados ficam nele (a Ira enche o miolo de sangue, a pulsar)
	var lvl: int = main.effects_level()
	var at := Vector2(0, -8)
	var ira := stance == "ira" and not dead
	if dead:
		Pix.sigil(self, at, "ash", false, t, 0)
		if revive_t > 0.0:  # o círculo de reanimar: chamas de alma à volta do selo
			var fl := Pix.flame_tex("soul", int(t * 10.0) % 4, 0.55)
			for i in 8:
				Pix.stand(self, fl, at + Vector2.from_angle(i * TAU / 8.0 + 0.39) * Vector2(44.0, 19.0))
		return
	Pix.sigil(self, at, SIGIL[slot], ira and sin(t * 8.0) > 0.0, t, lvl, ira)
	if lich:  # Lich de Ferro (#140): a sombra no chão, debaixo de quem flutua
		Pix.haze(self, at, 30.0, 12.0, Color.BLACK, 0.65)
	if root_until > main.time:  # preso pela corrente do Carrasco (#44): uma argola de ferro aos pés
		Pix.band(self, at, 34.0, 15.0, "iron", 2.0)
	if debt > 0.0:  # Sangue Negro (#117): o anel do selo enche-se de sangue escuro, do tamanho da dívida
		Pix.arc(self, at, 43.0, 19.0, 0.0, debt / (max_hp * 0.5), Pix.RAMPS.bleed[1], 2)
	if march >= 20.0 and walk_t > 0.0:  # Passos da Marcha Fúnebre (#228): a marcha forte larga dois pontos de cinza a cada passo, atrás dos pés
		var step := int(walk_t * 8.0) % 2
		for i in 2:
			Pix.dot(self, Vector2((-1.0 if facing.x > 0.0 else 1.0) * (16.0 + 10.0 * i), -6.0 + 6.0 * ((i + step) % 2)), Pix.RAMPS.ash[2 + i], 2)
	if stat("parede") > 0.0:  # A Parede dos Lamentos (#238): seis marcas por baixo dos pés, cheias pelo lamento; com 20 ou mais o grito sai no golpe seguinte
		for i in 6:
			var q := Vector2(-25.0 + 10.0 * i, 14.0)
			if lament >= max_hp * (i + 0.5) / 6.0 or (i == 0 and lament >= 20.0):
				Pix.orb(self, q, 2, "soulblue")
			else:
				Pix.dot(self, q, Pix.RAMPS.soulblue[6], 2)
	if stat("fome") > 0.0:  # Fome Insaciável (#137): seis marcas à frente dos pés, cheias tantas quantos os mortos engolidos
		for i in 6:
			var q := Vector2.from_angle(deg_to_rad(30.0 + 24.0 * i)) * Vector2(56.0, 24.0) + Vector2(0, -10)
			if i < fome_n:
				Pix.orb(self, q, 2, "bone")
			else:
				Pix.dot(self, q, Pix.RAMPS.bone[5], 2)
	# Linha guia: pontos até ao inimigo que a mira automática escolheu
	var tg = target()
	if tg != null:
		var to: Vector2 = tg.position - position
		for i in range(1, int(to.length() / 26.0)):
			Pix.dot(self, Vector2(0, -12) + to.normalized() * i * 26.0, Color(tint, 0.55), 2)
	# Recarga: no anel do selo, uma fatia por habilidade longa, que enche; quando fica pronta, abre-se num brilho. Com dívida,
	# fica só com a fila de fora e o sangue vê-se na de dentro
	var longs := 0
	for id in order:
		if skills[id].cd >= RING_CD:
			longs += 1
	var n := 0
	for id in order:
		if skills[id].cd < RING_CD:
			continue
		var f0 := float(n) / longs
		var span := 1.0 / longs - 0.03
		n += 1
		var left: float = cds[id] / skills[id].cd
		if left > 0.0:
			Pix.arc(self, at, 43.0, 19.0, f0, f0 + span * (1.0 - minf(left, 1.0)), Pix.RAMPS.soulblue[3], 1 if debt > 0.0 else 2)
		elif ready_t.get(id, 0.0) > 0.0:
			var k: float = ready_t[id] / READY_T
			Pix.arc(self, at, 43.0 + (1.0 - k) * 16.0, 19.0 + (1.0 - k) * 7.0, f0, f0 + span, Color.WHITE if k > 0.5 else Pix.RAMPS.soulblue[1], 2)


## Dança dos Crânios (#167): a aura do pixelfx atrás do herói, nos píxeis do mundo; com menos crânios desfaz-se em pontilhado.
func _draw_halo() -> void:
	var aura := skull_aura()
	if aura > 0.0:
		Pix.sheet_draw(halo, "skulls", Pix.sheet_frame("skulls", t), position.snapped(Vector2(Pix.S, Pix.S)) - position, 1.0, 1.0, Color(1, 1, 1, aura))


## Rasto da esquiva: fantasmas largados pelo caminho (~44 px), cada um 0,4 s, a escurecer na rampa e a desfazer-se em
## pontilhado (ghost.gdshader). Vem do dash_cd (o tempo desde o salto): o convidado vê o mesmo.
func _draw_trail() -> void:
	var el := DASH_CD - dash_cd
	if ghost_tex == null or dead or el >= DASH_T + 0.4:
		return
	var C: Array = Pix.ramp("bleed" if stance == "ira" else "iron" if lich else "soul")
	for tc in [0.0, 0.1] if main.effects_level() == 0 else [0.0, 0.06, 0.1, 0.14]:
		var k: float = (el - tc) / 0.4
		if k < 0.0 or k >= 1.0:
			continue
		var i := mini(C.size() - 3, 1 + int(k * (C.size() - 3)))
		trail.draw_set_transform_matrix(Transform2D(0.0, -dash_dir * DASH_SPEED * (minf(el, DASH_T) - tc)) * ghost_pose)
		trail.draw_texture(ghost_tex, Vector2.ZERO, Color(C[i + 1], 1.0 if k < 0.45 else (1.0 - k) / 0.55))
	trail.draw_set_transform(Vector2.ZERO)


func _draw_body() -> void:
	var col := Color(1.0, 0.4, 0.4) if hurt > 0.0 else Color.WHITE
	if dead:
		col = Color(0.8, 0.8, 0.8, 0.95)
	if lich:  # Lich de Ferro (#140): cor de ferro frio
		col *= Color(0.72, 0.78, 0.92)
	if furia_until > main.time:  # Fúria Póstuma (#169): o corpo pulsa a vermelho
		col = col.lerp(Color(1.0, 0.15, 0.1), 0.35 + 0.3 * sin(t * 14.0))
	# Os desenhos olham para a direita: espelha quando olha para a esquerda (flip_s, a virar suave).
	var f32 := _frame32()
	var tex: Texture2D = FRAMES32[hero][f32]
	var sc: float = Feet32.SCALE[SHEET32[hero]]
	var feet: float = Feet32.FEET[SHEET32[hero]][f32]
	var mirror := flip_s
	# Antecipação e continuação: ao atacar recua, passa um pouco à frente e assenta
	var k := exp(-lean_t * 8.0) * cos(lean_t * 22.0)
	# Fluidez: um salto a cada passo, inclinado para onde anda, e a respirar quando está parado
	var bob := 0.0 if dead else -absf(sin(walk_t * TAU * 2.0)) * 4.0
	if lich:  # flutua (a pose da silhueta também)
		bob -= 12.0 + 3.0 * sin(t * 4.0)
	var breath := sin(t * 2.4) * 0.015 if walk_t == 0.0 and not dead else 0.0
	# A pose fica guardada para a silhueta atrás das paredes (#92); é o mesmo que draw_set_transform(posição, rotação, escala)
	pose_tex = tex
	# Transform2D(rotação, escala, inclinação, posição): escala local, como o draw_set_transform (o .scaled() escalaria no global e a inclinação ia ao contrário)
	# Esquiva: estica-se na direção do salto e encolhe no outro eixo (vem do dash_t: o convidado vê o mesmo)
	var sq := 1.0 + 0.25 * clampf(dash_t / DASH_T, 0.0, 1.0)
	var squash := Vector2(sq, 1.0 / sq) if absf(dash_dir.x) >= absf(dash_dir.y) else Vector2(1.0 / sq, sq)
	pose = Transform2D(0.0 if dead else tilt, Vector2(sc * mirror * (1.0 - 0.05 * k - breath * 0.5), sc * (1.0 + 0.05 * k + breath)) * squash, 0.0, lean_dir * -9.0 * k + Vector2(0, bob)).translated_local(Vector2(-tex.get_width() / 2.0, -tex.get_height() + feet))
	if dash_t > 0.0:
		ghost_tex = tex
		ghost_pose = pose
	body.draw_set_transform_matrix(pose)
	body.draw_texture(tex, Vector2.ZERO, col)
	body.draw_set_transform(Vector2.ZERO)
	if armor > 0.0:
		Pix.band(body, Vector2(0, -42), 40.0, 40.0, "bone", 1.0, 8, 2 if sin(t * 10.0) > 0.0 else 3)
	if iron_t > 0.0:  # Donzela de Ferro Móvel (#174): a couraça de aço à volta do herói
		Pix.band(body, Vector2(0, -42), 46.0, 46.0, "iron", 2.0, 4)
	if overload_t > 0.0 and stat("imolacao") > 0.0:  # Imolação Funerária (#127): na Sobrecarga o herói arde
		Pix.band(body, Vector2(0, -42), 44.0 if sin(t * 18.0) > 0.0 else 42.0, 44.0 if sin(t * 18.0) > 0.0 else 42.0, "loot_ash", 1.0, 6)
	if lich:  # Lich de Ferro (#140): três lascas de osso em órbita
		for i in 3:
			Pix.orb(body, Vector2.from_angle(t * 1.5 + i * TAU / 3.0) * 40.0 + Vector2(0, -50), 2, "bone")
	if soul == "cranios" and not dead and main.effects_level() == 0:  # com efeitos baixos, os crânios em órbita por cima do herói (os outros veem a aura)
		for i in skulls:
			Pix.orb(body, _skull_at(i), 3, "loot_ash")
	if dead and revive_t > 0.0:
		Pix.arc(body, Vector2(0, -40), 22.0, 22.0, 0.0, revive_t / main.REVIVE_T, Pix.RAMPS.soul[2], 2)
