extends Node2D
## Esquiva Espectral: o herói vira fumo de cinzas e fica para trás um clone de osso que atrai os monstros
## por um bocado (main.lure). Aguenta os golpes todos e desfaz-se sozinho.

const Player := preload("res://player.gd")
const LIFE := 1.6

var main
var hero := "strider"
var frame := 0  # o desenho em que o herói estava quando esquivou
var frame32 := -1  # o mesmo, em 32-bit (-1 = pintado)
var flip := 1.0
var t := 0.0
var dead := false  # os monstros tratam-no como um herói


func _ready() -> void:
	add_to_group("decoys")


func _process(delta: float) -> void:
	t += delta
	queue_redraw()
	if t >= LIFE:
		queue_free()


func take_damage(_amount: float, _by := "", _src = null) -> void:
	pass  # é osso e cinza


func _draw() -> void:
	var tex: Texture2D = Player.FRAMES[hero][frame]
	var sc: float = Player.HEROES[hero].scale
	var feet: float = Player.Feet.FEET[Player.SHEET[hero]][frame]
	var fl := flip * (-1.0 if frame32 < 0 and Player.faces_left(hero, frame) else 1.0)
	if frame32 >= 0:
		tex = Player.FRAMES32[hero][frame32]
		sc = Player.Feet32.SCALE[Player.SHEET32[hero]]
		feet = Player.Feet32.FEET[Player.SHEET32[hero]][frame32]
	var a := 0.75 * (1.0 - t / LIFE)
	draw_set_transform(Vector2.ZERO, 0.0, Vector2(sc * fl, sc))
	draw_texture(tex, Vector2(-tex.get_width() / 2.0, -tex.get_height() + feet), Color(0.82, 0.8, 0.72, a))
	draw_set_transform(Vector2.ZERO)
