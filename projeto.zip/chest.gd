extends Node2D
## Relicário selado: aparece no monumento quando o Cortejo é quebrado e guarda o tesouro final.
## Abrir tem 7 tempos: abanar e esmagar, esticar, abrir com estrondo (congela e treme),
## luz de dentro com raios a rodar, onda de choque, estrelas e pó mágico.

const CLOSED := preload("res://art/props/chest.png")
const OPEN := preload("res://art/props/chest_open.png")
const Pix := preload("res://fx_pix.gd")
const WIDTH := 110.0
const SLAM_AT := 0.65

var main
var rewards := []  # [tipo, quantidade]
var opening := -1.0  # -1 = fechado; depois, segundos desde que começou a abrir
var opened := false
var locked := false  # S9: o relicário do Meteoro Funerário (#218) fica selado até caírem os elites da cratera (viaja ao convidado)
var t := 0.0
var stars := []  # [posição, velocidade, idade]
var dust := []


func _process(delta: float) -> void:
	t += delta
	if opening >= 0.0:
		var before := opening
		opening += delta
		if before < SLAM_AT and opening >= SLAM_AT:
			_slam()
	for s in stars:
		s[0] += s[1] * delta
		s[1].y += 420.0 * delta
		s[2] += delta
	stars = stars.filter(func(s): return s[2] < 1.2)
	for d in dust:
		d[0] += d[1] * delta
		d[2] += delta
	dust = dust.filter(func(d): return d[2] < 3.5)
	if opened and opening < 6.0 and randf() < delta * 12.0:
		dust.append([Vector2(randf_range(-40, 40), randf_range(-70, -30)), Vector2(randf_range(-12, 12), randf_range(-45, -15)), 0.0])
	queue_redraw()


func open() -> void:
	if locked:
		main.hud.toast("Selado: mata os elites.")
		return
	if opening < 0.0:
		opening = 0.0
		main.sfx("creak")
		main.vibrate(30, 0.5)


func _slam() -> void:
	opened = true
	main.hitstop(0.12)
	main.shake = 14.0
	main.vibrate(60, 1.0)
	main.sfx("chest")
	main.spawn_fx("ring", position + Vector2(0, -30), 260.0, Color(1.0, 0.85, 0.4))
	main.spawn_fx("glow", position + Vector2(0, -45), 130.0, Color(1.0, 0.8, 0.4))
	for i in 10:
		stars.append([Vector2(0, -50), Vector2.from_angle(-PI / 2.0 + randf_range(-1.1, 1.1)) * randf_range(260.0, 430.0), 0.0])
	for r in rewards:
		main.drop(r[0], position + Vector2(0, 20), r[1], Vector2.from_angle(randf_range(0.3, PI - 0.3)) * randf_range(140.0, 240.0))


func _draw() -> void:
	var sq := Vector2.ONE
	var rot := 0.0
	if opening >= 0.0 and opening < 0.5:  # abanar e esmagar: a antecipação
		var k := opening / 0.5
		rot = sin(opening * 45.0) * 0.09 * k
		sq = Vector2(1.0 + 0.12 * k, 1.0 - 0.14 * k)
	elif opening >= 0.5 and opening < SLAM_AT:  # esticar antes de rebentar
		sq = Vector2(0.88, 1.2)
	elif opening >= SLAM_AT and opening < SLAM_AT + 0.2:  # assentar
		var k := (opening - SLAM_AT) / 0.2
		sq = Vector2(1.1 - 0.1 * k, 0.92 + 0.08 * k)
	var tex: Texture2D = OPEN if opened else CLOSED
	var h := WIDTH * tex.get_height() / tex.get_width()
	var light := clampf(1.0 - (opening - SLAM_AT) / 5.0, 0.0, 1.0) if opened else 0.0
	if light > 0.0:  # raios de luz a rodar devagar, por trás do baú
		var o := Vector2(0, -h * 0.55)
		for i in 8:
			var a := Vector2.from_angle(t * 0.6 + i * TAU / 8.0)
			for j in range(3, 26):  # um raio são pontos na grelha: cada vez mais espaçados e só onde o Bayer deixa
				if Pix.bayer(j, i) < light * (1.0 - j / 26.0) * 1.6:
					Pix.dot(self, o + a * j * 7.0, Color(1.0, 0.85, 0.45))
	draw_set_transform(Vector2.ZERO, rot, sq)
	draw_texture_rect(tex, Rect2(-WIDTH / 2.0, -h, WIDTH, h), false)
	draw_set_transform(Vector2.ZERO)
	if locked:  # selado (#218, Cofre de Sangue): um cadeado de ferro em células de 2 px e um brilho vermelho a pulsar
		Pix.haze(self, Vector2(0, -h * 0.5), 34.0, 34.0, Color(0.9, 0.15, 0.1), 0.45 + 0.25 * sin(t * 4.0))
		var c := Vector2(0, -h * 0.4).snapped(Vector2(2, 2))
		var dark := Color(0.07, 0.06, 0.08)
		var iron := Color(0.4, 0.38, 0.42)
		for r in [[-12, -26, 24, 18, dark], [-8, -22, 16, 14, iron], [-4, -18, 8, 10, dark], [-16, -10, 32, 26, dark], [-14, -8, 28, 22, iron], [-14, -8, 28, 4, Color(0.62, 0.6, 0.64)], [-14, 10, 28, 4, Color(0.25, 0.23, 0.27)], [-4, -2, 8, 10, dark], [-2, 0, 4, 6, Color(0.95, 0.2, 0.12)]]:  # asa, corpo e fechadura
			draw_rect(Rect2(c + Vector2(r[0], r[1]), Vector2(r[2], r[3])), r[4])
	if opening >= 0.0 and not opened and main.effects_level() > 0:  # luz a escapar pelas frinchas antes de abrir
		Pix.haze(self, Vector2(0, -h * 0.55), 26.0, 26.0, Color(1.0, 0.85, 0.4), 0.8 * minf(opening / 0.5, 1.0))
	if light > 0.0:
		Pix.haze(self, Vector2(0, -h * 0.55), 26.0 + sin(t * 4.0) * 3.0, 26.0 + sin(t * 4.0) * 3.0, Color(1.0, 0.85, 0.4), 0.7 * light)
	for s in stars:
		Pix.sparkle(self, s[0], roundi(6.0 * (1.0 - s[2] / 1.2)) + 1, Pix.RAMPS.gold[1], Pix.RAMPS.gold[3])
	for d in dust:
		if Pix.bayer(int(d[0].x), int(d[0].y)) < 1.2 * (1.0 - d[2] / 3.5):  # desfaz-se ao pontilhado
			Pix.dot(self, d[0], Pix.RAMPS.gold[1])
