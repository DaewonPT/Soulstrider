shader_type canvas_item;
// Crescentes e ondas em píxeis (fx.gd): os três crescentes da Foice do Vazio (#106) e as três ondas do grito (o Canto da
// Decomposição, #109, e a Parede dos Lamentos, #238). Células de 2 px na grelha do mundo, a cor aos degraus da rampa e as
// bordas ao pontilhado de Bayer 4x4, como o resto dos efeitos (fx_pix.gd); sem brilho nem transparência suave. Um só
// retângulo por efeito: a forma sai do tempo, com os números de sempre (os mesmos nos dois telemóveis).

const float BAYER[16] = {0.0, 8.0, 2.0, 10.0, 12.0, 4.0, 14.0, 6.0, 3.0, 11.0, 1.0, 9.0, 15.0, 7.0, 13.0, 5.0};
const float WAVE_HALF = 1.131;  // meia abertura das ondas (0,18 da volta)

uniform int mode = 0;  // 0: os três crescentes da Foice do Vazio; 1: as três ondas do grito
uniform vec4 ramp[8];  // a rampa (Pix.RAMPS), do claro para o escuro
uniform int n = 8;  // quantas cores tem a rampa (6 ou 8)
uniform vec2 org;  // a célula do nó na grelha do mundo: o pontilhado bate com o dos outros efeitos
uniform float ang;  // para onde aponta (a mira)
uniform float r;  // o raio: a área do golpe, ou o alcance do grito
uniform float w;  // crescentes: a largura de agora
uniform float ta;  // crescentes: onde começa a parte à vista (radianos) e quanto mede
uniform float tl = 1.0;
uniform float age;  // crescentes: 0 a 1 ao longo do golpe; ondas: t / dur

varying vec2 lp;
varying vec4 tint;

void vertex() {
	lp = VERTEX;
	tint = COLOR;
}

float bayer(vec2 cell) {
	ivec2 g = ivec2(mod(cell + org, 4.0));
	return (BAYER[g.y * 4 + g.x] + 0.5) / 16.0;
}

vec4 tone(int i) {
	return ramp[clamp(i, 0, n - 1)];
}

void fragment() {
	vec2 cell = floor(lp / 2.0);
	vec2 c = (cell + 0.5) * 2.0;
	float th = bayer(cell);
	vec4 col = vec4(0.0);
	if (mode == 0) {
		// a 120° uns dos outros (-1,2, 0, +1,2 rad da mira), cada um numa elipse achatada a 0,6 no sentido da mira
		for (int b = 0; b < 3; b++) {
			float a0 = ang + float(b - 1) * 1.2;
			vec2 q = vec2(cos(a0) * c.x + sin(a0) * c.y, (-sin(a0) * c.x + cos(a0) * c.y) / 0.6);
			float v = (atan(q.y, q.x) - ta) / tl;
			if (v < 0.0 || v > 1.0) {
				continue;
			}
			float w1 = w * pow(max(0.0, sin(PI * pow(v, 2.2))), 0.6);
			float d = (r - length(q)) / max(w1, 0.001);  // 0 no gume, 1 por dentro
			if (w1 < 2.0 || d < 0.0 || d > 1.0) {
				continue;
			}
			// a ponta de trás e o lado de dentro ao pontilhado; no fim desfaz-se aos pontos
			float dens = clamp(v / 0.35, 0.0, 1.0) * (d > 0.7 ? 1.0 - (d - 0.7) / 0.3 * 0.75 : 1.0) * (1.0 - smoothstep(0.5, 1.0, age));
			if (th >= dens) {
				continue;
			}
			// o gume: 2 células cor de osso enquanto a lâmina está acesa; para dentro, os degraus da rampa (sem os 2 quase negros:
			// a desfazer-se, ficavam pontos pretos)
			col = r - length(q) < 4.0 && age < 0.5 ? vec4(0.957, 0.933, 0.863, 1.0) : tone(min(int(round(d * float(n - 1) * 0.75 + age * 2.4 - v * 0.8 + 0.4)), n - 3));
		}
	} else {
		// elipses do chão (achatadas a 0,6 no ecrã); a espessura conta-se em células, igual em x e em y
		float rel = mod(atan(c.y / 0.6, c.x) - ang + PI, 2.0 * PI) - PI;
		if (abs(rel) <= WAVE_HALF) {
			for (int i = 0; i < 3; i++) {
				float u = clamp(age * 1.5 - float(i) * 0.22, 0.0, 1.0);
				if (u <= 0.0 || u >= 1.0) {
					continue;
				}
				float rr = r * (0.25 + 0.75 * (1.0 - pow(1.0 - u, 3.0)));
				vec2 ab = vec2(rr, rr * 0.6);
				float f = length(c / ab);
				float gm = length(c / (ab * ab)) / max(f, 0.0001);
				float dc = (1.0 - f) / max(gm, 0.0001) / 2.0;  // células para dentro da borda da frente
				float thick = u < 0.5 ? 6.0 : u < 0.8 ? 4.0 : 3.0;
				if (dc < -1.0 || dc >= thick) {
					continue;
				}
				// a borda escura por fora, 1 célula clara à frente, os tons a escurecer para dentro e o rasto ao pontilhado
				float e = 1.0 - abs(rel) / WAVE_HALF;
				float wake = dc < 2.0 ? 1.0 : 0.8 * (thick - dc) / (thick - 2.0);
				float dens = smoothstep(0.0, 0.3, e) * (1.0 - smoothstep(0.6, 1.0, u)) * wake;
				if (th >= dens) {
					continue;
				}
				int shift = int(u * 2.5);
				col = dc < 0.0 ? tone(6) : dc < 1.0 ? tone(1 + shift) : tone(2 + shift + int(dc * 0.6));
			}
		}
	}
	if (col.a <= 0.0) {
		discard;
	}
	COLOR = vec4(col.rgb, tint.a);
}
