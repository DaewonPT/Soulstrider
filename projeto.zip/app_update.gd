extends Node
## Atualização da app (APK) sem ir ao GitHub, como no Zero-Sum: ao abrir, pergunta à API do GitHub qual é
## a última Release do repositório público DaewonPT/Soulstrider (o Actions publica uma a cada build, com
## "code=<versionCode>" no texto e o Soulstrider_vX.Y.Z.apk em anexo). Se for mais nova do que esta app, o
## ecrã de título mostra "Nova versão — atualizar": abre o APK no navegador, que o descarrega, e o Android
## pede para instalar por cima (mesma assinatura: o progresso fica). Fora da Play Store há sempre um toque.

signal update_available(info: Dictionary)

const VERSION_CODE := 14  # igual ao version/code do export_presets.cfg (o teste confirma)
const VERSION_NAME := "0.4.1"
const LATEST_URL := "https://api.github.com/repos/DaewonPT/Soulstrider/releases/latest"
const APK_PREFIX := "https://github.com/DaewonPT/Soulstrider/releases/download/"

var info := {}  # {"code", "name", "apk", "notes"} quando há uma versão mais nova
var checked := false


## Uma verificação por arranque (silenciosa: sem rede ou sem resposta, não acontece nada).
func check() -> void:
	if checked or OS.has_feature("editor"):
		return
	checked = true
	var req := HTTPRequest.new()
	req.timeout = 10.0
	add_child(req)
	if req.request(LATEST_URL, ["User-Agent: Soulstrider", "Accept: application/vnd.github+json"]) != OK:
		req.queue_free()
		return
	var result: Array = await req.request_completed
	req.queue_free()
	if int(result[0]) != HTTPRequest.RESULT_SUCCESS or int(result[1]) != 200:
		return
	var parsed = JSON.parse_string((result[3] as PackedByteArray).get_string_from_utf8())
	if not (parsed is Dictionary):
		return
	var found := parse_release(parsed)
	if found.is_empty() or int(found["code"]) <= VERSION_CODE:
		return
	info = found
	update_available.emit(info)


## Lê a resposta de /releases/latest: versionCode (linha "code=N" no texto), nome, link do APK e as notas.
## Só aceita APKs deste repositório. Vazio se faltar alguma coisa.
static func parse_release(d: Dictionary) -> Dictionary:
	var body := String(d.get("body", "")) if d.get("body") is String else ""
	var m := RegEx.create_from_string("code=(\\d+)").search(body)
	if m == null:
		return {}
	var apk := ""
	for a in d.get("assets", []):
		if a is Dictionary and String(a.get("name", "")).ends_with(".apk"):
			apk = String(a.get("browser_download_url", ""))
	if not apk.begins_with(APK_PREFIX):
		return {}
	var notes: Array[String] = []
	for line in body.split("\n"):
		var l := line.strip_edges()
		if l != "" and not l.begins_with("code="):
			notes.append(l)
	var name := String(d.get("name", "")) if d.get("name") is String else ""
	if name == "":
		name = String(d.get("tag_name", ""))
	return {"code": int(m.get_string(1)), "name": name, "apk": apk, "notes": "\n".join(PackedStringArray(notes))}


## Nome do ficheiro que o navegador grava: o do anexo da Release (Soulstrider_v0.2.0.apk, por exemplo).
static func file_name_of(apk_url: String) -> String:
	var file := apk_url.get_file().uri_decode()
	return file if file.ends_with(".apk") else "Soulstrider.apk"


## Abre o APK no navegador (descarrega; ao abrir o ficheiro o Android pergunta se instala).
func open_download() -> void:
	if info.is_empty() or not String(info.get("apk", "")).begins_with(APK_PREFIX):
		return
	OS.shell_open(String(info["apk"]))
