shader_type canvas_item;
// Catacumbas Cegas (#26): o escuro da cripta, por cima das personagens e debaixo dos efeitos. Cada luz é vec3(x, y, raio)
// no mundo (main.lights: a tocha de cada herói, as lâmpadas, a saída, os abrigos). O último quarto de cada raio é um
// pontilhado de Bayer em células de 2 px, como o nevoeiro, com uma orla verde ténue por fora. Um só quadro do tamanho da vista.

uniform vec3 lights[16];
uniform int count = 0;
uniform vec3 shade : source_color = vec3(0.01, 0.015, 0.012);
uniform vec3 rim : source_color = vec3(0.3, 1.0, 0.6);

const float BAYER[16] = {0.0, 8.0, 2.0, 10.0, 12.0, 4.0, 14.0, 6.0, 3.0, 11.0, 1.0, 9.0, 15.0, 7.0, 13.0, 5.0};

varying vec2 world;

void vertex() {
	world = VERTEX;  // o nó está na origem: VERTEX já é o mundo
}

void fragment() {
	float d = 9.0;  // a distância à luz mais perto, em raios dela
	for (int i = 0; i < 16; i++) {
		if (i >= count) {
			break;
		}
		d = min(d, distance(world, lights[i].xy) / lights[i].z);
	}
	ivec2 g = ivec2(mod(floor(world / 2.0), 4.0));
	float b = (BAYER[g.y * 4 + g.x] + 0.5) / 16.0;
	if (clamp((d - 0.75) / 0.25, 0.0, 1.0) < b) {
		COLOR = vec4(0.0);  // à luz; na orla, cada vez menos células acesas
	} else {
		COLOR = vec4(mix(shade, rim, 0.12 * (1.0 - smoothstep(1.0, 1.15, d))), 0.95);
	}
}
