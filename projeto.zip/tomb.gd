extends Node2D
## O túmulo do herói: ao morrer, metade dos recursos fica aqui. Quem lá chegar recupera-os;
## quem morrer outra vez antes disso perde-os (main.die).

const TEX := preload("res://art/props/grave_broken.png")
const BEAM := preload("res://art/fx/beam_unique.png")
const Gothic := preload("res://gothic.gd")

var main
var t := 0.0


func _ready() -> void:
	var l := Label.new()
	l.text = "O teu túmulo"
	l.add_theme_font_override("font", Gothic.FONT)
	l.add_theme_font_size_override("font_size", 22)
	l.add_theme_color_override("font_color", Color(0.55, 1.0, 0.7))
	l.add_theme_color_override("font_outline_color", Color.BLACK)
	l.add_theme_constant_override("outline_size", 6)
	l.position = Vector2(-80, -126)
	l.size = Vector2(160, 26)
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	add_child(l)


func _process(delta: float) -> void:
	t += delta
	queue_redraw()
	var p = main.nearest_player(position)
	if p != null and position.distance_to(p.position) < 60.0:
		main.recover_tomb()


func _draw() -> void:
	var h := 150.0 + sin(t * 3.0) * 8.0
	var w := h * BEAM.get_width() / BEAM.get_height()
	draw_texture_rect(BEAM, Rect2(-w / 2.0, -h + 6.0, w, h), false, Color(1, 1, 1, 0.6))
	for i in 4:
		draw_circle(Vector2.ZERO, 46.0 * (1.0 - i * 0.2), Color(0.35, 1.0, 0.6, 0.06))
	var gh := 84.0
	var gw := gh * TEX.get_width() / TEX.get_height()
	draw_texture_rect(TEX, Rect2(-gw / 2.0, -gh, gw, gh), false, Color(0.75, 0.95, 0.85))
