extends CanvasLayer
## HUD gótico (arte das folhas SC-UI1/SC-UI2) + controlos de telemóvel: ecrã tátil (joystick flutuante,
## botões escaláveis) ou comando, com os botões A/B/X/Y desenhados no ecrã
## + painéis: título, Arsenal, Árvore dos Condenados, Cortejo e morte (no comando: A escolhe, B volta).
## Também os momentos grandes: barra e cartão do chefe, subida de nível e flash do crítico.

const JOY_R := 80.0
const SCALES := [1.0, 1.3, 1.6]
const CARD_T := 3.2
const LVL_T := 2.4
const UI := {
	"holder": preload("res://art/ui/orb_holder.png"),
	"red": preload("res://art/ui/orb_red.png"),
	"soul": preload("res://art/ui/orb_soul.png"),
	"ring": preload("res://art/ui/ring_small.png"),
	"joy": preload("res://art/ui/joy_base.png"),
	"knob": preload("res://art/ui/joy_knob.png"),
	"bar": preload("res://art/ui/bar.png"),
	"panel": preload("res://art/ui/panel.png"),
	"btn": preload("res://art/ui/btn_s.png"),
	"btn_on": preload("res://art/ui/btn_on_s.png"),
}
const ICONS := {
	"scythe": preload("res://art/icons/sk_scythe.png"),
	"bolt": preload("res://art/icons/sk_bolt.png"),
	"nova": preload("res://art/icons/sk_nova.png"),
	"chop": preload("res://art/icons/sk_chop.png"),
	"cleave": preload("res://art/icons/sk_cleave.png"),
	"bonearmor": preload("res://art/icons/sk_bonearmor.png"),
	"bone": preload("res://art/icons/bone.png"),
	"ink": preload("res://art/icons/ink.png"),
	"ash": preload("res://art/icons/ash.png"),
	"": preload("res://art/icons/flask_empty.png"),
	"parasita": preload("res://art/icons/flask_parasita.png"),
	"titanica": preload("res://art/icons/flask_titanica.png"),
	"weapon": preload("res://art/icons/scythe.png"),
	"sealed": preload("res://art/icons/sealed.png"),
	"veloz": preload("res://art/icons/flask_swift.png"),
	"eco": preload("res://art/icons/flask_echo.png"),
	"tumular": preload("res://art/icons/flask_grave.png"),
	"colerica": preload("res://art/icons/flask_wrath.png"),
	"roubo": preload("res://art/icons/flask_roubo.png"),
	"caotico": preload("res://art/icons/flask_caotico.png"),
	"mitotico": preload("res://art/icons/flask_mitotico.png"),
	"martir": preload("res://art/icons/flask_martir.png"),
	"gatilho": preload("res://art/icons/flask_gatilho.png"),
	"carga": preload("res://art/icons/flask_carga.png"),
	"eter": preload("res://art/icons/flask_eter.png"),
	"gravidade": preload("res://art/icons/flask_gravidade.png"),
	"meteoro": preload("res://art/icons/flask_meteoro.png"),
	"terramoto": preload("res://art/icons/flask_terramoto.png"),
	"vinganca": preload("res://art/icons/soul_vinganca.png"),
	"escriba": preload("res://art/icons/soul_escriba.png"),
	"cranios": preload("res://art/icons/soul_cranios.png"),
	"donzela": preload("res://art/icons/soul_donzela.png"),
	"potion_hp": preload("res://art/icons/potion_red.png"),
	"potion_mp": preload("res://art/icons/potion_soul.png"),
	"guarda": preload("res://art/icons/shield.png"),  # Postura de Combate: Guarda Sepulcral
	"ira": preload("res://art/icons/sk_sacrifice.png"),  # e Ira Sacrificial
	"tree": preload("res://art/icons/hud_tree.png"),  # os três botões do canto de cima (top_bar)
	"arsenal": preload("res://art/icons/hud_arsenal.png"),
	"menu": preload("res://art/icons/hud_menu.png"),
}
const TREE := {
	"node": preload("res://art/tree/node.png"), "node_on": preload("res://art/tree/node_on.png"),
	"notable": preload("res://art/tree/notable.png"), "notable_on": preload("res://art/tree/notable_on.png"),
	"keystone": preload("res://art/tree/keystone.png"), "keystone_on": preload("res://art/tree/keystone_on.png"),
	"root": preload("res://art/tree/root.png"), "root_on": preload("res://art/tree/root_on.png"),
	"bg": preload("res://art/bg/tree.webp"),
}
const NODE_KIND := {"raiz": "keystone", "bleedbone": "keystone", "ossada": "notable", "hemorragia": "notable", "eco": "notable", "pacto": "keystone", "vermes": "keystone", "canibal": "keystone", "semalma": "keystone", "frio": "keystone", "martir_aco": "notable", "ectoplasma": "notable", "ecos": "notable", "presenca": "notable", "sede": "notable", "fragmentada": "keystone", "imolacao": "keystone", "sangue": "keystone", "fome": "keystone", "lich": "keystone", "circulacao": "notable"}
const NODE_SIZE := {"node": 46.0, "notable": 60.0, "keystone": 76.0}
const TREE_WIN := Vector2(780, 390)  # janela da Árvore: nunca muda de tamanho (780: a descrição do nó, na Augusta, cabe em 2 linhas)
const TREE_AREA := Rect2(-310, -170, 1160, 760)  # a folha inteira (com lugar para mais nós), que desliza dentro da janela
const Gothic := preload("res://gothic.gd")
const AppUpdate := preload("res://app_update.gd")
const FILTER := preload("res://filter.gdshader")
const Enemy := preload("res://enemy.gd")
const MINIMAP := 160.0  # lado maior do minimapa, em píxeis
const TOP_BTN := 64.0  # botões do canto de cima: perto de 40 dp num telemóvel, fáceis de acertar
const TOP_GAP := 8.0
## Bestiário: [descrição, mortes para saber o nome / os números / o saque, o que deixa cair] (nomes em Enemy.NAMES).
## Os chefes revelam-se mais depressa. As mortes são do grupo inteiro e ficam gravadas.
const BESTIARY := {
	"skeleton": ["Ossos que o cemitério não deixa descansar. Andam em bando.", [1, 10, 50],
		"Ossos Ancestrais (28%), Tinteiros (6%), Cinzas (4%) e, muito raramente, um Frasco de Alma."],
	"specter": ["Rápido e frágil: chega sempre antes dos outros.", [1, 10, 50],
		"Ossos Ancestrais (28%), Tinteiros (6%), Cinzas (4%) e, muito raramente, um Frasco de Alma."],
	"colossus": ["Bate devagar e com muita força. Um deles guarda a cripta.", [1, 2, 3],
		"2 Ossos Ancestrais, 1 Tinteiro, 1 Cinza e um Frasco de Alma que falte ao grupo (o da cripta deixa também o relicário)."],
	"herald": ["O mensageiro do Cortejo Fúnebre: faz tocar o sino e chama os mortos.", [1, 2, 3],
		"2 Ossos Ancestrais, 1 Tinteiro, 1 Cinza e um Frasco de Alma que falte ao grupo."],
}
const SKILL_SPOTS := [[Vector2(240, 190), 120.0], [Vector2(120, 225), 95.0], [Vector2(255, 75), 95.0]]  # [posição, diâmetro]
## Cores das letras dos botões, como num comando Xbox / GameSir.
const GLYPH_COL := {"a": Color(0.45, 0.82, 0.35), "b": Color(0.93, 0.32, 0.28), "x": Color(0.33, 0.58, 0.97), "y": Color(0.98, 0.8, 0.22)}
const TITLE_ART := preload("res://art/bg/title.webp")
## Afixos do Cortejo em cartões, com arte que já existe a dizer o que fazem.
const AFFIX_ICON := {
	"blindados": preload("res://art/icons/chest_armor.png"),
	"furia": preload("res://art/icons/flask_swift.png"),
	"laminas": preload("res://art/icons/sword.png"),
	"legiao": preload("res://art/icons/sk_raise.png"),
	"gemeo": preload("res://art/colossus.png"),
}
const HERALD_TEX := preload("res://art/anim/herald_0.png")
const SKULLS := preload("res://art/props/skulls.png")
const HOLD_SKIP := 1.0
## Compras do Arsenal a segurar: carregar compra uma vez; segurar espera HOLD_FIRST e depois compra a cada HOLD_STEP,
## até largar o botão ou o jogo responder que já não há com que pagar (as respostas de main.use_currency em SPEND_FAIL).
const HOLD_FIRST := 0.45
const HOLD_STEP := 0.12
## Segurar um botão de toque HOLD_INFO s mostra o cartão do que ele faz (_info_text). Mais que o HOLD_FIRST: um
## toque firme de pânico na poção ainda bebe.
const HOLD_INFO := 0.7
const SKILL_INFO := {
	"scythe": "Golpe em arco com a foice à frente.",
	"bolt": "Dispara uma lança de alma contra o inimigo mais perto.",
	"nova": "Explosão à tua volta.",
	"chop": "Machadada em arco à frente.",
	"cleave": "Rodopio do machado que atinge tudo à volta.",
	"bonearmor": "Durante 5 s levas metade do dano.",
}
const STANCE_INFO := {
	"guarda": "Guarda Sepulcral: -25% de dano recebido e devolves 60% do que levas a quem bateu.",
	"ira": "Ira Sacrificial: +30% dano, recargas -25%, mas cada habilidade custa 2% da vida.",
}
const SPEND_FAIL := ["Sem Tinteiros de Sangue Negro.", "Nada selado para revelar.", "Sem Cinzas do Purgatório.", "Precisas de 5 Ossos Ancestrais."]
const TABS := ["Som", "Desempenho", "Jogo", "Toque", "Ecrã", "Comando"]  # separadores das Configurações
## Perfis de controlo tátil (#81, Configurações > Toque): cada um muda estas opções de uma vez.
## Dois polegares = as de origem · Um polegar = ataque automático, botões a 130% e joystick fixo (o mesmo polegar
## acha-o sem olhar) · Garra = indicadores nos botões, opacidade a 75% para se ver o chão · Tablet = joystick fixo
## no canto, onde o polegar chega, opacidade a 50% e poções a 100% (no ecrã grande já são grandes).
const TOUCH_PROFILES := {
	"Dois polegares": {"ui": 0, "opacity": 0, "potion_ui": 2, "joy_fixed": false, "auto_attack": false},
	"Um polegar": {"ui": 1, "opacity": 0, "potion_ui": 2, "joy_fixed": true, "auto_attack": true},
	"Garra": {"ui": 0, "opacity": 1, "potion_ui": 1, "joy_fixed": false, "auto_attack": false},
	"Tablet": {"ui": 0, "opacity": 2, "potion_ui": 0, "joy_fixed": true, "auto_attack": false},
}
const STUDIO_LOGO := preload("res://art/ui/studio_logo.png")  # no Sobre (e no fim da abertura, opening.gd)
## Intro: a imagem 32-bit de cada quadro (chega com a Parte 8 da arte; até lá, a pintada que já existe) e a legenda.
const Intro := preload("res://intro.gd")
const Opening := preload("res://opening.gd")  # a abertura: o Colosso acorda e o nome do jogo cai  # a intro animada: planos, legendas e o nome do jogo
static var VIGNETTE := _vignette()  # bordas vermelhas da vida baixa


static func _vignette() -> GradientTexture2D:
	var g := GradientTexture2D.new()
	g.gradient = Gradient.new()
	g.gradient.offsets = PackedFloat32Array([0.78, 1.0])
	g.gradient.colors = PackedColorArray([Color(0.6, 0.0, 0.05, 0.0), Color(0.6, 0.0, 0.05, 0.7)])
	g.fill = GradientTexture2D.FILL_RADIAL
	g.fill_from = Vector2(0.5, 0.5)
	g.fill_to = Vector2(1.0, 0.5)
	return g

var main
var root: Control
var safe: Control  # o HUD de jogo, afastado das bordas e do recorte da câmara (_apply_safe)
var overlay: Control  # por baixo dos botões
var front: Control  # por cima dos botões: recargas, chefe, nível, flash
var status: Label
var toast_label: Label
var toast_t := 0.0
var pad: Control
var top_bar: VBoxContainer  # Árvore, Arsenal e Menu em ícones, à esquerda do minimapa (_layout_top)
var interact_btn: Button
var stance_btn: Button  # Guarda Sepulcral ↔ Ira Sacrificial
var skill_btns := {}
var potion_btns := []
var closed_frame := -1  # frame em que se fechou o último painel
var calm_t := 0.0  # há quanto tempo não há combate (HUD que se esbate)
var panel: Control
var panel_cancel := false  # B (ou o Voltar do Android) fecha este painel
var panel_back := Callable()  # para onde B / Voltar levam (vazio = fecha e volta ao jogo)
var sub_back := Callable()  # Arsenal e Árvore abertos pelo Menu: B volta ao Menu
var license_scroll: ScrollContainer  # Licenças: o stick do comando faz rolar o texto
var title_open := false  # no título (e nas Configurações/Sobre abertas dele) ainda não se grava nada
var title_reveal := Callable()  # título: troca o "Toca para começar" pelo menu
var lefty := false  # botões de habilidade à esquerda (set_lefty)
var minimap_rect := Rect2()  # onde ficou o minimapa
var top_rect := Rect2()  # o canto de cima: botões e minimapa (as setas dos chefes não o tapam)
var filter: ColorRect  # daltonismo e conforto ocular: um filtro por cima de tudo (só existe se for preciso)
var intro_i := -1  # quadro da intro que está a passar (-1 = sem intro)
var intro_t := 0.0
var intro_hold := -1.0  # há quanto tempo o dedo segura na intro (-1 = sem toque); HOLD_SKIP salta tudo
var intro_hint: Control
var panel_frame := 0
var gamepad := false  # o último controlo usado foi um comando: esconde os botões de toque e mostra A/B/X/Y
var last_gamepad := false
var hint_title := ""
var hint_action := ""
var updater: Node  # AppUpdate: avisa no título quando há um APK novo no GitHub
var title_menu: VBoxContainer
var hold_kind := ""  # compra do Arsenal a ser segurada (ink, ash, bone) ou ""
var hold_t := 0.0
var tree_drag := 0.0  # Árvore: quanto o dedo já arrastou desde que pousou (mais de 12 desliza a folha em vez de escolher o nó)
var ui_scale_i := 0
var joy_index := -1
var joy_origin := Vector2.ZERO
var joy_pos := Vector2.ZERO
var swipes := {}  # toques fora do joystick: índice -> [onde começou, quando] (deslizar depressa = esquiva)
## Cartão de ajuda: o botão seguro, pelo índice do dedo (o rato do Godot só segue o 1.º dedo, que costuma ser o do joystick)
var info_btn: Button
var info_shown: Button  # o cartão já apareceu para este botão: ao largar, a ação dele não corre
var info_key := ""
var info_at := 0
var info_idx := -1
var info_rect := Rect2()
var info_on := false
var last_touch := 0
var enemy_near := false  # algum inimigo a menos de 700 px de um herói (o _fade_hud sem a opção de esbater; o boneco de treino não conta)
var flash_a := 0.0
var fade_a := 0.0  # negro a desvanecer ao mudar de zona (descer/subir as escadas)
var dark := 0.0
var card_t := 0.0
var card_name := ""
var card_sub := ""
var lvl_t := 0.0
var xp_shown := 0.0
var xp_hold := 0.0
var last_level := 1


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	root = Control.new()
	root.set_anchors_preset(Control.PRESET_FULL_RECT)
	root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.theme = _theme()
	add_child(root)
	safe = Control.new()
	safe.set_anchors_preset(Control.PRESET_FULL_RECT)
	safe.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(safe)
	_apply_safe()
	get_viewport().size_changed.connect(_apply_safe)
	overlay = _layer(_draw_overlay, safe)

	gamepad = not Input.get_connected_joypads().is_empty()
	updater = AppUpdate.new()
	add_child(updater)
	updater.update_available.connect(_on_update)
	updater.check()
	status = _label(Vector2(16, 100), 18)
	status.reparent(safe, false)
	toast_label = _label(Vector2(0, 0), Gothic.TOAST_SIZE)
	toast_label.set_anchors_and_offsets_preset(Control.PRESET_CENTER_TOP)
	toast_label.offset_top = 172
	toast_label.grow_horizontal = Control.GROW_DIRECTION_BOTH
	toast_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	toast_label.add_theme_color_override("font_color", Color(1.0, 0.85, 0.5))

	pad = Control.new()
	pad.mouse_filter = Control.MOUSE_FILTER_IGNORE
	pad.set_anchors_preset(Control.PRESET_BOTTOM_RIGHT)
	pad.offset_left = -380
	pad.offset_top = -330
	pad.offset_right = 0
	pad.offset_bottom = 0
	pad.pivot_offset = Vector2(380, 330)
	safe.add_child(pad)
	for i in 3:
		_skill_button(main.player.order[i], SKILL_SPOTS[i][0], SKILL_SPOTS[i][1])
	interact_btn = _round_button("Invocar", Vector2(130, 110), 95, Color(0.6, 0.15, 0.2))
	_watch(interact_btn, "interact", _interact_or_dodge)
	pad.add_child(interact_btn)
	# Postura de Combate, no canto livre do pad (no comando: R3)
	stance_btn = _round_button("", Vector2(30, 14), 70, Color(0.85, 0.8, 0.65))
	stance_btn.expand_icon = true
	stance_btn.add_theme_constant_override("icon_max_width", 40)
	stance_btn.icon_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_watch(stance_btn, "stance", func(): main.player.toggle_stance())
	pad.add_child(stance_btn)
	# Poções no ecrã tátil, ao lado das habilidades
	for k in [["hp", Vector2(26, 140), Color(0.85, 0.2, 0.2)], ["mp", Vector2(26, 226), Color(0.25, 0.55, 0.95)]]:
		var b := _round_button("", k[1], 64, k[2])
		potion_btns.append(b)
		b.icon = ICONS["potion_" + k[0]]
		b.expand_icon = true
		b.add_theme_constant_override("icon_max_width", 34)
		b.icon_alignment = HORIZONTAL_ALIGNMENT_CENTER
		var kind: String = k[0]
		_watch(b, "potion_" + kind, func(): main.player.use_potion(kind))
		pad.add_child(b)

	top_bar = VBoxContainer.new()
	top_bar.add_theme_constant_override("separation", int(TOP_GAP))
	safe.add_child(top_bar)
	for b in [["tree", _tree], ["arsenal", _arsenal], ["menu", open_menu]]:
		var btn := _round_button("", Vector2.ZERO, TOP_BTN, Color(0.85, 0.8, 0.65))
		btn.custom_minimum_size = Vector2(TOP_BTN, TOP_BTN)
		btn.icon = ICONS[b[0]]
		btn.expand_icon = true
		btn.add_theme_constant_override("icon_max_width", 44)
		btn.icon_alignment = HORIZONTAL_ALIGNMENT_CENTER
		_watch(btn, b[0], b[1])  # segurar mostra o que abre (_info_text)
		top_bar.add_child(btn)
	front = _layer(_draw_front)


func _layer(cb: Callable, parent: Control = null) -> Control:
	var c := Control.new()
	c.set_anchors_preset(Control.PRESET_FULL_RECT)
	c.mouse_filter = Control.MOUSE_FILTER_IGNORE
	c.draw.connect(cb)
	(parent if parent else root).add_child(c)
	return c


## Margem segura do HUD de jogo: 16 px a mais em todo o lado (os elementos já trazem ~12 px de folga: ~28 px,
## uns 16 dp num telemóvel) e, no telemóvel, o recorte da câmara. O recorte conta dos dois lados porque o ecrã
## roda 180° sem mudar de tamanho.
func _apply_safe() -> void:
	var side := 16.0
	var top := 16.0
	var bottom := 16.0
	if OS.has_feature("mobile"):
		var sa := Rect2(DisplayServer.get_display_safe_area())
		var ws := Vector2(DisplayServer.window_get_size())
		var k := root.get_viewport_rect().size / ws
		side = maxf(side, maxf(sa.position.x, ws.x - sa.end.x) * k.x)
		top = maxf(top, sa.position.y * k.y)
		bottom = maxf(bottom, (ws.y - sa.end.y) * k.y)
	safe.offset_left = side
	safe.offset_right = -side
	safe.offset_top = top
	safe.offset_bottom = -bottom


func _sbt(tex: Texture2D, mod: Color) -> StyleBoxTexture:
	var s := StyleBoxTexture.new()
	s.texture = tex
	s.set_texture_margin_all(18.0)
	s.content_margin_left = 22.0
	s.content_margin_right = 22.0
	s.content_margin_top = 6.0
	s.content_margin_bottom = 6.0
	s.modulate_color = mod
	return s


## Painéis com a moldura de ferro e osso, botões com a placa da SC-UI2 (acesa quando premida).
func _theme() -> Theme:
	var th := Theme.new()
	th.default_font = Gothic.BODY
	th.default_font_size = Gothic.BODY_SIZE
	var pn := StyleBoxTexture.new()
	pn.texture = UI.panel
	pn.set_texture_margin_all(96.0)
	pn.set_content_margin_all(38.0)
	th.set_stylebox("panel", "PanelContainer", pn)
	th.set_stylebox("normal", "Button", _sbt(UI.btn, Color.WHITE))
	th.set_stylebox("hover", "Button", _sbt(UI.btn, Color(1.3, 1.3, 1.25)))
	th.set_stylebox("pressed", "Button", _sbt(UI.btn_on, Color.WHITE))
	th.set_stylebox("disabled", "Button", _sbt(UI.btn, Color(0.5, 0.5, 0.5)))
	var fo := StyleBoxFlat.new()
	fo.draw_center = false
	fo.set_border_width_all(2)
	fo.border_color = Color(0.45, 1.0, 0.65)
	fo.set_corner_radius_all(6)
	fo.set_expand_margin_all(2.0)
	th.set_stylebox("focus", "Button", fo)
	# Barras de volume: calha escura com aro de osso, cheia a verde-alma
	var track := StyleBoxFlat.new()
	track.bg_color = Color(0.05, 0.06, 0.06)
	track.border_color = Color(0.5, 0.45, 0.34)
	track.set_border_width_all(2)
	track.set_corner_radius_all(6)
	track.content_margin_top = 5.0
	track.content_margin_bottom = 5.0
	th.set_stylebox("slider", "HSlider", track)
	var fill := StyleBoxFlat.new()
	fill.bg_color = Color(0.28, 0.8, 0.5)
	fill.set_corner_radius_all(6)
	th.set_stylebox("grabber_area", "HSlider", fill)
	var lit: StyleBoxFlat = fill.duplicate()
	lit.bg_color = Color(0.45, 1.0, 0.65)
	th.set_stylebox("grabber_area_highlight", "HSlider", lit)
	th.set_stylebox("focus", "HSlider", fo)
	for c in ["font_color", "font_hover_color", "font_focus_color"]:
		th.set_color(c, "Button", Color(0.93, 0.89, 0.76))
	th.set_color("font_pressed_color", "Button", Color.WHITE)
	# Botões com a letra do texto (não a do sistema), com contorno escuro para se lerem em cima da arte
	th.set_font("font", "Button", Gothic.BODY)
	th.set_font_size("font_size", "Button", Gothic.BODY_SIZE)
	th.set_constant("outline_size", "Button", 5)
	th.set_color("font_outline_color", "Button", Color(0.02, 0.02, 0.02))
	return th


func _label(pos: Vector2, size: int) -> Label:
	var l := Label.new()
	l.position = pos
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_outline_color", Color.BLACK)
	l.add_theme_constant_override("outline_size", 6)
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(l)
	return l


func _round_button(text: String, pos: Vector2, d: float, tint: Color) -> Button:
	var b := Button.new()
	b.text = text
	b.position = pos
	b.size = Vector2(d, d)
	b.focus_mode = Control.FOCUS_NONE
	for st in ["normal", "hover", "pressed"]:
		var sb := StyleBoxFlat.new()
		sb.bg_color = Color(0.04, 0.07, 0.07, 0.75) if st != "pressed" else Color(tint, 0.6)
		sb.border_color = tint
		sb.set_border_width_all(3)
		sb.set_corner_radius_all(int(d / 2))
		b.add_theme_stylebox_override(st, sb)
	return b


## O herói deste telemóvel mudou (o convidado da Wi-Fi é o Guardião): botões com as habilidades dele.
func skills_for_player() -> void:
	for b in skill_btns.values():
		b.free()
	skill_btns.clear()
	for i in 3:
		var spot: Array = SKILL_SPOTS[i]
		_skill_button(main.player.order[i], Vector2(380.0 - spot[0].x - spot[1], spot[0].y) if lefty else spot[0], spot[1])


## Botão de habilidade = o ícone redondo da folha SC-ICO3.
func _skill_button(id: String, pos: Vector2, d: float) -> void:
	var b := Button.new()
	b.position = pos
	b.size = Vector2(d, d)
	b.focus_mode = Control.FOCUS_NONE
	for st in ["normal", "hover", "pressed"]:
		var sb := StyleBoxTexture.new()
		sb.texture = ICONS[id]
		sb.modulate_color = Color(0.7, 0.7, 0.7) if st == "pressed" else Color.WHITE
		b.add_theme_stylebox_override(st, sb)
	b.button_down.connect(func(): main.player.held[id] = true)
	b.button_up.connect(func(): main.player.held[id] = false)
	_watch(b, id)
	skill_btns[id] = b
	pad.add_child(b)


## Segurar o botão b mostra o cartão de key ("interact", "stance", "potion_hp"/"potion_mp", "tree"/"arsenal"/"menu" ou a habilidade).
## cb = a ação do botão (ao largar): não corre se o cartão chegou a aparecer, venha o pressed antes ou depois do button_up.
func _watch(b: Button, key: String, cb = null) -> void:
	b.button_down.connect(func():
		info_btn = b
		info_key = key
		info_at = Time.get_ticks_msec()
		info_idx = last_touch  # o 2.º dedo chega ao _input antes do botão; o 1.º só depois (o _input corrige-o)
		info_rect = b.get_global_rect()
		if info_shown == b:
			info_shown = null)
	b.button_up.connect(func():
		if info_btn == b:
			info_btn = null)
	if cb != null:
		b.pressed.connect(func():
			if info_shown == b:
				info_shown = null
			else:
				cb.call())


func set_ui_scale(i: int) -> void:
	ui_scale_i = clampi(i, 0, SCALES.size() - 1)
	pad.scale = Vector2.ONE * SCALES[ui_scale_i]


## Canhoto: os botões de habilidade passam para o canto de baixo à esquerda (espelhados) e o joystick
## para a metade direita do ecrã.
func set_lefty(on: bool) -> void:
	if on == lefty:
		return
	lefty = on
	for c in pad.get_children():
		c.position.x = 380.0 - c.position.x - c.size.x
	pad.anchor_left = 0.0 if on else 1.0
	pad.anchor_right = pad.anchor_left
	pad.offset_left = 0.0 if on else -380.0
	pad.offset_right = pad.offset_left + 380.0
	pad.pivot_offset = Vector2(0.0 if on else 380.0, 330)


## Interface fora de combate: 3 s sem inimigos perto, com a vida cheia e sem Cortejo, as barras, as moedas e o
## minimapa ficam quase transparentes; voltam logo ao primeiro sinal de luta. Os botões ficam como estão.
func _fade_hud(delta: float) -> void:
	var fight: bool = not main.settings.hud_fade or main.cortejo.active or panel != null
	enemy_near = false
	for p in main.players:
		fight = fight or p.hp < p.max_hp * 0.99 or p.dead
		for e in main.enemies():
			var near: bool = p.position.distance_squared_to(e.position) < 700.0 * 700.0
			fight = fight or near
			enemy_near = enemy_near or (near and not e.dummy)  # ao pé do boneco de treino os cartões das habilidades abrem-se
	calm_t = 0.0 if fight else calm_t + delta
	overlay.modulate.a = move_toward(overlay.modulate.a, 0.22 if calm_t > 3.0 else 1.0, delta * (1.5 if calm_t > 3.0 else 6.0))
	status.modulate.a = overlay.modulate.a


## Botões de poção maiores para o toque de pânico: o de cima cresce para cima e o de baixo para baixo.
func set_potion_scale(i: int) -> void:
	for j in potion_btns.size():
		var b: Button = potion_btns[j]
		b.pivot_offset = Vector2(b.size.x / 2.0, b.size.y if j == 0 else 8.0)
		b.scale = Vector2.ONE * [1.0, 1.25, 1.5][i]


## Daltonismo (mode 0..3) e conforto ocular (0..1): só desenha o filtro com algum ligado.
func set_filter(mode: int, comfort: float) -> void:
	if filter == null:
		if mode == 0 and comfort == 0.0:
			return
		var layer := CanvasLayer.new()
		layer.layer = 128
		add_child(layer)
		filter = ColorRect.new()
		filter.set_anchors_preset(Control.PRESET_FULL_RECT)
		filter.mouse_filter = Control.MOUSE_FILTER_IGNORE
		filter.material = ShaderMaterial.new()
		filter.material.shader = FILTER
		layer.add_child(filter)
	filter.material.set_shader_parameter("mode", mode)
	filter.material.set_shader_parameter("comfort", comfort)
	filter.visible = mode > 0 or comfort > 0.0


func toast(text: String) -> void:
	Net.echo("hud", "toast", [text])
	toast_label.text = text
	toast_t = 3.0


func flash(a: float) -> void:
	Net.echo("hud", "flash", [a])
	if main.settings.flash:
		flash_a = maxf(flash_a, a)


func fade() -> void:
	fade_a = 1.0


func name_card(n: String, sub: String) -> void:
	Net.echo("hud", "name_card", [n, sub])
	card_name = n
	card_sub = sub
	card_t = CARD_T


func level_up() -> void:
	Net.echo("hud", "level_up", [])  # o convidado também vê o aviso
	lvl_t = LVL_T


func _process(delta: float) -> void:
	_fade_hud(delta)
	_hold_buy_tick(delta)
	if not is_instance_valid(info_btn):
		info_btn = null  # skills_for_player troca os botões de habilidade
	if not is_instance_valid(info_shown):
		info_shown = null
	# Habilidades: segurar é atacar sem parar, por isso o cartão delas só aparece longe de inimigos
	var was_on := info_on
	info_on = info_btn != null and panel == null and Time.get_ticks_msec() - info_at >= HOLD_INFO * 1000.0 \
			and (not enemy_near or not skill_btns.has(info_key)) and _info_text(info_key)[1] != ""
	if was_on and not info_on and info_btn != null and panel == null and enemy_near and skill_btns.has(info_key):
		main.player.held[info_key] = true  # chegou um inimigo com o dedo ainda no botão: o cartão fecha e o herói volta a golpear
	if info_on and info_shown != info_btn:
		info_shown = info_btn
		if skill_btns.has(info_key):
			main.player.held[info_key] = false  # a ler o cartão, o herói pára de repetir o golpe (volta no toque seguinte)
		else:
			main.vibrate(25, 0.4, main.player)
	# Primeira vez com o ecrã tátil: diz que segurar um botão explica-o (não é o toast(): esse ia ao convidado)
	if panel == null and not title_open and intro_i < 0 and not gamepad and not main.settings.hold_hint:
		toast_label.text = tr("Fora de combate, segura um botão para saber o que faz")
		toast_t = 5.0
		main.settings.hold_hint = true
		main.save_settings()
	if intro_i >= 0:
		intro_t -= delta
		if intro_hold >= 0.0:
			intro_hold += delta
			intro_hint.queue_redraw()
			if intro_hold >= HOLD_SKIP:
				intro_hold = -1.0
				_intro_end()
		elif intro_t <= 0.0:
			_intro_next()
	toast_t -= delta
	toast_label.visible = toast_t > 0.0
	flash_a = maxf(0.0, flash_a - delta * 3.0)
	fade_a = maxf(0.0, fade_a - delta * 1.4)
	card_t -= delta
	lvl_t -= delta
	dark = lerpf(dark, 0.45 if main.rumble > 0.0 else 0.0, 1.0 - exp(-3.0 * delta))
	# XP: enche devagar; ao subir de nível fica cheia a piscar um instante e só depois recomeça
	if main.level != last_level:
		last_level = main.level
		xp_hold = 0.5
		xp_shown = 1.0
	if xp_hold > 0.0:
		xp_hold -= delta
		if xp_hold <= 0.0:
			xp_shown = 0.0
	else:
		xp_shown = lerpf(xp_shown, float(main.xp) / main.xp_needed(), 1.0 - exp(-6.0 * delta))
	status.text = ""  # a foice e o oculto estão no Arsenal (e no cartão do botão dele)
	if main.cortejo.active:
		var names := []
		for a in main.cortejo.affixes:
			names.append(tr(main.AFFIXES[a][0]))
		status.text = tr("CORTEJO FÚNEBRE — onda %d/%d   restantes: %d   afixos: %s") % [main.cortejo.wave, main.WAVES, main.cortejo.alive, ", ".join(names) if names else tr("nenhum")]
	# O que dá para fazer aqui (B no comando, ou o botão redondo no ecrã)
	var door: String = main.near_door()
	hint_title = ""
	hint_action = ""
	var soul = main.soul_target(main.player)
	if soul != null:  # Execução Espectral / extração da Alma Ancestral: vem antes de tudo, a meio da luta
		hint_title = soul.who()
		hint_action = "Extrair" if soul.extractable() else "Executar"
	elif main.near_chest():
		hint_title = "Relicário selado"
		hint_action = "Abrir"
	elif door != "":
		hint_title = "Cripta dos Condenados" if door == "down" else "Saída da cripta"
		hint_action = "Descer" if door == "down" else "Subir"
	elif main.near_monument():
		hint_title = "Monumento Fúnebre"
		hint_action = "Invocar"
	interact_btn.text = hint_action if hint_action != "" else "Pacto" if main.player.stat("pacto") > 0.0 else "Esquiva"  # o Pacto (#101) tira a esquiva: o botão diz porquê
	var ira: bool = main.player.stance == "ira"
	stance_btn.icon = ICONS["ira" if ira else "guarda"]
	stance_btn.get_theme_stylebox("normal").border_color = Color(0.95, 0.2, 0.15) if ira else Color(0.85, 0.8, 0.65)
	pad.visible = not gamepad
	top_bar.visible = not gamepad
	_layout_top()
	if gamepad != last_gamepad:
		last_gamepad = gamepad
		root.propagate_call("queue_redraw")  # o título e os painéis desenham as legendas do modo novo
	# Menu = menu do jogo, Vista = Árvore de quem carregou; com um painel aberto, voltam atrás (como o B)
	var fresh: bool = Engine.get_process_frames() > panel_frame  # o botão que abriu o painel não o fecha logo
	for i in main.players.size():
		var pfx := "" if i == 0 else "p2_"
		for a in ["menu", "tree", "arsenal"]:
			if Input.is_action_just_pressed(pfx + a) and not main.players[i].dead:
				if panel == null:
					if a == "menu":
						open_menu()
					elif a == "arsenal":
						_arsenal()
					else:
						_tree(i)
				elif panel_cancel and fresh:
					_back()
	if panel != null and panel_cancel and fresh and Input.is_action_just_pressed("ui_cancel"):
		_back()
	if is_instance_valid(license_scroll):
		license_scroll.scroll_vertical += int(Input.get_axis("ui_up", "ui_down") * 700.0 * delta)
	overlay.queue_redraw()
	front.queue_redraw()


## O botão redondo: interage com o que está perto; sem nada, esquiva para onde o joystick aponta.
func _interact_or_dodge() -> void:
	if hint_action != "":
		main.interact()
	else:
		main.player.dodge(main.player.touch_move)


func _input(event: InputEvent) -> void:
	var vs := root.get_viewport_rect().size
	if event is InputEventJoypadButton or (event is InputEventJoypadMotion and absf(event.axis_value) > 0.5):
		gamepad = true
		main.on_pad_input(event)
	elif event is InputEventScreenTouch and event.pressed:
		gamepad = false
		last_touch = event.index
		if info_btn != null and info_rect.has_point(event.position):
			info_idx = event.index  # o 1.º dedo carrega no botão (pelo rato emulado) antes de o toque chegar aqui
	# Intro: tocar (ou A) passa ao quadro seguinte; segurar o dedo 1 s, B ou Menu salta tudo. O toque conta ao
	# levantar o dedo (para se poder segurar). O rato só conta sem ecrã tátil, senão o toque (que também chega
	# como rato) passava dois quadros de uma vez.
	if intro_i >= 0 and not event.is_echo() and Engine.get_process_frames() > panel_frame \
			and (event is InputEventScreenTouch or (event is InputEventMouseButton and not DisplayServer.is_touchscreen_available())):
		get_viewport().set_input_as_handled()
		if event.is_pressed():
			intro_hold = 0.0
		elif intro_hold >= 0.0:
			intro_hold = -1.0
			_intro_next()
		return
	if intro_i >= 0 and event is InputEventJoypadButton and event.is_pressed() and Engine.get_process_frames() > panel_frame:
		get_viewport().set_input_as_handled()
		if event.button_index in [JOY_BUTTON_B, JOY_BUTTON_START]:
			_intro_end()
		else:
			_intro_next()
		return
	if event is InputEventScreenTouch:
		var joy_side: bool = event.position.x > vs.x * 0.55 if lefty else event.position.x < vs.x * 0.45
		if event.pressed and joy_index == -1 and panel == null and joy_side and event.position.y > maxf(vs.y * 0.3, safe.position.y + top_rect.end.y):  # os botões do canto de cima não começam o joystick (no canhoto, é o lado dele)
			joy_index = event.index
			joy_origin = _joy_home() if main.settings.joy_fixed else event.position
			joy_pos = event.position
			main.player.touch_move = ((joy_pos - joy_origin) / (JOY_R * SCALES[ui_scale_i])).limit_length(1.0)
		elif not event.pressed and event.index == joy_index:
			joy_index = -1
			main.player.touch_move = Vector2.ZERO
		elif event.pressed:
			swipes[event.index] = [event.position, Time.get_ticks_msec()]
		elif swipes.has(event.index):
			var s: Array = swipes[event.index]
			swipes.erase(event.index)
			var v: Vector2 = event.position - s[0]
			if v.length() > 90.0 and Time.get_ticks_msec() - s[1] < 300 and panel == null:
				main.player.dodge(v)
	elif event is InputEventScreenDrag and event.index == joy_index:
		joy_pos = event.position
		var r: float = JOY_R * SCALES[ui_scale_i]
		main.player.touch_move = ((joy_pos - joy_origin) / r).limit_length(1.0)
	# O dedo que segura um botão saiu dele: não há cartão
	if event is InputEventScreenDrag and info_btn != null and event.index == info_idx and not info_rect.grow(12.0).has_point(event.position):
		info_btn = null


func _draw_overlay() -> void:
	var vs := overlay.size
	var font := ThemeDB.fallback_font
	var p = main.player
	# Jogador 1: retrato no anel + nome + vida + mana
	_portrait(p, Vector2(42, 44), 25.0)
	Gothic.draw(overlay, Vector2(82, 26), p.hero_name, 21, Color(0.9, 0.85, 0.7), 5)
	_life_bar(Rect2(82, 32, 220, 12), p)
	overlay.draw_rect(Rect2(82, 48, 180, 7), Color(0.02, 0.04, 0.08))
	overlay.draw_rect(Rect2(82, 48, 180 * p.mana / p.max_mana, 7), Color(0.2, 0.6, 0.85))
	_corruption_bar(Rect2(82, 57, 180, 3), p)
	# Moedas com os ícones da folha SC-ICO1
	var x := 16.0
	for k in ["bone", "ink", "ash"]:
		overlay.draw_texture_rect(ICONS[k], Rect2(x, 72, 26, 26), false)
		Gothic.draw(overlay, Vector2(x + 30, 93), str(main.currency[k]), 20, Color(0.95, 0.9, 0.75), 5)
		x += 74.0
	# Jogador 2 (co-op): retrato, vida e as 3 habilidades com recarga
	if main.players.size() > 1:
		var q = main.players[1]
		_portrait(q, Vector2(352, 40), 20.0)
		var label: String = tr(q.hero_name) + ("  — " + tr("caído") if q.dead else "")
		Gothic.draw(overlay, Vector2(380, 26), label, 20, q.tint, 5)
		_life_bar(Rect2(380, 32, 160, 10), q)
		_corruption_bar(Rect2(380, 44, 160, 2), q)
		for i in 3:
			var id: String = q.order[i]
			var r := Rect2(380 + i * 30, 47, 26, 26)
			overlay.draw_texture_rect(ICONS[id], r, false)
			if q.cds[id] > 0.0:
				_pie(overlay, r.get_center(), 13.0, q.cds[id] / q.skills[id].cd)
		if main.pad_of[1] == -1:
			overlay.draw_string(font, Vector2(474, 70), tr("carrega num botão do 2.º comando"), HORIZONTAL_ALIGNMENT_LEFT, -1, 16, Color(1, 1, 1, 0.6))
	elif gamepad:
		_prompts(overlay, Vector2(330, 30), ["2.º comando: ", "@menu", " entra o Guardião"], 14)
	# Orbes de vida e alma dentro do suporte duplo da folha SC-UI1 (buracos medidos: centros a 27% e 73%, 54% de altura)
	var hw := 300.0
	var hh: float = hw * UI.holder.get_height() / UI.holder.get_width()
	var hr := Rect2(vs.x * 0.5 - hw / 2.0, vs.y - hh - 10.0, hw, hh)
	var rad := hw * 0.18
	_orb(hr.position + Vector2(hw * 0.269, hh * 0.54), rad, p.hp / p.max_hp, UI.red)
	_orb(hr.position + Vector2(hw * 0.726, hh * 0.54), rad, p.mana / p.max_mana, UI.soul)
	overlay.draw_texture_rect(UI.holder, hr, false)
	# Poções de cada lado das orbes, com as cargas (no comando: LB vida, RB alma)
	_potion(Vector2(hr.position.x - 30, hr.get_center().y), "hp", p)
	_potion(Vector2(hr.end.x + 30, hr.get_center().y), "mp", p)
	# Experiência do grupo
	var xr := Rect2(vs.x * 0.5 - 160, vs.y - 8, 320, 5)
	overlay.draw_rect(xr, Color(0, 0, 0, 0.75))
	var xc := Color(1.0, 0.97, 0.8) if xp_hold > 0.0 and int(xp_hold * 14.0) % 2 == 0 else Color(0.95, 0.8, 0.4)
	overlay.draw_rect(Rect2(xr.position, Vector2(xr.size.x * clampf(xp_shown, 0.0, 1.0), xr.size.y)), xc)
	Gothic.draw(overlay, Vector2(xr.end.x + 8, vs.y - 2), tr("Nv %d") % main.level, 17,Color(0.95, 0.8, 0.4), 4)
	# Seta para o objetivo: o monumento no cemitério; na cripta, o Carcereiro e depois a saída
	var to: Vector2 = main.objective() - p.position
	if to.length() > 450.0:
		var c := overlay.get_viewport_rect().size / 2.0 - overlay.global_position + to.normalized() * 200.0
		var d := to.normalized()
		overlay.draw_colored_polygon(PackedVector2Array([c + d * 16.0, c + d.orthogonal() * 9.0, c - d.orthogonal() * 9.0]), Color(0.9, 0.2, 0.25, 0.8) if main.cortejo.active else Color(0.4, 1.0, 0.65, 0.7))
	if main.settings.minimap:
		_minimap(vs)
	# Chefes fora do ecrã: seta vermelha a pulsar na borda
	var a := 0.65 + 0.3 * sin(Time.get_ticks_msec() * 0.008)
	for m in boss_marks():
		var tip: Vector2 = m[0]
		var d: Vector2 = m[1]
		var tri := PackedVector2Array([tip, tip - d * 26.0 + d.orthogonal() * 14.0, tip - d * 26.0 - d.orthogonal() * 14.0, tip])
		overlay.draw_colored_polygon(tri, Color(1.0, 0.12, 0.18, a))
		overlay.draw_polyline(tri, Color(0, 0, 0, a), 2.0)


## O minimapa fica no canto de cima (a zona dá a forma, o lado maior é MINIMAP).
func _minimap_box(vs: Vector2) -> Rect2:
	var b: Rect2 = main.bounds
	var k: float = MINIMAP / maxf(b.size.x, b.size.y)
	return Rect2(vs.x - 12.0 - b.size.x * k, 12.0, b.size.x * k, b.size.y * k)


## Os botões ficam à esquerda do minimapa (ou no canto, sem minimapa). Todos os frames: a forma do minimapa muda com a zona.
func _layout_top() -> void:
	var vs := overlay.size
	var left := vs.x - 12.0  # onde acaba a coluna de botões
	var mm := Rect2()
	if main.settings.minimap:
		mm = _minimap_box(vs)
		left = mm.position.x - 10.0
	top_bar.position = Vector2(left - TOP_BTN, 12.0)
	top_rect = Rect2(top_bar.position, Vector2(TOP_BTN, 3.0 * TOP_BTN + 2.0 * TOP_GAP))
	if mm.size != Vector2.ZERO:
		top_rect = top_rect.merge(mm)


## Minimapa no canto de cima, à direita dos botões: a zona inteira, o que a câmara vê, o grupo, os monstros
## (os chefes maiores e a pulsar) e o que importa: monumento, escadas da cripta, túmulo, relicário, saída.
func _minimap(vs: Vector2) -> void:
	var b: Rect2 = main.bounds
	var k: float = MINIMAP / maxf(b.size.x, b.size.y)
	var box := _minimap_box(vs)
	minimap_rect = box
	var at := func(w: Vector2) -> Vector2: return box.position + ((w - b.position) * k).clamp(Vector2.ZERO, box.size)
	overlay.draw_rect(box, Color(0.02, 0.03, 0.03, 0.75))
	if main.zone == "crypt":
		overlay.draw_colored_polygon(PackedVector2Array(Array(main.crypt_floor).map(at)), Color(0.45, 0.5, 0.43, 0.75))
		overlay.draw_rect(Rect2(at.call(main.CRYPT_ORIGIN + main.CRYPT_OUT) - Vector2(4, 4), Vector2(8, 8)), Color(0.75, 0.6, 1.0))
	else:
		overlay.draw_circle(at.call(main.monument_pos), 4.0, Color(0.4, 1.0, 0.65))
		overlay.draw_rect(Rect2(at.call(main.CRYPT_DOOR) - Vector2(4, 4), Vector2(8, 8)), Color(0.75, 0.6, 1.0))
		if not main.tomb.is_empty():
			overlay.draw_dashed_line(at.call(main.player.position), at.call(main.tomb.pos), Color(0.6, 1.0, 0.8, 0.7), 1.5, 4.0)
			overlay.draw_circle(at.call(main.tomb.pos), 3.5, Color(0.6, 1.0, 0.8))
	if is_instance_valid(main.chest) and not main.chest.opened:
		overlay.draw_circle(at.call(main.chest.position), 3.5, Color(1.0, 0.82, 0.3))
	var half: Vector2 = overlay.get_viewport_rect().size / 2.0 / main.cam.zoom
	var view := Rect2(main.cam.get_screen_center_position() - half, half * 2.0).intersection(b)
	overlay.draw_rect(Rect2(at.call(view.position), view.size * k), Color(1, 1, 1, 0.3), false, 1.0)
	for a in get_tree().get_nodes_in_group("allies"):
		overlay.draw_circle(at.call(a.position), 1.8, Color(0.6, 1.0, 0.7))
	var pulse := 4.0 + sin(Time.get_ticks_msec() * 0.01) * 1.2
	for e in main.enemies():
		overlay.draw_circle(at.call(e.position), pulse if e.is_boss else 1.8, Color(1.0, 0.25, 0.25))
	for p in main.players:
		var q: Vector2 = at.call(p.position)
		overlay.draw_circle(q, 4.5, Color.BLACK)
		overlay.draw_circle(q, 3.5, p.tint.darkened(0.5) if p.dead else p.tint)
	overlay.draw_rect(box, Color(0.55, 0.5, 0.38, 0.85), false, 2.0)


## Chefes fora do ecrã: [ponta da seta na borda, direção] para cada um.
func boss_marks() -> Array:
	var vs := overlay.size
	var ct := overlay.get_viewport().get_canvas_transform()
	var half := vs / 2.0 - Vector2(30, 60)
	var marks := []
	for e in main.enemies():
		var s: Vector2 = ct * e.global_position - overlay.global_position
		if e.is_boss and not Rect2(Vector2.ZERO, vs).has_point(s):
			var d := (s - vs / 2.0).normalized()
			var tip := vs / 2.0 + d * minf(half.x / maxf(absf(d.x), 0.01), half.y / maxf(absf(d.y), 0.01))
			if top_rect.grow(28.0).has_point(tip):
				tip.y = top_rect.end.y + 34.0  # por baixo dos botões e do minimapa
			marks.append([tip, d])
	return marks


func _draw_front() -> void:
	var vs := front.size
	var sr := safe.get_global_rect()
	var p = main.player
	if main.settings.show_fps:
		front.draw_string_outline(ThemeDB.fallback_font, Vector2(sr.position.x, sr.end.y - 4), "%d FPS" % Engine.get_frames_per_second(), HORIZONTAL_ALIGNMENT_LEFT, -1, 16, 4, Color.BLACK)
		front.draw_string(ThemeDB.fallback_font, Vector2(sr.position.x, sr.end.y - 4), "%d FPS" % Engine.get_frames_per_second(), HORIZONTAL_ALIGNMENT_LEFT, -1, 16, Color(0.6, 1.0, 0.7))
	if Net.is_guest() and Net.host_paused:
		Gothic.draw_centered(front, vs.x / 2.0, vs.y * 0.3, "O anfitrião está num menu…", 32, Color(0.93, 0.89, 0.77), 8)
	# Joystick flutuante (na frente: não se esbate com o HUD)
	if joy_index != -1:
		var r: float = JOY_R * SCALES[ui_scale_i]
		front.draw_texture_rect(UI.joy, Rect2(joy_origin - Vector2(r, r), Vector2(2 * r, 2 * r)), false, Color(1, 1, 1, 0.8))
		var k := joy_origin + (joy_pos - joy_origin).limit_length(r)
		front.draw_texture_rect(UI.knob, Rect2(k - Vector2(r, r) * 0.45, Vector2(r, r) * 0.9), false)
	elif not gamepad and main.settings.joy_fixed and panel == null:
		var r: float = JOY_R * SCALES[ui_scale_i]
		var h := _joy_home()
		front.draw_texture_rect(UI.joy, Rect2(h - Vector2(r, r), Vector2(2 * r, 2 * r)), false, Color(1, 1, 1, 0.45))
		front.draw_texture_rect(UI.knob, Rect2(h - Vector2(r, r) * 0.45, Vector2(r, r) * 0.9), false, Color(1, 1, 1, 0.6))
	elif not gamepad and DisplayServer.is_touchscreen_available():
		front.draw_string(ThemeDB.fallback_font, Vector2(sr.end.x - 240.0 if lefty else sr.position.x + 24.0, sr.end.y - 24.0), tr("toca e arrasta para mover"), HORIZONTAL_ALIGNMENT_LEFT, -1, 16, Color(1, 1, 1, 0.35))
	if gamepad:
		_pad_diamond(sr.end, p)
		if panel == null:
			_prompts(front, Vector2(sr.position.x + top_bar.position.x + TOP_BTN, sr.position.y + 22.0), ["@view", " Árvore     ", "@menu", " Menu"], 18, 1.0)  # onde estariam os botões
	else:
		# Recargas por cima dos botões de toque, e o frasco de suporte no canto
		for id in skill_btns:
			var r: Rect2 = skill_btns[id].get_global_rect()
			if p.cds[id] > 0.0:
				_pie(front, r.get_center(), r.size.x * 0.43, p.cds[id] / p.skills[id].cd)
			var sup: String = p.skills[id].support
			if sup != "":
				front.draw_texture_rect(ICONS[sup], Rect2(r.end - Vector2(30, 34), Vector2(28, 28)), false)
		if hint_action == "" and p.dash_cd > 0.0:
			var ir: Rect2 = interact_btn.get_global_rect()
			_pie(front, ir.get_center(), ir.size.x * 0.43, p.dash_cd / p.DASH_CD)
	if hint_title != "":
		var parts := [hint_title + "  —  "] + (["@b", " " + hint_action] if gamepad else [tr("toca em %s") % tr(hint_action)])
		_prompts(front, Vector2(vs.x * 0.5, 150.0), parts, 20, 0.5)
	# Legenda dos painéis no comando, por baixo da moldura
	if gamepad and panel is PanelContainer:
		var pr: Rect2 = panel.get_global_rect()
		_prompts(front, Vector2(vs.x * 0.5, minf(pr.end.y + 24.0, vs.y - 8.0)), ["@a", " Escolher     ", "@b", " Voltar"] if panel_cancel else ["@a", " Escolher"], 17, 0.5)
	# Vida baixa (menos de 30%): as bordas do ecrã pulsam a vermelho, mais forte quanto menos vida
	var low: float = 1.0 - p.hp / (p.max_hp * 0.3)
	if low > 0.0 and not p.dead:
		front.draw_texture_rect(VIGNETTE, Rect2(Vector2.ZERO, vs), false, Color(1, 1, 1, minf(low, 1.0) * (0.45 + 0.25 * sin(Time.get_ticks_msec() * 0.008))))
	if dark > 0.01:  # o mundo escurece enquanto o sino dobra
		front.draw_rect(Rect2(Vector2.ZERO, vs), Color(0.0, 0.02, 0.01, dark))
	var y := 62.0
	for e in main.enemies():
		if e.is_boss and e.rise_t <= 0.0 and (e.awake or e.aggro == INF):  # o Carcereiro só depois de acordar
			_boss_bar(e, vs, y)
			y += 92.0
	if card_t > 0.0:
		_name_card(vs)
	if lvl_t > 0.0:
		_level_card(vs)
	if info_on:
		_info_card(info_btn, _info_text(info_key))
	if flash_a > 0.0:
		front.draw_rect(Rect2(Vector2.ZERO, vs), Color(1, 1, 1, flash_a))
	if fade_a > 0.0:
		front.draw_rect(Rect2(Vector2.ZERO, vs), Color(0, 0, 0, fade_a))


## Onde fica o joystick fixo: no canto de baixo do lado do polegar, dentro da margem segura.
func _joy_home() -> Vector2:
	var r: float = JOY_R * SCALES[ui_scale_i]
	var sr := safe.get_global_rect()
	return Vector2(sr.end.x - r - 40.0 if lefty else sr.position.x + r + 40.0, sr.end.y - r - 40.0)


func _pie(ci: CanvasItem, c: Vector2, r: float, f: float) -> void:
	if f < 0.02:
		return
	f = minf(f, 1.0)  # Titânica e Meteórica: a recarga passa da base e o polígono dava mais que uma volta
	var pts := PackedVector2Array([c])
	for i in 25:
		pts.append(c + Vector2.from_angle(-PI / 2.0 + TAU * f * i / 24.0) * r)
	ci.draw_colored_polygon(pts, Color(0, 0, 0, 0.6))


## Habilidades em losango, como os botões do comando: Y em cima, X à esquerda, A em baixo, B (interagir) à direita.
## corner = canto de baixo à direita da margem segura.
func _pad_diamond(corner: Vector2, p) -> void:
	var c := corner - Vector2(116.0, 116.0)
	var slot := {"y": Vector2(0, -64), "x": Vector2(-64, 0), "a": Vector2(0, 64), "b": Vector2(64, 0)}
	var keys := ["a", "x", "y"]
	for i in 3:
		var id: String = p.order[i]
		var at: Vector2 = c + slot[keys[i]]
		var r := 36.0 if i == 0 else 30.0
		front.draw_texture_rect(ICONS[id], Rect2(at - Vector2(r, r), Vector2(2 * r, 2 * r)), false)
		if p.cds[id] > 0.0:
			_pie(front, at, r * 0.86, p.cds[id] / p.skills[id].cd)
		var sup: String = p.skills[id].support
		if sup != "":
			front.draw_texture_rect(ICONS[sup], Rect2(at + Vector2(r * 0.2, -r * 1.1), Vector2(r * 0.8, r * 0.8)), false)
		_glyph(front, at + Vector2(r * 0.4, r * 0.62), keys[i], 11.0)
	var b: Vector2 = c + slot.b
	front.draw_circle(b, 26.0, Color(0.05, 0.06, 0.06, 0.8))
	_glyph(front, b - Vector2(13, 0), "b", 13.0)
	if hint_action == "" and p.dash_cd > 0.0:
		_pie(front, b, 22.0, p.dash_cd / p.DASH_CD)
	Gothic.draw_centered(front, b.x, b.y + 46.0, hint_action if hint_action != "" else "Pacto" if p.stat("pacto") > 0.0 else "Esquiva", 19, Color(0.95, 0.85, 0.6), 5)


## Linha de texto com botões do comando: "@a" "@b" "@x" "@y" "@lb" "@rb" "@menu" "@view" desenham o botão.
## align: 0 = começa em pos, 0.5 = centrada, 1 = acaba em pos.
func _prompts(ci: CanvasItem, pos: Vector2, parts: Array, size := 18, align := 0.0) -> void:
	# o texto traduz-se sem os espaços à volta (que só servem para separar)
	parts = parts.map(func(s: String): return s if s.begins_with("@") or s.strip_edges() == "" else s.replace(s.strip_edges(), tr(s.strip_edges())))
	size = Gothic.px(size)
	var font := ThemeDB.fallback_font
	var r := size * 0.62
	var w := 0.0
	for s in parts:
		w += (2.0 * r + 2.0 if GLYPH_COL.has(s.substr(1)) else 3.0 * r + 2.0) if s.begins_with("@") else font.get_string_size(s, HORIZONTAL_ALIGNMENT_LEFT, -1, size).x
	var x := pos.x - w * align
	for s in parts:
		if s.begins_with("@"):
			x += _glyph(ci, Vector2(x, pos.y - size * 0.34), s.substr(1), r)
		else:
			ci.draw_string_outline(font, Vector2(x, pos.y), s, HORIZONTAL_ALIGNMENT_LEFT, -1, size, 6, Color.BLACK)
			ci.draw_string(font, Vector2(x, pos.y), s, HORIZONTAL_ALIGNMENT_LEFT, -1, size, Color(0.95, 0.92, 0.85))
			x += font.get_string_size(s, HORIZONTAL_ALIGNMENT_LEFT, -1, size).x


## Um botão do comando desenhado, com o lado esquerdo em at (a meia altura). Devolve a largura gasta.
func _glyph(ci: CanvasItem, at: Vector2, id: String, r: float) -> float:
	var font := ThemeDB.fallback_font
	var dark_bg := Color(0.06, 0.06, 0.06, 0.92)
	if GLYPH_COL.has(id):
		var c := at + Vector2(r, 0)
		ci.draw_circle(c, r, dark_bg)
		ci.draw_arc(c, r, 0, TAU, 24, GLYPH_COL[id], maxf(1.5, r * 0.14), true)
		var s := Gothic.px(int(r * 1.25))
		var l := id.to_upper()
		ci.draw_string(font, c + Vector2(-font.get_string_size(l, HORIZONTAL_ALIGNMENT_LEFT, -1, s).x / 2.0, s * 0.36), l, HORIZONTAL_ALIGNMENT_LEFT, -1, s, GLYPH_COL[id])
		return 2.0 * r + 2.0
	# Botões pequenos em pílula: Menu (≡), Vista (dois quadrados), LB, RB
	var rect := Rect2(at + Vector2(0, -r * 0.78), Vector2(3.0 * r, r * 1.56))
	var h := rect.size.y / 2.0
	ci.draw_circle(rect.position + Vector2(h, h), h, dark_bg)
	ci.draw_circle(rect.end - Vector2(h, h), h, dark_bg)
	ci.draw_rect(Rect2(rect.position + Vector2(h, 0), Vector2(rect.size.x - 2.0 * h, rect.size.y)), dark_bg)
	var col := Color(0.92, 0.9, 0.84)
	var c := rect.get_center()
	var line := maxf(1.4, r * 0.15)
	match id:
		"menu":
			for k in [-1, 0, 1]:
				ci.draw_line(c + Vector2(-r * 0.55, k * r * 0.36), c + Vector2(r * 0.55, k * r * 0.36), col, line)
		"view":
			var q := r * 0.62
			ci.draw_rect(Rect2(c + Vector2(-q * 0.8, -q * 0.65), Vector2(q, q * 0.85)), col, false, line)
			ci.draw_rect(Rect2(c + Vector2(-q * 0.2, -q * 0.2), Vector2(q, q * 0.85)), col, false, line)
		_:
			var l := id.to_upper()
			var s := Gothic.px(int(r * 1.05))
			ci.draw_string(font, c + Vector2(-font.get_string_size(l, HORIZONTAL_ALIGNMENT_LEFT, -1, s).x / 2.0, s * 0.36), l, HORIZONTAL_ALIGNMENT_LEFT, -1, s, col)
	return 3.0 * r + 2.0


## Uma poção: o frasco (apagado sem cargas), o número de cargas e a barra da próxima carga.
func _potion(c: Vector2, kind: String, p) -> void:
	var tex: Texture2D = ICONS["potion_" + kind]
	var n: float = p.potions[kind]
	var h := 50.0
	var w := h * tex.get_width() / tex.get_height()
	var col := Color.WHITE if n >= 1.0 else Color(0.4, 0.4, 0.4, 0.8)
	if kind == "hp" and p.stat("sangue") > 0.0:  # Sangue Negro (#117): a poção de vida não faz nada, fica escura
		col = Color(0.45, 0.08, 0.12)
	overlay.draw_texture_rect(tex, Rect2(c.x - w / 2.0, c.y - h / 2.0 - 6.0, w, h), false, col)
	Gothic.draw(overlay, Vector2(c.x + 8, c.y + 20), str(int(n)), 22, Color(1.0, 0.95, 0.8), 5)
	if n < p.POTION_MAX:
		overlay.draw_rect(Rect2(c.x - 18, c.y + 26, 36, 4), Color(0, 0, 0, 0.7))
		overlay.draw_rect(Rect2(c.x - 18, c.y + 26, 36 * (n - floorf(n)), 4), Color(1.0, 0.85, 0.4))
	if gamepad:  # LB por fora da poção da esquerda, RB por fora da da direita
		_glyph(overlay, Vector2(c.x - 50.0 if kind == "hp" else c.x + 20.0, c.y - 30), "lb" if kind == "hp" else "rb", 10.0)


## Retrato redondo dentro do anel ornamentado (o buraco do anel tem 68% da largura).
func _portrait(pl, c: Vector2, r: float) -> void:
	overlay.draw_circle(c, r, Color(0.05, 0.06, 0.06))
	overlay.draw_texture_rect(pl.portrait, Rect2(c - Vector2(r, r), Vector2(2 * r, 2 * r)), false, Color(0.45, 0.45, 0.45) if pl.dead else Color.WHITE)
	var w := 2.0 * r / 0.68
	var h: float = w * UI.ring.get_height() / UI.ring.get_width()
	overlay.draw_texture_rect(UI.ring, Rect2(c.x - w * 0.498, c.y - h * 0.499, w, h), false)


## Barra de vida: cor diz o estado (verde/amarelo/vermelho) e o pedaço claro mostra o que se perdeu.
## A barreira de ossos (Medula Sacrificial) é o pedaço cor de osso a seguir à vida.
func _life_bar(r: Rect2, p) -> void:
	var frac: float = maxf(p.hp, 0.0) / p.max_hp
	r.position.x += 4.0 * p.hurt / 0.2  # a barra leva um empurrão ao sofrer dano
	var col := Color(0.35, 0.85, 0.4) if frac > 0.6 else (Color(0.95, 0.75, 0.2) if frac > 0.3 else Color(0.85, 0.1, 0.12))
	overlay.draw_rect(r.grow(2.0), Color(0.12, 0.1, 0.08))
	overlay.draw_rect(r, Color(0.1, 0.02, 0.02))
	overlay.draw_rect(Rect2(r.position, Vector2(r.size.x * minf(p.hp_chunk / p.max_hp, 1.0), r.size.y)), Color(1.0, 0.85, 0.55))
	overlay.draw_rect(Rect2(r.position, Vector2(r.size.x * frac, r.size.y)), col)
	var bf: float = p.barrier / p.max_hp
	if bf > 0.0:  # com a vida quase cheia, a barreira entra por cima do fim da barra em vez de sair dela
		overlay.draw_rect(Rect2(r.position.x + r.size.x * minf(frac, 1.0 - bf), r.position.y, r.size.x * bf, r.size.y), Color(0.8, 0.88, 0.96))  # osso frio: não se confunde com o pedaço amarelo da vida perdida


## Instabilidade de Alma: a corrupção num fio roxo; na Sobrecarga brilha a pulsar e mostra o tempo que falta.
func _corruption_bar(r: Rect2, p) -> void:
	var over: bool = p.overload_t > 0.0
	overlay.draw_rect(r, Color(0.04, 0.02, 0.06))
	r.size.x *= p.overload_t / p.OVERLOAD_T if over else minf(p.corruption / 100.0, 1.0)
	overlay.draw_rect(r, Color(0.95, 0.55, 1.0, 0.7 + 0.3 * sin(Time.get_ticks_msec() * 0.02)) if over else Color(0.55, 0.25, 0.85))


## Orbe: o vidro da textura recortado num círculo, escuro por cima do nível e cheio por baixo.
func _orb(c: Vector2, r: float, frac: float, tex: Texture2D) -> void:
	var full := PackedVector2Array()
	for i in 40:
		full.append(c + Vector2.from_angle(i * TAU / 40.0) * r)
	overlay.draw_colored_polygon(full, Color(0.22, 0.22, 0.22), _orb_uv(full, c, r, tex), tex)
	if frac <= 0.0:
		return
	var level := c.y + r - 2.0 * r * clampf(frac, 0.0, 1.0)
	var pts := PackedVector2Array()
	for q in full:
		pts.append(Vector2(q.x, maxf(q.y, level)))
	overlay.draw_colored_polygon(pts, Color.WHITE, _orb_uv(pts, c, r, tex), tex)


func _orb_uv(pts: PackedVector2Array, c: Vector2, r: float, tex: Texture2D) -> PackedVector2Array:
	var uv := PackedVector2Array()
	var ky := 0.4 * tex.get_width() / tex.get_height()
	for q in pts:
		uv.append(Vector2(0.5 + (q.x - c.x) / r * 0.4, 0.5 + (q.y - c.y) / r * ky))
	return uv


## Barra do chefe na placa da SC-UI2 (o nome por cima): enche do zero quando ele aparece, com o pedaço de dano.
func _boss_bar(e, vs: Vector2, y: float) -> void:
	var w := 460.0
	var h: float = w * UI.bar.get_height() / UI.bar.get_width()
	var r := Rect2(vs.x * 0.5 - w / 2.0, y, w, h)
	var name: String = e.title if e.title != "" else e.NAMES.get(e.kind, "Chefe")
	front.draw_texture_rect(UI.bar, r, false)
	var inner := Rect2(r.position.x + w * 0.095, r.position.y + h * 0.3125, w * 0.8125, h * 0.375)  # a ranhura da placa
	front.draw_rect(inner, Color(0.08, 0.02, 0.02))
	front.draw_rect(Rect2(inner.position, Vector2(inner.size.x * minf(e.bar_fill, e.hp_chunk / e.max_hp), inner.size.y)), Color(1.0, 0.85, 0.55))
	front.draw_rect(Rect2(inner.position, Vector2(inner.size.x * minf(e.bar_fill, maxf(e.hp, 0.0) / e.max_hp), inner.size.y)), Color(0.75, 0.08, 0.12))
	Gothic.draw_centered(front, vs.x * 0.5, r.position.y + h * 0.12, name, 21, Color(1.0, 0.85, 0.55), 5)
	# Postura (#16): enche com os golpes; cheia, o chefe fica quebrado (a barra pisca a branco)
	var pr := Rect2(inner.position.x, inner.end.y + 5.0, inner.size.x, 5.0)
	front.draw_rect(pr, Color(0.05, 0.04, 0.02, 0.85))
	if e.stagger_t > 0.0:
		front.draw_rect(Rect2(pr.position, Vector2(pr.size.x * e.stagger_t / e.STAGGER_T, pr.size.y)), Color(1, 1, 1, 0.6 + 0.4 * sin(Time.get_ticks_msec() * 0.02)))
	else:
		front.draw_rect(Rect2(pr.position, Vector2(pr.size.x * minf(e.posture, 1.0), pr.size.y)), Color(1.0, 0.85, 0.35))


## Texto centrado: gótico (títulos, nomes, números) ou a letra normal para frases pequenas.
func _centered(text: String, y: float, size: int, col: Color, vs: Vector2, gothic := true) -> void:
	text = tr(text)
	if gothic:
		Gothic.draw_centered(front, vs.x * 0.5, y, text, size, col, maxi(5, size / 7))
		return
	var font := ThemeDB.fallback_font
	size = Gothic.px(size)
	var x: float = vs.x * 0.5 - font.get_string_size(text, HORIZONTAL_ALIGNMENT_LEFT, -1, size).x / 2.0
	front.draw_string_outline(font, Vector2(x, y), text, HORIZONTAL_ALIGNMENT_LEFT, -1, size, maxi(4, size / 6), Color(0, 0, 0, col.a))
	front.draw_string(font, Vector2(x, y), text, HORIZONTAL_ALIGNMENT_LEFT, -1, size, col)


## Cartão do chefe: o nome entra a "bater" (grande e encolhe), numa faixa escura.
func _name_card(vs: Vector2) -> void:
	var k := 1.0 - card_t / CARD_T
	var pop := 1.0 + 0.7 * maxf(0.0, 1.0 - k / 0.05)
	var a := clampf(card_t / 0.5, 0.0, 1.0)
	var cy := vs.y * 0.33
	front.draw_rect(Rect2(0, cy - 62, vs.x, 116), Color(0, 0, 0, 0.45 * a))
	_centered("Chefe", cy - 32, 22, Color(1.0, 0.3, 0.3, a), vs)
	_centered(card_name, cy + 16, int(62 * pop), Color(0.85, 1.0, 0.85, a), vs)
	_centered(card_sub, cy + 44, 17, Color(0.75, 0.75, 0.7, a), vs, false)


## Subida de nível: texto grande a saltar e depois as recompensas, uma a uma.
func _level_card(vs: Vector2) -> void:
	var k := 1.0 - lvl_t / LVL_T
	var a := clampf(lvl_t / 0.4, 0.0, 1.0)
	var pop := 1.0 + 0.6 * maxf(0.0, 1.0 - k / 0.06)
	var cy := vs.y * 0.6  # por baixo do herói, para não tapar o cartão do chefe nem os avisos
	_centered(tr("Nível %d!") % main.level, cy, int(66 * pop), Color(1.0, 0.85, 0.4, a), vs)
	var lines := ["+1 Ponto na Árvore dos Condenados", "+8 Vida máxima"]
	for i in lines.size():
		var start := 0.2 + i * 0.12
		if k > start:
			var lp := 1.0 + 0.4 * maxf(0.0, 1.0 - (k - start) / 0.05)
			_centered(lines[i], cy + 36 + i * 28, int(19 * lp), Color(0.9, 1.0, 0.85, a), vs, false)


## Cartão de ajuda: [título, texto] do botão seguro, com os números de agora. Texto vazio = sem cartão
## (Abrir, Descer, Subir e Invocar: o aviso em cima já diz o que fazem).
func _info_text(key: String) -> Array:
	var p = main.player
	var lines := []
	var title := ""
	if p.skills.has(key):
		var s: Dictionary = p.skills[key]
		var n: Array = p.skill_numbers(key)
		title = s.name
		lines.append(tr(SKILL_INFO[key]))
		if key == "bonearmor":
			lines.append(tr("Recarga %s s") % _dec(n[2], 1))
		elif key == "bolt":  # os 16 px da Lança são o raio do golpe, não uma área
			lines.append(tr("Dano %s · recarga %s s") % [_dec(n[0], 0), _dec(n[2], 1)])
		else:
			lines.append(tr("Dano %s · área %d px · recarga %s s") % [_dec(n[0], 0), int(n[1]), _dec(n[2], 1)])
		if s.support == "parasita":
			lines.append(tr("Paga %d de vida em vez de alma") % int(maxf(s.mana * 1.5, 6.0)))
		elif p.stat("fragmentada") > 0.0 and s.mana > 0.0:
			lines.append(tr("Mente Fragmentada: gasta %s de uma carga da poção de alma") % _dec(s.mana / 60.0))
		elif s.mana > 0.0:
			lines.append(tr("Custo: %d de alma") % int(s.mana))
		else:
			lines.append(tr("Sem custo"))
		lines.append(_flask_line(s.support))
	elif key == "interact" and hint_action == "":
		title = "Esquiva Espectral"
		lines.append(tr("Salto de %d px para onde o joystick aponta (ou para a frente); não levas dano durante o salto. Recarga %s s.") % [int(p.DASH_SPEED * p.DASH_T), _dec(p.DASH_CD, 1)])
		lines.append(tr("Esquiva perfeita: esquivar um golpe no momento certo deixa quem bateu exposto (triplo do dano)."))
		lines.append(tr("Deslizar depressa o dedo fora do joystick também esquiva."))
		if p.stat("pacto") > 0.0:
			lines.append(_passive_line("pacto"))
		if p.wears("martir"):
			lines.append(_flask_line("martir"))
	elif key == "interact":
		title = hint_action
		if hint_action == "Executar":
			lines.append(tr("Execução Espectral: um morto com menos de %d%% de vida tem a alma exposta (losango a pulsar). Mata-o de vez, +15 de alma e cura 5%% da vida.") % int(Enemy.EXECUTE_AT * 100.0))
		elif hint_action == "Extrair":
			lines.append(tr("Alma Ancestral: um chefe quebrado deixa extrair a alma: +3 Ossos e +30 de alma."))
	elif key == "tree":
		title = "Árvore dos Condenados"
		lines.append(tr("Abre a árvore de poderes do herói: gasta aqui os pontos que ganhas em cada nível."))
		lines.append(tr("Pontos por gastar: %d") % p.points)
	elif key == "arsenal":
		title = "Arsenal"
		lines.append(tr("Abre o Arsenal: melhora a foice com Tinteiros, Cinzas e Ossos e escolhe o Frasco de Alma de cada habilidade."))
		lines.append(main.weapon_text())
	elif key == "menu":
		title = "Menu"
		lines.append(tr("Abre o menu e põe o jogo em pausa: Bestiário, Configurações, Gravar e Menu principal."))
	elif key == "stance":
		title = "Postura de Combate"
		lines.append(tr("Agora: %s") % tr(STANCE_INFO[p.stance]))
		lines.append(tr("Toca para passar a: %s") % tr(STANCE_INFO["ira" if p.stance == "guarda" else "guarda"]))
		if p.stat("grito") > 0.0:
			lines.append(_passive_line("grito"))
	elif key == "potion_hp":
		title = "Poção de Vida"
		lines.append(tr("Cura 40%% da vida máxima (%d). Cargas: %s/3 — cada abate dá ¼, um chefe dá 1. Não se bebe com a vida cheia.") % [int(p.max_hp * 0.4), _dec(p.potions.hp)])
		for k in ["sangue", "lich"]:
			if p.stat(k) > 0.0:
				lines.append(_passive_line(k))
		if p.wears("roubo"):
			lines.append(_flask_line("roubo"))
	elif key == "potion_mp":
		title = "Poção de Alma"
		lines.append(tr("Dá 60%% da alma máxima (%d). Cargas: %s/3 — cada abate dá ¼, um chefe dá 1. Não se bebe com a alma cheia.") % [int(p.max_mana * 0.6), _dec(p.potions.mp)])
		for k in ["fragmentada", "lich"]:
			if p.stat(k) > 0.0:
				lines.append(_passive_line(k))
		if p.wears("roubo"):
			lines.append(_flask_line("roubo"))
	return [title, "\n".join(lines)]


func _flask_line(f: String) -> String:
	return tr("Frasco: %s — %s") % [tr(main.player.SUPPORT_NAMES[f]), tr(main.player.SUPPORT_DESC[f])]


func _passive_line(id: String) -> String:
	return "%s: %s" % [tr(main.PASSIVES[id].name), tr(main.PASSIVES[id].desc)]


## O cartão ao lado do botão seguro (à esquerda dele; no canhoto, à direita; os do canto de cima, sempre à esquerda),
## dentro da margem segura.
func _info_card(b: Button, t: Array) -> void:
	var sr := safe.get_global_rect()
	var br := b.get_global_rect()
	var w := 520.0  # mais largo que antes: a Augusta a 25 px pede mais espaço por linha
	var h: float = 64.0 + Gothic.BODY.get_multiline_string_size(t[1], HORIZONTAL_ALIGNMENT_LEFT, w - 28.0, Gothic.CARD_SIZE).y
	var at := Vector2(br.end.x + 16.0 if lefty and pad.is_ancestor_of(b) else br.position.x - w - 16.0, br.get_center().y - h / 2.0)
	at = at.clamp(sr.position, sr.end - Vector2(w, h))
	var sb := StyleBoxFlat.new()
	sb.bg_color = Color(0.04, 0.07, 0.07, 0.92)
	sb.border_color = Color(0.85, 0.8, 0.65)
	sb.set_border_width_all(3)
	sb.set_corner_radius_all(8)
	front.draw_style_box(sb, Rect2(at, Vector2(w, h)))
	Gothic.draw(front, at + Vector2(14.0, 14.0 + Gothic.FONT.get_ascent(32)), t[0], 32, Color(1.0, 0.85, 0.55), 5)
	# corpo na Augusta: a Alkhemikal a 16 ou 19 px lia-se mal no telemóvel (o título fica na gótica, a 32)
	front.draw_multiline_string(Gothic.BODY, at + Vector2(14.0, 54.0 + Gothic.BODY.get_ascent(Gothic.CARD_SIZE)), t[1], HORIZONTAL_ALIGNMENT_LEFT, w - 28.0, Gothic.CARD_SIZE, -1, Color(0.88, 0.84, 0.72))


# ---------- Painéis ----------

## cancel: o B do comando (ou o Voltar do Android) fecha o painel.
## back = para onde B / Voltar levam (vazio: fecha o painel e volta ao jogo).
func _open_panel(title: String, cancel := true, back := Callable()) -> VBoxContainer:
	close_panel()
	get_tree().paused = true
	panel_cancel = cancel
	panel_back = back
	panel_frame = Engine.get_process_frames()
	for p in main.players:
		p.held.clear()
	var pc := PanelContainer.new()
	panel = pc
	root.add_child(pc)
	var box := VBoxContainer.new()
	box.add_theme_constant_override("separation", 6)
	pc.add_child(box)
	# Título do painel em letra gótica (desenhado, para os acentos saírem na mesma letra)
	var t := Control.new()
	t.custom_minimum_size = Vector2(Gothic.width(title, 32) + 10, 42)
	t.draw.connect(func(): Gothic.draw(t, Vector2(0, 33), title, 32, Color(0.95, 0.8, 0.5), 6))
	box.add_child(t)
	pc.set_anchors_and_offsets_preset(Control.PRESET_CENTER)
	pc.grow_horizontal = Control.GROW_DIRECTION_BOTH
	pc.grow_vertical = Control.GROW_DIRECTION_BOTH
	return box


func close_panel() -> void:
	if panel:
		panel.queue_free()
		panel = null
	panel_cancel = false
	panel_back = Callable()
	get_tree().paused = false
	for p in main.players:
		p.lock_skills = true  # o A que fechou o painel não sai como ataque
	closed_frame = Engine.get_process_frames()  # nem o B que o fechou sai como esquiva (ou volta a abrir o Cortejo)
	if not title_open:
		main.save_game()  # o que se gastou ou escolheu no painel fica logo gravado


## Alguém perdeu o comando: pausa com aviso (Continuar no ecrã ou com outro comando).
func pad_lost(who: String, first: bool) -> void:
	if first:
		gamepad = false
	if panel != null:
		toast(tr("O comando do %s desligou-se.") % tr(who))
		return
	var box := _open_panel("Comando desligado")
	_text(box, tr("O comando do %s desligou-se.\nVolta a ligá-lo, ou continua com os controlos no ecrã.") % tr(who))
	_button(box, "Continuar", close_panel).grab_focus()


## Botão/gesto Voltar do Android: volta atrás no painel aberto ou abre o Menu (que pausa o jogo), em vez de sair.
## A app vai para segundo plano a meio do jogo (só no telemóvel): ao voltar está em pausa no Menu.
func _notification(what: int) -> void:
	if what == NOTIFICATION_APPLICATION_PAUSED and main != null and panel == null and intro_i < 0 and not title_open:
		open_menu()
	elif what == NOTIFICATION_WM_GO_BACK_REQUEST and main != null:
		if panel == null:
			open_menu()
		elif panel_cancel:
			_back()


func _back() -> void:
	if panel_back.is_valid():
		panel_back.call()
	else:
		close_panel()


## Arsenal e Árvore abertos direto (barra do ecrã; no comando LS e Vista/RS): B volta ao jogo.
func _arsenal() -> void:
	sub_back = Callable()
	open_arsenal()


func _tree(who := 0) -> void:
	sub_back = Callable()
	open_tree(who)


func _text(box: Control, text: String, col := Color(0.8, 0.8, 0.75)) -> void:
	var l := Label.new()
	l.text = text
	l.add_theme_color_override("font_color", col)
	box.add_child(l)


func _button(box: Control, text: String, cb: Callable, icon: Texture2D = null, width := 560.0) -> Button:
	var b := Button.new()
	b.text = text
	b.custom_minimum_size = Vector2(width, 52)
	b.icon = icon
	b.add_theme_constant_override("icon_max_width", 28)
	b.pressed.connect(cb)
	box.add_child(b)
	return b


func _art(tex: Texture2D, size: Vector2) -> TextureRect:
	var r := TextureRect.new()
	r.texture = tex
	r.custom_minimum_size = size
	r.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	r.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_COVERED
	r.clip_contents = true
	return r


## Ecrã de título com a arte de capa: Continuar (se há jogo gravado), Novo jogo, Co-op, Configurações e Sobre.
func open_title() -> void:
	main.play_track("title")
	title_open = true
	close_panel()
	get_tree().paused = true
	var c := Control.new()
	c.set_anchors_preset(Control.PRESET_FULL_RECT)
	var bg := _art(TITLE_ART, Vector2.ZERO)
	bg.set_anchors_preset(Control.PRESET_FULL_RECT)
	c.add_child(bg)
	var logo := VBoxContainer.new()
	logo.anchor_right = 1.0
	logo.offset_top = 24
	logo.offset_bottom = 150
	c.add_child(logo)
	for l in [["Soulstrider", 112, Color(0.88, 0.97, 0.88)], ["Necro-Dominion", 38, Color(0.45, 1.0, 0.65)]]:
		var lb := Label.new()
		lb.text = l[0]
		lb.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		lb.add_theme_font_override("font", Gothic.FONT)
		lb.add_theme_font_size_override("font_size", Gothic.px(l[1]))
		lb.add_theme_color_override("font_color", l[2])
		lb.add_theme_color_override("font_outline_color", Color.BLACK)
		lb.add_theme_constant_override("outline_size", 14)
		logo.add_child(lb)
	var menu := VBoxContainer.new()
	menu.anchor_left = 0.5
	menu.anchor_right = 0.5
	menu.anchor_top = 1.0
	menu.anchor_bottom = 1.0
	menu.offset_left = -200
	menu.offset_right = 200
	menu.offset_top = -190
	menu.offset_bottom = -24
	menu.add_theme_constant_override("separation", 10)
	menu.grow_vertical = Control.GROW_DIRECTION_BEGIN  # com o botão de atualizar, cresce para cima
	c.add_child(menu)
	title_menu = menu
	var ver := _label(Vector2.ZERO, 18)
	ver.reparent(c)
	ver.text = tr("Versão %s") % AppUpdate.VERSION_NAME
	ver.set_anchors_and_offsets_preset(Control.PRESET_TOP_RIGHT)
	ver.offset_left = -140
	ver.offset_top = 8
	ver.offset_right = -12
	ver.offset_bottom = 28
	ver.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	ver.add_theme_color_override("font_color", Color(1, 1, 1, 0.55))
	var coop := func():
		_play()
		if main.players.size() < 2:
			main.add_player()
	var items := [[tr("Continuar · Nível %d") % main.level, _play]] if main.has_save() else []
	items += [["Novo jogo", _new_game], ["Co-op local — 2 jogadores", coop], ["Co-op por Wi-Fi", open_lan],
		["Configurações", func(): open_settings(0, open_title)], ["Sobre", func(): open_about(open_title)]]
	var first: Button
	for it in items:
		var b := _button(menu, it[0], it[1], null, 400.0)
		b.add_theme_font_override("font", Gothic.FONT)
		b.add_theme_font_size_override("font_size", Gothic.px(24))
		b.custom_minimum_size.y = 46
		if first == null:
			first = b
	# Legenda: com comando mostra os botões; no ecrã tátil basta tocar
	var tip := Control.new()
	tip.custom_minimum_size = Vector2(400, 24)
	tip.draw.connect(func():
		var parts := ["@a", " Escolher      ", "2.º comando: ", "@menu", " entra o Guardião"] if gamepad else ["Toca para escolher  ·  com comandos, cada jogador usa o seu"]
		_prompts(tip, Vector2(200, 17), parts, 15, 0.5))
	menu.add_child(tip)
	# Primeiro só a arte, o nome e "Toca para começar" (com Configurações e Sobre nos cantos); um toque em
	# qualquer sítio, ou A, mostra o menu. O botão invisível do ecrã inteiro fica por baixo dos outros.
	var shade := TextureRect.new()
	var grad := GradientTexture2D.new()
	grad.gradient = Gradient.new()
	grad.gradient.colors = PackedColorArray([Color(0, 0, 0, 0), Color(0, 0, 0, 0.85)])
	grad.fill_to = Vector2(0, 1)
	shade.texture = grad
	shade.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	shade.mouse_filter = Control.MOUSE_FILTER_IGNORE
	shade.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_WIDE)
	shade.offset_top = -240
	c.add_child(shade)
	c.move_child(shade, 1)
	var start := Button.new()
	start.flat = true
	start.set_anchors_preset(Control.PRESET_FULL_RECT)
	start.add_theme_stylebox_override("focus", StyleBoxEmpty.new())
	c.add_child(start)
	c.move_child(start, 2)
	var press := Control.new()
	press.set_anchors_preset(Control.PRESET_FULL_RECT)
	press.mouse_filter = Control.MOUSE_FILTER_IGNORE
	press.draw.connect(func():
		if gamepad:
			_prompts(press, Vector2(press.size.x / 2.0, press.size.y - 58.0), ["@a", " Começar"], 30, 0.5)
		else:
			Gothic.draw_centered(press, press.size.x / 2.0, press.size.y - 50.0, "Toca para começar", 48, Color(0.93, 0.89, 0.77), 8))
	c.add_child(press)
	var pulse := press.create_tween().set_loops()
	pulse.tween_property(press, "modulate:a", 0.35, 0.9)
	pulse.tween_property(press, "modulate:a", 1.0, 0.9)
	var corners := []
	for k in [["Configurações", func(): open_settings(0, open_title), 0.0, 24.0], ["Sobre", func(): open_about(open_title), 1.0, -264.0]]:
		var b := _button(c, k[0], k[1], null, 240.0)
		b.focus_mode = Control.FOCUS_NONE
		b.add_theme_font_override("font", Gothic.FONT)
		b.add_theme_font_size_override("font_size", Gothic.px(24))
		b.anchor_left = k[2]
		b.anchor_right = k[2]
		b.anchor_top = 1.0
		b.anchor_bottom = 1.0
		b.offset_left = k[3]
		b.offset_right = k[3] + 240.0
		b.offset_top = -70.0
		b.offset_bottom = -22.0
		corners.append(b)
	title_reveal = func():
		for n in [start, press] + corners:
			n.queue_free()
		menu.visible = true
		first.grab_focus()
	start.pressed.connect(title_reveal)
	menu.visible = false
	root.add_child(c)
	panel = c
	panel_cancel = false
	panel_frame = Engine.get_process_frames()
	start.grab_focus()
	if not updater.info.is_empty():
		_on_update(updater.info)
	Net.stop_scan()
	if Engine.has_meta("net_note"):
		title_reveal.call()
		toast(Engine.get_meta("net_note"))
		Engine.remove_meta("net_note")


## Co-op por Wi-Fi: um telemóvel cria a sala e joga como Strider; o outro, na mesma rede, vê-a aparecer e
## entra como Guardião. Se a rede não deixar ver a sala, entra-se pelo IP que o anfitrião vê no Menu.
func open_lan() -> void:
	var box := _open_panel("Co-op por Wi-Fi", true, open_title)
	_text(box, "Os dois telemóveis na mesma rede Wi-Fi: um cria a sala e é o Strider, o outro entra e é o Guardião.")
	var make := func():
		if Net.host() != OK:
			toast("Não deu para abrir a sala. A Wi-Fi está ligada?")
			return
		_play()
		toast(tr("Sala aberta (%s). No outro telemóvel: Co-op por Wi-Fi.") % Net.my_ip())
	_button(box, "Criar sala", make, null, 460.0).grab_focus()
	var list := VBoxContainer.new()
	box.add_child(list)
	var ip := LineEdit.new()
	ip.placeholder_text = tr("ou escreve o IP da sala")
	ip.custom_minimum_size = Vector2(460, 44)
	ip.alignment = HORIZONTAL_ALIGNMENT_CENTER
	for st in ["normal", "focus"]:
		var sb := StyleBoxFlat.new()
		sb.bg_color = Color(0.03, 0.04, 0.04, 0.9)
		sb.border_color = Color(0.45, 1.0, 0.65) if st == "focus" else Color(0.5, 0.45, 0.35)
		sb.set_border_width_all(2)
		sb.set_corner_radius_all(4)
		ip.add_theme_stylebox_override(st, sb)
	box.add_child(ip)
	_button(box, "Entrar por IP", func(): _join(ip.text.strip_edges()), null, 460.0)
	_button(box, "Voltar", _back, null, 460.0)
	Net.scan()
	var shown := [null]  # só refaz a lista quando as salas mudam (não rouba o foco ao comando)
	var refresh := func():
		var key := str(Net.rooms.keys())
		if key == shown[0]:
			return
		shown[0] = key
		for c in list.get_children():
			c.queue_free()
		if Net.rooms.is_empty():
			_text(list, "À procura de salas na rede…")
		for addr in Net.rooms:
			_button(list, tr("Entrar na sala %s (Nv %d)") % [addr, Net.rooms[addr].level], _join.bind(addr), null, 460.0)
	refresh.call()
	var timer := Timer.new()
	timer.wait_time = 0.5
	timer.autostart = true
	timer.timeout.connect(refresh)
	box.add_child(timer)


func _join(addr: String) -> void:
	if not addr.is_valid_ip_address():
		toast("Esse IP não parece certo.")
	elif Net.join(addr) != OK:
		toast("Não foi possível entrar na sala.")
	else:
		toast(tr("A ligar a %s…") % addr)


## Do título para o jogo (Continuar, Novo jogo sem nada gravado, Co-op).
func _play() -> void:
	title_open = false
	close_panel()


## Abertura (opening.gd), sempre que o jogo abre; depois segue para then (a intro da 1.ª vez, ou o título).
func open_opening(then: Callable) -> void:
	main.play_track("title")
	title_open = true  # antes do título ainda não há jogo para gravar
	close_panel()
	get_tree().paused = true
	var o := Opening.new()
	o.set_anchors_preset(Control.PRESET_FULL_RECT)
	root.add_child(o)
	panel = o
	panel_cancel = false
	o.finished.connect(func(): then.call_deferred())


## Intro animada (intro.gd): 4 planos com faixas de cinema e legenda. Passa sozinha (cada plano tem a sua
## duração), ou com toque/A; segurar o dedo, B ou Menu salta. Abre-se da 1.ª vez e no Sobre.
func open_intro() -> void:
	main.play_track("title")
	title_open = true  # ao fechar a intro (para o título) não se grava um jogo vazio
	close_panel()
	get_tree().paused = true
	var c := Intro.new()
	c.set_anchors_preset(Control.PRESET_FULL_RECT)
	root.add_child(c)
	panel = c
	panel_cancel = false
	var vs := root.get_viewport_rect().size
	var hint := Control.new()
	hint.set_anchors_preset(Control.PRESET_FULL_RECT)
	hint.mouse_filter = Control.MOUSE_FILTER_IGNORE
	hint.draw.connect(func():
		_prompts(hint, vs - Vector2(28, 26), ["@a", " Seguinte   ", "@b", " Saltar"] if gamepad else ["Toca para continuar · segura para saltar"], 16, 1.0)
		if intro_hold > 0.0:  # a barra enche enquanto o dedo segura
			hint.draw_rect(Rect2(vs.x - 228.0, vs.y - 54.0, 200.0 * minf(intro_hold / HOLD_SKIP, 1.0), 4.0), Color(0.45, 1.0, 0.65)))
	c.add_child(hint)
	intro_hint = hint
	intro_i = -1
	_intro_next()


func _intro_next() -> void:
	intro_i += 1
	if intro_i >= Intro.SHOTS.size():
		_intro_end()
		return
	panel_frame = Engine.get_process_frames()
	intro_t = Intro.SHOTS[intro_i][1]
	panel.play(intro_i)
	intro_hint.queue_redraw()


func _intro_end() -> void:
	intro_i = -1
	intro_hold = -1.0
	main.set_setting("intro_seen", true)
	open_title.call_deferred()  # o toque ou botão que acabou a intro não carrega já num botão do título


## Novo jogo: sem jogo gravado começa logo; com jogo gravado pede confirmação (apaga o progresso).
func _new_game() -> void:
	if not main.has_save():
		_play()
		return
	var box := _open_panel("Novo jogo", true, open_title)
	_text(box, "Começar de novo apaga o jogo gravado: nível, moedas, arma,\nÁrvore dos Condenados e Frascos de Alma. As configurações ficam.")
	var wipe := _button(box, "Apagar e começar de novo", main.new_game)
	wipe.add_theme_color_override("font_color", Color(1.0, 0.55, 0.5))
	wipe.add_theme_color_override("font_focus_color", Color(1.0, 0.65, 0.6))
	_button(box, "Voltar", open_title).grab_focus()


## Menu do jogo (Menu no comando, botão Menu no ecrã ou Voltar do Android): o jogo fica em pausa.
func open_menu(focus := 0, note := "") -> void:
	var box := _open_panel("Menu")
	var arsenal := func():
		sub_back = open_menu.bind(1)
		open_arsenal()
	var tree := func():
		sub_back = open_menu.bind(2)
		open_tree()
	var bestiary := func(): open_bestiary(open_menu.bind(3))
	var save := func():
		main.save_game()
		open_menu(4, tr("Jogo gravado às %s.") % Time.get_time_string_from_system().left(5))
	var to_title := func():
		main.save_game()
		main.restart(true)
	var unstuck := func():
		main.unstuck()
		close_panel()
	var items := [["Voltar ao jogo", close_panel], ["Arsenal", arsenal], ["Árvore dos Condenados", tree],
		["Bestiário", bestiary], ["Gravar", save], ["Configurações", func(): open_settings(0, open_menu.bind(5))],
		["Soltar personagem", unstuck], ["Menu principal", to_title]]
	if Net.is_guest():
		items = [["Voltar ao jogo", close_panel], ["Arsenal", arsenal], ["Árvore dos Condenados", tree],
			["Bestiário", bestiary], ["Configurações", func(): open_settings(0, open_menu.bind(4))],
			["Sair da sala", func(): main.restart(true)]]
		focus = mini(focus, 4)
	elif Net.role == "host" and note == "":
		note = tr("Sala Wi-Fi aberta: %s") % Net.my_ip()
	var btns := []
	for it in items:
		btns.append(_button(box, it[0], it[1], null, 420.0))
	if note != "":
		_text(box, note, Color(0.45, 1.0, 0.65))
	btns[focus].grab_focus()


## Configurações em separadores. Cada opção aplica-se logo e fica gravada à parte do jogo.
func open_settings(tab := 0, back := Callable()) -> void:
	var box := _open_panel("Configurações", true, back)
	var tabs := HBoxContainer.new()
	tabs.add_theme_constant_override("separation", 6)
	box.add_child(tabs)
	var here: Button
	for i in TABS.size():
		var b := _button(tabs, TABS[i], func(): open_settings(i, back), null, 100.0)
		if i == tab:
			b.add_theme_stylebox_override("normal", _sbt(UI.btn_on, Color.WHITE))
			b.add_theme_color_override("font_color", Color.WHITE)
			here = b
	var rows := VBoxContainer.new()
	rows.add_theme_constant_override("separation", 6)
	rows.custom_minimum_size = Vector2(620, 208)
	box.add_child(rows)
	match tab:
		0:
			_slider(rows, "Volume geral", "master")
			_slider(rows, "Música", "music")
			_slider(rows, "Efeitos sonoros", "sfx")
		1:
			_choice(rows, "Limite de FPS", "fps", ["30 · poupa bateria", "60", "O máximo do ecrã"])
			_choice(rows, "Resolução", "res", ["Alta", "Poupança (720p)"])
			_choice(rows, "Efeitos visuais", "effects", ["Baixos", "Médios", "Altos"])
			_choice(rows, "Mostrar FPS", "show_fps", ["Não", "Sim"])
			_choice(rows, "Proteção térmica", "thermal", ["Desligada", "Automática"])
			_choice(rows, "Quantidade de monstros", "density", ["Baixa", "Média", "Alta"])
		2:
			_choice(rows, "Idioma", "lang", ["Português", "English"], func(): open_settings(2, back))  # refaz o painel já no idioma novo
			_choice(rows, "Estilo das personagens", "pixel32", ["Pintado", "32-bit"])
			_choice(rows, "Ataque automático", "auto_attack", ["Desligado", "Ligado"])
			_choice(rows, "Mira automática", "boss_aim", ["O mais perto", "Chefes primeiro"])
			_choice(rows, "Números de dano", "numbers", ["Escondidos", "À vista"])
			_choice(rows, "Nomes no chão", "loot_names", ["Todos", "Só os raros"])
		3:
			_choice(rows, "Tamanho dos botões", "ui", ["100%", "130%", "160%"])
			_choice(rows, "Opacidade dos botões", "opacity", ["100%", "75%", "50%"])
			_choice(rows, "Botões de poção", "potion_ui", ["100%", "125%", "150%"])
			_choice(rows, "Botões no ecrã", "lefty", ["À direita", "À esquerda (canhoto)"])
			_choice(rows, "Joystick", "joy_fixed", ["Onde tocas", "Fixo no canto"])
			_choice(rows, "Vibração", "vibe", ["Desligada", "Fraca", "Média", "Forte"])
			# Perfis (#81): mudam várias opções de uma vez e o separador reabre com as escolhas novas (como o Idioma)
			var prof := HBoxContainer.new()
			prof.add_theme_constant_override("separation", 6)
			rows.add_child(prof)
			var pick := func(vals: Dictionary):
				main.settings.merge(vals, true)
				main.apply_settings()
				main.save_settings()
				open_settings(3, back)
			for n in TOUCH_PROFILES:
				_button(prof, n, pick.bind(TOUCH_PROFILES[n]), null, 149.0)
		4:
			_choice(rows, "Tremor do ecrã", "shake", ["Desligado", "Ligado"])
			_choice(rows, "Clarão nos críticos", "flash", ["Desligado", "Ligado"])
			_choice(rows, "Daltonismo", "colorblind", ["Desligado", "Protanopia", "Deuteranopia", "Tritanopia"])
			_choice(rows, "Conforto ocular", "comfort", ["Desligado", "Suave", "Forte"])
			_choice(rows, "Minimapa", "minimap", ["Desligado", "Ligado"])
			_choice(rows, "Interface fora de combate", "hud_fade", ["Sempre à vista", "Transparente"])
		5:
			_choice(rows, "Zona morta (analógicos e gatilhos)", "deadzone", ["Pequena", "Média", "Grande"])
			var map := Control.new()
			map.custom_minimum_size = Vector2(620, 30)
			map.draw.connect(func(): _prompts(map, Vector2(0, 21), ["Comando:  ", "@a", " ", "@x", " ", "@y", " habilidades   ", "@b", " interagir ou esquivar   ", "@lb", " ", "@rb", " poções"], 15))
			rows.add_child(map)
			var map2 := Control.new()
			map2.custom_minimum_size = Vector2(620, 30)
			map2.draw.connect(func(): _prompts(map2, Vector2(0, 21), ["@rt", " ", "@lt", " 1.ª e 2.ª habilidade   ", "@ls", " Arsenal   ", "@view", " Árvore   ", "@rs", " Postura   ", "@menu", " menu"], 15))
			rows.add_child(map2)
	var reset := func():
		main.reset_settings()
		open_settings(tab, back)
	_button(box, "Repor predefinições", reset)
	_button(box, "Voltar", _back)
	here.grab_focus()


## Linha de uma opção: o nome à esquerda, o controlo à direita.
func _row(box: Control, label: String) -> HBoxContainer:
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 16)
	var l := Label.new()
	l.text = label
	l.custom_minimum_size = Vector2(250, 42)
	l.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	l.add_theme_color_override("font_color", Color(0.88, 0.84, 0.72))
	row.add_child(l)
	box.add_child(row)
	return row


## Escolha: cada toque (ou A) passa à seguinte. after = o que fazer depois de mudar.
func _choice(box: Control, label: String, key: String, names: Array, after := Callable()) -> void:
	var b := Button.new()
	b.custom_minimum_size = Vector2(300, 52)
	b.text = names[int(main.settings[key])]
	b.pressed.connect(func():
		var v := (int(main.settings[key]) + 1) % names.size()
		main.set_setting(key, v == 1 if main.settings[key] is bool else v)
		b.text = names[v]
		if after.is_valid():
			after.call())
	_row(box, label).add_child(b)


## Volume de 0 a 100% (com o foco, a cruz ou o stick mexem-no).
func _slider(box: Control, label: String, key: String) -> void:
	var row := _row(box, label)
	var s := HSlider.new()
	s.min_value = 0.0
	s.max_value = 100.0
	s.step = 10.0
	s.value = float(main.settings[key]) * 100.0
	s.custom_minimum_size = Vector2(240, 42)
	var val := Label.new()
	val.text = "%d%%" % s.value
	val.custom_minimum_size = Vector2(56, 42)
	val.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	s.value_changed.connect(func(v: float):
		main.set_setting(key, v / 100.0)
		val.text = "%d%%" % v)
	row.add_child(s)
	row.add_child(val)


## Sobre: o jogo, a versão, quem o fez e as licenças (o Godot e a letra pedem que se mostrem).
func open_about(back := Callable()) -> void:
	var box := _open_panel("Sobre", true, back)
	var top := HBoxContainer.new()
	top.add_theme_constant_override("separation", 20)
	var logo := _art(STUDIO_LOGO, Vector2(150, 150))
	logo.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	top.add_child(logo)
	var info := VBoxContainer.new()
	top.add_child(info)
	box.add_child(top)
	var head := Control.new()
	head.custom_minimum_size = Vector2(560, 48)
	head.draw.connect(func(): Gothic.draw(head, Vector2(0, 38), "Soulstrider: Necro-Dominion", 40, Color(0.88, 0.97, 0.88), 6))
	info.add_child(head)
	_text(info, tr("Versão %s") % AppUpdate.VERSION_NAME, Color(0.45, 1.0, 0.65))
	_text(info, "Um ARPG gótico para telemóvel: almas, ossos e o Cortejo Fúnebre.\nJoga-se no ecrã ou com comando, sozinho ou a dois.")
	_text(info, "Um jogo Pixel Lusitano · desenvolvido por AlizeOnMe", Color(1.0, 0.8, 0.4))
	_text(box, "Feito com o Godot Engine. Letra Alkhemikal, de jeti (CC BY 4.0).", Color(0.65, 0.65, 0.6))
	_text(box, "Letra Augusta, de Typographer Mediengestaltung e Dieter Steffmann.", Color(0.65, 0.65, 0.6))
	_text(box, "Efeitos visuais: Sprite Fusion (MIT).", Color(0.65, 0.65, 0.6))
	_button(box, "Site: pixellusitano.com", func(): OS.shell_open("https://pixellusitano.com"))
	_button(box, "Contacto: contact@pixellusitano.com", func(): OS.shell_open("mailto:contact@pixellusitano.com"))
	_button(box, "Página do jogo e versões", func(): OS.shell_open("https://github.com/DaewonPT/Soulstrider/releases"))
	_button(box, "Ver a introdução", open_intro)
	_button(box, "Licenças", func(): _licenses(open_about.bind(back)))
	_button(box, "Voltar", _back).grab_focus()


## Licenças: a do Godot e dos componentes que traz, as das letras Alkhemikal, Augusta e Pirata One e a dos efeitos (o stick faz rolar).
func _licenses(back: Callable) -> void:
	var box := _open_panel("Licenças", true, back)
	var text := "Godot Engine\n" + Engine.get_license_text() + "\n\n" + tr("Componentes incluídos no Godot:")
	for c in Engine.get_copyright_info():
		for part in c.parts:
			text += "\n• %s: %s (%s)" % [c.name, ", ".join(part.copyright), part.license]
	text += "\n\nAlkhemikal\n" + FileAccess.get_file_as_string("res://fonts/Alkhemikal-LICENSE.txt")
	text += "\n\n" + FileAccess.get_file_as_string("res://fonts/Augusta-LICENCA.txt")
	text += "\n\nPirata One\n" + FileAccess.get_file_as_string("res://fonts/PirataOne-OFL.txt")
	text += "\n\n" + FileAccess.get_file_as_string("res://LICENCAS.txt")  # Sprite Fusion Pixel Art VFX (MIT)
	var sc := ScrollContainer.new()
	sc.custom_minimum_size = Vector2(680, 400)
	sc.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	var l := Label.new()
	l.text = text
	l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	l.custom_minimum_size.x = 660
	l.add_theme_color_override("font_color", Color(0.75, 0.75, 0.7))
	sc.add_child(l)
	box.add_child(sc)
	license_scroll = sc
	_button(box, "Voltar", _back).grab_focus()


## Há um APK novo no GitHub (AppUpdate): botão dourado por cima do Jogar, no ecrã de título.
func _on_update(info: Dictionary) -> void:
	if not is_instance_valid(title_menu) or title_menu.has_node("Update"):
		return
	if not title_menu.visible:
		title_reveal.call()  # há versão nova: o menu aparece logo, para o botão de atualizar se ver
	var go := func():
		updater.open_download()
		toast(tr("A descarregar %s: quando acabar, abre o ficheiro para instalar.") % AppUpdate.file_name_of(String(info.get("apk", ""))))
	var b := _button(title_menu, tr("Nova versão %s — atualizar") % String(info.get("name", "")).trim_prefix("Soulstrider "), go, null, 400.0)
	b.name = "Update"
	b.add_theme_font_size_override("font_size", 24)  # na Augusta do tema: o número da versão lê-se melhor que na gótica
	b.custom_minimum_size.y = 52
	b.add_theme_color_override("font_color", Color(1.0, 0.84, 0.4))
	b.add_theme_color_override("font_focus_color", Color(1.0, 0.9, 0.55))
	title_menu.move_child(b, 0)


func open_arsenal(focus := 0) -> void:
	var box := _open_panel("Arsenal — Frascos de Alma", true, sub_back)
	var head := HBoxContainer.new()
	var icon := _art(ICONS.sealed if main.weapon.sealed else ICONS.weapon, Vector2(56, 56))
	icon.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	head.add_child(icon)
	_text(head, main.weapon_text(), Color(0.95, 0.85, 0.6))
	box.add_child(head)
	var buttons := []
	var c: Dictionary = main.currency
	for it in [["ink", tr("Tinteiro de Sangue Negro (%d): sortear novos sufixos") % c.ink], ["ash", tr("Cinzas do Purgatório (%d): revelar propriedade oculta") % c.ash],
			["bone", tr("5 Ossos Ancestrais (%d): reforjar a arma (+10%% dano)") % c.bone]]:
		var b := _button(box, it[1], func(): pass, ICONS[it[0]])
		b.button_down.connect(_hold_buy.bind(it[0]))  # compra ao carregar; segurar continua (_hold_buy_tick)
		buttons.append(b)
	# Em co-op, uma coluna por jogador para o painel caber no ecrã
	var grid := GridContainer.new()
	grid.columns = main.players.size()
	grid.add_theme_constant_override("h_separation", 8)
	box.add_child(grid)
	var w: float = 560.0 / main.players.size() - 4.0 * (main.players.size() - 1)
	# O que faz o frasco da habilidade escolhida (muda com o foco do comando ou ao tocar)
	var desc := Label.new()
	desc.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	desc.custom_minimum_size = Vector2(600, 44)
	desc.add_theme_color_override("font_color", Color(0.62, 0.78, 0.68))
	desc.text = _found(false)
	for i in 4:  # as 3 habilidades e, na 4.ª linha, a Alma Condensada (veste-a o herói, não uma habilidade)
		for p in main.players:
			var id: String = p.order[i] if i < 3 else ""
			var f: String = p.skills[id].support if i < 3 else p.soul
			var idx := buttons.size()
			var b := _button(grid, "%s — %s" % [tr(p.skills[id].name if i < 3 else "Alma Condensada"), tr(p.SUPPORT_NAMES[f])], open_picker.bind(p, id, idx), ICONS[f], w)
			b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
			var info: String = _found(true) if i == 3 and f == "" else "%s: %s" % [tr(p.SUPPORT_NAMES[f]), tr(p.SUPPORT_DESC[f])]
			b.focus_entered.connect(func(): desc.text = info)
			buttons.append(b)
	box.add_child(desc)
	var fi := buttons.size()
	var row := HBoxContainer.new()  # Fórmulas e Fechar lado a lado: com a linha da Alma Condensada, o painel cabe nos 720 px em co-op
	box.add_child(row)
	for b in [_button(row, "Fórmulas de dano", func(): open_formulas(open_arsenal.bind(fi)), null, 276.0), _button(row, "Fechar", _back, null, 276.0)]:
		b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		buttons.append(b)
	buttons[clampi(focus, 0, buttons.size() - 1)].grab_focus()


## Grelha com os frascos que o grupo já encontrou, para a habilidade id (ou, com id "", para a Alma Condensada do
## herói). O posto vem aceso e com o foco; tocar (ou A) põe o escolhido e volta ao Arsenal; B (ou Voltar) não muda nada.
func open_picker(p, id: String, back: int) -> void:
	var box := _open_panel(p.skills[id].name if id != "" else "%s — %s" % [tr("Alma Condensada"), tr(p.hero_name)], true, open_arsenal.bind(back))
	var grid := GridContainer.new()
	grid.columns = 3
	grid.add_theme_constant_override("h_separation", 8)
	box.add_child(grid)
	var desc := Label.new()
	desc.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	desc.custom_minimum_size = Vector2(600, 44)
	desc.add_theme_color_override("font_color", Color(0.62, 0.78, 0.68))
	box.add_child(desc)
	var now: String = p.skills[id].support if id != "" else p.soul
	var on := 0  # o botão do frasco posto (ou o Nenhum, o primeiro)
	for f in (p.SUPPORTS if id != "" else p.SOULS).filter(func(k): return k in main.flasks):
		var pick := func():
			if id != "":
				_act(p, "set_support", [id, f], func(_r): open_arsenal(back))
			else:
				_act(p, "set_soul", [f], func(_r): open_arsenal(back))
		var b := _button(grid, p.SUPPORT_NAMES[f], pick, ICONS[f], 200.0)
		var info: String = _found(true) if id == "" and f == "" else "%s: %s" % [tr(p.SUPPORT_NAMES[f]), tr(p.SUPPORT_DESC[f])]
		b.focus_entered.connect(func(): desc.text = info)
		if f == now:
			b.toggle_mode = true  # o posto fica aceso
			b.button_pressed = true
			on = b.get_index()
	_button(box, "Voltar", _back)
	grid.get_child(on).grab_focus()


## Quantos Frascos de Alma (ou, com souls, Almas Condensadas) o grupo já encontrou; o Nenhum não conta.
func _found(souls: bool) -> String:
	var list: Array = main.player.SOULS if souls else main.player.SUPPORTS
	var n: int = list.filter(func(f): return f in main.flasks).size() - 1
	return tr("Almas Condensadas encontradas: %d de %d. Os chefes deixam as que faltam." if souls else "Frascos de Alma encontrados: %d de %d. Os chefes deixam os que faltam.") % [n, list.size() - 1]


## Fórmulas de dano: de onde vem o dano de cada habilidade, multiplicador a multiplicador.
func open_formulas(back := Callable()) -> void:
	var box := _open_panel("Fórmulas de dano", true, back)
	for p in main.players:
		_text(box, tr(p.hero_name), p.tint)
		for id in p.order:
			var n: Array = p.skill_numbers(id)
			var txt := "%s: %s" % [tr(p.skills[id].name), _dec(p.skills[id].dmg, 0)]
			for part in n[3]:
				if not is_equal_approx(part[1], 1.0):  # × 1 não muda nada
					txt += " × %s %s" % [_dec(part[1]), tr(part[0])]
			var lb := Label.new()
			lb.text = txt + " = %s" % _dec(n[0], 0) if n[0] > 0.0 else "%s: %s" % [tr(p.skills[id].name), tr("sem dano (defesa)")]
			lb.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
			lb.custom_minimum_size.x = 640.0
			lb.add_theme_color_override("font_color", Color(0.8, 0.8, 0.75))
			box.add_child(lb)
		_text(box, tr("Crítico: %d%% de hipótese, dano ×%s · contra chefes ×%s") % [roundi(main.CRIT * 100.0), _dec(main.CRIT_MULT), _dec(1.0 + p.stat("boss"))], Color(0.6, 0.6, 0.55))
	_button(box, "Fechar", _back).grab_focus()


## Número com vírgula em português e ponto em inglês.
func _dec(x: float, places := 2) -> String:
	var s := String.num(x, places)
	return s.replace(".", ",") if TranslationServer.get_locale().begins_with("pt") else s


func _spend(kind: String) -> void:
	_act(main, "use_currency", [kind], func(msg):
		if msg in SPEND_FAIL:  # acabou o dinheiro (ou não há nada para revelar): o segurar para aqui
			hold_kind = ""
		if panel != null and is_instance_valid(panel):
			open_arsenal(["ink", "ash", "bone"].find(kind))
		toast(msg))


func _hold_buy(kind: String) -> void:
	hold_kind = kind
	hold_t = HOLD_FIRST
	_spend(kind)


## O painel refaz-se a cada compra (o botão segurado desaparece), por isso o segurar vê-se pelo dedo, rato ou A ainda em
## baixo (no telemóvel o toque também conta como rato) e não pelo botão.
func _hold_buy_tick(delta: float) -> void:
	if hold_kind == "":
		return
	if panel == null or not (Input.is_mouse_button_pressed(MOUSE_BUTTON_LEFT) or Input.is_action_pressed("ui_accept")):
		hold_kind = ""
		return
	hold_t -= delta
	if hold_t <= 0.0:
		hold_t = HOLD_STEP
		_spend(hold_kind)


## Muda o jogo e depois refaz o painel. No convidado da Wi-Fi quem muda é o anfitrião: after corre quando
## a resposta chega, já com o jogo mudado.
func _act(who, method: String, args: Array, after: Callable) -> void:
	if Net.is_guest():
		Net.ask(-1 if who == main else who.slot, method, args, after)
	else:
		after.call(who.callv(method, args))


## Cortejo Fúnebre: o caminho das ondas até ao Arauto, os afixos em cartões (os das ondas anteriores
## ficam presos) e o saque da próxima onda, que sobe à medida que se junta perigo.
## step: a seta do Círculo que reabriu o menu (fica com o foco do comando).
func open_cortejo(step := 0) -> void:
	var w: int = main.cortejo.wave
	var box := _open_panel("Cortejo Fúnebre")
	var picks := {}
	var chosen := func() -> Array:
		return picks.keys().filter(func(k): return picks[k].button_pressed)
	var track := Control.new()
	track.custom_minimum_size = Vector2(620, 66)
	track.draw.connect(func(): _draw_track(track, w))
	box.add_child(track)
	var arrows := {}
	if w == 0:  # Círculos (#27): escolhe-se antes da 1.ª onda; os selos do círculo mudam com ele
		var row := HBoxContainer.new()
		row.add_theme_constant_override("separation", 8)
		box.add_child(row)
		var go_to := func(d: int):
			main.circle = clampi(main.circle + d, 1, main.circle_max)
			open_cortejo(d)
		for d in [-1, 1]:
			var b := _button(row, "", go_to.bind(d), null, 56.0)
			b.name = "circle_prev" if d < 0 else "circle_next"
			b.disabled = main.circle + d < 1 or main.circle + d > main.circle_max
			b.draw.connect(func():  # seta desenhada: a letra gótica não tem ◀ ▶
				var c := b.size / 2.0
				b.draw_colored_polygon(PackedVector2Array([c + Vector2(9 * d, 0), c + Vector2(-6 * d, -10), c + Vector2(-6 * d, 10)]),
					Color(0.95, 0.85, 0.55, 0.35 if b.disabled else 1.0)))
			arrows[d] = b
			if d == -1:
				var label := Control.new()
				label.custom_minimum_size = Vector2(170, 52)
				label.draw.connect(func(): Gothic.draw_centered(label, 85.0, 36.0, tr("Círculo %d") % main.circle, 26, Color(1.0, 0.85, 0.4), 5))
				row.add_child(label)
		var wins := Label.new()
		wins.text = tr("Vitórias %d · Recompensa ×%.1f") % [main.wins, main.circle_loot()]
		wins.custom_minimum_size.y = 52
		wins.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
		wins.add_theme_color_override("font_color", Color(0.8, 0.8, 0.75))
		row.add_child(wins)
	_text(box, tr("Escolhe os afixos da onda %d. Ficam até ao fim do Cortejo: mais perigo, mais saque.") % (w + 1))
	var grid := GridContainer.new()
	grid.columns = 2
	grid.add_theme_constant_override("h_separation", 8)
	grid.add_theme_constant_override("v_separation", 6)
	box.add_child(grid)
	var reward := Control.new()
	reward.custom_minimum_size = Vector2(620, 76)
	reward.draw.connect(func(): _draw_reward(reward, w + 1, chosen.call()))
	for k in main.AFFIXES:
		var b := Button.new()
		b.toggle_mode = true
		b.text = "%s\n%s" % [tr(main.AFFIXES[k][0]), tr(main.AFFIXES[k][1])]
		b.icon = AFFIX_ICON[k]
		b.add_theme_constant_override("icon_max_width", 40)
		b.alignment = HORIZONTAL_ALIGNMENT_LEFT
		b.custom_minimum_size = Vector2(308, 60)
		if k in main.cortejo.affixes or k in main.circle_seals():
			b.button_pressed = true
			b.disabled = true
			b.add_theme_stylebox_override("disabled", _sbt(UI.btn_on, Color(0.7, 0.7, 0.7)))
			# presos desde a onda anterior (ou selos do Círculo): lêem-se como ativos, não como indisponíveis
			b.add_theme_color_override("font_disabled_color", Color(0.65, 0.9, 0.7))
			b.add_theme_color_override("icon_disabled_color", Color.WHITE)
		b.toggled.connect(func(_on): reward.queue_redraw())
		picks[k] = b
		grid.add_child(b)
	box.add_child(reward)
	var go := func():
		var sel: Array = chosen.call()
		close_panel()
		main.start_wave(sel)
	var start := _button(box, tr("Invocar a onda %d") % (w + 1), go)
	start.add_theme_font_override("font", Gothic.FONT)
	start.add_theme_font_size_override("font_size", Gothic.px(26))
	start.custom_minimum_size.y = 52
	if w > 0:
		var stop := func():
			main.end_cortejo()
			close_panel()
		_button(box, "Encerrar o Cortejo (guardas o que já caiu)", stop)
	else:
		_button(box, "Recuar", close_panel)
	(arrows[step] if arrows.has(step) and not arrows[step].disabled else start).grab_focus()


## Caminho das ondas: as feitas a verde, a próxima a brilhar, a última com o Arauto ao lado.
func _draw_track(ci: Control, done: int) -> void:
	var y := 24.0
	var xs := [110.0, 300.0, 490.0]
	ci.draw_line(Vector2(xs[0], y), Vector2(xs[2], y), Color(0.3, 0.27, 0.22), 4.0)
	if done > 0:
		ci.draw_line(Vector2(xs[0], y), Vector2(xs[mini(done, 2)], y), Color(0.4, 1.0, 0.6), 4.0)
	for i in 3:
		var c := Vector2(xs[i], y)
		var col := Color(0.4, 1.0, 0.6) if i < done else (Color(1.0, 0.85, 0.4) if i == done else Color(0.4, 0.37, 0.32))
		ci.draw_circle(c, 15.0, Color(0.06, 0.07, 0.07))
		ci.draw_arc(c, 15.0, 0, TAU, 24, col, 3.0)
		if i < done:
			ci.draw_circle(c, 8.0, col)
		elif i == done:
			ci.draw_arc(c, 21.0, 0, TAU, 24, Color(col, 0.4), 2.0)
		Gothic.draw_centered(ci, c.x, y + 40.0, "Arauto" if i == 2 else tr("Onda %d") % (i + 1), 19, col, 4)
	var h := 62.0
	ci.draw_texture_rect(HERALD_TEX, Rect2(xs[2] + 24, y - h * 0.6, h * HERALD_TEX.get_width() / HERALD_TEX.get_height(), h), false)


## Saque da próxima onda com os afixos escolhidos (o mesmo cálculo do jogo) e o perigo em caveiras.
func _draw_reward(ci: Control, w: int, sel: Array) -> void:
	var r: Dictionary = main.wave_rewards(w, sel)
	var head := tr("Saque ×%.1f") % main.reward_mult(sel)
	var y := 28.0
	Gothic.draw(ci, Vector2(6, y), head, 24, Color(1.0, 0.85, 0.4), 5)
	var x := _draw_currency(ci, 18.0 + Gothic.width(head, 24), y, r)
	if w >= main.WAVES:
		Gothic.draw(ci, Vector2(x, y), "no Relicário", 19, Color(0.75, 0.75, 0.7), 4)
	y += 38.0
	Gothic.draw(ci, Vector2(6, y), "Perigo", 22, Color(1.0, 0.4, 0.35), 5)
	for i in main.AFFIXES.size():
		ci.draw_texture_rect(SKULLS, Rect2(84 + i * 32, y - 22, 28, 22), false, Color.WHITE if i < sel.size() else Color(0.3, 0.3, 0.3, 0.6))


## Ícones das moedas com as quantidades (as que forem > 0), a partir de x; devolve onde acaba.
func _draw_currency(ci: Control, x: float, y: float, amounts: Dictionary) -> float:
	for k in ["bone", "ink", "ash"]:
		if amounts.get(k, 0) <= 0:
			continue
		ci.draw_texture_rect(ICONS[k], Rect2(x, y - 26, 30, 30), false)
		Gothic.draw(ci, Vector2(x + 34, y), str(amounts[k]), 24, Color(0.95, 0.9, 0.75), 5)
		x += 52.0 + Gothic.width(str(amounts[k]), 24)
	return x


## Árvore dos Condenados: raízes e ossadas com a arte da folha SC-ICO4 sobre o fundo SC-TREE.
## Um nó só abre se o nó de que nasce já estiver aberto.
## A folha é maior do que a janela: arrasta-se com o dedo (ou o rato) e segue o nó com foco do comando.
func open_tree(who := 0, focus := "raiz") -> void:
	var p = main.players[who]
	var box := _open_panel(tr("Árvore dos Condenados — %s   (pontos: %d)") % [tr(p.hero_name), p.points], true, sub_back)
	var canvas := Control.new()
	canvas.custom_minimum_size = TREE_WIN
	canvas.clip_contents = true
	box.add_child(canvas)
	var sheet := Control.new()  # a folha (TREE_AREA): fundo, raízes e nós com os mesmos pos; desliza dentro da janela
	sheet.mouse_filter = Control.MOUSE_FILTER_IGNORE
	# Com tamanho 0 o Godot deixava de a desenhar quando o canto dela saía do ecrã (em co-op a janela fica mais acima e
	# a Árvore aparecia vazia); com o tamanho da folha, a caixa dela cruza sempre a janela
	sheet.size = TREE_AREA.end
	canvas.add_child(sheet)
	var look := func(v: Vector2) -> void:  # v: o ponto da folha que fica no canto de cima, à esquerda, da janela
		sheet.position = -v.clamp(TREE_AREA.position, TREE_AREA.end - TREE_WIN)
	var info := Label.new()
	# Altura fixa de 2 linhas e texto a quebrar: uma descrição comprida já não alarga a janela a cada nó escolhido
	info.custom_minimum_size = Vector2(640, 52)
	info.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	info.max_lines_visible = 2
	info.add_theme_color_override("font_color", Color(0.95, 0.85, 0.6))
	box.add_child(info)
	var nodes: Dictionary = main.PASSIVES
	var btns := {}
	sheet.draw.connect(func():
		sheet.draw_texture_rect(TREE.bg, TREE_AREA, false, Color(0.75, 0.75, 0.75))
		for id in nodes:
			var n: Dictionary = nodes[id]
			if n.req == "":
				continue
			var a: Vector2 = nodes[n.req].pos
			var v: Vector2 = n.pos - a
			sheet.draw_set_transform(a, v.angle())
			sheet.draw_texture_rect(TREE.root_on if id in p.passives else TREE.root, Rect2(0, -8, v.length(), 16), false)
			sheet.draw_set_transform(Vector2.ZERO)
		var font := ThemeDB.fallback_font
		for id in nodes:
			var n: Dictionary = nodes[id]
			var kind: String = NODE_KIND.get(id, "node")
			var have: bool = id in p.passives
			var open: bool = not have and n.req in p.passives and not p.EXCLUSIVE.get(id, "") in p.passives
			var d: float = NODE_SIZE[kind]
			var col := Color.WHITE if have or open else Color(0.45, 0.45, 0.45)
			if open:
				sheet.draw_circle(n.pos, d * 0.56, Color(1.0, 0.85, 0.4, 0.35))
			sheet.draw_texture_rect(TREE[kind + ("_on" if have else "")], Rect2(n.pos - Vector2(d, d) / 2.0, Vector2(d, d)), false, col)
			if btns.has(id) and btns[id].has_focus():
				sheet.draw_arc(n.pos, d * 0.6, 0, TAU, 32, Color(0.45, 1.0, 0.65), 3.0)
			var nm := tr(n.name)
			var tw := font.get_string_size(nm, HORIZONTAL_ALIGNMENT_LEFT, -1, 16).x
			var at: Vector2 = n.pos + Vector2(-tw / 2.0, minf(d * 0.5 + 15.0, TREE_AREA.end.y - 4.0 - n.pos.y))  # a Raiz, em baixo, não corta o nome
			sheet.draw_string_outline(font, at, nm, HORIZONTAL_ALIGNMENT_LEFT, -1, 16, 4, Color.BLACK)
			sheet.draw_string(font, at, nm, HORIZONTAL_ALIGNMENT_LEFT, -1, 16, col))
	var empty := StyleBoxEmpty.new()
	for id in nodes:
		var n: Dictionary = nodes[id]
		var d: float = NODE_SIZE[NODE_KIND.get(id, "node")]
		var have: bool = id in p.passives
		var open: bool = not have and n.req in p.passives and not p.EXCLUSIVE.get(id, "") in p.passives  # as chaves que se excluem (#108 #117 #140) ficam bloqueadas
		var b := Button.new()
		b.flat = true
		b.position = n.pos - Vector2(d, d) / 2.0
		b.size = Vector2(d, d)
		b.mouse_filter = Control.MOUSE_FILTER_PASS  # o toque segue também para a janela, que distingue tocar de arrastar
		for st in ["normal", "hover", "pressed", "focus"]:
			b.add_theme_stylebox_override(st, empty)
		var txt: String = "%s — %s%s" % [tr(n.name), tr(n.desc), "" if have or open else "  " + tr("(bloqueado)")]
		b.focus_entered.connect(func():
			info.text = txt
			# Comando/teclado: a folha desliza até o nó com foco ficar à vista (com o dedo ou o rato em baixo não salta)
			if not Input.is_mouse_button_pressed(MOUSE_BUTTON_LEFT) and not Rect2(Vector2(60, 60) - sheet.position, TREE_WIN - Vector2(120, 120)).has_point(n.pos):
				look.call(n.pos - TREE_WIN / 2.0)
			sheet.queue_redraw())
		b.mouse_entered.connect(func(): info.text = txt)
		b.pressed.connect(func():
			_act(p, "allocate", [id], func(ok):
				if ok:  # sem comprar não se refaz: tocar só para ler não faz saltar a vista
					toast("%s: %s" % [tr(p.hero_name), tr(n.name)])
					open_tree(who, id)))
		sheet.add_child(b)
		btns[id] = b
	# Dedo (no PC o rato também chega como toque): arrastar mais de 12 px desliza a folha e larga o toque no nó
	canvas.gui_input.connect(func(e: InputEvent):
		if e is InputEventScreenTouch and e.pressed:
			tree_drag = 0.0
		elif e is InputEventScreenDrag:
			tree_drag += e.relative.length()
			if tree_drag > 12.0:
				canvas.propagate_notification(Control.NOTIFICATION_SCROLL_BEGIN)  # o BaseButton cancela o toque, como num ScrollContainer
				look.call(-sheet.position - e.relative))
	if main.players.size() > 1:
		_button(box, tr("Ver a árvore do %s") % tr(main.players[1 - who].hero_name), func(): open_tree(1 - who))
	var row := HBoxContainer.new()  # Refazer ao lado do Fechar: em co-op mais uma linha passava da altura do ecrã
	box.add_child(row)
	var redo_txt := "Refazer (grátis)" if p.respecs == 0 else "Refazer (1 Cinza)"
	_button(row, redo_txt, func():  # pede confirmação: refazer devolve tudo de uma vez
		var c := _open_panel(tr("Refazer a Árvore"), true, open_tree.bind(who, focus))
		var l := Label.new()
		l.text = "Devolve todos os pontos. A primeira vez é grátis; depois custa 1 Cinza do Purgatório."
		l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		l.custom_minimum_size.x = 560.0
		l.add_theme_color_override("font_color", Color(0.8, 0.8, 0.75))
		c.add_child(l)
		_button(c, redo_txt, func(): _act(p, "respec", [], func(msg):
			if msg is String:  # o convidado não refaz a Árvore do anfitrião (sem resposta)
				toast(msg)
			open_tree(who, focus)))
		_button(c, "Voltar", open_tree.bind(who, focus)).grab_focus(), null, 0.0)
	_button(row, "Fechar", _back, null, 0.0)
	for b in row.get_children():
		b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	look.call(nodes[focus].pos - TREE_WIN / 2.0)  # abre centrada no nó com foco (depois de escolher, reabre no nó escolhido)
	# O comando escolhe o vizinho mais perto em cada direção e nunca chegava ao Canibalismo: à esquerda do Tutano vai lá
	btns.tutano.focus_neighbor_left = btns.tutano.get_path_to(btns.canibal)
	btns[focus].grab_focus()


## Bestiário: um monstro por linha; o que ainda não se sabe fica escondido (silhueta negra, "???").
func open_bestiary(back := Callable()) -> void:
	var box := _open_panel("Bestiário", true, back)
	for kind in BESTIARY:
		var b: Array = BESTIARY[kind]
		var steps: Array = b[1]
		var n: int = main.kills.get(kind, 0)
		var st: Array = Enemy.STATS[kind]
		var row := HBoxContainer.new()
		row.add_theme_constant_override("separation", 12)
		var pic := _art(Enemy.FRAMES[kind][8], Vector2(72, 72))
		pic.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
		pic.modulate = Color.WHITE if n >= steps[0] else Color(0, 0, 0, 0.85)
		row.add_child(pic)
		var lines := []
		if n < steps[0]:
			lines.append([tr("??? — ainda não o derrotaste"), Color(0.6, 0.6, 0.55)])
		else:
			lines.append([tr("%s — %d morto" if n == 1 else "%s — %d mortos") % [tr(Enemy.NAMES[kind]), n], Color(0.95, 0.85, 0.6)])
			lines.append([tr(b[0]), Color(0.75, 0.75, 0.7)])
		if n >= steps[1]:
			lines.append([tr("Vida %d · Dano %d · Velocidade %d") % [st[0], st[2], st[1]], Color(0.55, 0.9, 0.65)])
		if n >= steps[2]:
			lines.append([tr("Experiência %d · Deixa: %s") % [main.XP[kind], tr(b[2])], Color(0.55, 0.8, 1.0)])
		else:
			var next: int = steps.filter(func(s): return s > n)[0]
			lines.append([tr("Mata mais %d para saberes mais.") % (next - n), Color(0.5, 0.5, 0.48)])
		var col := VBoxContainer.new()
		col.add_theme_constant_override("separation", 0)
		for l in lines:
			var lb := Label.new()
			lb.text = l[0]
			lb.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
			lb.custom_minimum_size.x = 700.0  # largo: na Augusta, com tudo descoberto, o painel cabe nos 720 px
			lb.add_theme_color_override("font_color", l[1])
			col.add_child(lb)
		row.add_child(col)
		box.add_child(row)
	_button(box, "Fechar", _back).grab_focus()


## info vem de main.die(): o que ficou no túmulo e se havia um túmulo antigo (que se desfez).
func open_death(info := {}) -> void:
	Net.echo("hud", "toast", ["Caíram todos. O anfitrião escolhe o que fazer."])
	var box := _open_panel("A tua alma dissipou-se", false)
	var lost: Dictionary = info.get("lost", {})
	if lost.is_empty():
		_text(box, "Os mortos reclamam o que é deles.")
	else:
		_text(box, "Metade do que trazias ficou no teu túmulo, no cemitério:")
		var row := Control.new()
		row.custom_minimum_size = Vector2(0, 40)
		row.draw.connect(func(): _draw_currency(row, 6.0, 32.0, lost))
		box.add_child(row)
		_text(box, "Vai buscá-lo antes de voltares a morrer, senão perde-se.")
	if info.get("had_old", false):
		_text(box, "O túmulo anterior desfez-se com tudo o que lá estava.", Color(1.0, 0.5, 0.45))
	if info.get("by", "") != "":
		_text(box, tr("Derrubado por: %s") % tr(info.by), Color(0.95, 0.6, 0.5))
	_button(box, "Erguer-se novamente", main.restart).grab_focus()  # recomeça já a jogar, do jogo gravado
