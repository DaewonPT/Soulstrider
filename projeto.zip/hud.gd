extends CanvasLayer
## HUD gótico (arte das folhas SC-UI1/SC-UI2) + controlos de telemóvel: ecrã tátil (joystick flutuante,
## botões escaláveis) ou comando, com os botões A/B/X/Y desenhados no ecrã
## + painéis: título, Arsenal, Árvore dos Condenados, Cortejo e morte (no comando: A escolhe, B volta).
## Também os momentos grandes: barra e cartão do chefe, subida de nível e flash do crítico.

const JOY_R := 80.0
const SCALES := [1.0, 1.3, 1.6, 0.8]  # o 80% (#99) vai no fim: os índices já gravados não mudam
const CARD_T := 3.2
const CARD_BAND_A := 0.55  # a faixa escura do cartão do chefe (a 0,35 as marcas dos membros viam-se através do título)
const DOOR_HINT := {"down": ["Cripta dos Condenados", "Descer"], "up": ["Saída da cripta", "Subir"], "gate": ["Portão dos Reis", "Descer"], "sep_up": ["Sair dos Sepulcros", "Subir"], "sep_down": ["", "Descer"]}
const LVL_T := 2.4
const UI := {
	"holder": preload("res://art/ui/orb_holder.png"),
	"red": preload("res://art/ui/orb_red.png"),
	"soul": preload("res://art/ui/orb_soul.png"),
	"ring": preload("res://art/ui/ring_small.png"),
	"joy": preload("res://art/ui/joy_base.png"),
	"knob": preload("res://art/ui/joy_knob.png"),
	"bar": preload("res://art/ui/bar.png"),
	"panel": preload("res://art/ui/panel.png"),
	"btn": preload("res://art/ui/btn_s.png"),
	"btn_on": preload("res://art/ui/btn_on_s.png"),
	"slot": preload("res://art/ui/slot.png"),  # G1: a moldura dos quadrados do Equipamento
}
const ICONS := {
	"scythe": preload("res://art/icons/sk_scythe.png"),
	"bolt": preload("res://art/icons/sk_bolt.png"),
	"nova": preload("res://art/icons/sk_raise.png"),  # Erguer os Mortos
	"chop": preload("res://art/icons/sk_chop.png"),
	"cleave": preload("res://art/icons/sk_cleave.png"),
	"bonearmor": preload("res://art/icons/sk_bonearmor.png"),
	"bone": preload("res://art/icons/bone.png"),
	"ink": preload("res://art/icons/ink.png"),
	"ash": preload("res://art/icons/ash.png"),
	"": preload("res://art/icons/flask_empty.png"),
	"parasita": preload("res://art/icons/flask_parasita.png"),
	"titanica": preload("res://art/icons/flask_titanica.png"),
	"weapon": preload("res://art/icons/scythe.png"),
	"sealed": preload("res://art/icons/sealed.png"),
	"veloz": preload("res://art/icons/flask_swift.png"),
	"eco": preload("res://art/icons/flask_echo.png"),
	"tumular": preload("res://art/icons/flask_grave.png"),
	"colerica": preload("res://art/icons/flask_wrath.png"),
	"roubo": preload("res://art/icons/flask_roubo.png"),
	"caotico": preload("res://art/icons/flask_caotico.png"),
	"mitotico": preload("res://art/icons/flask_mitotico.png"),
	"martir": preload("res://art/icons/flask_martir.png"),
	"gatilho": preload("res://art/icons/flask_gatilho.png"),
	"carga": preload("res://art/icons/flask_carga.png"),
	"eter": preload("res://art/icons/flask_eter.png"),
	"gravidade": preload("res://art/icons/flask_gravidade.png"),
	"meteoro": preload("res://art/icons/flask_meteoro.png"),
	"terramoto": preload("res://art/icons/flask_terramoto.png"),
	"voraz": preload("res://art/icons/flask_voraz.png"),
	"chumbo": preload("res://art/icons/flask_chumbo.png"),
	"biomecanica": preload("res://art/icons/flask_biomecanica.png"),
	"furia": preload("res://art/icons/flask_furia.png"),
	"maldito_carcereiro": preload("res://art/icons/flask_maldito_carcereiro.png"),
	"maldito_arauto": preload("res://art/icons/flask_maldito_arauto.png"),
	"vinganca": preload("res://art/icons/soul_vinganca.png"),
	"escriba": preload("res://art/icons/soul_escriba.png"),
	"cranios": preload("res://art/icons/soul_cranios.png"),
	"donzela": preload("res://art/icons/soul_donzela.png"),
	"transitoria": preload("res://art/icons/soul_transitoria.png"),  # o botão da Alma Transitória (#4)
	"potion_hp": preload("res://art/icons/potion_red.png"),
	"potion_mp": preload("res://art/icons/potion_soul.png"),
	"guarda": preload("res://art/icons/shield.png"),  # Postura de Combate: Guarda Sepulcral
	"ira": preload("res://art/icons/sk_sacrifice.png"),  # e Ira Sacrificial
	"tree": preload("res://art/icons/hud_tree.png"),  # os três botões do canto de cima (top_bar)
	"arsenal": preload("res://art/icons/hud_arsenal.png"),
	"menu": preload("res://art/icons/hud_menu.png"),
}
const TREE := {
	"node": preload("res://art/tree/node.png"), "node_on": preload("res://art/tree/node_on.png"),
	"notable": preload("res://art/tree/notable.png"), "notable_on": preload("res://art/tree/notable_on.png"),
	"keystone": preload("res://art/tree/keystone.png"), "keystone_on": preload("res://art/tree/keystone_on.png"),
	"root": preload("res://art/tree/root.png"), "root_on": preload("res://art/tree/root_on.png"),
	"bg": preload("res://art/bg/tree.webp"),
}
const NODE_KIND := {"raiz": "keystone", "bleedbone": "keystone", "ossada": "notable", "hemorragia": "notable", "eco": "notable", "pacto": "keystone", "vermes": "keystone", "canibal": "keystone", "semalma": "keystone", "frio": "keystone", "martir_aco": "notable", "ectoplasma": "notable", "ecos": "notable", "presenca": "notable", "sede": "notable", "fragmentada": "keystone", "imolacao": "keystone", "sangue": "keystone", "fome": "keystone", "lich": "keystone", "circulacao": "notable", "arqueiros": "notable", "guardioes": "notable", "exumacao": "notable", "estacas": "notable", "carrasco": "notable", "falange": "notable", "ressurreicao": "notable"}
const NODE_SIZE := {"node": 46.0, "notable": 60.0, "keystone": 76.0}
const RING_K := 0.62  # C (e): o aro do foco de um nó vai até d x 0,6 (mais a grossura): os nomes ficam fora dele
const TREE_WIN := Vector2(780, 390)  # janela da Árvore: nunca muda de tamanho (780: a descrição do nó, na Augusta, cabe em 2 linhas)
const TREE_AREA := Rect2(-310, -170, 1260, 860)  # a folha inteira (com lugar para mais nós, S3), que desliza dentro da janela
## Procurar na Árvore (#97): cada atalho e as palavras que procura (sem acentos: a busca tira-os dos dois lados)
const FIND := {"Sangramento": ["sangr"], "Lacaios": ["lacaio", "esquelet"], "Barreira": ["barreira"], "Alma": ["alma", "mana"], "Esquiva": ["esquiva"], "Cadáveres": ["cadaver", "mortos"]}
const PLAIN := ["áàâãéêíóôõúç", "aaaaeeiooouc"]  # cada letra com acento e a mesma sem ele
const Gothic := preload("res://gothic.gd")
const AppUpdate := preload("res://app_update.gd")
const FILTER := preload("res://filter.gdshader")
const Enemy := preload("res://enemy.gd")
const Pix := preload("res://fx_pix.gd")
const Loot := preload("res://loot.gd")
const MINIMAP := 160.0  # lado maior do minimapa, em píxeis
const TOP_BTN := 64.0  # botões do canto de cima: perto de 40 dp num telemóvel, fáceis de acertar
const MENU_TOP := 60.0  # Lote 11 C (c): o cimo do Menu (acaba por cima das esferas)
const TOAST_GAP := 8.0  # Lote 11 C (c): a folga entre um aviso e a moldura do painel aberto
const LAN_WAIT := 8.0  # UX 28: segundos sem salas à vista até o painel da Wi-Fi mostrar o campo do IP
const XP_ROOM := 26.0  # C (c): a barra da experiência e o "Nv" no fundo do ecrã; os avisos ficam por cima disto
const TOP_GAP := 8.0
## Bestiário: [descrição, mortes para saber o nome / os números / o saque, o que deixa cair] (nomes em Enemy.NAMES).
## Os chefes revelam-se mais depressa. As mortes são do grupo inteiro e ficam gravadas.
const BESTIARY := {
	"skeleton": ["Ossos que o cemitério não deixa descansar. Andam em bando.", [1, 10, 50],
		"Ossos Ancestrais (28%), Tinteiros (6%), Cinzas (4%) e, muito raramente, um Frasco de Alma."],
	"enforcado": ["Ainda traz a corda ao pescoço. Anda à procura de quem o enforcou.", [1, 10, 50],
		"Ossos Ancestrais (28%), Tinteiros (6%), Cinzas (4%) e, muito raramente, um Frasco de Alma."],
	"afogado": ["Saiu da água inchado e a pingar, e nunca mais secou.", [1, 10, 50],
		"Ossos Ancestrais (28%), Tinteiros (6%), Cinzas (4%) e, muito raramente, um Frasco de Alma."],
	"queimado": ["Saiu do forno ainda em brasa e nunca mais se apagou.", [1, 10, 50],
		"Ossos Ancestrais (28%), Tinteiros (6%), Cinzas (4%) e, muito raramente, um Frasco de Alma."],
	"estandarte": ["Morreu de estandarte na mão e nunca mais o largou.", [1, 10, 50],
		"Ossos Ancestrais (28%), Tinteiros (6%), Cinzas (4%) e, muito raramente, um Frasco de Alma."],
	"specter": ["Rápido e frágil: chega sempre antes dos outros.", [1, 10, 50],
		"Ossos Ancestrais (28%), Tinteiros (6%), Cinzas (4%) e, muito raramente, um Frasco de Alma."],
	"colossus": ["Bate devagar e com muita força. Um deles guarda a cripta.", [1, 2, 3],
		"2 Ossos Ancestrais, 1 Tinteiro, 1 Cinza e um Frasco de Alma que falte ao grupo. O da cripta deixa também um reagente da Forja (30%), uma Relíquia de Família (35%) e o relicário (com outro reagente, uma vez em duas)."],
	"herald": ["O mensageiro do Cortejo Fúnebre: faz tocar o sino e chama os mortos.", [1, 2, 3],
		"2 Ossos Ancestrais, 1 Tinteiro, 1 Cinza, um Frasco de Alma que falte ao grupo, um reagente da Forja (30%) e uma Relíquia de Família (35%)."],
}
const SKILL_SPOTS := [[Vector2(240, 190), 120.0], [Vector2(120, 225), 95.0], [Vector2(255, 75), 95.0]]  # [posição, diâmetro]
## Cores das letras dos botões, como num comando Xbox / GameSir.
const GLYPH_COL := {"a": Color(0.45, 0.82, 0.35), "b": Color(0.93, 0.32, 0.28), "x": Color(0.33, 0.58, 0.97), "y": Color(0.98, 0.8, 0.22)}
const TITLE_ART := preload("res://art/bg/title.webp")
## Afixos do Cortejo em cartões, com arte que já existe a dizer o que fazem.
const CURSE_TEXT := {"legiao": "+60% mortos em cada piso", "gemeo": "+1 colosso em cada piso"}  # no Mausoléu (#27) não há ondas nem escoltas
const AFFIX_ICON := {
	"blindados": preload("res://art/icons/chest_armor.png"),
	"furia": preload("res://art/icons/flask_swift.png"),
	"laminas": preload("res://art/icons/sword.png"),
	"legiao": preload("res://art/icons/sk_raise.png"),
	"gemeo": preload("res://art/anim/colossus32_16.png"),
	"rebeldes": preload("res://art/icons/sk_revive.png"),  # os afixos novos (S8)
	"sinos": preload("res://art/icons/sk_ping.png"),
	"ceifador": preload("res://art/icons/scythe.png"),
	"eclipse": preload("res://art/icons/hood.png"),
	"mares": preload("res://art/icons/potion_red.png"),
	"dentes": preload("res://art/icons/bone.png"),
}
const HERALD_TEX := preload("res://art/anim/herald32_0.png")
const SKULLS := preload("res://art/props/skulls.png")
var trims := {}  # _trim(): cada desenho recorta-se uma vez
var rims := {}  # Lote 11 C (d, e): _rim(): o contorno claro de cada ícone, feito uma vez
var dark_icons := {}  # e se cada ícone é escuro (_dark_icon)
const HOLD_SKIP := 1.0
## Compras da Forja a segurar (Tinteiro, Cinzas e 5 Ossos): carregar compra uma vez; segurar espera HOLD_FIRST e depois compra a cada HOLD_STEP,
## até largar o botão ou o jogo responder que já não há com que pagar (as respostas de main.use_currency em SPEND_FAIL).
const HOLD_FIRST := 0.45
const HOLD_STEP := 0.12
## Segurar um botão de toque HOLD_INFO s mostra o cartão do que ele faz (_info_text). Mais que o HOLD_FIRST: um
## toque firme de pânico na poção ainda bebe.
const HOLD_INFO := 0.7
const SKILL_INFO := {
	"scythe": "Golpe em arco com a foice à frente.",
	"bolt": "Dispara uma lança de alma contra o inimigo mais perto.",
	"nova": "Explosão à tua volta que ergue 2 esqueletos teus durante 12 s.",
	"chop": "Machadada em arco à frente; o terceiro golpe seguido é um rodopio que apanha tudo à volta.",
	"cleave": "Redemoinho: 3 voltas do machado que atingem tudo à volta.",
	"bonearmor": "Cura 15% da vida e, durante 5 s, levas metade do dano.",
}
## Almas Transitórias (#4): o cartão do botão (o nome vem de player.TRANS)
const TRANS_INFO := {
	"lamento": "12 lascas de alma voam para os monstros mais perto (até 600 px), cada uma com o dobro do dano do teu golpe mais forte.",
	"cataclismo": "Rebenta tudo à tua volta (400 px) com o triplo do dano do teu golpe mais forte.",
}
const STANCE_INFO := {
	"guarda": "Guarda Sepulcral: -25% de dano recebido e devolves 60% do que levas a quem bateu.",
	"ira": "Ira Sacrificial: +30% dano, recargas -25%, mas cada habilidade custa 2% da vida.",
}
## Forja (0.4.9): o que faz cada sufixo da foice (main.SUFFIXES) e cada propriedade oculta já revelada (main.HIDDEN).
# atalho: os números copiam-se à mão de main.gd, enemy.gd:504-527 e player.gd:309; o teste de fumo só prende os dos sufixos, do oculto e as 10 camadas: as durações e as bases (4 s, 3/1,5 s, 35%, 30%, 60%, 5%, 7) mudam-se aqui à mão
const WEAPON_INFO := {
	"do Sangramento": "os golpes da foice, do machado e da Ceifa de Ossos fazem sangrar mais 50% do golpe por segundo, durante 3 s (a base é 35%).",
	"da Ossada": "+25% de dano em todas as habilidades.",
	"da Vigília": "+3 de alma por segundo (a base é 7).",
	"do Tutano": "4% do dano dos teus golpes volta como vida.",
	"do Coveiro Veloz": "andas 15% mais depressa.",
	"da Podridão": "cada golpe apodrece o monstro 4 s (30% do golpe por segundo) e pega-se aos do lado. Podre e a andar, leva até +60% de dano.",
	"da Calcificação": "10 golpes seguidos petrificam o monstro: fica parado 3 s (os chefes, 1,5 s). Com 4 s sem golpes, a conta recomeça.",
	"da Necrose": "cada golpe faz o monstro levar mais 5% de dano, até +50%. Com 4 s sem golpes, volta a zero.",
	"Ruína dos Colossos: +60% dano a chefes": "Ruína dos Colossos. +60% de dano a chefes.",
	"Banquete Fúnebre: +5 vida por abate": "Banquete Fúnebre. Cada monstro que morre cura 5 de vida a cada herói.",
	"Alma Faminta: +35% dano de feitiços": "Alma Faminta. +35% de dano na Lança de Almas e no Erguer os Mortos (o Cavaleiro não os tem).",
}
## Equipamento (0.4.8): como se lê cada chave das peças, [nome, em percentagem]. O resto (as regras dos únicos) vai na descrição.
const GEAR_TEXT := {
	"hp_max": ["Vida máxima", false], "hp_mul": ["Vida máxima", true], "mana_max": ["Alma máxima", false], "regen": ["Alma por segundo", false],
	"gdmg": ["Dano", true], "crit": ["Crítico", true], "dr": ["Proteção", true], "speed": ["Velocidade", true], "leech": ["Roubo de vida", true],
	"bleed": ["Sangramento", true], "boss": ["Dano a chefes", true], "kill_heal": ["Vida por abate", false], "bone_barrier": ["Barreira de ossos", true],
	"spell": ["Dano de feitiços", true],  # só na ficha do herói (nenhuma peça o dá)
	"aura": ["Proteção do grupo", true], "crit_dmg": ["Dano crítico", true],  # G2: o Incensário (#63) e o Visor (#252)
}
const GEAR_FELT := ["gdmg", "hp_mul", "speed"]  # no comparador estes mostram o número que se sente (o golpe, a vida, os px/s), não a percentagem
const SPEND_FAIL := ["Sem Tinteiros de Sangue Negro.", "Nada selado para revelar.", "Sem Cinzas do Purgatório.", "Precisas de 5 Ossos Ancestrais."]
const FORGE_COST := {"ink": 1, "ash": 1, "bone": 5, "formao": 1, "carmesim": 1, "pena": 1}  # A7: a linha da Forja que não se pode pagar fica apagada
## A6: uma linha por opção de nome pouco claro, por baixo das linhas das Configurações (ao escolher ou carregar nela)
const SETTING_INFO := {
	"thermal": "Se o telemóvel aquecer, baixa sozinho os efeitos ou os FPS.",
	"hud_fade": "Transparente: sem luta por perto e com a vida cheia, as barras, as moedas e o minimapa quase desaparecem.",
	"fx_alpha": "Deixa ver através dos efeitos dos golpes. Os números de dano e os avisos dos chefes não mudam.",
	"deadzone": "Quanto tens de mexer os analógicos e os gatilhos antes de o jogo contar.",
	"comfort": "Cores mais quentes, com menos luz azul, para cansar menos os olhos.",
	"auto_attack": "Com um inimigo ao alcance, o golpe básico sai sozinho.",
	"boss_aim": "Para onde vão os golpes: o inimigo mais perto, ou os chefes e os elites primeiro.",
}
const ON_WORDS := ["Ligado", "Ligada", "Sim", "À vista"]  # A6: o valor que liga lê-se a verde, o que desliga a cinzento
const OFF_WORDS := ["Desligado", "Desligada", "Não", "Escondidos"]
const TABS := ["Som", "Desempenho", "Jogo", "Toque", "Ecrã", "Comando"]  # separadores das Configurações
## Perfis de controlo tátil (#81, Configurações > Toque): cada um muda estas opções de uma vez.
## Dois polegares = as de origem · Um polegar = ataque automático, botões a 130% e joystick fixo (o mesmo polegar
## acha-o sem olhar) · Garra = indicadores nos botões, opacidade a 75% para se ver o chão · Tablet = joystick fixo
## no canto, onde o polegar chega, opacidade a 50% e poções a 100% (no ecrã grande já são grandes).
const TOUCH_PROFILES := {
	"Dois polegares": {"ui": 0, "opacity": 0, "potion_ui": 2, "joy_fixed": false, "auto_attack": false},
	"Um polegar": {"ui": 1, "opacity": 0, "potion_ui": 2, "joy_fixed": true, "auto_attack": true},
	"Garra": {"ui": 0, "opacity": 1, "potion_ui": 1, "joy_fixed": false, "auto_attack": false},
	"Tablet": {"ui": 0, "opacity": 2, "potion_ui": 0, "joy_fixed": true, "joy_at": Vector2.ZERO, "auto_attack": false},
}
const STUDIO_LOGO := preload("res://art/ui/studio_logo.png")  # no Sobre (e no fim da abertura, opening.gd)
const Intro := preload("res://intro.gd")
const Opening := preload("res://opening.gd")  # a abertura: o Colosso acorda e o nome do jogo cai  # a intro animada: planos, legendas e o nome do jogo
static var VIGNETTE := _vignette()  # bordas vermelhas da vida baixa
const ONE_GUARD := {"membros": "membro", "estátuas": "estátua", "runas": "runa", "penitentes": "penitente", "rodas": "roda"}
## Lote 9: o Livro dos Chefes (Bestiário > Chefes), por esta ordem; o nome e a frase vêm de Bosses.BOOK ou Bosses.INFO
const BOSS_BOOK := ["carcereiro", "arauto", "suturado", "monge", "carrasco", "guardiao", "tita", "santuario", "arquivista", "sibila", "tecela",
	"marechal", "arquilich", "matriarca", "bispo", "donzelas", "quimera", "reis", "amalgama", "carruagem"]
const CHALLENGE_H := 440.0  # Lote 9: a altura da lista das Provações e modos, que rola
const BODY_PAD := 20  # Lote 7 C (c): a legenda do comando nas Configurações, no tamanho das outras linhas (Gothic.BODY_SIZE)
const SIGNED := ["crit_dmg"]  # Lote 7 C (j): na ficha e no comparador com o sinal ("Dano crítico +50%": sem ele lia-se como se o crítico fizesse 50%)
## G1: o Arsenal em 3 separadores, todos com HUB_W de largura (× o tamanho do texto) e o cimo em HUB_TOP: a moldura e os
## separadores não saltam ao trocar, e não tapam os botões redondos de cima; o Equipamento em quadrados de 64 px
const HUB_TABS := ["Frascos", "Forja", "Equipamento"]
const ORB_KEYS := ["orb0", "orb1"]  # C (h): a esfera da vida e a da alma, cada uma tapada à parte (covered)
const TILE := 64.0
const HUB_W := 680.0
const HUB_TOP := 12.0
const BAG_TOP := 20  # a mochila com as 3 Bolsas de Almas (#72): os lugares que faltam abrir ficam apagados
const BAG_COLS := 5  # 4 filas de 5 (com 6 o Arsenal não cabia na largura dos outros separadores); o 5.º lugar (Pescoço, G2) cabe na fila de cima
const HOLD_LOCK := 0.6  # segurar um quadrado tranca a peça (#78)
const FORM_ICON := 37  # Lote 11 C (a): a lista das almas da Forja: ícones de 37 px de largo (até 40 de alto)
const FORM_ROW := 58.0  # em botões de 58: 9 px de folga em cima e em baixo, por dentro da moldura (a 52 pisavam-na)
const RIM := Color(0.86, 0.82, 0.7)  # Lote 11 C (d, e, g): o contorno claro dos ícones escuros e dos chefes do Livro
const ICON_GAP := 8.0  # Lote 10 C (a): a folga mínima entre o ícone de um botão da Forja e o texto
const VERDICT_RANK := ["up", "both", "", "down"]  # Ordenar: melhores (#273)
const SORT_NAMES := ["Ordenar: lugar", "Ordenar: raridade", "Ordenar: melhores"]
const LOT_NAMES := ["Comuns (%s, +%d Ossos)", "Comuns e mágicas (%s, +%d Ossos)", "Até às raras (%s, +%d Ossos)"]  # Desfazer em lote (#266)
## B6: para que serve cada moeda (segurar as moedas do HUD)
const COIN_INFO := {"bone": "Cada 5 reforjam a foice (+1).", "ink": "Sorteia sufixos novos para a foice.", "ash": "Revela o oculto da foice; também refaz a Árvore.",
	"formao": "Trava um sufixo da foice.", "carmesim": "Troca os sufixos de ataque da foice.", "pena": "Arrisca uma pilha de moedas: dobra ou arde.",
	"tomo": "Refaz a Árvore sem gastar Cinzas do Purgatório.", "coracao": "Oferece-se no altar do titã."}
## G6 (#85): a Bolsa, os 3 separadores, e onde cai cada coisa (uma linha por moeda e por material)
const BAG_TABS := ["Moedas", "Materiais", "Frascos"]
const COIN_FROM := {"bone": "De quase todos os mortos e dos relicários.", "ink": "Dos mortos mais fortes, dos chefes e dos relicários.",
	"ash": "Dos chefes, dos elites e dos relicários.", "formao": "Dos chefes com nome, dos relicários e, às vezes, dos elites e dos Gigantes Errantes.",
	"carmesim": "Dos chefes com nome, dos relicários e, às vezes, dos elites e dos Gigantes Errantes.", "pena": "Dos chefes com nome, dos relicários e, às vezes, dos elites e dos Gigantes Errantes.",
	"tomo": "Dos chefes com nome, dos relicários e, às vezes, dos elites e dos Gigantes Errantes.", "coracao": "Do guardião da cripta, dos guardiões dos Sepulcros, do Meteoro Funerário, da Carruagem Fúnebre e dos relicários do Cortejo (raro)."}
const MAT_FROM := {"enxofre": "Dos elites, dos Gigantes Errantes, dos chefes com nome e das Sentinelas dos Sepulcros.",
	"martelo": "Dos elites, dos Gigantes Errantes, dos chefes com nome e das Sentinelas dos Sepulcros.",
	"agulha": "Dos elites, dos Gigantes Errantes, dos chefes com nome e das Sentinelas dos Sepulcros.",
	"cinza_maior": "Dos guardiões dos Sepulcros, do Santuário (2), dos Reis Caídos (2), da Amálgama Primordial (3) e dos chefes do Mausoléu, a cada 10 pisos.",
	"cinzel": "Dos elites, dos Gigantes Errantes, dos chefes com nome e das Sentinelas dos Sepulcros.",
	"estaca": "De cada guardião dos Sepulcros, na primeira vitória (duas nas profundidades 25 e 50).",
	"oleo_lapide": "Do Santuário, dos Reis Caídos, da Amálgama Primordial, dos chefes do Mausoléu a cada 10 pisos e, às vezes, das Sentinelas dos Sepulcros (da profundidade 6 em diante)."}
## Lote 11: o que fazem as duas coisas do Atlas dos Sepulcros que se guardam com os materiais (Loot.KEEP)
const KEEP_DO := {"estaca": "Compra melhorias no Atlas dos Sepulcros, no Portão dos Reis.",
	"oleo_lapide": "Unge uma ida aos Sepulcros, no Atlas: 4 elites colossais por profundidade e relicários ×1,5."}
const ATLAS_H := 330.0  # #185: a altura da lista do Atlas, que rola (com 6 blocos e o texto a 130% o painel cabe nos 720 px)
const ATLAS_W := 720.0  # e a largura do Atlas (x o tamanho do texto)
const SILHOUETTE := preload("res://silhouette.gdshader")
const BAG_ICON := preload("res://art/icons/bolsa.png")  # a Bolsa no Menu (SC-ICO9)


## B3: 64 x 36 com degraus (interpolação constante), desenhada com os píxeis à vista (a camada vig é NEAREST).
static func _vignette() -> GradientTexture2D:
	var g := GradientTexture2D.new()
	g.width = 64
	g.height = 36
	g.gradient = Gradient.new()
	g.gradient.interpolation_mode = Gradient.GRADIENT_INTERPOLATE_CONSTANT
	g.gradient.offsets = PackedFloat32Array([0.5, 0.7, 0.85, 1.0])
	g.gradient.colors = PackedColorArray([Color(0.6, 0.0, 0.05, 0.0), Color(0.6, 0.0, 0.05, 0.25), Color(0.6, 0.0, 0.05, 0.5), Color(0.6, 0.0, 0.05, 0.8)])
	g.fill = GradientTexture2D.FILL_RADIAL
	g.fill_from = Vector2(0.5, 0.5)
	g.fill_to = Vector2(1.0, 0.5)
	return g

var main
var root: Control
var safe: Control  # o HUD de jogo, afastado das bordas e do recorte da câmara (_apply_safe)
var overlay: Control  # por baixo dos botões
var front: Control  # por cima dos botões: recargas, chefe, nível, flash
var status: Label
var toast_label: Label
var toast_t := 0.0
var toasts := []  # H4: os avisos que esperam pelo que está à vista (no máximo 5)
var toast_box: Control  # revisão do L12: a caixa do painel onde vai a resposta dele quando não há lugar à volta (a Forja)
var toast_own := false  # o aviso à vista é essa resposta
var shade: Control  # H3: por baixo do painel aberto (o título escurecido, ou o jogo tapado); só apanha os toques fora do painel (não fecha com um toque fora, de propósito)
var shield: Control  # H2: por cima do painel que abriu sozinho, uns instantes, para o toque ou o A da luta não carregarem num botão
var focus_box: StyleBoxFlat  # A5: o aro do foco, só com comando
var lan_note: Label  # A4: o que aconteceu ao entrar na sala, no próprio painel da Wi-Fi
var lan_since := 0  # UX 28: desde quando o painel da Wi-Fi não vê salas (Time.get_ticks_msec)
var setting_note: Label  # A6: a explicação da opção escolhida, por baixo das linhas das Configurações
var pad: Control
var top_bar: VBoxContainer  # Árvore, Arsenal e Menu em ícones, à esquerda do minimapa (_layout_top)
var interact_btn: Button
var stance_btn: Button  # Guarda Sepulcral ↔ Ira Sacrificial
var trans_btn: Button  # Almas Transitórias (#4): só à vista enquanto o herói tiver uma
var skill_btns := {}
var potion_btns := []
var closed_frame := -1  # frame em que se fechou o último painel
var calm_t := 0.0  # há quanto tempo não há combate (HUD que se esbate)
var panel: Control
var panel_cancel := false  # B (ou o Voltar do Android) fecha este painel
var panel_back := Callable()  # para onde B / Voltar levam (vazio = fecha e volta ao jogo)
var sub_back := Callable()  # Arsenal e Árvore abertos pelo Menu: B volta ao Menu
var gear_who := 0  # Equipamento (0.4.8): o herói de quem abriu o Arsenal (o LS do 2.º comando abre o dele; o ecrã e o Menu, o do jogador 1)
var license_scroll: ScrollContainer  # Licenças e Bestiário: o stick do comando faz rolar o texto
var title_open := false  # no título (e nas Configurações/Sobre abertas dele) ainda não se grava nada
var title_reveal := Callable()  # título: troca o "Toca para começar" pelo menu
var lefty := false  # botões de habilidade à esquerda (set_lefty)
var minimap_rect := Rect2()  # onde ficou o minimapa
var top_line_rect := Rect2()  # e o aviso do cimo ao meio (top_line)
var p2_rect := Rect2()  # e o que está ao lado dele: o 2.º jogador, ou o aviso do 2.º comando
var p2_steady := Rect2()  # #274: o p2_rect sem a linha da Wi-Fi fraca: o Menu e o Atlas põem-se por baixo disto (com ela, saltavam quando a linha aparecia e sumia)
var top_rect := Rect2()  # o canto de cima: botões e minimapa (as setas dos chefes não o tapam)
var orb_rect := Rect2()  # os orbes e as poções (as setas dos chefes também não os tapam)
var filter: ColorRect  # daltonismo e conforto ocular: um filtro por cima de tudo (só existe se for preciso)
var intro_i := -1  # quadro da intro que está a passar (-1 = sem intro)
var intro_t := 0.0
var intro_hold := -1.0  # há quanto tempo o dedo segura na intro (-1 = sem toque); HOLD_SKIP salta tudo
var intro_hint: Control
var panel_frame := 0
var gamepad := false  # o último controlo usado foi um comando: esconde os botões de toque e mostra A/B/X/Y
var last_gamepad := false
var hint_title := ""
var hint_action := ""
var updater: Node  # AppUpdate: avisa no título quando há um APK novo no GitHub
var title_menu: VBoxContainer
var hold_kind := ""  # compra da Forja a ser segurada (ink, ash, bone) ou ""
var hold_t := 0.0
var tree_drag := 0.0  # Árvore: quanto o dedo já arrastou desde que pousou (mais de 12 desliza a folha em vez de escolher o nó)
var find_word := ""  # Árvore: a busca acesa (#97), com o que se tocou ou escreveu, até se limpar
var find_terms := []
var text_k := 1.0  # tamanho do texto (#99, set_text_scale)
var ui_scale_i := 0
var joy_index := -1
var joy_origin := Vector2.ZERO
var joy_pos := Vector2.ZERO
var swipes := {}  # toques fora do joystick: índice -> [onde começou, quando] (deslizar depressa = esquiva)
## Cartão de ajuda: o botão seguro, pelo índice do dedo (o rato do Godot só segue o 1.º dedo, que costuma ser o do joystick)
var info_btn: Button
var info_shown: Button  # o cartão já apareceu para este botão: ao largar, a ação dele não corre
var info_key := ""
var hold_card := Rect2()  # onde ficou o último cartão do toque longo (para os testes)
var info_at := 0
var info_idx := -1
var info_rect := Rect2()
var info_on := false
var last_touch := 0
var enemy_near := false  # algum inimigo a menos de 700 px de um herói (o _fade_hud sem a opção de esbater; o boneco de treino não conta)
var flash_a := 0.0
var fade_a := 0.0  # negro a desvanecer ao mudar de zona (descer/subir as escadas)
var dark := 0.0
var card_t := 0.0
var card_head := "Chefe"  # por cima do nome; "" = sem nada (a relíquia apanhada)
var card_name := ""
var card_sub := ""
var lvl_t := 0.0
var xp_shown := 0.0
var xp_hold := 0.0
var last_level := 1
var vig: Control  # B3: as bordas vermelhas da vida baixa, numa camada com os píxeis à vista
var vig_a := 0.0  # a força delas agora, sem o pulsar (o teste lê-a)
var potion_ring := false  # B3: o anel à volta da poção de vida está desenhado (o teste lê-o)
var low_warned := false  # B3: já vibrou ao passar dos 30% da vida (volta a armar acima dos 40%)
var joy_used := false  # B1: "toca e arrasta para mover" só até o joystick se usar a 1.ª vez
var hint_w := 0.0  # a largura da linha do que dá para fazer, como ficou desenhada
var hint_y := 0.0  # e a altura dela (0 sem linha: nada para fazer, ou à espera que o cartão de um nome saia)
var orb_as := [1.0, 1.0]  # B2: cada esfera (vida, alma) fica transparente com um monstro ou saque por baixo dela, e só ela
var orb_rects := [Rect2(), Rect2()]  # onde ficou cada esfera (com a poção ao lado, no comando)
var covered := {}  # e os botões do ecrã tátil ("orb0", "orb1" = as esferas), procurado de 0,1 em 0,1 s
var cover_t := 0.0
var lost_t := 0.0  # Abismo dos Esquecidos (#211): segundos sem entrar numa sala nova; aos 45 a seta aparece 3 s (cada telemóvel o seu)
var lost_seen := 0
var lost_show := 0.0
var mm_rooms := 0
var move_hint := Rect2()  # C (c): a faixa do "toca e arrasta para mover" no último frame (vazia sem ela; para os testes)
var legend_rect := Rect2()  # C (h): as faixas da legenda do comando ao lado ou por baixo do painel (para os testes)
var legend_at := Vector2.ZERO  # onde ficou a legenda do comando por baixo (ou ao lado) do painel (para os testes)  # as salas do Sepulcro que o minimapa desenhou no último frame (para os testes)
var lit_was := false  # o botão redondo aceso (B5)
var boss_tip := ""  # B4: a frase do cartão do chefe, por baixo da última barra enquanto a barra dele estiver à vista
var boss_tip_of := ""  # o nome do chefe dessa frase
var toast_floor := 172.0  # B4: os avisos nunca acima disto (por baixo das barras, da frase, do cartão do chefe e da linha do que dá para fazer)
var bars_top := 62.0  # B4: onde começa a 1.ª barra dos chefes (mais abaixo com o 2.º herói ao lado)
var stack_y := 0.0  # e onde acaba o que está em cima ao meio (as barras): a linha do que dá para fazer e os avisos vão por baixo
var tip_rect := Rect2()  # a faixa da frase do chefe, por cima das barras (por baixo tapava as marcas dos membros do Colosso Suturado)
var card_rect := Rect2()  # o cartão do chefe à vista (os avisos passam por baixo dele)
var boss_icon_rect := Rect2()  # revisão do Lote 9: o ícone da barra do chefe (a arma da Quimera, a habilidade copiada), no último frame em que se desenhou
var map_btn: Button  # B6: segurar o minimapa mostra a legenda
var coin_btn: Button  # B6: as moedas: tocar abre a Bolsa (G6, #85), segurar diz para que serve cada uma
var scroll_cue: Control  # Lote 10 C (c): a seta "há mais em baixo" da última lista que rola (para os testes)
var forge_lines := 0  # as linhas da caixa de cima da Forja aberta (refeita por uma compra, não encolhe)
var badge_at := 0  # B5: os avisos nos ícones de cima, refeitos de 0,5 em 0,5 s
var badge_key := ""
var badge_gear := false
var badge_full := false
var flasks_seen := -1  # os frascos que o grupo tinha da última vez que o Arsenal abriu
var panel_title := ""  # o título do painel aberto
var tree_sheet: Control  # B7: a folha da Árvore aberta (o brilho dos nós que abrem pulsa)
var tree_btns := {}
var tree_info: Label
var tree_pop := ["", 0]  # o nó acabado de abrir e quando (o anel dourado cresce 0,4 s)
var halo_drawn := false
var tree_labels := []  # os nós com o nome escrito na Árvore aberta (para o teste)
var tree_label_rects := {}  # C (e): e onde ficou cada nome, na folha (para o teste)
var tree_lit := []  # C (e): os nós com o aro do foco ou do 1.º toque à volta, no último desenho da Árvore
var tree_label_at := {}  # C (e): o sítio de cada nome, [língua, tamanho] -> {nó: deslocamento}; muda só com a língua e o tamanho do texto
var tree_lines := {}  # Revisão do Lote 8: os nomes da Árvore de várias palavras partidos em 2 linhas (nó -> [linha 1, linha 2]); vão assim quando o deslocamento é um Vector3
var tree_gap := 17.0  # e a folga entre dois nomes na mesma linha: uma palavra (o tamanho da letra)
var tree_plate: Control  # o quadro dos pontos da Árvore aberta (para o teste)
var hub_tab := 0  # G1: o último separador do Arsenal (o ícone de cima e o LS abrem-no)
var gate_oil := false  # #227: o Óleo de Lápide armado no Atlas: a ida que começar dali vai untada
var gear_slot := ""  # #273: o lugar tocado no Equipamento (a mochila mostra só as peças dele; "" = todas)
var gear_marking := false  # #280: a marcar lixo
var gear_marked := []  # e as peças marcadas (índices da mochila)
var gear_bag := []  # a mochila que essas marcas viram: se mudar, os índices já não servem
var gear_tiles := []  # os quadrados do Equipamento aberto: {b, i (na mochila, -1 nos lugares), s, it, v (o veredicto)}
var pad_lines := []  # Lote 7 C (c): as linhas da legenda do comando nas Configurações (para o teste)
var own_gap := 2.0  # Lote 7 C (d): a folga do nome de um nó da Árvore para o aro dele (tree_own, por cima de 1,5 vezes a distância a esse aro; a 8 px fixos, a Hemorragia e o Mártir do Aço Fúnebre, apertados entre aros, não tinham sítio)
var bars_rect := Rect2()  # Lote 7 C (f): as barras dos chefes com os nomes e a frase por cima, no último frame (a seta do objetivo passa por baixo)
var arrow_at := Vector2.INF  # e onde ficou a seta do objetivo, no ecrã (INF sem seta; para os testes)


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	root = Control.new()
	root.set_anchors_preset(Control.PRESET_FULL_RECT)
	root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.theme = _theme()
	add_child(root)
	safe = Control.new()
	safe.set_anchors_preset(Control.PRESET_FULL_RECT)
	safe.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(safe)
	_apply_safe()
	get_viewport().size_changed.connect(_apply_safe)
	overlay = _layer(_draw_overlay, safe)

	gamepad = not Input.get_connected_joypads().is_empty()
	_focus_ring()
	updater = AppUpdate.new()
	add_child(updater)
	updater.update_available.connect(_on_update)
	updater.check()
	status = _label(Vector2(16, 100), 18)
	status.reparent(safe, false)
	status.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART  # a linha do Cortejo dobra antes da barra do chefe (_process)
	var strip := StyleBoxFlat.new()  # e fica numa faixa escura: lê-se por cima dos nomes do saque e dos monstros
	strip.bg_color = Color(0.0, 0.0, 0.0, 0.6)
	strip.set_content_margin_all(6.0)
	strip.set_corner_radius_all(4)
	status.add_theme_stylebox_override("normal", strip)
	toast_label = _label(Vector2(0, 0), Gothic.TOAST_SIZE)
	toast_label.set_anchors_preset(Control.PRESET_CENTER_TOP)  # H4: a largura segue o texto (_show_toast)
	toast_label.z_index = 10  # H4: por cima dos painéis e da arte do título
	toast_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART  # o mais comprido dobra em vez de sair do ecrã
	toast_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	toast_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER  # a resposta da Forja pode ter a faixa mais alta do que o texto
	toast_label.add_theme_color_override("font_color", Color(1.0, 0.85, 0.5))
	var band: StyleBoxFlat = strip.duplicate()  # numa faixa escura, como a linha de estado
	band.content_margin_left = 10.0
	band.content_margin_right = 10.0
	band.content_margin_top = 4.0
	band.content_margin_bottom = 4.0
	toast_label.add_theme_stylebox_override("normal", band)

	pad = Control.new()
	pad.mouse_filter = Control.MOUSE_FILTER_IGNORE
	pad.set_anchors_preset(Control.PRESET_BOTTOM_RIGHT)
	pad.offset_left = -380
	pad.offset_top = -330
	pad.offset_right = 0
	pad.offset_bottom = 0
	pad.pivot_offset = Vector2(380, 330)
	safe.add_child(pad)
	for i in 3:
		_skill_button(main.player.order[i], SKILL_SPOTS[i][0], SKILL_SPOTS[i][1])
	interact_btn = _round_button("Invocar", Vector2(130, 110), 95, Color(0.6, 0.15, 0.2))
	interact_btn.custom_minimum_size = Vector2(95, 95)  # a largura que o _fit_text dá ao texto
	_watch(interact_btn, "interact", _interact_or_dodge)
	pad.add_child(interact_btn)
	# Postura de Combate, no canto livre do pad (no comando: R3)
	stance_btn = _round_button("", Vector2(30, 14), 70, Color(0.85, 0.8, 0.65))
	stance_btn.expand_icon = true
	stance_btn.add_theme_constant_override("icon_max_width", 40)
	stance_btn.icon_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_watch(stance_btn, "stance", func(): main.player.toggle_stance())
	pad.add_child(stance_btn)
	# Alma Transitória (#4), ao lado da 3.ª habilidade (no comando: LS), com o anel dos 60 s por cima (_draw_front);
	# em x 135 o anel não chega ao botão Menu nem com os botões a 160%
	trans_btn = _round_button("", Vector2(135, 8), 80, Color(0.4, 0.95, 0.9))
	trans_btn.icon = ICONS.transitoria
	trans_btn.expand_icon = true
	trans_btn.add_theme_constant_override("icon_max_width", 50)
	trans_btn.icon_alignment = HORIZONTAL_ALIGNMENT_CENTER
	trans_btn.visible = false
	_watch(trans_btn, "trans", func(): main.player.use_trans())
	pad.add_child(trans_btn)
	# Poções no ecrã tátil, ao lado das habilidades
	for k in [["hp", Vector2(26, 140), Color(0.85, 0.2, 0.2)], ["mp", Vector2(26, 226), Color(0.25, 0.55, 0.95)]]:
		var b := _round_button("", k[1], 64, k[2])
		potion_btns.append(b)
		b.icon = ICONS["potion_" + k[0]]
		b.expand_icon = true
		b.add_theme_constant_override("icon_max_width", 34)
		b.icon_alignment = HORIZONTAL_ALIGNMENT_CENTER
		var kind: String = k[0]
		_watch(b, "potion_" + kind, func(): main.player.use_potion(kind))
		pad.add_child(b)

	top_bar = VBoxContainer.new()
	top_bar.add_theme_constant_override("separation", int(TOP_GAP))
	safe.add_child(top_bar)
	for b in [["tree", _tree], ["arsenal", _arsenal], ["menu", open_menu]]:
		var btn := _round_button("", Vector2.ZERO, TOP_BTN, Color(0.85, 0.8, 0.65))
		btn.custom_minimum_size = Vector2(TOP_BTN, TOP_BTN)
		btn.icon = ICONS[b[0]]
		btn.expand_icon = true
		btn.add_theme_constant_override("icon_max_width", 44)
		btn.icon_alignment = HORIZONTAL_ALIGNMENT_CENTER
		var go: Callable = b[1]
		_watch(btn, b[0], func():  # segurar mostra o que abre (_info_text)
			if panel == null or panel_cancel:  # como no comando: o painel que não se fecha (a maldição do Mausoléu, a morte) não se fecha por aqui
				go.call())
		top_bar.add_child(btn)
	map_btn = _ghost_button("minimap", null)  # B6: o minimapa e as moedas
	coin_btn = _ghost_button("coins", func():
		if panel == null:
			open_bag())
	coin_btn.position = Vector2(16, 62)  # 48 px de altura, a do dedo: entre as barras (acabam aos 60) e a linha de baixo
	coin_btn.size = Vector2(222, 48)
	vig = _layer(_draw_vignette)
	vig.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST  # os degraus da vinheta à vista
	root.move_child(vig, 0)  # por baixo do HUD: só o mundo fica vermelho (por cima, os botões e as barras desbotavam)
	front = _layer(_draw_front)


## B6: um botão sem desenho por cima do que o HUD desenha (o minimapa, as moedas): segurar explica, tocar faz cb.
func _ghost_button(key: String, cb) -> Button:
	var b := Button.new()
	b.flat = true
	b.focus_mode = Control.FOCUS_NONE
	for st in ["normal", "hover", "pressed", "focus", "disabled"]:
		b.add_theme_stylebox_override(st, StyleBoxEmpty.new())
	_watch(b, key, cb)
	safe.add_child(b)
	return b


func _layer(cb: Callable, parent: Control = null) -> Control:
	var c := Control.new()
	c.set_anchors_preset(Control.PRESET_FULL_RECT)
	c.mouse_filter = Control.MOUSE_FILTER_IGNORE
	c.draw.connect(cb)
	(parent if parent else root).add_child(c)
	return c


## Margem segura do HUD de jogo: 16 px a mais em todo o lado (os elementos já trazem ~12 px de folga: ~28 px,
## uns 16 dp num telemóvel) e, no telemóvel, o recorte da câmara. O recorte conta dos dois lados porque o ecrã
## roda 180° sem mudar de tamanho.
func _apply_safe() -> void:
	var side := 16.0
	var top := 16.0
	var bottom := 16.0
	if OS.has_feature("mobile"):
		var sa := Rect2(DisplayServer.get_display_safe_area())
		var ws := Vector2(DisplayServer.window_get_size())
		var k := root.get_viewport_rect().size / ws
		side = maxf(side, maxf(sa.position.x, ws.x - sa.end.x) * k.x)
		top = maxf(top, sa.position.y * k.y)
		bottom = maxf(bottom, (ws.y - sa.end.y) * k.y)
	safe.offset_left = side
	safe.offset_right = -side
	safe.offset_top = top
	safe.offset_bottom = -bottom


func _sbt(tex: Texture2D, mod: Color) -> StyleBoxTexture:
	var s := StyleBoxTexture.new()
	s.texture = tex
	s.set_texture_margin_all(18.0)
	s.content_margin_left = 22.0
	s.content_margin_right = 22.0
	s.content_margin_top = 6.0
	s.content_margin_bottom = 6.0
	s.modulate_color = mod
	return s


## Painéis com a moldura de ferro e osso, botões com a placa da SC-UI2 (acesa quando premida).
func _theme() -> Theme:
	var th := Theme.new()
	th.default_font = Gothic.BODY
	th.default_font_size = Gothic.BODY_SIZE
	var pn := StyleBoxTexture.new()
	pn.texture = UI.panel
	pn.set_texture_margin_all(96.0)
	pn.set_content_margin_all(38.0)
	th.set_stylebox("panel", "PanelContainer", pn)
	th.set_stylebox("normal", "Button", _sbt(UI.btn, Color.WHITE))
	th.set_stylebox("hover", "Button", _sbt(UI.btn, Color(1.3, 1.3, 1.25)))
	th.set_stylebox("pressed", "Button", _sbt(UI.btn_on, Color.WHITE))
	th.set_stylebox("disabled", "Button", _sbt(UI.btn, Color(0.5, 0.5, 0.5)))
	focus_box = StyleBoxFlat.new()  # o "focus" dos botões e das barras põe-no o _focus_ring (só com comando)
	focus_box.draw_center = false
	focus_box.set_border_width_all(3)
	focus_box.border_color = Color(0.55, 1.0, 0.7)
	focus_box.set_corner_radius_all(6)
	focus_box.set_expand_margin_all(3.0)
	# Barras de volume: calha escura com aro de osso, cheia a verde-alma
	var track := StyleBoxFlat.new()
	track.bg_color = Color(0.05, 0.06, 0.06)
	track.border_color = Color(0.5, 0.45, 0.34)
	track.set_border_width_all(2)
	track.set_corner_radius_all(6)
	track.content_margin_top = 5.0
	track.content_margin_bottom = 5.0
	th.set_stylebox("slider", "HSlider", track)
	var fill := StyleBoxFlat.new()
	fill.bg_color = Color(0.28, 0.8, 0.5)
	fill.set_corner_radius_all(6)
	th.set_stylebox("grabber_area", "HSlider", fill)
	var lit: StyleBoxFlat = fill.duplicate()
	lit.bg_color = Color(0.45, 1.0, 0.65)
	th.set_stylebox("grabber_area_highlight", "HSlider", lit)
	for c in ["font_color", "font_hover_color", "font_focus_color"]:
		th.set_color(c, "Button", Color(0.93, 0.89, 0.76))
	th.set_color("font_pressed_color", "Button", Color.WHITE)
	# Botões com a letra do texto (não a do sistema), com contorno escuro para se lerem em cima da arte
	th.set_font("font", "Button", Gothic.BODY)
	th.set_font_size("font_size", "Button", Gothic.BODY_SIZE)
	th.set_constant("outline_size", "Button", 5)
	th.set_color("font_outline_color", "Button", Color(0.02, 0.02, 0.02))
	return th


## A5: o aro do foco só aparece com comando; no ecrã tátil o botão com o foco parecia já escolhido.
func _focus_ring() -> void:
	var fo: StyleBox = focus_box if gamepad else StyleBoxEmpty.new()
	root.theme.set_stylebox("focus", "Button", fo)
	root.theme.set_stylebox("focus", "HSlider", fo)


func _label(pos: Vector2, size: int) -> Label:
	var l := Label.new()
	l.position = pos
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_outline_color", Color.BLACK)
	l.add_theme_constant_override("outline_size", 6)
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(l)
	return l


func _round_button(text: String, pos: Vector2, d: float, tint: Color) -> Button:
	var b := Button.new()
	b.text = text
	b.position = pos
	b.size = Vector2(d, d)
	b.focus_mode = Control.FOCUS_NONE
	for st in ["normal", "hover", "pressed"]:
		var sb := StyleBoxFlat.new()
		sb.bg_color = Color(0.04, 0.07, 0.07, 0.75) if st != "pressed" else Color(tint, 0.6)
		sb.border_color = tint
		sb.set_border_width_all(3)
		sb.set_corner_radius_all(int(d / 2))
		b.add_theme_stylebox_override(st, sb)
	return b


## O herói deste telemóvel mudou (o convidado da Wi-Fi fica com o outro herói): botões com as habilidades dele.
func skills_for_player() -> void:
	for b in skill_btns.values():
		b.free()
	skill_btns.clear()
	for i in 3:
		var spot: Array = SKILL_SPOTS[i]
		_skill_button(main.player.order[i], Vector2(380.0 - spot[0].x - spot[1], spot[0].y) if lefty else spot[0], spot[1])


## Botão de habilidade = o ícone redondo da folha SC-ICO3.
func _skill_button(id: String, pos: Vector2, d: float) -> void:
	var b := Button.new()
	b.position = pos
	b.size = Vector2(d, d)
	b.focus_mode = Control.FOCUS_NONE
	for st in ["normal", "hover", "pressed"]:
		var sb := StyleBoxTexture.new()
		sb.texture = ICONS[id]
		sb.modulate_color = Color(0.7, 0.7, 0.7) if st == "pressed" else Color.WHITE
		b.add_theme_stylebox_override(st, sb)
	b.button_down.connect(func(): main.player.held[id] = true)
	b.button_up.connect(func(): main.player.held[id] = false)
	_watch(b, id)
	skill_btns[id] = b
	pad.add_child(b)


## Segurar o botão b mostra o cartão de key ("interact", "stance", "potion_hp"/"potion_mp", "tree"/"arsenal"/"menu" ou a habilidade).
## cb = a ação do botão (ao largar): não corre se o cartão chegou a aparecer, venha o pressed antes ou depois do button_up.
func _watch(b: Button, key: String, cb = null) -> void:
	b.button_down.connect(func():
		info_btn = b
		info_key = key
		info_at = Time.get_ticks_msec()
		info_idx = last_touch  # o 2.º dedo chega ao _input antes do botão; o 1.º só depois (o _input corrige-o)
		info_rect = b.get_global_rect()
		if info_shown == b:
			info_shown = null)
	b.button_up.connect(func():
		if info_btn == b:
			info_btn = null)
	if cb != null:
		b.pressed.connect(func():
			if info_shown == b:
				info_shown = null
			else:
				cb.call())


func set_ui_scale(i: int) -> void:
	ui_scale_i = clampi(i, 0, SCALES.size() - 1)
	pad.scale = Vector2.ONE * SCALES[ui_scale_i]


## Canhoto: os botões de habilidade passam para o canto de baixo à esquerda (espelhados) e o joystick
## para a metade direita do ecrã.
func set_lefty(on: bool) -> void:
	if on == lefty:
		return
	lefty = on
	for c in pad.get_children():
		c.position.x = 380.0 - c.position.x - c.size.x
	pad.anchor_left = 0.0 if on else 1.0
	pad.anchor_right = pad.anchor_left
	pad.offset_left = 0.0 if on else -380.0
	pad.offset_right = pad.offset_left + 380.0
	pad.pivot_offset = Vector2(0.0 if on else 380.0, 330)


## Interface fora de combate: 3 s sem inimigos perto, com a vida cheia e sem Cortejo (nem o ar do Miasma, a maré, um
## evento do cemitério ou um modo a contar), as barras, as moedas e o minimapa ficam quase transparentes; voltam logo ao primeiro sinal de luta. Os
## botões ficam como estão.
func _fade_hud(delta: float) -> void:
	var fight: bool = not main.settings.hud_fade or main.cortejo.active or panel != null or main.crypt_rule == "submersa" or (main.crypt_rule == "miasma" and main.breath_end < INF) \
			or main.arena_r > 0.0 or not main.event.is_empty() or main.zone == "sep"
	enemy_near = false
	for p in main.players:
		fight = fight or p.hp < p.max_hp * 0.99 or p.dead
		for e in main.enemies():
			var near: bool = p.position.distance_squared_to(e.position) < 700.0 * 700.0
			fight = fight or near
			enemy_near = enemy_near or (near and not e.dummy)  # ao pé do boneco de treino os cartões das habilidades abrem-se
	calm_t = 0.0 if fight else calm_t + delta
	overlay.modulate.a = move_toward(overlay.modulate.a, 0.22 if calm_t > 3.0 else 1.0, delta * (1.5 if calm_t > 3.0 else 6.0))
	status.modulate.a = overlay.modulate.a


## Botões de poção maiores para o toque de pânico: o de cima cresce para cima e o de baixo para baixo.
func set_potion_scale(i: int) -> void:
	for j in potion_btns.size():
		var b: Button = potion_btns[j]
		b.pivot_offset = Vector2(b.size.x / 2.0, b.size.y if j == 0 else 8.0)
		b.scale = Vector2.ONE * [1.0, 1.25, 1.5][i]


## Tamanho do texto (#99): a letra do tema (painéis, botões, menus), os avisos, a linha de estado e o corpo dos
## cartões de ajuda. Os títulos na letra gótica ficam como estão (só fica nítida em múltiplos de 16).
func set_text_scale(k: float) -> void:
	text_k = k
	Gothic.k = k  # H6: o texto pequeno na Augusta (gothic.gd) também
	root.theme.default_font_size = roundi(Gothic.BODY_SIZE * k)
	root.theme.set_font_size("font_size", "Button", roundi(Gothic.BODY_SIZE * k))
	toast_label.add_theme_font_size_override("font_size", roundi(Gothic.TOAST_SIZE * k))
	status.add_theme_font_size_override("font_size", roundi(18 * k))


## Daltonismo (mode 0..3) e conforto ocular (0..1): só desenha o filtro com algum ligado.
func set_filter(mode: int, comfort: float) -> void:
	if filter == null:
		if mode == 0 and comfort == 0.0:
			return
		var layer := CanvasLayer.new()
		layer.layer = 128
		add_child(layer)
		filter = ColorRect.new()
		filter.set_anchors_preset(Control.PRESET_FULL_RECT)
		filter.mouse_filter = Control.MOUSE_FILTER_IGNORE
		filter.material = ShaderMaterial.new()
		filter.material.shader = FILTER
		layer.add_child(filter)
	filter.material.set_shader_parameter("mode", mode)
	filter.material.set_shader_parameter("comfort", comfort)
	filter.visible = mode > 0 or comfort > 0.0


## H4: um aviso de cada vez, numa faixa escura do tamanho do texto, por cima de tudo; dura conforme o comprimento. Um aviso
## novo com o de agora ainda bem à vista vai para a fila (até 5, sem repetidos) e aparece quando este acabar. Com 3, as peças
## do guardião apanhadas logo deitavam fora a Foice Longa e a Bolsa de Almas da primeira vitória (revisão final).
func toast(text: String, local := false) -> void:
	if not local:
		Net.echo("hud", "toast", [text])
	if toast_t > 0.8 or not toasts.is_empty():
		if not (toast_t > 0.0 and text == toast_label.text) and not text in toasts:
			toasts.append(text)
			if toasts.size() > 5:
				toasts.pop_front()
		return
	_show_toast(text)


## Os avisos são do sítio e do Cortejo de onde vieram: ao mudar de zona e no fim do Cortejo saem todos, o de agora e
## os da fila (o cartão de um nome segura-os, e de cartão em cartão chegavam a outra zona ou a outro chefe).
func drop_toasts() -> void:
	Net.echo("hud", "drop_toasts", [])
	toasts.clear()
	toast_t = 0.0


## Lote 9 C (b): tira um aviso que deixou de ser verdade (à vista ou na fila), também o que vem no fim de outro.
func unsay(text: String) -> void:
	Net.echo("hud", "unsay", [text])
	var said := func(t: String) -> bool: return t == text or t.ends_with("\n" + tr(text))
	toasts = toasts.filter(func(t): return not said.call(t))
	if toast_t > 0.0 and said.call(toast_label.text):
		toast_t = 0.0


func _show_toast(text: String, box: Control = null) -> void:
	toast_label.text = text
	toast_box = box
	toast_own = box != null
	var t := tr(text)
	toast_t = clampf(1.5 + t.length() * 0.05, 3.0, 7.0)
	_place_toast()


## Lote 12 C (h): um aviso em r (no ecrã) a menos de 8 px das esferas, ou em cima das poções e do número das cargas (ou de outro
## botão redondo): por baixo do Menu, o aviso da entrada do 2.º jogador tapava o "3" da poção.
func _toast_hits(r: Rect2) -> bool:
	return r.intersects(Rect2(orb_rect.position + overlay.global_position, orb_rect.size).grow(TOAST_GAP)) or pad_rects().any(func(q): return q.intersects(r))


## Onde fica o aviso: em cima, ao meio; com um painel aberto, logo por baixo dele se couber, senão por cima; com um painel
## alto, ao lado dele (no lado mais largo, a dobrar), para nunca tapar a moldura, se a coluna tiver 300 px. Sem lugar, devolve
## false e o aviso espera, sem perder tempo, que o painel feche (_process).
func _place_toast() -> bool:
	# a largura numa linha, medida aqui: o tamanho do texto pode mudar com o aviso à vista
	var font := toast_label.get_theme_font("font")
	var fs := toast_label.get_theme_font_size("font_size")
	var pad := toast_label.get_theme_stylebox("normal").get_minimum_size()
	var toast_w := minf(font.get_multiline_string_size(tr(toast_label.text), HORIZONTAL_ALIGNMENT_CENTER, -1, fs).x + 24.0, root.get_viewport_rect().size.x - 80.0)
	var tall := func(w: float) -> float:  # a altura com a largura w, medida na letra: escondido, o Label guarda a altura da última largura
		var n := roundi(font.get_multiline_string_size(tr(toast_label.text), HORIZONTAL_ALIGNMENT_CENTER, w - pad.x, fs).y / font.get_height(fs))
		return n * font.get_height(fs) + (n - 1) * toast_label.get_theme_constant("line_spacing") + pad.y
	toast_label.offset_left = -toast_w / 2.0
	toast_label.offset_right = toast_w / 2.0
	var h: float = tall.call(toast_w)
	var over := false
	var top := toast_floor  # B4: por baixo das barras dos chefes, da frase, do cartão (tapava o "Chefe") e da linha do que dá para fazer
	if panel is PanelContainer:
		var vs := root.get_viewport_rect().size
		var pr: Rect2 = panel.get_global_rect()
		if pr.end.y + TOAST_GAP + h <= vs.y - XP_ROOM and not _toast_hits(Rect2(vs.x / 2.0 - toast_w / 2.0, pr.end.y + TOAST_GAP, toast_w, h)):  # C (c): por cima da barra da experiência e do "Nv"; Lote 11 C (c): a 8 px da moldura (a 4 encostava aos cantos dela)
			top = pr.end.y + TOAST_GAP
		elif pr.position.y - TOAST_GAP - h >= 2.0 and not plates().any(func(q): return q.intersects(Rect2(vs.x / 2.0 - toast_w / 2.0, pr.position.y - TOAST_GAP - h, toast_w, h))):  # revisão do Lote 9: por cima do painel tapava a vida do 2.º herói
			top = pr.position.y - TOAST_GAP - h
		elif maxf(pr.position.x, vs.x - pr.end.x) >= 300.0:  # C (e): no cimo do ecrã a faixa escura tapava a borda e os ornatos de cima da moldura; numa coluna de 200 px ia em 5 linhas
			var room := maxf(pr.position.x, vs.x - pr.end.x) - 16.0
			var w := minf(toast_w, room)
			var on_left: bool = pr.position.x >= vs.x - pr.end.x
			var x: float = (8.0 if on_left else pr.end.x + 8.0) + (room - w) / 2.0
			toast_label.offset_left = x - vs.x / 2.0
			toast_label.offset_right = x + w - vs.x / 2.0
			h = tall.call(w)
			top = clampf(maxf(pr.position.y + 60.0, 150.0 if on_left else top_box().end.y + 8.0), 8.0, vs.y - h - XP_ROOM)  # por baixo da vida, da alma e das moedas (ou dos botões de cima, no ecrã: com a margem segura)
		elif toast_own:  # revisão do L12: a resposta da Forja por cima do fundo da caixa de texto dela (à espera, só se via com a Forja fechada)
			if not is_instance_valid(toast_box) or not panel.is_ancestor_of(toast_box):
				toast_t = 0.0  # a Forja refez-se com outra compra: esta resposta já passou
				return false
			var br := toast_box.get_global_rect()
			var bw := minf(toast_w, br.size.x)
			toast_label.offset_left = br.get_center().x - bw / 2.0 - vs.x / 2.0
			toast_label.offset_right = br.get_center().x + bw / 2.0 - vs.x / 2.0
			h = tall.call(bw)
			top = br.end.y - h
			if toast_box is RichTextLabel and toast_box.get_line_count() > 0:  # revisão do L12: o cimo entre duas linhas (cortava as pernas das letras da de cima)
				var ch: float = toast_box.get_content_height() * br.size.y / maxf(toast_box.size.y, 1.0)  # o texto vai ao meio da caixa
				var lh: float = ch / toast_box.get_line_count()
				var t0: float = br.get_center().y - ch / 2.0
				var lt: float = t0 + floorf((top - t0) / lh + 0.001) * lh
				if lt >= br.position.y - 0.5:  # só sobe (a faixa cresce para cima e o texto dela vai ao meio)
					top = lt
					h = br.end.y - top
			over = true
		else:  # o painel enche o ecrã
			return false
	var band: StyleBoxFlat = toast_label.get_theme_stylebox("normal")
	band.bg_color.a = 1.0 if over else 0.6  # por cima do texto da caixa, a faixa opaca (a 0,6 liam-se as duas coisas; a 0,92 ainda se viam as linhas)
	toast_label.offset_top = top
	toast_label.offset_bottom = top + h
	return true


func flash(a: float) -> void:
	Net.echo("hud", "flash", [a])
	if main.settings.flash:
		flash_a = maxf(flash_a, a)


func fade() -> void:
	fade_a = 1.0


func name_card(n: String, sub: String, head := "Chefe") -> void:
	Net.echo("hud", "name_card", [n, sub, head])
	card_head = head
	card_name = n
	card_sub = sub
	card_t = CARD_T
	Loot._ranked = -1000  # C (d): os nomes do saque saem já da faixa do cartão (Loot.rank)
	if head == "Chefe":
		boss_tip = sub  # B4: fica por baixo da barra depois de o cartão sair
		boss_tip_of = n


func level_up() -> void:
	Net.echo("hud", "level_up", [])  # o convidado também vê o aviso
	lvl_t = LVL_T


func _process(delta: float) -> void:
	_fade_hud(delta)
	_hold_buy_tick(delta)
	if not is_instance_valid(info_btn):
		info_btn = null  # skills_for_player troca os botões de habilidade
	if not is_instance_valid(info_shown):
		info_shown = null
	# Habilidades: segurar é atacar sem parar, por isso o cartão delas só aparece longe de inimigos
	var was_on := info_on
	info_on = info_btn != null and panel == null and Time.get_ticks_msec() - info_at >= HOLD_INFO * 1000.0 \
			and (not enemy_near or not skill_btns.has(info_key)) and _info_text(info_key)[1] != ""
	if was_on and not info_on and info_btn != null and panel == null and enemy_near and skill_btns.has(info_key):
		main.player.held[info_key] = true  # chegou um inimigo com o dedo ainda no botão: o cartão fecha e o herói volta a golpear
	if info_on and info_shown != info_btn:
		info_shown = info_btn
		if skill_btns.has(info_key):
			main.player.held[info_key] = false  # a ler o cartão, o herói pára de repetir o golpe (volta no toque seguinte)
		else:
			main.vibrate(25, 0.4, main.player)
	# Primeira vez com o ecrã tátil: diz que segurar um botão explica-o (só neste telemóvel: não vai ao convidado)
	if panel == null and not title_open and intro_i < 0 and not gamepad and not main.settings.hold_hint:
		toast("Fora de combate, segura um botão para saber o que faz", true)
		main.settings.hold_hint = true
		main.save_settings()
	if intro_i >= 0:
		intro_t -= delta
		if intro_hold >= 0.0:
			intro_hold += delta
			intro_hint.queue_redraw()
			if intro_hold >= HOLD_SKIP:
				intro_hold = -1.0
				_intro_end()
		elif intro_t <= 0.0:
			_intro_next()
	var held: bool = card_t > 0.0 and not panel is PanelContainer  # B4: com o cartão de um nome à vista o aviso espera, sem perder tempo (em cima tapava o "Chefe", por baixo o herói)
	if toast_t <= 0.0 and not toasts.is_empty():
		_show_toast(toasts.pop_front())
	if toast_t > 0.0 and not held:
		held = not _place_toast()  # o painel pode ter aberto, fechado ou mudado de tamanho; sem lugar à volta dele, o aviso espera
	if not held:
		toast_t -= delta
	toast_label.visible = toast_t > 0.0 and not held
	flash_a = maxf(0.0, flash_a - delta * 3.0)
	fade_a = maxf(0.0, fade_a - delta * 1.4)
	card_t -= delta
	lvl_t -= delta
	dark = lerpf(dark, 0.45 if main.rumble > 0.0 else 0.0, 1.0 - exp(-3.0 * delta))
	# XP: enche devagar; ao subir de nível fica cheia a piscar um instante e só depois recomeça
	if main.level != last_level:
		last_level = main.level
		xp_hold = 0.5
		xp_shown = 1.0
	if xp_hold > 0.0:
		xp_hold -= delta
		if xp_hold <= 0.0:
			xp_shown = 0.0
	else:
		xp_shown = lerpf(xp_shown, float(main.xp) / main.xp_needed(), 1.0 - exp(-6.0 * delta))
	var st := ""  # a foice e o oculto estão no Arsenal (e no cartão do botão dele)
	if main.cortejo.active:
		var names := []
		for a in main.cortejo.affixes:
			names.append(tr(main.AFFIXES[a][0]))
		st = tr("CORTEJO FÚNEBRE — onda %d de %d\nrestantes: %d   afixos: %s") % [main.cortejo.wave, main.WAVES, main.cortejo.alive, ", ".join(names) if names else tr("nenhum")]
	elif main.mausoleum > 0:  # Mausoléu Sem Fim (#27): o piso, o tempo que lhe falta e as maldições
		var cs := []
		for k in main.SEALS:
			var n: int = main.curses.count(k)
			if n > 0:
				cs.append(tr(main.AFFIXES[k][0]) + (" ×" + str(n) if n > 1 else ""))
		var at: String = tr("Piso %d · %d s") % [main.mausoleum, ceili(maxf(0.0, main.floor_end - main.time))] if main.floor_end < INF else tr("Piso %d · chefe") % main.mausoleum
		st = tr("MAUSOLÉU SEM FIM — %s   maldições: %s") % [at, ", ".join(cs) if cs else tr("nenhuma")]
	elif main.sanctum_rule > 0:  # Santuário dos Deuses Cadavéricos (#50): a lei de agora e o que ela muda
		var law: Array = main.LAWS[main.sanctum_rule - 1]
		st = tr("SANTUÁRIO — %s: %s. %s") % [tr(law[0]), tr(law[1]), tr(law[2])]
	var sw: float = root.get_viewport_rect().size.x * 0.5 - 230.0 - safe.offset_left - 24.0  # até à barra do chefe (460 px, ao meio)
	if main.zone == "sep" and main.mausoleum == 0 and main.sanctum_rule == 0 and not main.cortejo.active:
		var sp := [tr("Profundidade %d") % main.sep_depth()]
		if main.crypt_rule != "":
			sp.append(tr(main.CRYPT_RULES[main.crypt_rule][0]))
		if main.sep_bonus() > 0:
			sp.append("+" + "%d%%" % main.sep_bonus())
		st = _dots(sp.map(_whole), sw - 12.0, status.get_theme_font("font"), status.get_theme_font_size("font_size"))  # Lote 7 C (h): só muda de linha nos " · ": o nome da regra nunca se parte ao meio
	if status.text != st:  # uma escrita por frame: com o texto a "" primeiro, a Label voltava a dar forma a cada frame
		status.text = st
	status.visible = st != ""
	status.size = Vector2(sw, 0.0)  # a altura segue o texto
	# O que dá para fazer aqui (B no comando, ou o botão redondo no ecrã)
	var door: String = main.near_door(main.player)
	hint_title = ""
	hint_action = ""
	var soul = main.soul_target(main.player)
	var gi: int = main.near_gate(main.player)
	if soul != null:  # Execução Espectral / extração da Alma Ancestral: vem antes de tudo, a meio da luta
		hint_title = soul.who()
		hint_action = "Extrair" if soul.extractable() else "Executar"
	elif main.near_chest():
		hint_title = "Relicário selado"
		hint_action = "Abrir"
	elif gi >= 0:  # S10: o Recipiente de Sangue do Cofre (#32) e as Portas de Costelas (#191); o preço da porta está no toque longo
		var sangue: bool = main.sep.gates[gi][1] == "sangue"
		hint_title = "Recipiente de Sangue: 15% da vida" if sangue else "Porta de Costelas"
		hint_action = "Encher" if sangue else "Sacrificar"
	elif door != "":
		hint_title = tr("O próximo relicário vale +%d%%") % main.sep_bonus(1) if door == "sep_down" else DOOR_HINT[door][0]
		hint_action = DOOR_HINT[door][1]
	elif main.near_monument():
		hint_title = "Monumento Fúnebre"
		hint_action = "Invocar"
	elif main.near_altar():  # Coração de Titã (#70)
		hint_title = "Coração de Titã Petrificado"
		hint_action = "Oferecer"
	# O Pacto (#101) tira a esquiva: sem nada para fazer aqui o botão some (um botão que não faz nada só confundia)
	interact_btn.visible = hint_action != "" or main.player.stat("pacto") <= 0.0
	var ira: bool = main.player.stance == "ira"
	stance_btn.icon = ICONS["ira" if ira else "guarda"]
	stance_btn.get_theme_stylebox("normal").border_color = Color(0.95, 0.2, 0.15) if ira else Color(0.85, 0.8, 0.65)
	trans_btn.visible = main.player.trans_until > main.time
	var lit: bool = hint_action != ""  # B5: com alguma coisa para fazer aqui, o botão redondo fica com aro dourado e pulsa
	if lit != lit_was:
		lit_was = lit
		for sk in ["normal", "hover"]:
			var sb: StyleBoxFlat = interact_btn.get_theme_stylebox(sk)
			sb.border_color = Color(1.0, 0.82, 0.35) if lit else Color(0.6, 0.15, 0.2)
			sb.set_border_width_all(5 if lit else 3)
	var it: String = hint_action if hint_action != "" else "Esquiva"
	if interact_btn.text != it or interact_btn.get_meta("k", 0.0) != text_k:  # a 130% "Sacrificar" alargava o botão redondo, e um botão nunca volta a encolher: a letra é que encolhe
		interact_btn.text = it
		interact_btn.set_meta("k", text_k)
		interact_btn.remove_theme_font_size_override("font_size")
		_fit_text(interact_btn)
		interact_btn.size = interact_btn.custom_minimum_size  # o texto novo já o tinha alargado
	interact_btn.pivot_offset = interact_btn.size / 2.0
	interact_btn.scale = Vector2.ONE * (1.0 + 0.04 * (1.0 - cos(TAU * Time.get_ticks_msec() / 800.0)) if lit else 1.0)
	# B2: os botões e as esferas por cima de um monstro ou de saque ficam transparentes (os toques continuam a contar)
	if main.zone == "sep" and main.crypt_rule == "esquecidos":
		var seen: int = main.sep.get("rooms", []).filter(func(r): return r.seen).size()
		lost_t = 0.0 if seen != lost_seen else lost_t + delta
		lost_seen = seen
		lost_show = maxf(0.0, lost_show - delta)
		if lost_t >= 45.0:
			lost_t = 0.0
			lost_show = 3.0
	cover_t -= delta
	if cover_t <= 0.0:
		cover_t = 0.1
		_scan_covers()
	for b in pad.get_children():
		if b is Button:
			b.modulate.a = move_toward(b.modulate.a, 0.35 if covered.has(b) else 1.0, 6.0 * delta)
	for i in 2:  # C (h): só a esfera tapada; um esqueleto na borda da moldura apagava as duas
		orb_as[i] = move_toward(orb_as[i], 0.35 if covered.has(ORB_KEYS[i]) else 1.0, 6.0 * delta)
	for i in potion_btns.size():  # sem cargas a poção fica cinzenta (a de vida também com o Sangue Negro, #117)
		var pn: float = main.player.potions["hp" if i == 0 else "mp"]
		potion_btns[i].self_modulate = Color.WHITE if pn >= 1.0 and not (i == 0 and main.player.stat("sangue") > 0.0) else Color(0.42, 0.42, 0.42)
	# B3: uma vibração ao passar dos 30% da vida (volta a armar acima dos 40%)
	var me = main.player
	if not low_warned and not me.dead and me.hp < me.max_hp * 0.3:
		low_warned = true
		main.vibrate(60, 0.6, me)
	elif low_warned and me.hp > me.max_hp * 0.4:
		low_warned = false
	if boss_tip != "" and card_t < -4.0 and stack_y == 0.0:  # stack_y: 0 sem barras no último frame (o _draw_front já as contou)
		boss_tip = ""  # B4: a frase sai uns segundos depois de não haver barras
	if is_instance_valid(tree_sheet) and (halo_drawn or Time.get_ticks_msec() - tree_pop[1] < 450):
		tree_sheet.queue_redraw()  # B7: o brilho dos nós que abrem pulsa, e o anel do que abriu cresce
	pad.visible = not gamepad
	top_bar.visible = not gamepad
	safe.visible = not title_open  # A3: no título (e nos painéis abertos dele) o HUD do jogo gravado não se vê nem se toca
	_layout_top()
	if gamepad != last_gamepad:
		last_gamepad = gamepad
		_focus_ring()
		root.propagate_call("queue_redraw")  # o título e os painéis desenham as legendas do modo novo
	if gamepad and is_instance_valid(shade):
		shade.queue_redraw()  # a legenda do comando segue a moldura do painel
	# Menu = menu do jogo, Vista = Árvore de quem carregou; com um painel aberto, voltam atrás (como o B)
	var fresh: bool = Engine.get_process_frames() > panel_frame  # o botão que abriu o painel não o fecha logo
	for i in main.players.size():
		var pfx := "" if i == 0 else "p2_"
		for a in ["menu", "tree", "arsenal"]:
			if Input.is_action_just_pressed(pfx + a) and not main.players[i].dead:
				if panel == null:
					if a == "menu":
						open_menu()
					elif a == "arsenal" and main.players[i].trans_until > main.time:  # com uma Alma Transitória (#4), o LS liberta-a
						main.players[i].use_trans()
					elif a == "arsenal":
						_arsenal(i)
					else:
						_tree(i)
				elif panel_cancel and fresh:
					_back()
	if panel != null and panel_cancel and fresh and Input.is_action_just_pressed("ui_cancel"):
		_back()
	var scroll_step := int(Input.get_axis("ui_up", "ui_down") * 700.0 * delta)
	if scroll_step != 0 and is_instance_valid(license_scroll):  # escrever no scroll_vertical, mesmo +0, cancela o arrasto do dedo
		license_scroll.scroll_vertical += scroll_step
	if panel is PanelContainer:  # S1: um painel maior do que o ecrã (texto grande, co-op) encolhe à volta do meio até caber
		var menu := panel_title == "Menu"
		if menu:  # revisão do Lote 11: e o Menu desce se o 2.º jogador entra com ele aberto (o anfitrião a ler o endereço da sala)
			panel.offset_top = _menu_top()
		var room := Rect2(Vector2.ZERO, root.get_viewport_rect().size)
		var atlas := panel_title == "Atlas dos Sepulcros"
		if atlas:  # Lote 12 C (b): no que fica livre
			room = free_rect()
		var s := minf(1.0, minf(room.size.x / maxf(panel.size.x, 1.0), room.size.y / maxf(panel.size.y, 1.0)))
		panel.pivot_offset = panel.size / 2.0
		panel.scale = Vector2.ONE * s
		var side: bool = menu or panel_title == "De volta ao cemitério"  # revisão final: a volta dos Sepulcros também (com muito trazido, o canto tapava as cargas)
		var col: Rect2 = potion_col() if atlas or side else Rect2()
		if atlas:  # revisão do L12: o mais perto do meio do ecrã que isso deixa e assente em baixo; as poções e as cargas, todas ou nada
			var half: Vector2 = panel.size * s / 2.0
			var lo: float = room.position.x + half.x
			var hi: float = room.end.x - half.x
			var cx: float = clampf(root.get_viewport_rect().size.x / 2.0, lo, hi)
			if col.has_area() and [cx - half.x, cx + half.x].any(func(e): return col.position.x < e and e < col.end.x):  # uma borda a meio da coluna: passa para a beira dela
				var at := cx
				for c in [col.position.x - half.x, col.end.x - half.x, col.position.x + half.x, col.end.x + half.x]:
					if c >= lo - 0.5 and c <= hi + 0.5 and (at == cx or absf(c - cx) < absf(at - cx)):
						at = c
				cx = at
			var d: Vector2 = Vector2(cx, room.end.y - half.y) - panel.get_global_rect().get_center()
			panel.offset_left += d.x
			panel.offset_right += d.x
			panel.offset_top += d.y
			panel.offset_bottom += d.y
		elif s < 1.0:  # Lote 8: e fica ao meio do ecrã, todo à vista (a Forja a 130%, com a linha da alma da arma, ficava 23 px abaixo do fundo)
			var g: Rect2 = panel.get_global_rect()
			panel.pivot_offset += (room.position + (room.size - g.size) / 2.0 - g.position) / (1.0 - s)
		elif side:  # revisão final: ao meio, o canto de baixo da moldura tapava o cimo da poção de vida e o número das cargas. Como o
			# Atlas, a coluna fica toda à vista ou toda tapada: o painel passa para o lado dela e, se aí o Menu cortasse a vida e as
			# moedas do primeiro jogador, desce para debaixo delas
			var w: float = panel.size.x
			var top: float = panel.get_global_rect().position.y  # a volta dos Sepulcros fica ao meio na vertical; o Menu, no _menu_top
			var cx: float = room.size.x / 2.0
			if col.has_area() and Rect2(cx - w / 2.0, top, w, panel.size.y).intersects(col):
				cx = clampf(col.position.x - w / 2.0 if col.get_center().x > cx else col.end.x + w / 2.0, 8.0 + w / 2.0, room.size.x - 8.0 - w / 2.0)
				# shortcut: só o Menu desce para debaixo da vida; a volta (ao meio) só lá chegaria com mais de 520 px de altura
				if menu and plates()[0].intersects(Rect2(cx - w / 2.0, top, w, panel.size.y)):
					panel.offset_top = maxf(panel.offset_top, plates()[0].end.y)
			var dx: float = cx - panel.get_global_rect().get_center().x
			panel.offset_left += dx
			panel.offset_right += dx
	overlay.queue_redraw()
	vig.queue_redraw()
	front.queue_redraw()


## B2: monstros e saque (os pés, no ecrã) debaixo de cada botão do ecrã tátil (+8 px) e das esferas (+4 px, e 24 por baixo:
## o corpo fica por cima dos pés). Os nomes do saque só contam nos botões: ao lado da moldura apagavam meia esfera.
func _scan_covers() -> void:
	covered.clear()
	var ct := get_viewport().get_canvas_transform()
	var pts := []
	var names := []  # e o nome do saque, à largura do texto (um nome comprido ficava por baixo do botão)
	for e in map_foes():  # às escuras (#26) só os que estão à luz: um botão transparente dizia onde estava o monstro
		if not e.dying:
			pts.append(ct * e.global_position)
	for l in get_tree().get_nodes_in_group("loot"):
		pts.append(ct * l.global_position)
		if is_instance_valid(l.label) and l.label.visible:
			var lr: Rect2 = l.label.get_global_rect()
			var w: float = l.label.get_minimum_size().x
			names.append(ct * Rect2(lr.get_center().x - w / 2.0, lr.position.y, w, lr.size.y))
	if pts.is_empty():
		return
	var boxes := {}
	for i in 2:
		boxes[ORB_KEYS[i]] = Rect2(overlay.global_position + orb_rects[i].position, orb_rects[i].size).grow_individual(4.0, 4.0, 4.0, 24.0)
	if pad.visible:
		for b in pad.get_children():
			if b is Button and b.visible:
				boxes[b] = b.get_global_rect().grow(8.0)
	for k in boxes:
		if pts.any(func(q): return boxes[k].has_point(q)) or (not k in ORB_KEYS and names.any(func(r): return boxes[k].intersects(r))):
			covered[k] = true


## O botão redondo: interage com o que está perto; sem nada, esquiva para onde o joystick aponta.
func _interact_or_dodge() -> void:
	if hint_action != "":
		main.interact(main.player)
	else:
		main.player.dodge(main.player.touch_move)


func _input(event: InputEvent) -> void:
	var vs := root.get_viewport_rect().size
	if event is InputEventJoypadButton or (event is InputEventJoypadMotion and absf(event.axis_value) > 0.5):
		gamepad = true
		main.on_pad_input(event)
	elif event is InputEventScreenTouch and event.pressed:
		gamepad = false
		last_touch = event.index
		if info_btn != null and info_rect.has_point(event.position):
			info_idx = event.index  # o 1.º dedo carrega no botão (pelo rato emulado) antes de o toque chegar aqui
	# Intro: tocar (ou A) passa ao quadro seguinte; segurar o dedo 1 s, B ou Menu salta tudo. O toque conta ao
	# levantar o dedo (para se poder segurar). O rato só conta sem ecrã tátil, senão o toque (que também chega
	# como rato) passava dois quadros de uma vez.
	if intro_i >= 0 and not event.is_echo() and Engine.get_process_frames() > panel_frame \
			and (event is InputEventScreenTouch or (event is InputEventMouseButton and not DisplayServer.is_touchscreen_available())):
		get_viewport().set_input_as_handled()
		if event.is_pressed():
			intro_hold = 0.0
		elif intro_hold >= 0.0:
			intro_hold = -1.0
			_intro_next()
		return
	if intro_i >= 0 and event is InputEventJoypadButton and event.is_pressed() and Engine.get_process_frames() > panel_frame:
		get_viewport().set_input_as_handled()
		if event.button_index in [JOY_BUTTON_B, JOY_BUTTON_START]:
			_intro_end()
		else:
			_intro_next()
		return
	if event is InputEventScreenTouch:
		var joy_side: bool = event.position.x > vs.x * 0.55 if lefty else event.position.x < vs.x * 0.45
		if event.pressed and joy_index == -1 and panel == null and joy_side and event.position.y > maxf(vs.y * 0.3, safe.position.y + top_rect.end.y):  # os botões do canto de cima não começam o joystick (no canhoto, é o lado dele)
			joy_index = event.index
			joy_used = true
			joy_origin = _joy_home() if main.settings.joy_fixed else event.position
			joy_pos = event.position
			main.player.touch_move = ((joy_pos - joy_origin) / (JOY_R * SCALES[ui_scale_i])).limit_length(1.0)
		elif not event.pressed and event.index == joy_index:
			joy_index = -1
			main.player.touch_move = Vector2.ZERO
		elif event.pressed:
			swipes[event.index] = [event.position, Time.get_ticks_msec()]
		elif swipes.has(event.index):
			var s: Array = swipes[event.index]
			swipes.erase(event.index)
			var v: Vector2 = event.position - s[0]
			if v.length() > 90.0 and Time.get_ticks_msec() - s[1] < 300 and panel == null:
				main.player.dodge(v)
	elif event is InputEventScreenDrag and event.index == joy_index:
		joy_pos = event.position
		var r: float = JOY_R * SCALES[ui_scale_i]
		main.player.touch_move = ((joy_pos - joy_origin) / r).limit_length(1.0)
	# O dedo que segura um botão saiu dele: não há cartão
	if event is InputEventScreenDrag and info_btn != null and event.index == info_idx and not info_rect.grow(12.0).has_point(event.position):
		info_btn = null


func _draw_overlay() -> void:
	var vs := overlay.size
	var font := ThemeDB.fallback_font
	var p = main.player
	# Jogador 1: retrato no anel + nome + vida + mana
	_portrait(p, Vector2(42, 44), 25.0)
	Gothic.draw(overlay, Vector2(82, 26), p.hero_name, 21, Color(0.9, 0.85, 0.7), 5)
	_life_bar(Rect2(82, 32, 220, 12), p)
	overlay.draw_rect(Rect2(82, 48, 180, 7), Color(0.02, 0.04, 0.08))
	overlay.draw_rect(Rect2(82, 48, 180 * p.mana / p.max_mana, 7), Color(0.2, 0.6, 0.85))
	_corruption_bar(Rect2(82, 57, 180, 3), p)
	# Moedas com os ícones da folha SC-ICO1
	var x := 16.0
	for k in ["bone", "ink", "ash"]:
		overlay.draw_texture_rect(ICONS[k], Rect2(x, 72, 26, 26), false)
		Gothic.draw(overlay, Vector2(x + 30, 93), str(main.currency[k]), 20, Color(0.95, 0.9, 0.75), 5)
		x += 74.0
	# Jogador 2 (co-op): retrato, vida e as 3 habilidades com recarga
	p2_rect = Rect2()
	var wifi_r := Rect2()
	var p2_hid: bool = info_on and Rect2(hold_card.position + front.global_position - overlay.global_position, hold_card.size).intersects(Rect2(330, 10, 212, 66))  # Lote 12 C (i): via-se através do cartão do toque longo
	if main.players.size() > 1 and p2_hid:
		p2_rect = Rect2(330, 10, 212, 66)
	elif main.players.size() > 1:
		p2_rect = Rect2(330, 10, 212, 66)
		var q = main.players[1]
		_portrait(q, Vector2(352, 40), 20.0)
		var label: String = tr(q.hero_name) + ("  — " + tr("sem ligação") if q.away else "  — " + tr("caído") if q.dead else "")
		Gothic.draw(overlay, Vector2(380, 26), label, 20, q.tint, 5)
		_life_bar(Rect2(380, 32, 160, 10), q)
		_corruption_bar(Rect2(380, 44, 160, 2), q)
		for i in 3:
			var id: String = q.order[i]
			var r := Rect2(380 + i * 30, 47, 26, 26)
			overlay.draw_texture_rect(ICONS[id], r, false)
			if q.cds[id] > 0.0:
				_pie(overlay, r.get_center(), 13.0, q.cds[id] / q.skills[id].cd)
		if main.pad_of[1] == -1:
			var hint := tr("carrega num botão do segundo comando")
			var hf := Gothic.small_font()
			var hs := Gothic.small_px(16)
			overlay.draw_string(hf, Vector2(474, 70), hint, HORIZONTAL_ALIGNMENT_LEFT, -1, hs, Color(1, 1, 1, 0.6))
			p2_rect = p2_rect.merge(Rect2(474, 56, hf.get_string_size(hint, HORIZONTAL_ALIGNMENT_LEFT, -1, hs).x, 18))
		elif q.trans_until > main.time:  # a Alma Transitória (#4) dele a seguir às habilidades, com o anel dos 60 s
			overlay.draw_texture_rect(ICONS.transitoria, Rect2(470, 47, 26, 26), false)
			overlay.draw_arc(Vector2(483, 60), 15.0, -PI / 2.0, -PI / 2.0 + TAU * (q.trans_until - main.time) / q.TRANS_T, 24, Color(0.4, 0.95, 0.9), 2.0)
		if Net.weak():  # #274: só quando a Wi-Fi atrapalha, uma linha vermelha por baixo do 2.º jogador, com o que a acendeu (com a rede parada a ida e volta não sobe; os perdidos sim)
			var wt := tr("Wi-Fi fraca: %d%% perdido") % roundi(Net.loss() * 100.0) if Net.loss() >= 0.05 and Net.rtt_ms() < 150 else tr("Wi-Fi fraca: %d ms") % Net.rtt_ms()
			var wf := Gothic.small_font()
			var ws := Gothic.small_px(17)
			overlay.draw_string_outline(wf, Vector2(380, 76 + ws), wt, HORIZONTAL_ALIGNMENT_LEFT, -1, ws, 4, Color.BLACK)
			overlay.draw_string(wf, Vector2(380, 76 + ws), wt, HORIZONTAL_ALIGNMENT_LEFT, -1, ws, Color(1.0, 0.35, 0.3))
			wifi_r = Rect2(380, 76, wf.get_string_size(wt, HORIZONTAL_ALIGNMENT_LEFT, -1, ws).x, ws * 1.3)
	elif gamepad:
		var p2_parts := ["Segundo comando: ", "@menu", " entra o segundo jogador"]
		if 330.0 + _prompts(null, Vector2.ZERO, p2_parts, 14) + 16.0 <= top_bar.position.x + TOP_BTN - _prompts(null, Vector2.ZERO, top_prompts(), 18):
			p2_rect = Rect2(330, 14, _prompts(overlay, Vector2(330, 30), p2_parts, 14), 22)
		else:  # a 130% chegava a "Árvore (N)  Arsenal  Menu", na mesma linha à direita: em duas linhas
			var p2_dy := Gothic.small_px(14) * 1.3
			p2_rect = Rect2(330, 14, maxf(_prompts(overlay, Vector2(330, 30), ["Segundo comando:"], 14), _prompts(overlay, Vector2(330, 30.0 + p2_dy), p2_parts.slice(1), 14)), 22.0 + p2_dy)
	p2_steady = p2_rect
	if wifi_r.has_area():
		p2_rect = p2_rect.merge(wifi_r)
	# Orbes de vida e alma dentro do suporte duplo da folha SC-UI1 (buracos medidos: centros a 27% e 73%, 54% de altura)
	var hw := 220.0  # B2: com 300 tapavam o chão a sul do herói (o saque e os monstros)
	var hh: float = hw * UI.holder.get_height() / UI.holder.get_width()
	var hr := Rect2(vs.x * 0.5 - hw / 2.0, vs.y - hh - 10.0, hw, hh)
	var rad := hw * 0.18
	_orb(hr.position + Vector2(hw * 0.269, hh * 0.54), rad, p.hp / p.max_hp, UI.red, orb_as[0])
	_orb(hr.position + Vector2(hw * 0.726, hh * 0.54), rad, p.mana / p.max_mana, UI.soul, orb_as[1])
	var ts: Vector2 = UI.holder.get_size()
	for i in 2:  # a moldura em duas metades, cada uma com a sua esfera
		overlay.draw_texture_rect_region(UI.holder, Rect2(hr.position.x + hw * 0.5 * i, hr.position.y, hw * 0.5, hh), Rect2(ts.x * 0.5 * i, 0.0, ts.x * 0.5, ts.y), Color(1, 1, 1, orb_as[i]))
	if gamepad:  # as poções de cada lado das esferas só com comando (LB vida, RB alma); no ecrã tátil estão nos botões delas
		_potion(Vector2(hr.position.x - 30, hr.get_center().y), "hp", p)
		_potion(Vector2(hr.end.x + 30, hr.get_center().y), "mp", p)
		orb_rect = hr.grow_individual(60.0, 0.0, 60.0, 0.0)
	else:
		orb_rect = hr.grow(10.0)
	orb_rects = [Rect2(orb_rect.position, Vector2(orb_rect.size.x * 0.5, orb_rect.size.y)), Rect2(orb_rect.get_center().x, orb_rect.position.y, orb_rect.size.x * 0.5, orb_rect.size.y)]
	# Experiência do grupo
	var xr := Rect2(vs.x * 0.5 - 160, vs.y - 8, 320, 5)
	overlay.draw_rect(xr, Color(0, 0, 0, 0.75))
	var xc := Color(1.0, 0.97, 0.8) if xp_hold > 0.0 and int(xp_hold * 14.0) % 2 == 0 else Color(0.95, 0.8, 0.4)
	overlay.draw_rect(Rect2(xr.position, Vector2(xr.size.x * clampf(xp_shown, 0.0, 1.0), xr.size.y)), xc)
	Gothic.draw(overlay, Vector2(xr.end.x + 8, vs.y - 2), tr("Nv %d") % main.level, 17,Color(0.95, 0.8, 0.4), 4)
	# Seta para o objetivo: o monumento no cemitério; na cripta, o Carcereiro e depois a saída
	var to: Vector2 = main.objective() - p.position
	arrow_at = Vector2.INF
	if to.length() > (120.0 if main.zone == "sep" else 450.0) and not arrow_hidden():  # lá em baixo a abertura fica muitas vezes a menos de 450 px, e a seta sumia precisamente aí
		var c := overlay.get_viewport_rect().size / 2.0 - overlay.global_position + to.normalized() * 200.0
		var d := to.normalized()
		var bars_box := Rect2(bars_rect.position + front.global_position - overlay.global_position, bars_rect.size).grow(18.0)
		if bars_rect.has_area() and bars_box.has_point(c):  # Lote 7 C (f): nem por cima das barras dos chefes e dos nomes deles: por baixo
			c.y = bars_box.end.y
		if hint_y > 0.0:  # por baixo da faixa da linha do que dá para fazer (no fundo dela, com o objetivo para cima, ficava entre as palavras)
			var hs: float = Gothic.small_px(20)
			var plate := Rect2(front.global_position - overlay.global_position + Vector2(front.size.x * 0.5 - hint_w * 0.5 - 10.0, hint_y - hs), Vector2(hint_w + 20.0, hs * 1.4)).grow(18.0)
			if plate.has_point(c):
				c.y = plate.end.y
		overlay.draw_colored_polygon(PackedVector2Array([c + d * 16.0, c + d.orthogonal() * 9.0, c - d.orthogonal() * 9.0]), Color(0.9, 0.2, 0.25, 0.8) if main.cortejo.active else Color(0.4, 1.0, 0.65, 0.7))
		arrow_at = c + overlay.global_position
	minimap_rect = Rect2()
	if minimap_on():
		_minimap(vs)
	# O aviso do cimo ao meio (top_line); com o 2.º jogador ou o aviso do 2.º comando no caminho, passa para a direita deles
	var line := top_line()
	top_line_rect = Rect2()
	if not line.is_empty():
		var small: bool = line.size() > 2  # Lote 12: as linhas da Wi-Fi, compridas (o IP), no texto pequeno
		var lw: float = Gothic.small_font().get_string_size(line[0], HORIZONTAL_ALIGNMENT_LEFT, -1, Gothic.small_px(22)).x if small else Gothic.width(line[0], 26)
		var cx: float = vs.x * 0.5
		if p2_rect.has_area():
			cx = maxf(cx, p2_rect.end.x + 16.0 + lw / 2.0)
		var ly := 40.0
		if small and p2_rect.has_area() and cx + lw / 2.0 > top_rect.position.x - 8.0:  # sem lugar à direita do 2.º jogador (a sala aberta com comando, a 130%): por baixo dele
			cx = maxf(vs.x * 0.5, p2_rect.position.x + lw / 2.0)
			ly = p2_rect.end.y + 30.0
		top_line_rect = Rect2(cx - lw / 2.0, ly - 26.0, lw, 36.0)
		if small:
			Gothic.draw_small_centered(overlay, cx, ly, line[0], 22, line[1], 5)
		else:
			Gothic.draw_centered(overlay, cx, 40.0, line[0], 26, line[1], 5)
		if main.event.get("id") == "banquete":  # a barra do Banquete (#47), por baixo
			var br := Rect2(cx - 100.0, 50.0, 200.0, 8.0)
			overlay.draw_rect(br, Color(0, 0, 0, 0.75))
			overlay.draw_rect(Rect2(br.position, Vector2(br.size.x * main.event.bar, br.size.y)), Color(0.9, 0.3, 0.3))
	if main.tide_on():  # Lago das Lamentações (#30): 3 faixas azuis translúcidas atravessam o ecrã no sentido da maré
		var k: float = main.time - main.tide_next
		var d: Vector2 = main.tide_dir
		var span := vs.length()
		for i in 3:
			var c: Vector2 = vs / 2.0 + d * (fmod(k / main.TIDE_T + i / 3.0, 1.0) - 0.5) * span
			var o: Vector2 = d.orthogonal() * span
			overlay.draw_colored_polygon(PackedVector2Array([c - o - d * 40.0, c + o - d * 40.0, c + o + d * 40.0, c - o + d * 40.0]), Color(0.35, 0.6, 1.0, 0.16))
	# Afixos do Cortejo (S8): as lascas da Chuva de Dentes (#192) a cair pelo ecrã
	if main.cortejo.active and "dentes" in main.cortejo.affixes:
		for i in 30:
			var fx: float = fmod(i * 431.7, vs.x)
			var fy: float = fmod(main.time * (480.0 + 40.0 * (i % 4)) + i * 157.0, vs.y + 60.0) - 30.0
			overlay.draw_line(Vector2(fx, fy), Vector2(fx - 5.0, fy - 18.0), Color(0.92, 0.88, 0.78, 0.65), 2.0)
	# Chefes fora do ecrã: seta vermelha a pulsar na borda (dourada nos elites, #277; roxa no Ceifador, #216)
	var a := 0.65 + 0.3 * sin(Time.get_ticks_msec() * 0.008)
	for m in boss_marks():
		var tip: Vector2 = m[0]
		var d: Vector2 = m[1]
		var tri := PackedVector2Array([tip, tip - d * 26.0 + d.orthogonal() * 14.0, tip - d * 26.0 - d.orthogonal() * 14.0, tip])
		overlay.draw_colored_polygon(tri, Color(m[2], a))
		overlay.draw_polyline(tri, Color(0, 0, 0, a), 2.0)


## O aviso do cimo ao meio, um de cada vez: o ar e a maré de almas das salas da cripta (S6, #38, #30), a maré do Cortejo
## (#212), o Banquete dos Espectros (#47, até o titã se erguer) e, na Wi-Fi, a espera pelo convidado que perdeu a ligação
## (#91) e a sala aberta com o IP (UX 27). [texto, cor], ou [] sem nenhum; um 3.º valor: no texto pequeno.
func top_line() -> Array:
	if main.crypt_rule == "miasma" and main.breath_end < INF:
		var air: float = maxf(0.0, main.breath_end - main.time)
		return [tr("Ar: %d s") % ceili(air), Color(1.0, 0.3, 0.25) if air < 15.0 else Color(0.5, 1.0, 0.55)]
	if main.crypt_rule == "submersa" and main.time >= main.tide_next - 1.0 and main.time < main.tide_next:
		return ["Maré de almas!", Color(0.5, 0.75, 1.0)]
	if main.cortejo.active and "mares" in main.cortejo.affixes and main.time >= main.tide_start - 3.0 and main.time < main.tide_start:
		return ["A maré sobe!", Color(1.0, 0.3, 0.25)]
	if main.event.get("id") == "banquete" and not main.event.has("titan"):
		return [tr("Banquete: %d%%") % roundi(main.event.bar * 100.0), Color(1.0, 0.45, 0.4)]
	if Net.away_end > 0 and main.players.size() > 1 and main.players[1].away:
		return [tr("À espera do %s: %d s") % [tr(main.players[1].hero_name), ceili(maxf(0.0, Net.away_end - Time.get_ticks_msec()) / 1000.0)], Color(1.0, 0.85, 0.4), true]
	if Net.role == "host" and not Net.guest_ready and main.players.size() < 2:  # com um 2.º jogador no telemóvel a sala já está cheia
		return [tr("À espera do segundo telemóvel · %s") % Net.my_ip(), Color(0.45, 1.0, 0.65), true]
	return []


## O minimapa à vista: ligado nas Configurações e sem o Visor da Agonia Perpétua (#252) no herói deste telemóvel (no co-op
## local, o do jogador 1).
func minimap_on() -> bool:
	return main.settings.minimap and main.player.stat("visor") <= 0.0


## O minimapa fica no canto de cima (a zona dá a forma, o lado maior é MINIMAP).
func _minimap_box(vs: Vector2) -> Rect2:
	var b: Rect2 = main.bounds
	var k: float = MINIMAP / maxf(b.size.x, b.size.y)
	return Rect2(vs.x - 12.0 - b.size.x * k, 12.0, b.size.x * k, b.size.y * k)


## Os botões ficam à esquerda do minimapa (ou no canto, sem minimapa). Todos os frames: a forma do minimapa muda com a zona.
func _layout_top() -> void:
	var vs := overlay.size
	var left := vs.x - 12.0  # onde acaba a coluna de botões
	var mm := Rect2()
	if minimap_on():
		mm = _minimap_box(vs)
		left = mm.position.x - 10.0
	top_bar.position = Vector2(left - TOP_BTN, 12.0)
	top_rect = Rect2(top_bar.position, Vector2(TOP_BTN, 3.0 * TOP_BTN + 2.0 * TOP_GAP))
	if mm.size != Vector2.ZERO:
		top_rect = top_rect.merge(mm)
	map_btn.visible = mm.size != Vector2.ZERO and not gamepad  # B6: por cima do minimapa e das moedas (sem toque com comando)
	map_btn.position = mm.position
	map_btn.size = mm.size
	coin_btn.visible = not gamepad


## Minimapa no canto de cima, à direita dos botões: a zona inteira, o que a câmara vê, o grupo, os monstros
## (os chefes maiores e a pulsar) e o que importa: monumento, escadas da cripta, túmulo, relicário, saída.
func _minimap(vs: Vector2) -> void:
	var b: Rect2 = main.bounds
	var k: float = MINIMAP / maxf(b.size.x, b.size.y)
	var box := _minimap_box(vs)
	minimap_rect = box
	var at := func(w: Vector2) -> Vector2: return box.position + ((w - b.position) * k).clamp(Vector2.ZERO, box.size)
	overlay.draw_rect(box, Color(0.02, 0.03, 0.03, 0.75))
	mm_rooms = 0
	if main.zone == "crypt":
		overlay.draw_colored_polygon(PackedVector2Array(Array(main.crypt_floor).map(at)), Color(0.45, 0.5, 0.43, 0.75))
		overlay.draw_rect(Rect2(at.call(main.CRYPT_ORIGIN + main.CRYPT_OUT) - Vector2(4, 4), Vector2(8, 8)), Color(0.75, 0.6, 1.0))
	elif main.zone == "sep" and (main.crypt_rule != "esquecidos" or main.eye_on()):  # só o que já se pisou: é assim que se descobre o mapa. No Abismo dos Esquecidos (#211), nada: só os heróis e o relicário (com o Olho do Primeiro Rei, #258, tudo)
		var rooms: Array = main.sep.get("rooms", [])
		var shown: Array = map_rooms()
		var eye: bool = main.eye_on()
		var blink: bool = eye and int(Time.get_ticks_msec() / 400) % 2 == 0
		for i in shown:
			var r: Dictionary = rooms[i]
			overlay.draw_rect(Rect2(at.call(r.world.position), r.world.size * k), Color(0.35, 0.62, 1.0, 0.85) if blink and r.type in ["capela", "cofre"] else Color(0.45, 0.5, 0.43, 0.75))  # #258: as salas de desvio piscam a azul
			mm_rooms += 1
		var links: Array = main.sep.get("links", [])
		for li in links.size():
			var l: Dictionary = links[li]
			if (l.a in shown or l.b in shown) and (eye or not main.link_hidden(li)):  # o Cofre (#32) fica escondido até a porta de sangue abrir (com o Olho, não)
				overlay.draw_rect(Rect2(at.call(l.world.position), l.world.size * k), Color(0.35, 0.4, 0.35, 0.75))
		if not rooms.is_empty():
			overlay.draw_rect(Rect2(at.call(main.sep.exit) - Vector2(4, 4), Vector2(8, 8)), Color(0.75, 0.6, 1.0))
			if main.sep_done == 1:
				overlay.draw_rect(Rect2(at.call(main.sep.down) - Vector2(4, 4), Vector2(8, 8)), Color(1.0, 0.85, 0.4))
	elif main.zone != "sep":
		overlay.draw_texture_rect(main.map_tex, box, false, Color(1, 1, 1, 0.45))  # as zonas e, a dourado, os acampamentos por limpar
		for i in main.camps.size():
			overlay.draw_rect(Rect2(at.call(main.camps[i].pos) - Vector2(2.5, 2.5), Vector2(5, 5)), Color(0.45, 0.42, 0.35) if i in main.camps_done else Color(1.0, 0.8, 0.3))
		overlay.draw_rect(Rect2(at.call(main.GATE) - Vector2(3, 3), Vector2(6, 6)), Color(1.0, 0.85, 0.4) if main.wins >= 1 else Color(0.75, 0.7, 0.55), false, 1.0)
		overlay.draw_circle(at.call(main.monument_pos), 4.0, Color(0.4, 1.0, 0.65))
		overlay.draw_rect(Rect2(at.call(main.CRYPT_DOOR) - Vector2(4, 4), Vector2(8, 8)), Color(0.75, 0.6, 1.0))
		if not main.tomb.is_empty():
			overlay.draw_dashed_line(at.call(main.player.position), at.call(main.tomb.pos), Color(0.6, 1.0, 0.8, 0.7), 1.5, 4.0)
			overlay.draw_circle(at.call(main.tomb.pos), 3.5, Color(0.6, 1.0, 0.8))
		if not main.event.is_empty():  # S9: o evento, um anel cor de laranja a pulsar
			overlay.draw_arc(at.call(main.event.pos), 5.0 + 2.0 * sin(Time.get_ticks_msec() * 0.01), 0, TAU, 16, Color(1.0, 0.55, 0.2), 2.0)
			overlay.draw_circle(at.call(main.event.pos), 2.5, Color(1.0, 0.55, 0.2))
	if is_instance_valid(main.chest) and not main.chest.opened:
		overlay.draw_circle(at.call(main.chest.position), 3.5, Color(1.0, 0.82, 0.3))
	var half: Vector2 = overlay.get_viewport_rect().size / 2.0 / main.cam.zoom
	var view := Rect2(main.cam.get_screen_center_position() - half, half * 2.0).intersection(b)
	overlay.draw_rect(Rect2(at.call(view.position), view.size * k), Color(1, 1, 1, 0.3), false, 1.0)
	for a in get_tree().get_nodes_in_group("allies"):
		overlay.draw_circle(at.call(a.position), 1.8, Color(0.6, 1.0, 0.7))
	var pulse := 4.0 + sin(Time.get_ticks_msec() * 0.01) * 1.2
	for e in map_foes():
		overlay.draw_circle(at.call(e.position), pulse if e.is_boss else 1.8, Color(1.0, 0.25, 0.25))
	if is_instance_valid(main.reaper):  # O Ceifador Ambulante (#216), a roxo
		overlay.draw_circle(at.call(main.reaper.position), pulse, Color(0.7, 0.35, 1.0))
	for p in main.players:
		if p.away:  # #91: o herói à espera da ligação está escondido, colado ao anfitrião: o ponto dele tapava o do anfitrião
			continue
		var q: Vector2 = at.call(p.position)
		overlay.draw_circle(q, 4.5, Color.BLACK)
		overlay.draw_circle(q, 3.5, p.tint.darkened(0.5) if p.dead else p.tint)
	overlay.draw_rect(box, Color(0.55, 0.5, 0.38, 0.85), false, 2.0)


## As salas do Sepulcro que o minimapa mostra (índices em sep.rooms): as que já se pisaram; com o Olho Mumificado do Primeiro
## Rei (#258) num herói, todas desde o início, também no Abismo dos Esquecidos e o Cofre escondido (#32). No Abismo, sem ele, nenhuma.
func map_rooms() -> Array:
	var rooms: Array = main.sep.get("rooms", [])
	var eye: bool = main.eye_on()
	if main.crypt_rule == "esquecidos" and not eye:
		return []
	return range(rooms.size()).filter(func(i): return eye or rooms[i].seen)


## Abismo dos Esquecidos (#211): sem seta, a não ser 3 s depois de 45 s sem entrar numa sala nova (para ninguém ficar perdido).
func arrow_hidden() -> bool:
	return main.zone == "sep" and main.crypt_rule == "esquecidos" and lost_show <= 0.0


## Os monstros no minimapa e nas setas: nas Catacumbas Cegas (#26) só os que estão à luz, e o Carcereiro sempre (o único
## chefe da cripta; no convidado main.guardian costuma faltar). No Abismo dos Esquecidos (#211) o chefe também só à luz: a seta dele era o caminho.
func map_foes() -> Array:
	if not main.dark_on():
		return main.enemies()
	var ls: Array = main.lights()  # uma vez, não uma por monstro
	var lost: bool = main.crypt_rule == "esquecidos"
	return main.enemies().filter(func(e): return (e.is_boss and not lost) or main.lit(e.position, ls))


## Os chefes com barra no cimo do ecrã: o Carcereiro só depois de acordar; os Gigantes Errantes (#39) e as Estátuas
## Funerárias (#204) nunca (a vida deles vai por cima, enemy.life_bar). No máximo 3 (os Reforços dos Sineiros, os Coveiros
## e os colossos do Mausoléu juntavam 7 ou mais e tapavam os heróis): os chefes com nome primeiro, os colossos sem nome depois.
func boss_bars() -> Array:
	var bs: Array = main.enemies().filter(func(e): return e.is_boss and e.rise_t <= 0.0 and (e.awake or e.aggro == INF) and e.title != "Gigante Errante" and not e.anchor)
	var heads := {}  # Lote 9: um grupo (as Donzelas, os Reis) leva uma barra só, a da que está na vez (_boss_bar soma-lhes a vida): três tapavam os heróis
	for e in bs:
		if e.trio != "" and (not heads.has(e.trio) or e.turn_at > heads[e.trio].turn_at):
			heads[e.trio] = e
	bs = bs.filter(func(e): return e.trio == "" or heads[e.trio] == e)
	return (bs.filter(func(e): return e.kind != "colossus" or e.boss != "") + bs.filter(func(e): return e.kind == "colossus" and e.boss == "")).slice(0, 3)


## O nome por cima de um monstro (r, no ecrã) cai debaixo das barras dos chefes (a placa de 460 px ao meio, do cimo do
## ecrã até ao fundo delas) ou do painel do objetivo: enemy._bar põe-no então por baixo dele.
func name_blocked(r: Rect2) -> bool:
	return (stack_y > 0.0 and r.intersects(Rect2(front.global_position + Vector2(front.size.x * 0.5 - 230.0, 0.0), Vector2(460.0, stack_y)))) or (status.visible and r.intersects(status.get_global_rect()))


## A vida, a alma e as moedas do 1.º jogador e o 2.º jogador (ou o aviso do 2.º comando), no canto de cima, no ecrã.
func plates() -> Array:
	var o := overlay.global_position
	return [Rect2(o, Vector2(330, 100))] + ([Rect2(p2_rect.position + o, p2_rect.size)] if p2_rect.has_area() else [])


## Lote 9 C (f): a coluna de botões de cima (Árvore, Arsenal, Menu) e o minimapa, no ecrã.
func top_box() -> Rect2:
	return Rect2(top_rect.position + overlay.global_position, top_rect.size) if top_rect.has_area() else Rect2()


## Lote 9 C (f): r (no ecrã) toca no que o HUD tem em cima: as placas dos heróis, a coluna de botões, o minimapa e a faixa
## da linha do que dá para fazer. Os nomes do saque, dos monstros e dos lugares não se desenham por cima deles.
func over_hud(r: Rect2) -> bool:
	return plates().any(func(q): return q.intersects(r)) or top_box().intersects(r) or (hint_y > 0.0 and hint_box().intersects(r))


## A faixa da linha do que dá para fazer, no ecrã, como ficou desenhada no último frame (hint_y 0: não há).
func hint_box() -> Rect2:
	var hs: float = Gothic.small_px(20)
	return Rect2(front.global_position + Vector2(front.size.x * 0.5 - hint_w * 0.5 - 10.0, hint_y - hs), Vector2(hint_w + 20.0, hs * 1.4))


## Chefes e elites (#277) fora do ecrã: [ponta da seta na borda, direção, cor] para cada um. Vermelha nos chefes e no
## elite com a Marca da Cova a encher; dourada nos outros elites.
func boss_marks() -> Array:
	var vs := overlay.size
	var ct := overlay.get_viewport().get_canvas_transform()
	var half := vs / 2.0 - Vector2(30, 60)
	var marks := []
	var hud_left := Rect2(0, 0, 330, 100).merge(p2_rect)  # a vida, a alma e as moedas do 1.º jogador e o 2.º jogador
	for e in map_foes() + ([main.reaper] if is_instance_valid(main.reaper) else []):  # às escuras, nada de setas para quem não está à luz; o Ceifador (#216) sempre
		var s: Vector2 = ct * e.global_position - overlay.global_position
		if (e.is_boss or e.elite) and not Rect2(Vector2.ZERO, vs).has_point(s):
			var d := (s - vs / 2.0).normalized()
			var tip := vs / 2.0 + d * minf(half.x / maxf(absf(d.x), 0.01), half.y / maxf(absf(d.y), 0.01))
			if top_rect.grow(28.0).has_point(tip):
				tip.y = top_rect.end.y + 34.0  # por baixo dos botões e do minimapa
			elif hud_left.grow(28.0).has_point(tip):
				tip.y = hud_left.end.y + 34.0
			elif orb_rect.grow(28.0).has_point(tip):
				tip.y = orb_rect.position.y - 34.0
			var bars_box := Rect2(bars_rect.position + front.global_position - overlay.global_position, bars_rect.size)
			if bars_rect.has_area() and bars_box.grow(28.0).has_point(tip):  # nem por cima das barras dos chefes e dos nomes deles (a seta tem 26 px de corpo)
				tip.y = bars_box.end.y + 34.0
			marks.append([tip, d, Color(0.7, 0.35, 1.0) if e.reaper else Color(1.0, 0.12, 0.18) if e.is_boss or e.mark_end > main.time else Color(1.0, 0.8, 0.3)])
	return marks


func _draw_front() -> void:
	potion_ring = false
	move_hint = Rect2()
	if title_open:  # A3: no título nada do jogo gravado (a legenda do comando dos painéis está no fundo deles, o shade)
		toast_floor = 172.0
		return
	var vs := front.size
	var sr := safe.get_global_rect()
	var p = main.player
	if main.settings.show_fps:
		var fps_txt := "%d FPS  %.0f ms  %d  %d" % [Engine.get_frames_per_second(), Performance.get_monitor(Performance.TIME_PROCESS) * 1000.0, Performance.get_monitor(Performance.RENDER_TOTAL_DRAW_CALLS_IN_FRAME), main.enemies().size()]
		if Net.linked():
			fps_txt += "  Wi-Fi %d ms" % Net.rtt_ms()  # #274
		front.draw_string_outline(ThemeDB.fallback_font, Vector2(sr.position.x, sr.end.y - 4), fps_txt, HORIZONTAL_ALIGNMENT_LEFT, -1, 16, 4, Color.BLACK)
		front.draw_string(ThemeDB.fallback_font, Vector2(sr.position.x, sr.end.y - 4), fps_txt, HORIZONTAL_ALIGNMENT_LEFT, -1, 16, Color(0.6, 1.0, 0.7))
	if Net.is_guest() and Net.host_paused:
		Gothic.draw_centered(front, vs.x / 2.0, vs.y * 0.3, "O anfitrião está num menu…", 32, Color(0.93, 0.89, 0.77), 8)
	# Joystick flutuante (na frente: não se esbate com o HUD), com a opacidade dos controlos (#271)
	var op: float = main.OPACITY[main.settings.opacity]
	if joy_index != -1:
		var r: float = JOY_R * SCALES[ui_scale_i]
		front.draw_texture_rect(UI.joy, Rect2(joy_origin - Vector2(r, r), Vector2(2 * r, 2 * r)), false, Color(1, 1, 1, 0.8 * op))
		var k := joy_origin + (joy_pos - joy_origin).limit_length(r)
		front.draw_texture_rect(UI.knob, Rect2(k - Vector2(r, r) * 0.45, Vector2(r, r) * 0.9), false, Color(1, 1, 1, op))
	elif not gamepad and main.settings.joy_fixed and panel == null:
		_joy_draw(front, _joy_home(), op)
	elif not gamepad and DisplayServer.is_touchscreen_available() and not joy_used and panel == null and not info_on:  # B1: só até se usar o joystick a 1.ª vez; C (d): nunca por cima de um painel
		# C (c): numa faixa escura, com contorno, como a linha do que dá para fazer (cinzento solto, os adereços cortavam-no)
		move_hint = Rect2()
		var mx: float = sr.end.x - 24.0 if lefty else sr.position.x + 24.0
		var mw := _prompts(front, Vector2(mx, sr.end.y - 24.0), ["toca e arrasta para mover"], 16, 1.0 if lefty else 0.0, true)
		var ms := Gothic.small_px(16)
		move_hint = Rect2(mx - (mw if lefty else 0.0) - 10.0, sr.end.y - 24.0 - ms, mw + 20.0, ms * 1.4)
	if gamepad:
		_pad_diamond(sr.end, p)
		if panel == null:  # onde estariam os botões
			_prompts(front, Vector2(sr.position.x + top_bar.position.x + TOP_BTN, sr.position.y + 22.0), top_prompts(), 18, 1.0)
	else:
		# Recargas por cima dos botões de toque, e o frasco de suporte no canto
		for id in skill_btns:
			var r: Rect2 = skill_btns[id].get_global_rect()
			if p.cds[id] > 0.0:
				_pie(front, r.get_center(), r.size.x * 0.43, p.cds[id] / p.skills[id].cd)
			var sup: String = p.skills[id].support
			if sup != "":
				front.draw_texture_rect(ICONS[sup], Rect2(r.end - Vector2(30, 34), Vector2(28, 28)), false)
		if trans_btn.visible:  # o anel da Alma Transitória (#4) esvazia-se nos 60 s
			var tc: Vector2 = trans_btn.get_global_rect().get_center()
			front.draw_arc(tc, trans_btn.get_global_rect().size.x * 0.5 + 5.0, -PI / 2.0, -PI / 2.0 + TAU * (p.trans_until - main.time) / p.TRANS_T, 40, Color(0.4, 0.95, 0.9), 4.0)
		if hint_action == "" and p.dash_cd > 0.0:
			var ir: Rect2 = interact_btn.get_global_rect()
			_pie(front, ir.get_center(), ir.size.x * 0.43, p.dash_cd / p.DASH_CD)
		for i in potion_btns.size():  # B2: as cargas e a barra da próxima no próprio botão (os frascos ao lado das esferas saíram)
			var pb: Button = potion_btns[i]
			var n: float = p.potions["hp" if i == 0 else "mp"]
			var r: Rect2 = pb.get_global_rect()
			var a: float = pb.modulate.a * pad.modulate.a
			var nb := charge_box(i)  # numa caixa escura ao lado do botão: no aro, a 16 px, não se lia
			front.draw_rect(nb, Color(0.03, 0.03, 0.03, 0.8 * a))
			front.draw_rect(nb, Color(0.85, 0.75, 0.5, 0.7 * a), false, 2.0)
			Gothic.draw_centered(front, nb.get_center().x, nb.end.y - 9.0, str(int(n)), 32, Color(1.0, 0.95, 0.8, a), 5)
			if n < p.POTION_MAX:
				var bar := Rect2(r.position.x + 8.0, r.end.y + 3.0, r.size.x - 16.0, 4.0)
				front.draw_rect(bar, Color(0, 0, 0, 0.7 * a))
				front.draw_rect(Rect2(bar.position, Vector2(bar.size.x * (n - floorf(n)), bar.size.y)), Color(1.0, 0.85, 0.4, a))
		potion_ring = not p.dead and p.hp < p.max_hp * 0.3 and p.potions.hp >= 1.0 and p.stat("sangue") <= 0.0
		if potion_ring:  # B3: um anel de quadrados chama a poção de vida (de 4 px e a apagar-se até 0,1 não se via)
			var hr: Rect2 = potion_btns[0].get_global_rect()
			var pa := 0.75 + 0.25 * sin(Time.get_ticks_msec() * 0.012)
			for i in 12:
				var q: Vector2 = (hr.get_center() + Vector2.from_angle(TAU * i / 12.0) * (hr.size.x * 0.5 + 11.0)).snapped(Vector2(2, 2))
				front.draw_rect(Rect2(q - Vector2(5, 5), Vector2(10, 10)), Color(0.1, 0.0, 0.0, pa))
				front.draw_rect(Rect2(q - Vector2(3, 3), Vector2(6, 6)), Color(1.0, 0.42, 0.3, pa))
		if panel == null:
			_badges()
	# B4: em cima ao meio, de cima para baixo: a frase do cartão, as barras dos chefes (por baixo do 2.º herói, que ficava tapado
	# pela ponta da barra), a linha do que dá para fazer e os avisos (_place_toast)
	var bars: Array = boss_bars()
	var tip: bool = boss_tip != "" and card_t <= 0.0 and bars.any(func(e): return (main.Bosses.BOOK[e.trio][0] if e.trio != "" else e.who()) == boss_tip_of)  # um grupo: a barra dele, seja qual for a da vez
	var ts: float = Gothic.small_px(20)
	var name_up: float = maxf(0.0, bars_top - boss_name_top(bars_top))  # C (f): o nome do chefe passa acima da barra; a frase fica 6 px acima dele
	var tip_h: float = ts * 1.4 + 6.0 + name_up if tip else 0.0  # a faixa (_prompts) e a folga até ao nome do chefe
	bars_top = maxf(62.0, (sr.position.y + p2_rect.end.y + 8.0 if p2_rect.has_area() else 0.0) + tip_h)
	var bars_end: float = bars_top + 92.0 * bars.size()
	stack_y = 0.0 if bars.is_empty() else bars_end
	var bars_y: float = minf(bars_top - tip_h, boss_name_top(bars_top))
	bars_rect = Rect2() if bars.is_empty() else Rect2(vs.x * 0.5 - 230.0, bars_y, 460.0, bars_end - bars_y)  # Lote 7 C (f): as barras, os nomes e a frase por cima
	tip_rect = Rect2()
	hint_y = maxf(150.0, stack_y + 16.0)
	if hint_title != "" and status.visible:  # C (k): a faixa da linha comprida (o Recipiente a 130%) não toca na caixa do estado, à esquerda: passa para baixo dela
		var plate := Rect2(vs.x * 0.5 - hint_w * 0.5 - 10.0, hint_y - ts, hint_w + 20.0, ts * 1.4)  # o hint_w do último frame
		var sb: Rect2 = status.get_global_rect()
		if plate.intersects(sb.grow(6.0)):
			hint_y = sb.end.y + 6.0 + ts
	toast_floor = maxf(172.0, stack_y + 40.0)  # com o cartão de um nome à vista os avisos esperam (_process): por baixo dele tapavam o herói
	if hint_title != "" and panel == null and not info_on and (card_t <= 0.0 or hint_y + Gothic.small_px(20) * 0.4 <= _card_band(vs).position.y):  # e a linha só por cima dele; C (d): nunca por cima de um painel
		var parts := [tr(hint_title) + "  —  "] + (["@b", " " + hint_action] if gamepad else [tr("toca em %s") % tr(hint_action)])
		hint_w = _prompts(front, Vector2(vs.x * 0.5, hint_y), parts, 20, 0.5, true)  # B5: numa faixa escura
		toast_floor = maxf(toast_floor, hint_y + 22.0)
	else:
		hint_y = 0.0
	if dark > 0.01:  # o mundo escurece enquanto o sino dobra
		front.draw_rect(Rect2(Vector2.ZERO, vs), Color(0.0, 0.02, 0.01, dark))
	var y := bars_top
	for e in bars:
		_boss_bar(e, vs, y)
		y += 92.0
	if tip:  # numa faixa escura, como a linha do que dá para fazer: solta, perdia-se no chefe e nas marcas dos membros
		var tip_end: float = bars_top - name_up - 6.0
		var tw := _prompts(front, Vector2(vs.x * 0.5, tip_end - ts * 0.4), [boss_tip], 20, 0.5, true)
		tip_rect = Rect2(vs.x * 0.5 - tw * 0.5 - 10.0, tip_end - ts * 1.4, tw + 20.0, ts * 1.4)
	card_rect = Rect2()
	if card_t > 0.0:
		_name_card(vs)
	if lvl_t > 0.0:
		_level_card(vs)
	if info_on:
		_info_card(info_btn, _info_text(info_key))
	if flash_a > 0.0:
		front.draw_rect(Rect2(Vector2.ZERO, vs), Color(1, 1, 1, flash_a))
	if fade_a > 0.0:
		front.draw_rect(Rect2(Vector2.ZERO, vs), Color(0, 0, 0, fade_a))


## Lote 7 C (g): os botões do ecrã tátil, no ecrã (o ataque, as habilidades, a Esquiva, a postura e as poções com a caixa das
## cargas), com 4 px de folga: o Loot.rank não deixa um nome de saque por cima deles. Com comando, nenhum.
func pad_rects() -> Array:
	if gamepad or not pad.visible:
		return []
	var out := []
	for b in skill_btns.values() + [interact_btn, stance_btn, trans_btn] + potion_btns:
		if is_instance_valid(b) and b.is_visible_in_tree():
			out.append(b.get_global_rect().grow(4.0))
	for i in potion_btns.size():
		out.append(charge_box(i).grow(4.0))
	return out


## A coluna das poções e das cargas no ecrã, com 4 px de folga (vazia sem os botões de toque): o Atlas e o Menu tapam-na toda ou nada.
func potion_col() -> Rect2:
	var col := Rect2()
	for i in potion_btns.size():
		if potion_btns[i].is_visible_in_tree():
			var q: Rect2 = potion_btns[i].get_global_rect().merge(charge_box(i)).grow(4.0)
			col = col.merge(q) if col.has_area() else q
	return col


## A caixa do número das cargas da poção i, encostada ao botão do lado de fora do grupo (à esquerda; no canhoto, à direita).
func charge_box(i: int) -> Rect2:
	var r: Rect2 = potion_btns[i].get_global_rect()
	return Rect2(r.end.x + 4.0 if lefty else r.position.x - 38.0, r.get_center().y - 19.0, 34.0, 38.0)


## B3: vida baixa (menos de 30%): as bordas do ecrã aos degraus, a pulsar, mais fortes quanto menos vida (nunca abaixo de 0,4).
func _draw_vignette() -> void:
	var p = main.player
	var low: float = 1.0 - p.hp / (p.max_hp * 0.3)
	vig_a = clampf(low * 1.6, 0.4, 1.0) if low > 0.0 and not p.dead and not title_open else 0.0
	if vig_a > 0.0:
		vig.draw_texture_rect(VIGNETTE, Rect2(Vector2.ZERO, vig.size), false, Color(1, 1, 1, vig_a * (0.7 + 0.3 * sin(Time.get_ticks_msec() * 0.008))))


## B5: o que espera por ti nos heróis deste telemóvel: os pontos por gastar (tree) e se o Arsenal tem novidade (arsenal):
## uma peça melhor do que a posta, a mochila cheia (full) ou um frasco que ainda não viste no Arsenal (new). As peças
## contam-se de 0,5 em 0,5 s e só quando a mochila ou o posto mudam (o _gear_verdict faz contas).
func badges() -> Dictionary:
	var heroes: Array = main.players if Net.role == "" else [main.player]
	var pts := 0
	for q in heroes:
		pts += q.points
	var now := Time.get_ticks_msec()
	if now >= badge_at:
		badge_at = now + 500
		var key := str(main.bags)  # uma Bolsa nova (#72) muda o "cheia" sem mexer na mochila
		for q in heroes:
			key += str(q.bag) + str(q.gear)
		if key != badge_key:
			badge_key = key
			badge_gear = heroes.any(func(q): return q.bag.any(func(it): return _gear_verdict(q, it) == Color(0.45, 1.0, 0.5)))
			badge_full = heroes.any(func(q): return q.bag.size() >= q.bag_cap())
	if flasks_seen < 0 and not (Net.is_guest() and Net.nodes.is_empty()):  # o convidado conta os do anfitrião, quando chegarem (antes tinha os de um jogo novo)
		flasks_seen = main.flasks.size()
	var fresh: bool = flasks_seen >= 0 and main.flasks.size() > flasks_seen
	return {"tree": pts, "arsenal": badge_gear or badge_full or fresh, "full": badge_full, "new": fresh}


func _badges() -> void:
	var bd := badges()
	if bd.tree > 0:
		_badge(top_bar.get_child(0).get_global_rect(), str(bd.tree), Color(0.55, 0.08, 0.1))
	if bd.arsenal:
		_badge(top_bar.get_child(1).get_global_rect(), "!" if bd.full or bd.new else "", Color(0.12, 0.45, 0.2))


## Um quadrado de 24 px no canto de cima do ícone, com aro dourado: um número, "!" ou (vazio) uma seta para cima.
func _badge(r: Rect2, text: String, col: Color) -> void:
	var b := Rect2(r.position + Vector2(r.size.x - 18.0, -6.0), Vector2(24, 24))
	front.draw_rect(b, col)
	front.draw_rect(b, Color(1.0, 0.85, 0.4), false, 2.0)
	if text != "":
		Gothic.draw_centered(front, b.get_center().x, b.end.y - 5.0, text, 16, Color(1.0, 0.95, 0.85), 3)
	else:
		var c := b.get_center()
		front.draw_colored_polygon(PackedVector2Array([c + Vector2(0, -7), c + Vector2(7, 5), c + Vector2(-7, 5)]), Color(0.75, 1.0, 0.75))


## Onde fica o joystick fixo: no canto de baixo do lado do polegar, dentro da margem segura, ou onde o jogador o pôs
## (#271: settings.joy_at, espelhado no canhoto), sempre na metade do polegar.
func _joy_home() -> Vector2:
	var r: float = JOY_R * SCALES[ui_scale_i]
	var sr := safe.get_global_rect()
	var at: Vector2 = main.settings.joy_at
	if at == Vector2.ZERO:
		return Vector2(sr.end.x - r - 40.0 if lefty else sr.position.x + r + 40.0, sr.end.y - r - 40.0)
	return _joy_clamp(sr.position + Vector2(1.0 - at.x if lefty else at.x, at.y) * sr.size)


## O joystick inteiro na metade do ecrã onde um toque o começa (_input) e dentro da margem segura.
func _joy_clamp(h: Vector2) -> Vector2:
	var r: float = JOY_R * SCALES[ui_scale_i]
	var sr := safe.get_global_rect()
	var vs := root.get_viewport_rect().size
	var lo := Vector2(vs.x * 0.55 if lefty else sr.position.x, maxf(vs.y * 0.3, sr.position.y + top_rect.end.y)) + Vector2(r, r)
	var hi := Vector2(sr.end.x if lefty else vs.x * 0.45, sr.end.y) - Vector2(r, r)
	return h.clamp(lo, hi)


## O joystick fixo parado em h (no jogo e no ecrã de o pôr no sítio), com a opacidade dos controlos.
func _joy_draw(ci: CanvasItem, h: Vector2, op: float) -> void:
	var r: float = JOY_R * SCALES[ui_scale_i]
	ci.draw_texture_rect(UI.joy, Rect2(h - Vector2(r, r), Vector2(2 * r, 2 * r)), false, Color(1, 1, 1, 0.45 * op))
	ci.draw_texture_rect(UI.knob, Rect2(h - Vector2(r, r) * 0.45, Vector2(r, r) * 0.9), false, Color(1, 1, 1, 0.6 * op))


func _pie(ci: CanvasItem, c: Vector2, r: float, f: float) -> void:
	if f < 0.02:
		return
	f = minf(f, 1.0)  # Titânica e Meteórica: a recarga passa da base e o polígono dava mais que uma volta
	var pts := PackedVector2Array([c])
	for i in 25:
		pts.append(c + Vector2.from_angle(-PI / 2.0 + TAU * f * i / 24.0) * r)
	ci.draw_colored_polygon(pts, Color(0, 0, 0, 0.6))


## C (h): a caixa que o losango do comando ocupa no ecrã (os 4 botões e o nome do B por baixo), para a legenda dos painéis
## ficar longe dele.
func pad_box() -> Rect2:
	return Rect2(safe.get_global_rect().end - Vector2(216.0, 216.0), Vector2(200.0, 216.0))


## Habilidades em losango, como os botões do comando: Y em cima, X à esquerda, A em baixo, B (interagir) à direita.
## corner = canto de baixo à direita da margem segura.
func _pad_diamond(corner: Vector2, p) -> void:
	var c := corner - Vector2(116.0, 116.0)
	var slot := {"y": Vector2(0, -64), "x": Vector2(-64, 0), "a": Vector2(0, 64), "b": Vector2(64, 0)}
	var keys := ["a", "x", "y"]
	for i in 3:
		var id: String = p.order[i]
		var at: Vector2 = c + slot[keys[i]]
		var r := 36.0 if i == 0 else 30.0
		front.draw_texture_rect(ICONS[id], Rect2(at - Vector2(r, r), Vector2(2 * r, 2 * r)), false)
		if p.cds[id] > 0.0:
			_pie(front, at, r * 0.86, p.cds[id] / p.skills[id].cd)
		var sup: String = p.skills[id].support
		if sup != "":
			front.draw_texture_rect(ICONS[sup], Rect2(at + Vector2(r * 0.2, -r * 1.1), Vector2(r * 0.8, r * 0.8)), false)
		_glyph(front, at + Vector2(r * 0.4, r * 0.62), keys[i], 11.0)
	if p.trans_until > main.time:  # a Alma Transitória (#4) no canto livre do losango, com o LS
		var ta: Vector2 = c + Vector2(-64, -64)
		front.draw_texture_rect(ICONS.transitoria, Rect2(ta - Vector2(26, 26), Vector2(52, 52)), false)
		front.draw_arc(ta, 31.0, -PI / 2.0, -PI / 2.0 + TAU * (p.trans_until - main.time) / p.TRANS_T, 32, Color(0.4, 0.95, 0.9), 3.0)
		_glyph(front, ta + Vector2(-62, 0), "ls", 9.0)  # à esquerda: por baixo tapava o X e o frasco dele
	if hint_action == "" and p.stat("pacto") > 0.0:
		return  # o Pacto tira a esquiva: o B só aparece quando há alguma coisa para fazer
	var b: Vector2 = c + slot.b
	front.draw_circle(b, 26.0, Color(0.05, 0.06, 0.06, 0.8))
	_glyph(front, b - Vector2(13, 0), "b", 13.0)
	if hint_action == "" and p.dash_cd > 0.0:
		_pie(front, b, 22.0, p.dash_cd / p.DASH_CD)
	Gothic.draw_centered(front, b.x, b.y + 46.0, hint_action if hint_action != "" else "Esquiva", 19, Color(0.95, 0.85, 0.6), 5)


## Com comando, no canto de cima, onde estariam os botões (B5: a Árvore com os pontos por gastar).
func top_prompts() -> Array:
	var pts: int = badges().tree
	return ["@view", " " + (tr("Árvore (%d)") % pts if pts > 0 else tr("Árvore")) + "   ", "@ls", " Arsenal   ", "@menu", " Menu"]


## Linha de texto com botões do comando: "@a" "@b" "@x" "@y" "@lb" "@rb" "@menu" "@view" desenham o botão.
## align: 0 = começa em pos, 0.5 = centrada, 1 = acaba em pos.
## back: numa faixa escura (B5: a linha do que dá para fazer lê-se por cima do chão e dos nomes). ci null: só mede.
func _prompts(ci: CanvasItem, pos: Vector2, parts: Array, size := 18, align := 0.0, back := false) -> float:
	# o texto traduz-se sem os espaços à volta (que só servem para separar)
	parts = parts.map(func(s: String): return s if s.begins_with("@") or s.strip_edges() == "" else s.replace(s.strip_edges(), tr(s.strip_edges())))
	size = Gothic.small_px(size)  # B1: na Augusta e no tamanho do texto (ver gothic.gd)
	var font := Gothic.small_font()
	var r := size * 0.62
	var w := 0.0
	for s in parts:
		w += (2.0 * r + 2.0 if GLYPH_COL.has(s.substr(1)) else 3.0 * r + 2.0) if s.begins_with("@") else font.get_string_size(s, HORIZONTAL_ALIGNMENT_LEFT, -1, size).x
	if ci == null:
		return w
	var x := pos.x - w * align
	if back:
		ci.draw_rect(Rect2(x - 10.0, pos.y - size, w + 20.0, size * 1.4), Color(0, 0, 0, 0.6))
	for s in parts:
		if s.begins_with("@"):
			x += _glyph(ci, Vector2(x, pos.y - size * 0.34), s.substr(1), r)
		else:
			ci.draw_string_outline(font, Vector2(x, pos.y), s, HORIZONTAL_ALIGNMENT_LEFT, -1, size, 6, Color.BLACK)
			ci.draw_string(font, Vector2(x, pos.y), s, HORIZONTAL_ALIGNMENT_LEFT, -1, size, Color(0.95, 0.92, 0.85))
			x += font.get_string_size(s, HORIZONTAL_ALIGNMENT_LEFT, -1, size).x
	return w


## Um botão do comando desenhado, com o lado esquerdo em at (a meia altura). Devolve a largura gasta.
func _glyph(ci: CanvasItem, at: Vector2, id: String, r: float) -> float:
	var font := ThemeDB.fallback_font
	var dark_bg := Color(0.06, 0.06, 0.06, 0.92)
	if GLYPH_COL.has(id):
		var c := at + Vector2(r, 0)
		ci.draw_circle(c, r, dark_bg)
		ci.draw_arc(c, r, 0, TAU, 24, GLYPH_COL[id], maxf(1.5, r * 0.14), true)
		var s := glyph_px(r)  # Lote 9 C (e): A, B, X e Y crescem com o círculo, como as letras das pílulas
		var l := id.to_upper()
		var lf: Font = Gothic.small_font() if Gothic.small_body else font
		ci.draw_string(lf, c + Vector2(-lf.get_string_size(l, HORIZONTAL_ALIGNMENT_LEFT, -1, s).x / 2.0, s * 0.36), l, HORIZONTAL_ALIGNMENT_LEFT, -1, s, GLYPH_COL[id])
		return 2.0 * r + 2.0
	# Botões pequenos em pílula: Menu (≡), Vista (dois quadrados), LB, RB
	var rect := Rect2(at + Vector2(0, -r * 0.78), Vector2(3.0 * r, r * 1.56))
	var h := rect.size.y / 2.0
	ci.draw_circle(rect.position + Vector2(h, h), h, dark_bg)
	ci.draw_circle(rect.end - Vector2(h, h), h, dark_bg)
	ci.draw_rect(Rect2(rect.position + Vector2(h, 0), Vector2(rect.size.x - 2.0 * h, rect.size.y)), dark_bg)
	var col := Color(0.92, 0.9, 0.84)
	var c := rect.get_center()
	var line := maxf(1.4, r * 0.15)
	match id:
		"menu":
			for k in [-1, 0, 1]:
				ci.draw_line(c + Vector2(-r * 0.55, k * r * 0.36), c + Vector2(r * 0.55, k * r * 0.36), col, line)
		"view":
			var q := r * 0.62
			ci.draw_rect(Rect2(c + Vector2(-q * 0.8, -q * 0.65), Vector2(q, q * 0.85)), col, false, line)
			ci.draw_rect(Rect2(c + Vector2(-q * 0.2, -q * 0.2), Vector2(q, q * 0.85)), col, false, line)
		_:  # Lote 8 C (g): as letras (LB, RB, LT, RT, LS, RS) na letra do texto pequeno, a crescer com o tamanho do texto
			var l := id.to_upper()
			var s := pill_px(r)
			var pf := Gothic.small_font()
			ci.draw_string(pf, c + Vector2(-pf.get_string_size(l, HORIZONTAL_ALIGNMENT_LEFT, -1, s).x / 2.0, s * 0.36), l, HORIZONTAL_ALIGNMENT_LEFT, -1, s, col)
	return 3.0 * r + 2.0


## Lote 8 C (g): o tamanho das letras de um botão em pílula de raio r. Na Augusta (Gothic.small_body), proporcional ao raio,
## que já cresce com o texto; na de píxeis ficava sempre nos 16 (~7 px de letra a 130%, numa pílula maior).
func pill_px(r: float) -> int:
	return roundi(r * 1.3) if Gothic.small_body else Gothic.px(int(r * 1.05))


## Lote 9 C (e): o mesmo para a letra dentro de um botão redondo (A, B, X, Y) de raio r: na de píxeis ficava nos 16 (~7 px).
func glyph_px(r: float) -> int:
	return roundi(r * 1.25) if Gothic.small_body else Gothic.px(int(r * 1.25))


## Uma poção: o frasco (apagado sem cargas), o número de cargas e a barra da próxima carga.
func _potion(c: Vector2, kind: String, p) -> void:
	var tex: Texture2D = ICONS["potion_" + kind]
	var n: float = p.potions[kind]
	var h := 50.0
	var w := h * tex.get_width() / tex.get_height()
	var col := Color.WHITE if n >= 1.0 else Color(0.4, 0.4, 0.4, 0.8)
	if kind == "hp" and p.stat("sangue") > 0.0:  # Sangue Negro (#117): a poção de vida não faz nada, fica escura
		col = Color(0.45, 0.08, 0.12)
	var oa: float = orb_as[0 if kind == "hp" else 1]
	col.a *= oa  # B2: transparente com a esfera dela
	overlay.draw_texture_rect(tex, Rect2(c.x - w / 2.0, c.y - h / 2.0 - 6.0, w, h), false, col)
	Gothic.draw(overlay, Vector2(c.x + 8, c.y + 20), str(int(n)), 22, Color(1.0, 0.95, 0.8, oa), 5)
	if n < p.POTION_MAX:
		overlay.draw_rect(Rect2(c.x - 18, c.y + 26, 36, 4), Color(0, 0, 0, 0.7))
		overlay.draw_rect(Rect2(c.x - 18, c.y + 26, 36 * (n - floorf(n)), 4), Color(1.0, 0.85, 0.4))
	if gamepad:  # LB por fora da poção da esquerda, RB por fora da da direita
		_glyph(overlay, Vector2(c.x - 50.0 if kind == "hp" else c.x + 20.0, c.y - 30), "lb" if kind == "hp" else "rb", 10.0)


## Retrato redondo dentro do anel ornamentado (o buraco do anel tem 68% da largura).
func _portrait(pl, c: Vector2, r: float) -> void:
	overlay.draw_circle(c, r, Color(0.05, 0.06, 0.06))
	overlay.draw_texture_rect(pl.portrait, Rect2(c - Vector2(r, r), Vector2(2 * r, 2 * r)), false, Color(0.45, 0.45, 0.45) if pl.dead else Color.WHITE)
	var w := 2.0 * r / 0.68
	var h: float = w * UI.ring.get_height() / UI.ring.get_width()
	overlay.draw_texture_rect(UI.ring, Rect2(c.x - w * 0.498, c.y - h * 0.499, w, h), false)


## Barra de vida: cor diz o estado (verde/amarelo/vermelho) e o pedaço claro mostra o que se perdeu.
## A barreira de ossos (Medula Sacrificial) é o pedaço cor de osso a seguir à vida.
func _life_bar(r: Rect2, p) -> void:
	var frac: float = maxf(p.hp, 0.0) / p.max_hp
	r.position.x += 4.0 * p.hurt / 0.2  # a barra leva um empurrão ao sofrer dano
	var col := Color(0.35, 0.85, 0.4) if frac > 0.6 else (Color(0.95, 0.75, 0.2) if frac > 0.3 else Color(0.85, 0.1, 0.12))
	overlay.draw_rect(r.grow(2.0), Color(0.12, 0.1, 0.08))
	overlay.draw_rect(r, Color(0.1, 0.02, 0.02))
	overlay.draw_rect(Rect2(r.position, Vector2(r.size.x * minf(p.hp_chunk / p.max_hp, 1.0), r.size.y)), Color(1.0, 0.85, 0.55))
	overlay.draw_rect(Rect2(r.position, Vector2(r.size.x * frac, r.size.y)), col)
	var bf: float = p.barrier / p.max_hp
	if bf > 0.0:  # com a vida quase cheia, a barreira entra por cima do fim da barra em vez de sair dela
		overlay.draw_rect(Rect2(r.position.x + r.size.x * minf(frac, 1.0 - bf), r.position.y, r.size.x * bf, r.size.y), Color(0.8, 0.88, 0.96))  # osso frio: não se confunde com o pedaço amarelo da vida perdida


## Instabilidade de Alma: a corrupção num fio roxo; na Sobrecarga brilha a pulsar e mostra o tempo que falta.
func _corruption_bar(r: Rect2, p) -> void:
	var over: bool = p.overload_t > 0.0
	overlay.draw_rect(r, Color(0.04, 0.02, 0.06))
	r.size.x *= p.overload_t / p.OVERLOAD_T if over else minf(p.corruption / 100.0, 1.0)
	overlay.draw_rect(r, Color(0.95, 0.55, 1.0, 0.7 + 0.3 * sin(Time.get_ticks_msec() * 0.02)) if over else Color(0.55, 0.25, 0.85))


## Orbe: o vidro da textura recortado num círculo, escuro por cima do nível e cheio por baixo.
func _orb(c: Vector2, r: float, frac: float, tex: Texture2D, oa: float) -> void:
	var full := PackedVector2Array()
	for i in 40:  # a começar no cimo: o que fica abaixo do nível é um só pedaço da volta
		full.append(c + Vector2.from_angle(-PI / 2.0 + i * TAU / 40.0) * r)
	overlay.draw_colored_polygon(full, Color(0.22, 0.22, 0.22, oa), _orb_uv(full, c, r, tex), tex)
	var level := c.y + r - 2.0 * r * clampf(frac, 0.0, 1.0)
	if level > c.y + r - 1.0:
		return  # menos de 1 px de cheio
	# o cheio: a volta abaixo do nível e a linha do nível (os pontos de cima espremidos na linha iam e voltavam por ela, e o
	# polígono às vezes não se triangulava)
	var pts := full
	if level > c.y - r + 0.5:
		var hx := sqrt(maxf(0.0, r * r - (level - c.y) * (level - c.y)))
		pts = PackedVector2Array([Vector2(c.x + hx, level)])
		for q in full:
			if q.y > level:
				pts.append(q)
		pts.append(Vector2(c.x - hx, level))
	overlay.draw_colored_polygon(pts, Color(1, 1, 1, oa), _orb_uv(pts, c, r, tex), tex)


func _orb_uv(pts: PackedVector2Array, c: Vector2, r: float, tex: Texture2D) -> PackedVector2Array:
	var uv := PackedVector2Array()
	var ky := 0.4 * tex.get_width() / tex.get_height()
	for q in pts:
		uv.append(Vector2(0.5 + (q.x - c.x) / r * 0.4, 0.5 + (q.y - c.y) / r * ky))
	return uv


## Barra do chefe na placa da SC-UI2 (o nome por cima): enche do zero quando ele aparece, com o pedaço de dano.
## C (f): onde começa (em cima) o nome do chefe da barra que começa em y.
func boss_name_top(y: float) -> float:
	return y + 460.0 * UI.bar.get_height() / UI.bar.get_width() * 0.12 - Gothic.FONT.get_ascent(Gothic.px(21))


func _boss_bar(e, vs: Vector2, y: float) -> void:
	var w := 460.0
	var h: float = w * UI.bar.get_height() / UI.bar.get_width()
	var r := Rect2(vs.x * 0.5 - w / 2.0, y, w, h)
	var name: String = e.title if e.title != "" else e.NAMES.get(e.kind, "Chefe")
	var hp: float = maxf(e.hp, 0.0)
	var chunk: float = e.hp_chunk
	var full: float = e.max_hp
	if e.trio != "":  # Lote 9: o grupo numa barra, com o nome dele e a vida das que estão de pé somada (as três nascem com a mesma vida)
		var all: Array = main.Bosses.sisters(main, e.trio)
		name = main.Bosses.BOOK[e.trio][0]
		hp = all.reduce(func(s, o): return s + maxf(o.hp, 0.0), 0.0)
		chunk = all.reduce(func(s, o): return s + o.hp_chunk, 0.0)
		full = e.max_hp * 3.0
	front.draw_texture_rect(UI.bar, r, false)
	var inner := Rect2(r.position.x + w * 0.095, r.position.y + h * 0.3125, w * 0.8125, h * 0.375)  # a ranhura da placa
	front.draw_rect(inner, Color(0.08, 0.02, 0.02))
	front.draw_rect(Rect2(inner.position, Vector2(inner.size.x * minf(e.bar_fill, chunk / full), inner.size.y)), Color(1.0, 0.85, 0.55))
	var g: Array = main.Bosses.guards(e)
	front.draw_rect(Rect2(inner.position, Vector2(inner.size.x * minf(e.bar_fill, hp / full), inner.size.y)), Color(0.3, 0.3, 0.32) if bar_shut(e, g) else Color(0.75, 0.08, 0.12))
	var said := boss_guard_text(e, g)
	if said != "":  # e diz porquê, dentro da ranhura (o "Imune" que salta dele perdia-se entre os números de dano); C (d): na Augusta a 20, com contorno escuro, num cinzento escuro (a 16 de píxeis tinha 10 px)
		Gothic.draw_small_centered(front, vs.x * 0.5, inner.end.y - 6.0, said, 20, Color(1.0, 0.97, 0.9), 5)
	Gothic.draw_centered(front, vs.x * 0.5, r.position.y + h * 0.12, name, 21, Color(1.0, 0.85, 0.55), 5)
	var ic: Texture2D = main.Bosses.icon(e) if e.trio == "" else null  # a arma de cada Rei vai por cima dele
	if ic != null:  # o Arquivista (#29): a habilidade que copiou; a Quimera (#190), a arma. Revisão do Lote 9: dentro da moldura, à esquerda do nome, num disco escuro de aro dourado (fora dela tocava no chifre e perdia-se na pedra)
		var c := Vector2(roundf(vs.x * 0.5 - Gothic.width(name, 21) * 0.5 - 24.0), roundf(r.position.y + 5.0))
		Pix.disc(front, c, 9, Color(0.1, 0.06, 0.03))
		Pix.disc(front, c, 8, Color(0.85, 0.62, 0.25))
		Pix.disc(front, c, 7, Color(0.06, 0.04, 0.05))
		boss_icon_rect = Rect2(c - Vector2(14, 14), Vector2(28, 28))
		front.draw_texture_rect(ic, boss_icon_rect, false)
	# Postura (#16): enche com os golpes; cheia, o chefe fica quebrado (a barra pisca a branco)
	var pr := Rect2(inner.position.x, inner.end.y + 5.0, inner.size.x, 5.0)
	front.draw_rect(pr, Color(0.05, 0.04, 0.02, 0.85))
	if e.stagger_t > 0.0:
		front.draw_rect(Rect2(pr.position, Vector2(pr.size.x * e.stagger_t / e.STAGGER_T, pr.size.y)), Color(1, 1, 1, 0.6 + 0.4 * sin(Time.get_ticks_msec() * 0.02)))
	else:
		front.draw_rect(Rect2(pr.position, Vector2(pr.size.x * minf(e.posture, 1.0), pr.size.y)), Color(1.0, 0.85, 0.35))


## B4: a barra do chefe fica cinzenta enquanto ele está imune: guardado (membros, estátuas, runas) ou, a Sibila, fechada ao que
## mais lhe deste (C (g): o mesmo aspeto para os dois).
func bar_shut(e, g: Array = []) -> bool:
	return (main.Bosses.guards(e) if g.is_empty() else g)[0] > 0 and e.boss != "bispo"  # o Bispo (#183) não é imune: os penitentes só o protegem


## B4: o que guarda o chefe, na barra: "Imune · 3 membros", "Imune · 1 runa"; a Sibila diz a que se fechou ("Imune a golpes").
func boss_guard_text(e, g: Array = []) -> String:
	if g.is_empty():
		g = main.Bosses.guards(e)
	if g[0] <= 0:
		return ""
	if e.boss == "sibila":
		return tr("Imune a %s") % tr(g[1])
	if e.boss == "bispo":  # Lote 7: leva 35% enquanto rezam por ele
		return tr("Protegido · %d %s") % [g[0], tr(g[1] if g[0] > 1 else ONE_GUARD.get(g[1], g[1]))]
	return tr("Imune · %d %s") % [g[0], tr(g[1] if g[0] > 1 else ONE_GUARD.get(g[1], g[1]))]


## Texto centrado: gótico (títulos, nomes, números) ou a letra do texto pequeno para frases pequenas.
func _centered(text: String, y: float, size: int, col: Color, vs: Vector2, gothic := true) -> void:
	text = tr(text)
	if gothic:
		Gothic.draw_centered(front, vs.x * 0.5, y, text, size, col, maxi(5, size / 7))
		return
	var font := Gothic.small_font()
	size = Gothic.small_px(size)
	var x: float = vs.x * 0.5 - font.get_string_size(text, HORIZONTAL_ALIGNMENT_LEFT, -1, size).x / 2.0
	front.draw_string_outline(font, Vector2(x, y), text, HORIZONTAL_ALIGNMENT_LEFT, -1, size, maxi(4, size / 6), Color(0, 0, 0, col.a))
	front.draw_string(font, Vector2(x, y), text, HORIZONTAL_ALIGNMENT_LEFT, -1, size, col)


## Cartão do chefe: o nome entra a "bater" (grande e encolhe), numa faixa escura.
func _name_card(vs: Vector2) -> void:
	var k := 1.0 - card_t / CARD_T
	var pop := 1.0 + 0.7 * maxf(0.0, 1.0 - k / 0.05)
	var a := clampf(card_t / 0.5, 0.0, 1.0)
	var cy := vs.y * 0.33
	card_rect = _card_band(vs)
	front.draw_rect(card_rect, Color(0, 0, 0, CARD_BAND_A * a))
	if card_head != "":  # C (d): na Augusta a 24, mais clara e com contorno (na de píxeis a 16 tinha 9 px, vermelho sobre escuro)
		_centered(card_head, cy - 28, 24, Color(1.0, 0.45, 0.4, a), vs, false)
	_centered(card_name, cy + 16, int(48 * pop), Color(0.85, 1.0, 0.85, a), vs)
	_centered(card_sub, _card_sub_y(vs), 20, Color(0.75, 0.75, 0.7, a), vs, false)


## A linha de base da frase do cartão, pela altura real da letra pequena no tamanho do texto: na Augusta, maior, a 18 px
## do título as hastes do l, do h e do F tocavam na linha de base dele.
func _card_sub_y(vs: Vector2) -> float:
	return vs.y * 0.33 + 24.0 + Gothic.small_font().get_ascent(Gothic.small_px(20))


## B4: a faixa do cartão do chefe, mais baixa (eram 116 px) e mais transparente: tapava o chefe. Acaba 4 px abaixo da frase.
func _card_band(vs: Vector2) -> Rect2:
	var top := minf(vs.y * 0.33 - 46.0, vs.y * 0.33 - 28.0 - Gothic.small_font().get_ascent(Gothic.small_px(24)) - 4.0)  # C (d): o "Chefe" maior fica dentro da faixa
	return Rect2(0, top, vs.x, _card_sub_y(vs) + Gothic.small_font().get_descent(Gothic.small_px(20)) + 4.0 - top)


## C (d): com o cartão do chefe à vista, a faixa dele e 24 px por cima, onde nada do mundo com texto se desenha: os nomes do
## saque (Loot.rank) e os números e nomes que saltam (fx.gd, under_card). Vazia sem o cartão.
func card_block() -> Rect2:
	return _card_band(front.size).grow_individual(0.0, 24.0, 0.0, 0.0) if card_t > 0.0 else Rect2()


## Subida de nível: texto grande a saltar e depois as recompensas, uma a uma.
func _level_card(vs: Vector2) -> void:
	var k := 1.0 - lvl_t / LVL_T
	var a := clampf(lvl_t / 0.4, 0.0, 1.0)
	var pop := 1.0 + 0.6 * maxf(0.0, 1.0 - k / 0.06)
	var cy := vs.y * 0.6  # por baixo do herói, para não tapar o cartão do chefe nem os avisos
	_centered(tr("Nível %d!") % main.level, cy, int(66 * pop), Color(1.0, 0.85, 0.4, a), vs)
	var lines := ["+1 Ponto na Árvore dos Condenados", "+8 Vida máxima"]
	for i in lines.size():
		var start := 0.2 + i * 0.12
		if k > start:
			var lp := 1.0 + 0.4 * maxf(0.0, 1.0 - (k - start) / 0.05)
			_centered(lines[i], cy + 36 + i * 28, int(19 * lp), Color(0.9, 1.0, 0.85, a), vs, false)


## Cartão de ajuda: [título, texto] do botão seguro, com os números de agora. Texto vazio = sem cartão
## (Abrir, Descer, Subir e Invocar: o aviso em cima já diz o que fazem).
func _info_text(key: String) -> Array:
	var p = main.player
	var lines := []
	var title := ""
	if p.skills.has(key):
		var s: Dictionary = p.skills[key]
		var n: Array = p.skill_numbers(key)
		title = s.name
		lines.append(tr(SKILL_INFO[key]))
		if key == "bonearmor":
			lines.append(tr("Recarga %s s") % _dec(n[2], 1))
		elif key == "bolt":  # os 16 px da Lança são o raio do golpe, não uma área
			lines.append(tr("Dano %s · recarga %s s") % [_dec(n[0], 0), _dec(n[2], 1)])
		else:
			lines.append(tr("Dano %s · área %d px · recarga %s s") % [_dec(n[0], 0), int(n[1]), _dec(n[2], 1)])
		if s.support == "parasita":
			lines.append(tr("Paga %d de vida em vez de alma") % int(maxf(s.mana * 1.5, 6.0)))
		elif p.stat("fragmentada") > 0.0 and s.mana > 0.0:
			lines.append(tr("Mente Fragmentada: gasta %s de uma carga da poção de alma") % _dec(s.mana / 60.0))
		elif s.mana > 0.0:
			lines.append(tr("Custo: %d de alma") % int(s.mana))
		else:
			lines.append(tr("Sem custo"))
		lines.append(_flask_line(s.support))
	elif key == "interact" and hint_action == "":
		title = "Esquiva Espectral"
		lines.append(tr("Salto de %d px para onde o joystick aponta (ou para a frente); não levas dano durante o salto. Recarga %s s.") % [int(p.DASH_SPEED * p.DASH_T), _dec(p.DASH_CD, 1)])
		lines.append(tr("Esquiva perfeita: esquivar um golpe no momento certo deixa quem bateu exposto (triplo do dano)."))
		lines.append(tr("Deslizar depressa o dedo fora do joystick também esquiva."))
		if p.wears("martir"):
			lines.append(_flask_line("martir"))
	elif key == "interact":
		title = hint_action
		if hint_action == "Executar":
			lines.append(tr("Execução Espectral: um morto com menos de %d%% de vida tem a alma exposta (losango a pulsar). Mata-o de vez, +15 de alma e cura 5%% da vida.") % int(Enemy.EXECUTE_AT * 100.0))
		elif hint_action == "Extrair":
			lines.append(tr("Alma Ancestral: um chefe quebrado deixa extrair a alma: +3 Ossos e +30 de alma."))
		elif hint_action == "Encher":
			lines.append(tr("Quem carrega paga 15% da vida (nunca mata). Com o recipiente cheio (2 vezes), a porta do cofre abre-se."))
		elif hint_action == "Sacrificar":
			lines.append(tr("O teu lacaio mais perto (até 300 px) desfaz-se e a porta abre-se. Sem lacaios, pagas 20% da vida (nunca mata)."))
	elif key == "trans" and p.trans_until > main.time:  # Almas Transitórias (#4)
		title = p.TRANS[p.trans_kind]
		lines.append(tr(TRANS_INFO[p.trans_kind]))
		lines.append(tr("Alma de um só uso: desfaz-se daqui a %d s.") % ceili(p.trans_until - main.time))
	elif key == "tree":
		title = "Árvore dos Condenados"
		lines.append(tr("Abre a árvore de poderes do herói: gasta aqui os pontos que ganhas em cada nível."))
		lines.append(tr("Pontos por gastar: %d") % p.points)
	elif key == "arsenal":
		title = "Arsenal"
		lines.append(tr("Abre o Arsenal: melhora a foice com Tinteiros, Cinzas do Purgatório e Ossos, escolhe os Frascos de Alma e põe o equipamento de cada herói."))
		lines.append(main.weapon_text())
	elif key == "menu":
		title = "Menu"
		lines.append(tr("Abre o menu e põe o jogo em pausa: Bestiário, Configurações, Gravar e Menu principal."))
	elif key == "minimap":  # B6: a legenda do minimapa
		title = "Mapa"
		if main.zone == "sep" and main.crypt_rule == "esquecidos" and not main.eye_on():  # o Abismo (#211) não desenha salas nem saídas
			lines.append(tr("Sem mapa nem seta: segue as tochas negras."))
		elif main.zone == "sep":
			lines.append_array([tr("Com o Olho Mumificado vês todas as salas; a Capela e o Cofre piscam a azul.") if main.eye_on() else tr("Só aparecem as salas que já pisaste."),
				tr("Quadrado roxo: a saída."), tr("Quadrado dourado: a descida (depois do guardião).")])
		elif main.zone == "crypt":
			lines.append(tr("Quadrado roxo: a saída da cripta."))
		else:
			lines.append_array([tr("Círculo verde: o Monumento."), tr("Quadrado roxo: a Cripta."), tr("Quadrado dourado: o Portão dos Reis."),
				tr("Pontos dourados: acampamentos por limpar."), tr("Linha tracejada: o caminho até ao teu túmulo.")])
		lines.append(tr("Pontos vermelhos: monstros (os chefes são maiores e pulsam)."))
	elif key == "coins":  # B6: para que serve cada moeda
		title = "Moedas"
		for k in COIN_INFO:
			if k in ["bone", "ink", "ash"] or main.currency.get(k, 0) > 0:
				lines.append(tr("%s (%d): %s") % [tr(Loot.INFO[k][0]), main.currency.get(k, 0), tr(COIN_INFO[k])])
		lines.append(tr("Toca para abrir a Bolsa."))
	elif key == "stance":
		title = "Postura de Combate"
		lines.append(tr("Agora: %s") % tr(STANCE_INFO[p.stance]))
		lines.append(tr("Toca para passar a: %s") % tr(STANCE_INFO["ira" if p.stance == "guarda" else "guarda"]))
		if p.stat("grito") > 0.0:
			lines.append(_passive_line("grito"))
	elif key == "potion_hp":
		title = "Poção de Vida"
		lines.append(tr("Cargas: %s de %d") % [_charges(p.potions.hp), p.POTION_MAX])  # numa linha só dela: o número nunca se separa do total
		lines.append(tr("Cura 40%% da vida máxima (%d). Cada abate dá ¼ de carga, um chefe dá 1. Não se bebe com a vida cheia.") % int(p.max_hp * 0.4))
		for k in ["sangue", "lich"]:
			if p.stat(k) > 0.0:
				lines.append(_passive_line(k))
		if p.wears("roubo"):
			lines.append(_flask_line("roubo"))
	elif key == "potion_mp":
		title = "Poção de Alma"
		lines.append(tr("Cargas: %s de %d") % [_charges(p.potions.mp), p.POTION_MAX])
		lines.append(tr("Dá 60%% da alma máxima (%d). Cada abate dá ¼ de carga, um chefe dá 1. Não se bebe com a alma cheia.") % int(p.max_mana * 0.6))
		for k in ["fragmentada", "lich"]:
			if p.stat(k) > 0.0:
				lines.append(_passive_line(k))
		if p.wears("roubo"):
			lines.append(_flask_line("roubo"))
	return [title, "\n".join(lines)]


func _flask_line(f: String) -> String:
	return tr("Frasco: %s — %s") % [tr(main.player.SUPPORT_NAMES[f]), tr(main.player.SUPPORT_DESC[f])]


func _passive_line(id: String) -> String:
	return "%s: %s" % [tr(main.PASSIVES[id].name), tr(main.PASSIVES[id].desc)]


## O cartão ao lado do botão seguro (à esquerda dele; no canhoto, à direita; os do canto de cima, sempre à esquerda),
## dentro da margem segura.
func _info_card(b: Button, t: Array) -> void:
	var sr := safe.get_global_rect()
	var br := b.get_global_rect()
	if b in potion_btns:  # C (b): a caixa das cargas, encostada ao botão, também fica à vista
		br = br.merge(charge_box(potion_btns.find(b)))
	var w := 520.0  # mais largo que antes: a Augusta a 25 px pede mais espaço por linha
	var cs := roundi(Gothic.CARD_SIZE * text_k)  # o tamanho do texto das Configurações (#99)
	var h: float = 64.0 + Gothic.BODY.get_multiline_string_size(t[1], HORIZONTAL_ALIGNMENT_LEFT, w - 28.0, cs).y
	var right: bool = (lefty and pad.is_ancestor_of(b)) or (not pad.is_ancestor_of(b) and br.get_center().x < sr.get_center().x)  # B6: as moedas, à esquerda: o cartão à direita delas
	var at := Vector2(br.end.x + 16.0 if right else br.position.x - w - 16.0, br.get_center().y - h / 2.0)
	at = at.clamp(sr.position, sr.end - Vector2(w, h))
	hold_card = Rect2(at, Vector2(w, h))
	var sb := StyleBoxFlat.new()
	sb.bg_color = Color(0.04, 0.07, 0.07, 0.95)  # Lote 12 C (i): a 0,92 via-se o 2.º jogador através dele (agora também fica escondido)
	sb.border_color = Color(0.85, 0.8, 0.65)
	sb.set_border_width_all(3)
	sb.set_corner_radius_all(8)
	front.draw_style_box(sb, Rect2(at, Vector2(w, h)))
	Gothic.draw(front, at + Vector2(14.0, 14.0 + Gothic.FONT.get_ascent(32)), t[0], 32, Color(1.0, 0.85, 0.55), 5)
	# corpo na Augusta: a Alkhemikal a 16 ou 19 px lia-se mal no telemóvel (o título fica na gótica, a 32)
	front.draw_multiline_string(Gothic.BODY, at + Vector2(14.0, 54.0 + Gothic.BODY.get_ascent(cs)), t[1], HORIZONTAL_ALIGNMENT_LEFT, w - 28.0, cs, -1, Color(0.88, 0.84, 0.72))


# ---------- Painéis ----------

## cancel: o B do comando (ou o Voltar do Android) fecha o painel.
## back = para onde B / Voltar levam (vazio: fecha o painel e volta ao jogo).
func _open_panel(title: String, cancel := true, back := Callable()) -> VBoxContainer:
	var fresh := panel == null  # H3: só o primeiro painel aparece devagar (os que se refazem a cada toque não piscam)
	close_panel()
	get_tree().paused = true
	panel_title = title
	panel_cancel = cancel
	panel_back = back
	panel_frame = Engine.get_process_frames()
	for p in main.players:
		p.held.clear()
	var pc := PanelContainer.new()
	# H3: o fundo por baixo do painel, no título a arte escurecida e no jogo um véu escuro; tapa o HUD e os botões de cima.
	if title_open:
		shade = _art(TITLE_ART, Vector2.ZERO)  # escurecida no draw, por baixo da legenda (o modulate escurecia a legenda também)
	else:
		var veil := ColorRect.new()
		veil.color = Color(0.0, 0.02, 0.02, 0.62)
		shade = veil
	var sh := shade
	sh.set_anchors_preset(Control.PRESET_FULL_RECT)
	sh.mouse_filter = Control.MOUSE_FILTER_STOP
	sh.draw.connect(func():  # a legenda do comando, por baixo da moldura (o fundo fica por baixo do painel e por cima do HUD)
		if sh is TextureRect:
			sh.draw_rect(Rect2(Vector2.ZERO, sh.size), Color(0.0, 0.0, 0.0, 0.6))  # a arte do título a 40%
		legend_rect = Rect2()
		if gamepad:
			var pr: Rect2 = pc.get_global_rect()
			var side := 0.0  # C (h): sem lugar por baixo da moldura (o Equipamento chega aos 702 px), ao lado dela, uma por linha
			if pr.end.y + 30.0 > sh.size.y - 4.0:  # à esquerda primeiro: à direita, em baixo, estão os botões do comando (o losango do HUD)
				side = -1.0 if pr.position.x >= 150.0 else 1.0 if sh.size.x - pr.end.x >= 150.0 else 0.0
			var ls := Gothic.small_px(17)
			var lines: Array = [["@a", " Escolher     ", "@b", " Voltar"] if panel_cancel else ["@a", " Escolher"]] if side == 0.0 else [["@a", " Escolher"]] + ([["@b", " Voltar"]] if panel_cancel else [])
			var al := 0.5 if side == 0.0 else 0.0 if side > 0.0 else 1.0
			# numa faixa escura (como a linha do que dá para fazer), afastada 12 px da moldura
			legend_at = Vector2(sh.size.x * 0.5, minf(pr.end.y + 24.0, sh.size.y - 8.0)) if side == 0.0 else Vector2(pr.end.x + 22.0 if side > 0.0 else pr.position.x - 22.0, pr.end.y - 38.0)
			for i in lines.size():
				var at: Vector2 = legend_at + Vector2(0, (ls * 1.4 + 4.0) * i)
				var lw := _prompts(sh, at, lines[i], 17, al, true)
				legend_rect = legend_rect.merge(Rect2(at.x - lw * al - 10.0, at.y - ls, lw + 20.0, ls * 1.4)) if legend_rect.has_area() else Rect2(at.x - lw * al - 10.0, at.y - ls, lw + 20.0, ls * 1.4))
	root.add_child(sh)
	panel = pc
	root.add_child(pc)
	if fresh:  # nunca na escala: o _process encolhe o painel que não cabe (S1)
		pc.modulate.a = 0.0
		sh.modulate.a = 0.0
		var tw := pc.create_tween().set_parallel()
		tw.tween_property(pc, "modulate:a", 1.0, 0.12)
		tw.tween_property(sh, "modulate:a", 1.0, 0.12)
	var box := VBoxContainer.new()
	box.add_theme_constant_override("separation", 6)
	pc.add_child(box)
	# Título do painel em letra gótica (desenhado, para os acentos saírem na mesma letra)
	var t := Control.new()
	t.custom_minimum_size = Vector2(Gothic.width(title, 32) + 10, 42)
	t.draw.connect(func(): Gothic.draw(t, Vector2(0, 33), title, 32, Color(0.95, 0.8, 0.5), 6))
	box.add_child(t)
	pc.set_anchors_and_offsets_preset(Control.PRESET_CENTER)
	pc.grow_horizontal = Control.GROW_DIRECTION_BOTH
	pc.grow_vertical = Control.GROW_DIRECTION_BOTH
	return box


func close_panel() -> void:
	if panel:
		panel.queue_free()
		panel = null
	for n in [shade, shield]:
		if is_instance_valid(n):
			n.queue_free()
	shade = null
	shield = null
	panel_title = ""
	panel_cancel = false
	panel_back = Callable()
	get_tree().paused = false
	for p in main.players:
		p.lock_skills = true  # o A que fechou o painel não sai como ataque
	closed_frame = Engine.get_process_frames()  # nem o B que o fechou sai como esquiva (ou volta a abrir o Cortejo)
	if not title_open:
		main.save_game()  # o que se gastou ou escolheu no painel fica logo gravado


## Alguém perdeu o comando: pausa com aviso (Continuar no ecrã ou com outro comando).
func pad_lost(who: String, first: bool) -> void:
	if first:
		gamepad = false
	if panel != null:
		toast(tr("O comando do %s desligou-se.") % tr(who))
		return
	var box := _open_panel("Comando desligado")
	_text(box, tr("O comando do %s desligou-se.\nVolta a ligá-lo, ou continua com os controlos no ecrã.") % tr(who))
	_button(box, "Continuar", close_panel).grab_focus()


## Botão/gesto Voltar do Android: volta atrás no painel aberto ou abre o Menu (que pausa o jogo), em vez de sair.
## A app vai para segundo plano a meio do jogo (só no telemóvel): ao voltar está em pausa no Menu.
func _notification(what: int) -> void:
	if what == NOTIFICATION_APPLICATION_PAUSED and main != null and panel == null and intro_i < 0 and not title_open:
		open_menu()
	elif what == NOTIFICATION_WM_GO_BACK_REQUEST and main != null:
		if panel == null:
			open_menu()
		elif panel_cancel:
			_back()


func _back() -> void:
	if panel_back.is_valid():
		panel_back.call()
	else:
		close_panel()


## Arsenal e Árvore abertos direto (barra do ecrã; no comando LS e Vista/RS): B volta ao jogo. O Arsenal abre no último
## separador (G1).
func _arsenal(who := 0) -> void:
	sub_back = Callable()
	gear_who = who
	match hub_tab:
		1:
			open_forge()
		2:
			open_gear(who, Callable())
		_:
			open_arsenal()


## G1: os 3 separadores do Arsenal (Frascos, Forja, Equipamento), como os das Configurações, na linha do título, à direita
## (numa linha só deles a Forja passava dos 720 px com o texto a 130%). B / Voltar saem do Arsenal (para o Menu ou para o
## jogo: sub_back), nunca de um separador para o outro.
func _hub_tabs(box: Control, at: int) -> void:
	hub_tab = at
	box.custom_minimum_size.x = hub_w()
	panel.set_anchors_and_offsets_preset(Control.PRESET_CENTER_TOP)  # o cimo fixo: os separadores ficam no mesmo sítio, cresça o painel quanto crescer
	panel.grow_horizontal = Control.GROW_DIRECTION_BOTH
	panel.grow_vertical = Control.GROW_DIRECTION_END
	panel.offset_top = HUB_TOP
	var tabs := HBoxContainer.new()
	tabs.add_theme_constant_override("separation", 6)
	box.add_child(tabs)
	box.move_child(tabs, 0)
	box.get_child(1).reparent(tabs, false)  # o título do painel, à esquerda
	var gap := Control.new()
	gap.custom_minimum_size.x = 12
	gap.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	tabs.add_child(gap)
	var go := [open_arsenal, open_forge.bind(2, sub_back), func(): open_gear(gear_who, sub_back)]
	for i in HUB_TABS.size():
		var b := _button(tabs, HUB_TABS[i], go[i], null, 140.0)
		b.custom_minimum_size.y = 48  # a altura do dedo (com 44 falhava-se o separador)
		b.set_meta("tab", i)
		if i == at:
			b.add_theme_stylebox_override("normal", _sbt(UI.btn_on, Color.WHITE))
			b.add_theme_color_override("font_color", Color.WHITE)


## A largura do conteúdo do Arsenal (os 3 separadores): com o texto a 80% fica a de 100%.
func hub_w() -> float:
	return HUB_W * maxf(text_k, 1.0)


func _tree(who := 0) -> void:
	sub_back = Callable()
	open_tree(who)


func _text(box: Control, text: String, col := Color(0.8, 0.8, 0.75)) -> void:
	var l := Label.new()
	l.text = text
	l.add_theme_color_override("font_color", col)
	box.add_child(l)


func _button(box: Control, text: String, cb: Callable, icon: Texture2D = null, width := 560.0) -> Button:
	var b := Button.new()
	b.text = text
	b.custom_minimum_size = Vector2(width, 52)
	b.icon = icon
	b.add_theme_constant_override("icon_max_width", 28)
	b.draw.connect(_icon_rim.bind(b))
	b.pressed.connect(cb)
	box.add_child(b)
	return b


## H5: o botão de sair de cada painel, sempre o último: "Voltar" quando B / Voltar levam a outro painel, "Fechar" quando
## voltam ao jogo (word troca a palavra: o "Recuar" do Cortejo).
func _close_button(box: Control, width := 560.0, word := "") -> Button:
	return _button(box, word if word != "" else "Voltar" if panel_back.is_valid() else "Fechar", _back, null, width)


## H1: o que sai, apaga ou gasta pede dois toques. O 1.º só arma o botão ("Outra vez: …", aceso e do mesmo tamanho, para o
## painel não mexer debaixo do dedo); o 2.º corre act. O foco noutro sítio desarma-o, e correr também (um 3.º toque arma).
func _two_tap(b: Button, verb: String, act: Callable) -> Button:
	var was := [b.text, b.icon, b.custom_minimum_size.x, b.get_theme_font_size("font_size") if b.has_theme_font_size_override("font_size") else 0]
	var calm := func():
		b.remove_meta("armed")
		b.text = b.get_meta("idle", was[0])
		b.icon = was[1]
		b.custom_minimum_size.x = was[2]
		if was[3] > 0:
			b.add_theme_font_size_override("font_size", was[3])
		else:
			b.remove_theme_font_size_override("font_size")
		b.clip_text = false
		b.text_overrun_behavior = TextServer.OVERRUN_NO_TRIMMING
		b.modulate = Color.WHITE
		if b.has_meta("idle"):  # o texto de repouso mudou (_set_idle): cabe na largura
			_fit_text(b)
	b.pressed.connect(func():
		if b.has_meta("armed"):
			calm.call()
			act.call()
			return
		b.set_meta("armed", true)
		b.custom_minimum_size.x = maxf(b.size.x, b.get_combined_minimum_size().x)  # antes do clip_text, que lhe tirava a largura do texto
		b.clip_text = true
		b.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
		b.icon = null
		b.text = tr("Outra vez: %s") % tr(verb)
		_fit_text(b)  # a 130% ou em inglês os botões estreitos cortavam o que o 2.º toque faz
		b.modulate = Color(1.3, 1.2, 0.8))
	b.focus_exited.connect(calm)
	b.set_meta("calm", calm)  # _disarm: outra escolha no painel também o desarma (o foco pode não ter passado por ele)
	return b


func _disarm(b: Button) -> void:
	if b.has_meta("armed"):
		b.get_meta("calm").call()


## A letra do botão encolhe até o texto caber inteiro na largura dele (gap: a folga de cada lado do texto, com ícone).
## wrap (revisão do Lote 10, nas grelhas da Forja): antes de encolher, o texto passa a duas linhas (depois do ":" ou ao meio) e
## o botão cresce; e nunca encolhe abaixo de 85% (uma linha a 65%, ao lado das outras, lia-se mal no telemóvel).
func _fit_text(b: Button, gap := 0.0, wrap := false) -> void:
	var room: float = b.custom_minimum_size.x - b.get_theme_stylebox("normal").get_minimum_size().x - 2.0 * b.get_theme_constant("outline_size")  # o contorno das letras também ocupa
	if b.icon != null:  # e o ícone (os frascos do Arsenal)
		room -= b.get_theme_constant("icon_max_width") + b.get_theme_constant("h_separation") + 2.0 * gap
	var font := b.get_theme_font("font")
	var fs := b.get_theme_font_size("font_size")
	var wide := func(s: String, size: int) -> float: return Array(s.split("\n")).map(func(l): return font.get_string_size(l, HORIZONTAL_ALIGNMENT_LEFT, -1, size).x).max()
	var t: String = tr(b.text) if wrap else b.text  # wrap: o texto que se vê (as almas da arma têm a chave portuguesa)
	if wrap and not "\n" in t and wide.call(t, fs) > room:
		var at := t.find(": ")
		var w := t.split(" ")
		var cuts: Array = [t.substr(0, at + 1) + "\n" + t.substr(at + 2)] if at > 0 else range(1, w.size()).map(func(i): return " ".join(w.slice(0, i)) + "\n" + " ".join(w.slice(i)))
		cuts.sort_custom(func(x, y): return wide.call(x, fs) < wide.call(y, fs))
		if not cuts.is_empty():
			t = cuts[0]
			b.text = t  # já traduzido: com a quebra deixava de ser a chave da tradução
	var least := ceili(fs * 0.85) if wrap else 12
	while fs > least and wide.call(t, fs) > room:
		fs -= 1
	b.add_theme_font_size_override("font_size", fs)
	if "\n" in b.text:  # a altura das duas linhas fica, também armado (H1: o painel não mexe debaixo do dedo)
		b.custom_minimum_size.y = maxf(b.custom_minimum_size.y, b.get_minimum_size().y)


## Muda o texto de um botão de dois toques (H1) sem o desarmar: fica como o texto de repouso.
func _set_idle(b: Button, text: String) -> void:
	b.set_meta("idle", text)
	if not b.has_meta("armed"):
		b.text = text
		b.remove_theme_font_size_override("font_size")
		_fit_text(b)


## H2: um painel que abre sozinho (entre ondas, a maldição, a morte) ou que apaga tudo não aceita toques nem o A durante t
## segundos: o dedo ou o A que vinham da luta não carregam no 1.º botão. Uma barra na moldura de baixo esvazia-se.
func _shield(t := 0.6, focus: Control = null) -> void:
	var f: Control = focus if focus != null else get_viewport().gui_get_focus_owner()
	get_viewport().gui_release_focus()
	shield = Control.new()
	var sh := shield
	sh.set_anchors_preset(Control.PRESET_FULL_RECT)
	sh.mouse_filter = Control.MOUSE_FILTER_STOP
	var left := [1.0]
	sh.draw.connect(func():
		if panel is PanelContainer:
			var pr: Rect2 = panel.get_global_rect()
			sh.draw_rect(Rect2(pr.position.x + 24.0, pr.end.y - 16.0, (pr.size.x - 48.0) * left[0], 4.0), Color(1.0, 0.85, 0.4, 0.85)))
	root.add_child(sh)
	var tw := sh.create_tween()  # preso ao escudo: fechar o painel antes do fim acaba com tudo
	tw.tween_method(func(k: float):
		left[0] = k
		sh.queue_redraw(), 1.0, 0.0, t)
	tw.tween_callback(func():
		if is_instance_valid(f) and f.is_inside_tree():
			f.grab_focus()
		sh.queue_free())


## Os desenhos 32-bit têm margens vazias à volta: para ícones e quadros fica só o que tem píxeis.
func _trim(tex: Texture2D) -> Texture2D:
	if not trims.has(tex):
		var a := AtlasTexture.new()
		a.atlas = tex
		a.region = Rect2(tex.get_image().get_used_rect())
		trims[tex] = a
	return trims[tex]


## Lote 11 C (d, e): o ícone com um contorno claro de r píxeis (da imagem) por fora, para um ícone escuro se ler num fundo
## escuro. only: só o contorno, para desenhar por cima do ícone que o botão já pôs (o ícone dele não muda). fit: o ícone
## primeiro nesse tamanho (o do ecrã). Uma vez por ícone.
func _rim(tex: Texture2D, only := false, r := 5, fit := Vector2i.ZERO) -> Texture2D:
	var key := [tex, only, r, fit]
	if not rims.has(key):
		var img: Image = tex.get_image()
		if img.is_compressed():
			img.decompress()
		img = img.duplicate()
		img.convert(Image.FORMAT_RGBA8)
		if fit != Vector2i.ZERO:
			img.resize(fit.x, fit.y, Image.INTERPOLATE_BILINEAR)
		var w := img.get_width()
		var h := img.get_height()
		var solid := Image.create_empty(w, h, false, Image.FORMAT_RGBA8)
		solid.fill(RIM)
		var out := Image.create_empty(w + 2 * r, h + 2 * r, false, Image.FORMAT_RGBA8)
		for dy in range(-r, r + 1):
			for dx in range(-r, r + 1):
				if dx * dx + dy * dy <= r * r:  # um disco de r: o contorno com a mesma largura em toda a volta
					out.blit_rect_mask(solid, img, Rect2i(0, 0, w, h), Vector2i(r + dx, r + dy))
		if only:
			out.blit_rect_mask(Image.create_empty(w, h, false, Image.FORMAT_RGBA8), img, Rect2i(0, 0, w, h), Vector2i(r, r))  # tira o sítio do ícone
		else:
			out.blend_rect(img, Rect2i(0, 0, w, h), Vector2i(r, r))
		rims[key] = ImageTexture.create_from_image(out)
	return rims[key]


## Lote 12 C (c, f): o contorno de um ícone escuro desenhado em r: 1 px no ecrã, osso a 65%, por fora do ícone (o ícone não
## muda); nada abaixo de y_max.
func _draw_rim(ci: CanvasItem, tex: Texture2D, r: Rect2, y_max := INF) -> void:
	var rim := _rim(tex, true, 1, Vector2i(maxi(1, roundi(r.size.x)), maxi(1, roundi(r.size.y))))  # feito já no tamanho do ecrã: 1 px certo (encolhido pelo filtro, desfazia-se)
	var dst := Rect2(r.position.round() - Vector2.ONE, rim.get_size())
	var src := Rect2(Vector2.ZERO, rim.get_size())
	if dst.end.y > y_max:
		src.size.y = maxf(0.0, floorf(y_max - dst.position.y))
		dst.size.y = src.size.y
	ci.draw_texture_rect_region(rim, dst, src, Color(1, 1, 1, 0.65))


## Lote 12 C (c): um ícone escuro num botão (o Óleo de Lápide, no Atlas, sumia no cinzento) leva o contorno dos quadrados.
func _icon_rim(b: Button) -> void:
	if b.icon == null or b.expand_icon or b.icon_alignment != HORIZONTAL_ALIGNMENT_LEFT or not _dark_icon(b.icon):
		return
	var mw: int = b.get_theme_constant("icon_max_width")
	var w: float = minf(b.icon.get_width(), mw) if mw > 0 else float(b.icon.get_width())
	var h: float = b.icon.get_height() * w / b.icon.get_width()
	_draw_rim(b, b.icon, Rect2(b.get_theme_stylebox("normal").get_margin(SIDE_LEFT), (b.size.y - h) / 2.0, w, h))


## Lote 11 C (e): um ícone escuro (a média da luz dos píxeis à vista abaixo de 0,3, como as Manoplas) some num quadrado escuro.
func _dark_icon(tex: Texture2D) -> bool:
	if not dark_icons.has(tex):
		var img: Image = tex.get_image()
		if img.is_compressed():
			img.decompress()
		img = img.duplicate()
		img.convert(Image.FORMAT_RGBA8)
		img.resize(16, 16, Image.INTERPOLATE_NEAREST)
		var sum := 0.0
		var n := 0
		for y in 16:
			for x in 16:
				var c := img.get_pixel(x, y)
				if c.a > 0.5:
					sum += c.get_luminance()
					n += 1
		dark_icons[tex] = n > 0 and sum / n < 0.3
	return dark_icons[tex]


func _art(tex: Texture2D, size: Vector2) -> TextureRect:
	var r := TextureRect.new()
	r.texture = tex
	r.custom_minimum_size = size
	r.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	r.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_COVERED
	r.clip_contents = true
	return r


## Ecrã de título com a arte de capa: Continuar (se há jogo gravado), Novo jogo, Co-op, Configurações e Sobre.
func open_title() -> void:
	main.play_track("title")
	title_open = true
	drop_toasts()  # C (f): os avisos do jogo ficam no jogo
	close_panel()
	get_tree().paused = true
	var c := Control.new()
	c.set_anchors_preset(Control.PRESET_FULL_RECT)
	var bg := _art(TITLE_ART, Vector2.ZERO)
	bg.set_anchors_preset(Control.PRESET_FULL_RECT)
	c.add_child(bg)
	var logo := VBoxContainer.new()
	logo.anchor_right = 1.0
	logo.offset_top = 24
	logo.offset_bottom = 150
	c.add_child(logo)
	for l in [["Soulstrider", 112, Color(0.88, 0.97, 0.88)], ["Necro-Dominion", 38, Color(0.45, 1.0, 0.65)]]:
		var lb := Label.new()
		lb.text = l[0]
		lb.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		lb.add_theme_font_override("font", Gothic.FONT)
		lb.add_theme_font_size_override("font_size", Gothic.px(l[1]))
		lb.add_theme_color_override("font_color", l[2])
		lb.add_theme_color_override("font_outline_color", Color.BLACK)
		lb.add_theme_constant_override("outline_size", 14)
		logo.add_child(lb)
	var menu := VBoxContainer.new()
	menu.anchor_left = 0.5
	menu.anchor_right = 0.5
	menu.anchor_top = 1.0
	menu.anchor_bottom = 1.0
	menu.offset_left = -200
	menu.offset_right = 200
	menu.offset_top = -190
	menu.offset_bottom = -24
	menu.add_theme_constant_override("separation", 10)
	menu.grow_vertical = Control.GROW_DIRECTION_BEGIN  # com o botão de atualizar, cresce para cima
	c.add_child(menu)
	title_menu = menu
	var ver := _label(Vector2.ZERO, 18)
	ver.reparent(c)
	ver.text = tr("Versão %s") % AppUpdate.VERSION_NAME
	ver.set_anchors_and_offsets_preset(Control.PRESET_TOP_RIGHT)
	ver.offset_left = -140
	ver.offset_top = 8
	ver.offset_right = -12
	ver.offset_bottom = 28
	ver.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	ver.add_theme_color_override("font_color", Color(1, 1, 1, 0.55))
	var items := [[tr("Continuar · Nível %d") % main.level, _play], ["Mudar de herói", _pick_hero.bind(_play_as, "Mudar de herói (o progresso fica)")]] if main.has_save() else []
	items += [["Novo jogo", _new_game], ["Jogar a dois", open_duo]]  # A3: Configurações e Sobre só nos cantos; UX 27: as duas maneiras de jogar a dois num só sítio
	var first: Button
	for it in items:
		var b := _button(menu, it[0], it[1], null, 400.0)
		b.add_theme_font_size_override("font_size", roundi(22 * text_k))  # A3: na letra do texto, mais pequenas que o Continuar
		b.custom_minimum_size.y = 42
		if first == null:
			first = b
	if main.has_save():  # A3: o Continuar à frente de tudo, maior e dourado
		first.custom_minimum_size.y = 60
		first.add_theme_font_override("font", Gothic.FONT)
		first.add_theme_font_size_override("font_size", Gothic.px(30))
		for st in ["font_color", "font_focus_color", "font_hover_color"]:
			first.add_theme_color_override(st, Color(1.0, 0.85, 0.45))
	# Legenda: com comando mostra os botões; no ecrã tátil basta tocar
	var tip := Control.new()
	tip.custom_minimum_size = Vector2(400, 24)
	tip.draw.connect(func():
		var parts := ["@a", " Escolher      ", "Segundo comando: ", "@menu", " entra o segundo jogador"] if gamepad else ["Toca para escolher  ·  com comandos, cada jogador usa o seu"]
		_prompts(tip, Vector2(200, 17), parts, 15, 0.5))
	menu.add_child(tip)
	# Primeiro só a arte, o nome e "Toca para começar" (com Configurações e Sobre nos cantos); um toque em
	# qualquer sítio, ou A, mostra o menu. O botão invisível do ecrã inteiro fica por baixo dos outros.
	var shade := TextureRect.new()
	var grad := GradientTexture2D.new()
	grad.gradient = Gradient.new()
	grad.gradient.colors = PackedColorArray([Color(0, 0, 0, 0), Color(0, 0, 0, 0.85)])
	grad.fill_to = Vector2(0, 1)
	shade.texture = grad
	shade.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	shade.mouse_filter = Control.MOUSE_FILTER_IGNORE
	shade.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_WIDE)
	shade.offset_top = -240
	c.add_child(shade)
	c.move_child(shade, 1)
	var start := Button.new()
	start.flat = true
	start.set_anchors_preset(Control.PRESET_FULL_RECT)
	start.add_theme_stylebox_override("focus", StyleBoxEmpty.new())
	c.add_child(start)
	c.move_child(start, 2)
	var press := Control.new()
	press.set_anchors_preset(Control.PRESET_FULL_RECT)
	press.mouse_filter = Control.MOUSE_FILTER_IGNORE
	press.draw.connect(func():
		if gamepad:
			_prompts(press, Vector2(press.size.x / 2.0, press.size.y - 58.0), ["@a", " Começar"], 30, 0.5)
		else:
			Gothic.draw_centered(press, press.size.x / 2.0, press.size.y - 50.0, "Toca para começar", 48, Color(0.93, 0.89, 0.77), 8))
	c.add_child(press)
	var pulse := press.create_tween().set_loops()
	pulse.tween_property(press, "modulate:a", 0.35, 0.9)
	pulse.tween_property(press, "modulate:a", 1.0, 0.9)
	var corners := []
	for k in [["Configurações", func(): open_settings(0, open_title), 0.0, 24.0], ["Sobre", func(): open_about(open_title), 1.0, -264.0]]:
		var b := _button(c, k[0], k[1], null, 240.0)
		b.focus_mode = Control.FOCUS_NONE
		b.add_theme_font_override("font", Gothic.FONT)
		b.add_theme_font_size_override("font_size", Gothic.px(24))
		b.anchor_left = k[2]
		b.anchor_right = k[2]
		b.anchor_top = 1.0
		b.anchor_bottom = 1.0
		b.offset_left = k[3]
		b.offset_right = k[3] + 240.0
		b.offset_top = -70.0
		b.offset_bottom = -22.0
		corners.append(b)
	title_reveal = func():
		for n in [start, press]:
			n.queue_free()
		for k in corners.size():  # A3: os cantos ficam; no comando, à esquerda e à direita do menu
			var cb: Button = corners[k]
			cb.focus_mode = Control.FOCUS_ALL
			for b in menu.get_children():
				if b is Button:
					b.set("focus_neighbor_" + ["left", "right"][k], b.get_path_to(cb))
			cb.set("focus_neighbor_" + ["right", "left"][k], cb.get_path_to(first))
		menu.visible = true
		first.grab_focus()
	start.pressed.connect(title_reveal)
	menu.visible = false
	root.add_child(c)
	panel = c
	panel_cancel = false
	panel_frame = Engine.get_process_frames()
	start.grab_focus()
	if main.has_save():  # A3: com jogo gravado o menu abre já, com o foco no Continuar (sem o "Toca para começar")
		title_reveal.call()
	if not updater.info.is_empty():
		_on_update(updater.info)
	Net.stop_scan()
	if Engine.has_meta("net_note"):
		title_reveal.call()
		toast(Engine.get_meta("net_note"))
		Engine.remove_meta("net_note")


## UX 27: as duas maneiras de jogar a dois, cada uma com o que precisa (no título eram duas entradas sem explicação).
func open_duo() -> void:
	var box := _open_panel("Jogar a dois", true, open_title)
	_button(box, "No mesmo telemóvel", func():
		_play()
		if main.players.size() < 2:
			main.add_player(), null, 460.0).grab_focus()
	var pads := not Input.get_connected_joypads().is_empty()
	_text(box, "O segundo jogador precisa de um comando (Bluetooth ou USB)." if pads else "Liga primeiro um comando.", Color(0.8, 0.8, 0.75) if pads else Color(1.0, 0.4, 0.35))
	_button(box, "Dois telemóveis, na mesma Wi-Fi", open_lan, null, 460.0)
	_close_button(box, 460.0)


## Co-op por Wi-Fi: um telemóvel cria a sala e joga com o seu herói; o outro, na mesma rede, vê-a aparecer e
## entra com o outro herói. Se a rede não deixar ver a sala, entra-se pelo IP que o anfitrião vê no Menu. UX 28: o IP à mão
## só aparece depois de LAN_WAIT s sem salas à vista, com o teclado dos números, e o painel sobe ao tocar no campo e fica lá em
## cima (o teclado do telemóvel tapava o campo).
func open_lan() -> void:
	var box := _open_panel("Co-op por Wi-Fi", true, open_duo)
	var pc := panel
	_text(box, "Os dois telemóveis na mesma rede Wi-Fi: quem cria a sala joga com o seu herói; quem entra fica com o outro.")
	lan_note = Label.new()  # A4: o que aconteceu fica também aqui (o aviso sozinho podia passar despercebido)
	lan_note.add_theme_color_override("font_color", Color(1.0, 0.85, 0.5))
	var make := func():
		if Net.host() != OK:
			lan_say("Não deu para abrir a sala. A Wi-Fi está ligada?")
			return
		_play()
		toast(tr("Sala aberta (%s). No outro telemóvel: Jogar a dois.") % Net.my_ip())
	_button(box, "Criar sala", make, null, 460.0).grab_focus()
	var list := VBoxContainer.new()
	box.add_child(list)
	var help := Label.new()
	help.text = "Não aparece? No outro telemóvel toca em Criar sala, ou escreve o IP que ele mostra no Menu."
	help.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	help.custom_minimum_size.x = 460.0
	help.add_theme_color_override("font_color", Color(0.8, 0.8, 0.75))  # a cor das outras linhas (_text): sem ela ficava branca
	box.add_child(help)
	var ip := _field(box, "ou escreve o IP da sala", 460.0)
	ip.virtual_keyboard_type = LineEdit.KEYBOARD_TYPE_NUMBER_DECIMAL
	ip.text_submitted.connect(func(t: String): _join(t.strip_edges()))
	ip.focus_entered.connect(func():  # e fica lá em cima, a crescer para baixo: a descer ao perder o foco saltava debaixo do dedo (carregar no Entrar por IP tira o foco ao campo)
		pc.set_anchors_and_offsets_preset(Control.PRESET_CENTER_TOP, Control.PRESET_MODE_MINSIZE, 8)
		pc.grow_vertical = Control.GROW_DIRECTION_END)
	var manual := [help, ip, _button(box, "Entrar por IP", func(): _join(ip.text.strip_edges()), null, 460.0)]
	for c in manual:
		c.visible = false
	box.add_child(lan_note)
	_button(box, "Voltar", _back, null, 460.0)
	Net.scan()
	lan_since = Time.get_ticks_msec()
	var shown := [null]  # só refaz a lista quando as salas mudam (não rouba o foco ao comando)
	var refresh := func():
		if not Net.rooms.is_empty():
			lan_since = Time.get_ticks_msec()
		elif not manual[0].visible and Time.get_ticks_msec() - lan_since >= LAN_WAIT * 1000.0:
			for c in manual:
				c.visible = true
		var key := str(Net.rooms.keys())
		if key == shown[0]:
			return
		shown[0] = key
		for c in list.get_children():
			c.queue_free()
		if Net.rooms.is_empty():
			_text(list, "À procura de salas na rede…")
		for addr in Net.rooms:
			_button(list, tr("Entrar na sala %s (Nv %d)") % [addr, Net.rooms[addr].level], _join.bind(addr), null, 460.0)
	refresh.call()
	var timer := Timer.new()
	timer.wait_time = 0.5
	timer.autostart = true
	timer.timeout.connect(refresh)
	box.add_child(timer)


## #91: o convidado perdeu o anfitrião sem _bye. O jogo fica parado por baixo e o Net tenta voltar à sala sozinho (o _welcome
## recarrega a cena e este painel sai com ela); Desistir (dois toques) volta ao título.
func open_link_lost() -> void:
	var box := _open_panel("Ligação perdida", false)
	_text(box, "A ligação ao anfitrião caiu. A tentar voltar à mesma sala…")
	var left := Label.new()
	left.add_theme_color_override("font_color", Color(1.0, 0.85, 0.5))
	box.add_child(left)
	var tick := func(): left.text = tr("Faltam %d s.") % ceili(maxf(0.0, Net.retry_end - Time.get_ticks_msec()) / 1000.0)
	tick.call()
	var timer := Timer.new()
	timer.wait_time = 0.5
	timer.autostart = true
	timer.timeout.connect(tick)
	box.add_child(timer)
	_two_tap(_button(box, "Desistir", func(): pass, null, 460.0), "desistir", Net.give_up).grab_focus()


## Caixa de texto escuro com o aro de osso (aceso com o foco); hint aparece enquanto está vazia.
func _field(box: Control, hint: String, width: float) -> LineEdit:
	var ed := LineEdit.new()
	ed.placeholder_text = tr(hint)
	ed.custom_minimum_size = Vector2(width, 44)
	ed.alignment = HORIZONTAL_ALIGNMENT_CENTER
	var caret := func(t: String) -> void:  # vazia, o cursor ficava a piscar a meio da dica (ao meio): só aparece com texto
		ed.add_theme_color_override("caret_color", Color.TRANSPARENT if t == "" else Color(0.95, 0.9, 0.75))
	caret.call("")
	ed.text_changed.connect(caret)
	for st in ["normal", "focus"]:
		var sb := StyleBoxFlat.new()
		sb.bg_color = Color(0.03, 0.04, 0.04, 0.9)
		sb.border_color = Color(0.45, 1.0, 0.65) if st == "focus" else Color(0.5, 0.45, 0.35)
		sb.set_border_width_all(2)
		sb.set_corner_radius_all(4)
		ed.add_theme_stylebox_override(st, sb)
	box.add_child(ed)
	return ed


func _join(addr: String) -> void:
	if not addr.is_valid_ip_address():
		lan_say("Esse IP não parece certo.")
	elif Net.join(addr) != OK:
		lan_say("Não foi possível entrar na sala.")
	else:
		lan_say(tr("A ligar a %s…") % addr)


## A4: o que aconteceu ao entrar numa sala vai para o aviso e para a linha do painel da Wi-Fi. O Net também o chama quando
## a ligação falha ou o anfitrião recusa, já depois do "A ligar a…" (senão a linha ficava a dizê-lo para sempre).
func lan_say(msg: String) -> void:
	toast(msg)
	if is_instance_valid(lan_note):
		lan_note.text = msg


## Do título para o jogo (Continuar, Novo jogo sem nada gravado, Co-op).
func _play() -> void:
	title_open = false
	close_panel()


## Abertura (opening.gd), sempre que o jogo abre; depois segue para then (a intro da 1.ª vez, ou o título).
func open_opening(then: Callable) -> void:
	main.play_track("title")
	title_open = true  # antes do título ainda não há jogo para gravar
	close_panel()
	get_tree().paused = true
	var o := Opening.new()
	o.set_anchors_preset(Control.PRESET_FULL_RECT)
	root.add_child(o)
	panel = o
	panel_cancel = false
	o.finished.connect(func(): then.call_deferred())


## Intro animada (intro.gd): 4 planos com faixas de cinema e legenda. Passa sozinha (cada plano tem a sua
## duração), ou com toque/A; segurar o dedo, B ou Menu salta. Abre-se da 1.ª vez e no Sobre.
func open_intro() -> void:
	main.play_track("title")
	title_open = true  # ao fechar a intro (para o título) não se grava um jogo vazio
	close_panel()
	get_tree().paused = true
	var c := Intro.new()
	c.set_anchors_preset(Control.PRESET_FULL_RECT)
	root.add_child(c)
	panel = c
	panel_cancel = false
	var vs := root.get_viewport_rect().size
	var hint := Control.new()
	hint.set_anchors_preset(Control.PRESET_FULL_RECT)
	hint.mouse_filter = Control.MOUSE_FILTER_IGNORE
	hint.draw.connect(func():
		_prompts(hint, vs - Vector2(28, 26), ["@a", " Seguinte   ", "@b", " Saltar"] if gamepad else ["Toca para continuar · segura para saltar"], 16, 1.0)
		if intro_hold > 0.0:  # a barra enche enquanto o dedo segura
			hint.draw_rect(Rect2(vs.x - 228.0, vs.y - 54.0, 200.0 * minf(intro_hold / HOLD_SKIP, 1.0), 4.0), Color(0.45, 1.0, 0.65)))
	c.add_child(hint)
	intro_hint = hint
	intro_i = -1
	_intro_next()


func _intro_next() -> void:
	intro_i += 1
	if intro_i >= Intro.SHOTS.size():
		_intro_end()
		return
	panel_frame = Engine.get_process_frames()
	intro_t = Intro.SHOTS[intro_i][1]
	panel.play(intro_i)
	intro_hint.queue_redraw()


func _intro_end() -> void:
	intro_i = -1
	intro_hold = -1.0
	main.set_setting("intro_seen", true)
	open_title.call_deferred()  # o toque ou botão que acabou a intro não carrega já num botão do título


## Novo jogo: primeiro o herói; sem jogo gravado começa logo, com jogo gravado pede confirmação (apaga o progresso).
func _new_game() -> void:
	_pick_hero(_new_as, "Novo jogo — escolhe o herói")


## Novo jogo com o herói h (com jogo gravado, só depois de confirmar que se apaga). A1: o Voltar vem primeiro (onde estava o
## cartão do herói) e apagar pede dois toques, que só contam passado meio segundo.
func _new_as(h: String) -> void:
	if not main.has_save():
		_play_as(h)
		return
	var box := _open_panel("Novo jogo", true, open_title)
	_text(box, "Começar de novo apaga o jogo gravado: nível, moedas, arma,\nÁrvore dos Condenados e Frascos de Alma. As configurações ficam.")
	_button(box, "Voltar", open_title).grab_focus()
	var gap := Control.new()
	gap.custom_minimum_size.y = 20
	box.add_child(gap)
	var wipe := _two_tap(_button(box, "Apagar e começar de novo", func(): pass), "apagar tudo", func():
		Engine.set_meta("hero", h)  # só aqui: quem volta atrás não deixa a escolha pendurada
		main.new_game())
	wipe.add_theme_color_override("font_color", Color(1.0, 0.55, 0.5))
	wipe.add_theme_color_override("font_focus_color", Color(1.0, 0.65, 0.6))
	_shield(0.5)


## Escolhe o teu herói (Novo jogo e Mudar de herói): retrato, nome e o que faz; then(id) segue com o escolhido.
func _pick_hero(then: Callable, title := "Escolhe o teu herói") -> void:
	var box := _open_panel(title, true, open_title)
	var heroes: Dictionary = main.player.HEROES
	for h in heroes:
		var b := _button(box, "%s\n%s" % [tr(heroes[h].name), tr(heroes[h].info)], then.bind(h), heroes[h].portrait, 720.0)
		b.add_theme_constant_override("icon_max_width", 96)
		b.custom_minimum_size.y = 104
		b.alignment = HORIZONTAL_ALIGNMENT_LEFT
		if h == main.player.hero:
			b.grab_focus()
	_button(box, "Voltar", open_title, null, 720.0)


## Do título para o jogo com este herói: o mesmo entra já; o outro recomeça a cena com ele (o progresso fica).
func _play_as(h: String) -> void:
	if h == main.player.hero:
		_play()
		return
	Engine.set_meta("hero", h)
	main.restart()


## Menu do jogo (Menu no comando, botão Menu no ecrã ou Voltar do Android): o jogo fica em pausa.
func open_menu(focus := 0, note := "") -> void:
	var box := _open_panel("Menu")
	panel.set_anchors_and_offsets_preset(Control.PRESET_CENTER_TOP)  # Lote 11 C (c): o cimo fixo, mais acima: ao meio chegava às esferas (com a linha da sala Wi-Fi ou a 130%)
	panel.grow_horizontal = Control.GROW_DIRECTION_BOTH
	panel.grow_vertical = Control.GROW_DIRECTION_END
	panel.offset_top = _menu_top()
	var arsenal := func():
		sub_back = open_menu.bind(1)
		gear_who = 0
		open_arsenal()
	var tree := func():
		sub_back = open_menu.bind(2)
		open_tree()
	var guest: bool = Net.is_guest()
	var bestiary := func(): open_bestiary(open_menu.bind(3))
	var relics := func(): open_relics(open_menu.bind(4))
	var bag := func(): open_bag(0, open_menu.bind(6 if guest else 7))  # G6: a Bolsa (#85), no fim da lista: os índices de antes não mudam
	var rel := tr("Relíquias (%d de %d)") % [main.relics.size(), main.RELICS.size()]  # Relíquias de Família (#58)
	var pts: int = main.player.points
	var save := func():
		main.save_game()
		open_menu(5, tr("Jogo gravado às %s.") % Time.get_time_string_from_system().left(5))
	var to_title := func():
		main.save_game()
		main.restart(true)
	var unstuck := func():
		main.unstuck()
		close_panel()
	if guest:
		focus = mini(focus, 6)
	var live: bool = note == "" and Net.linked()
	if live:  # #274: a ligação (com o convidado dentro, o IP da sala já não faz falta)
		note = tr("Ligação: %d ms, %d%% perdido") % [Net.rtt_ms(), roundi(Net.loss() * 100.0)]
	elif Net.role == "host" and note == "":
		note = tr("Sala Wi-Fi aberta: %s") % Net.my_ip()
	# A6: o Voltar ao jogo grande; o resto em 2 colunas com ícones; sair da sala, voltar ao título e Soltar à parte, mais
	# apagados, com dois toques. btns fica pela ordem de sempre (o open_menu.bind(1..6) volta ao mesmo botão)
	var top := HBoxContainer.new()  # Lote 11 C (c): o Gravar ao lado do Voltar ao jogo (sozinho na grelha, deixava uma casa vazia e o Menu chegava às esferas)
	top.add_theme_constant_override("separation", 8)
	box.add_child(top)
	var btns := [_button(top, "Voltar ao jogo", close_panel, null, 560.0 if guest else 276.0)]
	btns[0].custom_minimum_size.y = 60
	var grid := GridContainer.new()
	grid.columns = 2
	grid.add_theme_constant_override("h_separation", 8)
	box.add_child(grid)
	var cells := []
	for it in [["Arsenal", arsenal, ICONS.arsenal], ["Árvore dos Condenados" if pts == 0 else tr("Árvore · %d ponto" if pts == 1 else "Árvore · %d pontos") % pts, tree, ICONS.tree],
			["Bestiário", bestiary, _trim(SKULLS)], [rel, relics, Loot.TEX.relic], ["Bolsa", bag, BAG_ICON],  # SC-ICO9: a bolsa de couro já se lê no botão (o cinto escuro precisava do contorno claro)
			["Configurações", func(): open_settings(0, open_menu.bind(5 if guest else 6)), ICONS.menu]]:
		cells.append(_button(grid, it[0], it[1], it[2], 276.0))
	if not guest:
		cells.append(_button(top, "Gravar", save, Loot.TEX.tomo, 276.0))
		cells[-1].custom_minimum_size.y = 60
	var save_b: Button = null if guest else cells[-1]
	grid.sort_children.connect(func():  # Lote 12 C (g): o Voltar ao jogo por cima da 1.ª coluna e o Gravar da 2.ª (a 130% as colunas alargam)
		btns[0].custom_minimum_size.x = grid.get_child(1).position.x + grid.get_child(1).size.x if guest else grid.get_child(0).size.x
		if save_b != null:
			save_b.custom_minimum_size.x = grid.get_child(1).size.x)
	btns += [cells[0], cells[1], cells[2], cells[3]] + ([cells[5]] if guest else [cells[6], cells[5]]) + [cells[4]]
	var gap := Control.new()
	gap.custom_minimum_size.y = 10
	box.add_child(gap)
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 8)
	box.add_child(row)
	for it in [["Sair da sala", func(): main.restart(true), "sair", 560.0]] if guest else [["Soltar personagem", unstuck, "voltar ao início", 276.0],
			["Menu principal", to_title, "fechar a sala" if Net.role == "host" else "voltar ao título", 276.0]]:
		var b := _two_tap(_button(row, it[0], func(): pass, null, it[3]), it[2], it[1])
		b.add_theme_color_override("font_color", Color(0.7, 0.67, 0.6))
		btns.append(b)
	if note != "":  # revisão do Lote 11: na linha do título, à direita (por baixo de tudo o Menu crescia até 35 px e, em co-op, já não cabia entre o 2.º jogador e as esferas)
		var nl := Label.new()
		nl.text = note
		nl.add_theme_color_override("font_color", Color(0.45, 1.0, 0.65))
		box.get_child(0).add_child(nl)
		nl.set_anchors_and_offsets_preset(Control.PRESET_CENTER_RIGHT)
		nl.grow_horizontal = Control.GROW_DIRECTION_BEGIN
		if live:  # #274: a medida de segundo a segundo (com a rede parada lia-se a de quando o Menu abriu)
			var tick := Timer.new()
			tick.wait_time = 1.0
			tick.autostart = true
			tick.timeout.connect(func(): nl.text = tr("Ligação: %d ms, %d%% perdido") % [Net.rtt_ms(), roundi(Net.loss() * 100.0)])
			box.add_child(tick)
	btns[focus].grab_focus()


## O cimo do Menu: MENU_TOP ou, com o 2.º jogador (ou a linha do 2.º comando) no cimo, 8 px por baixo do retrato, dos estados e da dica dele.
func _menu_top() -> float:
	return maxf(MENU_TOP, overlay.global_position.y + p2_steady.end.y + 8.0) if p2_steady.has_area() else MENU_TOP


## Configurações em separadores. Cada opção aplica-se logo e fica gravada à parte do jogo.
func open_settings(tab := 0, back := Callable()) -> void:
	var box := _open_panel("Configurações", true, back)
	var tabs := HBoxContainer.new()
	tabs.add_theme_constant_override("separation", 6)
	box.add_child(tabs)
	var here: Button
	for i in TABS.size():
		var b := _button(tabs, TABS[i], func(): open_settings(i, back), null, 100.0)
		if i == tab:
			b.add_theme_stylebox_override("normal", _sbt(UI.btn_on, Color.WHITE))
			b.add_theme_color_override("font_color", Color.WHITE)
			here = b
	var rows := VBoxContainer.new()
	rows.add_theme_constant_override("separation", 6)
	rows.custom_minimum_size = Vector2(620, 7 * 52 + 6 * 6)  # A2: a altura do separador mais alto: os separadores não saltam debaixo do dedo
	box.add_child(rows)
	setting_note = Label.new()  # A6: o que faz a opção escolhida (SETTING_INFO), com 2 linhas sempre guardadas
	setting_note.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	setting_note.custom_minimum_size = Vector2(620, Gothic.BODY.get_height(roundi(Gothic.BODY_SIZE * text_k)) * 2)
	setting_note.add_theme_color_override("font_color", Color(0.62, 0.78, 0.68))
	match tab:
		0:
			_slider(rows, "Volume geral", "master")
			_slider(rows, "Música", "music")
			_slider(rows, "Efeitos sonoros", "sfx")
		1:
			_choice(rows, "Limite de FPS", "fps", ["30 · poupa bateria", "60", "O máximo do ecrã"])
			_choice(rows, "Resolução", "res", ["Alta", "Poupança (720p)"])
			_choice(rows, "Efeitos visuais", "effects", ["Baixos", "Médios", "Altos"])
			_choice(rows, "Opacidade dos efeitos", "fx_alpha", ["100%", "70%", "40%"])  # #86: os números de dano e os avisos dos chefes não mudam
			_choice(rows, "Mostrar FPS", "show_fps", ["Não", "Sim"])
			_choice(rows, "Proteção térmica", "thermal", ["Desligada", "Automática"])
			_choice(rows, "Quantidade de monstros", "density", ["Baixa", "Média", "Alta"])
		2:
			_choice(rows, "Idioma", "lang", ["Português", "English"], func(): open_settings(2, back))  # refaz o painel já no idioma novo
			_choice(rows, "Ataque automático", "auto_attack", ["Desligado", "Ligado"])
			_choice(rows, "Mira automática", "boss_aim", ["O mais perto", "Chefes primeiro"])
			_choice(rows, "Números de dano", "numbers", ["Escondidos", "À vista"])
			# Filtro do saque (#76), só neste telemóvel: os frascos, os reagentes e as relíquias mostram sempre tudo
			_choice(rows, "Ossos e esferas", "loot_common", ["Nome, luz e som", "Luz e som", "Só o ícone"])
			_choice(rows, "Tinteiros e Cinzas", "loot_rare", ["Nome, luz e som", "Luz e som", "Só o ícone"])
		3:
			_choice(rows, "Tamanho dos botões", "ui", ["100%", "130%", "160%", "80%"])
			_choice(rows, "Opacidade dos controlos", "opacity", ["100%", "75%", "50%"])  # botões e joystick
			_choice(rows, "Botões de poção", "potion_ui", ["100%", "125%", "150%"])
			_choice(rows, "Botões no ecrã", "lefty", ["À direita", "À esquerda (canhoto)"])
			# Joystick (#271): onde tocas → fixo no canto → fixo onde escolheste (este abre o ecrã de o pôr no sítio)
			var modes := ["Onde tocas", "Fixo no canto", "Fixo onde escolheste…"]
			var mode := func() -> int: return 0 if not main.settings.joy_fixed else 1 if main.settings.joy_at == Vector2.ZERO else 2
			var joy := Button.new()
			joy.custom_minimum_size = Vector2(300, 52)
			joy.text = modes[mode.call()]
			joy.pressed.connect(func():
				if mode.call() == 1:
					open_joy_place(open_settings.bind(3, back))
					return
				main.settings.joy_at = Vector2.ZERO
				main.set_setting("joy_fixed", mode.call() == 0)
				joy.text = modes[mode.call()])
			_row(rows, "Joystick").add_child(joy)
			_choice(rows, "Vibração", "vibe", ["Desligada", "Fraca", "Média", "Forte"])
			# Perfis (#81): mudam várias opções de uma vez e o separador reabre com as escolhas novas (como o Idioma)
			var prof := HBoxContainer.new()
			prof.add_theme_constant_override("separation", 6)
			rows.add_child(prof)
			var pick := func(vals: Dictionary):
				main.settings.merge(vals, true)
				main.apply_settings()
				main.save_settings()
				open_settings(3, back)
			for n in TOUCH_PROFILES:
				var pb := _button(prof, n, pick.bind(TOUCH_PROFILES[n]), null, 149.0)
				if TOUCH_PROFILES[n].keys().all(func(k): return main.settings.get(k) == TOUCH_PROFILES[n][k]):  # A6: o perfil que está posto fica aceso
					pb.add_theme_stylebox_override("normal", _sbt(UI.btn_on, Color.WHITE))
					pb.add_theme_color_override("font_color", Color.WHITE)
		4:
			_choice(rows, "Tremor do ecrã", "shake", ["Desligado", "Ligado"])
			_choice(rows, "Clarão nos críticos", "flash", ["Desligado", "Ligado"])
			_choice(rows, "Daltonismo", "colorblind", ["Desligado", "Protanopia", "Deuteranopia", "Tritanopia"])
			_choice(rows, "Conforto ocular", "comfort", ["Desligado", "Suave", "Forte"])
			_choice(rows, "Minimapa", "minimap", ["Desligado", "Ligado"])
			_choice(rows, "Interface fora de combate", "hud_fade", ["Sempre à vista", "Transparente"])
			_choice(rows, "Tamanho do texto", "text", ["80%", "100%", "115%", "130%"])  # #99
		5:
			_choice(rows, "Zona morta (analógicos e gatilhos)", "deadzone", ["Pequena", "Média", "Grande"])
			# Lote 7 C (c): a legenda do comando no tamanho do resto do painel (a 15 tinha ~10 px), em linhas que cabem nos 620 px a
			# 130% e em inglês: cada botão fica com o que faz, e uma linha muda antes do que já não cabe
			var fs := BODY_PAD
			var groups := [["Comando:"], ["@a", " ", "@x", " ", "@y", " habilidades"], ["@b", " interagir ou esquivar"], ["@lb", " ", "@rb", " poções"],
				["@rt", " ", "@lt", " primeira e segunda habilidade"], ["@ls", " Arsenal"], ["@view", " Árvore"], ["@rs", " Postura"], ["@menu", " menu"]]
			var line := []
			var lines := []
			for gp in groups:
				var both: Array = gp if line.is_empty() else line + ["   "] + gp
				if not line.is_empty() and _prompts(null, Vector2.ZERO, both, fs) > 600.0:
					lines.append(line)
					both = gp
				line = both
			lines.append(line)
			pad_lines = []
			for parts in lines:
				var map := Control.new()
				map.custom_minimum_size = Vector2(620, Gothic.small_px(fs) * 1.45)
				map.set_meta("parts", parts)
				map.draw.connect(func(): _prompts(map, Vector2(0, Gothic.small_px(fs) * 1.1), parts, fs))  # C (b): o 1.ª e 2.ª por extenso (na Augusta pequena o º e o ª borravam)
				rows.add_child(map)
				pad_lines.append(map)
	box.add_child(setting_note)
	var reset := func():
		main.reset_settings()
		open_settings(tab, back)
	var end := HBoxContainer.new()  # A2: Repor tudo (dois toques) e Voltar lado a lado
	end.add_theme_constant_override("separation", 6)
	box.add_child(end)
	_two_tap(_button(end, "Repor tudo", func(): pass, null, 260.0), "repor tudo", reset)
	_close_button(end, 360.0)
	here.grab_focus()


## Joystick fixo onde escolheste (#271): arrasta-o com o dedo (ou o rato) para onde o polegar o acha sem olhar; Feito
## grava o sítio (fração da margem segura, espelhada no canhoto) e No canto volta ao canto. B / Voltar não muda nada.
func open_joy_place(back: Callable) -> void:
	close_panel()
	get_tree().paused = true
	var c := Control.new()
	c.set_anchors_preset(Control.PRESET_FULL_RECT)
	root.add_child(c)
	panel = c
	panel_cancel = true
	panel_back = back
	panel_frame = Engine.get_process_frames()
	var at := [_joy_home()]  # num Array: as funções partilham-no
	c.draw.connect(func():
		c.draw_rect(Rect2(Vector2.ZERO, c.size), Color(0, 0, 0, 0.35))
		_joy_draw(c, at[0], 1.0)
		c.draw_arc(at[0], JOY_R * SCALES[ui_scale_i] + 6.0, 0, TAU, 48, Color(0.45, 1.0, 0.65, 0.8), 3.0))
	c.gui_input.connect(func(e: InputEvent):  # no PC o rato também chega como toque
		if (e is InputEventScreenTouch and e.pressed) or e is InputEventScreenDrag:
			at[0] = _joy_clamp(e.position)
			c.queue_redraw())
	var box := VBoxContainer.new()
	box.add_theme_constant_override("separation", 10)
	box.set_anchors_and_offsets_preset(Control.PRESET_CENTER_TOP)
	box.offset_top = 70
	box.grow_horizontal = Control.GROW_DIRECTION_BOTH
	c.add_child(box)
	_text(box, "Arrasta o joystick para onde o queres.", Color(0.95, 0.85, 0.6))
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 10)
	box.add_child(row)
	var done := func():
		var sr := safe.get_global_rect()
		var f: Vector2 = (at[0] - sr.position) / sr.size
		main.settings.joy_at = Vector2(1.0 - f.x if lefty else f.x, f.y)
		main.set_setting("joy_fixed", true)
		back.call()
	var corner := func():
		main.settings.joy_at = Vector2.ZERO
		main.set_setting("joy_fixed", true)
		back.call()
	_button(row, "Feito", done, null, 220.0).grab_focus()
	_button(row, "No canto", corner, null, 220.0)


## Linha de uma opção: o nome à esquerda, o controlo à direita.
func _row(box: Control, label: String) -> HBoxContainer:
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 16)
	var l := Label.new()
	l.text = label
	l.custom_minimum_size = Vector2(250.0 * maxf(text_k, 1.0), 42)  # com o texto maior (#99) os controlos continuam alinhados
	l.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	l.add_theme_color_override("font_color", Color(0.88, 0.84, 0.72))
	row.add_child(l)
	box.add_child(row)
	return row


## Escolha: cada toque (ou A) passa à seguinte. after = o que fazer depois de mudar.
## A6: ‹ › nas pontas e uma pinta por valor (a de agora dourada) dizem que o toque passa ao seguinte; Ligado a verde e
## Desligado a cinzento; a explicação da opção (SETTING_INFO) aparece por baixo das linhas.
func _choice(box: Control, label: String, key: String, names: Array, after := Callable()) -> void:
	var b := Button.new()
	b.custom_minimum_size = Vector2(300, 52)
	var paint := func():
		var n: String = names[int(main.settings[key])]
		b.text = n
		var col := Color(0.45, 1.0, 0.5) if n in ON_WORDS else Color(0.6, 0.6, 0.55) if n in OFF_WORDS else Color(0.93, 0.89, 0.76)
		for st in ["font_color", "font_focus_color", "font_hover_color"]:
			b.add_theme_color_override(st, col)
		b.queue_redraw()
	paint.call()
	var say := func():
		if is_instance_valid(setting_note):
			setting_note.text = tr(SETTING_INFO.get(key, ""))
	b.pressed.connect(func():
		var v := (int(main.settings[key]) + 1) % names.size()
		main.set_setting(key, v == 1 if main.settings[key] is bool else v)
		paint.call()
		say.call()
		if after.is_valid():
			after.call())
	b.focus_entered.connect(say)
	b.draw.connect(func():
		var mid := b.size.y / 2.0 - 3.0
		var gold := Color(1.0, 0.85, 0.4)
		for d in [-1, 1]:
			var x: float = 14.0 if d < 0 else b.size.x - 14.0
			b.draw_colored_polygon(PackedVector2Array([Vector2(x, mid), Vector2(x - 8.0 * d, mid - 6.0), Vector2(x - 8.0 * d, mid + 6.0)]), Color(gold, 0.7))
		var v := int(main.settings[key])
		var x0 := b.size.x / 2.0 - (names.size() * 9.0 - 4.0) / 2.0
		for i in names.size():
			b.draw_rect(Rect2(x0 + i * 9.0, b.size.y - 11.0, 5.0, 5.0), gold if i == v else Color(0.45, 0.42, 0.36)))
	_row(box, label).add_child(b)


## Volume de 0 a 100% (com o foco, a cruz ou o stick mexem-no).
func _slider(box: Control, label: String, key: String) -> void:
	var row := _row(box, label)
	var s := HSlider.new()
	s.min_value = 0.0
	s.max_value = 100.0
	s.step = 10.0
	s.value = float(main.settings[key]) * 100.0
	s.custom_minimum_size = Vector2(240, 42)
	var val := Label.new()
	val.text = "%d%%" % s.value
	val.custom_minimum_size = Vector2(56, 42)
	val.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	s.value_changed.connect(func(v: float):
		main.set_setting(key, v / 100.0)
		val.text = "%d%%" % v)
	row.add_child(s)
	row.add_child(val)


## Sobre: o jogo, a versão, quem o fez e as licenças (o Godot e a letra pedem que se mostrem).
func open_about(back := Callable()) -> void:
	var box := _open_panel("Sobre", true, back)
	var top := HBoxContainer.new()
	top.add_theme_constant_override("separation", 20)
	var logo := _art(STUDIO_LOGO, Vector2(150, 150))
	logo.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	top.add_child(logo)
	var info := VBoxContainer.new()
	top.add_child(info)
	box.add_child(top)
	var head := Control.new()
	head.custom_minimum_size = Vector2(560, 48)
	head.draw.connect(func(): Gothic.draw(head, Vector2(0, 38), "Soulstrider: Necro-Dominion", 40, Color(0.88, 0.97, 0.88), 6))
	info.add_child(head)
	_text(info, tr("Versão %s") % AppUpdate.VERSION_NAME, Color(0.45, 1.0, 0.65))
	_text(info, "Um ARPG gótico para telemóvel: almas, ossos e o Cortejo Fúnebre.\nJoga-se no ecrã ou com comando, sozinho ou a dois.")
	_text(info, "Um jogo Pixel Lusitano · desenvolvido por AlizeOnMe", Color(1.0, 0.8, 0.4))
	_text(box, "Feito com o Godot Engine. Letra Alkhemikal, de jeti (CC BY 4.0).", Color(0.65, 0.65, 0.6))
	_text(box, "Letra Augusta, de Typographer Mediengestaltung e Dieter Steffmann.", Color(0.65, 0.65, 0.6))
	_text(box, "Efeitos visuais: Sprite Fusion (MIT).", Color(0.65, 0.65, 0.6))
	_button(box, "Site: pixellusitano.com", func(): OS.shell_open("https://pixellusitano.com"))
	_button(box, "Contacto: contact@pixellusitano.com", func(): OS.shell_open("mailto:contact@pixellusitano.com"))
	_button(box, "Página do jogo e versões", func(): OS.shell_open("https://github.com/DaewonPT/Soulstrider/releases"))
	_button(box, "Ver a introdução", open_intro)
	_button(box, "Licenças", func(): _licenses(open_about.bind(back)))
	_close_button(box).grab_focus()


## Licenças: a do Godot e dos componentes que traz, as das letras Alkhemikal, Augusta e Pirata One e a dos efeitos (o stick faz rolar).
func _licenses(back: Callable) -> void:
	var box := _open_panel("Licenças", true, back)
	var text := "Godot Engine\n" + Engine.get_license_text() + "\n\n" + tr("Componentes incluídos no Godot:")
	for c in Engine.get_copyright_info():
		for part in c.parts:
			text += "\n• %s: %s (%s)" % [c.name, ", ".join(part.copyright), part.license]
	text += "\n\nAlkhemikal\n" + FileAccess.get_file_as_string("res://fonts/Alkhemikal-LICENSE.txt")
	text += "\n\n" + FileAccess.get_file_as_string("res://fonts/Augusta-LICENCA.txt")
	text += "\n\nPirata One\n" + FileAccess.get_file_as_string("res://fonts/PirataOne-OFL.txt")
	text += "\n\n" + FileAccess.get_file_as_string("res://LICENCAS.txt")  # Sprite Fusion Pixel Art VFX e pixelfx (MIT)
	var sc := ScrollContainer.new()
	sc.custom_minimum_size = Vector2(680, 400)
	sc.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	var l := Label.new()
	l.text = text
	l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	l.custom_minimum_size.x = 660
	l.add_theme_color_override("font_color", Color(0.75, 0.75, 0.7))
	sc.add_child(l)
	box.add_child(sc)
	license_scroll = sc
	_button(box, "Voltar", _back).grab_focus()


## Há um APK novo no GitHub (AppUpdate): botão dourado por cima do Jogar, no ecrã de título.
func _on_update(info: Dictionary) -> void:
	if not is_instance_valid(title_menu) or title_menu.has_node("Update"):
		return
	if not title_menu.visible:
		title_reveal.call()  # há versão nova: o menu aparece logo, para o botão de atualizar se ver
	var b := _button(title_menu, tr("Nova versão %s — atualizar") % String(info.get("name", "")).trim_prefix("Soulstrider "), open_update.bind(info), null, 400.0)
	b.name = "Update"
	b.add_theme_font_size_override("font_size", 24)  # na Augusta do tema: o número da versão lê-se melhor que na gótica
	b.custom_minimum_size.y = 52
	b.add_theme_color_override("font_color", Color(1.0, 0.84, 0.4))
	b.add_theme_color_override("font_focus_color", Color(1.0, 0.9, 0.55))
	title_menu.move_child(b, 0)


## A versão nova: o que traz (as notas da Release, uma linha por entrada numa lista que rola) e o Atualizar, que abre o APK
## no navegador. Voltar volta ao título (com o botão dourado outra vez).
func open_update(info: Dictionary) -> void:
	var box := _open_panel(tr("Nova versão %s") % String(info.get("name", "")).trim_prefix("Soulstrider "), true, open_title)
	var w: float = 700.0 * maxf(text_k, 1.0)
	var list := _scroll_list(box, w, 400.0)
	var notes := String(info.get("notes", "")).split("\n")
	for line in notes.slice(1 if notes[0].begins_with("Soulstrider") else 0):  # revisão final: a 1.ª linha das notas ("Soulstrider 0.5.0") já é o título do painel
		var l := Label.new()
		l.text = line
		l.auto_translate_mode = Node.AUTO_TRANSLATE_MODE_DISABLED  # as notas vêm escritas em português, tal como estão
		l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		l.custom_minimum_size.x = w
		l.add_theme_color_override("font_color", Color(1.0, 0.85, 0.4) if line.ends_with(":") else Color(0.8, 0.8, 0.75))  # Novo:, Melhorado: e Corrigido: a dourado
		list.add_child(l)
	_button(box, "Atualizar", func():
		updater.open_download()
		open_title()  # revisão final: o aviso no título, como na 0.4.9 (com o painel aberto não tinha lugar e o Voltar apagava-o)
		toast(tr("A descarregar %s: quando acabar, abre o ficheiro para instalar.") % AppUpdate.file_name_of(String(info.get("apk", "")))), null, w).grab_focus()
	_button(box, "Voltar", open_title, null, w)


## Arsenal — Frascos de Alma (G1: o 1.º separador): a grelha das habilidades e da Alma Condensada de cada herói. A foice e
## o Equipamento têm os separadores deles. note (B7): o que acabou de mudar ("Lança de Almas: Alma Veloz"), a verde, e o botão
## de onde veio acende.
func open_arsenal(focus := 0, note := "") -> void:
	flasks_seen = main.flasks.size()  # B5: os frascos novos já se viram
	var box := _open_panel("Frascos de Alma", true, sub_back)
	_hub_tabs(box, 0)
	# O que faz o frasco da habilidade escolhida (muda com o foco do comando ou ao tocar)
	var desc := Label.new()
	desc.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	desc.custom_minimum_size = Vector2(600, 44)
	desc.add_theme_color_override("font_color", Color(0.62, 0.78, 0.68))
	desc.text = _found(false)
	var buttons := []
	# Em co-op, uma coluna por jogador para o painel caber no ecrã, com o nome do herói por cima, na cor dele
	var grid := GridContainer.new()
	grid.columns = main.players.size()
	grid.add_theme_constant_override("h_separation", 8)
	box.add_child(grid)
	if main.players.size() > 1:
		for p in main.players:
			var who := Label.new()
			who.text = tr(p.hero_name)
			who.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
			who.add_theme_color_override("font_color", p.tint)
			grid.add_child(who)
	var w: float = (hub_w() - 8.0 * (main.players.size() - 1)) / main.players.size()
	for i in 4:  # as 3 habilidades e, na 4.ª linha, a Alma Condensada (veste-a o herói, não uma habilidade)
		for p in main.players:
			var id: String = p.order[i] if i < 3 else ""
			var f: String = p.skills[id].support if i < 3 else p.soul
			var idx := buttons.size()
			var held: bool = i < 3 and id == p.cursed_lock()  # Frascos Malditos (#21): o engaste preso não abre a grelha
			var b := _button(grid, tr("%s — Preso pelo Frasco Maldito") % tr(p.skills[id].name) if held else "%s — %s" % [tr(p.skills[id].name if i < 3 else "Alma Condensada"), tr(p.SUPPORT_NAMES[f])], open_picker.bind(p, id, idx), ICONS[f], w)
			b.disabled = held
			b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
			b.clip_text = true  # em co-op um nome comprido encolhe a letra e não alarga a coluna: o Arsenal fica da largura dos outros separadores
			b.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
			_fit_text(b)
			var info: String = _found(true) if i == 3 and f == "" else "%s: %s" % [tr(p.SUPPORT_NAMES[f]), tr(p.SUPPORT_DESC[f])]
			b.focus_entered.connect(func(): desc.text = info)
			buttons.append(b)
	box.add_child(desc)
	var fi := buttons.size()
	var row := HBoxContainer.new()  # Fórmulas e Fechar lado a lado
	box.add_child(row)
	for b in [_button(row, "Fórmulas", func(): open_formulas(open_arsenal.bind(fi)), null, 276.0), _close_button(row, 276.0)]:
		b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		buttons.append(b)
	for b in buttons:  # a nota a verde só até o foco mudar
		b.focus_entered.connect(func(): desc.add_theme_color_override("font_color", Color(0.62, 0.78, 0.68)))
	buttons[clampi(focus, 0, buttons.size() - 1)].grab_focus()
	if focus <= 0:  # depois do grab_focus: a descrição do 1.º frasco tapava logo a conta dos frascos
		desc.text = _found(false)
	if note != "":
		desc.text = note
		desc.add_theme_color_override("font_color", Color(0.45, 1.0, 0.65))
		_pop(buttons[clampi(focus, 0, buttons.size() - 1)])


## B7: o botão que acabou de mudar acende e volta ao normal em 0,35 s.
func _pop(c: CanvasItem) -> void:
	var was := c.modulate  # volta à cor que tinha (o quadrado escolhido do Equipamento fica aceso)
	c.modulate = Color(1.8, 1.6, 1.0)
	c.create_tween().tween_property(c, "modulate", was, 0.35)


## Grelha com os frascos que o grupo já encontrou, para a habilidade id (ou, com id "", para a Alma Condensada do
## herói). O posto vem aceso e com o foco. O 1.º toque (ou A) num frasco mostra o que faz e marca-o; o 2.º no mesmo
## põe-no e volta ao Arsenal (para ler antes de escolher, e sem escolher por engano). B (ou Voltar) não muda nada.
func open_picker(p, id: String, back: int) -> void:
	var box := _open_panel(p.skills[id].name if id != "" else "%s — %s" % [tr("Alma Condensada"), tr(p.hero_name)], true, open_arsenal.bind(back))
	var grid := GridContainer.new()
	grid.columns = 3
	grid.add_theme_constant_override("h_separation", 8)
	box.add_child(grid)
	var desc := RichTextLabel.new()  # com cores: o comparador (#267) pinta o que melhora e o que piora
	desc.bbcode_enabled = true
	desc.fit_content = false  # A2: altura fixa de 4 linhas, como a do Equipamento: a grelha não sobe entre o 1.º e o 2.º toque
	desc.scroll_active = false
	desc.custom_minimum_size = Vector2(600.0 * text_k, Gothic.BODY.get_height(roundi(Gothic.BODY_SIZE * text_k)) * 4)
	desc.add_theme_color_override("default_color", Color(0.62, 0.78, 0.68))
	box.add_child(desc)
	var now: String = p.skills[id].support if id != "" else p.soul
	var on := 0  # o botão do frasco posto (ou o Nenhum, o primeiro)
	var list: Array = (p.SUPPORTS if id != "" else p.SOULS).filter(func(k): return k in main.flasks and not (k in p.CURSED and id == p.order[0]))  # os Malditos (#21) não vão no golpe básico
	grid.columns = 4 if list.size() > 18 else 3  # C (a): com 19 frascos ou mais, 3 colunas davam 8 filas e o painel passava dos 720 px (o smoke falhava quando o acaso dava frascos a mais)
	for i in list.size():
		var f: String = list[i]
		var info: String = _found(true) if id == "" and f == "" else "%s: %s" % [tr(p.SUPPORT_NAMES[f]), tr(p.SUPPORT_DESC[f])]
		var b := _button(grid, p.SUPPORT_NAMES[f], func():  # cada toque mostra o que faz; o botão diz "Outra vez: escolher" (H1)
			desc.text = "\n".join([info, _compare(p, id, f) if id != "" else "", tr("Na Provação das Almas não se põe nenhum frasco até ao fim do Cortejo.") if main.trial_on("almas") else ""].filter(func(s): return s != ""))
			for c in grid.get_children():
				c.set_pressed_no_signal(c.toggle_mode), ICONS[f], 200.0)  # o toque não apaga o posto (só ele é toggle)
		_two_tap(b, "escolher", func():
			var said: String = tr("%s: %s") % [tr(p.skills[id].name if id != "" else "Alma Condensada"), tr(p.SUPPORT_NAMES[f])]  # B7
			if id != "":
				_act(p, "set_support", [id, f], func(_r): open_arsenal(back, said if p.skills[id].support == f else ""))  # na Provação das Almas não se põe
			else:
				_act(p, "set_soul", [f], func(_r): open_arsenal(back, said if p.soul == f else "")))
		b.focus_entered.connect(func(): desc.text = info)
		if f == now:
			b.toggle_mode = true  # o posto fica aceso
			b.button_pressed = true
			on = b.get_index()
	_close_button(box)
	grid.get_child(on).grab_focus()


## Comparador de Frascos (#267): o que o frasco f muda na habilidade id (dano, área e recarga, de agora → com ele), a
## verde o que melhora e a vermelho o que piora. Vazio se não mexe em nenhum (Eco, Tumular...). Experimenta-o no
## herói e volta a pôr o que lá estava: no convidado também, com os valores que vêm do anfitrião.
func _compare(p, id: String, f: String) -> String:
	var was: String = p.skills[id].support
	var a: Array = p.skill_numbers(id)
	p.skills[id].support = f
	var b: Array = p.skill_numbers(id)
	p.skills[id].support = was
	var parts := []
	for k in [["Dano", 0, 0], ["Área", 1, 0], ["Recarga", 2, 2]]:
		var from := _dec(a[k[1]], k[2])
		var to := _dec(b[k[1]], k[2])
		if from == to or (k[1] == 1 and id == "bolt"):  # os 16 px da Lança são o raio do golpe, não uma área
			continue
		var better: bool = (b[k[1]] < a[k[1]]) == (k[1] == 2)  # na recarga, menos é melhor
		parts.append("%s %s → [color=#%s]%s[/color]%s" % [tr(k[0]), from, (Color(0.45, 1.0, 0.5) if better else Color(1.0, 0.4, 0.35)).to_html(false), to, " s" if k[1] == 2 else ""])
	return " · ".join(parts)


## Quantos Frascos de Alma (ou, com souls, Almas Condensadas) o grupo já encontrou; o Nenhum não conta.
func _found(souls: bool) -> String:
	var list: Array = main.player.SOULS if souls else main.player.SUPPORTS
	var n: int = list.filter(func(f): return f in main.flasks).size() - 1
	return tr("Almas Condensadas encontradas: %d de %d. Os chefes deixam as que faltam." if souls else "Frascos de Alma encontrados: %d de %d. Os chefes deixam os que faltam.") % [n, list.size() - 1]


## Equipamento (G1): os lugares do herói em cima e a mochila por baixo, em quadrados com o ícone da peça, uma barra na cor da
## raridade (os únicos num quadrado cor de brasa) e, em píxeis por cima, o veredicto contra a posta (_gear_verdict: um triângulo
## verde para cima se só ganha, vermelho para baixo se só perde, os dois se ganha e perde), um cadeado nas trancadas (#78) e uma
## cruz vermelha nas marcadas (#280). A cor das letras já não quer dizer nada. À direita a descrição, da altura dos quadrados (o
## painel não mexe entre o 1.º e o 2.º toque), e por baixo as ações em três colunas. O 1.º toque (ou A) num quadrado mostra a peça e compara-a; o 2.º no
## mesmo põe-na, como o Pôr. Segurar 0,6 s tranca ou destranca. Tocar num lugar deixa à vista só as peças desse lugar (#273). Abre
## na ficha do herói, e a Ficha volta a ela. Na Wi-Fi cada telemóvel só mexe no seu herói (mine).
## who: o índice em main.players, como na Árvore; back: para onde B / Voltar levam (o Menu ou o jogo); note: o que acabou de mudar.
func open_gear(who: int, back: Callable, focus := -1, note := "", pick := "") -> void:
	var again: bool = panel != null and panel.has_meta("gear") and gear_who == mini(who, main.players.size() - 1)  # refeito depois de um toque, e não aberto de fresco
	gear_who = mini(who, main.players.size() - 1)
	var p = main.players[gear_who]  # o convidado pode ter saído com o painel aberto
	if not again:  # aberto de fresco: sem filtro
		gear_slot = ""
	if not again or p.bag != gear_bag:  # nem marcas; e a mochila que mudou (um lote, ou a do convidado que chegou do anfitrião) também as apaga
		gear_marking = false
		gear_marked.clear()
	gear_bag = p.bag.duplicate()
	var box := _open_panel(p.hero_name, true, back)  # o separador aceso já diz Equipamento; com ele no título, o do Cavaleiro não cabia ao lado dos separadores
	panel.set_meta("gear", true)
	_hub_tabs(box, 2)
	var line_h: float = Gothic.BODY.get_height(roundi(Gothic.BODY_SIZE * text_k))
	var said := Label.new()  # o que acabou de mudar, a verde; vazia também ocupa a linha
	said.text = note
	said.custom_minimum_size.y = line_h
	said.add_theme_color_override("font_color", Color(0.45, 1.0, 0.65))
	box.add_child(said)
	var cols := HBoxContainer.new()  # os quadrados à esquerda, a descrição à direita, da altura deles (o painel não mexe entre o 1.º e o 2.º toque)
	cols.add_theme_constant_override("separation", 16)
	box.add_child(cols)
	var left := VBoxContainer.new()
	left.add_theme_constant_override("separation", 6)
	cols.add_child(left)
	var right := VBoxContainer.new()  # G4: a descrição e, por baixo dela, o Forjar da peça escolhida (as 3 filas de ações já enchem os 720 px a 130%)
	right.add_theme_constant_override("separation", 6)
	cols.add_child(right)
	var desc := RichTextLabel.new()  # com cores, como no comparador dos frascos (#267)
	desc.bbcode_enabled = true
	desc.fit_content = false
	desc.scroll_active = false
	desc.custom_minimum_size.x = _gear_desc_w()
	desc.size_flags_vertical = Control.SIZE_EXPAND_FILL
	desc.add_theme_color_override("default_color", Color(0.62, 0.78, 0.68))
	right.add_child(desc)
	var mine: bool = tree_buys(p) and not (Net.guest_ready and p.slot == 1)  # na Wi-Fi cada um mexe só nas suas (tree_buys dá sempre true no anfitrião); no co-op local, os dois
	var sheet := _hero_sheet(p)  # feita já: o convidado pode sair com o painel aberto e o p deixar de existir
	var sel := ["", -1, ""]  # o quadrado escolhido: [worn | bag, o índice em SLOTS ou na mochila, a peça]
	var dragged := [false]  # o dedo andou de quadrado em quadrado (#280): o toque que acaba ali não marca outra vez
	var btns := []
	gear_tiles = []
	var hold_hint := tr("Carrega outra vez para pôr." if gamepad else "Toca outra vez para pôr.")
	var marked_hint := tr("Marcadas: %d. Carrega numa peça para a marcar ou a tirar. As trancadas e as únicas não se marcam." if gamepad else "Marcadas: %d. Arrasta o dedo pelas peças para as marcar; um toque marca ou tira uma. As trancadas e as únicas não se marcam.")
	var bag_it := {}  # índice -> a peça, como estava ao abrir (no convidado a mochila pode mudar entretanto: o anfitrião confere)
	for i in p.bag.size():
		bag_it[i] = p.bag[i]
	var lockable := func(i: int) -> bool: return bag_it.has(i) and not bag_it[i] in p.locks and p.gear_rarity(bag_it[i]) < 3
	# a mochila pela ordem escolhida (#273: só o que se vê; os toques usam o índice verdadeiro)
	var sort: int = main.settings.bag_sort
	var vds := {}
	for i in p.bag.size():
		vds[i] = _verdict_word(_gear_verdict(p, p.bag[i]))
	var rank := func(i: int) -> int:
		var r: int = 3 - p.gear_rarity(p.bag[i])
		var s: int = p.SLOTS.find(p.gear_slot(p.bag[i]))
		return ((s * 4 + r) if sort == 0 else (r * 8 + s) if sort == 1 else (VERDICT_RANK.find(vds[i]) * 4 + r)) * 100 + i
	var order: Array = range(p.bag.size())
	order.sort_custom(func(a, b): return rank.call(a) < rank.call(b))
	# as ações, criadas antes dos quadrados (os quadrados mudam-nas); entram no painel depois deles
	var acts := GridContainer.new()  # por baixo, em 3 colunas a toda a largura
	acts.columns = 3
	acts.add_theme_constant_override("h_separation", 8)
	acts.add_theme_constant_override("v_separation", 6)
	var aw: float = (hub_w() - 16.0) / 3.0
	var act_btns := []
	var legend := Label.new()
	var paint := func() -> void:  # o que se vê depende da escolha, do filtro e das marcas
		var full: bool = p.bag.size() >= p.bag_cap()
		legend.text = tr("Mochila (%d de %d) · cheia" if full else "Mochila (%d de %d)") % [p.bag.size(), p.bag_cap()]
		legend.add_theme_color_override("font_color", Color(1.0, 0.6, 0.25) if full else Color(0.8, 0.8, 0.75))
		for t in gear_tiles:
			var a: float = 0.4 if t.i >= 0 and gear_slot != "" and p.gear_slot(t.it) != gear_slot else 1.0
			t.b.modulate = Color(1.3, 1.2, 0.8, a) if sel[1] == (t.i if t.i >= 0 else p.SLOTS.find(t.s)) and sel[0] == ("bag" if t.i >= 0 else "worn") else Color(1, 1, 1, a)
			t.b.queue_redraw()
		if act_btns.is_empty():
			return
		var it: String = sel[2]
		act_btns[0].disabled = not mine or sel[0] != "bag"
		act_btns[1].disabled = not mine or it == ""
		act_btns[1].text = tr("Destrancar" if it in p.locks else "Trancar")
		var bones := 0
		for i in gear_marked:
			bones += p.SCRAP[p.gear_rarity(bag_it[i])]
		_set_idle(act_btns[2], tr("Desfazer (+%d Ossos)") % bones if gear_marking else tr("Desfazer"))  # curto: "Desfazer marcadas (…)" não cabia na casa, nem com a letra a 12
		act_btns[2].disabled = not mine or (gear_marked.is_empty() if gear_marking else sel[0] != "bag" or it in p.locks)
		if act_btns.size() > 3:  # G4: o Forjar (os únicos não se forjam)
			act_btns[3].disabled = not mine or gear_marking or it == "" or p.gear_rarity(it) == 3
	var mark := func(i: int, on: bool) -> void:
		if not lockable.call(i) or (i in gear_marked) == on:
			return
		if on:
			gear_marked.append(i)
		else:
			gear_marked.erase(i)
		desc.text = marked_hint % gear_marked.size()
		paint.call()
	var show := func(kind: String, i: int, it: String) -> void:  # o 1.º toque: mostra e escolhe
		_disarm(act_btns[2])  # o Desfazer volta a pedir os dois toques para a peça nova
		sel[0] = kind
		sel[1] = i
		sel[2] = it
		var lines := [_gear_text(p, it) if it != "" else tr("Nada posto. A primeira peça que apanhares para aqui põe-se sozinha.")]
		if kind == "bag":
			lines.append(_gear_compare(p, it))
		if it in p.locks:
			lines.append(tr("Trancada: não se desfaz nem sai com a mochila cheia."))
		if kind == "worn":
			lines.append(tr("Na mochila, só as peças deste lugar (carrega outra vez para ver todas)." if gamepad else "Na mochila, só as peças deste lugar (toca outra vez para ver todas).") if gear_slot != "" else tr("Na mochila, todas as peças."))
		elif not mine:
			lines.append(tr("Só o %s mexe nas peças dele.") % tr(p.hero_name))
		else:
			lines.append(hold_hint)
		desc.text = "\n".join(lines)
		paint.call()
	var lock := func(it: String, at: int) -> void:  # segurar 0,6 s, ou o Trancar
		if not is_instance_valid(p):
			_back()
			return
		var was: bool = it in p.locks
		_act(p, "lock_gear", [it], func(_ok):  # recusado por outra razão (a peça já saiu da mochila, no convidado), sem nota: o painel refeito mostra a mochila de agora
			if panel != null:
				open_gear(who, back, at, tr("Destrancada: %s") % p.gear_name(it) if was else tr("Trancada: %s") % p.gear_name(it) if it in p.locks else tr("No máximo %d peças trancadas.") % p.LOCKS_MAX if p.locks.size() >= p.LOCKS_MAX else ""))
	var put := func(i: int, it: String) -> void:
		if not is_instance_valid(p):  # o convidado saiu com este painel aberto no anfitrião (drop_player)
			_back()
			return
		var s: String = p.gear_slot(it)
		_act(p, "equip_gear", [i, it], func(ok): open_gear(who, back, p.SLOTS.find(s), tr("%s: %s") % [tr(p.SLOT_NAMES[s]), p.gear_name(it)] if ok else ""))
	# os quadrados: os lugares em cima, a mochila por baixo
	var worn := HBoxContainer.new()
	worn.add_theme_constant_override("separation", 6)
	left.add_child(worn)
	for si in p.SLOTS.size():
		var s: String = p.SLOTS[si]
		var it: String = p.gear.get(s, "")
		var b := _gear_tile(worn, it, s)
		b.pressed.connect(func():
			if b.has_meta("held"):
				return
			gear_slot = "" if gear_slot == s else s  # #273: o 2.º toque no mesmo lugar volta a mostrar tudo
			show.call("worn", si, it))
		b.focus_entered.connect(func():
			_disarm(act_btns[2])
			desc.text = _gear_text(p, it) if it != "" else tr("Nada posto. A primeira peça que apanhares para aqui põe-se sozinha."))
		if it != "":
			_hold_lock(b, func(): return mine and not gear_marking, lock.bind(it, btns.size()))
		gear_tiles.append({"b": b, "i": -1, "s": s, "it": it, "v": ""})
		btns.append(b)
	left.add_child(legend)
	var grid := GridContainer.new()
	grid.columns = BAG_COLS
	grid.add_theme_constant_override("h_separation", 6)
	grid.add_theme_constant_override("v_separation", 6)
	grid.custom_minimum_size.y = 4 * TILE + 3 * 6.0  # a altura das 20: o painel não muda com a mochila
	left.add_child(grid)
	for i in order:
		var it: String = p.bag[i]
		var b := _gear_tile(grid, it, "")
		var at: int = btns.size()
		b.pressed.connect(func():
			if b.has_meta("held"):  # acabou de trancar ao segurar: largar não escolhe
				return
			if gear_marking:
				if not dragged[0]:
					mark.call(i, not i in gear_marked)
				return
			if not is_instance_valid(p):
				_back()
				return
			if sel[0] == "bag" and sel[1] == i and mine:
				put.call(i, it)
			else:
				show.call("bag", i, it))
		b.button_down.connect(func(): dragged[0] = false)  # cada toque começa sem arrasto: o que arrastou largou noutro quadrado e o pressed do 1.º não chegou
		b.focus_entered.connect(func():
			_disarm(act_btns[2])  # com o comando o foco anda de peça em peça sem tocar
			desc.text = _gear_text(p, it))
		_hold_lock(b, func(): return mine and not gear_marking, lock.bind(it, at))
		b.gui_input.connect(func(e: InputEvent):  # #280: arrastar o dedo marca cada peça por onde passa (o Godot deixa o toque no 1.º quadrado)
			if not gear_marking or not (e is InputEventScreenDrag or (e is InputEventMouseMotion and e.button_mask & MOUSE_BUTTON_MASK_LEFT)):
				return
			var g: Vector2 = b.get_global_transform() * e.position
			for t in gear_tiles:
				if t.i >= 0 and t.i != i and t.b.get_global_rect().has_point(g):
					dragged[0] = true
					mark.call(i, true)
					mark.call(t.i, true))
		gear_tiles.append({"b": b, "i": i, "s": p.gear_slot(it), "it": it, "v": vds[i]})
		btns.append(b)
	for k in range(p.bag.size(), BAG_TOP):  # os lugares vazios da mochila; os que as Bolsas (#72) ainda não abriram, mais apagados
		var hole := Panel.new()
		hole.custom_minimum_size = Vector2(TILE, TILE)
		hole.add_theme_stylebox_override("panel", _tile_box(Color.WHITE))
		hole.modulate.a = 0.55 if k < p.bag_cap() else 0.18
		hole.mouse_filter = Control.MOUSE_FILTER_IGNORE
		grid.add_child(hole)
	box.add_child(acts)
	var acts_at := btns.size()
	act_btns.append(_button(acts, "Pôr", func():
		if sel[0] == "bag":
			put.call(sel[1], sel[2]), null, aw))
	act_btns.append(_button(acts, "Trancar", func():
		if sel[2] != "":
			lock.call(sel[2], btns.find(gear_tiles.filter(func(t): return t.it == sel[2])[0].b)), null, aw))
	var craft_where := func() -> String: return p.SLOTS[sel[1]] if sel[0] == "worn" else str(sel[1])
	act_btns.append(_two_tap(_button(acts, "Desfazer", func(): pass, null, aw), "desfazer", func():
		if not is_instance_valid(p):
			_back()
			return
		if gear_marking:  # #280: as marcadas, de uma vez
			var snap: Array = gear_marked.map(func(i): return bag_it[i])
			_act(p, "scrap_many", [2, snap], func(n):
				gear_marking = false
				gear_marked.clear()
				open_gear(who, back, -1, tr("Desfizeste as marcadas: +%d Ossos.") % n if n is int and n > 0 else ""))
		elif sel[0] == "bag":
			_act(p, "scrap_gear", [sel[1], sel[2]], func(n): open_gear(who, back, -1, tr("Desfizeste a peça: +%d Ossos.") % n if n is int and n > 0 else ""))))
	var forge := _button(right, "Forjar", func():  # G4: a Forja de Peças da peça escolhida (posta ou na mochila)
		if sel[2] != "" and is_instance_valid(p):
			open_craft(who, back, craft_where.call()), null, aw)
	forge.size_flags_horizontal = Control.SIZE_SHRINK_END  # Lote 11 C (b): na 3.ª coluna das ações de baixo (ia de ponta a ponta da descrição, fora de todas)
	forge.custom_minimum_size.y = 48.0
	act_btns.append(forge)
	for ab in act_btns:  # com o comando, o foco passa por outras peças a caminho das ações: ao chegar, a descrição volta à escolhida, a que elas usam
		ab.focus_entered.connect(func():
			if sel[2] != "" and not gear_marking:
				show.call(sel[0], sel[1], sel[2]))
	var lot := _button(acts, "Desfazer em lote", _scrap_lot.bind(who, back), null, aw)
	lot.disabled = not mine or not range(p.bag.size()).any(lockable)
	var mk := _button(acts, "Deixar de marcar" if gear_marking else "Marcar", func():
		gear_marking = not gear_marking
		gear_marked.clear()
		open_gear(who, back, acts_at + 4), null, aw)
	mk.disabled = not mine or p.bag.is_empty()
	_button(acts, tr(SORT_NAMES[sort]), func():
		main.set_setting("bag_sort", (sort + 1) % SORT_NAMES.size())
		open_gear(who, back, acts_at + 5), null, aw)
	var fb := _button(acts, "Ficha", func():
		desc.text = sheet
		sel[0] = ""  # sem a comparação à vista, o toque seguinte não põe nem desfaz
		sel[1] = -1
		sel[2] = ""
		paint.call(), null, aw)
	fb.focus_entered.connect(func(): desc.text = sheet)
	if main.players.size() > 1:
		var other: int = 1 - gear_who
		_button(acts, tr("Ver o do %s") % tr(main.players[other].hero_name), func(): open_gear(other, back), null, aw)
	_close_button(acts, aw)
	for ab in acts.get_children():
		ab.custom_minimum_size.y = 48.0  # 3 filas: com o texto a 130% o painel cabe nos 720 px a partir do HUB_TOP
	btns.append_array(acts.get_children())
	btns.append(forge)  # no fim: os índices das ações (acts_at + n) não mudam
	if pick != "":  # G4: de volta da Forja de Peças, na mesma peça (a mochila pode ter mudado de ordem: a raridade subiu)
		focus = p.SLOTS.find(pick) if pick in p.SLOTS else gear_tiles.map(func(t): return t.i).find(int(pick))
	paint.call()
	btns[focus if focus >= 0 and focus < btns.size() else (p.SLOTS.size() if not p.bag.is_empty() else 0)].grab_focus()
	if focus < 0 or focus >= acts_at:  # depois do grab_focus: o focus_entered trocava logo a ficha pela peça com o foco
		desc.text = sheet
	elif focus < gear_tiles.size() and not gear_marking:  # refeito depois de pôr ou de trancar: a peça do foco fica escolhida, e os botões falam dela (Destrancar)
		var ft: Dictionary = gear_tiles[focus]
		show.call("bag" if ft.i >= 0 else "worn", ft.i if ft.i >= 0 else focus, ft.it)
	if gear_marking:
		desc.text = marked_hint % gear_marked.size()
	if note != "" and focus >= 0 and focus < btns.size():
		_pop(btns[focus])


## G1: um quadrado do Equipamento, 64 x 64, na moldura art/ui/slot.png (os únicos cor de brasa), com o ícone da base na cor
## dela (Loot.TINT). Vazio, o lugar mostra a primeira base que lá cabe, muito apagada. As marcas desenha-as o _draw_tile.
func _gear_tile(box: Control, it: String, s: String) -> Button:
	var b := Button.new()
	b.custom_minimum_size = Vector2(TILE, TILE)
	var base: String = it.get_slice(":", 0) if it != "" else main.player.BASES.filter(func(k): return main.player.GEAR[k].slot == s)[0]
	var mod := Color(1.25, 0.85, 0.65) if it != "" and main.player.gear_rarity(it) == 3 else Color.WHITE
	b.add_theme_stylebox_override("normal", _tile_box(mod))
	b.add_theme_stylebox_override("hover", _tile_box(mod * Color(1.25, 1.25, 1.2)))
	b.add_theme_stylebox_override("pressed", _tile_box(mod * Color(1.4, 1.35, 1.2)))
	b.add_theme_stylebox_override("disabled", _tile_box(mod))
	b.icon = Loot.TEX.get(base)
	b.expand_icon = true
	b.icon_alignment = HORIZONTAL_ALIGNMENT_CENTER
	b.vertical_icon_alignment = VERTICAL_ALIGNMENT_CENTER
	for st in ["icon_normal_color", "icon_focus_color", "icon_hover_color", "icon_pressed_color"]:
		b.add_theme_color_override(st, Loot.TINT.get(base, Color.WHITE) if it != "" else Color(0.6, 0.6, 0.55, 0.3))
	b.draw.connect(_draw_tile.bind(b, it))
	box.add_child(b)
	return b


func _tile_box(mod: Color) -> StyleBoxTexture:
	var sb := StyleBoxTexture.new()
	sb.texture = UI.slot  # a moldura inteira esticada: num quadrado de 64 a borda fica com uns 8 px
	sb.set_content_margin_all(10.0)
	sb.modulate_color = mod
	return sb


## As marcas de um quadrado, em células de 2 px: a barra da raridade em baixo, o veredicto em cima à direita, o cadeado em cima
## à esquerda (o do relicário, chest.gd, a metade) e a cruz das marcadas.
func _draw_tile(b: Button, it: String) -> void:
	if it == "":
		return
	var t: Dictionary = {}
	for q in gear_tiles:
		if q.b == b:
			t = q
	var p = main.players[gear_who] if gear_who < main.players.size() else main.player
	var sz := b.size
	if b.icon != null and _dark_icon(b.icon):  # Lote 11 C (e): um ícone escuro (as Manoplas) leva um contorno claro à volta, sem cor por cima
		var cr := Rect2(10, 10, sz.x - 20, sz.y - 20)  # o sítio do ícone: a caixa do quadrado (content margin 10), com o ícone inteiro e ao meio
		var k: float = minf(cr.size.x / b.icon.get_width(), cr.size.y / b.icon.get_height())
		var ir := Rect2(cr.get_center() - b.icon.get_size() * k / 2.0, b.icon.get_size() * k)
		_draw_rim(b, b.icon, ir, sz.y - 15.0)  # Lote 12 C (f): fino e apagado, 2 px acima da barra da raridade (a 2 px e claro, as duas manoplas eram uma mancha só)
	b.draw_rect(Rect2(10, sz.y - 13, sz.x - 20, 3), main.player.rarity_color(main.player.gear_rarity(it)))
	var v: String = t.get("v", "")
	if v in ["up", "both"]:
		_pix_tri(b, Vector2(sz.x - 15, 13 if v == "up" else 9), -1, Color(0.45, 1.0, 0.5))
	if v in ["down", "both"]:
		_pix_tri(b, Vector2(sz.x - 15, 13 if v == "down" else 19), 1, Color(1.0, 0.4, 0.35))
	if it in p.locks:
		b.draw_set_transform(Vector2(17, 19), 0.0, Vector2(0.5, 0.5))
		var dark := Color(0.07, 0.06, 0.08)
		var iron := Color(0.4, 0.38, 0.42)
		for r in [[-12, -26, 24, 18, dark], [-8, -22, 16, 14, iron], [-4, -18, 8, 10, dark], [-16, -10, 32, 26, dark], [-14, -8, 28, 22, iron], [-14, -8, 28, 4, Color(0.62, 0.6, 0.64)], [-14, 10, 28, 4, Color(0.25, 0.23, 0.27)], [-4, -2, 8, 10, dark], [-2, 0, 4, 6, Color(0.95, 0.2, 0.12)]]:
			b.draw_rect(Rect2(r[0], r[1], r[2], r[3]), r[4])
		b.draw_set_transform(Vector2.ZERO)
	if t.get("i", -1) in gear_marked:
		for pass_i in 2:  # primeiro o contorno escuro, depois o vermelho
			for k in 11:
				for q in [Vector2(12 + 4 * k, 12 + 4 * k), Vector2(sz.x - 16 - 4 * k, 12 + 4 * k)]:
					b.draw_rect(Rect2(q - Vector2(1, 1), Vector2(6, 6)) if pass_i == 0 else Rect2(q, Vector2(4, 4)), Color(0.1, 0.0, 0.0) if pass_i == 0 else Color(1.0, 0.25, 0.2))


## Um triângulo em células de 2 px (4 filas), a apontar para cima (dir -1) ou para baixo (1), com contorno escuro; c = o meio.
func _pix_tri(ci: CanvasItem, c: Vector2, dir: int, col: Color) -> void:
	for pass_i in 2:
		for row in 4:
			var w: int = (row if dir < 0 else 3 - row) * 2 + 1
			for k in w:
				var q := c + Vector2((k - w / 2) * 2 - 1, (row - 2) * 2)
				ci.draw_rect(Rect2(q - Vector2(2, 2), Vector2(6, 6)) if pass_i == 0 else Rect2(q, Vector2(2, 2)), Color(0.05, 0.04, 0.03) if pass_i == 0 else col)


## Segurar um quadrado 0,6 s tranca ou destranca a peça (#78); o largar que se segue não conta como toque. O dedo que anda
## mais de 12 px já não segura (é um arrastar); com o comando, o A seguro. O temporizador é filho do quadrado: morre com ele.
func _hold_lock(b: Button, ok: Callable, act: Callable) -> void:
	b.gui_input.connect(func(e: InputEvent):
		if (e is InputEventScreenTouch or e is InputEventMouseButton) and e.pressed:
			b.set_meta("at", e.position)
		elif (e is InputEventScreenDrag or e is InputEventMouseMotion) and e.position.distance_to(b.get_meta("at", e.position)) > 12.0:
			b.set_meta("moved", true))
	b.button_down.connect(func():
		b.remove_meta("held")
		b.remove_meta("moved")
		var n: int = b.get_meta("press", 0) + 1  # o temporizador só vale para este toque: largar (ou um toque seguinte) apaga-o
		b.set_meta("press", n)
		if not ok.call():
			return
		var t := Timer.new()
		t.one_shot = true
		t.wait_time = HOLD_LOCK
		t.timeout.connect(func():
			t.queue_free()
			if b.get_meta("press") == n and b.is_pressed() and not b.has_meta("moved"):
				b.set_meta("held", true)
				act.call())
		b.add_child(t)
		t.start())
	b.button_up.connect(func(): b.set_meta("press", b.get_meta("press", 0) + 1))


## O veredicto de uma peça (_gear_verdict) em palavra, para o desenho e para o teste: up, down, both ou "" (igual).
func _verdict_word(c: Color) -> String:
	return "up" if c == Color(0.45, 1.0, 0.5) else "down" if c == Color(1.0, 0.4, 0.35) else "both" if c == Color(0.92, 0.88, 0.78) else ""


## Para o teste: o veredicto desenhado no quadrado da peça i da mochila (up, down, both ou "").
func tile_verdict(i: int) -> String:
	for t in gear_tiles:
		if t.i == i:
			return t.v
	return ""


## Desfazer em lote (#266): as comuns, as comuns e as mágicas, ou até às raras, de uma vez. Nunca as postas, as trancadas
## nem as únicas. Dois toques em cada (H1).
func _scrap_lot(who: int, back: Callable) -> void:
	var p = main.players[mini(who, main.players.size() - 1)]
	var box := _open_panel("Desfazer em lote", true, open_gear.bind(who, back))
	panel.set_meta("gear", true)  # ao voltar, o Equipamento fica como estava (o filtro)
	_text(box, "Nunca as peças postas, as trancadas nem as únicas.", Color(0.62, 0.78, 0.68))
	var first: Button = null
	for r in 3:
		var them: Array = p.bag.filter(func(it): return not it in p.locks and p.gear_rarity(it) <= r)
		var bones := 0
		for it in them:
			bones += p.SCRAP[p.gear_rarity(it)]
		var n: String = tr("1 peça") if them.size() == 1 else tr("%d peças") % them.size()
		var b := _two_tap(_button(box, tr(LOT_NAMES[r]) % [n, bones], func(): pass), "desfazer", func():
			if not is_instance_valid(p):
				_back()
				return
			_act(p, "scrap_many", [r, them], func(got): open_gear(who, back, -1, tr("Desfizeste o lote: +%d Ossos.") % got if got is int and got > 0 else "")))
		b.disabled = them.is_empty()
		if first == null and not b.disabled:
			first = b
	var c := _close_button(box)
	(first if first != null else c).grab_focus()


## G4: Forjar — <peça>: os materiais que o grupo já encontrou (Loot.MATS, quantos no botão; a 0 ficam apagados) e o Tinteiro,
## na peça posta (where = o lugar) ou na mochila (where = o índice, em texto). O 1.º toque diz o que o material faz e o que
## muda e arma o botão ("Outra vez: forjar"); o 2.º forja (sorteia-se só aí, no anfitrião: reabrir não dá para escolher). O
## que não serve fica apagado, e o toque ou o foco dizem porquê. B / Voltar volta ao Equipamento, na mesma peça.
func open_craft(who: int, back: Callable, where: String, focus := 0, note := "") -> void:
	var p = main.players[mini(who, main.players.size() - 1)]
	var home := func(): open_gear(who, back, -1, "", where)
	var at: int = int(where) if where.is_valid_int() else -1
	var it: String = p.gear.get(where, "") if where in p.SLOTS else p.bag[at] if at >= 0 and at < p.bag.size() else ""
	if it == "":  # a peça já não está ali (no convidado, a mochila que o anfitrião mudou)
		home.call()
		return
	var box := _open_panel(tr("Forjar — %s") % p.gear_name(it), true, home)
	panel.set_meta("gear", true)  # ao voltar, o Equipamento fica como estava (o filtro)
	var w: float = 640.0 * maxf(text_k, 1.0)
	var line_h: float = Gothic.BODY.get_height(roundi(Gothic.BODY_SIZE * text_k))
	# Lote 11 C (i): as duas caixas de texto com a altura que esta peça pede, e não a do pior caso de todas (sobravam ~55 px por
	# cima dos botões e ~50 por cima do Voltar). A de cima guarda já a linha da nota da forja (só aparece depois do 2.º toque),
	# a de baixo a do material com mais texto: o 1.º toque não mexe em nada
	var fs := roundi(Gothic.BODY_SIZE * text_k)
	var tall := func(t: String) -> float: return Gothic.BODY.get_multiline_string_size(BBCODE.sub(t, "", true), HORIZONTAL_ALIGNMENT_LEFT, w, fs).y + 2.0
	var top := RichTextLabel.new()  # a peça como está agora e o que a última forja fez
	top.bbcode_enabled = true
	top.fit_content = false
	top.scroll_active = false
	top.add_theme_color_override("default_color", Color(0.62, 0.78, 0.68))
	top.text = _gear_text(p, it, w) + ("\n" + "[color=#%s]%s[/color]" % [(Color(1.0, 0.4, 0.35) if note in p.CRAFT_FAIL else Color(0.45, 1.0, 0.65)).to_html(false), tr(note)] if note != "" else "")
	top.custom_minimum_size = Vector2(w, maxf(tall.call(top.text), tall.call(_gear_text(p, it, w) + "\n" + tr("%s » %s (%s)") % [p.gear_name(it), p.gear_name(it), tr(p.RARITY_WORD[mini(p.gear_rarity(it) + 1, 2)])])))  # o smoke B24 confere que nada se corta
	box.add_child(top)
	var grid := GridContainer.new()
	grid.columns = 2
	grid.add_theme_constant_override("h_separation", 8)
	box.add_child(grid)
	var desc := RichTextLabel.new()  # o que o material faz e o que muda (altura fixa: o painel não mexe entre os dois toques)
	desc.bbcode_enabled = true
	desc.fit_content = false
	desc.scroll_active = false
	desc.custom_minimum_size = Vector2(w, line_h)  # a altura certa vem dos materiais (Lote 11 C (i)): a do texto mais comprido
	desc.add_theme_color_override("default_color", Color(0.8, 0.8, 0.75))
	var kinds: Array = Loot.MATS.filter(func(k): return main.mats.has(k)) + ["ink"]
	var gold := Color(0.95, 0.85, 0.6).to_html(false)
	var rows := []
	for k in kinds:
		var n: int = main.currency.ink if k == "ink" else main.mats[k]
		var why: String = p.craft_why(it, k, n, it in p.locks)
		var info: String = "[color=#%s]%s[/color]: %s" % [gold, tr(Loot.INFO[k][0]), tr(p.CRAFT[k])] + "\n" + ("[color=#%s]%s[/color]" % [Color(1.0, 0.4, 0.35).to_html(false), tr(why)] if why != "" else _craft_preview(p, it, k))
		desc.custom_minimum_size.y = maxf(desc.custom_minimum_size.y, tall.call(info))
		var b := _button(grid, tr("Tinteiro (%d): afixos novos") % n if k == "ink" else tr("%s (%d)") % [tr(Loot.INFO[k][0]), n], func(): desc.text = info, Loot.TEX[k], (w - 8.0) / 2.0)
		b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		_fit_text(b, ICON_GAP)
		for st in ["icon_normal_color", "icon_focus_color", "icon_hover_color", "icon_pressed_color"]:
			b.add_theme_color_override(st, Loot.TINT.get(k, Color.WHITE) * (Color(0.55, 0.55, 0.55) if why != "" else Color.WHITE))
		if why != "":  # apagado, mas o toque e o foco ainda dizem porquê (um botão desligado não os recebe)
			b.add_theme_stylebox_override("normal", _sbt(UI.btn, Color(0.5, 0.5, 0.5)))
			b.add_theme_stylebox_override("hover", _sbt(UI.btn, Color(0.5, 0.5, 0.5)))
			b.add_theme_stylebox_override("pressed", _sbt(UI.btn, Color(0.5, 0.5, 0.5)))
			for st in ["font_color", "font_hover_color", "font_focus_color", "font_pressed_color"]:
				b.add_theme_color_override(st, Color(0.55, 0.55, 0.5))
			b.set_meta("why", why)
		else:
			var row: int = rows.size()
			_two_tap(b, "forjar", func(): _act(p, "craft_gear", [where, it, k], func(msg):
				if panel != null:
					open_craft(who, back, where, row, msg if msg is String else "")))  # null: o anfitrião estava a recarregar
		b.focus_entered.connect(func(): desc.text = info)
		rows.append(b)
	box.add_child(desc)
	if kinds.size() == 1:  # ainda nenhum material: onde caem
		_text(box, "Os materiais caem dos elites, dos Gigantes Errantes, dos chefes com nome e dos relicários dos Sepulcros.", Color(0.62, 0.78, 0.68))
		box.get_child(box.get_child_count() - 1).autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		box.get_child(box.get_child_count() - 1).custom_minimum_size.x = w
	_close_button(box, w)
	rows[clampi(focus, 0, rows.size() - 1)].grab_focus()


## G4: o que muda na peça it com o material k, sem sortear nada (o sorteio é só no 2.º toque, no anfitrião).
func _craft_preview(p, it: String, k: String) -> String:
	var affs: Array = p.gear_affixes(it)
	var names := func(list: Array) -> String: return tr(" ou ").join(list.map(func(t): return tr(GEAR_TEXT[p.affix_key(t)][0])))
	var lvl := func(t: String) -> int: return 0 if t.ends_with("-") else 2 if t.ends_with("+") else 1
	match k:
		"enxofre":
			return tr("Fica %s, com mais um afixo ao calhas.") % tr(p.RARITY_WORD[p.gear_rarity(it) + 1])
		"agulha":
			var low: int = affs.map(lvl).min()
			return tr("Sai: %s.") % names.call(affs.filter(func(t): return lvl.call(t) == low))
		"cinza_maior":
			return tr("Passa ao máximo: %s.") % names.call(affs.filter(func(t): return not t.ends_with("+")))
		"cinzel":
			return tr("Qualidade +%d%% » +%d%%.") % [p.gear_q(it) * 10, p.gear_q(it) * 10 + 10]
		"martelo":
			return tr("Ficam os mesmos (%s); só a força muda.") % ", ".join(affs.map(func(t): return tr(GEAR_TEXT[p.affix_key(t)][0])))
	return tr("Saem os de agora (%s).") % ", ".join(affs.map(func(t): return tr(GEAR_TEXT[p.affix_key(t)][0])))


## G6 (#85): a Bolsa: o que o grupo tem, em 3 separadores (como os do Bestiário): Moedas, Materiais (só os que já caíram; os
## gastos a cinzento) e Frascos (os Frascos de Alma, as Almas Condensadas e as almas da arma encontradas). Cada linha: o
## ícone, quantos, o que faz e onde cai. Só se lê. As moedas do HUD abrem-na (B6); o Menu também.
func open_bag(tab := 0, back := Callable()) -> void:
	var box := _open_panel("Bolsa", true, back)
	var tabs := HBoxContainer.new()
	tabs.add_theme_constant_override("separation", 6)
	box.add_child(tabs)
	for i in BAG_TABS.size():
		var tb := _button(tabs, BAG_TABS[i], func(): open_bag(i, back), null, 180.0)
		tb.set_meta("tab", i)
		if i == tab:
			tb.add_theme_stylebox_override("normal", _sbt(UI.btn_on, Color.WHITE))
			tb.add_theme_color_override("font_color", Color.WHITE)
	var w: float = 720.0 * maxf(text_k, 1.0)
	var list := _scroll_list(box, w, 400.0)
	var rows := []  # [ícone, a cor dele, título, cor do título, o que faz, onde cai]
	var gold := Color(0.95, 0.85, 0.6)
	var grey := Color(0.5, 0.5, 0.48)
	match tab:
		0:
			for k in COIN_INFO:
				var n: int = main.currency.get(k, 0)
				rows.append([Loot.TEX[k], Loot.TINT.get(k, Color.WHITE), "%s: %d" % [tr(Loot.INFO[k][0]), n], gold if n > 0 else grey, tr(COIN_INFO[k]), tr(COIN_FROM[k])])
		1:
			for k in Loot.MATS + Loot.KEEP:  # Lote 11: e as Estacas Fúnebres e o Óleo de Lápide, do Atlas
				if main.mats.has(k):
					var n: int = main.mats[k]
					rows.append([Loot.TEX[k], Loot.TINT.get(k, Color.WHITE), "%s: %d" % [tr(Loot.INFO[k][0]), n], gold if n > 0 else grey, tr(main.player.CRAFT.get(k, KEEP_DO.get(k, ""))), tr(MAT_FROM[k])])
			if rows.is_empty():
				_note(list, tr("Ainda não encontraste nenhum material da Forja de Peças.") + " " + tr("Caem dos elites, dos Gigantes Errantes, dos chefes com nome e dos relicários dos Sepulcros. Gastam-se no Equipamento, com o Forjar."), false)
		_:
			var P = main.player
			for f in P.SUPPORTS + P.SOULS:
				if f != "" and f in main.flasks:
					var soul: bool = f in P.SOULS
					rows.append([Loot.FLASK_TEX[f], Color.WHITE, "%s · %s" % [tr(P.SUPPORT_NAMES[f]), tr("Alma Condensada" if soul else "Frasco Maldito" if f in P.CURSED else "Frasco de Alma")], Loot.RELIC if soul else gold,
						tr(P.SUPPORT_DESC[f]), tr("Do chefe dele: o Carcereiro ou o Arauto." if f in P.CURSED else "Dos chefes (um que ainda falte) e, raramente, de outros mortos.")])
			for id in main.forms:
				rows.append([Loot.TEX[id], Color.WHITE, "%s · %s" % [tr(main.FORMS[id][0]), tr("Alma da arma")], Loot.INFO.arma[1], tr(main.FORMS[id][1]), tr("Dos chefes com nome; a Foice Longa, do guardião da profundidade 5.")])
			if rows.is_empty():
				_note(list, tr("Ainda não tens frascos nem almas da arma: caem dos chefes."), false)
	for r in rows:
		var row := HBoxContainer.new()
		row.add_theme_constant_override("separation", 12)
		var pic := _art(r[0], Vector2(48, 48))
		pic.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
		pic.modulate = r[1]
		row.add_child(pic)
		var col := VBoxContainer.new()
		col.add_theme_constant_override("separation", 0)
		col.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		for l in [[r[2], r[3]], [r[4], Color(0.75, 0.75, 0.7)], [r[5], Color(0.55, 0.7, 0.62)]]:
			var lb := Label.new()
			lb.text = l[0]
			lb.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
			lb.custom_minimum_size.x = w - 72.0
			lb.add_theme_color_override("font_color", l[1])
			col.add_child(lb)
		row.add_child(col)
		list.add_child(row)
	_close_button(box, w).grab_focus()


## Uma parte da ficha ou do comparador ("Alma por segundo 8") inteira numa linha: espaços que não partem. As linhas só partem
## depois de cada " · " (DOT), como as cargas da poção (o 8 ia sozinho para a linha de baixo).
static var DOT := String.chr(0xA0) + "· "
static var BBCODE := RegEx.create_from_string("\\[[^\\]]*\\]")  # as marcas [color] do comparador (as partes não têm outros parênteses retos)
func _whole(s: String) -> String:
	return s.replace(" ", String.chr(0xA0))


## C (a): as partes em linhas que nunca acabam num "·" (o separador só fica entre duas partes da mesma linha): mede cada linha
## na letra da descrição do Equipamento e muda de linha antes da parte que já não cabe. Uma frase comprida (a regra de um
## único) vai sozinha para uma linha nova e parte nos espaços dela.
func _dots(parts: Array, w := -1.0, font: Font = null, fs := 0) -> String:
	if w < 0.0:  # a descrição do Equipamento; o estado (Lote 7 C (h)) diz a dele
		w = _gear_desc_w()
	w -= 6.0  # a folga: a descrição não pode partir uma linha que aqui coube
	if font == null:
		font = Gothic.BODY
	if fs <= 0:
		fs = roundi(Gothic.BODY_SIZE * text_k)
	var lines := []
	var line := ""
	for q in parts:
		var both: String = q if line == "" else line + DOT + q
		if line != "" and font.get_string_size(BBCODE.sub(both, "", true), HORIZONTAL_ALIGNMENT_LEFT, -1, fs).x > w:
			lines.append(line)
			both = q
		line = both
	if line != "":
		lines.append(line)
	return "\n".join(lines)


## A largura da descrição do Equipamento (à direita dos quadrados): o _dots mede as linhas com ela.
func _gear_desc_w() -> float:
	return hub_w() - BAG_COLS * TILE - (BAG_COLS - 1) * 6.0 - 16.0


## O que a peça dá, para ler: o nome na cor da raridade, a raridade e cada número (os únicos, também a regra deles).
## w: a largura das linhas (por omissão, a da descrição do Equipamento; a Forja de Peças é mais larga).
func _gear_text(p, it: String, w := -1.0) -> String:
	var r: int = p.gear_rarity(it)
	var parts := []
	var st: Dictionary = p.gear_of(it)
	var marks := {}  # G3: a força de cada afixo, "+" no máximo e "-" fraco
	for t in p.gear_affixes(it):
		marks[p.affix_key(t)] = t.right(1)
	for k in st:
		if GEAR_TEXT.has(k):
			var pct: bool = GEAR_TEXT[k][1]
			var mk: String = marks.get(k, "")
			parts.append(_whole(("+" if st[k] > 0.0 else "") + _dec(st[k] * (100.0 if pct else 1.0), 1).trim_suffix(",0").trim_suffix(".0") + ("%" if pct else "") + " " + tr(GEAR_TEXT[k][0])
				+ (" " + tr("(máx.)") if mk == "+" else " " + tr("(fraco)") if mk == "-" else "")))
	if p.gear_q(it) > 0:  # G3: a qualidade da base (o Cinzel de Marfim, #231)
		parts.append(_whole(tr("Qualidade +%d%%") % (p.gear_q(it) * 10)))
	var g: Dictionary = p.GEAR[it.get_slice(":", 0)]
	if g.has("desc"):
		parts.append(tr(g.desc))
	return _dots(["[color=#%s]%s[/color]" % [p.rarity_color(r).to_html(false), p.gear_name(it)], _whole(tr(p.RARITY[r]))], w) + "\n" + _dots(parts, w)


## O que a peça it muda no herói p, no lugar dela: de agora » com ela, a verde o que melhora e a vermelho o que piora (só as
## linhas que mudam).
func _gear_compare(p, it: String) -> String:
	var parts: Array = _gear_rows(p, it).map(func(r): return _whole("%s %s » [color=#%s]%s[/color]%s" % [r[0], r[1], (Color(0.45, 1.0, 0.5) if r[3] else Color(1.0, 0.4, 0.35)).to_html(false), r[2], "%" if r[4] else ""]))
	var mate: String = "" if not p.gear_of(it).has("alianca") or main.players.any(func(q): return q != p and q.stat("alianca") > 0.0) else "\n" + tr("Só funciona com o outro herói a usar a outra aliança.")  # #68: sozinha, só o roubo de vida
	return (_dots(parts) if not parts.is_empty() else tr("Igual ao que tens posto.")) + mate


## A cor de uma peça da mochila contra a posta, com os números do comparador: verde se só ganha, vermelho se só perde, branco
## se ganha e perde, cinzento se não muda nada. Uma regra dos únicos sem número (garras, teeth) ganha-se ou perde-se inteira.
func _gear_verdict(p, it: String) -> Color:
	var ups: Array = _gear_rows(p, it).map(func(r): return r[3])
	var got: Dictionary = p.gear_of(it)
	var now: Dictionary = p.gear_of(p.gear[p.gear_slot(it)]) if p.gear.has(p.gear_slot(it)) else {}
	for k in got.keys() + now.keys():
		if not GEAR_TEXT.has(k) and got.has(k) != now.has(k):
			ups.append(got.has(k))
	if ups.is_empty():
		return Color(0.6, 0.6, 0.55)
	return Color(0.45, 1.0, 0.5) if not ups.has(false) else Color(1.0, 0.4, 0.35) if not ups.has(true) else Color(0.92, 0.88, 0.78)


## As linhas do comparador, [nome, de, para, sobe, em %], só as que mudam ao ler. Experimenta a peça só nos números
## (gear_stats) e volta a pôr os de antes: a vida não mexe, porque o refresh_stats cortava-a (player:289). No convidado
## também, com as peças que vêm do anfitrião.
func _gear_rows(p, it: String) -> Array:
	var s: String = p.gear_slot(it)
	var keys: Array = p.gear_of(it).keys()
	if p.gear.has(s):
		keys += p.gear_of(p.gear[s]).keys()
	var keep: Dictionary = p.gear_stats
	var a: Array = keys.map(func(k): return p.gear_view(k))
	var worn: Dictionary = p.gear.duplicate()
	worn[s] = it
	p.gear_stats = p.gear_sum(worn)
	var b: Array = keys.map(func(k): return p.gear_view(k))
	p.gear_stats = keep
	var rows := []
	var seen := []  # hp_max e hp_mul são as duas a "Vida máxima": uma linha só
	for i in keys.size():
		var k: String = keys[i]
		if not GEAR_TEXT.has(k) or GEAR_TEXT[k][0] in seen:
			continue
		seen.append(GEAR_TEXT[k][0])
		var pct: bool = GEAR_TEXT[k][1] and not k in GEAR_FELT
		var places := 1 if pct or k == "regen" else 0
		var va: float = a[i] * (100.0 if pct else 1.0)
		var vb: float = b[i] * (100.0 if pct else 1.0)
		if _dec(va, places) == _dec(vb, places) and not is_equal_approx(va, vb):  # o arredondamento escondia-a (Garras contra Luvas comuns: 22,9 e 23,1 davam "23"): mais uma casa
			places += 1
		var sg: String = "+" if k in SIGNED else ""
		var from := sg + _dec(va, places).trim_suffix(",0").trim_suffix(".0")  # "20" e não "20,0"
		var to := sg + _dec(vb, places).trim_suffix(",0").trim_suffix(".0")
		if from != to:  # no comparador, » e não → (o dos frascos): a Augusta não tem a seta, e a letra de recurso fazia a linha mais alta e mais larga
			rows.append([tr(GEAR_TEXT[k][0]), from, to, b[i] > a[i], pct])
	return rows


## A ficha do herói (0.4.9): os totais, com os números do comparador (gear_view); os da 3.ª linha só se não forem 0, e o dano
## de feitiços só no herói com Lança e Erguer (os únicos que o usam, player:866).
func _hero_sheet(p) -> String:
	var lines := []
	for keys in [["hp_max", "mana_max", "regen"], ["gdmg", "crit", "dr", "speed"], ["leech", "bleed", "boss", "kill_heal", "bone_barrier", "spell", "crit_dmg", "aura"]]:
		var parts := []
		for k in keys:
			var v: float = p.gear_view(k)
			if keys.size() > 4 and (is_zero_approx(v) or (k == "spell" and not "bolt" in p.order)):  # a 3.ª linha só com o que não é 0 (o Visor e o Incensário, G2, também)
				continue
			var pct: bool = GEAR_TEXT[k][1] and not k in GEAR_FELT
			parts.append(_whole(tr(GEAR_TEXT[k][0]) + " " + ("+" if k in SIGNED else "") + _dec(v * (100.0 if pct else 1.0), 1 if pct or k == "regen" else 0).trim_suffix(",0").trim_suffix(".0") + ("%" if pct else "")))
		if not parts.is_empty():
			lines.append(_dots(parts))
	lines.append(tr("Dano: o do golpe básico. Já conta com o herói, a Árvore, a foice e as peças. Toca numa peça para comparar."))
	return "\n".join(lines)


## Fórmulas de dano: de onde vem o dano de cada habilidade, multiplicador a multiplicador.
func open_formulas(back := Callable()) -> void:
	var box := _open_panel("Fórmulas de dano", true, back)
	for p in main.players:
		_text(box, tr(p.hero_name), p.tint)
		for id in p.order:
			var n: Array = p.skill_numbers(id)
			var txt := "%s: %s" % [tr(p.skills[id].name), _dec(p.skills[id].dmg, 0)]
			for part in n[3]:
				if not is_equal_approx(part[1], 1.0):  # × 1 não muda nada
					txt += " × %s %s" % [_dec(part[1]), tr(part[0])]
			var lb := Label.new()
			lb.text = txt + " = %s" % _dec(n[0], 0) if n[0] > 0.0 else "%s: %s" % [tr(p.skills[id].name), tr("sem dano (defesa)")]
			lb.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
			lb.custom_minimum_size.x = 640.0
			lb.add_theme_color_override("font_color", Color(0.8, 0.8, 0.75))
			box.add_child(lb)
		_text(box, tr("Crítico: %d%% de hipótese, dano ×%s · contra chefes ×%s") % [roundi((main.CRIT + p.stat("crit")) * 100.0), _dec(main.CRIT_MULT + p.stat("crit_dmg")), _dec(1.0 + p.stat("boss"))], Color(0.6, 0.6, 0.55))
	_close_button(box).grab_focus()


## Forja (S2; desde a 0.4.9 o ecrã da foice): em cima o que a foice faz, por baixo as 7 maneiras de a mudar, em duas colunas
## (à esquerda as moedas, à direita os reagentes que os chefes com nome deixam, #54 #59 #100 #239). Cada compra refaz o painel
## do mesmo tamanho (texto de 8 linhas, nota sempre lá) e põe o foco no mesmo botão, para o dedo ou o A segurado continuarem
## nele; o que aconteceu vai em note (um aviso ficava por baixo do painel). focus 2, o Forjar até…, não gasta nada. back = o Arsenal.
func open_forge(focus := 2, back := Callable(), note := "") -> void:
	var again := panel_title == "Forja"  # refeita por uma compra: o dedo ou o A continuam nos botões
	var box := _open_panel("Forja", true, back)
	_hub_tabs(box, 1)
	var fs := roundi(Gothic.BODY_SIZE * text_k)
	var line_h: float = Gothic.BODY.get_height(fs)
	var lines_of := func(s: String) -> int: return roundi(Gothic.BODY.get_multiline_string_size(s, HORIZONTAL_ALIGNMENT_LEFT, hub_w() - 8.0, fs).y / line_h)
	var info := RichTextLabel.new()
	info.bbcode_enabled = true
	info.fit_content = false
	info.scroll_active = false
	info.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	info.add_theme_color_override("default_color", Color(0.8, 0.8, 0.75))
	info.text = _weapon_info()
	box.add_child(info)
	# Lote 9 C (c): a nota (o que a compra fez, ou a Lâmina Cega) vai nas linhas livres da caixa de cima: a linha só dela era
	# uma faixa vazia (a 130%) ou repetia o botão da alma. Sem lugar, vai num aviso
	var blunt: bool = note == "" and main.trial_on("lamina")
	var said: String = tr("Provação da Lâmina Cega: a foice não conta até ao fim do Cortejo.") if blunt else tr(note)
	var n: int = lines_of.call(RegEx.create_from_string("\\[[^\\]]*\\]").sub(info.text, "", true))
	var rows_max: int = 8 if main.players.size() > 1 else 7  # o pior caso: 8 linhas a dois (a linha do grupo), 7 a solo
	# Revisão do Lote 10: a caixa tem o texto e a nota (ou uma linha livre para a da próxima compra, meia por cima e meia por
	# baixo do texto); o que falta para o pior caso fica por baixo dos botões, ao pé do Fechar (por cima ou por baixo do texto
	# lia-se como uma linha em falta). O painel tem sempre a mesma altura e, refeita por uma compra, a caixa nunca encolhe:
	# com mais ou menos linhas os botões mexiam-se debaixo do dedo
	forge_lines = maxi(forge_lines, n) if again else mini(n + (lines_of.call(said) if said != "" else 1), rows_max)
	info.custom_minimum_size = Vector2(hub_w(), line_h * forge_lines)
	if said != "":
		if n + lines_of.call(said) <= forge_lines:
			info.text += "\n" + "[color=#%s]%s[/color]" % [(Color(1.0, 0.4, 0.35) if blunt or note in SPEND_FAIL else Color(0.45, 1.0, 0.65)).to_html(false), said]
		else:  # a resposta ao toque é já (na fila, esperava por avisos que vieram antes); sem lugar à volta, por cima do fundo da caixa
			_show_toast(said, info)
	var c: Dictionary = main.currency
	var w: Dictionary = main.weapon
	var locks := range(2).map(func(i): return [tr("Travar «%s»") % tr(w.suffixes[i]), "lock" + str(i), tr("travar «%s»") % tr(w.suffixes[i])])
	var piles := ["bone", "ink", "ash"].map(func(k): return ["%s (%d)" % [tr(main.PILES[k]), c[k]], "pena_" + k, tr("arriscar %s") % tr(main.PILES[k])])
	# revisão do Lote 10: o Destravar sem o nome (o texto de cima diz qual, «travado»): com ele ia a duas linhas e a grelha mexia
	var formao: Array = [tr("Destravar o sufixo (grátis)"), _forge.bind("unlock", 1, back), "formao", ""] if w.locked != "" else \
		[tr("Travar um sufixo (%d)") % c.formao, _forge_pick.bind("Formão Cadavérico", "O sufixo travado fica quando sorteias com Tinteiros.", locks, 1, back), "formao", "formao"]
	# [texto, o que faz ao toque, ícone, a moeda que paga]: o que faz é null (compra ao carregar e segurar repete), um verbo
	# (dois toques, H1: o Tinteiro sorteia sufixos novos e apagava os bons a quem segurava para ler) ou uma função.
	# A7: primeiro o que faz, depois quantos há; apagado sem com que pagar (as Cinzas também sem nada selado)
	var form: String = w.get("form", "")  # G7: a alma da arma posta
	var lines := [  # por linhas: [0 | 1], [2 | 3], [4 | 5], [6 | 7 a alma da arma]; por baixo, os Tomos e o Fechar
		[tr("Novos sufixos (%d)") % c.ink, "sortear", "ink", "ink"], formao,
		[tr("Forjar até… (%d)") % c.ink, _forge_until.bind(back), "ink", "ink"],
		[tr("Trocar os de ataque (%d)") % c.carmesim, _forge.bind("carmesim", 3, back), "carmesim", "carmesim"],
		[tr("Revelar o oculto (%d)") % c.ash, null, "ash", "ash"],
		[tr("Arriscar uma pilha (%d)") % c.pena, _forge_pick.bind("Pena de Abutre", "3 em 4 vezes a pilha dobra; 1 em 4 arde toda.", piles, 5, back), "pena", "pena"],
		[tr("Reforjar +1: 5 Ossos (tens %d)") % c.bone, null, "bone", "bone"],  # o preço à vista: "(2 Ossos)" sozinho lia-se como o preço
		[tr("Alma da arma: %s") % tr(main.FORMS[form][0] if form != "" else "nenhuma"), _form_pick.bind(back), form, ""],  # G7: grátis, escolhe-se na lista (sem nenhuma encontrada, a lista diz onde caem)
	]
	var short := func(k: String) -> bool:  # lê o main.currency de agora: no convidado chega um dicionário novo a cada frame
		return k != "" and (main.currency[k] < FORGE_COST[k] or (k == "ash" and not main.weapon.sealed))
	var grid := GridContainer.new()
	grid.columns = 2
	grid.add_theme_constant_override("h_separation", 8)
	box.add_child(grid)
	var rows := []
	for l in lines:
		var b := _button(grid, l[0], func(): pass, Loot.TEX.get(l[2]), (hub_w() - 8.0) / 2.0)  # Lote 10 C (a): as duas colunas iguais
		b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		if rows.size() >= 6:  # revisão do Lote 10: a fila dos Ossos e da alma tem sempre duas linhas de altura (o nome da alma e o "tens" mudam; a grelha não)
			b.custom_minimum_size.y = b.get_theme_font("font").get_height(b.get_theme_font_size("font_size")) * 2.0 + b.get_theme_stylebox("normal").get_minimum_size().y
		_fit_text(b, ICON_GAP, true)  # e o texto cabe à direita do ícone (a 130% e em inglês corria por cima dele): em duas linhas, com a letra das outras
		b.disabled = short.call(l[3])
		if l[1] == null:
			b.button_down.connect(_hold_buy.bind(l[2]))  # compra ao carregar; segurar continua (_hold_buy_tick)
		elif l[1] is String:
			_two_tap(b, l[1], _spend.bind(l[2]))
		else:
			b.pressed.connect(l[1])
		for st in ["icon_normal_color", "icon_focus_color", "icon_hover_color", "icon_pressed_color"]:
			b.add_theme_color_override(st, Loot.TINT.get(l[2], Color.WHITE))  # os ícones com cor por cima (os reagentes já vêm pintados)
		rows.append(b)
	var spare := Control.new()  # as linhas que faltam ao texto para o pior caso: o Fechar fica sempre no mesmo sítio
	spare.custom_minimum_size.y = line_h * maxi(rows_max - forge_lines, 0)
	box.add_child(spare)
	var tail := HBoxContainer.new()  # Lote 8: os Tomos ao lado do Fechar (a 8.ª casa da grelha é agora a da alma da arma: a Forja não cresce)
	tail.add_theme_constant_override("separation", 8)
	box.add_child(tail)
	var tomos := Label.new()  # A2: os Tomos fora da grelha das compras, como o Fechar (os 5 Ossos compram ao carregar)
	tomos.text = (tr("Tomos dos Nomes Esquecidos: %d (gastam-se ao refazer a Árvore)") % c.tomo).replace("-", "-" + String.chr(0x2060))  # sem partir no hífen: "gastam-" ficava sozinho no fim da linha
	tomos.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	tomos.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	tomos.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	tomos.add_theme_color_override("font_color", Color(0.8, 0.8, 0.75))
	tail.add_child(tomos)
	_close_button(tail, 0.0).size_flags_horizontal = Control.SIZE_EXPAND_FILL
	rows[clampi(focus, 0, rows.size() - 1)].grab_focus()
	var timer := Timer.new()  # o anfitrião continua a jogar com o painel do convidado aberto: o que se pode pagar muda
	timer.wait_time = 0.5
	timer.autostart = true
	timer.timeout.connect(func():
		for i in rows.size():
			rows[i].disabled = short.call(lines[i][3]))
	box.add_child(timer)


## O texto de cima da Forja: o +N, a linha do grupo (só em co-op), cada sufixo e a propriedade oculta. No máximo 8 linhas.
func _weapon_info() -> String:
	var w: Dictionary = main.weapon
	var gold := Color(0.95, 0.85, 0.6).to_html(false)
	var lines := ["[color=#%s]%s[/color]" % [gold, tr("Foice do Coveiro +%d: +%d%% de dano. Cada +1 custa 5 Ossos e dá mais 10%%.") % [w.tier, w.tier * 10] if w.tier > 0 else tr("Foice do Coveiro +0. Cada +1 custa 5 Ossos e dá +10% de dano.")]]
	if main.players.size() > 1:
		lines.append(tr("A foice é do grupo: tudo isto conta para os dois heróis."))
	for s in w.suffixes:
		lines.append("[color=#%s]%s[/color]: %s" % [gold, tr("%s (travado)") % tr(s) if s == w.locked else tr(s), tr(WEAPON_INFO[s])])
	lines.append("[color=#%s]%s[/color]: %s" % [gold, tr("Oculto"), tr("selado, ainda não conta. As Cinzas do Purgatório revelam-no. Pode ser +60% de dano a chefes, +5 de vida por abate ou +35% de dano de feitiços.") if w.sealed \
		else tr("%s O Tinteiro de Sangue Negro volta a selá-lo; o Carmesim não.") % tr(WEAPON_INFO.get(w.hidden, ""))])
	return "\n".join(lines)  # G7: a alma da arma não cabe aqui (o pior caso já tem as 8 linhas): vai na linha dela, por baixo, e o que faz na lista dela


## G7: as almas da arma que o grupo encontrou e "Nenhuma". O foco ou o 1.º toque dizem o que cada uma faz e armam o botão
## ("Outra vez: pôr"); o 2.º põe-na na foice (grátis, troca-se quando se quiser). Volta à Forja na linha dela.
func _form_pick(back: Callable) -> void:
	var box := _open_panel("Alma da arma", true, open_forge.bind(7, back))
	_text(box, "A foice leva uma de cada vez e só mexe no golpe básico dos dois heróis.", Color(0.62, 0.78, 0.68))
	if main.forms.is_empty():  # a linha da Forja abre-se sempre: apagada, não dizia o que era nem onde se arranja
		_text(box, "Ainda não tens nenhuma: caem dos chefes com nome.\nA Foice Longa vem do guardião da profundidade 5.", Color(0.95, 0.85, 0.6))
	var desc := RichTextLabel.new()
	desc.bbcode_enabled = true
	desc.fit_content = false
	desc.scroll_active = false
	desc.custom_minimum_size = Vector2(608.0 * text_k, Gothic.BODY.get_height(roundi(Gothic.BODY_SIZE * text_k)) * 3)  # altura fixa: a descrição mais comprida tem 3 linhas
	desc.add_theme_color_override("default_color", Color(0.8, 0.8, 0.75))
	var grid := GridContainer.new()
	grid.columns = 2
	grid.add_theme_constant_override("h_separation", 8)
	box.add_child(grid)
	box.add_child(desc)
	var now: String = main.weapon.get("form", "")
	for id in main.forms + [""]:
		var info: String = "[color=#%s]%s[/color]: %s" % [Color(0.95, 0.85, 0.6).to_html(false), tr(main.FORMS[id][0]), tr(main.FORMS[id][1])] if id != "" else tr("A foice sem alma: o golpe básico de sempre.")
		var b := _button(grid, main.FORMS[id][0] if id != "" else "Nenhuma", func(): desc.text = info, Loot.TEX.get(id), 300.0 * maxf(text_k, 1.0))
		b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		b.add_theme_constant_override("icon_max_width", FORM_ICON)  # Lote 10 C (g): os ícones da SC-ICO8 a 28 px liam-se pequenos e escuros
		b.custom_minimum_size.y = FORM_ROW  # Lote 11 C (a): o ícone (até 40 px de alto) fica dentro da moldura do botão, sem a pisar
		_fit_text(b, ICON_GAP, true)  # os nomes compridos em duas linhas, com a letra dos outros
		if id != "":
			for st in ["icon_normal_color", "icon_focus_color", "icon_hover_color", "icon_pressed_color"]:
				b.add_theme_color_override(st, Loot.TINT.get(id, Color.WHITE))
		if id == now:
			b.add_theme_color_override("font_color", Color(0.45, 1.0, 0.65))  # a posta, a verde
		_two_tap(b, "pôr", func(): _act(main, "set_form", [id], func(_msg):
			if panel != null:  # Lote 9 C (c): sem nota (o botão da alma já diz qual ficou): ele acende
				open_forge(7, back)
				var row = get_viewport().gui_get_focus_owner()
				if row != null:
					_pop(row)))
		b.focus_entered.connect(func(): desc.text = info)
	_close_button(box, 608.0)
	var at: int = (main.forms + [""]).find(now)
	grid.get_child(maxi(at, 0)).grab_focus()


## Gasta na Forja (no convidado pede-o ao anfitrião) e volta a ela com o que aconteceu.
func _forge(kind: String, row: int, back: Callable) -> void:
	_act(main, "use_currency", [kind], func(msg):
		if panel != null:
			open_forge(row, back, msg))


## Uma escolha da Forja ([texto, o que gastar, o que o 2.º toque faz]): os dois sufixos do Formão ou as três pilhas da Pena
## (pode queimar a pilha toda). Dois toques (H1): o 1.º só arma o botão e diz qual ("Outra vez: arriscar Ossos Ancestrais"), o 2.º gasta.
func _forge_pick(title: String, info: String, opts: Array, row: int, back: Callable) -> void:
	var box := _open_panel(title, true, open_forge.bind(row, back))
	_text(box, info, Color(0.62, 0.78, 0.68))
	var btns := []
	for i in opts.size():
		btns.append(_two_tap(_button(box, opts[i][0], func(): pass), opts[i][2], _forge.bind(opts[i][1], row, back)))
	_close_button(box)
	btns[0].grab_focus()


## Forja contínua (#100): os 8 sufixos em duas colunas; o escolhido gasta Tinteiros até sair (main.forge_until). O foco ou o
## toque dizem o que o sufixo faz; o 1.º toque arma o botão ("Outra vez: forjar") e só o 2.º gasta (um toque gastava até 200 às cegas).
func _forge_until(back: Callable) -> void:
	var box := _open_panel("Forja contínua", true, open_forge.bind(2, back))
	_text(box, "Escolhe um sufixo: gastam-se Tinteiros, um a um, até ele sair.", Color(0.62, 0.78, 0.68))
	var grid := GridContainer.new()
	grid.columns = 2
	grid.add_theme_constant_override("h_separation", 8)
	box.add_child(grid)
	var desc := RichTextLabel.new()
	desc.bbcode_enabled = true
	desc.fit_content = false
	desc.scroll_active = false
	desc.custom_minimum_size = Vector2(608.0 * text_k, Gothic.BODY.get_height(roundi(Gothic.BODY_SIZE * text_k)) * 3)  # altura fixa: a da Podridão, a mais comprida, tem 3 linhas
	desc.add_theme_color_override("default_color", Color(0.8, 0.8, 0.75))
	box.add_child(desc)
	for s in main.SUFFIXES:
		var info := "[color=#%s]%s[/color]: %s" % [Color(0.95, 0.85, 0.6).to_html(false), tr(s), tr(WEAPON_INFO[s])]
		var b := _button(grid, s, func(): desc.text = info, null, 300.0)
		_two_tap(b, "forjar", func(): _act(main, "forge_until", [s], func(msg):
			if panel != null:
				open_forge(2, back, msg)))
		b.focus_entered.connect(func(): desc.text = info)
	_close_button(box, 608.0)
	grid.get_child(0).grab_focus()


## As cargas de uma poção: inteiras sem casas ("3", nunca "3,0"); a meio, com elas ("2,25").
func _charges(n: float) -> String:
	return str(roundi(n)) if is_equal_approx(n, roundf(n)) else _dec(n)


## Número com vírgula em português e ponto em inglês.
func _dec(x: float, places := 2) -> String:
	var s := String.num(x, places)
	return s.replace(".", ",") if TranslationServer.get_locale().begins_with("pt") else s


func _spend(kind: String) -> void:
	_act(main, "use_currency", [kind], func(msg):
		if msg in SPEND_FAIL:  # acabou o dinheiro (ou não há nada para revelar): o segurar para aqui
			hold_kind = ""
		if panel != null and is_instance_valid(panel):
			open_forge({"ink": 0, "ash": 4, "bone": 6}[kind], sub_back, msg)  # o mesmo botão, no mesmo sítio, com o que aconteceu na nota
		else:
			toast(msg))


func _hold_buy(kind: String) -> void:
	if hold_kind == kind and hold_t == HOLD_FIRST:  # o toque e o rato que o Godot faz dele carregavam os dois no mesmo quadro (o 2.º depois de o painel se refazer): duas compras por toque
		return
	hold_kind = kind
	hold_t = HOLD_FIRST
	_spend(kind)


## O painel refaz-se a cada compra (o botão segurado desaparece), por isso o segurar vê-se pelo dedo, rato ou A ainda em
## baixo (no telemóvel o toque também conta como rato) e não pelo botão.
func _hold_buy_tick(delta: float) -> void:
	if hold_kind == "":
		return
	if panel == null or not (Input.is_mouse_button_pressed(MOUSE_BUTTON_LEFT) or Input.is_action_pressed("ui_accept")):
		hold_kind = ""
		return
	hold_t -= delta
	if hold_t <= 0.0:
		hold_t = HOLD_STEP
		_spend(hold_kind)


## Muda o jogo e depois refaz o painel. No convidado da Wi-Fi quem muda é o anfitrião: after corre quando
## a resposta chega, já com o jogo mudado.
func _act(who, method: String, args: Array, after: Callable) -> void:
	if Net.is_guest():
		Net.ask(-1 if who == main else who.slot, method, args, after)
	else:
		after.call(who.callv(method, args))


## Cortejo Fúnebre: o caminho das ondas até ao Arauto, os afixos em cartões (os das ondas anteriores
## ficam presos) e o saque da próxima onda, que sobe à medida que se junta perigo.
## step: a seta do Círculo que reabriu o menu (fica com o foco do comando).
func open_cortejo(step := 0) -> void:
	var w: int = main.cortejo.wave
	var box := _open_panel("Cortejo Fúnebre")
	var picks := {}
	var chosen := func() -> Array:
		return picks.keys().filter(func(k): return picks[k].button_pressed)
	var track := Control.new()
	track.custom_minimum_size = Vector2(620, 66)
	track.draw.connect(func(): _draw_track(track, w))
	box.add_child(track)
	var arrows := {}
	if w == 0:  # Círculos (#27): escolhe-se antes da 1.ª onda; os selos do círculo mudam com ele
		var row := HBoxContainer.new()
		row.add_theme_constant_override("separation", 8)
		box.add_child(row)
		var go_to := func(d: int):
			main.circle = clampi(main.circle + d, 1, main.circle_max)
			open_cortejo(d)
		for d in [-1, 1]:
			var b := _button(row, "", go_to.bind(d), null, 56.0)
			b.name = "circle_prev" if d < 0 else "circle_next"
			b.disabled = main.circle + d < 1 or main.circle + d > main.circle_max
			b.draw.connect(func():  # seta desenhada: a letra gótica não tem ◀ ▶
				var c := b.size / 2.0
				b.draw_colored_polygon(PackedVector2Array([c + Vector2(9 * d, 0), c + Vector2(-6 * d, -10), c + Vector2(-6 * d, 10)]),
					Color(0.95, 0.85, 0.55, 0.35 if b.disabled else 1.0)))
			arrows[d] = b
			if d == -1:
				var label := Control.new()
				label.custom_minimum_size = Vector2(170, 52)
				label.draw.connect(func(): Gothic.draw_centered(label, 85.0, 36.0, tr("Círculo %d") % main.circle, 26, Color(1.0, 0.85, 0.4), 5))
				row.add_child(label)
		var wins := Label.new()
		wins.text = tr("Vitórias %d\nRecompensa ×%.1f") % [main.wins, main.circle_loot()]  # em 2 linhas: numa, com o "Provações e modos…", o painel alargava e tapava os botões redondos de cima
		wins.custom_minimum_size.y = 52
		wins.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
		wins.add_theme_color_override("font_color", Color(0.8, 0.8, 0.75))
		row.add_child(wins)
		var dare := _button(row, "Provações e modos…", open_challenges, null, 0.0)  # as Provações (S8), na fila do Círculo (o menu cabe nos 720 px); aceso com uma escolhida
		dare.toggle_mode = true
		dare.button_pressed = main.trial != ""
	_text(box, tr("Escolhe os afixos da onda %d. Ficam até ao fim do Cortejo: mais perigo, mais saque.") % (w + 1))
	var grid := GridContainer.new()
	grid.columns = 2
	grid.add_theme_constant_override("h_separation", 8)
	grid.add_theme_constant_override("v_separation", 6)
	grid.size_flags_horizontal = Control.SIZE_SHRINK_CENTER  # ao meio, se a fila do Círculo for mais larga
	box.add_child(grid)
	var reward := Control.new()
	reward.custom_minimum_size = Vector2(620, 76)
	reward.draw.connect(func(): _draw_reward(reward, w + 1, chosen.call()))
	for k in main.affix_cards():  # S8: 6 dos 11, à vez
		var b := _affix_card(k)
		if k in main.cortejo.affixes or k in main.circle_seals():
			b.button_pressed = true
			b.disabled = true
			b.add_theme_stylebox_override("disabled", _sbt(UI.btn_on, Color(0.7, 0.7, 0.7)))
			# presos desde a onda anterior (ou selos do Círculo): lêem-se como ativos, não como indisponíveis
			b.add_theme_color_override("font_disabled_color", Color(0.65, 0.9, 0.7))
			b.add_theme_color_override("icon_disabled_color", Color.WHITE)
		b.toggled.connect(func(_on): reward.queue_redraw())
		picks[k] = b
		grid.add_child(b)
	box.add_child(reward)
	var go := func():
		var sel: Array = chosen.call()
		close_panel()
		main.start_wave(sel)
	var start := _button(box, tr("Invocar a onda %d") % (w + 1), go)
	start.add_theme_font_override("font", Gothic.FONT)
	start.add_theme_font_size_override("font_size", Gothic.px(26))
	start.custom_minimum_size.y = 52
	if w > 0:
		var stop := func():
			main.end_cortejo()
			close_panel()
		var gap := Control.new()  # A1: o Encerrar afastado do Invocar, e com dois toques
		gap.custom_minimum_size.y = 14
		box.add_child(gap)
		_two_tap(_button(box, "Encerrar o Cortejo (guardas o que já caiu)", func(): pass), "encerrar", stop)
	else:
		_close_button(box, 560.0, "Recuar")
	(arrows[step] if arrows.has(step) and not arrows[step].disabled else start).grab_focus()
	if w > 0:  # A1: abriu sozinho entre ondas, por cima das poções: o dedo e o A da luta não carregam em nada durante 0,6 s
		_shield(0.6, start)


## Um cartão de afixo do menu do Cortejo: o nome e a descrição, em 2 linhas a 100% do texto (o teste confere-o).
func _affix_card(k: String) -> Button:
	var b := Button.new()
	b.toggle_mode = true
	b.text = "%s\n%s" % [tr(main.AFFIXES[k][0]), tr(main.AFFIXES[k][1])]
	b.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART  # com o texto maior, dobram dentro do cartão
	b.icon = _trim(AFFIX_ICON[k])
	b.add_theme_constant_override("icon_max_width", 40)
	b.alignment = HORIZONTAL_ALIGNMENT_LEFT
	b.custom_minimum_size = Vector2(308, 60)
	return b


## Desafios (S8): as Provações (#37, #214) para o próximo Cortejo, uma de cada vez (tocar na acesa apaga-a), e os dois
## modos, que começam já: o Mausoléu Sem Fim (#27) e o Santuário dos Deuses Cadavéricos (#50). Só o anfitrião abre o menu
## do Cortejo: o convidado vê o aviso de que ele está num menu.
## focus: a Provação acabada de tocar (fica com o foco do comando).
func open_challenges(focus := "") -> void:
	var outer := _open_panel("Provações e modos", true, open_cortejo)
	var box := _scroll_list(outer, 600.0, CHALLENGE_H)  # Lote 9: 2 Provações e 4 modos já não cabem nos 720 px: a lista rola (o foco do comando leva-a)
	_text(box, "Provações · uma de cada vez, dura o Cortejo inteiro", Color(1.0, 0.85, 0.4))  # B6: os títulos a dourado
	var first: Button = null
	for id in main.TRIALS:
		var solo: bool = id == "almas" and main.players.size() > 1  # sem frascos a dois não dá: só a solo
		var b := _button(box, tr(main.TRIALS[id][0]) + ("  —  " + tr("Só a solo") if solo else ""), func():
			main.trial = "" if main.trial == id or (id == "almas" and main.players.size() > 1) else id  # o 2.º jogador pode ter entrado com o painel aberto
			open_challenges(id))
		b.set_meta("cut", false)  # a lista à vista nunca acaba entre o botão e a explicação dele
		b.toggle_mode = true
		b.button_pressed = main.trial == id
		b.disabled = solo
		if not solo and (first == null or id == focus):
			first = b
		_note(box, main.TRIALS[id][1], solo)
	# os modos não são Provações (não começa nenhuma com eles); fechados, dizem porquê
	var block: String = main.mode_block()
	_text(box, "Modos · começam já", Color(1.0, 0.85, 0.4))
	box.get_child(box.get_child_count() - 1).set_meta("cut", false)
	for m in [[tr("Descer ao Mausoléu Sem Fim — recorde: piso %d") % main.deep if main.deep > 0 else tr("Descer ao Mausoléu Sem Fim — nunca desceste"), "Abre depois da primeira vitória." if main.wins < 1 else block,
			"Pisos de 40 s sem fim e uma maldição a cada 5. Cair acaba a descida, sem túmulo.", main.start_mausoleum],
			["Santuário dos Deuses Cadavéricos (4 leis)", "Abre no Círculo 6." if main.circle_max < 6 else block,
			"Um deus com 4 leis que mudam a cura e o custo das habilidades.", main.start_sanctum],
			["Os Reis Caídos (três chefes)", "Abre no Círculo 4." if main.circle_max < 4 else block,  # Lote 9, #34
			"Três reis coroados que trocam de armas a cada quarto da vida. Dão uma peça rara a cada herói.", main.start_kings],
			["Amálgama Primordial (o último chefe)", "Abre depois da primeira vitória no Santuário." if main.gods < 1 else block,  # #220
			"Cinco chefes numa só alma: veste outro a cada quinto da vida, e no fim a arena fecha.", main.start_amalgama]]:
		var go: Callable = m[3]
		var b := _button(box, m[0], func():
			close_panel()
			go.call())
		b.set_meta("cut", false)
		b.disabled = m[1] != ""
		_note(box, m[1] if b.disabled else m[2], b.disabled)
	var back := _button(outer, "Voltar", open_cortejo)
	(first if first != null else back).grab_focus()


## Lote 10 C (c): uma lista que rola, com w de largura (os botões dela da largura do Voltar: sem barra ao lado) e no máximo h de
## altura, cortada no fim de uma linha (nunca a meio: os filhos com a meta "cut" a false não acabam a vista); por baixo, uma
## seta em píxeis enquanto houver mais para baixo e, na mesma fila, outra a apontar para cima enquanto houver mais para cima
## (revisão final: no fim da Bolsa não se sabia que havia mais em cima; numa fila por cima da lista, os painéis cresciam 20 px
## e tapavam as placas dos heróis). Pára sempre no início de uma entrada: o dedo que larga a meio vai para a mais perto, e o
## fim da lista acaba com uma entrada inteira em cima (a lista ganha o que falta por baixo da última). O dedo, a roda e o foco
## do comando rolam-na. Devolve a caixa das linhas. Nas listas "even" (o Atlas) não há a seta de cima.
func _scroll_list(parent: Control, w: float, h: float) -> VBoxContainer:
	var sc := ScrollContainer.new()
	sc.custom_minimum_size = Vector2(w, h)
	sc.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	sc.vertical_scroll_mode = ScrollContainer.SCROLL_MODE_SHOW_NEVER  # a seta diz que há mais; a barra fininha tirava 12 px aos botões
	sc.follow_focus = true
	var list := VBoxContainer.new()
	list.add_theme_constant_override("separation", 6)
	list.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	sc.add_child(list)
	parent.add_child(sc)
	license_scroll = sc
	var cue := Control.new()
	cue.custom_minimum_size = Vector2(w, 14)
	cue.set_meta("scroll", sc)
	var bar := sc.get_v_scroll_bar()
	cue.draw.connect(func():  # um triângulo dourado em células de 4 px por cada lado onde há mais: sozinho ao meio, os dois lado a lado
		var dirs: Array = ([-1] if bar.value > 1.0 and not list.has_meta("even") else []) + ([1] if bar.max_value - bar.page > bar.value + 1.0 else [])
		cue.set_meta("dirs", dirs)  # para o teste
		for i in dirs.size():
			cue.draw_set_transform(Vector2(cue.size.x / 2.0 + (i - (dirs.size() - 1) / 2.0) * 48.0, 8.0), 0.0, Vector2(2, 2))
			_pix_tri(cue, Vector2.ZERO, dirs[i], Color(1.0, 0.85, 0.4))
		cue.draw_set_transform(Vector2.ZERO))
	parent.add_child(cue)
	scroll_cue = cue
	bar.value_changed.connect(func(_v): cue.queue_redraw())
	bar.changed.connect(cue.queue_redraw)
	var starts := func() -> Array:  # onde a vista pode começar: no início de cada entrada (a explicação de um botão não começa a vista)
		var kids := list.get_children()
		return range(kids.size()).filter(func(i): return i == 0 or kids[i - 1].get_meta("cut", true)).map(func(i): return kids[i].position.y)
	sc.scroll_ended.connect(func():  # o dedo largou (e o embalo acabou): a entrada mais perto fica inteira no cimo
		var at: float = sc.scroll_vertical
		var best := 0.0
		for t in starts.call():
			if t <= bar.max_value - bar.page + 0.5 and absf(t - at) < absf(best - at):
				best = t
		if roundi(best) != sc.scroll_vertical:  # escrever no scroll_vertical volta a dar o sinal (o Godot só o apaga depois): só uma vez
			sc.scroll_vertical = roundi(best))
	list.sort_children.connect(func():  # a altura à vista acaba no fim da última linha inteira que cabe em h
		if list.has_meta("even"):
			_even_rows(list, sc)
			cue.queue_redraw()
			return
		var fit := 0.0
		var end := 0.0
		for c in list.get_children():
			end = maxf(end, c.position.y + c.size.y)
			if c.get_meta("cut", true) and c.position.y + c.size.y <= h + 0.5:
				fit = maxf(fit, c.position.y + c.size.y)
		if fit > 0.0:
			sc.custom_minimum_size.y = fit
		var pad := 0.0  # o fim da lista: a primeira entrada a partir da qual o resto cabe à vista fica no cimo, inteira
		if fit > 0.0 and end > fit + 0.5:
			for t in starts.call():
				if end - t <= fit + 0.5:
					pad = t + fit
					break
		list.custom_minimum_size.y = pad
		cue.queue_redraw())
	return list


## Lote 12 C (a): o Atlas: cada nó da altura do maior e, à vista, um nó inteiro (com o maior à vista, a fila de botões de baixo
## dos outros ficava cortada, só com os debruns de cima). Se o painel passasse da altura do ecrã (o tecto "cap", do
## open_gate), à vista fica menos, mas nunca a meio da metade de cima de um botão.
func _even_rows(list: VBoxContainer, sc: ScrollContainer) -> void:
	var tall := 0.0
	for c in list.get_children():
		tall = maxf(tall, c.size.y)
	for c in list.get_children():
		c.custom_minimum_size.y = tall
	var h: float = minf(tall, list.get_meta("cap", INF))
	var moved := true
	while moved and h > 0.0:
		moved = false
		for r in list.get_children():
			for b in r.find_children("*", "Button", true, false):
				var top: float = (r.get_global_transform().affine_inverse() * b.get_global_transform()).origin.y
				if top < h and h < top + b.size.y * 0.5:
					h = top - 2.0
					moved = true
	sc.custom_minimum_size.y = maxf(h, 0.0)


## A explicação por baixo de um botão dos Desafios (apagada com o botão fechado).
func _note(box: Control, text: String, dim: bool) -> void:
	var l := Label.new()
	l.text = text
	l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	l.custom_minimum_size.x = 560.0
	l.add_theme_color_override("font_color", Color(0.5, 0.5, 0.48) if dim else Color(0.75, 0.75, 0.7))
	box.add_child(l)


## B6: ao subir dos Sepulcros com alguma coisa, o que se trouxe, até onde se chegou e o recorde (só no anfitrião; o convidado
## recebe o aviso, main.sep_leave).
func open_run_end(got: Dictionary, reached: int, best: int, record: bool) -> void:
	card_t = 0.0  # o cartão vermelho "Profundidade N" da última sala espreitava por cima do painel
	var box := _open_panel("De volta ao cemitério")
	var coins := {}  # as 3 moedas do ecrã com os ícones delas; o resto por extenso (até 15 tipos saíam da moldura, e a Estaca, o Óleo e as Cinzas Maiores têm ícones de outras)
	var rest := []
	for k in got:
		if k in ["bone", "ink", "ash"]:
			coins[k] = got[k]
		elif got[k] > 0:
			rest.append("%s x%d" % [tr(Loot.INFO[k][0]), got[k]])
	var row := Control.new()
	row.custom_minimum_size = Vector2(560, 0 if coins.is_empty() else 40)
	row.draw.connect(func(): _draw_currency(row, 6.0, 32.0, coins))
	row.set_meta("got", got)  # para o teste
	box.add_child(row)
	if not rest.is_empty():
		_text(box, ", ".join(rest))
		var l: Label = box.get_child(box.get_child_count() - 1)
		l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		l.custom_minimum_size.x = 560.0
		l.set_meta("rest", rest)  # para o teste
	_text(box, tr("Chegaste à profundidade %d.") % reached)
	if record:  # o recorde é a mais funda vencida, não a que se pisou: diz-se, para não parecer que não bate certo
		_text(box, tr("Novo recorde: venceste a profundidade %d!") % best, Color(1.0, 0.85, 0.4))
	elif best > 0:
		_text(box, tr("Recorde: venceste a profundidade %d.") % best)
	_shield(0.6, _button(box, "Continuar", close_panel))  # H2: no co-op abre com o toque do outro, a meio da luta


## Mausoléu Sem Fim (#27): a cada 5 pisos, uma das 5 maldições (os selos do Círculo), que se somam até ao fim da descida;
## ou sair, com tudo o que se apanhou. Não se fecha sem escolher. Só o anfitrião a vê (o convidado vê que está num menu).
func open_curses() -> void:
	var box := _open_panel(tr("Mausoléu Sem Fim — piso %d") % main.mausoleum, false)
	_text(box, "Escolhe uma maldição: somam-se até ao fim da descida.")
	var first: Button = null
	for k in main.SEALS:
		var n: int = main.curses.count(k) + 1
		var b := _button(box, "%s — %s" % [tr(main.AFFIXES[k][0]), tr(CURSE_TEXT.get(k, main.AFFIXES[k][1]))] + (" ×" + str(n) if n > 1 else ""), func():
			main.curses.append(k)
			close_panel())
		b.icon = _trim(AFFIX_ICON[k])
		if first == null:
			first = b
	_two_tap(_button(box, "Sair do Mausoléu (guardas tudo)", func(): pass), "sair", func():
		close_panel()
		main.end_mode())
	first.grab_focus()
	_shield(0.6, first)  # A1: abre sozinho a meio da luta


## #185 Atlas dos Sepulcros (Lote 11): o Portão dos Reis abre este mapa, também na 1.ª ida (com um nó só). Uma coluna de nós
## ligados por estacas de osso, um por bloco de 5 profundidades até ao primeiro por vencer, o mais fundo em cima: o aspeto, os
## guardiões (o retrato é o da próxima ida), as regras, o ponto de partida (sem o bónus de seguidas) e as 4 melhorias que as
## Estacas Fúnebres compram (dois toques, H1). Com Óleo de Lápide, o 1.º botão unge a ida que se começar (#227, dois toques).
## Só o anfitrião o vê (o convidado vê que está num menu). focus: a profundidade do ponto de partida a escolher (0 = o mais fundo).
func open_gate(focus := 0, note := "") -> void:
	var why: String = main.mode_block()
	if why != "":  # a meio de um Cortejo, de um evento ou de um modo nem abre: diz porquê (como o sep_enter)
		toast(why)
		return
	if panel_title != "Atlas dos Sepulcros":
		gate_oil = false  # aberto de fresco: o óleo por armar
	var box := _open_panel("Atlas dos Sepulcros")
	var w: float = ATLAS_W * maxf(text_k, 1.0)
	var line := func(text: String, col: Color) -> void:
		var l := Label.new()
		l.text = text
		l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		l.custom_minimum_size.x = w
		l.add_theme_color_override("font_color", col)
		box.add_child(l)
	line.call(tr("Recorde: venceste a profundidade %d.") % main.sep_max if main.sep_max > 0 else tr("Vence o guardião da profundidade 5 para começares mais fundo."), Color(0.8, 0.8, 0.75))
	line.call(tr("Estacas Fúnebres: %d (uma por guardião, na primeira vitória)") % main.mats.get("estaca", 0), Color(0.62, 0.78, 0.68))
	if note != "":
		line.call(note, Color(0.45, 1.0, 0.65))
	var btns := {}
	var oil: int = main.mats.get("oleo_lapide", 0)
	if oil > 0 and gate_oil:
		line.call(tr("Óleo de Lápide pronto: a ida que começares agora vai untada."), Color(1.0, 0.85, 0.4))
	elif oil > 0:
		var ob := _button(box, tr("Ungir com Óleo de Lápide (%d): 4 elites colossais, relicários ×1,5") % oil, func(): pass, Loot.TEX.oleo_lapide, w)
		_fit_text(ob, ICON_GAP)  # antes do H1: o tamanho da letra que ele repõe ao desarmar
		btns[-1] = _two_tap(ob, "ungir", func():
			gate_oil = true
			open_gate())
	var list := _scroll_list(box, w, ATLAS_H)
	list.set_meta("even", true)
	var pc := panel
	pc.resized.connect(func():  # Lote 12 C (a): mais alto do que o ecrã, a lista à vista encolhe o que sobra
		var over: float = pc.size.y - root.get_viewport_rect().size.y
		if over > 0.5:
			list.set_meta("cap", list.get_parent().size.y - over)
			list.queue_sort())
	var last: int = mini(main.sep_max / 5, main.ATLAS_MAX - 1)
	for b in range(last, -1, -1):
		_atlas_node(list, b, w, b == last, b == 0, btns)
	_close_button(box, w)
	(btns[focus] if btns.has(focus) else btns[last * 5 + 1]).grab_focus()  # as chaves: a profundidade dos pontos de partida, -1 o Óleo, -(10 x bloco + melhoria + 2) as melhorias


## Lote 12 C (b): o ecrã sem os botões redondos de cima (Árvore, Arsenal, Menu), sem as moedas do 1.º jogador (revisão do L12:
## os Tinteiros e as Cinzas ficavam cortados a meio) e, em co-op, sem o 2.º jogador, com 8 px de folga: o Atlas, largo, tapava-os.
func free_rect() -> Rect2:
	var vs := root.get_viewport_rect().size
	var top: float = maxf(plates()[0].end.y, overlay.global_position.y + p2_steady.end.y) + 8.0
	var right: float = top_bar.get_global_rect().position.x - 8.0 if top_bar.visible else vs.x - 8.0
	return Rect2(8.0, top, right - 8.0, vs.y - 8.0 - top)


## #185: um nó do Atlas, o bloco b (profundidades 5b+1 a 5b+5). À esquerda o guardião da próxima ida na estaca de osso que
## liga os nós (já visto, a cores com o contorno claro, como no Livro dos Chefes; por ver, à sombra; o losango dourado diz
## que o bloco já foi vencido); à direita o resto. top/bottom: o primeiro e o
## último da coluna (a estaca não passa deles).
func _atlas_node(list: Control, b: int, w: float, top: bool, bottom: bool, btns: Dictionary) -> void:
	var d0: int = b * 5 + 1
	var blk: Dictionary = main.sep_block(d0)
	var guards: Array = blk.guard
	var next: String = guards[(main.sep_runs + 1) % guards.size()]  # o da próxima ida (o sep_enter soma a ida antes da chave)
	var beaten: bool = main.sep_max >= d0 + 4
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 12)
	var left := Control.new()
	left.custom_minimum_size.x = 88.0
	var look: String = "donzela_l" if next == "donzelas" else next
	var pic := _shadow_pic(_trim(Enemy.FRAMES32[main.Bosses.spawn_kind(next)][16]), Vector2(72, 72), (main.Bosses.INFO[look][3] if main.Bosses.INFO.has(look) else Color.WHITE) if main.beaten.has(next) else Color.TRANSPARENT)
	pic.position = Vector2(8, 10)
	left.add_child(pic)
	left.set_meta("atlas", b)  # para o teste
	left.draw.connect(_draw_stake.bind(left, top, bottom, beaten))
	row.add_child(left)
	var col := VBoxContainer.new()
	col.add_theme_constant_override("separation", 4)
	row.add_child(col)
	list.add_child(row)  # já na árvore: o _fit_text dos botões mede com a letra do tema (fora dela media com a de origem e o preço saía do botão)
	var cw: float = w - 100.0
	var who := func(g: String) -> String: return tr(main.Bosses.BOOK.get(g, main.Bosses.INFO.get(g, ["", ""]))[0]) + (" " + tr("(a seguir)") if g == next and guards.size() > 1 else "")
	var rules: String = tr("Uma destas regras por profundidade: %s") % ", ".join(blk.rules.map(func(r): return tr(main.CRYPT_RULES[r][0])))
	if blk.guard_rule != "":
		rules += ". " + tr("Com o guardião: %s") % tr(main.CRYPT_RULES[blk.guard_rule][0])
	for l in [[tr("%s · profundidades %d a %d") % [tr(blk.name), d0, d0 + 4], Color(1.0, 0.85, 0.4) if beaten else Color(0.95, 0.9, 0.8)],
			[(tr("Guardiões: %s") if guards.size() > 1 else tr("Guardião: %s")) % ", ".join(guards.map(who)), Color(0.75, 0.75, 0.7)], [rules, Color(0.55, 0.7, 0.62)]]:
		var lb := Label.new()
		lb.text = l[0]
		lb.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		lb.custom_minimum_size.x = cw
		lb.add_theme_color_override("font_color", l[1])
		col.add_child(lb)
	btns[d0] = _button(col, tr("Começar na profundidade %d") % d0, func():
		var o := gate_oil
		gate_oil = false
		close_panel()
		main.sep_enter(d0, o), null, cw)
	var grid := GridContainer.new()
	grid.columns = 2
	grid.add_theme_constant_override("h_separation", 8)
	grid.add_theme_constant_override("v_separation", 6)
	col.add_child(grid)
	var est: int = main.mats.get("estaca", 0)
	for id in main.ATLAS_UP:
		var up: Array = main.ATLAS_UP[id]
		var has: bool = main.atlas_has(b, id)
		var ub := _button(grid, tr(up[0]) if has else (tr("%s (%d estaca)") if up[1] == 1 else tr("%s (%d estacas)")) % [tr(up[0]), up[1]], func(): pass, null, (cw - 8.0) / 2.0)  # sem ícone: o osso da Estaca lia-se como os Ossos
		ub.custom_minimum_size.y = 46.0
		_fit_text(ub, 0.0, true)
		ub.set_meta("up", id)
		if has:  # comprada: a verde, sem a conta
			ub.disabled = true
			ub.add_theme_color_override("font_disabled_color", Color(0.45, 1.0, 0.65))
		elif est < up[1]:
			ub.disabled = true
		else:
			_two_tap(ub, "comprar", func():  # o foco fica na melhoria: com o comando, um 3.º A já não começava a ida
				open_gate(-(10 * b + main.ATLAS_UP.keys().find(id) + 2), tr("Comprado: %s (profundidades %d a %d).") % [tr(up[0]), d0, d0 + 4] if main.buy_atlas(b, id) else ""))
		btns[-(10 * b + main.ATLAS_UP.keys().find(id) + 2)] = ub


## #185: a estaca de osso do Atlas, em células de 2 px como os triângulos: de nó em nó (também por cima da folga entre as
## linhas, para a coluna não se partir) e, por baixo do retrato, o nó: um losango dourado se o guardião já caiu.
func _draw_stake(c: Control, top: bool, bottom: bool, beaten: bool) -> void:
	var x := 42.0
	var dark := Color(0.05, 0.04, 0.03)
	var bone := Color(0.86, 0.8, 0.66)
	var shade := Color(0.55, 0.5, 0.4)
	var runs := []
	if not top:
		runs.append([-6.0, 8.0])
	if not bottom:
		runs.append([98.0, c.size.y + 6.0])
	for r in runs:
		var y: float = r[0]
		while y < r[1]:  # estacas de 14 px com a ponta em baixo, 4 px de folga
			var h: float = minf(14.0, r[1] - y)
			c.draw_rect(Rect2(x - 2.0, y, 8.0, h), dark)
			c.draw_rect(Rect2(x, y, 4.0, h - 2.0), bone)
			c.draw_rect(Rect2(x + 2.0, y, 2.0, h - 2.0), shade)
			y += 18.0
	var gem: Color = Color(1.0, 0.82, 0.35) if beaten else Color(0.45, 0.43, 0.4)
	for i in 4:  # o losango, 2 px de cada vez
		var hw: float = (i if i < 2 else 3 - i) * 2.0 + 2.0
		c.draw_rect(Rect2(x + 2.0 - hw - 2.0, 84.0 + i * 2.0, hw * 2.0 + 4.0, 2.0), dark)
		c.draw_rect(Rect2(x + 2.0 - hw, 84.0 + i * 2.0, hw * 2.0, 2.0), gem)


## Caminho das ondas: as feitas a verde, a próxima a brilhar, a última com o chefe ao lado (o Arauto ou, um Cortejo
## sim, outro não, o Guardião dos Monumentos, como em main._boss_intro).
func _draw_track(ci: Control, done: int) -> void:
	var guard: bool = main.wins % 2 == 1
	var y := 24.0
	var xs := [110.0, 300.0, 490.0]
	ci.draw_line(Vector2(xs[0], y), Vector2(xs[2], y), Color(0.3, 0.27, 0.22), 4.0)
	if done > 0:
		ci.draw_line(Vector2(xs[0], y), Vector2(xs[mini(done, 2)], y), Color(0.4, 1.0, 0.6), 4.0)
	for i in 3:
		var c := Vector2(xs[i], y)
		var col := Color(0.4, 1.0, 0.6) if i < done else (Color(1.0, 0.85, 0.4) if i == done else Color(0.4, 0.37, 0.32))
		ci.draw_circle(c, 15.0, Color(0.06, 0.07, 0.07))
		ci.draw_arc(c, 15.0, 0, TAU, 24, col, 3.0)
		if i < done:
			ci.draw_circle(c, 8.0, col)
		elif i == done:
			ci.draw_arc(c, 21.0, 0, TAU, 24, Color(col, 0.4), 2.0)
		Gothic.draw_centered(ci, c.x, y + 40.0, ("Guardião" if guard else "Arauto") if i == 2 else tr("Onda %d") % (i + 1), 19, col, 4)
	var h := 62.0
	var ht := _trim(AFFIX_ICON.gemeo if guard else HERALD_TEX)  # o Guardião é um colosso, com a cor dele
	var hw := h * ht.get_width() / ht.get_height()
	ci.draw_set_transform(Vector2(xs[2] + 24 + hw, 0), 0.0, Vector2(-1, 1))  # espelhado: olha para a pista
	ci.draw_texture_rect(ht, Rect2(0, y - h * 0.6, hw, h), false, main.Bosses.INFO.guardiao[3] if guard else Color.WHITE)
	ci.draw_set_transform(Vector2.ZERO)


## Saque da próxima onda com os afixos escolhidos (o mesmo cálculo do jogo) e o perigo em caveiras.
func _draw_reward(ci: Control, w: int, sel: Array) -> void:
	var r: Dictionary = main.wave_rewards(w, sel)
	var head := tr("Saque ×%.1f") % main.reward_mult(sel)
	var y := 28.0
	Gothic.draw(ci, Vector2(6, y), head, 24, Color(1.0, 0.85, 0.4), 5)
	var x := _draw_currency(ci, 18.0 + Gothic.width(head, 24), y, r)
	if w >= main.WAVES:
		Gothic.draw(ci, Vector2(x, y), "no Relicário", 19, Color(0.75, 0.75, 0.7), 4)
	y += 38.0
	Gothic.draw(ci, Vector2(6, y), "Perigo", 22, Color(1.0, 0.4, 0.35), 5)
	for i in main.CARDS:
		ci.draw_texture_rect(SKULLS, Rect2(84 + i * 32, y - 22, 28, 22), false, Color.WHITE if i < sel.size() else Color(0.3, 0.3, 0.3, 0.6))


## Ícones das moedas (e dos reagentes, no túmulo) com as quantidades (as que forem > 0), a partir de x; devolve onde acaba.
func _draw_currency(ci: Control, x: float, y: float, amounts: Dictionary) -> float:
	for k in amounts:
		if amounts[k] <= 0:
			continue
		ci.draw_texture_rect(Loot.TEX[k], Rect2(x, y - 26, 30, 30), false, Loot.TINT.get(k, Color.WHITE))
		Gothic.draw(ci, Vector2(x + 34, y), str(amounts[k]), 24, Color(0.95, 0.9, 0.75), 5)
		x += 52.0 + Gothic.width(str(amounts[k]), 24)
	return x


## O 2.º toque compra mesmo? O convidado só compra no herói dele (net._ask), e a lista dele está ao contrário: conta o slot.
func tree_buys(p) -> bool:
	return not Net.is_guest() or p.slot == 1


## Árvore dos Condenados: raízes e ossadas com a arte da folha SC-ICO4 sobre o fundo SC-TREE.
## Um nó só abre se o nó de que nasce já estiver aberto.
## A folha é maior do que a janela: arrasta-se com o dedo (ou o rato) e segue o nó com foco do comando.
## note (B7): o que se acabou de abrir, a verde no lugar da descrição.
func open_tree(who := 0, focus := "raiz", note := "") -> void:
	var p = main.players[who]
	var box := _open_panel(tr("Árvore dos Condenados — %s") % tr(p.hero_name), true, sub_back)
	var canvas := Control.new()
	canvas.custom_minimum_size = TREE_WIN
	canvas.clip_contents = true
	box.add_child(canvas)
	var sheet := Control.new()  # a folha (TREE_AREA): fundo, raízes e nós com os mesmos pos; desliza dentro da janela
	sheet.mouse_filter = Control.MOUSE_FILTER_IGNORE
	# Com tamanho 0 o Godot deixava de a desenhar quando o canto dela saía do ecrã (em co-op a janela fica mais acima e
	# a Árvore aparecia vazia); com o tamanho da folha, a caixa dela cruza sempre a janela
	sheet.size = TREE_AREA.end
	canvas.add_child(sheet)
	var look := func(v: Vector2) -> void:  # v: o ponto da folha que fica no canto de cima, à esquerda, da janela
		sheet.position = -v.clamp(TREE_AREA.position, TREE_AREA.end - TREE_WIN)
		sheet.queue_redraw()  # os nomes presos à janela seguem o arrasto
	var info := Label.new()
	# Altura fixa de 2 linhas (3 com o texto maior, #99) e texto a quebrar: uma descrição comprida já não alarga a
	# janela a cada nó escolhido
	info.max_lines_visible = 3 if text_k > 1.0 else 2
	info.custom_minimum_size = Vector2(640, ceilf(26.0 * text_k) * info.max_lines_visible)
	info.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	info.add_theme_color_override("font_color", Color(0.95, 0.85, 0.6))
	box.add_child(info)
	var show_txt := func(t: String) -> void:  # a descrição de um nó, na cor de sempre (a nota do que abriu é verde)
		info.text = t
		info.add_theme_color_override("font_color", Color(0.95, 0.85, 0.6))
	var nodes: Dictionary = main.PASSIVES
	var btns := {}
	var armed := [""]  # o nó do 1.º toque (num Array: as funções partilham-no), como nos frascos
	var opening := [true]  # C (h): o foco do abrir não volta a centrar a vista que o tree_view escolheu
	# Busca acesa (#97): os nós achados e, de cada um, o caminho de raízes até ao primeiro nó já aberto
	var hits: Array = tree_matches(find_terms) if not find_terms.is_empty() else []
	var gold := {}
	for id in hits:
		var at: String = id
		while at != "" and not at in p.passives:
			gold[at] = true
			at = nodes[at].req
	sheet.draw.connect(func():
		halo_drawn = false
		tree_labels.clear()
		tree_label_rects.clear()
		sheet.draw_texture_rect(TREE.bg, TREE_AREA, false, Color(0.75, 0.75, 0.75))
		for id in nodes:
			var n: Dictionary = nodes[id]
			if n.req == "":
				continue
			var a: Vector2 = nodes[n.req].pos
			var v: Vector2 = n.pos - a
			sheet.draw_set_transform(a, v.angle())
			sheet.draw_texture_rect(TREE.root_on if id in p.passives else TREE.root, Rect2(0, -8, v.length(), 16), false, Color(1.0, 0.8, 0.3) if gold.has(id) else Color.WHITE)
			sheet.draw_set_transform(Vector2.ZERO)
		var font := Gothic.small_font()  # B1: os nomes na Augusta (ver gothic.gd)
		var fs := Gothic.small_px(17)
		var win := Rect2(-sheet.position, TREE_WIN)
		var hint_at := Vector2.INF
		tree_lit = nodes.keys().filter(func(id): return armed[0] == id or (btns.has(id) and btns[id].has_focus()))  # com o aro do foco à volta
		var named := nodes.keys().filter(func(id): return id in p.passives or (nodes[id].req in p.passives and not p.EXCLUSIVE.get(id, "") in p.passives and nodes[id].get("hero", p.hero) == p.hero) or id in tree_lit)
		var offs: Dictionary = _tree_labels_at(named, font, fs, win, p.passives)  # C (e): os nomes à vista, longe dos aros e uns dos outros
		for id in nodes:
			var n: Dictionary = nodes[id]
			var kind: String = NODE_KIND.get(id, "node")
			var have: bool = id in p.passives
			var open: bool = not have and n.req in p.passives and not p.EXCLUSIVE.get(id, "") in p.passives and n.get("hero", p.hero) == p.hero
			var d: float = NODE_SIZE[kind]
			var col := Color.WHITE if have or open else Color(0.45, 0.45, 0.45)
			if id in hits:
				sheet.draw_circle(n.pos, d * 0.62, Color(1, 0.8, 0.3, 0.5))
			if open and p.points > 0 and tree_buys(p):  # B7: os nós que abrem pulsam, e só com pontos por gastar
				sheet.draw_circle(n.pos, d * 0.56, Color(1.0, 0.85, 0.4, 0.425 + 0.175 * sin(Time.get_ticks_msec() * 0.005)))
				halo_drawn = true
			if tree_pop[0] == id and Time.get_ticks_msec() - tree_pop[1] < 400:  # o que abriu agora: um anel dourado a crescer
				var k: float = (Time.get_ticks_msec() - tree_pop[1]) / 400.0
				sheet.draw_arc(n.pos, d * lerpf(0.6, 0.9, k), 0, TAU, 32, Color(1.0, 0.85, 0.4, 1.0 - k), 4.0)
			sheet.draw_texture_rect(TREE[kind + ("_on" if have else "")], Rect2(n.pos - Vector2(d, d) / 2.0, Vector2(d, d)), false, col)
			if btns.has(id) and btns[id].has_focus():
				sheet.draw_arc(n.pos, d * 0.6, 0, TAU, 32, Color(0.45, 1.0, 0.65), 3.0)
			if armed[0] == id:  # com o dedo o foco não muda: o nó marcado tem de se ver sem ele
				sheet.draw_arc(n.pos, d * 0.6, 0, TAU, 32, Color(1.0, 0.85, 0.4), 4.0)
				if open and tree_buys(p) and p.points > 0:
					hint_at = n.pos - Vector2(0, d * 0.5 + 8.0)
			if not (have or open or armed[0] == id or (btns.has(id) and btns[id].has_focus())):
				continue  # B7: os nomes só dos nós abertos, dos que abrem e do escolhido (os outros enchiam a folha)
			if not win.intersects(Rect2(n.pos - Vector2(d, d) / 2.0, Vector2(d, d))) or not offs.has(id):
				continue  # e só dos que se veem: o de um nó lá fora, preso à borda, ia parar por cima de outro nó (e, Lote 8 C (h), os sem sítio claro)
			tree_labels.append(id)
			var off = offs[id]
			var ls: Array = tree_lines[id] if off is Vector3 else [tr(n.name)]  # Revisão do Lote 8: os de 2 linhas, cada uma ao meio
			var tw := 0.0
			for l in ls:
				tw = maxf(tw, font.get_string_size(l, HORIZONTAL_ALIGNMENT_LEFT, -1, fs).x)
			var lh := font.get_height(fs)
			var at: Vector2 = (n.pos + Vector2(off.x, off.y)).clamp(win.position + Vector2(4.0, fs), win.end - Vector2(tw + 4.0, 4.0 + lh * (ls.size() - 1)))  # sempre dentro da janela
			tree_label_rects[id] = Rect2(at.x, at.y - font.get_ascent(fs), tw, lh * ls.size())
			for i in ls.size():
				sheet.draw_string_outline(font, at + Vector2(0, lh * i), ls[i], HORIZONTAL_ALIGNMENT_CENTER, tw, fs, 4, Color.BLACK)
				sheet.draw_string(font, at + Vector2(0, lh * i), ls[i], HORIZONTAL_ALIGNMENT_CENTER, tw, fs, col)
		if hint_at != Vector2.INF:  # por cima do nó e dos nomes: a descrição tem altura fixa e cortava o aviso
			var hint := tr("Carrega outra vez para abrir" if gamepad else "Toca outra vez para abrir")  # A5: no ecrã tátil não se carrega
			var hw := font.get_string_size(hint, HORIZONTAL_ALIGNMENT_LEFT, -1, fs).x
			var inside := win.grow_individual(-hw / 2.0 - 8.0, -18.0, -hw / 2.0 - 8.0, -8.0)  # a janela corta a folha: num nó da beira, o aviso ficava cortado
			hint_at = hint_at.clamp(inside.position, inside.end)
			sheet.draw_rect(Rect2(hint_at + Vector2(-hw / 2.0 - 6.0, -fs), Vector2(hw + 12.0, fs + 6.0)), Color(0.05, 0.04, 0.03, 0.92))
			sheet.draw_string(font, hint_at - Vector2(hw / 2.0, 0.0), hint, HORIZONTAL_ALIGNMENT_LEFT, -1, fs, Color(1.0, 0.85, 0.4)))
	var plate := Control.new()  # B7: os pontos por gastar num quadro à direita, na linha do título (por cima da folha tapava os nós); a 0 não aparece
	plate.mouse_filter = Control.MOUSE_FILTER_IGNORE
	plate.visible = p.points > 0
	plate.position = Vector2(TREE_WIN.x - 150.0, 0.0)
	plate.size = Vector2(150.0, 40.0)
	plate.draw.connect(func():
		var pr := Rect2(Vector2.ZERO, plate.size)
		plate.draw_rect(pr, Color(0.05, 0.04, 0.03, 0.85))
		plate.draw_rect(pr, Color(0.55, 0.45, 0.3), false, 2.0)
		var nw := Gothic.width(str(p.points), 32)
		var unit := tr("ponto" if p.points == 1 else "pontos")  # na mesma linha lê-se como frase: "1 ponto"
		var us := Gothic.body_px(22)  # C (e): na Augusta, no tamanho do texto (a 16 de píxeis tinha 9 px)
		var uw := Gothic.BODY.get_string_size(unit, HORIZONTAL_ALIGNMENT_LEFT, -1, us).x
		var x0 := (pr.size.x - nw - 8.0 - uw) / 2.0
		Gothic.draw(plate, Vector2(x0, 32.0), str(p.points), 32, Color(1.0, 0.85, 0.4), 5)
		plate.draw_string_outline(Gothic.BODY, Vector2(x0 + nw + 8.0, 31.0), unit, HORIZONTAL_ALIGNMENT_LEFT, -1, us, 4, Color.BLACK)
		plate.draw_string(Gothic.BODY, Vector2(x0 + nw + 8.0, 31.0), unit, HORIZONTAL_ALIGNMENT_LEFT, -1, us, Color(1.0, 0.85, 0.4)))
	box.get_child(0).add_child(plate)  # a linha do título
	tree_plate = plate
	var empty := StyleBoxEmpty.new()
	for id in nodes:
		var n: Dictionary = nodes[id]
		var d: float = NODE_SIZE[NODE_KIND.get(id, "node")]
		var have: bool = id in p.passives
		# as chaves que se excluem (#108 #117 #140, #11) ficam bloqueadas, e os nós do outro herói (S3) também
		var open: bool = not have and n.req in p.passives and not p.EXCLUSIVE.get(id, "") in p.passives and n.get("hero", p.hero) == p.hero
		var b := Button.new()
		b.flat = true
		b.position = n.pos - Vector2(d, d) / 2.0 - Vector2(12, 12)  # B7: 12 px a mais de cada lado (os nós de 46 px eram difíceis de acertar)
		b.size = Vector2(d, d) + Vector2(24, 24)
		b.mouse_filter = Control.MOUSE_FILTER_PASS  # o toque segue também para a janela, que distingue tocar de arrastar
		for st in ["normal", "hover", "pressed", "focus"]:
			b.add_theme_stylebox_override(st, empty)
		var other: bool = n.get("hero", p.hero) != p.hero  # S3: um nó do outro herói diz de quem é
		var txt: String = "%s — %s%s" % [tr(n.name), tr(n.desc), "" if have or open else "  " + (tr("(só o %s)") % tr(p.HEROES[n.hero].name) if other else tr("(bloqueado)"))]
		b.focus_entered.connect(func():
			show_txt.call(txt)
			if armed[0] != id:
				armed[0] = ""
			# Comando/teclado: a folha desliza até o nó com foco ficar à vista (com o dedo ou o rato em baixo não salta)
			if not opening[0] and not Input.is_mouse_button_pressed(MOUSE_BUTTON_LEFT) and not Rect2(Vector2(60, 60) - sheet.position, TREE_WIN - Vector2(120, 120)).has_point(n.pos):
				look.call(n.pos - TREE_WIN / 2.0)
			sheet.queue_redraw())
		b.mouse_entered.connect(func(): show_txt.call(txt))
		b.pressed.connect(func():
			show_txt.call(txt)
			if armed[0] != id:  # o 1.º toque só mostra o que faz; o 2.º, no mesmo nó, compra (como nos frascos)
				armed[0] = id
				sheet.queue_redraw()
				return
			_act(p, "allocate", [id], func(ok):
				if ok:  # sem comprar não se refaz: tocar só para ler não faz saltar a vista. B7: o que abriu fica escrito, com um anel dourado no nó
					tree_pop = [id, Time.get_ticks_msec()]
					var left: int = p.points
					open_tree(who, id, tr("Abriste %s · ficam %d pontos") % [tr(n.name), left] if left > 1 else tr("Abriste %s · fica 1 ponto") % tr(n.name) if left == 1 else tr("Abriste %s.") % tr(n.name))))
		sheet.add_child(b)
		btns[id] = b
	# Dedo (no PC o rato também chega como toque): arrastar mais de 12 px desliza a folha e larga o toque no nó
	canvas.gui_input.connect(func(e: InputEvent):
		if e is InputEventScreenTouch and e.pressed:
			tree_drag = 0.0
		elif e is InputEventScreenDrag:
			tree_drag += e.relative.length()
			if tree_drag > 12.0:
				canvas.propagate_notification(Control.NOTIFICATION_SCROLL_BEGIN)  # o BaseButton cancela o toque, como num ScrollContainer
				look.call(-sheet.position - e.relative))
	if main.players.size() > 1:
		_button(box, tr("Ver a árvore do %s") % tr(main.players[1 - who].hero_name), func(): open_tree(1 - who))
	var row := HBoxContainer.new()  # Refazer, Procurar e Fechar lado a lado: em co-op mais uma linha passava da altura do ecrã
	box.add_child(row)
	var redo_txt := "Refazer (grátis)" if p.respecs == 0 else "Refazer (1 Tomo)" if main.currency.tomo > 0 else "Refazer (1 Cinza)"  # o Tomo (#61) vai primeiro
	_button(row, redo_txt, func():  # pede confirmação: refazer devolve tudo de uma vez
		var c := _open_panel(tr("Refazer a Árvore"), true, open_tree.bind(who, focus))
		var l := Label.new()
		l.text = "Devolve todos os pontos. A primeira vez é grátis; depois gasta um Tomo dos Nomes Esquecidos se tiveres; senão, 1 Cinza do Purgatório."
		l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		l.custom_minimum_size.x = 560.0
		l.add_theme_color_override("font_color", Color(0.8, 0.8, 0.75))
		c.add_child(l)
		_button(c, redo_txt, func(): _act(p, "respec", [], func(msg):
			if msg is String:  # o convidado não refaz a Árvore do anfitrião (sem resposta)
				toast(msg)
			open_tree(who, focus)))
		_button(c, "Voltar", open_tree.bind(who, focus)).grab_focus(), null, 0.0)
	if find_terms.is_empty():
		_button(row, "Procurar", _tree_find.bind(who, focus), null, 0.0)
	else:
		_button(row, "Limpar busca", func():
			find_terms = []
			find_word = ""
			open_tree(who, focus), null, 0.0)
	_close_button(row, 0.0)
	for b in row.get_children():
		b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	look.call(tree_view(p, focus))  # abre centrada no nó com foco (depois de escolher, reabre no nó escolhido), sem aros cortados (C (h))
	# O comando escolhe o vizinho mais perto em cada direção e nunca chegava ao Canibalismo: à esquerda do Tutano vai lá
	btns.tutano.focus_neighbor_left = btns.tutano.get_path_to(btns.canibal)
	btns.arqueiros.focus_neighbor_right = btns.arqueiros.get_path_to(btns.guardioes)  # e aos Guardiões de Tórax (#11), à direita dos Arqueiros
	btns.ectoplasma.focus_neighbor_right = btns.ectoplasma.get_path_to(btns.imolacao)  # à Imolação, na mesma linha (com a Falange Espectral não se chegava lá)
	btns.exumacao.focus_neighbor_bottom = btns.exumacao.get_path_to(btns.ressurreicao)  # e à Ressurreição de Elites (#179), fora da vista por baixo
	btns[focus].grab_focus()
	opening[0] = false
	tree_sheet = sheet
	tree_btns = btns
	tree_info = info
	if note != "":  # depois do foco, que escreve a descrição do nó
		info.text = note
		info.add_theme_color_override("font_color", Color(0.45, 1.0, 0.65))
	elif not find_terms.is_empty():  # depois do foco, que escreve a descrição do nó (a nota do que abriu vem primeiro)
		info.text = tr("%d nó com «%s»" if hits.size() == 1 else "%d nós com «%s»") % [hits.size(), find_word]
	elif focus == "raiz" and p.points > 0 and tree_buys(p):  # B5: abrir com pontos diz o que fazer com eles
		info.text = tr("Pontos por gastar: %d. Os nós com brilho dourado abrem-se: carrega para ler, carrega outra vez para abrir." if gamepad else "Pontos por gastar: %d. Os nós com brilho dourado abrem-se: toca para ler, toca outra vez para abrir.") % p.points


## C (e): onde fica o nome de cada nó de ids (a linha de base, a contar do centro dele): por baixo, 4 px fora do aro do foco;
## se tocar no aro de algum nó (o dele ou um vizinho) ou num nome já posto, mais abaixo, para o lado ou por cima. Guardado
## pela língua, o tamanho do texto e os nós com nome (mudam ao abrir um nó ou ao escolher outro). Um nome que sairia da janela
## win (o nó está na borda dela) procura outro sítio lá dentro, em vez de ser empurrado para cima de um aro; esse guarda-se
## também pela posição da janela, de 8 em 8 px.
## Lote 8 C (a) e (h): para cada janela, primeiro procura-se um sítio para todos os nomes à vista ao mesmo tempo, cada um num
## dos seus sítios livres (sem aro e mais perto do aro dele) dentro da janela e sem tocar noutro nome (uma procura com volta
## atrás, os nomes com menos sítios primeiro). Só os nomes sem nenhum sítio livre lá dentro (o nó está à borda) passam pelo
## pick; e só se a procura falhar se faz a volta antiga, nome a nome. Arrastar a Árvore custava 7,9 ms por passo de 8 px.
## Revisão do Lote 8: os nós abertos (have) escolhem primeiro (a 130% ficavam sem nome a Hemorragia e as Ossos Densos); um nome
## de várias palavras com menos de 4 sítios livres numa linha também pode ir em 2, mais estreito (depois dos sítios numa linha;
## o deslocamento vem então num Vector3, com as linhas em tree_lines); e dois nomes na mesma linha ficam a uma palavra um do
## outro (_tree_pad).
func _tree_labels_at(ids: Array, font: Font, fs: int, win: Rect2, have := []) -> Dictionary:
	var key := TranslationServer.get_locale() + str(fs) + ",".join(ids) + "|" + ",".join(tree_lit) + "|" + ",".join(have.filter(func(id): return id in ids))
	var wp: Vector2 = win.position.snapped(Vector2(8, 8))
	var wkey := "win_" + key + str(wp)
	tree_gap = fs
	tree_lines = tree_label_at.get(key + "2", {})
	if tree_label_at.has(wkey):
		return tree_label_at[wkey]
	if tree_label_at.size() > 80:  # esquece tudo menos os arranjos deste conjunto de nós (a chave muda com o foco: sem tecto, crescia a cada nó escolhido)
		for k in tree_label_at.keys():
			if not k in [key, key + "#", key + "%", key + "2"]:
				tree_label_at.erase(k)
	var asc := font.get_ascent(fs)
	var h := font.get_height(fs)
	var tw := {}  # [numa linha, em 2]
	var split := func(id: String) -> void:  # as 2 linhas cortam no espaço mais perto do meio
		var nm := tr(main.PASSIVES[id].name)
		var cut := -1
		for i in nm.length():
			if nm[i] == " " and (cut < 0 or absf(i - nm.length() / 2.0) < absf(cut - nm.length() / 2.0)):
				cut = i
		tree_lines[id] = [nm.left(cut), nm.substr(cut + 1)]
		tw[id][1] = maxf(font.get_string_size(tree_lines[id][0], HORIZONTAL_ALIGNMENT_LEFT, -1, fs).x, font.get_string_size(tree_lines[id][1], HORIZONTAL_ALIGNMENT_LEFT, -1, fs).x)
	for id in ids:
		tw[id] = [font.get_string_size(tr(main.PASSIVES[id].name), HORIZONTAL_ALIGNMENT_LEFT, -1, fs).x, 0.0]
		if tree_lines.has(id):
			split.call(id)
	var box := func(id: String, off) -> Rect2:
		if off is Vector3:
			return Rect2(main.PASSIVES[id].pos + Vector2(off.x, off.y - asc), Vector2(tw[id][1], h * 2.0))
		return Rect2(main.PASSIVES[id].pos + off - Vector2(0.0, asc), Vector2(tw[id][0], h))
	var rings := tree_rings()
	var tries_of := func(id: String) -> Array:  # por baixo, um pouco ao lado, à direita, à esquerda e por cima; depois mais longe; e o mesmo em 2 linhas
		var d: float = NODE_SIZE[NODE_KIND.get(id, "node")]
		var r: float = d * RING_K + 2.0 if id in tree_lit else d * 0.5 + 3.0
		var tries := []
		for two in ([false, true] if tree_lines.has(id) else [false]):
			var w: float = tw[id][1 if two else 0]
			var th := h * 2.0 if two else h
			var some := []
			for gap in [4.0, 12.0, 22.0]:
				for k in [0.0, 20.0, -20.0, 40.0, -40.0, 64.0, -64.0]:
					some.append(Vector2(-w / 2.0 + k, r + gap + asc))
				for k in [0.0, -14.0, 14.0, -28.0, 28.0]:  # ao lado, com o meio do nome à altura do nó
					some.append(Vector2(r + gap, asc * 0.5 + k - (th - h) * 0.5))
					some.append(Vector2(-r - gap - w, asc * 0.5 + k - (th - h) * 0.5))
				for k in [0.0, 20.0, -20.0, 40.0, -40.0]:
					some.append(Vector2(-w / 2.0 + k, -r - gap - (th - asc)))
			tries += some.map(func(v): return Vector3(v.x, v.y, 2.0)) if two else some
		return tries
	if not tree_label_at.has(key + "%"):  # os aros a que os sítios de cada nome podem chegar (os de longe nunca tocam)
		var reach_of := {}
		for id in ids:
			var reach: float = tw[id][0] + h + 170.0
			reach_of[id] = rings.filter(func(q): return q[0].distance_to(main.PASSIVES[id].pos) < reach)
		tree_label_at[key + "%"] = reach_of
	var near: Dictionary = tree_label_at[key + "%"]
	# o 1.º sítio livre; sem nenhum, o que toca menos (fora da janela é o pior, depois um aro, depois outro nome, depois, com
	# own, ficar mais perto de outro aro). Cada sítio só soma o resto enquanto ainda pode ganhar ao melhor.
	var pick := func(id: String, others: Array, inside: Rect2, own: bool):
		var tries: Array = tries_of.call(id)
		var best := INF
		var got = tries[0]
		for off in tries:
			var b: Rect2 = box.call(id, off)
			var cost := 0.0 if not inside.has_area() or inside.encloses(b) else 1e8
			if cost >= best:
				continue
			cost += 1e6 if tree_ring_hit(b, near[id]) else 0.0
			if cost >= best:
				continue
			cost += 0.0 if not own or tree_own(id, b, rings) else 1e5
			for q in others:
				if cost >= best:
					break
				var g := _tree_pad(q)
				cost += g.intersection(b).get_area() + (2e5 if g.intersects(b) else 0.0)
			if cost < best:
				best = cost
				got = off
			if cost == 0.0:
				break
		return got
	if not tree_label_at.has(key):  # sem janela: a Árvore toda
		var out := {}
		var placed := []
		for id in ids:
			out[id] = pick.call(id, placed, Rect2(), false)
			placed.append(box.call(id, out[id]))
		tree_label_at[key] = out
		# os sítios livres de cada nome (sem aro e mais perto do aro dele), sem contar com os outros nomes nem com a janela
		var free_of := {}
		var free_at := func(id: String) -> Array: return tries_of.call(id).filter(func(off): return not tree_ring_hit(box.call(id, off), near[id]) and tree_own(id, box.call(id, off), rings))
		for id in ids:
			free_of[id] = free_at.call(id)
			if free_of[id].size() < 4 and " " in tr(main.PASSIVES[id].name):  # com poucos sítios numa linha (só esses: em todos, arrastar custava o dobro), também em 2
				split.call(id)
				free_of[id] = free_at.call(id)
		tree_label_at[key + "#"] = free_of
		tree_label_at[key + "2"] = tree_lines
	var free: Dictionary = tree_label_at[key + "#"]
	var fixed: Dictionary = tree_label_at[key].duplicate()
	var inner := Rect2(wp, win.size).grow(-8.0)  # a de 8 em 8 px pode estar até 4 px ao lado da janela de agora
	# Só os nós que o desenho nomeia (os que cruzam a janela, com folga do passo): os de fora nunca achavam lugar cá dentro
	var seen := ids.filter(func(id): return Rect2(wp, win.size).grow(8.0).intersects(Rect2(main.PASSIVES[id].pos - Vector2.ONE * NODE_SIZE[NODE_KIND.get(id, "node")] / 2.0, Vector2.ONE * NODE_SIZE[NODE_KIND.get(id, "node")])))
	# Lote 8: todos de uma vez, cada um num sítio livre dentro da janela, sem tocar noutro (3 px); os da borda, sem sítio livre
	# lá dentro, ficam para o fim (pick, sem tocar nos que já estão)
	var cand := {}
	var edge := []
	for id in seen:
		var c: Array = []
		for off in free[id]:
			var b: Rect2 = box.call(id, off)
			if inner.encloses(b):
				c.append([off, b])
		if c.is_empty():
			edge.append(id)
		else:
			cand[id] = c
	var order: Array = cand.keys()
	order.sort_custom(func(a, b): return cand[a].size() < cand[b].size() or (cand[a].size() == cand[b].size() and seen.find(a) < seen.find(b)))
	var order_h: Array = order.filter(func(id): return id in have) + order.filter(func(id): return not id in have)  # os abertos primeiro
	for k in 8:  # sem lugar para todos: o menor número de nomes de fora (com o texto grande escondidos), nunca o do nó escolhido e, nas 4 primeiras voltas, nenhum dos abertos
		var skips := k % 4
		if k == 4:
			continue
		var got := {}
		if not _tree_assign(order_h if k in [1, 2, 3] else order, 0, cand, got, [0], skips, tree_lit + (have if k < 4 else [])):
			continue
		var placed := []
		var hide := []
		for id in got:
			if got[id] == null:
				hide.append(id)
				continue
			fixed[id] = got[id][0]
			placed.append(got[id][1])
		for id in edge + (hide if text_k <= 1.0 else []):  # a 100% os de fora também aparecem, no sítio que menos toca
			if text_k > 1.0 and not id in tree_lit:  # com o texto grande escondem-se (_tree_unclear): o pick dele era metade do custo de cada passo a 130%, e o sítio que menos tocava ficava em cima de um aro (Revisão do Lote 8: a Hemofilia em 2 linhas)
				hide.append(id)
				continue
			fixed[id] = pick.call(id, placed, inner, true)
			placed.append(box.call(id, fixed[id]))
		return _tree_unclear(fixed, seen, free, wkey, hide)
	# A volta antiga, nome a nome (a procura falhou: não há lugar livre para todos dentro da janela)
	for id in seen:
		if not inner.encloses(box.call(id, fixed[id])):
			fixed[id] = pick.call(id, seen.filter(func(o): return o != id).map(func(o): return box.call(o, fixed[o])), inner, false)
	# Lote 7 C (d): só agora, com todos no lugar, o nome mais perto de outro aro (ou por cima de outro nome) procura um sítio
	# melhor; nunca troca isso por ficar em cima de outro nome (com o tree_own na 1.ª volta, a 130% os primeiros tiravam o
	# sítio aos outros e ficavam 5 pares de nomes uns por cima dos outros)
	# a volta do aro começa pelos nomes com menos sítios livres, senão os primeiros ficavam com o único sítio de um vizinho
	# apertado (as Veias Abertas ficavam sem nenhum ao lado das Ossos Densos)
	order = seen.duplicate()
	order.sort_custom(func(a, b): return free[a].size() < free[b].size() or (free[a].size() == free[b].size() and seen.find(a) < seen.find(b)))
	var boxes := {}  # onde está cada nome agora (arrastar a Árvore passava dos 10 ms a refazê-los)
	for id in seen:
		boxes[id] = box.call(id, fixed[id])
	for id in order:
		var others := []
		for o in seen:
			if o != id:
				others.append(boxes[o])
		var b0: Rect2 = boxes[id]
		if tree_own(id, b0, rings) and not others.any(func(q): return _tree_pad(q).intersects(b0)):
			continue
		var at = null
		for off in free[id]:  # o 1.º sítio sem custo do pick, sem refazer as contas dos aros
			var q: Rect2 = box.call(id, off)
			if inner.encloses(q) and not others.any(func(o): return _tree_pad(o).intersects(q)):
				at = off
				break
		fixed[id] = at if at != null else pick.call(id, others, inner, true)
		boxes[id] = box.call(id, fixed[id])
	# e um nome que ainda falhe fica com um sítio livre que só toca num outro nome, se esse outro tiver para onde ir
	for id in order:
		var b: Rect2 = boxes[id]
		if tree_own(id, b, rings) and not seen.any(func(o): return o != id and _tree_pad(boxes[o]).intersects(b)):
			continue
		var moved := false
		for off in free[id]:
			var nb: Rect2 = box.call(id, off)
			if not inner.encloses(nb):
				continue
			var hit: Array = seen.filter(func(o): return o != id and _tree_pad(boxes[o]).intersects(nb))
			if hit.size() != 1:
				continue
			var rest: Array = seen.filter(func(o): return o != id and o != hit[0]).map(func(o): return boxes[o]) + [nb]
			for off2 in free[hit[0]]:
				var hb: Rect2 = box.call(hit[0], off2)
				if inner.encloses(hb) and not rest.any(func(q): return _tree_pad(q).intersects(hb)):
					fixed[id] = off
					fixed[hit[0]] = off2
					boxes[id] = nb
					boxes[hit[0]] = hb
					moved = true
					break
			if moved:
				break
	return _tree_unclear(fixed, seen, free, wkey)


## Lote 8 C (h): com o texto grande (acima de 100%), o nome de um nó sem nenhum sítio livre na Árvore toda (em todos os
## sítios ficava em cima de um aro ou mais perto de outro: a 130%, a Hemorragia, a Hemofilia e o Mártir do Aço, entre 5 e 6
## vizinhos), ou sem lugar ao lado dos outros (hide), só aparece com o nó escolhido (o foco ou o 1.º toque); senão lia-se
## como o nome do vizinho. A 100% aparecem todos, como antes (a Presença também não tem sítio livre). Guarda a janela e
## devolve-a.
func _tree_unclear(fixed: Dictionary, seen: Array, free: Dictionary, wkey: String, hide := []) -> Dictionary:
	for id in seen:
		if text_k > 1.0 and (free[id].is_empty() or id in hide) and not id in tree_lit:
			fixed.erase(id)
	tree_label_at[wkey] = fixed
	return fixed


## Lote 8: a procura com volta atrás de _tree_labels_at. order[i:] ainda por pôr; cand[id] = [[deslocamento, retângulo]] dos
## sítios livres de id dentro da janela; got guarda o escolhido de cada um (null: fica de fora, até skips nomes, nunca os de keep:
## o nó escolhido e, primeiro, os abertos). Dois nomes nunca a menos de 3 px (na mesma linha, a uma palavra: _tree_pad). No
## máximo 500 passos por volta (spent; a arrastar com 15 nós abertos, a 100% e a 130%, nenhuma volta que acabou bem passou
## disso, e com 4000 uma janela podia gastar 16 000): sem solução até lá, desiste.
func _tree_assign(order: Array, i: int, cand: Dictionary, got: Dictionary, spent: Array, skips := 0, keep := []) -> bool:
	if i == order.size():
		return true
	var id: String = order[i]
	for c in cand[id]:
		spent[0] += 1
		if spent[0] > 500:
			return false
		var q: Rect2 = _tree_pad(c[1])
		var clash := false
		for o in got:
			if got[o] != null and q.intersects(got[o][1]):
				clash = true
				break
		if clash:
			continue
		got[id] = c
		if _tree_assign(order, i + 1, cand, got, spent, skips, keep):
			return true
		got.erase(id)
		if spent[0] > 500:
			return false
	if skips > 0 and not id in keep:
		got[id] = null
		if _tree_assign(order, i + 1, cand, got, spent, skips - 1, keep):
			return true
		got.erase(id)
	return false


## Lote 8 C (h): o canto da folha onde a Árvore de p abre: centrada no nó com foco e depois, se for preciso, mexida o menos
## possível (primeiro só na vertical, senão só na horizontal) até nenhum aro de um nó com nome ficar cortado pela borda da
## janela: o nome de um nó meio cortado não achava lugar e ia parar mais perto de outro aro (a 130%, a Hemorragia cortada em
## cima empurrava 4 nomes). O aro do nó com foco fica todo à vista. Sem nenhum sítio assim, fica centrada.
func tree_view(p, focus: String) -> Vector2:
	var nodes: Dictionary = main.PASSIVES
	var v0: Vector2 = (nodes[focus].pos - TREE_WIN / 2.0).clamp(TREE_AREA.position, TREE_AREA.end - TREE_WIN)
	var boxes := []  # o aro de cada nó com nome, como tree_rings (o do foco é o aro do foco)
	var mine := Rect2()
	for id in nodes:
		if id == focus or id in p.passives or (nodes[id].req in p.passives and not p.EXCLUSIVE.get(id, "") in p.passives and nodes[id].get("hero", p.hero) == p.hero):
			var d: float = NODE_SIZE[NODE_KIND.get(id, "node")]
			var h: float = d * RING_K + 2.0 if id == focus else d * 0.5 + 3.0
			boxes.append(Rect2(nodes[id].pos - Vector2(h, h), Vector2(h, h) * 2.0))
			if id == focus:
				mine = boxes[-1]
	for ax in [1, 0]:
		for step in range(0, int(TREE_WIN[ax] / 2.0), 2):
			for k in ([0] if step == 0 else [-step, step]):
				var v := v0
				v[ax] += k
				var win := Rect2(v, TREE_WIN)
				if TREE_AREA.encloses(win) and win.encloses(mine) and boxes.all(func(b): return not win.intersects(b) or win.encloses(b)):
					return v
	return v0


## C (e): o retângulo b (na folha da Árvore) toca no aro de algum nó? O aro é o do desenho (d / 2), com 3 px de folga, e nos
## nós com o foco ou escolhidos (tree_lit) o aro deles (d x 0,6, 3 px). rings: os de tree_rings(), feitos uma vez por arranjo.
func tree_ring_hit(b: Rect2, rings: Array = []) -> bool:
	for r in (rings if not rings.is_empty() else tree_rings()):
		if r[0].clamp(b.position, b.end).distance_to(r[0]) < r[1]:
			return true
	return false


## Lote 7 C (d): o nome b do nó id fica mais perto do aro dele do que de qualquer outro aro (do ponto do nome mais perto de
## cada aro), com folga: o outro aro tem de estar a mais de 1,5 vezes a distância ao dele, mais own_gap (a Raiz, a 5 px do aro
## da Densidade Osteológica, lia-se como o nome dela; as Ossos Densos, a 16 px do seu aro e a 24 do da Medula Sacrificial,
## mesmo por cima deste, liam-se como um 2.º nome da Medula).
func tree_own(id: String, b: Rect2, rings: Array = []) -> bool:
	var c: Vector2 = main.PASSIVES[id].pos
	var d: float = NODE_SIZE[NODE_KIND.get(id, "node")]
	var own: float = c.clamp(b.position, b.end).distance_to(c) - (d * RING_K + 2.0 if id in tree_lit else d * 0.5 + 3.0)
	for r in (rings if not rings.is_empty() else tree_rings()):
		if r[0] != c and r[0].clamp(b.position, b.end).distance_to(r[0]) - r[1] < own * 1.5 + own_gap:
			return false
	return true


## Revisão do Lote 8: o nome r da Árvore com a folga até outro nome: 3 px por cima e por baixo e, na mesma linha, uma
## palavra (tree_gap, o tamanho da letra): a 10 px, "Tutano Faminto" e "Veias Abertas" liam-se como uma frase.
func _tree_pad(r: Rect2) -> Rect2:
	return r.grow_individual(tree_gap, 3.0, tree_gap, 3.0)


## [centro, raio] do aro de cada nó, para o tree_ring_hit (sem ler o dicionário dos nós a cada sítio experimentado).
func tree_rings() -> Array:
	var out := []
	for k in main.PASSIVES:
		var d: float = NODE_SIZE[NODE_KIND.get(k, "node")]
		out.append([main.PASSIVES[k].pos, d * RING_K + 2.0 if k in tree_lit else d * 0.5 + 3.0])
	return out


## Procurar na Árvore (#97): um atalho, ou uma palavra escrita, acende os nós que a têm e o caminho de raízes até
## eles; a Árvore reabre centrada no primeiro. Fica acesa até Limpar busca.
func _tree_find(who: int, focus: String) -> void:
	var box := _open_panel("Procurar na Árvore", true, open_tree.bind(who, focus))
	var go := func(word: String, terms: Array):
		find_word = word
		find_terms = terms
		open_tree(who, (tree_matches(terms) + [focus])[0])
	var grid := GridContainer.new()
	grid.columns = 3
	grid.add_theme_constant_override("h_separation", 8)
	box.add_child(grid)
	for k in FIND:
		_button(grid, k, go.bind(tr(k), FIND[k]), null, 200.0)
	var word := _field(box, "Escreve uma palavra…", 616.0)
	var typed := func():
		var w := word.text.strip_edges()
		if w != "":
			go.call(w, [w])
	word.text_submitted.connect(func(_t): typed.call())
	_button(box, "Procurar", typed, null, 616.0)
	_button(box, "Voltar", _back, null, 616.0)
	grid.get_child(0).grab_focus()


## Os nós da Árvore com alguma das palavras no nome ou na descrição, sem maiúsculas nem acentos: em português (os
## atalhos servem nos dois idiomas) e no idioma do jogo (para o que se escreve).
func tree_matches(terms: Array) -> Array:
	var words := terms.map(_plain)
	var out := []
	for id in main.PASSIVES:
		var n: Dictionary = main.PASSIVES[id]
		var hay := _plain(" ".join([n.name, n.desc, tr(n.name), tr(n.desc)]))
		if words.any(func(w): return hay.contains(w)):
			out.append(id)
	return out


func _plain(s: String) -> String:
	s = s.to_lower()
	for i in PLAIN[0].length():
		s = s.replace(PLAIN[0][i], PLAIN[1][i])
	return s


## Bestiário: um monstro por linha; o que ainda não se sabe fica escondido (silhueta negra, "???").
func open_bestiary(back := Callable(), tab := 0) -> void:
	var box := _open_panel("Bestiário", true, back)
	var tabs := HBoxContainer.new()  # Lote 9: Mortos | Chefes (o Livro dos Chefes), como os separadores das Configurações
	tabs.add_theme_constant_override("separation", 6)
	box.add_child(tabs)
	for i in 2:
		var tb := _button(tabs, ["Mortos", "Chefes"][i], func(): open_bestiary(back, i), null, 180.0)
		tb.set_meta("tab", i)
		if i == tab:
			tb.add_theme_stylebox_override("normal", _sbt(UI.btn_on, Color.WHITE))
			tb.add_theme_color_override("font_color", Color.WHITE)
	var list := _scroll_list(box, 800.0, 390.0)  # 8 linhas já não cabem nos 720 px; revisão do Lote 10: só linhas inteiras e a seta (como as Provações)
	if tab == 1:
		_boss_book(list)
		_close_button(box).grab_focus()
		return
	for kind in BESTIARY:
		var b: Array = BESTIARY[kind]
		var steps: Array = b[1]
		var n: int = main.kills.get(kind, 0)
		var st: Array = Enemy.STATS.get(kind, Enemy.STATS.skeleton)  # as peles lutam como o esqueleto
		var row := HBoxContainer.new()
		row.add_theme_constant_override("separation", 12)
		var pic := _art(_trim(Enemy.FRAMES32[kind][16]), Vector2(72, 72))  # parado (o Arauto: a invocar)
		pic.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
		pic.modulate = Color.WHITE if n >= steps[0] else Color(0, 0, 0, 0.85)
		row.add_child(pic)
		var lines := []
		if n < steps[0]:
			lines.append([tr("??? — ainda não o derrotaste"), Color(0.6, 0.6, 0.55)])
		else:
			lines.append([tr("%s — %d morto" if n == 1 else "%s — %d mortos") % [tr(Enemy.NAMES[kind]), n], Color(0.95, 0.85, 0.6)])
			lines.append([tr(b[0]), Color(0.75, 0.75, 0.7)])
		if n >= steps[1]:
			lines.append([tr("Vida %d · Dano %d · Velocidade %d") % [st[0], st[2], st[1]], Color(0.55, 0.9, 0.65)])
		if n >= steps[2]:
			lines.append([tr("Experiência %d · Deixa: %s") % [main.XP[kind], tr(b[2])], Color(0.55, 0.8, 1.0)])
		else:
			var next: int = steps.filter(func(s): return s > n)[0]
			lines.append([tr("Mata mais %d para saberes mais.") % (next - n), Color(0.5, 0.5, 0.48)])
		var col := VBoxContainer.new()
		col.add_theme_constant_override("separation", 0)
		for l in lines:
			var lb := Label.new()
			lb.text = l[0]
			lb.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
			lb.custom_minimum_size.x = 700.0  # largo: na Augusta, com tudo descoberto, o painel cabe nos 720 px
			lb.add_theme_color_override("font_color", l[1])
			col.add_child(lb)
		row.add_child(col)
		list.add_child(row)
	_close_button(box).grab_focus()


## Lote 9: o Livro dos Chefes: cada chefe com nome já visto, com a frase do cartão dele (que só se via 3 s) e as vitórias;
## os que ainda não apareceram ficam à sombra.
func _boss_book(list: Control) -> void:
	list.add_theme_constant_override("separation", 14)  # Lote 11 C (g): as figuras de linhas seguidas já não se tocam
	for id in BOSS_BOOK:
		var met: bool = main.beaten.has(id)
		var info: Array = main.Bosses.BOOK.get(id, main.Bosses.INFO.get(id, ["", ""]))
		var look: String = "donzela_l" if id == "donzelas" else "rei_ouro" if id == "reis" else id
		var row := HBoxContainer.new()
		row.add_theme_constant_override("separation", 12)
		var tex: Texture2D = main.Bosses.COFFIN if id == "carruagem" else Enemy.FRAMES32[main.Bosses.spawn_kind(id)][16]
		row.add_child(_shadow_pic(_trim(tex), Vector2(72, 72), (main.Bosses.INFO[look][3] if main.Bosses.INFO.has(look) else Color.WHITE) if met else Color.TRANSPARENT))
		var col := VBoxContainer.new()
		col.add_theme_constant_override("separation", 0)
		var n: int = main.beaten.get(id, 0)
		var lines: Array = [[tr("??? — Ainda não o encontraste."), Color(0.6, 0.6, 0.55)]] if not met else [[tr(info[0]), Color(0.95, 0.85, 0.6)], [tr(info[1]), Color(0.75, 0.75, 0.7)],
			[tr("Vitórias: %d") % n if n > 0 else tr("Ainda sem vitórias"), Color(0.55, 0.9, 0.65) if n > 0 else Color(0.5, 0.5, 0.48)]]
		for l in lines:
			var lb := Label.new()
			lb.text = l[0]
			lb.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
			lb.custom_minimum_size.x = 700.0
			lb.add_theme_color_override("font_color", l[1])
			col.add_child(lb)
		row.add_child(col)
		list.add_child(row)


## Lote 10 C (d): um chefe ainda por encontrar: a silhueta num cinzento com um contorno de 2 px (a preta sumia no painel quase
## preto). Lote 11 C (g): mais apagada do que um chefe já visto (era mais clara do que o Arauto, escuro), que leva o mesmo
## contorno, claro, por baixo do desenho dele na cor tint (transparente: por encontrar).
func _shadow_pic(tex: Texture2D, size: Vector2, tint := Color.TRANSPARENT) -> Control:
	var met: bool = tint.a > 0.0
	var c := Control.new()
	c.custom_minimum_size = size
	c.material = ShaderMaterial.new()
	c.material.shader = SILHOUETTE  # o desenho numa cor só, a do draw
	c.set_meta("shadow" if not met else "met", true)
	var s: float = minf(size.x / tex.get_width(), size.y / tex.get_height())
	var r := Rect2((size - tex.get_size() * s) / 2.0, tex.get_size() * s)
	c.draw.connect(func():
		for o in [Vector2(-2, 0), Vector2(2, 0), Vector2(0, -2), Vector2(0, 2)]:
			c.draw_texture_rect(tex, Rect2(r.position + o, r.size), false, RIM if met else Color(0.36, 0.34, 0.3))
		if not met:
			c.draw_texture_rect(tex, r, false, Color(0.15, 0.145, 0.14)))
	if met:  # o desenho a cores, por cima do contorno (fora do material da silhueta)
		var pic := TextureRect.new()
		pic.expand_mode = TextureRect.EXPAND_IGNORE_SIZE  # antes do tamanho: senão o mínimo era o do desenho, e ele saía grande e fora do sítio
		pic.texture = tex
		pic.position = r.position
		pic.size = r.size
		pic.modulate = tint
		pic.mouse_filter = Control.MOUSE_FILTER_IGNORE
		c.add_child(pic)
	return c


## Relíquias de Família (#58): as 5 que os chefes com nome deixam, com a lenda; as que faltam ficam por saber.
func open_relics(back := Callable()) -> void:
	var box := _open_panel("Relíquias de Família", true, back)
	_text(box, "Cada relíquia dá +1 ponto na Árvore a cada herói.", Color(0.62, 0.78, 0.68))
	for id in main.RELICS:
		var have: bool = id in main.relics
		var row := HBoxContainer.new()
		row.add_theme_constant_override("separation", 12)
		var pic := _art(Loot.TEX.relic, Vector2(44, 44))
		pic.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
		pic.modulate = Color.WHITE if have else Color(0, 0, 0, 0.85)  # a silhueta, como no Bestiário
		row.add_child(pic)
		var col := VBoxContainer.new()
		col.add_theme_constant_override("separation", 0)
		_text(col, main.RELICS[id][0] if have else "??? — cai de um chefe", Color(1.0, 0.85, 0.4) if have else Color(0.6, 0.6, 0.55))
		if have:
			_text(col, main.RELICS[id][1], Color(0.75, 0.75, 0.7))
		row.add_child(col)
		box.add_child(row)
	_close_button(box).grab_focus()


## info vem de main.die(): o que ficou no túmulo e se havia um túmulo antigo (que se desfez).
func open_death(info := {}) -> void:
	Net.echo("hud", "toast", ["Caíram todos. O anfitrião escolhe o que fazer."])
	var box := _open_panel("A tua alma dissipou-se", false)
	var lost: Dictionary = info.get("lost", {})
	if info.has("deep"):  # Mausoléu Sem Fim (#27): cair acaba a descida e guarda-se tudo
		_text(box, tr("A descida acabou no piso %d. Guardaste tudo, sem túmulo.") % info.deep)
	elif lost.is_empty():
		_text(box, "Os mortos reclamam o que é deles.")
	else:
		_text(box, "Metade do que apanhaste nesta ida ficou no teu túmulo, ao pé do Portão dos Reis:" if info.get("sep", false) else "Metade do que trazias ficou no teu túmulo, no cemitério:")
		var row := Control.new()
		row.custom_minimum_size = Vector2(0, 40)
		row.draw.connect(func(): _draw_currency(row, 6.0, 32.0, lost))
		box.add_child(row)
		_text(box, "Vai buscá-lo: se caíres fora dos Sepulcros, perde-se." if info.get("sep", false) else "Vai buscá-lo antes de voltares a morrer, senão perde-se.")
	if info.get("moved", false):  # nada apanhado nesta ida: sem isto, o painel não dizia onde ficou
		_text(box, "O túmulo que já tinhas está agora ao pé do Portão dos Reis, com tudo o que lá estava.")
	if info.get("had_old", false):
		_text(box, "O túmulo anterior desfez-se com tudo o que lá estava.", Color(1.0, 0.5, 0.45))
	if info.get("by", "") != "":
		_text(box, tr("Derrubado por: %s") % tr(info.by), Color(0.95, 0.6, 0.5))
	_button(box, "Erguer-se novamente", main.restart).grab_focus()  # recomeça já a jogar, do jogo gravado
	_shield(0.6)  # A1: o golpe que vinha a caminho não carrega no Erguer-se
