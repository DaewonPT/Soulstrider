extends CanvasLayer
## HUD gótico (arte das folhas UI-01/UI-02) + controlos de telemóvel: ecrã tátil (joystick flutuante,
## botões escaláveis) ou comando, com os botões A/B/X/Y desenhados no ecrã
## + painéis: título, Arsenal, Árvore dos Condenados, Cortejo e morte (no comando: A escolhe, B volta).
## Também os momentos grandes: barra e cartão do chefe, subida de nível e flash do crítico.

const JOY_R := 80.0
const SCALES := [1.0, 1.3, 1.6]
const CARD_T := 3.2
const LVL_T := 2.4
const UI := {
	"holder": preload("res://art/ui/orb_holder.png"),
	"red": preload("res://art/ui/orb_red.png"),
	"soul": preload("res://art/ui/orb_soul.png"),
	"ring": preload("res://art/ui/ring_small.png"),
	"joy": preload("res://art/ui/joy_base.png"),
	"knob": preload("res://art/ui/joy_knob.png"),
	"bar": preload("res://art/ui/bar.png"),
	"panel": preload("res://art/ui/panel.png"),
	"btn": preload("res://art/ui/btn_s.png"),
	"btn_on": preload("res://art/ui/btn_on_s.png"),
}
const ICONS := {
	"scythe": preload("res://art/icons/sk_scythe.png"),
	"bolt": preload("res://art/icons/sk_bolt.png"),
	"nova": preload("res://art/icons/sk_nova.png"),
	"chop": preload("res://art/icons/sk_chop.png"),
	"cleave": preload("res://art/icons/sk_cleave.png"),
	"bonearmor": preload("res://art/icons/sk_bonearmor.png"),
	"bone": preload("res://art/icons/bone.png"),
	"ink": preload("res://art/icons/ink.png"),
	"ash": preload("res://art/icons/ash.png"),
	"": preload("res://art/icons/flask_empty.png"),
	"parasita": preload("res://art/icons/flask_parasita.png"),
	"titanica": preload("res://art/icons/flask_titanica.png"),
	"weapon": preload("res://art/icons/scythe.png"),
	"sealed": preload("res://art/icons/sealed.png"),
	"veloz": preload("res://art/icons/flask_swift.png"),
	"eco": preload("res://art/icons/flask_echo.png"),
	"tumular": preload("res://art/icons/flask_grave.png"),
	"colerica": preload("res://art/icons/flask_wrath.png"),
	"potion_hp": preload("res://art/icons/potion_red.png"),
	"potion_mp": preload("res://art/icons/potion_soul.png"),
}
const TREE := {
	"node": preload("res://art/tree/node.png"), "node_on": preload("res://art/tree/node_on.png"),
	"notable": preload("res://art/tree/notable.png"), "notable_on": preload("res://art/tree/notable_on.png"),
	"keystone": preload("res://art/tree/keystone.png"), "keystone_on": preload("res://art/tree/keystone_on.png"),
	"root": preload("res://art/tree/root.png"), "root_on": preload("res://art/tree/root_on.png"),
	"bg": preload("res://art/bg/tree.webp"),
}
const NODE_KIND := {"raiz": "keystone", "bleedbone": "keystone", "ossada": "notable", "hemorragia": "notable", "eco": "notable"}
const NODE_SIZE := {"node": 46.0, "notable": 60.0, "keystone": 76.0}
const Gothic := preload("res://gothic.gd")
const AppUpdate := preload("res://app_update.gd")
## Cores das letras dos botões, como num comando Xbox / GameSir.
const GLYPH_COL := {"a": Color(0.45, 0.82, 0.35), "b": Color(0.93, 0.32, 0.28), "x": Color(0.33, 0.58, 0.97), "y": Color(0.98, 0.8, 0.22)}
const TITLE_ART := preload("res://art/bg/title.webp")
## Afixos do Cortejo em cartões, com arte que já existe a dizer o que fazem.
const AFFIX_ICON := {
	"blindados": preload("res://art/icons/chest_armor.png"),
	"furia": preload("res://art/icons/flask_swift.png"),
	"laminas": preload("res://art/icons/sword.png"),
	"legiao": preload("res://art/icons/sk_raise.png"),
	"gemeo": preload("res://art/colossus.png"),
}
const HERALD_TEX := preload("res://art/anim/herald_0.png")
const SKULLS := preload("res://art/props/skulls.png")
const LOADING_ART := preload("res://art/bg/loading.webp")
const TABS := ["Som", "Desempenho", "Jogo", "Controlos"]  # separadores das Configurações
const STUDIO_LOGO := preload("res://art/ui/studio_logo.png")  # também é o ecrã de arranque (project.godot)

var main
var root: Control
var overlay: Control  # por baixo dos botões
var front: Control  # por cima dos botões: recargas, chefe, nível, flash
var status: Label
var toast_label: Label
var toast_t := 0.0
var pad: Control
var top_bar: HBoxContainer
var interact_btn: Button
var skill_btns := {}
var panel: Control
var panel_cancel := false  # B (ou o Voltar do Android) fecha este painel
var panel_back := Callable()  # para onde B / Voltar levam (vazio = fecha e volta ao jogo)
var sub_back := Callable()  # Arsenal e Árvore abertos pelo Menu: B volta ao Menu
var license_scroll: ScrollContainer  # Licenças: o stick do comando faz rolar o texto
var title_open := false  # no título (e nas Configurações/Sobre abertas dele) ainda não se grava nada
var panel_frame := 0
var gamepad := false  # o último controlo usado foi um comando: esconde os botões de toque e mostra A/B/X/Y
var last_gamepad := false
var hint_title := ""
var hint_action := ""
var updater: Node  # AppUpdate: avisa no título quando há um APK novo no GitHub
var title_menu: VBoxContainer
var ui_scale_i := 0
var joy_index := -1
var joy_origin := Vector2.ZERO
var joy_pos := Vector2.ZERO
var flash_a := 0.0
var fade_a := 0.0  # negro a desvanecer ao mudar de zona (descer/subir as escadas)
var dark := 0.0
var card_t := 0.0
var card_name := ""
var card_sub := ""
var lvl_t := 0.0
var xp_shown := 0.0
var xp_hold := 0.0
var last_level := 1


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	root = Control.new()
	root.set_anchors_preset(Control.PRESET_FULL_RECT)
	root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.theme = _theme()
	add_child(root)
	overlay = _layer(_draw_overlay)

	gamepad = not Input.get_connected_joypads().is_empty()
	updater = AppUpdate.new()
	add_child(updater)
	updater.update_available.connect(_on_update)
	updater.check()
	status = _label(Vector2(16, 100), 15)
	toast_label = _label(Vector2(0, 0), 27)
	toast_label.add_theme_font_override("font", Gothic.FONT)
	toast_label.set_anchors_and_offsets_preset(Control.PRESET_CENTER_TOP)
	toast_label.offset_top = 172
	toast_label.grow_horizontal = Control.GROW_DIRECTION_BOTH
	toast_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	toast_label.add_theme_color_override("font_color", Color(1.0, 0.85, 0.5))

	pad = Control.new()
	pad.mouse_filter = Control.MOUSE_FILTER_IGNORE
	pad.set_anchors_preset(Control.PRESET_BOTTOM_RIGHT)
	pad.offset_left = -380
	pad.offset_top = -330
	pad.offset_right = 0
	pad.offset_bottom = 0
	pad.pivot_offset = Vector2(380, 330)
	root.add_child(pad)
	var spots := [[Vector2(240, 190), 120.0], [Vector2(120, 225), 95.0], [Vector2(255, 75), 95.0]]
	for i in 3:
		_skill_button(main.player.order[i], spots[i][0], spots[i][1])
	interact_btn = _round_button("Invocar", Vector2(130, 110), 95, Color(0.6, 0.15, 0.2))
	interact_btn.pressed.connect(main.interact)
	pad.add_child(interact_btn)
	# Poções no ecrã tátil, ao lado das habilidades
	for k in [["hp", Vector2(26, 150), Color(0.85, 0.2, 0.2)], ["mp", Vector2(26, 238), Color(0.25, 0.55, 0.95)]]:
		var b := _round_button("", k[1], 64, k[2])
		b.icon = ICONS["potion_" + k[0]]
		b.expand_icon = true
		b.add_theme_constant_override("icon_max_width", 34)
		b.icon_alignment = HORIZONTAL_ALIGNMENT_CENTER
		var kind: String = k[0]
		b.pressed.connect(func(): main.player.use_potion(kind))
		pad.add_child(b)

	top_bar = HBoxContainer.new()
	top_bar.set_anchors_and_offsets_preset(Control.PRESET_TOP_RIGHT)
	top_bar.offset_left = -460
	top_bar.offset_top = 10
	top_bar.offset_right = -10
	top_bar.alignment = BoxContainer.ALIGNMENT_END
	root.add_child(top_bar)
	for b in [["Árvore", _tree], ["Arsenal", _arsenal], ["Menu", open_menu]]:
		var btn := Button.new()
		btn.text = b[0]
		btn.focus_mode = Control.FOCUS_NONE
		btn.custom_minimum_size = Vector2(0, 48)
		btn.pressed.connect(b[1])
		top_bar.add_child(btn)
	front = _layer(_draw_front)


func _layer(cb: Callable) -> Control:
	var c := Control.new()
	c.set_anchors_preset(Control.PRESET_FULL_RECT)
	c.mouse_filter = Control.MOUSE_FILTER_IGNORE
	c.draw.connect(cb)
	root.add_child(c)
	return c


func _sbt(tex: Texture2D, mod: Color) -> StyleBoxTexture:
	var s := StyleBoxTexture.new()
	s.texture = tex
	s.set_texture_margin_all(18.0)
	s.content_margin_left = 22.0
	s.content_margin_right = 22.0
	s.content_margin_top = 6.0
	s.content_margin_bottom = 6.0
	s.modulate_color = mod
	return s


## Painéis com a moldura de ferro e osso, botões com a placa da UI-02 (acesa quando premida).
func _theme() -> Theme:
	var th := Theme.new()
	th.default_font_size = 17
	var pn := StyleBoxTexture.new()
	pn.texture = UI.panel
	pn.set_texture_margin_all(96.0)
	pn.set_content_margin_all(38.0)
	th.set_stylebox("panel", "PanelContainer", pn)
	th.set_stylebox("normal", "Button", _sbt(UI.btn, Color.WHITE))
	th.set_stylebox("hover", "Button", _sbt(UI.btn, Color(1.3, 1.3, 1.25)))
	th.set_stylebox("pressed", "Button", _sbt(UI.btn_on, Color.WHITE))
	th.set_stylebox("disabled", "Button", _sbt(UI.btn, Color(0.5, 0.5, 0.5)))
	var fo := StyleBoxFlat.new()
	fo.draw_center = false
	fo.set_border_width_all(2)
	fo.border_color = Color(0.45, 1.0, 0.65)
	fo.set_corner_radius_all(6)
	fo.set_expand_margin_all(2.0)
	th.set_stylebox("focus", "Button", fo)
	# Barras de volume: calha escura com aro de osso, cheia a verde-alma
	var track := StyleBoxFlat.new()
	track.bg_color = Color(0.05, 0.06, 0.06)
	track.border_color = Color(0.5, 0.45, 0.34)
	track.set_border_width_all(2)
	track.set_corner_radius_all(6)
	track.content_margin_top = 5.0
	track.content_margin_bottom = 5.0
	th.set_stylebox("slider", "HSlider", track)
	var fill := StyleBoxFlat.new()
	fill.bg_color = Color(0.28, 0.8, 0.5)
	fill.set_corner_radius_all(6)
	th.set_stylebox("grabber_area", "HSlider", fill)
	var lit: StyleBoxFlat = fill.duplicate()
	lit.bg_color = Color(0.45, 1.0, 0.65)
	th.set_stylebox("grabber_area_highlight", "HSlider", lit)
	th.set_stylebox("focus", "HSlider", fo)
	for c in ["font_color", "font_hover_color", "font_focus_color"]:
		th.set_color(c, "Button", Color(0.93, 0.89, 0.76))
	th.set_color("font_pressed_color", "Button", Color.WHITE)
	return th


func _label(pos: Vector2, size: int) -> Label:
	var l := Label.new()
	l.position = pos
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_outline_color", Color.BLACK)
	l.add_theme_constant_override("outline_size", 6)
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(l)
	return l


func _round_button(text: String, pos: Vector2, d: float, tint: Color) -> Button:
	var b := Button.new()
	b.text = text
	b.position = pos
	b.size = Vector2(d, d)
	b.focus_mode = Control.FOCUS_NONE
	for st in ["normal", "hover", "pressed"]:
		var sb := StyleBoxFlat.new()
		sb.bg_color = Color(0.04, 0.07, 0.07, 0.75) if st != "pressed" else Color(tint, 0.6)
		sb.border_color = tint
		sb.set_border_width_all(3)
		sb.set_corner_radius_all(int(d / 2))
		b.add_theme_stylebox_override(st, sb)
	return b


## Botão de habilidade = o ícone redondo da folha ICO-03.
func _skill_button(id: String, pos: Vector2, d: float) -> void:
	var b := Button.new()
	b.position = pos
	b.size = Vector2(d, d)
	b.focus_mode = Control.FOCUS_NONE
	for st in ["normal", "hover", "pressed"]:
		var sb := StyleBoxTexture.new()
		sb.texture = ICONS[id]
		sb.modulate_color = Color(0.7, 0.7, 0.7) if st == "pressed" else Color.WHITE
		b.add_theme_stylebox_override(st, sb)
	b.button_down.connect(func(): main.player.held[id] = true)
	b.button_up.connect(func(): main.player.held[id] = false)
	skill_btns[id] = b
	pad.add_child(b)


func set_ui_scale(i: int) -> void:
	ui_scale_i = clampi(i, 0, SCALES.size() - 1)
	pad.scale = Vector2.ONE * SCALES[ui_scale_i]


func toast(text: String) -> void:
	toast_label.text = text
	toast_t = 3.0


func flash(a: float) -> void:
	if main.settings.flash:
		flash_a = maxf(flash_a, a)


func fade() -> void:
	fade_a = 1.0


func name_card(n: String, sub: String) -> void:
	card_name = n
	card_sub = sub
	card_t = CARD_T


func level_up() -> void:
	lvl_t = LVL_T


func _process(delta: float) -> void:
	toast_t -= delta
	toast_label.visible = toast_t > 0.0
	flash_a = maxf(0.0, flash_a - delta * 3.0)
	fade_a = maxf(0.0, fade_a - delta * 1.4)
	card_t -= delta
	lvl_t -= delta
	dark = lerpf(dark, 0.45 if main.rumble > 0.0 else 0.0, 1.0 - exp(-3.0 * delta))
	# XP: enche devagar; ao subir de nível fica cheia a piscar um instante e só depois recomeça
	if main.level != last_level:
		last_level = main.level
		xp_hold = 0.5
		xp_shown = 1.0
	if xp_hold > 0.0:
		xp_hold -= delta
		if xp_hold <= 0.0:
			xp_shown = 0.0
	else:
		xp_shown = lerpf(xp_shown, float(main.xp) / main.xp_needed(), 1.0 - exp(-6.0 * delta))
	status.text = main.weapon_text()
	if main.cortejo.active:
		var names := []
		for a in main.cortejo.affixes:
			names.append(tr(main.AFFIXES[a][0]))
		status.text += "\n" + tr("CORTEJO FÚNEBRE — onda %d/%d   restantes: %d   afixos: %s") % [main.cortejo.wave, main.WAVES, main.cortejo.alive, ", ".join(names) if names else tr("nenhum")]
	# O que dá para fazer aqui (B no comando, ou o botão redondo no ecrã)
	var door: String = main.near_door()
	hint_title = ""
	hint_action = ""
	if main.near_chest():
		hint_title = "Relicário selado"
		hint_action = "Abrir"
	elif door != "":
		hint_title = "Cripta dos Condenados" if door == "down" else "Saída da cripta"
		hint_action = "Descer" if door == "down" else "Subir"
	elif main.near_monument():
		hint_title = "Monumento Fúnebre"
		hint_action = "Invocar"
	interact_btn.visible = hint_action != ""
	interact_btn.text = hint_action
	pad.visible = not gamepad
	top_bar.visible = not gamepad
	if gamepad != last_gamepad:
		last_gamepad = gamepad
		root.propagate_call("queue_redraw")  # o título e os painéis desenham as legendas do modo novo
	# Menu = menu do jogo, Vista = Árvore de quem carregou; com um painel aberto, voltam atrás (como o B)
	var fresh: bool = Engine.get_process_frames() > panel_frame  # o botão que abriu o painel não o fecha logo
	for i in main.players.size():
		var pfx := "" if i == 0 else "p2_"
		for a in ["menu", "tree"]:
			if Input.is_action_just_pressed(pfx + a) and not main.players[i].dead:
				if panel == null:
					if a == "menu":
						open_menu()
					else:
						_tree(i)
				elif panel_cancel and fresh:
					_back()
	if panel != null and panel_cancel and fresh and Input.is_action_just_pressed("ui_cancel"):
		_back()
	if is_instance_valid(license_scroll):
		license_scroll.scroll_vertical += int(Input.get_axis("ui_up", "ui_down") * 700.0 * delta)
	overlay.queue_redraw()
	front.queue_redraw()


func _input(event: InputEvent) -> void:
	var vs := root.get_viewport_rect().size
	if event is InputEventJoypadButton or (event is InputEventJoypadMotion and absf(event.axis_value) > 0.5):
		gamepad = true
		main.on_pad_input(event)
	elif event is InputEventScreenTouch and event.pressed:
		gamepad = false
	if event is InputEventScreenTouch:
		if event.pressed and joy_index == -1 and panel == null and event.position.x < vs.x * 0.45 and event.position.y > vs.y * 0.3:
			joy_index = event.index
			joy_origin = event.position
			joy_pos = event.position
		elif not event.pressed and event.index == joy_index:
			joy_index = -1
			main.player.touch_move = Vector2.ZERO
	elif event is InputEventScreenDrag and event.index == joy_index:
		joy_pos = event.position
		var r: float = JOY_R * SCALES[ui_scale_i]
		main.player.touch_move = ((joy_pos - joy_origin) / r).limit_length(1.0)


func _draw_overlay() -> void:
	var vs := overlay.size
	var font := ThemeDB.fallback_font
	var p = main.player
	# Jogador 1: retrato no anel + nome + vida + mana
	_portrait(p, Vector2(42, 44), 25.0)
	Gothic.draw(overlay, Vector2(82, 26), p.hero_name, 21, Color(0.9, 0.85, 0.7), 5)
	_life_bar(Rect2(82, 32, 220, 12), p)
	overlay.draw_rect(Rect2(82, 48, 180, 7), Color(0.02, 0.04, 0.08))
	overlay.draw_rect(Rect2(82, 48, 180 * p.mana / p.max_mana, 7), Color(0.2, 0.6, 0.85))
	# Moedas com os ícones da folha ICO-01
	var x := 16.0
	for k in ["bone", "ink", "ash"]:
		overlay.draw_texture_rect(ICONS[k], Rect2(x, 72, 26, 26), false)
		Gothic.draw(overlay, Vector2(x + 30, 93), str(main.currency[k]), 20, Color(0.95, 0.9, 0.75), 5)
		x += 74.0
	# Jogador 2 (co-op): retrato, vida e as 3 habilidades com recarga
	if main.players.size() > 1:
		var q = main.players[1]
		_portrait(q, Vector2(352, 40), 20.0)
		var label: String = tr(q.hero_name) + ("  — " + tr("caído") if q.dead else "")
		Gothic.draw(overlay, Vector2(380, 26), label, 20, q.tint, 5)
		_life_bar(Rect2(380, 32, 160, 10), q)
		for i in 3:
			var id: String = q.order[i]
			var r := Rect2(380 + i * 30, 47, 26, 26)
			overlay.draw_texture_rect(ICONS[id], r, false)
			if q.cds[id] > 0.0:
				_pie(overlay, r.get_center(), 13.0, q.cds[id] / q.skills[id].cd)
		if main.pad_of[1] == -1:
			overlay.draw_string(font, Vector2(474, 70), tr("carrega num botão do 2.º comando"), HORIZONTAL_ALIGNMENT_LEFT, -1, 13, Color(1, 1, 1, 0.6))
	elif gamepad:
		_prompts(overlay, Vector2(330, 30), ["2.º comando: ", "@menu", " entra o Guardião"], 14)
	# Orbes de vida e alma dentro do suporte duplo da folha UI-01
	var hw := 300.0
	var hh: float = hw * UI.holder.get_height() / UI.holder.get_width()
	var hr := Rect2(vs.x * 0.5 - hw / 2.0, vs.y - hh - 10.0, hw, hh)
	var rad := hw * 0.3 / 2.0
	_orb(hr.position + Vector2(hw * 0.272, hh * 0.491), rad, p.hp / p.max_hp, UI.red)
	_orb(hr.position + Vector2(hw * 0.725, hh * 0.491), rad, p.mana / p.max_mana, UI.soul)
	overlay.draw_texture_rect(UI.holder, hr, false)
	# Poções de cada lado das orbes, com as cargas (no comando: LB vida, RB alma)
	_potion(Vector2(hr.position.x - 30, hr.get_center().y), "hp", p)
	_potion(Vector2(hr.end.x + 30, hr.get_center().y), "mp", p)
	# Experiência do grupo
	var xr := Rect2(vs.x * 0.5 - 160, vs.y - 8, 320, 5)
	overlay.draw_rect(xr, Color(0, 0, 0, 0.75))
	var xc := Color(1.0, 0.97, 0.8) if xp_hold > 0.0 and int(xp_hold * 14.0) % 2 == 0 else Color(0.95, 0.8, 0.4)
	overlay.draw_rect(Rect2(xr.position, Vector2(xr.size.x * clampf(xp_shown, 0.0, 1.0), xr.size.y)), xc)
	Gothic.draw(overlay, Vector2(xr.end.x + 8, vs.y - 2), tr("Nv %d") % main.level, 17,Color(0.95, 0.8, 0.4), 4)
	# Joystick flutuante
	if joy_index != -1:
		var r: float = JOY_R * SCALES[ui_scale_i]
		overlay.draw_texture_rect(UI.joy, Rect2(joy_origin - Vector2(r, r), Vector2(2 * r, 2 * r)), false, Color(1, 1, 1, 0.8))
		var k := joy_origin + (joy_pos - joy_origin).limit_length(r)
		overlay.draw_texture_rect(UI.knob, Rect2(k - Vector2(r, r) * 0.45, Vector2(r, r) * 0.9), false)
	elif not gamepad and DisplayServer.is_touchscreen_available():
		overlay.draw_string(font, Vector2(40, vs.y - 40), tr("toca e arrasta para mover"), HORIZONTAL_ALIGNMENT_LEFT, -1, 14, Color(1, 1, 1, 0.35))
	# Seta para o objetivo: o monumento no cemitério; na cripta, o Carcereiro e depois a saída
	var to: Vector2 = main.objective() - p.position
	if to.length() > 450.0:
		var c := vs / 2.0 + to.normalized() * 200.0
		var d := to.normalized()
		overlay.draw_colored_polygon(PackedVector2Array([c + d * 16.0, c + d.orthogonal() * 9.0, c - d.orthogonal() * 9.0]), Color(0.9, 0.2, 0.25, 0.8) if main.cortejo.active else Color(0.4, 1.0, 0.65, 0.7))


func _draw_front() -> void:
	var vs := front.size
	var p = main.player
	if main.settings.show_fps:
		front.draw_string_outline(ThemeDB.fallback_font, Vector2(10, vs.y - 10), "%d FPS" % Engine.get_frames_per_second(), HORIZONTAL_ALIGNMENT_LEFT, -1, 14, 4, Color.BLACK)
		front.draw_string(ThemeDB.fallback_font, Vector2(10, vs.y - 10), "%d FPS" % Engine.get_frames_per_second(), HORIZONTAL_ALIGNMENT_LEFT, -1, 14, Color(0.6, 1.0, 0.7))
	if gamepad:
		_pad_diamond(vs, p)
		if panel == null:
			_prompts(front, Vector2(vs.x - 16.0, 34.0), ["@view", " Árvore     ", "@menu", " Menu"], 18, 1.0)
	else:
		# Recargas por cima dos botões de toque, e o frasco de suporte no canto
		for id in skill_btns:
			var r: Rect2 = skill_btns[id].get_global_rect()
			if p.cds[id] > 0.0:
				_pie(front, r.get_center(), r.size.x * 0.43, p.cds[id] / p.skills[id].cd)
			var sup: String = p.skills[id].support
			if sup != "":
				front.draw_texture_rect(ICONS[sup], Rect2(r.end - Vector2(30, 34), Vector2(28, 28)), false)
	if hint_title != "":
		var parts := [hint_title + "  —  "] + (["@b", " " + hint_action] if gamepad else [tr("toca em %s") % tr(hint_action)])
		_prompts(front, Vector2(vs.x * 0.5, 150.0), parts, 20, 0.5)
	# Legenda dos painéis no comando, por baixo da moldura
	if gamepad and panel is PanelContainer:
		var pr: Rect2 = panel.get_global_rect()
		_prompts(front, Vector2(vs.x * 0.5, minf(pr.end.y + 24.0, vs.y - 8.0)), ["@a", " Escolher     ", "@b", " Voltar"] if panel_cancel else ["@a", " Escolher"], 17, 0.5)
	if dark > 0.01:  # o mundo escurece enquanto o sino dobra
		front.draw_rect(Rect2(Vector2.ZERO, vs), Color(0.0, 0.02, 0.01, dark))
	var y := 62.0
	for e in main.enemies():
		if e.is_boss and e.rise_t <= 0.0 and (e.awake or e.aggro == INF):  # o Carcereiro só depois de acordar
			_boss_bar(e, vs, y)
			y += 70.0
	if card_t > 0.0:
		_name_card(vs)
	if lvl_t > 0.0:
		_level_card(vs)
	if flash_a > 0.0:
		front.draw_rect(Rect2(Vector2.ZERO, vs), Color(1, 1, 1, flash_a))
	if fade_a > 0.0:
		front.draw_rect(Rect2(Vector2.ZERO, vs), Color(0, 0, 0, fade_a))


func _pie(ci: CanvasItem, c: Vector2, r: float, f: float) -> void:
	if f < 0.02:
		return
	var pts := PackedVector2Array([c])
	for i in 25:
		pts.append(c + Vector2.from_angle(-PI / 2.0 + TAU * f * i / 24.0) * r)
	ci.draw_colored_polygon(pts, Color(0, 0, 0, 0.6))


## Habilidades em losango, como os botões do comando: Y em cima, X à esquerda, A em baixo, B (interagir) à direita.
func _pad_diamond(vs: Vector2, p) -> void:
	var c := Vector2(vs.x - 128.0, vs.y - 128.0)
	var slot := {"y": Vector2(0, -64), "x": Vector2(-64, 0), "a": Vector2(0, 64), "b": Vector2(64, 0)}
	var keys := ["a", "x", "y"]
	for i in 3:
		var id: String = p.order[i]
		var at: Vector2 = c + slot[keys[i]]
		var r := 36.0 if i == 0 else 30.0
		front.draw_texture_rect(ICONS[id], Rect2(at - Vector2(r, r), Vector2(2 * r, 2 * r)), false)
		if p.cds[id] > 0.0:
			_pie(front, at, r * 0.86, p.cds[id] / p.skills[id].cd)
		var sup: String = p.skills[id].support
		if sup != "":
			front.draw_texture_rect(ICONS[sup], Rect2(at + Vector2(r * 0.2, -r * 1.1), Vector2(r * 0.8, r * 0.8)), false)
		_glyph(front, at + Vector2(r * 0.4, r * 0.62), keys[i], 11.0)
	if hint_action != "":
		var b: Vector2 = c + slot.b
		front.draw_circle(b, 26.0, Color(0.05, 0.06, 0.06, 0.8))
		_glyph(front, b - Vector2(13, 0), "b", 13.0)
		Gothic.draw_centered(front, b.x, b.y + 46.0, hint_action, 19, Color(0.95, 0.85, 0.6), 5)


## Linha de texto com botões do comando: "@a" "@b" "@x" "@y" "@lb" "@rb" "@menu" "@view" desenham o botão.
## align: 0 = começa em pos, 0.5 = centrada, 1 = acaba em pos.
func _prompts(ci: CanvasItem, pos: Vector2, parts: Array, size := 18, align := 0.0) -> void:
	# o texto traduz-se sem os espaços à volta (que só servem para separar)
	parts = parts.map(func(s: String): return s if s.begins_with("@") or s.strip_edges() == "" else s.replace(s.strip_edges(), tr(s.strip_edges())))
	var font := ThemeDB.fallback_font
	var r := size * 0.62
	var w := 0.0
	for s in parts:
		w += (2.0 * r + 2.0 if GLYPH_COL.has(s.substr(1)) else 3.0 * r + 2.0) if s.begins_with("@") else font.get_string_size(s, HORIZONTAL_ALIGNMENT_LEFT, -1, size).x
	var x := pos.x - w * align
	for s in parts:
		if s.begins_with("@"):
			x += _glyph(ci, Vector2(x, pos.y - size * 0.34), s.substr(1), r)
		else:
			ci.draw_string_outline(font, Vector2(x, pos.y), s, HORIZONTAL_ALIGNMENT_LEFT, -1, size, 6, Color.BLACK)
			ci.draw_string(font, Vector2(x, pos.y), s, HORIZONTAL_ALIGNMENT_LEFT, -1, size, Color(0.95, 0.92, 0.85))
			x += font.get_string_size(s, HORIZONTAL_ALIGNMENT_LEFT, -1, size).x


## Um botão do comando desenhado, com o lado esquerdo em at (a meia altura). Devolve a largura gasta.
func _glyph(ci: CanvasItem, at: Vector2, id: String, r: float) -> float:
	var font := ThemeDB.fallback_font
	var dark_bg := Color(0.06, 0.06, 0.06, 0.92)
	if GLYPH_COL.has(id):
		var c := at + Vector2(r, 0)
		ci.draw_circle(c, r, dark_bg)
		ci.draw_arc(c, r, 0, TAU, 24, GLYPH_COL[id], maxf(1.5, r * 0.14), true)
		var s := int(r * 1.25)
		var l := id.to_upper()
		ci.draw_string(font, c + Vector2(-font.get_string_size(l, HORIZONTAL_ALIGNMENT_LEFT, -1, s).x / 2.0, s * 0.36), l, HORIZONTAL_ALIGNMENT_LEFT, -1, s, GLYPH_COL[id])
		return 2.0 * r + 2.0
	# Botões pequenos em pílula: Menu (≡), Vista (dois quadrados), LB, RB
	var rect := Rect2(at + Vector2(0, -r * 0.78), Vector2(3.0 * r, r * 1.56))
	var h := rect.size.y / 2.0
	ci.draw_circle(rect.position + Vector2(h, h), h, dark_bg)
	ci.draw_circle(rect.end - Vector2(h, h), h, dark_bg)
	ci.draw_rect(Rect2(rect.position + Vector2(h, 0), Vector2(rect.size.x - 2.0 * h, rect.size.y)), dark_bg)
	var col := Color(0.92, 0.9, 0.84)
	var c := rect.get_center()
	var line := maxf(1.4, r * 0.15)
	match id:
		"menu":
			for k in [-1, 0, 1]:
				ci.draw_line(c + Vector2(-r * 0.55, k * r * 0.36), c + Vector2(r * 0.55, k * r * 0.36), col, line)
		"view":
			var q := r * 0.62
			ci.draw_rect(Rect2(c + Vector2(-q * 0.8, -q * 0.65), Vector2(q, q * 0.85)), col, false, line)
			ci.draw_rect(Rect2(c + Vector2(-q * 0.2, -q * 0.2), Vector2(q, q * 0.85)), col, false, line)
		_:
			var l := id.to_upper()
			var s := int(r * 1.05)
			ci.draw_string(font, c + Vector2(-font.get_string_size(l, HORIZONTAL_ALIGNMENT_LEFT, -1, s).x / 2.0, s * 0.36), l, HORIZONTAL_ALIGNMENT_LEFT, -1, s, col)
	return 3.0 * r + 2.0


## Uma poção: o frasco (apagado sem cargas), o número de cargas e a barra da próxima carga.
func _potion(c: Vector2, kind: String, p) -> void:
	var tex: Texture2D = ICONS["potion_" + kind]
	var n: float = p.potions[kind]
	var h := 50.0
	var w := h * tex.get_width() / tex.get_height()
	overlay.draw_texture_rect(tex, Rect2(c.x - w / 2.0, c.y - h / 2.0 - 6.0, w, h), false, Color.WHITE if n >= 1.0 else Color(0.4, 0.4, 0.4, 0.8))
	Gothic.draw(overlay, Vector2(c.x + 8, c.y + 20), str(int(n)), 22, Color(1.0, 0.95, 0.8), 5)
	if n < p.POTION_MAX:
		overlay.draw_rect(Rect2(c.x - 18, c.y + 26, 36, 4), Color(0, 0, 0, 0.7))
		overlay.draw_rect(Rect2(c.x - 18, c.y + 26, 36 * (n - floorf(n)), 4), Color(1.0, 0.85, 0.4))
	if gamepad:  # LB por fora da poção da esquerda, RB por fora da da direita
		_glyph(overlay, Vector2(c.x - 50.0 if kind == "hp" else c.x + 20.0, c.y - 30), "lb" if kind == "hp" else "rb", 10.0)


## Retrato redondo dentro do anel ornamentado (o buraco do anel tem 68% da largura).
func _portrait(pl, c: Vector2, r: float) -> void:
	overlay.draw_circle(c, r, Color(0.05, 0.06, 0.06))
	overlay.draw_texture_rect(pl.portrait, Rect2(c - Vector2(r, r), Vector2(2 * r, 2 * r)), false, Color(0.45, 0.45, 0.45) if pl.dead else Color.WHITE)
	var w := 2.0 * r / 0.68
	var h: float = w * UI.ring.get_height() / UI.ring.get_width()
	overlay.draw_texture_rect(UI.ring, Rect2(c.x - w * 0.498, c.y - h * 0.499, w, h), false)


## Barra de vida: cor diz o estado (verde/amarelo/vermelho) e o pedaço claro mostra o que se perdeu.
func _life_bar(r: Rect2, p) -> void:
	var frac: float = maxf(p.hp, 0.0) / p.max_hp
	var col := Color(0.35, 0.85, 0.4) if frac > 0.6 else (Color(0.95, 0.75, 0.2) if frac > 0.3 else Color(0.85, 0.1, 0.12))
	overlay.draw_rect(r.grow(2.0), Color(0.12, 0.1, 0.08))
	overlay.draw_rect(r, Color(0.1, 0.02, 0.02))
	overlay.draw_rect(Rect2(r.position, Vector2(r.size.x * minf(p.hp_chunk / p.max_hp, 1.0), r.size.y)), Color(1.0, 0.85, 0.55))
	overlay.draw_rect(Rect2(r.position, Vector2(r.size.x * frac, r.size.y)), col)


## Orbe: o vidro da textura recortado num círculo, escuro por cima do nível e cheio por baixo.
func _orb(c: Vector2, r: float, frac: float, tex: Texture2D) -> void:
	var full := PackedVector2Array()
	for i in 40:
		full.append(c + Vector2.from_angle(i * TAU / 40.0) * r)
	overlay.draw_colored_polygon(full, Color(0.22, 0.22, 0.22), _orb_uv(full, c, r, tex), tex)
	if frac <= 0.0:
		return
	var level := c.y + r - 2.0 * r * clampf(frac, 0.0, 1.0)
	var pts := PackedVector2Array()
	for q in full:
		pts.append(Vector2(q.x, maxf(q.y, level)))
	overlay.draw_colored_polygon(pts, Color.WHITE, _orb_uv(pts, c, r, tex), tex)


func _orb_uv(pts: PackedVector2Array, c: Vector2, r: float, tex: Texture2D) -> PackedVector2Array:
	var uv := PackedVector2Array()
	var ky := 0.4 * tex.get_width() / tex.get_height()
	for q in pts:
		uv.append(Vector2(0.5 + (q.x - c.x) / r * 0.4, 0.52 + (q.y - c.y) / r * ky))
	return uv


## Barra do chefe na placa da UI-02: enche do zero quando ele aparece, com o pedaço de dano.
func _boss_bar(e, vs: Vector2, y: float) -> void:
	var w := 460.0
	var h: float = w * UI.bar.get_height() / UI.bar.get_width()
	var r := Rect2(vs.x * 0.5 - w / 2.0, y, w, h)
	var name: String = e.title if e.title != "" else e.NAMES.get(e.kind, "Chefe")
	front.draw_texture_rect(UI.bar, r, false)
	var inner := Rect2(r.position.x + w * 0.17, r.position.y + h * 0.4, w * 0.66, h * 0.22)
	front.draw_rect(inner, Color(0.08, 0.02, 0.02))
	front.draw_rect(Rect2(inner.position, Vector2(inner.size.x * minf(e.bar_fill, e.hp_chunk / e.max_hp), inner.size.y)), Color(1.0, 0.85, 0.55))
	front.draw_rect(Rect2(inner.position, Vector2(inner.size.x * minf(e.bar_fill, maxf(e.hp, 0.0) / e.max_hp), inner.size.y)), Color(0.75, 0.08, 0.12))
	Gothic.draw_centered(front, vs.x * 0.5, r.position.y + h * 0.35, name, 21, Color(1.0, 0.85, 0.55), 5)


## Texto centrado: gótico (títulos, nomes, números) ou a letra normal para frases pequenas.
func _centered(text: String, y: float, size: int, col: Color, vs: Vector2, gothic := true) -> void:
	text = tr(text)
	if gothic:
		Gothic.draw_centered(front, vs.x * 0.5, y, text, size, col, maxi(5, size / 7))
		return
	var font := ThemeDB.fallback_font
	var x: float = vs.x * 0.5 - font.get_string_size(text, HORIZONTAL_ALIGNMENT_LEFT, -1, size).x / 2.0
	front.draw_string_outline(font, Vector2(x, y), text, HORIZONTAL_ALIGNMENT_LEFT, -1, size, maxi(4, size / 6), Color(0, 0, 0, col.a))
	front.draw_string(font, Vector2(x, y), text, HORIZONTAL_ALIGNMENT_LEFT, -1, size, col)


## Cartão do chefe: o nome entra a "bater" (grande e encolhe), numa faixa escura.
func _name_card(vs: Vector2) -> void:
	var k := 1.0 - card_t / CARD_T
	var pop := 1.0 + 0.7 * maxf(0.0, 1.0 - k / 0.05)
	var a := clampf(card_t / 0.5, 0.0, 1.0)
	var cy := vs.y * 0.33
	front.draw_rect(Rect2(0, cy - 62, vs.x, 116), Color(0, 0, 0, 0.45 * a))
	_centered("Chefe", cy - 32, 22, Color(1.0, 0.3, 0.3, a), vs)
	_centered(card_name, cy + 16, int(62 * pop), Color(0.85, 1.0, 0.85, a), vs)
	_centered(card_sub, cy + 44, 17, Color(0.75, 0.75, 0.7, a), vs, false)


## Subida de nível: texto grande a saltar e depois as recompensas, uma a uma.
func _level_card(vs: Vector2) -> void:
	var k := 1.0 - lvl_t / LVL_T
	var a := clampf(lvl_t / 0.4, 0.0, 1.0)
	var pop := 1.0 + 0.6 * maxf(0.0, 1.0 - k / 0.06)
	var cy := vs.y * 0.6  # por baixo do herói, para não tapar o cartão do chefe nem os avisos
	_centered(tr("Nível %d!") % main.level, cy, int(66 * pop), Color(1.0, 0.85, 0.4, a), vs)
	var lines := ["+1 Ponto na Árvore dos Condenados", "+8 Vida máxima"]
	for i in lines.size():
		var start := 0.2 + i * 0.12
		if k > start:
			var lp := 1.0 + 0.4 * maxf(0.0, 1.0 - (k - start) / 0.05)
			_centered(lines[i], cy + 36 + i * 28, int(19 * lp), Color(0.9, 1.0, 0.85, a), vs, false)


# ---------- Painéis ----------

## cancel: o B do comando (ou o Voltar do Android) fecha o painel.
## back = para onde B / Voltar levam (vazio: fecha o painel e volta ao jogo).
func _open_panel(title: String, cancel := true, back := Callable()) -> VBoxContainer:
	close_panel()
	get_tree().paused = true
	panel_cancel = cancel
	panel_back = back
	panel_frame = Engine.get_process_frames()
	for p in main.players:
		p.held.clear()
	var pc := PanelContainer.new()
	panel = pc
	root.add_child(pc)
	var box := VBoxContainer.new()
	box.add_theme_constant_override("separation", 6)
	pc.add_child(box)
	# Título do painel em letra gótica (desenhado, para os acentos saírem na mesma letra)
	var t := Control.new()
	t.custom_minimum_size = Vector2(Gothic.width(title, 32) + 10, 42)
	t.draw.connect(func(): Gothic.draw(t, Vector2(0, 33), title, 32, Color(0.95, 0.8, 0.5), 6))
	box.add_child(t)
	pc.set_anchors_and_offsets_preset(Control.PRESET_CENTER)
	pc.grow_horizontal = Control.GROW_DIRECTION_BOTH
	pc.grow_vertical = Control.GROW_DIRECTION_BOTH
	return box


func close_panel() -> void:
	if panel:
		panel.queue_free()
		panel = null
	panel_cancel = false
	panel_back = Callable()
	get_tree().paused = false
	for p in main.players:
		p.lock_skills = true  # o A que fechou o painel não sai como ataque
	if not title_open:
		main.save_game()  # o que se gastou ou escolheu no painel fica logo gravado


## Alguém perdeu o comando: pausa com aviso (Continuar no ecrã ou com outro comando).
func pad_lost(who: String, first: bool) -> void:
	if first:
		gamepad = false
	if panel != null:
		toast(tr("O comando de %s desligou-se.") % tr(who))
		return
	var box := _open_panel("Comando desligado")
	_text(box, tr("O comando de %s desligou-se.\nVolta a ligá-lo, ou continua com os controlos no ecrã.") % tr(who))
	_button(box, "Continuar", close_panel).grab_focus()


## Botão/gesto Voltar do Android: volta atrás no painel aberto ou abre o Menu (que pausa o jogo), em vez de sair.
func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_GO_BACK_REQUEST and main != null:
		if panel == null:
			open_menu()
		elif panel_cancel:
			_back()


func _back() -> void:
	if panel_back.is_valid():
		panel_back.call()
	else:
		close_panel()


## Arsenal e Árvore abertos direto (barra do ecrã, Vista no comando): B volta ao jogo.
func _arsenal() -> void:
	sub_back = Callable()
	open_arsenal()


func _tree(who := 0) -> void:
	sub_back = Callable()
	open_tree(who)


func _text(box: Control, text: String, col := Color(0.8, 0.8, 0.75)) -> void:
	var l := Label.new()
	l.text = text
	l.add_theme_color_override("font_color", col)
	box.add_child(l)


func _button(box: Control, text: String, cb: Callable, icon: Texture2D = null, width := 560.0) -> Button:
	var b := Button.new()
	b.text = text
	b.custom_minimum_size = Vector2(width, 42)
	b.icon = icon
	b.add_theme_constant_override("icon_max_width", 28)
	b.pressed.connect(cb)
	box.add_child(b)
	return b


func _art(tex: Texture2D, size: Vector2) -> TextureRect:
	var r := TextureRect.new()
	r.texture = tex
	r.custom_minimum_size = size
	r.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	r.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_COVERED
	r.clip_contents = true
	return r


## Ecrã de título com a arte de capa: Continuar (se há jogo gravado), Novo jogo, Co-op, Configurações e Sobre.
func open_title() -> void:
	title_open = true
	close_panel()
	get_tree().paused = true
	var c := Control.new()
	c.set_anchors_preset(Control.PRESET_FULL_RECT)
	var bg := _art(TITLE_ART, Vector2.ZERO)
	bg.set_anchors_preset(Control.PRESET_FULL_RECT)
	c.add_child(bg)
	var logo := VBoxContainer.new()
	logo.anchor_right = 1.0
	logo.offset_top = 24
	logo.offset_bottom = 150
	c.add_child(logo)
	for l in [["Soulstrider", 112, Color(0.88, 0.97, 0.88)], ["Necro-Dominion", 38, Color(0.45, 1.0, 0.65)]]:
		var lb := Label.new()
		lb.text = l[0]
		lb.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		lb.add_theme_font_override("font", Gothic.FONT)
		lb.add_theme_font_size_override("font_size", l[1])
		lb.add_theme_color_override("font_color", l[2])
		lb.add_theme_color_override("font_outline_color", Color.BLACK)
		lb.add_theme_constant_override("outline_size", 14)
		logo.add_child(lb)
	var menu := VBoxContainer.new()
	menu.anchor_left = 0.5
	menu.anchor_right = 0.5
	menu.anchor_top = 1.0
	menu.anchor_bottom = 1.0
	menu.offset_left = -200
	menu.offset_right = 200
	menu.offset_top = -190
	menu.offset_bottom = -24
	menu.add_theme_constant_override("separation", 10)
	menu.grow_vertical = Control.GROW_DIRECTION_BEGIN  # com o botão de atualizar, cresce para cima
	c.add_child(menu)
	title_menu = menu
	var ver := _label(Vector2.ZERO, 14)
	ver.reparent(c)
	ver.text = tr("Versão %s") % AppUpdate.VERSION_NAME
	ver.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_RIGHT)
	ver.offset_left = -140
	ver.offset_top = -28
	ver.offset_right = -12
	ver.offset_bottom = -8
	ver.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	ver.add_theme_color_override("font_color", Color(1, 1, 1, 0.55))
	var coop := func():
		_play()
		if main.players.size() < 2:
			main.add_player()
	var items := [[tr("Continuar · Nível %d") % main.level, _play]] if main.has_save() else []
	items += [["Novo jogo", _new_game], ["Co-op local — 2 jogadores", coop],
		["Configurações", func(): open_settings(0, open_title)], ["Sobre", func(): open_about(open_title)]]
	var first: Button
	for it in items:
		var b := _button(menu, it[0], it[1], null, 400.0)
		b.add_theme_font_override("font", Gothic.FONT)
		b.add_theme_font_size_override("font_size", 24)
		b.custom_minimum_size.y = 46
		if first == null:
			first = b
	# Legenda: com comando mostra os botões; no ecrã tátil basta tocar
	var tip := Control.new()
	tip.custom_minimum_size = Vector2(400, 24)
	tip.draw.connect(func():
		var parts := ["@a", " Escolher      ", "2.º comando: ", "@menu", " entra o Guardião"] if gamepad else ["Toca para escolher  ·  com comandos, cada jogador usa o seu"]
		_prompts(tip, Vector2(200, 17), parts, 15, 0.5))
	menu.add_child(tip)
	root.add_child(c)
	panel = c
	panel_cancel = false
	panel_frame = Engine.get_process_frames()
	first.grab_focus()
	if not updater.info.is_empty():
		_on_update(updater.info)


## Do título para o jogo (Continuar, Novo jogo sem nada gravado, Co-op).
func _play() -> void:
	title_open = false
	close_panel()


## Novo jogo: sem jogo gravado começa logo; com jogo gravado pede confirmação (apaga o progresso).
func _new_game() -> void:
	if not main.has_save():
		_play()
		return
	var box := _open_panel("Novo jogo", true, open_title)
	_text(box, "Começar de novo apaga o jogo gravado: nível, moedas, arma,\nÁrvore dos Condenados e Frascos de Alma. As configurações ficam.")
	var wipe := _button(box, "Apagar e começar de novo", main.new_game)
	wipe.add_theme_color_override("font_color", Color(1.0, 0.55, 0.5))
	wipe.add_theme_color_override("font_focus_color", Color(1.0, 0.65, 0.6))
	_button(box, "Voltar", open_title).grab_focus()


## Menu do jogo (Menu no comando, botão Menu no ecrã ou Voltar do Android): o jogo fica em pausa.
func open_menu(focus := 0, note := "") -> void:
	var box := _open_panel("Menu")
	var arsenal := func():
		sub_back = open_menu.bind(1)
		open_arsenal()
	var tree := func():
		sub_back = open_menu.bind(2)
		open_tree()
	var save := func():
		main.save_game()
		open_menu(3, tr("Jogo gravado às %s.") % Time.get_time_string_from_system().left(5))
	var to_title := func():
		main.save_game()
		main.restart(true)
	var items := [["Voltar ao jogo", close_panel], ["Arsenal", arsenal], ["Árvore dos Condenados", tree],
		["Salvar", save], ["Configurações", func(): open_settings(0, open_menu.bind(4))], ["Menu principal", to_title]]
	var btns := []
	for it in items:
		btns.append(_button(box, it[0], it[1], null, 420.0))
	if note != "":
		_text(box, note, Color(0.45, 1.0, 0.65))
	btns[focus].grab_focus()


## Configurações em separadores. Cada opção aplica-se logo e fica gravada à parte do jogo.
func open_settings(tab := 0, back := Callable()) -> void:
	var box := _open_panel("Configurações", true, back)
	var tabs := HBoxContainer.new()
	tabs.add_theme_constant_override("separation", 6)
	box.add_child(tabs)
	var here: Button
	for i in TABS.size():
		var b := _button(tabs, TABS[i], func(): open_settings(i, back), null, 150.0)
		if i == tab:
			b.add_theme_stylebox_override("normal", _sbt(UI.btn_on, Color.WHITE))
			b.add_theme_color_override("font_color", Color.WHITE)
			here = b
	var rows := VBoxContainer.new()
	rows.add_theme_constant_override("separation", 6)
	rows.custom_minimum_size = Vector2(620, 208)
	box.add_child(rows)
	match tab:
		0:
			_slider(rows, "Volume geral", "master")
			_slider(rows, "Música", "music")
			_slider(rows, "Efeitos sonoros", "sfx")
		1:
			_choice(rows, "Limite de FPS", "fps", ["30 · poupa bateria", "60", "O máximo do ecrã"])
			_choice(rows, "Resolução", "res", ["Alta", "Poupança (720p)"])
			_choice(rows, "Efeitos visuais", "effects", ["Baixos", "Médios", "Altos"])
			_choice(rows, "Mostrar FPS", "show_fps", ["Não", "Sim"])
		2:
			_choice(rows, "Idioma", "lang", ["Português", "English"], func(): open_settings(2, back))  # refaz o painel já no idioma novo
			_choice(rows, "Tremor do ecrã", "shake", ["Desligado", "Ligado"])
			_choice(rows, "Clarão nos críticos", "flash", ["Desligado", "Ligado"])
			_choice(rows, "Números de dano", "numbers", ["Escondidos", "À vista"])
		3:
			_choice(rows, "Tamanho dos botões", "ui", ["100%", "130%", "160%"])
			_choice(rows, "Opacidade dos botões", "opacity", ["100%", "75%", "50%"])
			_choice(rows, "Vibração", "vibrate", ["Desligada", "Ligada"])
			var map := Control.new()
			map.custom_minimum_size = Vector2(620, 30)
			map.draw.connect(func(): _prompts(map, Vector2(0, 21), ["Comando:  ", "@a", " ", "@x", " ", "@y", " habilidades   ", "@b", " interagir   ", "@lb", " ", "@rb", " poções   ", "@menu", " menu   ", "@view", " Árvore"], 15))
			rows.add_child(map)
	var reset := func():
		main.reset_settings()
		open_settings(tab, back)
	_button(box, "Repor predefinições", reset)
	_button(box, "Voltar", _back)
	here.grab_focus()


## Linha de uma opção: o nome à esquerda, o controlo à direita.
func _row(box: Control, label: String) -> HBoxContainer:
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 16)
	var l := Label.new()
	l.text = label
	l.custom_minimum_size = Vector2(250, 42)
	l.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	l.add_theme_color_override("font_color", Color(0.88, 0.84, 0.72))
	row.add_child(l)
	box.add_child(row)
	return row


## Escolha: cada toque (ou A) passa à seguinte. after = o que fazer depois de mudar.
func _choice(box: Control, label: String, key: String, names: Array, after := Callable()) -> void:
	var b := Button.new()
	b.custom_minimum_size = Vector2(300, 42)
	b.text = names[int(main.settings[key])]
	b.pressed.connect(func():
		var v := (int(main.settings[key]) + 1) % names.size()
		main.set_setting(key, v == 1 if main.settings[key] is bool else v)
		b.text = names[v]
		if after.is_valid():
			after.call())
	_row(box, label).add_child(b)


## Volume de 0 a 100% (com o foco, a cruz ou o stick mexem-no).
func _slider(box: Control, label: String, key: String) -> void:
	var row := _row(box, label)
	var s := HSlider.new()
	s.min_value = 0.0
	s.max_value = 100.0
	s.step = 10.0
	s.value = float(main.settings[key]) * 100.0
	s.custom_minimum_size = Vector2(240, 42)
	var val := Label.new()
	val.text = "%d%%" % s.value
	val.custom_minimum_size = Vector2(56, 42)
	val.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	s.value_changed.connect(func(v: float):
		main.set_setting(key, v / 100.0)
		val.text = "%d%%" % v)
	row.add_child(s)
	row.add_child(val)


## Sobre: o jogo, a versão, quem o fez e as licenças (o Godot e a letra pedem que se mostrem).
func open_about(back := Callable()) -> void:
	var box := _open_panel("Sobre", true, back)
	var top := HBoxContainer.new()
	top.add_theme_constant_override("separation", 20)
	var logo := _art(STUDIO_LOGO, Vector2(150, 150))
	logo.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	top.add_child(logo)
	var info := VBoxContainer.new()
	top.add_child(info)
	box.add_child(top)
	var head := Control.new()
	head.custom_minimum_size = Vector2(560, 48)
	head.draw.connect(func(): Gothic.draw(head, Vector2(0, 38), "Soulstrider: Necro-Dominion", 40, Color(0.88, 0.97, 0.88), 6))
	info.add_child(head)
	_text(info, tr("Versão %s") % AppUpdate.VERSION_NAME, Color(0.45, 1.0, 0.65))
	_text(info, "Um ARPG gótico para telemóvel: almas, ossos e o Cortejo Fúnebre.\nJoga-se no ecrã ou com comando, sozinho ou a dois.")
	_text(info, "Um jogo Pixel Lusitano · desenvolvido por AlizeOnMe", Color(1.0, 0.8, 0.4))
	_text(box, "Feito com o Godot Engine. Letra Pirata One (SIL Open Font License).", Color(0.65, 0.65, 0.6))
	_button(box, "Site: pixellusitano.com", func(): OS.shell_open("https://pixellusitano.com"))
	_button(box, "Contacto: contact@pixellusitano.com", func(): OS.shell_open("mailto:contact@pixellusitano.com"))
	_button(box, "Página do jogo e versões", func(): OS.shell_open("https://github.com/DaewonPT/Soulstrider/releases"))
	_button(box, "Licenças", func(): _licenses(open_about.bind(back)))
	_button(box, "Voltar", _back).grab_focus()


## Licenças: a do Godot e dos componentes que traz, e a da letra Pirata One (o stick faz rolar).
func _licenses(back: Callable) -> void:
	var box := _open_panel("Licenças", true, back)
	var text := "Godot Engine\n" + Engine.get_license_text() + "\n\n" + tr("Componentes incluídos no Godot:")
	for c in Engine.get_copyright_info():
		for part in c.parts:
			text += "\n• %s: %s (%s)" % [c.name, ", ".join(part.copyright), part.license]
	text += "\n\nPirata One\n" + FileAccess.get_file_as_string("res://fonts/PirataOne-OFL.txt")
	var sc := ScrollContainer.new()
	sc.custom_minimum_size = Vector2(680, 400)
	sc.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	var l := Label.new()
	l.text = text
	l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	l.custom_minimum_size.x = 660
	l.add_theme_font_size_override("font_size", 12)
	l.add_theme_color_override("font_color", Color(0.75, 0.75, 0.7))
	sc.add_child(l)
	box.add_child(sc)
	license_scroll = sc
	_button(box, "Voltar", _back).grab_focus()


## Há um APK novo no GitHub (AppUpdate): botão dourado por cima do Jogar, no ecrã de título.
func _on_update(info: Dictionary) -> void:
	if not is_instance_valid(title_menu) or title_menu.has_node("Update"):
		return
	var go := func():
		updater.open_download()
		toast(tr("A descarregar %s: quando acabar, abre o ficheiro para instalar.") % AppUpdate.file_name_of(String(info.get("apk", ""))))
	var b := _button(title_menu, tr("Nova versão %s — atualizar") % String(info.get("name", "")).trim_prefix("Soulstrider "), go, null, 400.0)
	b.name = "Update"
	b.add_theme_font_override("font", Gothic.FONT)
	b.add_theme_font_size_override("font_size", 24)
	b.custom_minimum_size.y = 52
	b.add_theme_color_override("font_color", Color(1.0, 0.84, 0.4))
	b.add_theme_color_override("font_focus_color", Color(1.0, 0.9, 0.55))
	title_menu.move_child(b, 0)


func open_arsenal(focus := 0) -> void:
	var box := _open_panel("Arsenal — Frascos de Alma", true, sub_back)
	var head := HBoxContainer.new()
	var icon := _art(ICONS.sealed if main.weapon.sealed else ICONS.weapon, Vector2(56, 56))
	icon.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	head.add_child(icon)
	_text(head, main.weapon_text(), Color(0.95, 0.85, 0.6))
	box.add_child(head)
	var buttons := []
	var c: Dictionary = main.currency
	buttons.append(_button(box, tr("Tinteiro de Sangue Negro (%d): rerrolar sufixos") % c.ink, func(): _spend("ink"), ICONS.ink))
	buttons.append(_button(box, tr("Cinzas do Purgatório (%d): revelar propriedade oculta") % c.ash, func(): _spend("ash"), ICONS.ash))
	buttons.append(_button(box, tr("5 Ossos Ancestrais (%d): reforjar a arma (+10%% dano)") % c.bone, func(): _spend("bone"), ICONS.bone))
	_text(box, "Suporte de cada habilidade (carrega para trocar):")
	# Em co-op, uma coluna por jogador para o painel caber no ecrã
	var grid := GridContainer.new()
	grid.columns = main.players.size()
	grid.add_theme_constant_override("h_separation", 8)
	box.add_child(grid)
	var w: float = 560.0 / main.players.size() - 4.0 * (main.players.size() - 1)
	# O que faz o frasco da habilidade escolhida (muda com o foco do comando ou ao tocar)
	var desc := Label.new()
	desc.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	desc.custom_minimum_size = Vector2(600, 44)
	desc.add_theme_color_override("font_color", Color(0.62, 0.78, 0.68))
	desc.text = tr("Frascos de Alma encontrados: %d de %d. Os chefes deixam os que faltam.") % [main.flasks.size() - 1, main.player.SUPPORTS.size() - 1]
	for i in 3:
		for p in main.players:
			var id: String = p.order[i]
			var s: Dictionary = p.skills[id]
			var idx := buttons.size()
			var cycle := func():
				p.cycle_support(id)
				open_arsenal(idx)
			var b := _button(grid, "%s — %s" % [tr(s.name), tr(p.SUPPORT_NAMES[s.support])], cycle, ICONS[s.support], w)
			b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
			var info := "%s: %s" % [tr(p.SUPPORT_NAMES[s.support]), tr(p.SUPPORT_DESC[s.support])]
			b.focus_entered.connect(func(): desc.text = info)
			buttons.append(b)
	box.add_child(desc)
	buttons.append(_button(box, "Fechar", _back))
	buttons[clampi(focus, 0, buttons.size() - 1)].grab_focus()


func _spend(kind: String) -> void:
	var msg: String = main.use_currency(kind)
	open_arsenal(["ink", "ash", "bone"].find(kind))
	toast(msg)


## Cortejo Fúnebre: o caminho das ondas até ao Arauto, os afixos em cartões (os das ondas anteriores
## ficam presos) e o saque da próxima onda, que sobe à medida que se junta perigo.
func open_cortejo() -> void:
	var w: int = main.cortejo.wave
	var box := _open_panel("Cortejo Fúnebre")
	var picks := {}
	var chosen := func() -> Array:
		return picks.keys().filter(func(k): return picks[k].button_pressed)
	var track := Control.new()
	track.custom_minimum_size = Vector2(620, 66)
	track.draw.connect(func(): _draw_track(track, w))
	box.add_child(track)
	_text(box, tr("Escolhe os afixos da onda %d. Ficam até ao fim do Cortejo: mais perigo, mais saque.") % (w + 1))
	var grid := GridContainer.new()
	grid.columns = 2
	grid.add_theme_constant_override("h_separation", 8)
	grid.add_theme_constant_override("v_separation", 6)
	box.add_child(grid)
	var reward := Control.new()
	reward.custom_minimum_size = Vector2(620, 76)
	reward.draw.connect(func(): _draw_reward(reward, w + 1, chosen.call()))
	for k in main.AFFIXES:
		var b := Button.new()
		b.toggle_mode = true
		b.text = "%s\n%s" % [tr(main.AFFIXES[k][0]), tr(main.AFFIXES[k][1])]
		b.icon = AFFIX_ICON[k]
		b.add_theme_constant_override("icon_max_width", 40)
		b.alignment = HORIZONTAL_ALIGNMENT_LEFT
		b.custom_minimum_size = Vector2(308, 60)
		if k in main.cortejo.affixes:
			b.button_pressed = true
			b.disabled = true
			b.add_theme_stylebox_override("disabled", _sbt(UI.btn_on, Color(0.7, 0.7, 0.7)))
			# presos desde a onda anterior: lêem-se como ativos, não como indisponíveis
			b.add_theme_color_override("font_disabled_color", Color(0.65, 0.9, 0.7))
			b.add_theme_color_override("icon_disabled_color", Color.WHITE)
		b.toggled.connect(func(_on): reward.queue_redraw())
		picks[k] = b
		grid.add_child(b)
	box.add_child(reward)
	var go := func():
		var sel: Array = chosen.call()
		close_panel()
		main.start_wave(sel)
	var start := _button(box, tr("Invocar a onda %d") % (w + 1), go)
	start.add_theme_font_override("font", Gothic.FONT)
	start.add_theme_font_size_override("font_size", 26)
	start.custom_minimum_size.y = 52
	if w > 0:
		var stop := func():
			main.end_cortejo()
			close_panel()
		_button(box, "Encerrar o Cortejo (guardas o que já caiu)", stop)
	else:
		_button(box, "Recuar", close_panel)
	start.grab_focus()


## Caminho das ondas: as feitas a verde, a próxima a brilhar, a última com o Arauto ao lado.
func _draw_track(ci: Control, done: int) -> void:
	var y := 24.0
	var xs := [110.0, 300.0, 490.0]
	ci.draw_line(Vector2(xs[0], y), Vector2(xs[2], y), Color(0.3, 0.27, 0.22), 4.0)
	if done > 0:
		ci.draw_line(Vector2(xs[0], y), Vector2(xs[mini(done, 2)], y), Color(0.4, 1.0, 0.6), 4.0)
	for i in 3:
		var c := Vector2(xs[i], y)
		var col := Color(0.4, 1.0, 0.6) if i < done else (Color(1.0, 0.85, 0.4) if i == done else Color(0.4, 0.37, 0.32))
		ci.draw_circle(c, 15.0, Color(0.06, 0.07, 0.07))
		ci.draw_arc(c, 15.0, 0, TAU, 24, col, 3.0)
		if i < done:
			ci.draw_circle(c, 8.0, col)
		elif i == done:
			ci.draw_arc(c, 21.0, 0, TAU, 24, Color(col, 0.4), 2.0)
		Gothic.draw_centered(ci, c.x, y + 40.0, "Arauto" if i == 2 else tr("Onda %d") % (i + 1), 19, col, 4)
	var h := 62.0
	ci.draw_texture_rect(HERALD_TEX, Rect2(xs[2] + 24, y - h * 0.6, h * HERALD_TEX.get_width() / HERALD_TEX.get_height(), h), false)


## Saque da próxima onda com os afixos escolhidos (o mesmo cálculo do jogo) e o perigo em caveiras.
func _draw_reward(ci: Control, w: int, sel: Array) -> void:
	var r: Dictionary = main.wave_rewards(w, sel)
	var head := tr("Saque ×%.1f") % main.reward_mult(sel)
	var y := 28.0
	Gothic.draw(ci, Vector2(6, y), head, 24, Color(1.0, 0.85, 0.4), 5)
	var x := _draw_currency(ci, 18.0 + Gothic.width(head, 24), y, r)
	if w >= main.WAVES:
		Gothic.draw(ci, Vector2(x, y), "no Relicário", 19, Color(0.75, 0.75, 0.7), 4)
	y += 38.0
	Gothic.draw(ci, Vector2(6, y), "Perigo", 22, Color(1.0, 0.4, 0.35), 5)
	for i in main.AFFIXES.size():
		ci.draw_texture_rect(SKULLS, Rect2(84 + i * 32, y - 22, 28, 22), false, Color.WHITE if i < sel.size() else Color(0.3, 0.3, 0.3, 0.6))


## Ícones das moedas com as quantidades (as que forem > 0), a partir de x; devolve onde acaba.
func _draw_currency(ci: Control, x: float, y: float, amounts: Dictionary) -> float:
	for k in ["bone", "ink", "ash"]:
		if amounts.get(k, 0) <= 0:
			continue
		ci.draw_texture_rect(ICONS[k], Rect2(x, y - 26, 30, 30), false)
		Gothic.draw(ci, Vector2(x + 34, y), str(amounts[k]), 24, Color(0.95, 0.9, 0.75), 5)
		x += 52.0 + Gothic.width(str(amounts[k]), 24)
	return x


## Árvore dos Condenados: raízes e ossadas com a arte da folha ICO-04 sobre o fundo BG-01.
## Um nó só abre se o nó de que nasce já estiver aberto.
func open_tree(who := 0, focus := "raiz") -> void:
	var p = main.players[who]
	var box := _open_panel(tr("Árvore dos Condenados — %s   (pontos: %d)") % [tr(p.hero_name), p.points], true, sub_back)
	var canvas := Control.new()
	canvas.custom_minimum_size = Vector2(640, 390)
	canvas.clip_contents = true
	box.add_child(canvas)
	var info := Label.new()
	info.custom_minimum_size = Vector2(640, 26)
	info.add_theme_color_override("font_color", Color(0.95, 0.85, 0.6))
	box.add_child(info)
	var nodes: Dictionary = main.PASSIVES
	var btns := {}
	canvas.draw.connect(func():
		canvas.draw_texture_rect(TREE.bg, Rect2(Vector2.ZERO, canvas.size), false, Color(0.75, 0.75, 0.75))
		for id in nodes:
			var n: Dictionary = nodes[id]
			if n.req == "":
				continue
			var a: Vector2 = nodes[n.req].pos
			var v: Vector2 = n.pos - a
			canvas.draw_set_transform(a, v.angle())
			canvas.draw_texture_rect(TREE.root_on if id in p.passives else TREE.root, Rect2(0, -8, v.length(), 16), false)
			canvas.draw_set_transform(Vector2.ZERO)
		var font := ThemeDB.fallback_font
		for id in nodes:
			var n: Dictionary = nodes[id]
			var kind: String = NODE_KIND.get(id, "node")
			var have: bool = id in p.passives
			var open: bool = not have and n.req in p.passives
			var d: float = NODE_SIZE[kind]
			var col := Color.WHITE if have or open else Color(0.45, 0.45, 0.45)
			if open:
				canvas.draw_circle(n.pos, d * 0.56, Color(1.0, 0.85, 0.4, 0.35))
			canvas.draw_texture_rect(TREE[kind + ("_on" if have else "")], Rect2(n.pos - Vector2(d, d) / 2.0, Vector2(d, d)), false, col)
			if btns.has(id) and btns[id].has_focus():
				canvas.draw_arc(n.pos, d * 0.6, 0, TAU, 32, Color(0.45, 1.0, 0.65), 3.0)
			var nm := tr(n.name)
			var tw := font.get_string_size(nm, HORIZONTAL_ALIGNMENT_LEFT, -1, 12).x
			canvas.draw_string_outline(font, n.pos + Vector2(-tw / 2.0, d * 0.5 + 13), nm, HORIZONTAL_ALIGNMENT_LEFT, -1, 12, 4, Color.BLACK)
			canvas.draw_string(font, n.pos + Vector2(-tw / 2.0, d * 0.5 + 13), nm, HORIZONTAL_ALIGNMENT_LEFT, -1, 12, col))
	var empty := StyleBoxEmpty.new()
	for id in nodes:
		var n: Dictionary = nodes[id]
		var d: float = NODE_SIZE[NODE_KIND.get(id, "node")]
		var have: bool = id in p.passives
		var open: bool = not have and n.req in p.passives
		var b := Button.new()
		b.flat = true
		b.position = n.pos - Vector2(d, d) / 2.0
		b.size = Vector2(d, d)
		for st in ["normal", "hover", "pressed", "focus"]:
			b.add_theme_stylebox_override(st, empty)
		var txt: String = "%s — %s%s" % [tr(n.name), tr(n.desc), "" if have or open else "  " + tr("(bloqueado)")]
		b.focus_entered.connect(func():
			info.text = txt
			canvas.queue_redraw())
		b.mouse_entered.connect(func(): info.text = txt)
		b.pressed.connect(func():
			if p.allocate(id):
				toast("%s: %s" % [tr(p.hero_name), tr(n.name)])
			open_tree(who, id))
		canvas.add_child(b)
		btns[id] = b
	if main.players.size() > 1:
		_button(box, tr("Ver árvore de %s") % tr(main.players[1 - who].hero_name), func(): open_tree(1 - who))
	_button(box, "Fechar", _back)
	btns[focus].grab_focus()


## info vem de main.die(): o que ficou no túmulo e se havia um túmulo antigo (que se desfez).
func open_death(info := {}) -> void:
	var box := _open_panel("A tua alma dissipou-se", false)
	var lost: Dictionary = info.get("lost", {})
	if lost.is_empty():
		_text(box, "Os mortos reclamam o que é deles.")
	else:
		_text(box, "Metade do que trazias ficou no teu túmulo, no cemitério:")
		var row := Control.new()
		row.custom_minimum_size = Vector2(0, 40)
		row.draw.connect(func(): _draw_currency(row, 6.0, 32.0, lost))
		box.add_child(row)
		_text(box, "Vai buscá-lo antes de voltares a morrer, senão perde-se.")
	if info.get("had_old", false):
		_text(box, "O túmulo anterior desfez-se com tudo o que lá estava.", Color(1.0, 0.5, 0.45))
	_button(box, "Erguer-se novamente", main.restart).grab_focus()  # recomeça já a jogar, do jogo gravado
