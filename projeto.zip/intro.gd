extends Control
## Intro: 4 planos sobre o mapa 32-bit da praça, com as personagens 32-bit animadas por cima. Faixas de cinema,
## a legenda a escrever-se letra a letra, o sino a dobrar (tremor, clarão e onda verde), almas a subir, raios
## e, no fim, o nome do jogo a cair com estrondo. O hud.gd trata dos toques e chama play() a cada plano.

const Player := preload("res://player.gd")
const Enemy := preload("res://enemy.gd")
const Gothic := preload("res://gothic.gd")
const HUB := preload("res://art/bg/hub.webp")
const BELL := preload("res://sfx/bell.wav")
const ROAR := preload("res://sfx/roar.wav")
const CRIT := preload("res://sfx/crit.wav")
const MONUMENT := Vector2(1376, 754)  # o poço da praça no mapa (main.gd: HUB_SPOT)
const TOP := 72.0  # faixas de cinema; a de baixo é mais alta, leva a legenda
const BOTTOM := 132.0
const GREEN := Color(0.45, 1.0, 0.65)
## Planos: legenda, duração, enquadramento no mapa (centro de partida, centro final, zoom de partida, zoom final),
## escuridão por cima do mapa.
const SHOTS := [
	["Quando o grande sino tocou, a necrópole acordou.", 7.0, Vector2(1376, 520), Vector2(1376, 754), 1.0, 1.3, 0.55],
	["O Arauto Fúnebre conduz o Cortejo: legiões de mortos que não descansam.", 7.0, Vector2(620, 1150), Vector2(820, 1080), 1.7, 1.8, 0.62],
	["De uma cova aberta ergueu-se um ceifeiro, com almas presas em frascos à cintura.", 7.0, Vector2(560, 520), Vector2(600, 560), 2.1, 2.3, 0.7],
	["Ele e o Guardião são tudo o que resta entre os vivos e o Cortejo.", 8.5, Vector2(1376, 860), Vector2(1376, 800), 1.6, 1.35, 0.5],
]
const SLAM_AT := 3.6  # quando o nome do jogo cai, no último plano
static var SOFT := _soft()  # mancha redonda que se esbate até às bordas (nevoeiro)


static func _soft() -> GradientTexture2D:
	var g := GradientTexture2D.new()
	g.gradient = Gradient.new()
	g.gradient.colors = PackedColorArray([Color.WHITE, Color(1, 1, 1, 0)])
	g.fill = GradientTexture2D.FILL_RADIAL
	g.fill_from = Vector2(0.5, 0.5)
	g.fill_to = Vector2(1.0, 0.5)
	return g

var shot := -1
var t := 0.0
var shake := 0.0
var flash := 0.0
var flash_col := Color.WHITE
var bars := 0.0  # 0 → 1: as faixas entram no início
var rings := []  # ondas do sino: [posição no ecrã, idade]
var bits := []  # partículas quadradas: [posição, velocidade, vida, vida total, cor, lado, alvo (ou null)]
var fog := []
var beats := {}  # o que já aconteceu neste plano (sinos, raios, o ceifeiro a acender)
var rng := RandomNumberGenerator.new()
var actors: Control  # personagens com píxeis nítidos (ampliadas sem esborratar)
var over: Control  # clarões, faixas e o nome do jogo
var caption: Label


func _ready() -> void:
	rng.seed = 1666
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	actors = _child(TEXTURE_FILTER_NEAREST)
	actors.draw.connect(_draw_actors)
	over = _child(TEXTURE_FILTER_PARENT_NODE)
	over.draw.connect(_draw_over)
	caption = Label.new()
	caption.add_theme_font_override("font", Gothic.FONT)  # legenda grande: fica na gótica (o tema do HUD é a Augusta)
	caption.add_theme_font_size_override("font_size", 32)
	caption.add_theme_color_override("font_color", Color(0.9, 0.95, 0.85))
	caption.add_theme_color_override("font_outline_color", Color.BLACK)
	caption.add_theme_constant_override("outline_size", 8)
	caption.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	caption.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	caption.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	caption.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_WIDE)
	caption.offset_left = 150
	caption.offset_right = -150
	caption.offset_top = -BOTTOM + 8
	caption.offset_bottom = -40
	add_child(caption)
	for i in 22:
		fog.append([Vector2(rng.randf(), rng.randf()), rng.randf_range(0.6, 1.4)])


func _child(filter: TextureFilter) -> Control:
	var c := Control.new()
	c.set_anchors_preset(Control.PRESET_FULL_RECT)
	c.mouse_filter = Control.MOUSE_FILTER_IGNORE
	c.texture_filter = filter
	add_child(c)
	return c


## Começa o plano i (0 a 3).
func play(i: int) -> void:
	shot = i
	t = 0.0
	beats.clear()
	rings.clear()
	bits.clear()
	caption.text = SHOTS[i][0]
	caption.visible_ratio = 0.0
	var tw := create_tween()
	tw.tween_interval(0.5)
	tw.tween_property(caption, "visible_ratio", 1.0, tr(SHOTS[i][0]).length() / 38.0)


func _process(delta: float) -> void:
	if shot < 0:
		return
	t += delta
	bars = minf(1.0, bars + delta * 1.5)
	shake = maxf(0.0, shake - delta * 2.2)
	flash = maxf(0.0, flash - delta * 2.5)
	for r in rings:
		r[1] += delta
	rings = rings.filter(func(r): return r[1] < 1.6)
	for b in bits:
		b[2] -= delta
		if b[6] != null:  # almas a rodopiar para dentro do ceifeiro
			var to: Vector2 = b[6] - b[0]
			b[1] = b[1].lerp(to.normalized().rotated(1.1) * 260.0 + to * 1.2, delta * 3.0)
		elif b[4].g < 0.5:  # terra: cai
			b[1].y += 900.0 * delta
		b[0] += b[1] * delta
	bits = bits.filter(func(b): return b[2] > 0.0 and (b[6] == null or b[0].distance_to(b[6]) > 14.0))
	_beats()
	queue_redraw()
	actors.queue_redraw()
	over.queue_redraw()


## Os momentos de cada plano, cada um uma só vez.
func _beats() -> void:
	var vs := size
	match shot:
		0:
			if _once("raio", 0.35):
				_flash(Color(0.85, 0.95, 1.0), 0.7)
			for at in [1.0, 4.2]:
				if _once("sino" + str(at), at):
					_bell(_to_screen(MONUMENT), 1.0 if at < 2.0 else 0.6)
			if t > 1.0 and rng.randf() < 0.55:  # almas a subir das campas
				_bit(Vector2(rng.randf_range(0, vs.x), rng.randf_range(vs.y * 0.3, vs.y)), Vector2(rng.randf_range(-15, 15), -rng.randf_range(40, 110)), 2.5, GREEN, 4.0)
		1:
			if _once("sino", 3.5):
				_bell(_herald_at() + Vector2(60, -150), 0.9)
		2:
			if _once("terra", 1.2):
				for i in 40:
					_bit(_reaper_at() + Vector2(rng.randf_range(-60, 60), -10), Vector2(rng.randf_range(-220, 220), -rng.randf_range(250, 600)), 1.2, Color(0.35, 0.25, 0.15), rng.randf_range(4, 8))
				shake = 0.5
			if _once("olhos", 2.6):
				_flash(GREEN, 0.55)
				shake = 0.8
				_sound(CRIT, -2.0)
				_sound(ROAR, -10.0, 0.7)
				rings.append([_reaper_at() + Vector2(0, -120), 0.0])
			if t > 2.6 and rng.randf() < 0.6:
				var a := rng.randf() * TAU
				_bit(_reaper_at() + Vector2(0, -110) + Vector2.from_angle(a) * 380.0, Vector2.ZERO, 3.0, GREEN, 5.0, _reaper_at() + Vector2(0, -100))
		3:
			if _once("raio", 1.4):
				_flash(Color(0.85, 0.95, 1.0), 0.5)
			if _once("nome", SLAM_AT):
				_flash(Color.WHITE, 0.8)
				shake = 1.2
				_sound(BELL, 0.0)
				_sound(ROAR, -6.0, 0.8)
				rings.append([Vector2(vs.x / 2.0, TOP + 120.0), 0.0])


func _once(key: String, at: float) -> bool:
	if t < at or beats.has(key):
		return false
	beats[key] = true
	return true


func _bell(at: Vector2, strength: float) -> void:
	_sound(BELL, -2.0 + 4.0 * (strength - 1.0))
	shake = maxf(shake, strength)
	_flash(GREEN, 0.35 * strength)
	rings.append([at, 0.0])


func _flash(col: Color, a: float) -> void:
	flash_col = col
	flash = maxf(flash, a)


func _bit(pos: Vector2, vel: Vector2, life: float, col: Color, side: float, target = null) -> void:
	bits.append([pos, vel, life, life, col, side, target])


func _sound(stream: AudioStream, db: float, pitch := 1.0) -> void:
	var a := AudioStreamPlayer.new()
	a.stream = stream
	a.volume_db = db
	a.pitch_scale = pitch
	a.bus = "Efeitos"
	a.finished.connect(a.queue_free)
	add_child(a)
	a.play()


func _shake_off() -> Vector2:
	return Vector2(sin(t * 61.0), cos(t * 47.0)) * 14.0 * shake * shake


## Enquadramento do mapa neste momento: [escala, canto do mapa no ecrã].
func _cam() -> Array:
	var s: Array = SHOTS[shot]
	var u := ease(clampf(t / s[1], 0.0, 1.0), -1.8)
	var z: float = lerpf(s[4], s[5], u)
	var k: float = maxf(size.x / HUB.get_width(), size.y / HUB.get_height()) * z
	var half := size / 2.0 / k
	var c: Vector2 = s[2].lerp(s[3], u).clamp(half, HUB.get_size() - half)
	return [k, size / 2.0 - c * k + _shake_off()]


func _to_screen(p: Vector2) -> Vector2:
	var cam := _cam()
	return cam[1] + p * cam[0]


func _draw() -> void:
	draw_rect(Rect2(Vector2.ZERO, size), Color.BLACK)
	if shot < 0:
		return
	var cam := _cam()
	draw_texture_rect(HUB, Rect2(cam[1], HUB.get_size() * cam[0]), false)
	var dark: float = SHOTS[shot][6]
	if shot == 0:  # o sino tira a necrópole da escuridão
		dark = lerpf(0.82, dark, clampf((t - 1.0) / 2.0, 0.0, 1.0))
	draw_rect(Rect2(Vector2.ZERO, size), Color(0.0, 0.02, 0.03, dark))
	# Nevoeiro a passar devagar
	for f in fog:
		var p := Vector2(fposmod(f[0].x * size.x + t * 22.0 * f[1], size.x + 400.0) - 200.0, f[0].y * size.y)
		var r: float = 170.0 * f[1]
		draw_texture_rect(SOFT, Rect2(p - Vector2(r, r * 0.6), Vector2(r, r * 0.6) * 2.0), false, Color(0.55, 0.7, 0.65, 0.12))


## Personagens 32-bit (os desenhos olham para a direita), com sombra no chão.
## sc = vezes o tamanho no jogo a dividir por 2 (1.0 = o dobro do tamanho de jogo); os pés ficam em feet.
func _sprite(kind: String, f: int, feet: Vector2, sc: float, flip := false, mod := Color.WHITE) -> void:
	var tex: Texture2D = (Player.FRAMES32 if kind in ["strider", "warden"] else Enemy.FRAMES32)[kind][f]
	var sz: Vector2 = tex.get_size() * sc * Player.Feet32.SCALE[kind + "32"] * 2.0
	actors.draw_set_transform(feet + _shake_off(), 0.0, Vector2(1.0, 0.4))
	actors.draw_circle(Vector2.ZERO, sz.y * 0.22, Color(0, 0, 0, 0.35 * mod.a))
	actors.draw_set_transform(feet + _shake_off(), 0.0, Vector2(-1.0 if flip else 1.0, 1.0))
	actors.draw_texture_rect(tex, Rect2(-sz.x / 2.0, -sz.y, sz.x, sz.y), false, mod)
	actors.draw_set_transform(Vector2.ZERO)


func _herald_at() -> Vector2:
	return Vector2(size.x * 0.30, size.y * 0.80) + Vector2(1.0, -0.42) * 60.0 * minf(t, 3.0) + Vector2(1.0, -0.42) * 60.0 * maxf(0.0, t - 4.2)


func _reaper_at() -> Vector2:
	return Vector2(size.x * 0.5, size.y * 0.74)


func _draw_actors() -> void:
	if shot < 0:
		return
	var vs := size
	var walk := int(t * 9.0) % 8
	var night := Color(0.78, 0.85, 0.82)
	match shot:
		1:  # o Cortejo: esqueletos e espectros atrás do Arauto, na diagonal do caminho
			var dir := Vector2(1.0, -0.42)
			var h := _herald_at()
			for k in range(9, 0, -1):
				var base := h - dir * (110.0 + k * 70.0) + dir.orthogonal() * (34.0 if k % 2 else -34.0)
				if k % 3 == 0:
					_sprite("specter", (walk + k) % 8, base + Vector2(0, -40.0 + sin(t * 3.0 + k) * 8.0), 0.85, false, Color(0.75, 0.9, 1.0, 0.85))
				else:
					_sprite("skeleton", (walk + k * 3) % 8, base, 0.85, false, night)
			var f := walk
			if t >= 3.0 and t < 4.2:  # o sino no chão
				f = 8 + mini(7, int((t - 3.0) * 7.0))
			_sprite("herald", f, h, 0.95, false, night)
		2:  # o ceifeiro ergue-se da cova
			var p := _reaper_at()
			actors.draw_circle(p + Vector2(0, -6), 70.0 + 6.0 * sin(t * 4.0), Color(0.3, 1.0, 0.55, 0.12 * clampf(t - 0.4, 0.0, 1.0)))
			if t >= 1.2:
				var f := 28 + mini(3, int((t - 1.2) / 0.32))
				if t >= 2.6:
					f = 16 + int((t - 2.6) * 7.0) % 8
				_sprite("strider", f, p, 1.55)
				if t >= 2.6:  # olhos acesos: um brilho que pulsa por cima do capuz
					var eyes := p + Vector2(2, -190) + _shake_off()
					actors.draw_circle(eyes, 10.0 + 3.0 * sin(t * 9.0), Color(0.45, 1.0, 0.65, 0.3))
		3:  # os dois heróis de costas um para o outro e a horda a fechar o cerco
			var c := Vector2(vs.x * 0.5, vs.y * 0.70)
			var close := minf(t, 5.0) * 70.0
			for k in 6:
				var y := c.y - 70.0 + k * 34.0
				_sprite("skeleton", (walk + k) % 8, Vector2(-60.0 - k * 46.0 + close, y), 0.9, false, night)
				_sprite("skeleton", (walk + k + 4) % 8, Vector2(vs.x + 60.0 + k * 46.0 - close, y), 0.9, true, night)
			_sprite("specter", walk, Vector2(vs.x * 0.2 + close * 0.5, c.y - 190.0 + sin(t * 2.0) * 10.0), 0.9, false, Color(0.75, 0.9, 1.0, 0.8))
			_sprite("specter", (walk + 4) % 8, Vector2(vs.x * 0.8 - close * 0.5, c.y - 200.0 + cos(t * 2.0) * 10.0), 0.9, true, Color(0.75, 0.9, 1.0, 0.8))
			var idle := 16 + int(t * 6.0) % 8
			_sprite("warden", idle, c + Vector2(-58, 4), 1.2, true)
			_sprite("strider", idle, c + Vector2(58, 0), 1.2)
	# Partículas em quadrados (como píxeis)
	for b in bits:
		var a: float = clampf(b[2] / b[3] * 1.5, 0.0, 1.0)
		var s: float = b[5]
		actors.draw_rect(Rect2(b[0] + _shake_off() - Vector2(s, s) / 2.0, Vector2(s, s)), Color(b[4], a))


func _draw_over() -> void:
	var vs := size
	# Ondas do sino
	for r in rings:
		var k: float = r[1] / 1.6
		over.draw_arc(r[0], 40.0 + 620.0 * ease(k, 0.4), 0, TAU, 64, Color(GREEN, 0.7 * (1.0 - k)), 10.0 * (1.0 - k) + 2.0)
	if flash > 0.0:
		over.draw_rect(Rect2(Vector2.ZERO, vs), Color(flash_col, flash * 0.6))
	# Bordas escuras
	for i in 6:
		var w := 26.0 * (6 - i)
		var col := Color(0, 0, 0, 0.07)
		over.draw_rect(Rect2(0, 0, w, vs.y), col)
		over.draw_rect(Rect2(vs.x - w, 0, w, vs.y), col)
	# O nome do jogo cai do alto e assenta com um estrondo
	if shot == 3 and t >= SLAM_AT:
		var k := clampf((t - SLAM_AT) / 0.28, 0.0, 1.0)
		var sc := lerpf(3.0, 1.0, ease(k, 2.4))
		var mid := Vector2(vs.x / 2.0, TOP + 150.0) + _shake_off()
		over.draw_set_transform(mid, 0.0, Vector2(sc, sc))
		Gothic.draw_centered(over, 0.0, 0.0, "SOULSTRIDER", 96, Color(0.85, 1.0, 0.88, k), 12)
		over.draw_set_transform(Vector2.ZERO)
		var sub := clampf((t - SLAM_AT - 0.8) / 0.8, 0.0, 1.0)
		Gothic.draw_centered(over, vs.x / 2.0, TOP + 200.0, "Necro-Dominion", 32, Color(0.95, 0.8, 0.5, sub), 6)
	# Faixas de cinema (entram no início), sempre por cima
	var e := ease(bars, 0.4)
	over.draw_rect(Rect2(0, 0, vs.x, TOP * e), Color.BLACK)
	over.draw_rect(Rect2(0, vs.y - BOTTOM * e, vs.x, BOTTOM * e), Color.BLACK)
	# Cada plano entra a partir do negro
	if t < 0.6:
		over.draw_rect(Rect2(Vector2.ZERO, vs), Color(0, 0, 0, 1.0 - t / 0.6))
