shader_type canvas_item;
// Uma folha do pixelfx a desvanecer (a aura da Dança dos Crânios): em vez de transparência, o pontilhado de Bayer 4x4 nos
// píxeis da própria folha (cada um 2x2 no ecrã); o alfa da cor é o limiar. A folha vem com o pivô e os frames em múltiplos
// de 4: o padrão bate com o pontilhado já cozido e não salta de um frame para o outro.

const float BAYER[16] = {0.0, 8.0, 2.0, 10.0, 12.0, 4.0, 14.0, 6.0, 3.0, 11.0, 1.0, 9.0, 15.0, 7.0, 13.0, 5.0};

varying vec4 tint;

void vertex() {
	tint = COLOR;
}

void fragment() {
	vec4 tex = texture(TEXTURE, UV);
	ivec2 g = ivec2(mod(floor(UV / TEXTURE_PIXEL_SIZE), 4.0));
	float th = (BAYER[g.y * 4 + g.x] + 0.5) / 16.0;
	COLOR = vec4(tex.rgb, tex.a > 0.5 && tint.a > th ? 1.0 : 0.0);
}
