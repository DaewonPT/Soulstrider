shader_type canvas_item;
// Silhueta atrás das paredes (#92): o desenho numa cor só (a cor e o alfa com que main o desenha),
// recortado pelo alfa da textura.

varying vec4 tint;

void vertex() {
	tint = COLOR;
}

void fragment() {
	COLOR = vec4(tint.rgb, texture(TEXTURE, UV).a * tint.a);
}
