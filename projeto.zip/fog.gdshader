shader_type canvas_item;
// Nevoeiro do cemitério: um banco de ruído (textura que se repete) lido em coordenadas do mundo, em células de 2 px,
// com três tons de orlas pontilhadas (Bayer) e uma crista mais clara onde o nevoeiro acaba por cima. Manchas grandes
// e lentas dizem onde há nevoeiro; o vento arrasta-o e ondula-o. Um só quadro do tamanho da vista.
// Efeitos adaptados de Sprite Fusion Pixel Art VFX (MIT, (c) 2026 Hugo Duprez)

uniform sampler2D field : repeat_enable, filter_linear;
uniform vec3 tone0 : source_color = vec3(0.180, 0.231, 0.212);
uniform vec3 tone1 : source_color = vec3(0.290, 0.369, 0.333);
uniform vec3 tone2 : source_color = vec3(0.478, 0.561, 0.518);
uniform float density = 0.8;
uniform float wind = 12.0;
uniform float depth = 0.5;  // 0,5 nos efeitos médios, 1 nos altos: mais lento, mais esticado e mais denso

const float BAYER[16] = {0.0, 8.0, 2.0, 10.0, 12.0, 4.0, 14.0, 6.0, 3.0, 11.0, 1.0, 9.0, 15.0, 7.0, 13.0, 5.0};
const float T0 = 0.3;
const float T1 = 0.52;
const float T2 = 0.74;
const float BW = 0.07;

varying vec2 world;

void vertex() {
	world = VERTEX;  // o nó está na origem: VERTEX já é o mundo
}

float noise(vec2 p) {
	return texture(field, p / 256.0).r;
}

float thick(float spot, float n) {
	return (spot * 0.72 + (clamp((n - 0.5) * 2.6 + 0.5, 0.0, 1.0) - 0.5) * 0.95) * (0.6 + 0.5 * density);
}

void fragment() {
	vec2 c = floor(world / 2.0);
	ivec2 g = ivec2(mod(c, 4.0));
	float b = (BAYER[g.y * 4 + g.x] + 0.5) / 16.0;
	float drift = TIME * wind * (0.4 + 0.8 * depth) / 2.0;
	float curl = TIME * (0.6 + 0.5 * depth);
	float off = depth * 97.3;
	float wu = noise(vec2(c.x * 0.35 + curl * 9.0 + off, c.y * 0.6 - curl * 3.0)) - 0.5;
	vec2 sc = vec2(0.3 + 0.25 * depth, 0.6 + 0.3 * depth);
	vec2 uv = vec2(c.x * sc.x - drift + wu * 30.0 + off, c.y * sc.y + wu * 12.0);
	float spot = smoothstep(0.45, 0.7, noise(c * 0.05 + vec2(off - drift * 0.1, off)));
	float f = thick(spot, noise(uv));
	int tone = -1;
	if (f > T2 + BW || (f > T2 && (f - T2) / BW > b)) {
		tone = 2;
	} else if (f > T1 + BW || (f > T1 && (f - T1) / BW > b)) {
		tone = 1;
	} else if (f > T0 + BW || (f > T0 && (f - T0) / BW > b)) {
		tone = 0;
	}
	float alpha = (0.2 + 0.16 * depth) * density;
	vec3 col = tone == 2 ? tone2 : tone == 1 ? tone1 : tone0;
	if (tone < 0) {
		COLOR = vec4(0.0);  // sem discard: nos GPU de telemóvel sai mais barato
	} else if (tone >= 1 && thick(spot, noise(uv - vec2(0.0, 2.0 * sc.y))) < (tone == 2 ? T2 : T1) - 0.03) {
		// A crista: 2 células acima já não há este tom
		COLOR = vec4(mix(tone2, vec3(1.0), 0.14 + 0.12 * depth), alpha * (0.95 + 0.15 * float(tone)));
	} else {
		COLOR = vec4(col, alpha * (0.6 + 0.2 * float(tone)));
	}
}
