extends RefCounted
## Peças comuns dos efeitos em píxeis (fx.gd, loot.gd): a grelha de 2 px, o pontilhado de Bayer, as rampas de cores do jogo,
## o brilho aditivo (um só quadro com textura), discos e glifos já cozidos (nada de ciclos por píxel a cada frame).
## Efeitos adaptados de Sprite Fusion Pixel Art VFX (MIT, (c) 2026 Hugo Duprez)

const S := 2.0  # 1 píxel do efeito = 2 px do mundo
const BAYER := [0, 8, 2, 10, 12, 4, 14, 6, 3, 11, 1, 9, 15, 7, 13, 5]
# Rampas do claro para o escuro, tiradas das cores do jogo; viajam ao convidado pelo nome
const RAMPS := {
	"bone": [Color("ffffff"), Color("f4eedc"), Color("e6dbbf"), Color("cbbe9c"), Color("a39677"), Color("6e6450"), Color("3e3830"), Color("1e1b18")],
	"iron": [Color("ffffff"), Color("e3eaf5"), Color("b8c7e6"), Color("8c9dbf"), Color("66789c"), Color("485670"), Color("2e3747"), Color("171c24")],
	"soul": [Color("ffffff"), Color("dfffea"), Color("9cffc4"), Color("59ff99"), Color("2fd27a"), Color("1f9a5e"), Color("155e40"), Color("0b2e22")],
	"rot": [Color("efffc8"), Color("c6f27a"), Color("9be04f"), Color("73c93e"), Color("4e9a32"), Color("35692a"), Color("22401f"), Color("131f12")],
	"necro": [Color("ffffff"), Color("ebd9ff"), Color("c9a3f5"), Color("9e5cd9"), Color("7638b0"), Color("4e2378"), Color("2c1347"), Color("140a22")],
	"bleed": [Color("f07a7a"), Color("c8202f"), Color("9a1526"), Color("6e0e1c"), Color("440813"), Color("24040a")],
	"ash": [Color("d8d4cc"), Color("b3aea3"), Color("8a857c"), Color("6b665c"), Color("4a4640"), Color("2e2b28")],
	"gold": [Color("ffffff"), Color("fff0b8"), Color("ffd966"), Color("ffbf4d"), Color("d98a2b"), Color("8c4a1a")],
	"life": [Color("ffffff"), Color("ffe0dc"), Color("ffa59c"), Color("ff5a5a"), Color("d92b3a"), Color("a01a2c"), Color("64101f"), Color("360812")],
	"soulblue": [Color("ffffff"), Color("ddf0ff"), Color("a6d6ff"), Color("59b3ff"), Color("3580d9"), Color("2552a0"), Color("18316a"), Color("0d1a3d")],
	# O saque a voar para o herói: osso dourado, tinta vermelha, cinzas cor de brasa
	"loot_bone": [Color("ffffff"), Color("fff4d6"), Color("f2d98c"), Color("c9a85c"), Color("7a6236"), Color("2e2414")],
	"loot_ink": [Color("ffe0e0"), Color("ff8a8a"), Color("d91f2e"), Color("8c1220"), Color("4a0912"), Color("1a0306")],
	"loot_ash": [Color("fff6e0"), Color("ffd08a"), Color("ff9933"), Color("c2621f"), Color("6e3412"), Color("2a1408")],
}
# Gotas da poção de alma (5x8 e 3x5): 1-4 = tom da rampa, w = branco
const DROP := [["..1..", "..2..", ".122.", ".1223", "1w223", "12223", "22234", ".334."], [".1.", ".2.", "1w3", "223", ".3."]]
const OUTLINE := Color("1a1422")
const SOOT := Color("0d0a12")

static var _glow: GradientTexture2D
static var _discs := {}
static var _glyphs := {}
static var _rows := {}
static var _sparkles := {}


static func ramp(name: String) -> Array:
	return RAMPS.get(name, RAMPS.bone)


## Limiar do pontilhado 4x4 na célula (x, y) da grelha do mundo (vizinhos partilham o padrão).
static func bayer(x: int, y: int) -> float:
	return (BAYER[((y & 3) << 2) | (x & 3)] + 0.5) / 16.0


## O canto da célula de 2 px onde cai o ponto p (coordenadas locais de um nó já alinhado à grelha).
static func cell(p: Vector2) -> Vector2:
	return (p / S).floor() * S


static func px(ci: CanvasItem, p: Vector2, c: Color, w := 1, h := 1) -> void:
	ci.draw_rect(Rect2(cell(p), Vector2(w, h) * S), c)


## Risco de 2 px entre a e b (alinhado ao meio das células).
static func line(ci: CanvasItem, a: Vector2, b: Vector2, c: Color) -> void:
	ci.draw_line(cell(a) + Vector2.ONE, cell(b) + Vector2.ONE, c, S)


## Ruído estável por (n, k), de 0 a 1: o mesmo nos dois lados do co-op sem guardar nada.
static func hashf(n: int, k := 0) -> float:
	return (((n + 1 + k * 7919) * 2654435761) & 0xFFFFFFFF) % 100000 / 100000.0


## Brilho (1-d)² num quadro aditivo: o nó ci tem de ter o material de soma.
static func glow(ci: CanvasItem, at: Vector2, r: float, c: Color, k: float) -> void:
	if r >= 1.0:
		glow_box(ci, Rect2(at - Vector2(r, r), Vector2(r, r) * 2.0), c, k)


## O mesmo brilho esticado num retângulo (uma coluna de luz, uma linha no chão): um quadro em vez de vários.
static func glow_box(ci: CanvasItem, box: Rect2, c: Color, k: float) -> void:
	if k > 0.01:
		ci.draw_texture_rect(glow_tex(), box, false, Color(c, k))


## A textura do brilho (fx.gd desenha-a direto nas partículas: duas chamadas a menos por cada uma).
static func glow_tex() -> GradientTexture2D:
	if _glow == null:
		var g := Gradient.new()
		g.offsets = PackedFloat32Array([0.0, 0.25, 0.5, 0.75, 1.0])
		g.colors = PackedColorArray([Color.WHITE, Color(1, 1, 1, 0.5625), Color(1, 1, 1, 0.25), Color(1, 1, 1, 0.0625), Color(1, 1, 1, 0)])
		_glow = GradientTexture2D.new()
		_glow.gradient = g
		_glow.fill = GradientTexture2D.FILL_RADIAL
		_glow.fill_from = Vector2(0.5, 0.5)
		_glow.fill_to = Vector2(1.0, 0.5)
		_glow.width = 32  # pequena e sem suavizar: o brilho fica aos degraus, como os píxeis
		_glow.height = 32
	return _glow


## Disco cheio de raio r células (cozido uma vez por raio, desenhado com a cor e o alfa de c).
static func disc(ci: CanvasItem, at: Vector2, r: float, c: Color) -> void:
	var n := clampi(roundi(r), 1, 24)
	if not _discs.has(n):
		var img := Image.create(n * 2, n * 2, false, Image.FORMAT_RGBA8)
		for y in n * 2:
			for x in n * 2:
				if (x + 0.5 - n) ** 2 + (y + 0.5 - n) ** 2 <= n * n:
					img.set_pixel(x, y, Color.WHITE)
		_discs[n] = ImageTexture.create_from_image(img)
	ci.draw_texture_rect(_discs[n], Rect2(cell(at) - Vector2(n, n) * S, Vector2(n, n) * S * 2.0), false, c)


## Elipse cheia aos riscos de 2 px (um por linha): rx, ry em px do mundo. Os riscos de cada tamanho (ao px) guardam-se
## e vão todos numa só chamada (a elipse grande do pilar tinha 53 quadros por frame).
static func ellipse(ci: CanvasItem, at: Vector2, rx: float, ry: float, c: Color) -> void:
	var key := Vector2i(roundi(rx), roundi(ry))
	if key.y < 1:
		return
	if not _rows.has(key):
		var pts := PackedVector2Array()
		var rows := floori(key.y / S)
		for j in range(-rows, rows + 1):
			var hw := ceilf(key.x / S * sqrt(maxf(0.0, 1.0 - pow((j + 0.5) * S / key.y, 2.0)))) * S
			if hw > 0.0:
				pts.append_array([Vector2(-hw, j * S + 1.0), Vector2(hw, j * S + 1.0)])
		_rows[key] = pts
	if not _rows[key].is_empty():
		ci.draw_set_transform(cell(at))
		ci.draw_multiline(_rows[key], c, S)
		ci.draw_set_transform(Vector2.ZERO)


## Cruz de brilho de n células: braços na cor c (a ponta em tip), diagonais a partir de 3, o meio branco. Cozida uma vez
## por tamanho e cores: um quadro por estrela em vez de 5 a 17 (o pilar e as poções largam dezenas).
static func sparkle(ci: CanvasItem, at: Vector2, n: int, c: Color, tip: Color) -> void:
	if n < 1:
		return
	var key := [n, c, tip]
	if not _sparkles.has(key):
		var img := Image.create(n * 2 + 1, n * 2 + 1, false, Image.FORMAT_RGBA8)
		var m := maxi(1, ceili(n * 0.6))
		for i in range(1, n + 1):
			for d in [Vector2i.RIGHT, Vector2i.LEFT, Vector2i.DOWN, Vector2i.UP]:
				img.set_pixelv(Vector2i(n, n) + d * i, c if i <= m else tip)
		if n >= 3:
			for d in [Vector2i(1, 1), Vector2i(1, -1), Vector2i(-1, 1), Vector2i(-1, -1)]:
				img.set_pixelv(Vector2i(n, n) + d, c)
				if n >= 6:
					img.set_pixelv(Vector2i(n, n) + d * 2, tip)
		img.set_pixel(n, n, Color.WHITE)
		_sparkles[key] = CanvasTexture.new()  # sem suavizar, seja qual for o filtro do nó
		_sparkles[key].diffuse_texture = ImageTexture.create_from_image(img)
		_sparkles[key].texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	ci.draw_texture_rect(_sparkles[key], Rect2(cell(at) - Vector2(n, n) * S, Vector2(n * 2 + 1, n * 2 + 1) * S), false)


## Estrela de 8 raios (brilho do saque raro): 4 longos de L células em três cores e 4 diagonais curtas, a rodar ang.
static func flare(ci: CanvasItem, at: Vector2, L: float, ang: float, c1: Color, c2: Color, a := 1.0) -> void:
	if L < 0.8 or a <= 0.01:
		return
	var o := cell(at) + Vector2.ONE
	for i in 8:
		var d := Vector2.from_angle(ang + i * TAU / 8.0) * S
		if i % 2 == 1:
			ci.draw_line(o, o + d * L * 0.21, Color(c1, a), S)
			ci.draw_line(o + d * L * 0.21, o + d * L * 0.42, Color(c2, a), S)
			continue
		if L > 4.0:  # a base dos raios longos é mais grossa
			ci.draw_line(o, o + d * L * 0.22, Color(c1, a), S * 3.0)
		ci.draw_line(o, o + d * L * 0.3, Color(Color.WHITE, a), S)
		ci.draw_line(o + d * L * 0.3, o + d * L * 0.65, Color(c1, a), S)
		ci.draw_line(o + d * L * 0.65, o + d * L, Color(c2, a * 0.6), S)
	ci.draw_rect(Rect2(o - Vector2.ONE, Vector2(S, S)), Color(Color.WHITE, a))


## Cruz da cura (braço L, meia largura w, contorno e relevo) ou gota da alma (shape 0 grande, 1 pequena), cozida uma vez.
static func glyph(r: Array, cross: bool, L: int, w: int, glint: bool) -> ImageTexture:
	var key := [r[3], cross, L, w, glint]
	if _glyphs.has(key):
		return _glyphs[key]
	var rows: Array = [] if cross else DROP[L]
	var n: int = L * 2 + 3 if cross else rows[0].length() + 2
	var m: int = n if cross else rows.size() + 2
	var inside := func(x: int, y: int) -> bool:  # na grelha do vidrado (sem a moldura de 1 px do contorno)
		if cross:
			var dx := x - L - 1
			var dy := y - L - 1
			return (absi(dx) <= w and absi(dy) <= L) or (absi(dy) <= w and absi(dx) <= L)
		return y >= 1 and y <= rows.size() and x >= 1 and x <= rows[0].length() and rows[y - 1][x - 1] != "."
	var img := Image.create(n, m, false, Image.FORMAT_RGBA8)
	for y in m:
		for x in n:
			var c := Color.TRANSPARENT
			if inside.call(x, y):
				if cross:
					var top: bool = not inside.call(x, y - 1) or not inside.call(x - 1, y)
					var low: bool = not inside.call(x, y + 1) or not inside.call(x + 1, y)
					c = (r[2] if y < L + 1 or x < L + 1 else r[4]) if w == 0 else r[2] if top else r[5] if low else r[3]  # um tom abaixo da biblioteca: cruzes vermelhas, não rosa
					if glint and ((x == L + 1 and y == L + 1) or (w > 0 and x == L + 1 - w and y == 1)):
						c = Color.WHITE
				else:
					var ch: String = rows[y - 1][x - 1]
					c = Color.WHITE if ch == "w" or (glint and ch == "1") else r[int(ch)]
			elif inside.call(x - 1, y) or inside.call(x + 1, y) or inside.call(x, y - 1) or inside.call(x, y + 1):
				c = OUTLINE
			img.set_pixel(x, y, c)
	_glyphs[key] = ImageTexture.create_from_image(img)
	return _glyphs[key]


static func smooth(a: float, b: float, x: float) -> float:
	var k := clampf((x - a) / (b - a), 0.0, 1.0)
	return k * k * (3.0 - 2.0 * k)


static func out_expo(k: float) -> float:
	return 1.0 if k >= 1.0 else 1.0 - pow(2.0, -10.0 * clampf(k, 0.0, 1.0))


static func out_cubic(k: float) -> float:
	return 1.0 - pow(1.0 - clampf(k, 0.0, 1.0), 3.0)


static func out_back(k: float) -> float:
	var u := clampf(k, 0.0, 1.0) - 1.0
	return 1.0 + 2.7 * u * u * u + 1.7 * u * u


# ---------- Círculos cozidos: o chão, os avisos e as auras ----------
# Células de 2 px, contorno escuro, pontilhado de Bayer em vez de transparência. Cada desenho coze-se uma vez, aos pedaços
# de linha (fill_rect, blit_rect): o custo cresce com o raio e não com a área. A chave é forma + raio + rampa. Rodar uma
# textura borrava a grelha: o que roda ou anda são frames cozidos ou peças alinhadas à grelha (stamp).

const BAKE_MAX := 16 * 1048576  # bytes das texturas; passando disto saem as menos usadas (nunca as deste frame)
const LOOPS_MAX := 600  # anéis finos guardados (não usam textura)
const WARN_STEPS := 12
const SAW_FRAMES := 12
const SAW_R := 46.0  # a ponta dos dentes: o raio que corta (main._crypt_tick)
const FLAME_H := [18, 23, 26, 21]
const RUNES := [["1.1", "111", ".1.", ".1.", ".1."], ["11.", "1.1", "11.", "1.1", "1.1"], [".1.", "1.1", ".1.", "1.1", ".1."], ["1.1", ".1.", "111", ".1.", "1.1"]]

static var _tex := {}  # chave -> [textura, bytes, último frame em que se desenhou]
static var _loops := {}
static var _walls := {}
static var bake_n := 0  # quantas cozeduras, quantos bytes vivos, tempo total e a pior (medidas e smoke)
static var bake_bytes := 0
static var bake_usec := 0
static var bake_worst := 0


static func _hit(key: Array) -> CanvasTexture:
	var v = _tex.get(key)
	if v == null:
		return null
	v[2] = Engine.get_process_frames()
	return v[0]


static func _store(key: Array, img: Image, t0: int) -> CanvasTexture:
	var ct := CanvasTexture.new()
	ct.diffuse_texture = ImageTexture.create_from_image(img)
	ct.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST  # sem suavizar, seja qual for o filtro do nó
	var size := img.get_width() * img.get_height() * 4
	var now := Engine.get_process_frames()
	if bake_bytes + size > BAKE_MAX:
		var old: Array = _tex.keys().filter(func(k): return _tex[k][2] < now - 1)
		old.sort_custom(func(a, b): return _tex[a][2] < _tex[b][2])
		for k in old:
			if bake_bytes + size <= BAKE_MAX * 0.75:  # de uma vez: a próxima cozedura não volta a ordenar a cache toda
				break
			bake_bytes -= _tex[k][1]
			_tex.erase(k)
	_tex[key] = [ct, size, now]
	bake_bytes += size
	bake_n += 1
	var dt := Time.get_ticks_usec() - t0
	bake_usec += dt
	bake_worst = maxi(bake_worst, dt)
	return ct


static func _img(w: int, h: int) -> Image:
	return Image.create_empty(w, h, false, Image.FORMAT_RGBA8)


static func _tone(r: Array, i: int) -> Color:  # as rampas têm 6 ou 8 cores
	return r[clampi(i, 0, r.size() - 1)]


## O ponto local de ci que cai na grelha do mundo: os nós que andam não estão alinhados.
static func snap(ci: Node2D, p: Vector2) -> Vector2:
	return ((ci.global_position + p) / S).floor() * S - ci.global_position


## n x n células de c na grelha do mundo.
static func dot(ci: Node2D, at: Vector2, c: Color, n := 1) -> void:
	ci.draw_rect(Rect2(snap(ci, at), Vector2(n, n) * S), c)


## Textura de células centrada em at.
static func stamp(ci: Node2D, tex: Texture2D, at: Vector2, c := Color.WHITE) -> void:
	var sz := tex.get_size()
	ci.draw_texture_rect(tex, Rect2(snap(ci, at) - (sz / 2.0).floor() * S, sz * S), false, c)


## Textura de células assente em at (feixes e chamas: a base no chão).
static func stand(ci: Node2D, tex: Texture2D, at: Vector2, c := Color.WHITE) -> void:
	var sz := tex.get_size()
	ci.draw_texture_rect(tex, Rect2(snap(ci, at) - Vector2(floorf(sz.x / 2.0), sz.y) * S, sz * S), false, c)


static func _put(img: Image, x: float, y: float, c: Color) -> void:
	var i := floori(x)
	var j := floori(y)
	if i >= 0 and j >= 0 and i < img.get_width() and j < img.get_height():
		img.set_pixel(i, j, c)


## Entre a elipse de fora (ox, oy) e a de dentro (ix, iy), do meio da imagem, linha a linha. Luz de cima: back em cima, mid
## ao meio, front em baixo. Com tile copia o pontilhado em vez de pintar.
static func _annulus(img: Image, ox: float, oy: float, ix: float, iy: float, front: Color, mid: Color, back: Color, tile: Image = null) -> void:
	var cx := img.get_width() / 2
	var cy := img.get_height() / 2
	for j in range(maxi(0, cy - ceili(oy)), mini(img.get_height(), cy + ceili(oy))):
		var y := j + 0.5 - cy
		if absf(y) >= oy:
			continue
		var a := roundi(ox * sqrt(1.0 - y * y / (oy * oy)))
		var b := mini(a - 1, roundi(ix * sqrt(1.0 - y * y / (iy * iy)))) if absf(y) < iy else 0
		if a <= b:
			continue
		if tile != null:
			img.blit_rect_mask(tile, tile, Rect2i(cx - a, j, a - b, 1), Vector2i(cx - a, j))
			img.blit_rect_mask(tile, tile, Rect2i(cx + b, j, a - b, 1), Vector2i(cx + b, j))
		else:
			var s := y / oy
			var c: Color = front if s > 0.25 else mid if s > -0.3 else back
			img.fill_rect(Rect2i(cx - a, j, a - b, 1), c)
			img.fill_rect(Rect2i(cx + b, j, a - b, 1), c)


## Anel que acaba em rx, ry (o que se desenha e o que conta), com o contorno 1 célula para cada lado.
static func _ring(img: Image, rx: float, ry: float, th: float, front: Color, mid: Color, back: Color, outline := true) -> void:
	var ty := maxf(1.0, th * ry / rx)
	if outline:
		_annulus(img, rx + 1.0, ry + 1.0, rx - th - 1.0, ry - ty - 1.0, OUTLINE, OUTLINE, OUTLINE)
	_annulus(img, rx, ry, rx - th, ry - ty, front, mid, back)


## Buracos no anel de _ring, contorno incluído: at em radianos na elipse, w de meia largura.
static func _gaps(img: Image, rx: float, ry: float, th: float, at: Array, w: float) -> void:
	var cx := img.get_width() / 2.0
	var cy := img.get_height() / 2.0
	var ty := maxf(1.0, th * ry / rx) + 2.0
	var n := ceili(w * rx * 2.0) + 1
	var m := ceili(th) * 2 + 4
	for a in at:
		for i in range(-n, n + 1):
			var d := Vector2.from_angle(a + w * i / n)
			for o in m + 1:
				var f := float(o) / m
				_put(img, cx + d.x * (rx + 1.0 - (th + 2.0) * f), cy + d.y * (ry + 1.0 - ty * f), Color.TRANSPARENT)


## Imagem do tamanho sz com o pontilhado de densidade d, feita de um ladrilho 4x4 a dobrar.
static func _tile(sz: Vector2i, c: Color, d: float) -> Image:
	var img := _img(sz.x, sz.y)
	for y in mini(4, sz.y):
		for x in mini(4, sz.x):
			if bayer(x, y) < d:
				img.set_pixel(x, y, c)
	var w := 4
	while w < sz.x:
		img.blit_rect(img, Rect2i(0, 0, w, mini(4, sz.y)), Vector2i(w, 0))
		w *= 2
	var h := 4
	while h < sz.y:
		img.blit_rect(img, Rect2i(0, 0, sz.x, h), Vector2i(0, h))
		h *= 2
	return img


## Pontilhado numa elipse às bandas: dens(d) dá a densidade à distância d (0 no meio, 1 na borda).
static func _dither(img: Image, rx: float, ry: float, c: Color, dens: Callable, bands := 6) -> void:
	for b in bands:
		var d0 := float(b) / bands
		var d1 := (b + 1.0) / bands
		var v: float = dens.call((d0 + d1) * 0.5)
		if v > 0.03:
			_annulus(img, rx * d1, ry * d1, rx * d0, ry * d0, c, c, c, _tile(img.get_size(), c, v))


## Polígono convexo (células, a contar do canto da imagem), linha a linha.
static func _poly(img: Image, pts: Array, c: Color, tile: Image = null) -> void:
	var y0 := INF
	var y1 := -INF
	for p in pts:
		y0 = minf(y0, p.y)
		y1 = maxf(y1, p.y)
	for j in range(maxi(0, floori(y0)), mini(img.get_height(), ceili(y1))):
		var y := j + 0.5
		var a := INF
		var b := -INF
		for i in pts.size():
			var p: Vector2 = pts[i]
			var q: Vector2 = pts[(i + 1) % pts.size()]
			if (p.y <= y) != (q.y <= y):
				var x := p.x + (y - p.y) / (q.y - p.y) * (q.x - p.x)
				a = minf(a, x)
				b = maxf(b, x)
		if a > b:
			continue
		var x0 := clampi(roundi(a), 0, img.get_width() - 1)
		var w := clampi(roundi(b) - x0, 1, img.get_width() - x0)
		if tile != null:
			img.blit_rect_mask(tile, tile, Rect2i(x0, j, w, 1), Vector2i(x0, j))
		else:
			img.fill_rect(Rect2i(x0, j, w, 1), c)


## Glifo de 3x5 células com o contorno à volta.
static func _rune(img: Image, x: int, y: int, i: int, c: Color) -> void:
	var r: Array = RUNES[i % RUNES.size()]
	for j in r.size():
		for k in r[j].length():
			if r[j][k] == "1":
				for o in [Vector2i.LEFT, Vector2i.RIGHT, Vector2i.UP, Vector2i.DOWN]:
					_put(img, x + k + o.x, y + j + o.y, OUTLINE)
	for j in r.size():
		for k in r[j].length():
			if r[j][k] == "1":
				_put(img, x + k, y + j, c)


## Gema de 3 células com contorno: as do anel de elite e os rebites.
static func _gem(img: Image, x: float, y: float, core: Color, side: Color) -> void:
	for o in [Vector2(0, -1), Vector2(0, 1), Vector2(-2, 0), Vector2(2, 0), Vector2(-1, -1), Vector2(1, -1), Vector2(-1, 1), Vector2(1, 1)]:
		_put(img, x + o.x, y + o.y, OUTLINE)
	_put(img, x - 1.0, y, side)
	_put(img, x + 1.0, y, side)
	_put(img, x, y, core)


## Os riscos de um anel fino (1 célula de largura), do topo e no sentido dos ponteiros: arc tira uma fatia. lv 4 é cheio;
## 5 é partido em 12; abaixo de 4, só as células que o Bayer deixa (desfaz-se em vez de ficar transparente). Sem textura.
static func _loop_pts(rx: int, ry: int, lv := 4) -> PackedVector2Array:
	var key := Vector3i(rx, ry, lv)
	var pts: PackedVector2Array = _loops.get(key, PackedVector2Array())
	if not pts.is_empty() or rx < 1 or ry < 1:
		return pts
	var t0 := Time.get_ticks_usec()
	var n := maxi(8, ceili(TAU * maxf(rx, ry) * 1.1))
	var last := Vector2i(1 << 20, 0)
	for i in n:
		var a := TAU * i / n - PI / 2.0
		var c := Vector2i(roundi(cos(a) * (rx - 0.5) - 0.5), roundi(sin(a) * (ry - 0.5) - 0.5))
		if c != last and (lv == 4 or (lv == 5 and fmod(i * 12.0 / n, 1.0) > 0.2) or (lv < 4 and bayer(c.x, c.y) < lv / 4.0)):
			pts.append(Vector2(c.x * S, c.y * S + 1.0))
			pts.append(Vector2(c.x * S + S, c.y * S + 1.0))
		last = c
	if _loops.size() >= LOOPS_MAX:
		_loops.erase(_loops.keys()[0])
	_loops[key] = pts
	var dt := Time.get_ticks_usec() - t0  # não é textura, mas custa a primeira vez: entra nas medidas
	bake_usec += dt
	bake_worst = maxi(bake_worst, dt)
	return pts


## Anel fino a crescer ou a pulsar (rx, ry em px do mundo): th células para dentro, contorno opcional, lv como em _loop_pts.
static func loop(ci: Node2D, at: Vector2, rx: float, ry: float, c: Color, th := 1, outline := false, lv := 4) -> void:
	var w := roundi(rx / S)
	var h := roundi(ry / S)
	if w < 1 or h < 1:
		return
	ci.draw_set_transform(snap(ci, at))
	if outline:
		ci.draw_multiline(_loop_pts(w + 1, maxi(1, h + 1)), OUTLINE, S)
		if w - th >= 1 and h - th >= 1:
			ci.draw_multiline(_loop_pts(w - th, h - th), OUTLINE, S)
	for o in th:
		var p := _loop_pts(maxi(1, w - o), maxi(1, h - o), lv)
		if p.size() >= 2:
			ci.draw_multiline(p, c, S)
	ci.draw_set_transform(Vector2.ZERO)


## Fatia do anel fino, de f0 a f1 da volta a contar do topo e no sentido dos ponteiros (f1 pode passar de 1).
static func arc(ci: Node2D, at: Vector2, rx: float, ry: float, f0: float, f1: float, c: Color, th := 1, lv := 4) -> void:
	if f1 <= f0:
		return
	var w := roundi(rx / S)
	var h := roundi(ry / S)
	ci.draw_set_transform(snap(ci, at))
	for o in th:
		var p := _loop_pts(maxi(1, w - o), maxi(1, h - o), lv)
		var n := p.size() / 2
		if n == 0:
			continue
		var a := int(fposmod(f0, 1.0) * n)
		var b := a + mini(n, ceili((f1 - f0) * n))
		if b > a:
			ci.draw_multiline(p.slice(a * 2, mini(b, n) * 2), c, S)
		if b > n:
			ci.draw_multiline(p.slice(0, (b - n) * 2), c, S)
	ci.draw_set_transform(Vector2.ZERO)


## Faíscas que sobem: peças soltas na grelha, só do tempo e do índice (iguais no convidado).
static func motes(ci: Node2D, at: Vector2, rx: float, h: float, n: int, time: float, C: Array) -> void:
	for i in n:
		var ph := fposmod(time * (0.3 + hashf(i, 1) * 0.35) + hashf(i, 2), 1.0)
		var q := snap(ci, at + Vector2((hashf(i, 3) * 2.0 - 1.0) * rx, -ph * h))
		ci.draw_rect(Rect2(q, Vector2(S, S)), _tone(C, 1 + i % 3))
		if i % 2 == 0:
			ci.draw_rect(Rect2(q + Vector2(0, S), Vector2(S, S)), _tone(C, 5))


## Pontilhado (sombras, poças, brilhos, poeira): cozido a branco por tamanho e densidade (8 degraus) e pintado com c ao
## desenhar, para servir a todas as cores. soft: mais denso no meio e nada na borda; senão igual até à borda.
static func haze(ci: Node2D, at: Vector2, rx: float, ry: float, c: Color, dens: float, soft := true) -> void:
	var lv := clampi(roundi(dens * 8.0), 0, 8)
	var w := maxi(1, roundi(rx / S))
	var h := maxi(1, roundi(ry / S))
	if lv == 0:
		return
	if w > 24:  # os grandes de 2 em 2 células: menos texturas (a poeira cresce de frame para frame)
		w = (w + 1) & ~1
		h = (h + 1) & ~1
	var key := ["haze", w, h, lv, soft]
	var tex := _hit(key)
	if tex == null:
		var t0 := Time.get_ticks_usec()
		var img := _img(w * 2, h * 2)
		var d := lv / 8.0
		_dither(img, w, h, Color.WHITE, (func(v): return d * (1.0 - v * v)) if soft else (func(_v): return d), mini(6, maxi(1, w / 4)) if soft else 1)
		tex = _store(key, img, t0)
	stamp(ci, tex, at, c)


## O mesmo pontilhado para o que muda a cada frame (fumo, poeira): raio aos degraus (r em px) e 3 densidades, sempre as
## mesmas poucas texturas em vez de umas novas a cada frame.
static func puff(ci: Node2D, at: Vector2, r: float, c: Color, dens: float) -> void:
	var cells := r / S
	var q := maxf(1.0, snappedf(cells, 2.0 if cells < 24.0 else 4.0)) * S
	haze(ci, at, q, q, c, snappedf(dens, 0.25))


## Bola com contorno e luz de cima: r em células (gotas, marcas, ossos e crânios em órbita).
static func orb(ci: Node2D, at: Vector2, r: int, rn: String) -> void:
	var key := ["orb", r, rn]
	var tex := _hit(key)
	if tex == null:
		var t0 := Time.get_ticks_usec()
		var C := ramp(rn)
		var img := _img(r * 2 + 2, r * 2 + 2)
		_annulus(img, r + 1.0, r + 1.0, 0.0, 0.0, OUTLINE, OUTLINE, OUTLINE)
		_annulus(img, r, r, 0.0, 0.0, _tone(C, 4), _tone(C, 3), _tone(C, 2))
		if r >= 2:
			_put(img, r - r * 0.4, r + 1.0 - r * 0.6, _tone(C, 0))
		tex = _store(key, img, t0)
	stamp(ci, tex, at)


## Peça pequena em células (pts em px à volta de at, um polígono convexo), com contorno e luz de cima; tone é a cor do meio.
## Cozida uma vez por forma: quem muda de tamanho ou de direção tem de mudar aos degraus.
static func solid(ci: Node2D, at: Vector2, pts: Array, rn: String, tone := 2, c := Color.WHITE) -> void:
	var box := Rect2(pts[0], Vector2.ZERO)
	for q in pts:
		box = box.expand(q)
	var key := ["solid", pts, rn, tone]
	var tex := _hit(key)
	if tex == null:
		var t0 := Time.get_ticks_usec()
		var C := ramp(rn)
		var w := ceili(box.size.x / S) + 4  # 2 células de folga: o contorno, e os vizinhos nunca saem da imagem
		var h := ceili(box.size.y / S) + 4
		var shape := _img(w, h)
		_poly(shape, pts.map(func(q): return (q - box.get_center()) / S + Vector2(w, h) / 2.0), Color.WHITE)
		var a := shape.get_data()
		var img := _img(w, h)
		for y in range(1, h - 1):
			for x in range(1, w - 1):
				var i := (y * w + x) * 4 + 3
				if a[i] > 0:
					img.set_pixel(x, y, _tone(C, tone - 1 if a[i - w * 4] == 0 else tone + 1 if a[i + w * 4] == 0 else tone))
				elif a[i - 4] > 0 or a[i + 4] > 0 or a[i - w * 4] > 0 or a[i + w * 4] > 0:
					img.set_pixel(x, y, OUTLINE)
		tex = _store(key, img, t0)
	stamp(ci, tex, at + box.get_center(), c)


## Anel de elite: dourado partido em quatro, com três gemas e brilho pontilhado por dentro.
static func elite(ci: Node2D, at: Vector2, rx: float, ry: float, c := Color.WHITE) -> void:
	var w := roundi(rx / S)
	var h := maxi(3, roundi(ry / S))
	var key := ["elite", w, h]
	var tex := _hit(key)
	if tex == null:
		var t0 := Time.get_ticks_usec()
		var C: Array = RAMPS.gold
		var img := _img((w + 4) * 2, (h + 4) * 2)
		_dither(img, w * 0.72, h * 0.72, Color.BLACK, func(v): return 0.55 * (1.0 - v * v), 4)
		_dither(img, w, h, C[3], func(v): return 0.28 * maxf(0.0, v - 0.45), 4)
		_ring(img, w, h, 1.6, C[2], C[3], C[4])
		_gaps(img, w, h, 1.6, [0.0, PI / 2.0, PI, -PI / 2.0], 0.26)
		for q in [0.0, PI, PI / 2.0]:
			_gem(img, w + 4 + (w - 1) * cos(q), h + 4 + (h - 1) * sin(q), C[0], C[1])
		tex = _store(key, img, t0)
	stamp(ci, tex, at, c)


## O selo do herói aos pés: um só desenho, com runas à frente e faíscas a subir nos efeitos médios e altos. A rampa do anel
## diz de quem é; na Ira (ira) o miolo, as runas e as faíscas enchem-se de sangue, e hot é o pulso.
static func sigil(ci: Node2D, at: Vector2, rn: String, hot: bool, time: float, lvl: int, ira := false) -> void:
	var key := ["sigil", rn, hot, ira]
	var tex := _hit(key)
	if tex == null:
		var t0 := Time.get_ticks_usec()
		var C := ramp(rn)
		var d := 1 if hot else 0
		var F: Array = RAMPS.bleed if ira else C  # a rampa de sangue tem 6 cores: 3 tons acima, para não ficar negra
		var up := 3 if ira else 0
		var img := _img(48, 24)
		_dither(img, 21.0, 9.0, _tone(F, 6 - d - up), func(v): return 0.35 * (1.0 - v) + 0.2 * v + 0.12 * d + (0.25 if ira else 0.0))
		_dither(img, 21.0, 9.0, _tone(F, 4 - d - up), func(v): return 0.5 * maxf(0.0, v - 0.6))
		_ring(img, 21.6, 9.6, 1.2, _tone(C, 3 - d), _tone(C, 4 - d), _tone(C, 5 - d))
		_gaps(img, 21.6, 9.6, 1.2, range(6).map(func(i): return i * PI / 3.0 + 0.5), 0.13)
		for i in 3:
			var a := PI * 0.25 + i * PI * 0.25
			_rune(img, roundi(24.0 + 15.5 * cos(a) - 1.5), roundi(12.0 + 6.0 * sin(a) - 2.5), i, _tone(F, 1 - d if ira else 2 - d))
		tex = _store(key, img, t0)
	stamp(ci, tex, at)
	if lvl > 0:
		motes(ci, at, 34.0, 56.0, 5 if lvl > 1 else 3, time, RAMPS.bleed if ira else ramp(rn))


## Anel simples (couraças, argolas): th células, buracos a intervalos iguais, tone na cor de cima da rampa.
static func band(ci: Node2D, at: Vector2, rx: float, ry: float, rn: String, th: float, gaps := 0, tone := 2) -> void:
	var w := roundi(rx / S)
	var h := roundi(ry / S)
	var key := ["band", w, h, rn, th, gaps, tone]
	var tex := _hit(key)
	if tex == null:
		var t0 := Time.get_ticks_usec()
		var C := ramp(rn)
		var img := _img((w + 2) * 2, (h + 2) * 2)
		_ring(img, w, h, th, _tone(C, tone + 2), _tone(C, tone + 1), _tone(C, tone))
		if gaps > 0:
			_gaps(img, w, h, th, range(gaps).map(func(i): return i * TAU / gaps), 0.1)
		tex = _store(key, img, t0)
	stamp(ci, tex, at)


## Aviso de ataque: a borda com dentes virados para dentro acaba no raio que acerta e o pontilhado enche do meio até lá,
## com uma frente a avançar. k de 0 a 1. Nos últimos 15% a borda fica em brasa: é agora.
static func warn(ci: Node2D, at: Vector2, r: float, k: float, rn := "life") -> void:
	var rc := roundi(r / S)
	k = clampf(k, 0.0, 1.0)
	var hot := k > 0.85
	var C := ramp(rn)
	if k * WARN_STEPS >= 1.0:  # aos degraus, sempre atrás da frente
		stamp(ci, _warn_fill(rc, floori(k * WARN_STEPS), rn), at)
	stamp(ci, _warn_ring(rc, rn, hot), at)
	if k * rc >= 3.0 and k < 1.0:
		loop(ci, at, r * k, r * k, _tone(C, 2 if hot else 3))


static func _warn_ring(rc: int, rn: String, hot: bool) -> CanvasTexture:
	var key := ["warn", rc, rn, hot]
	var tex := _hit(key)
	if tex != null:
		return tex
	var t0 := Time.get_ticks_usec()
	var C := ramp(rn)
	var d := 2 if hot else 0
	var img := _img((rc + 2) * 2, (rc + 2) * 2)
	var mid := rc + 2.0
	_dither(img, rc - 1.0, rc - 1.0, _tone(C, 5), func(_v): return 0.1, 1)
	var depth := clampf(rc * 0.1, 2.5, 6.0)
	var n := 12 if rc >= 24 else 8
	for i in n:
		var u := Vector2.from_angle(i * TAU / n)
		var o := u.orthogonal() * depth
		var b := Vector2(mid, mid) + u * (rc - 1.5)
		_poly(img, [b - o - u, b + o - u, b - u * (depth + 1.0)], _tone(C, 4 - d))
		_poly(img, [b - o, b + o, b + o * 0.6 - u * 1.2, b - o * 0.6 - u * 1.2], _tone(C, 3 - d))
	_ring(img, rc, rc, 2.0, _tone(C, 4 - d), _tone(C, 3 - d), _tone(C, 3 - d))
	return _store(key, img, t0)


static func _warn_fill(rc: int, step: int, rn: String) -> CanvasTexture:
	var key := ["fill", rc, step, rn]
	var tex := _hit(key)
	if tex != null:
		return tex
	var t0 := Time.get_ticks_usec()
	var C := ramp(rn)
	var p := float(step) / WARN_STEPS
	var rf := maxf(2.0, rc * p)
	var img := _img(ceili(rf) * 2 + 2, ceili(rf) * 2 + 2)
	_dither(img, rf, rf, _tone(C, 6), func(v): return 0.62 * (0.55 + 0.45 * v * p), 3)
	_dither(img, rf, rf, _tone(C, 5), func(v): return 0.4 if v > 0.8 else 0.0, 6)
	return _store(key, img, t0)


## Laje de pedra (abrigos): borda de osso, anel violeta com traços e o chão a ver-se pelo pontilhado. As runas são peças à
## volta do anel, a rodar devagar. A borda acaba em r, o raio que abriga.
static func slab(ci: Node2D, at: Vector2, r: float, time: float) -> void:
	stamp(ci, _slab_tex(roundi(r / S)), at)
	for i in 8:
		stamp(ci, _rune_tex(i, "necro"), at + Vector2.from_angle(TAU * i / 8.0 + time * 0.3) * r * 0.9)


static func _slab_tex(rc: int) -> CanvasTexture:
	var key := ["slab", rc]
	var tex := _hit(key)
	if tex == null:
		var t0 := Time.get_ticks_usec()
		var B: Array = RAMPS.bone
		var N: Array = RAMPS.necro
		var img := _img((rc + 2) * 2, (rc + 2) * 2)
		_dither(img, rc, rc, B[6], func(v): return 0.5 * (0.35 + 0.65 * v), 4)
		_dither(img, rc * 0.66, rc * 0.66, N[6], func(v): return 0.45 * (1.0 - v), 4)
		_ring(img, rc, rc, 2.2, B[5], B[4], B[3])
		_ring(img, rc * 0.8, rc * 0.8, 1.2, N[4], N[3], N[3])
		var mid := rc + 2.0
		for i in 16:
			var u := Vector2.from_angle(i * TAU / 16.0)
			for o in 3:
				_put(img, mid + u.x * (rc * 0.78 - o), mid + u.y * (rc * 0.78 - o), N[3] if o < 2 else N[4])
		tex = _store(key, img, t0)
	return tex


static func _rune_tex(i: int, rn: String) -> CanvasTexture:
	var key := ["rune", i % RUNES.size(), rn]
	var tex := _hit(key)
	if tex == null:
		var t0 := Time.get_ticks_usec()
		var img := _img(5, 7)
		_rune(img, 1, 1, i, _tone(ramp(rn), 2))
		tex = _store(key, img, t0)
	return tex


## A bigorna da Forja: disco de ferro escuro com rebites; a borda acaba em r, a área do martelo.
static func anvil(ci: Node2D, at: Vector2, r: float) -> void:
	var rc := roundi(r / S)
	var key := ["anvil", rc]
	var tex := _hit(key)
	if tex == null:
		var t0 := Time.get_ticks_usec()
		var I: Array = RAMPS.iron
		var img := _img((rc + 2) * 2, (rc + 2) * 2)
		_dither(img, rc, rc, I[7], func(_v): return 0.75, 1)
		_dither(img, rc * 0.7, rc * 0.7, I[6], func(v): return 0.45 * (1.0 - v), 3)
		_ring(img, rc, rc, 2.0, I[5], I[4], I[3])
		var mid := rc + 2.0
		for i in 8:
			var u := Vector2.from_angle(i * TAU / 8.0 + 0.39)
			_gem(img, mid + u.x * (rc - 5.0), mid + u.y * (rc - 5.0), I[1], I[3])
		tex = _store(key, img, t0)
	stamp(ci, tex, at)


## A Fenda: elipse violeta rachada com o fundo negro; o raio anda aos degraus de 3 células (abre e pulsa).
static func fenda(ci: Node2D, at: Vector2, r: float, time: float, lvl: int) -> void:
	var w := maxi(3, roundi(r / S / 3.0) * 3)
	var h := maxi(2, roundi(w * 0.45))
	var key := ["fenda", w]
	var tex := _hit(key)
	if tex == null:
		var t0 := Time.get_ticks_usec()
		var N: Array = RAMPS.necro
		var img := _img((w + 2) * 2, (h + 2) * 2)
		_dither(img, w, h, N[5], func(v): return 0.25 + 0.55 * v, 4)
		_dither(img, w * 0.6, h * 0.6, N[7], func(v): return 1.0 - 0.3 * v, 3)
		_ring(img, w, h, 2.0, N[2], N[3], N[4])
		_gaps(img, w, h, 2.0, [0.4, 1.9, 2.9, 4.1, 5.5], 0.05)
		tex = _store(key, img, t0)
	stamp(ci, tex, at)
	if lvl > 0:
		motes(ci, at, r * 0.7, 80.0, 6 if lvl > 1 else 3, time, RAMPS.necro)


## A cratera do Meteoro: fuligem pontilhada, borda de pedra em pedaços; as brasas do fundo pulsam por cima (haze).
static func crater(ci: Node2D, at: Vector2, r: float) -> void:
	var rc := roundi(r / S)
	var key := ["crater", rc]
	var tex := _hit(key)
	if tex == null:
		var t0 := Time.get_ticks_usec()
		var A: Array = RAMPS.ash
		var img := _img((rc + 5) * 2, (rc + 5) * 2)
		var mid := rc + 5.0
		_dither(img, rc, rc, SOOT, func(v): return 0.8 - 0.3 * v, 3)
		_ring(img, rc, rc, 3.0, A[4], A[3], A[2])
		for i in 26:
			var a := i * TAU / 26.0 + hashf(i, 1) * 0.15
			var q := Vector2(mid, mid) + Vector2.from_angle(a) * (rc - 1.0)
			var s := 2.0 + hashf(i, 2) * 2.5
			var rock := [q + Vector2(-s, 0), q + Vector2(0, -s * 0.7), q + Vector2(s, 0), q + Vector2(0, s * 0.7)]
			_poly(img, [q + Vector2(-s - 1.0, 0), q + Vector2(0, -s * 0.7 - 1.0), q + Vector2(s + 1.0, 0), q + Vector2(0, s * 0.7 + 1.0)], OUTLINE)
			_poly(img, rock, A[1] if i % 3 == 0 else A[3])
		tex = _store(key, img, t0)
	stamp(ci, tex, at)


## Chama aos 4 degraus de altura, com a base em baixo; sc para as pequenas (o círculo de reanimar).
static func flame_tex(rn: String, f: int, sc := 1.0) -> CanvasTexture:
	var key := ["flame", rn, f, sc]
	var tex := _hit(key)
	if tex == null:
		var t0 := Time.get_ticks_usec()
		var C := ramp(rn)
		var h := roundi(FLAME_H[f] * sc)
		var img := _img(13, h + 2)
		for j in h + 1:
			var k := float(j) / h  # 0 na ponta, 1 na base
			var hw := 4.6 * sc * pow(k, 0.7)
			var x := 6.5 + sin(k * 5.0 + f * 1.7) * (1.0 - k) * 1.8
			img.fill_rect(Rect2i(roundi(x - hw - 1.0), j, roundi(hw * 2.0 + 2.0), 1), OUTLINE)
			if k > 0.08:
				img.fill_rect(Rect2i(roundi(x - hw), j, maxi(1, roundi(hw * 2.0)), 1), _tone(C, 4 if k > 0.55 else 3))
			if k > 0.3:
				img.fill_rect(Rect2i(roundi(x - hw * 0.45), j, maxi(1, roundi(hw * 0.9)), 1), _tone(C, 2 if k > 0.6 else 1))
		tex = _store(key, img, t0)
	return tex


## O muro de almas: pedras a cada 16 px e uma chama em cada duas, à volta do círculo; com efeitos baixos, metade das pedras
## e das chamas. Nunca uma textura gigante: só as peças que se veem (ci na origem do mundo).
static func wall(ci: Node2D, center: Vector2, r: float, view: Rect2, time: float, lvl: int) -> void:
	var box := view.grow(70.0)
	var by := [[], [], [], []]  # uma chamada por textura: as peças de cada uma juntas
	var step := 2 if lvl > 0 else 4
	var stone := _wall_stone()
	var pts := _wall_pts(roundi(r))
	for i in pts.size():
		var q := pts[i] + center
		if box.has_point(q):
			if lvl > 0 or i % 2 == 0:
				stamp(ci, stone, q)
			if i % step == 0:
				by[(i * 7 + int(time * 10.0)) % 4].append(q)
	for f in 4:
		var tex := flame_tex("soul", f)
		for q in by[f]:
			stand(ci, tex, q - Vector2(0, 2))


static func _wall_pts(r: int) -> PackedVector2Array:
	if not _walls.has(r):
		var pts := PackedVector2Array()
		var n := roundi(TAU * r / 16.0)
		for i in n:
			pts.append(Vector2.from_angle(TAU * i / n) * r)
		_walls[r] = pts
	return _walls[r]


static func _wall_stone() -> CanvasTexture:
	var key := ["stone"]
	var tex := _hit(key)
	if tex == null:
		var t0 := Time.get_ticks_usec()
		var A: Array = RAMPS.ash
		var img := _img(12, 8)
		img.fill_rect(Rect2i(1, 0, 10, 8), OUTLINE)
		img.fill_rect(Rect2i(0, 1, 12, 6), OUTLINE)
		img.fill_rect(Rect2i(1, 1, 10, 3), A[3])
		img.fill_rect(Rect2i(1, 4, 10, 3), A[4])
		img.fill_rect(Rect2i(2, 1, 6, 1), A[2])
		tex = _store(key, img, t0)
	return tex


## Disco enorme em pontilhado (a Maré no chão da arena): uma linha por cada 8 px à vista (a borda vai aos degraus), com um
## ladrilho que se repete e bate certo com a grelha do mundo. ci na origem do mundo.
static func flood(ci: Node2D, center: Vector2, r: float, view: Rect2, c: Color, dens: float) -> void:
	var lv := clampi(roundi(dens * 8.0), 0, 8)
	if lv == 0:
		return
	var key := ["flood", lv]
	var tex := _hit(key)
	if tex == null:
		var t0 := Time.get_ticks_usec()
		tex = _store(key, _tile(Vector2i(4, 4), Color.WHITE, lv / 8.0), t0)
		tex.texture_repeat = CanvasItem.TEXTURE_REPEAT_ENABLED
	var y1 := minf(view.end.y, center.y + r)
	var j := floori(maxf(view.position.y, center.y - r) / S / 4.0) * 4
	while j * S < y1:
		var dy := (j + 2.0) * S - center.y
		if absf(dy) < r:
			var hw := sqrt(r * r - dy * dy)
			var x0 := floorf(maxf(view.position.x, center.x - hw) / S)
			var x1 := ceilf(minf(view.end.x, center.x + hw) / S)
			if x1 > x0:
				ci.draw_texture_rect_region(tex, Rect2(x0 * S, j * S, (x1 - x0) * S, S * 4.0), Rect2(x0, j, x1 - x0, 4.0), c, false, false)
		j += 4


## A passadeira do Moinho: duas calhas de ferro, travessas e o fundo pontilhado, ao comprido de d; as setas de sangue seco
## são peças a andar. hw e l em px: a área que empurra.
static func belt(ci: Node2D, at: Vector2, d: Vector2, l: float, hw: float, time: float) -> void:
	var axis := d if d.x > 0.0 or (d.x == 0.0 and d.y > 0.0) else -d  # as calhas são iguais nos dois sentidos
	var key := ["belt", axis, l, hw]
	var tex := _hit(key)
	if tex == null:
		var t0 := Time.get_ticks_usec()
		var I: Array = RAMPS.iron
		var size := Vector2i(ceili((absf(axis.x) * l + absf(axis.y) * hw) / S) * 2 + 4, ceili((absf(axis.y) * l + absf(axis.x) * hw) / S) * 2 + 4)
		var img := _img(size.x, size.y)
		var n := axis.orthogonal()
		var mid := Vector2(size) / 2.0
		var box := func(t0_: float, t1: float, w0: float, w1: float) -> Array:
			var a := mid + (axis * t0_ + n * w0) / S
			var b := mid + (axis * t1 + n * w0) / S
			var e := mid + (axis * t1 + n * w1) / S
			var f := mid + (axis * t0_ + n * w1) / S
			return [a, b, e, f]
		_poly(img, box.call(-l, l, -hw, hw), Color.WHITE, _tile(size, Color(0.09, 0.06, 0.06), 0.5))
		var t := -l + 10.0
		while t < l:
			_poly(img, box.call(t, t + 4.0, -hw + 6.0, hw - 6.0), I[6])
			t += 18.0
		for s in [-1.0, 1.0]:
			_poly(img, box.call(-l, l, s * (hw - 7.0), s * (hw + 1.0)), OUTLINE)
			_poly(img, box.call(-l, l, s * (hw - 5.0), s * (hw - 1.0)), I[5] if s < 0.0 else I[4])
		tex = _store(key, img, t0)
	stamp(ci, tex, at)
	var chev := _chevron(d, hw)
	for i in 5:
		stamp(ci, chev, at + d * (fmod(time * 120.0 + i * 52.0, l * 2.0) - l))


static func _chevron(d: Vector2, hw: float) -> CanvasTexture:
	var key := ["chevron", d, hw]
	var tex := _hit(key)
	if tex == null:
		var t0 := Time.get_ticks_usec()
		var L: Array = RAMPS.life
		var img := _img(36, 36)
		var mid := Vector2(18, 18)
		var n := d.orthogonal() * hw * 0.7 / S
		var u := d * 5.0
		for s in [-1.0, 1.0]:
			_poly(img, [mid + u * 1.3, mid - u * 0.7 + n * s, mid - u * 1.5 + n * s, mid + u * 0.5], OUTLINE)
			_poly(img, [mid + u, mid - u + n * s * 0.9, mid - u * 1.25 + n * s * 0.9, mid + u * 0.75], L[5])
			_poly(img, [mid + u, mid - u + n * s * 0.9, mid - u * 1.05 + n * s * 0.9, mid + u * 0.95], L[4])
		tex = _store(key, img, t0)
	return tex


## A serra: lâmina com rebordo, sulcos, centro aparafusado e sangue nos dentes, em frames (12 dentes a rodar). A ponta dos
## dentes chega a SAW_R, o raio que corta.
static func saw(ci: Node2D, at: Vector2, time: float) -> void:
	haze(ci, at + Vector2(0, 8), SAW_R, SAW_R * 0.5, Color.BLACK, 0.5)  # a sombra por baixo
	stamp(ci, _saw_tex(int(time * 24.0) % SAW_FRAMES), at)


static func _saw_tex(f: int) -> CanvasTexture:
	var key := ["saw", f]
	var tex := _hit(key)
	if tex == null:
		var t0 := Time.get_ticks_usec()
		var I: Array = RAMPS.iron
		var L: Array = RAMPS.life
		var tip := SAW_R / S
		var body := tip - 4.5
		var img := _img(ceili(tip) * 2 + 4, ceili(tip) * 2 + 4)
		var mid := Vector2(img.get_size()) / 2.0
		var rot := f * TAU / 3.0 / SAW_FRAMES
		_annulus(img, body + 1.0, body + 1.0, 0.0, 0.0, OUTLINE, OUTLINE, OUTLINE)
		for i in 12:
			var a := rot + i * TAU / 12.0
			_poly(img, [mid + Vector2.from_angle(a - 0.05) * body, mid + Vector2.from_angle(a) * (tip + 1.2), mid + Vector2.from_angle(a + TAU / 12.0 + 0.05) * body], OUTLINE)
		for i in 12:
			var a := rot + i * TAU / 12.0
			var bloody := i % 4 == 1
			_poly(img, [mid + Vector2.from_angle(a) * (body - 0.5), mid + Vector2.from_angle(a) * tip, mid + Vector2.from_angle(a + TAU / 12.0) * (body - 0.5)], I[1] if i % 2 == 0 else I[2])
			if bloody:
				_poly(img, [mid + Vector2.from_angle(a) * (body - 0.5), mid + Vector2.from_angle(a) * (body + 2.5), mid + Vector2.from_angle(a + TAU / 12.0) * (body - 0.5)], L[4])
		_annulus(img, body, body, 0.0, 0.0, I[5], I[4], I[3])
		_annulus(img, body, body, body - 2.0, body - 2.0, I[3], I[2], I[1])
		for i in 6:  # os sulcos, a rodar com a lâmina
			var u := Vector2.from_angle(rot + i * TAU / 6.0 + 0.26)
			for j in range(7, roundi(body) - 2):
				_put(img, mid.x + u.x * j, mid.y + u.y * j, I[6])
				_put(img, mid.x + u.x * j + 1.0, mid.y + u.y * j, I[3])
		for i in 3:  # o rasto a girar
			var a0 := i * TAU / 3.0 + rot
			for j in 18:
				var q := mid + Vector2.from_angle(a0 + j * 0.05) * (body * 0.62)
				_put(img, q.x, q.y, I[2] if j > 9 else I[4])
		for i in 4:  # sangue no rebordo, a rodar com os dentes
			var q := mid + Vector2.from_angle(rot + i * TAU / 4.0 + 0.5) * (body - 1.0)
			_put(img, q.x, q.y, L[5])
			_put(img, q.x + 1.0, q.y, L[4])
		_annulus(img, 6.0, 6.0, 0.0, 0.0, OUTLINE, OUTLINE, OUTLINE)
		_annulus(img, 5.0, 5.0, 0.0, 0.0, I[5], I[4], I[2])
		_annulus(img, 2.2, 2.2, 0.0, 0.0, I[7], I[7], I[6])
		tex = _store(key, img, t0)
	return tex


## O feixe do saque: fino, às faíscas, em pontilhado que sobe (3 frames). h em células, base em at.
static func beam(ci: Node2D, at: Vector2, rn: String, h: int, f: int, c := Color.WHITE) -> void:
	var key := ["beam", rn, h, f]
	var tex := _hit(key)
	if tex == null:
		var t0 := Time.get_ticks_usec()
		var C := ramp(rn)
		var img := _img(13, h)
		for t in h:
			var k := float(t) / h
			var half := 3.2 * pow(1.0 - k, 0.7) + 0.4
			for w in range(-5, 6):
				var edge := absf(w) / (half + 0.01)
				var b := bayer(w + 6, h - t + f * 2)
				if w == 0 and k < 0.92:
					if b < 1.0 - k * 0.6:
						img.set_pixel(6, h - 1 - t, _tone(C, 1 if k < 0.5 else 2))
				elif edge < 1.0 and b < (1.0 - edge) * (1.0 - k) * 1.9:
					img.set_pixel(w + 6, h - 1 - t, _tone(C, 3 if edge < 0.55 else 4))
		tex = _store(key, img, t0)
	stand(ci, tex, at, c)


## A marca no chão por baixo do saque com feixe: brilho pontilhado e anelzinho partido. w em células.
static func mark(ci: Node2D, at: Vector2, rn: String, w := 12) -> void:
	var key := ["mark", rn, w]
	var tex := _hit(key)
	if tex == null:
		var t0 := Time.get_ticks_usec()
		var C := ramp(rn)
		var h := roundi(w * 0.42)
		var img := _img((w + 1) * 2, (h + 1) * 2)
		_dither(img, w, h, _tone(C, 4), func(v): return 0.55 * (1.0 - v), 3)
		_ring(img, w * 0.88, h * 0.88, 1.0, _tone(C, 3), _tone(C, 3), _tone(C, 4), false)
		_gaps(img, w * 0.88, h * 0.88, 1.0, range(6).map(func(i): return i * TAU / 6.0 + 0.3), 0.15)
		tex = _store(key, img, t0)
	stamp(ci, tex, at)


## Texturas guardadas e bytes (medidas e smoke).
static func cache_size() -> Vector2i:
	return Vector2i(_tex.size(), bake_bytes)
