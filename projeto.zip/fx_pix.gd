extends RefCounted
## Peças comuns dos efeitos em píxeis (fx.gd, loot.gd): a grelha de 2 px, o pontilhado de Bayer, as rampas de cores do jogo,
## o brilho aditivo (um só quadro com textura), discos e glifos já cozidos (nada de ciclos por píxel a cada frame).
## Efeitos adaptados de Sprite Fusion Pixel Art VFX (MIT, (c) 2026 Hugo Duprez)

const S := 2.0  # 1 píxel do efeito = 2 px do mundo
const BAYER := [0, 8, 2, 10, 12, 4, 14, 6, 3, 11, 1, 9, 15, 7, 13, 5]
# Rampas do claro para o escuro, tiradas das cores do jogo; viajam ao convidado pelo nome
const RAMPS := {
	"bone": [Color("ffffff"), Color("f4eedc"), Color("e6dbbf"), Color("cbbe9c"), Color("a39677"), Color("6e6450"), Color("3e3830"), Color("1e1b18")],
	"iron": [Color("ffffff"), Color("e3eaf5"), Color("b8c7e6"), Color("8c9dbf"), Color("66789c"), Color("485670"), Color("2e3747"), Color("171c24")],
	"soul": [Color("ffffff"), Color("dfffea"), Color("9cffc4"), Color("59ff99"), Color("2fd27a"), Color("1f9a5e"), Color("155e40"), Color("0b2e22")],
	"rot": [Color("efffc8"), Color("c6f27a"), Color("9be04f"), Color("73c93e"), Color("4e9a32"), Color("35692a"), Color("22401f"), Color("131f12")],
	"necro": [Color("ffffff"), Color("ebd9ff"), Color("c9a3f5"), Color("9e5cd9"), Color("7638b0"), Color("4e2378"), Color("2c1347"), Color("140a22")],
	"bleed": [Color("f07a7a"), Color("c8202f"), Color("9a1526"), Color("6e0e1c"), Color("440813"), Color("24040a")],
	"ash": [Color("d8d4cc"), Color("b3aea3"), Color("8a857c"), Color("6b665c"), Color("4a4640"), Color("2e2b28")],
	"gold": [Color("ffffff"), Color("fff0b8"), Color("ffd966"), Color("ffbf4d"), Color("d98a2b"), Color("8c4a1a")],
	"life": [Color("ffffff"), Color("ffe0dc"), Color("ffa59c"), Color("ff5a5a"), Color("d92b3a"), Color("a01a2c"), Color("64101f"), Color("360812")],
	"soulblue": [Color("ffffff"), Color("ddf0ff"), Color("a6d6ff"), Color("59b3ff"), Color("3580d9"), Color("2552a0"), Color("18316a"), Color("0d1a3d")],
	# O saque a voar para o herói: osso dourado, tinta vermelha, cinzas cor de brasa
	"loot_bone": [Color("ffffff"), Color("fff4d6"), Color("f2d98c"), Color("c9a85c"), Color("7a6236"), Color("2e2414")],
	"loot_ink": [Color("ffe0e0"), Color("ff8a8a"), Color("d91f2e"), Color("8c1220"), Color("4a0912"), Color("1a0306")],
	"loot_ash": [Color("fff6e0"), Color("ffd08a"), Color("ff9933"), Color("c2621f"), Color("6e3412"), Color("2a1408")],
}
# Gotas da poção de alma (5x8 e 3x5): 1-4 = tom da rampa, w = branco
const DROP := [["..1..", "..2..", ".122.", ".1223", "1w223", "12223", "22234", ".334."], [".1.", ".2.", "1w3", "223", ".3."]]
const OUTLINE := Color("1a1422")
const SOOT := Color("0d0a12")

static var _glow: GradientTexture2D
static var _discs := {}
static var _glyphs := {}
static var _rows := {}
static var _sparkles := {}


static func ramp(name: String) -> Array:
	return RAMPS.get(name, RAMPS.bone)


## Limiar do pontilhado 4x4 na célula (x, y) da grelha do mundo (vizinhos partilham o padrão).
static func bayer(x: int, y: int) -> float:
	return (BAYER[((y & 3) << 2) | (x & 3)] + 0.5) / 16.0


## O canto da célula de 2 px onde cai o ponto p (coordenadas locais de um nó já alinhado à grelha).
static func cell(p: Vector2) -> Vector2:
	return (p / S).floor() * S


static func px(ci: CanvasItem, p: Vector2, c: Color, w := 1, h := 1) -> void:
	ci.draw_rect(Rect2(cell(p), Vector2(w, h) * S), c)


## Risco de 2 px entre a e b (alinhado ao meio das células).
static func line(ci: CanvasItem, a: Vector2, b: Vector2, c: Color) -> void:
	ci.draw_line(cell(a) + Vector2.ONE, cell(b) + Vector2.ONE, c, S)


## Ruído estável por (n, k), de 0 a 1: o mesmo nos dois lados do co-op sem guardar nada.
static func hashf(n: int, k := 0) -> float:
	return (((n + 1 + k * 7919) * 2654435761) & 0xFFFFFFFF) % 100000 / 100000.0


## Brilho (1-d)² num quadro aditivo: o nó ci tem de ter o material de soma.
static func glow(ci: CanvasItem, at: Vector2, r: float, c: Color, k: float) -> void:
	if r >= 1.0:
		glow_box(ci, Rect2(at - Vector2(r, r), Vector2(r, r) * 2.0), c, k)


## O mesmo brilho esticado num retângulo (uma coluna de luz, uma linha no chão): um quadro em vez de vários.
static func glow_box(ci: CanvasItem, box: Rect2, c: Color, k: float) -> void:
	if k > 0.01:
		ci.draw_texture_rect(glow_tex(), box, false, Color(c, k))


## A textura do brilho (fx.gd desenha-a direto nas partículas: duas chamadas a menos por cada uma).
static func glow_tex() -> GradientTexture2D:
	if _glow == null:
		var g := Gradient.new()
		g.offsets = PackedFloat32Array([0.0, 0.25, 0.5, 0.75, 1.0])
		g.colors = PackedColorArray([Color.WHITE, Color(1, 1, 1, 0.5625), Color(1, 1, 1, 0.25), Color(1, 1, 1, 0.0625), Color(1, 1, 1, 0)])
		_glow = GradientTexture2D.new()
		_glow.gradient = g
		_glow.fill = GradientTexture2D.FILL_RADIAL
		_glow.fill_from = Vector2(0.5, 0.5)
		_glow.fill_to = Vector2(1.0, 0.5)
		_glow.width = 32  # pequena e sem suavizar: o brilho fica aos degraus, como os píxeis
		_glow.height = 32
	return _glow


## Disco cheio de raio r células (cozido uma vez por raio, desenhado com a cor e o alfa de c).
static func disc(ci: CanvasItem, at: Vector2, r: float, c: Color) -> void:
	var n := clampi(roundi(r), 1, 24)
	if not _discs.has(n):
		var img := Image.create(n * 2, n * 2, false, Image.FORMAT_RGBA8)
		for y in n * 2:
			for x in n * 2:
				if (x + 0.5 - n) ** 2 + (y + 0.5 - n) ** 2 <= n * n:
					img.set_pixel(x, y, Color.WHITE)
		_discs[n] = ImageTexture.create_from_image(img)
	ci.draw_texture_rect(_discs[n], Rect2(cell(at) - Vector2(n, n) * S, Vector2(n, n) * S * 2.0), false, c)


## Elipse cheia aos riscos de 2 px (um por linha): rx, ry em px do mundo. Os riscos de cada tamanho (ao px) guardam-se
## e vão todos numa só chamada (a elipse grande do pilar tinha 53 quadros por frame).
static func ellipse(ci: CanvasItem, at: Vector2, rx: float, ry: float, c: Color) -> void:
	var key := Vector2i(roundi(rx), roundi(ry))
	if key.y < 1:
		return
	if not _rows.has(key):
		var pts := PackedVector2Array()
		var rows := floori(key.y / S)
		for j in range(-rows, rows + 1):
			var hw := ceilf(key.x / S * sqrt(maxf(0.0, 1.0 - pow((j + 0.5) * S / key.y, 2.0)))) * S
			if hw > 0.0:
				pts.append_array([Vector2(-hw, j * S + 1.0), Vector2(hw, j * S + 1.0)])
		_rows[key] = pts
	if not _rows[key].is_empty():
		ci.draw_set_transform(cell(at))
		ci.draw_multiline(_rows[key], c, S)
		ci.draw_set_transform(Vector2.ZERO)


## Cruz de brilho de n células: braços na cor c (a ponta em tip), diagonais a partir de 3, o meio branco. Cozida uma vez
## por tamanho e cores: um quadro por estrela em vez de 5 a 17 (o pilar e as poções largam dezenas).
static func sparkle(ci: CanvasItem, at: Vector2, n: int, c: Color, tip: Color) -> void:
	if n < 1:
		return
	var key := [n, c, tip]
	if not _sparkles.has(key):
		var img := Image.create(n * 2 + 1, n * 2 + 1, false, Image.FORMAT_RGBA8)
		var m := maxi(1, ceili(n * 0.6))
		for i in range(1, n + 1):
			for d in [Vector2i.RIGHT, Vector2i.LEFT, Vector2i.DOWN, Vector2i.UP]:
				img.set_pixelv(Vector2i(n, n) + d * i, c if i <= m else tip)
		if n >= 3:
			for d in [Vector2i(1, 1), Vector2i(1, -1), Vector2i(-1, 1), Vector2i(-1, -1)]:
				img.set_pixelv(Vector2i(n, n) + d, c)
				if n >= 6:
					img.set_pixelv(Vector2i(n, n) + d * 2, tip)
		img.set_pixel(n, n, Color.WHITE)
		_sparkles[key] = ImageTexture.create_from_image(img)
	ci.draw_texture_rect(_sparkles[key], Rect2(cell(at) - Vector2(n, n) * S, Vector2(n * 2 + 1, n * 2 + 1) * S), false)


## Estrela de 8 raios (brilho do saque raro): 4 longos de L células em três cores e 4 diagonais curtas, a rodar ang.
static func flare(ci: CanvasItem, at: Vector2, L: float, ang: float, c1: Color, c2: Color, a := 1.0) -> void:
	if L < 0.8 or a <= 0.01:
		return
	var o := cell(at) + Vector2.ONE
	for i in 8:
		var d := Vector2.from_angle(ang + i * TAU / 8.0) * S
		if i % 2 == 1:
			ci.draw_line(o, o + d * L * 0.21, Color(c1, a), S)
			ci.draw_line(o + d * L * 0.21, o + d * L * 0.42, Color(c2, a), S)
			continue
		if L > 4.0:  # a base dos raios longos é mais grossa
			ci.draw_line(o, o + d * L * 0.22, Color(c1, a), S * 3.0)
		ci.draw_line(o, o + d * L * 0.3, Color(Color.WHITE, a), S)
		ci.draw_line(o + d * L * 0.3, o + d * L * 0.65, Color(c1, a), S)
		ci.draw_line(o + d * L * 0.65, o + d * L, Color(c2, a * 0.6), S)
	ci.draw_rect(Rect2(o - Vector2.ONE, Vector2(S, S)), Color(Color.WHITE, a))


## Cruz da cura (braço L, meia largura w, contorno e relevo) ou gota da alma (shape 0 grande, 1 pequena), cozida uma vez.
static func glyph(r: Array, cross: bool, L: int, w: int, glint: bool) -> ImageTexture:
	var key := [r[3], cross, L, w, glint]
	if _glyphs.has(key):
		return _glyphs[key]
	var rows: Array = [] if cross else DROP[L]
	var n: int = L * 2 + 3 if cross else rows[0].length() + 2
	var m: int = n if cross else rows.size() + 2
	var inside := func(x: int, y: int) -> bool:  # na grelha do vidrado (sem a moldura de 1 px do contorno)
		if cross:
			var dx := x - L - 1
			var dy := y - L - 1
			return (absi(dx) <= w and absi(dy) <= L) or (absi(dy) <= w and absi(dx) <= L)
		return y >= 1 and y <= rows.size() and x >= 1 and x <= rows[0].length() and rows[y - 1][x - 1] != "."
	var img := Image.create(n, m, false, Image.FORMAT_RGBA8)
	for y in m:
		for x in n:
			var c := Color.TRANSPARENT
			if inside.call(x, y):
				if cross:
					var top: bool = not inside.call(x, y - 1) or not inside.call(x - 1, y)
					var low: bool = not inside.call(x, y + 1) or not inside.call(x + 1, y)
					c = (r[2] if y < L + 1 or x < L + 1 else r[4]) if w == 0 else r[2] if top else r[5] if low else r[3]  # um tom abaixo da biblioteca: cruzes vermelhas, não rosa
					if glint and ((x == L + 1 and y == L + 1) or (w > 0 and x == L + 1 - w and y == 1)):
						c = Color.WHITE
				else:
					var ch: String = rows[y - 1][x - 1]
					c = Color.WHITE if ch == "w" or (glint and ch == "1") else r[int(ch)]
			elif inside.call(x - 1, y) or inside.call(x + 1, y) or inside.call(x, y - 1) or inside.call(x, y + 1):
				c = OUTLINE
			img.set_pixel(x, y, c)
	_glyphs[key] = ImageTexture.create_from_image(img)
	return _glyphs[key]


static func smooth(a: float, b: float, x: float) -> float:
	var k := clampf((x - a) / (b - a), 0.0, 1.0)
	return k * k * (3.0 - 2.0 * k)


static func out_expo(k: float) -> float:
	return 1.0 if k >= 1.0 else 1.0 - pow(2.0, -10.0 * clampf(k, 0.0, 1.0))


static func out_cubic(k: float) -> float:
	return 1.0 - pow(1.0 - clampf(k, 0.0, 1.0), 3.0)


static func out_back(k: float) -> float:
	var u := clampf(k, 0.0, 1.0) - 1.0
	return 1.0 + 2.7 * u * u * u + 1.7 * u * u
