"""Folhas 32-bit do Gemini (tools/src/PX-xx, 4x2 frames sobre magenta) -> frames limpos para o jogo.
O desenho do Gemini já é pixel art e tem mais detalhe do que o ecrã base mostra: em vez de o re-pixelizar
(perdia o detalhe e ficava com manchas), cada frame é recortado do magenta, com a franja rosa das bordas
tirada, e reduzido com média de área para OUT vezes o tamanho no jogo (o jogo desenha-o a 1/OUT: nítido no
telemóvel). O magenta do fundo (e a sombra magenta mais escura que o Gemini às vezes deixa) fica transparente.
O Gemini não desenha sempre à mesma escala: cada folha diz que fração da altura da imagem ocupa a personagem de
pé (BODY) e quantos píxeis deve ter no jogo (TARGET), e a redução sai daí. Tudo fica virado para a direita, como
o Gemini desenha (o jogo espelha quando olham para a esquerda).
Escreve art/anim/<nome>_N.png e art/anim/feet32.gd com os pés de cada frame.
O mundo (WORLD: chão e adereços da Parte 5) sai um PNG por item, por cima dos pintados (os mesmos nomes), e os
mapas da praça e da cripta (PX-33, PX-34) vão para art/bg com as bordas a desvanecer.
Uso: python -I tools/cut_pixel.py   (só o mundo: --world)
"""
import os
import sys

from PIL import Image, ImageChops, ImageFilter

sys.path.insert(0, os.path.dirname(__file__))
from cut_anim import STEP, _components, _feet  # noqa: E402
from import_art import fade_edges  # noqa: E402

SRC = "tools/src"
OUT = 2  # resolução dos frames = OUT x o tamanho no ecrã base (o jogo desenha-os a 1/OUT)
COLS, ROWS = 4, 2
TARGET = {"art/anim/strider32": 73, "art/anim/warden32": 80, "art/anim/skeleton32": 60, "art/anim/specter32": 58,
          "art/anim/colossus32": 174, "art/anim/herald32": 180}  # altura de pé em píxeis de arte (como nos pintados)
## folha, saída, primeiro índice, fração da altura da imagem que a personagem de pé ocupa (medida no manto ou na
## armadura, sem a arma nem efeitos), fração de baixo de cada célula a apagar (legendas que o Gemini escreveu) e,
## opcional, um dicionário: "drop" = frames (1 a 8) onde se tira o verde que sobrou do frame anterior; "free" =
## a folha não respeita a grelha 4x2 (ver free(), com "pick", "cols", "rows" e "split"); "fit" = todas as figuras
## da folha à mesma altura (para andar, quando o Gemini as desenhou de tamanhos diferentes).
SHEETS = [
    ("PX-01", "art/anim/strider32", 0, 0.41, 0.0),  # 0-7 andar
    ("PX-02", "art/anim/strider32", 8, 0.41, 0.0),  # 8-15 gadanha
    ("PX-03", "art/anim/strider32", 16, 0.40, 0.0),  # 16-23 parado
    ("PX-04", "art/anim/strider32", 24, 0.411, 0.0),  # 24-27 ferido, 28 caído, 29-31 a reerguer-se
    ("PX-05", "art/anim/strider32", 32, 0.388, 0.0, {"drop": [8]}),  # 32-39 Lança de Almas (refeita na Parte 2)
    ("PX-06", "art/anim/strider32", 40, 0.335, 0.0),  # 40-47 Nova Espectral
    ("PX-52", "art/anim/strider32", 48, 0.355, 0.115),  # 48-55 Esquiva (com legendas por baixo)
    ("PX-07", "art/anim/warden32", 0, 0.415, 0.0),  # 0-7 andar
    ("PX-08", "art/anim/warden32", 8, 0.378, 0.0),  # 8-15 machado
    ("PX-09", "art/anim/warden32", 16, 0.455, 0.0),  # 16-23 parado
    ("PX-10", "art/anim/warden32", 24, 0.465, 0.0),  # 24 ferido, 25 de joelhos, 26-27 caído, 28-31 a reerguer-se
    ("PX-11", "art/anim/warden32", 32, 0.47, 0.0),  # 32-39 Ceifa de Ossos (giro)
    ("PX-12", "art/anim/warden32", 40, 0.456, 0.0),  # 40-47 Armadura de Ossos
    ("PX-53", "art/anim/warden32", 48, 0.45, 0.0),  # 48-55 Esquiva
    ("PX-13", "art/anim/skeleton32", 0, 0.41, 0.0),  # 0-7 andar
    ("PX-14", "art/anim/skeleton32", 8, 0.41, 0.0),  # 8-15 espada
    ("PX-15", "art/anim/skeleton32", 16, 0.39, 0.0),  # 16-19 parado, 20-23 ferido
    ("PX-16", "art/anim/skeleton32", 24, 0.42, 0.0),  # 24-31 a morrer
    ("PX-17", "art/anim/specter32", 0, 0.40, 0.0),  # 0-7 a flutuar
    ("PX-18", "art/anim/specter32", 8, 0.355, 0.0),  # 8-15 grito (refeito na Parte 4)
    ("PX-19", "art/anim/specter32", 16, 0.38, 0.0),  # 16-19 parado, 20-23 ferido
    ("PX-20", "art/anim/specter32", 24, 0.39, 0.0, {"free": True, "pick": [0, 1, 2, 3, 4, 5, 9, 9]}),  # 24-31 a desfazer-se (o Gemini meteu Colossos na 2.ª fila)
    ("PX-21", "art/anim/colossus32", 0, 0.38, 0.0, {"free": True, "pick": [0, 1, 2, 3, 4, 5, 6, 7], "fit": True}),  # 0-7 andar (9 figuras, a 2.ª fila mais pequena)
    ("PX-22", "art/anim/colossus32", 8, 0.42, 0.0),  # 8-15 murro no chão
    ("PX-23", "art/anim/colossus32", 16, 0.39, 0.0),  # 16-19 parado, 20-23 ferido
    ("PX-24", "art/anim/colossus32", 24, 0.44, 0.0),  # 24-31 a morrer
    ("PX-25", "art/anim/herald32", 0, 0.40, 0.0, {"free": True}),  # 0-7 andar (12 figuras)
    ("PX-26", "art/anim/herald32", 8, 0.41, 0.0, {"free": True, "split": False}),  # 8-15 o sino no chão
    ("PX-27", "art/anim/herald32", 16, 0.41, 0.0, {"free": True, "cols": 6, "rows": 2}),  # 16-23 a invocar (6x2, o fumo liga tudo)
    ("PX-28", "art/anim/herald32", 24, 0.41, 0.0, {"free": True}),  # 24-31 a morrer (10 figuras)
]


def is_bg(r, g, b):
    """Magenta do fundo, a franja rosa do JPG e a sombra magenta escura (o roxo #7B2FBE da arte fica)."""
    return (r > 150 and b > 150 and g < 90) or (r > 90 and b > 90 and g < 40 and abs(r - b) < 50)


def cut(path, blank=0.0, drop=()):
    """Os 8 frames da folha, todos com a mesma caixa: centrados na célula e da mesma altura (pés alinhados).
    Cada mancha pertence ao frame onde está o seu centro (como em cut_anim.py): o golpe verde que o Gemini
    deixou passar para a célula do lado não suja o frame vizinho."""
    im = Image.open(path).convert("RGB")
    cw, ch = im.width // COLS, im.height // ROWS
    alpha = _alpha(im, blank, drop)
    small = alpha.filter(ImageFilter.MaxFilter(5)).resize((im.width // STEP, im.height // STEP), Image.NEAREST)
    return _by_cell(im, alpha, small, cw, ch, path)


def _alpha(im, blank=0.0, drop=()):
    """Máscara do desenho: sem o magenta, sem as legendas e sem o verde que sobrou do frame anterior."""
    cw, ch = im.width // COLS, im.height // ROWS
    alpha = Image.new("L", im.size)
    alpha.putdata([0 if is_bg(*p) else 255 for p in im.get_flattened_data()])
    for f in drop:  # verde (a Lança do frame anterior) colado à margem esquerda deste frame: fora
        r, c = divmod(f - 1, COLS)
        x0, y0 = int(c * cw - 0.1 * cw), r * ch
        for y in range(y0, y0 + ch):
            for x in range(max(0, x0), int(c * cw + 0.25 * cw)):
                pr, pg, pb = im.getpixel((x, y))
                if pg > pr + 18 and pg >= pb:  # inclui o miolo claro da bola
                    alpha.putpixel((x, y), 0)
    if blank:  # apaga as legendas no fundo de cada célula
        for r in range(ROWS):
            y0 = int((r + 1 - blank) * im.height / ROWS)
            alpha.paste(0, (0, y0, im.width, int((r + 1) * im.height / ROWS)))
    return alpha.filter(ImageFilter.MinFilter(3)).filter(ImageFilter.MaxFilter(3))  # tira o pó solto


def _runs(values, gap, min_len):
    """Troços seguidos com desenho (valor > 0), juntando os que estão separados por menos de gap."""
    runs, start, last = [], None, None
    for i, v in enumerate(values):
        if v > 0:
            if start is None:
                start = i
            elif i - last > gap:
                runs.append((start, last + 1))
                start = i
            last = i
    if start is not None:
        runs.append((start, last + 1))
    return [r for r in runs if r[1] - r[0] >= min_len]


def free(path, blank=0.0, drop=(), pick=None, cols=0, rows=0, split=True):
    """Folhas em que o Gemini não respeitou a grelha (mais colunas, figuras desalinhadas): as filas e as figuras
    encontram-se pelos espaços vazios à volta delas. Uma mancha larga demais (duas figuras encostadas) divide-se
    ao meio. Fica com os frames de pick (índices por ordem de leitura) ou, sem pick, com 8 espalhados pela
    sequência (o primeiro e o último incluídos). Cada frame é centrado no seu centro de massa.
    cols / rows: as figuras encostam-se umas às outras (fumo a ligá-las): as filas / colunas dividem-se em partes iguais.
    split=False: manchas largas ficam inteiras (um anel no chão à volta de uma figura não é outra figura)."""
    im = Image.open(path).convert("RGB")
    alpha = _alpha(im, blank, drop)
    w, h = im.size
    segs = []
    bands = _runs(alpha.resize((1, h), Image.BOX).get_flattened_data(), int(0.03 * h), int(0.05 * h))
    if rows:
        top, bottom = bands[0][0], bands[-1][1]
        bands = [(top + (bottom - top) * k // rows, top + (bottom - top) * (k + 1) // rows) for k in range(rows)]
    for y0, y1 in bands:
        band = alpha.crop((0, y0, w, y1))
        if cols:
            x0, x1 = _runs(band.resize((w, 1), Image.BOX).get_flattened_data(), w, 4)[0]
            segs += [(x0 + (x1 - x0) * k // cols, y0, x0 + (x1 - x0) * (k + 1) // cols, y1) for k in range(cols)]
            continue
        runs = _runs(band.resize((w, 1), Image.BOX).get_flattened_data(), int(0.012 * w), 4)
        mass = [sum(band.crop((x0, 0, x1, y1 - y0)).resize((1, 1), Image.BOX).get_flattened_data()) * (x1 - x0) for x0, x1 in runs]
        runs = [c for c, m in zip(runs, mass) if m >= 0.004 * max(mass)]
        widths = sorted(x1 - x0 for x0, x1 in runs if x1 - x0 > 0.03 * w)
        typical = widths[len(widths) // 2] if widths else w
        for x0, x1 in runs:
            n = max(1, round((x1 - x0) / typical)) if split and x1 - x0 > 1.7 * typical else 1
            for k in range(n):
                segs.append((x0 + (x1 - x0) * k // n, y0, x0 + (x1 - x0) * (k + 1) // n, y1))
    if pick is None:
        pick = [round(i * (len(segs) - 1) / 7) for i in range(8)] if len(segs) > 8 else list(range(len(segs)))
    assert len(pick) == 8, f"{path}: {len(segs)} figuras, escolhe 8 com pick"
    frames = []
    for i in pick:
        x0, y0, x1, y1 = segs[i]
        m = Image.new("L", im.size)
        m.paste(alpha.crop((x0, y0, x1, y1)), (x0, y0))
        col = m.crop((0, y0, w, y1)).resize((w, 1), Image.BOX).get_flattened_data()
        tot = sum(col)
        cx = round(sum(x * v for x, v in enumerate(col)) / tot) if tot else (x0 + x1) // 2
        half = max(cx - x0, x1 - cx)
        box = (cx - half, y0, cx + half, y1)
        frames.append((im.crop(box), m.crop(box)))
    return frames, segs


def _by_cell(im, alpha, small, cw, ch, path):
    masks = _cell_masks(im, alpha, small, COLS, ROWS, path)
    boxes = []
    for i, m in enumerate(masks):
        b = m.getbbox()
        r, c = divmod(i, COLS)
        boxes.append((b[0] - c * cw, b[1] - r * ch, b[2] - c * cw, b[3] - r * ch))
    half = max(max(cw / 2 - b[0], b[2] - cw / 2) for b in boxes)
    top, bottom = min(b[1] for b in boxes), max(b[3] for b in boxes)
    frames = []
    for i in range(COLS * ROWS):
        r, c = divmod(i, COLS)
        box = (int(c * cw + cw / 2 - half), r * ch + top, int(c * cw + cw / 2 + half), r * ch + bottom)
        frames.append((im.crop(box), masks[i].crop(box)))
    return frames


def _cell_masks(im, alpha, small, cols, rows, path):
    """Máscara do desenho de cada célula da grelha (por ordem de leitura)."""
    cw, ch = im.width // cols, im.height // rows

    def cell_of(x, y):
        return min(rows - 1, y * STEP // ch) * cols + min(cols - 1, x * STEP // cw)

    owner = [[] for _ in range(cols * rows)]
    for cells in _components(small):
        if len(cells) < 12:
            continue
        xs, ys = [c[0] for c in cells], [c[1] for c in cells]
        if (max(xs) - min(xs)) * STEP > 1.2 * cw or (max(ys) - min(ys)) * STEP > 1.2 * ch:
            for c in cells:  # mancha que atravessa várias células: divide pela grelha
                owner[cell_of(*c)].append(c)
        else:
            owner[cell_of((min(xs) + max(xs)) // 2, (min(ys) + max(ys)) // 2)].extend(cells)
    masks = []
    for i, cells in enumerate(owner):
        m = Image.new("L", small.size)
        for c in cells:
            m.putpixel(c, 255)
        m = ImageChops.multiply(alpha, m.resize(im.size, Image.NEAREST).filter(ImageFilter.MaxFilter(5)))
        assert m.getbbox(), f"{path}: frame {i + 1} vazio"
        masks.append(m)
    return masks


def shrink(rgb, a, factor):
    """Recorte limpo e reduzido: tira 1 px de borda (a franja rosa do magenta) e o que ainda for rosado, e reduz
    com média de área sobre alfa pré-multiplicado (as bordas não puxam cor do fundo)."""
    a = a.filter(ImageFilter.MinFilter(3))
    pink = Image.new("L", rgb.size)
    pink.putdata([255 if r > 140 and b > 140 and g < r - 50 else 0 for r, g, b in rgb.get_flattened_data()])
    a = ImageChops.subtract(a, pink)
    rgba = rgb.convert("RGBA")
    rgba.putalpha(a)
    w, h = round(rgb.width / factor), round(rgb.height / factor)
    return rgba.convert("RGBa").resize((w, h), Image.Resampling.BOX).convert("RGBA")


def frames_of(path, blank, opt):
    """Os 8 frames de uma folha: pela grelha 4x2 ou, nas folhas fora da grelha, figura a figura."""
    if opt.get("free"):
        return free(path, blank, opt.get("drop", ()), opt.get("pick"), opt.get("cols", 0), opt.get("rows", 0), opt.get("split", True))[0]
    return cut(path, blank, opt.get("drop", ()))


## Mundo 32-bit: folha, pasta, nomes por ordem de leitura, altura a que o jogo desenha cada um (main.gd: PROPS,
## o monumento e as decorações; chest.gd: o baú). Cada adereço fica com o dobro dessa altura (nítido no
## telemóvel, sem nunca ampliar o desenho do Gemini); os ladrilhos com 256 px de largura, como os pintados.
WORLD = [
    ("PX-29", "art/tiles", 4, 2, ["cobble", "cobble_moss", "grass", "mud", "slab", "slab_roots", "bones", "water"], None),
    ("PX-30", "art/props", 4, 2, ["monument", "monument_on", "waypoint", "waypoint_on", "shrine", "shrine_on", "chest", "chest_open"],
     [230, 230, 80, 80, 90, 90, 90, 90]),
    ("PX-31", "art/props", 4, 3, ["grave_broken", "graves3", "fence", "fence_gate", "coffin", "coffin_open", "candles", "skulls",
                                  "roots", "bush", "statue", "lantern"], [84, 62, 70, 76, 46, 46, 52, 46, 56, 62, 112, 122]),
    ("PX-32", "art/props", 3, 2, ["chapel", "crypt_door", "gatehouse", "rubble", "cage_tree", "cliff"], [230, 200, 220, 150, 230, 160]),
    # o Gemini deixou umas velas e um fumo soltos entre os itens: fica só a maior mancha de cada célula
    ("PX-54", "art", 3, 1, ["tree", "tomb", "crypt"], [150, 66, 140], {"biggest": True}),
]
MAPS = [("PX-33", "hub"), ("PX-34", "crypt")]  # a praça (main.gd: HUB_SPOT) e a cripta (CRYPT_FLOOR medido nela)


def _biggest(m):
    """Só a maior mancha da máscara."""
    small = m.filter(ImageFilter.MaxFilter(5)).resize((m.width // STEP, m.height // STEP), Image.NEAREST)
    keep = Image.new("L", small.size)
    for c in max(_components(small), key=len):
        keep.putpixel(c, 255)
    return ImageChops.multiply(m, keep.resize(m.size, Image.NEAREST).filter(ImageFilter.MaxFilter(5)))


def world():
    for code, folder, cols, rows, names, heights, *opt in WORLD:
        path = f"{SRC}/{code}.png"
        im = Image.open(path).convert("RGB")
        alpha = _alpha(im)
        small = alpha.filter(ImageFilter.MaxFilter(5)).resize((im.width // STEP, im.height // STEP), Image.NEAREST)
        for i, m in enumerate(_cell_masks(im, alpha, small, cols, rows, path)):
            if opt and opt[0].get("biggest"):
                m = _biggest(m)
            box = m.getbbox()
            rgb, a = im.crop(box), m.crop(box)
            # brilho verde pintado por cima do magenta (o halo lilás à volta da lanterna e do portal): fora
            halo = Image.new("L", rgb.size)
            halo.putdata([255 if r > 120 and b > 140 and g > 70 and b > g + 40 and r > g + 20 else 0 for r, g, b in rgb.get_flattened_data()])
            a = ImageChops.subtract(a, halo)
            factor = rgb.width / 256 if heights is None else max(1.0, rgb.height / (2 * heights[i]))
            px = shrink(rgb, a, factor)
            px.save(f"{folder}/{names[i]}.png")
            pink = sum(1 for r, g, b, al in px.get_flattened_data() if al > 128 and r > 200 and b > 200 and g < 80)
            assert px.getbbox() and pink == 0, f"{names[i]}: vazio ou {pink} píxeis magenta"
        print(code, folder, len(names), "itens")
    for code, name in MAPS:  # sem perdas: a compressão estragava os blocos de píxeis
        fade_edges(Image.open(f"{SRC}/{code}.png").convert("RGB")).save(f"art/bg/{name}.webp", lossless=True)
        print(code, f"art/bg/{name}.webp")


def main():
    if "--world" in sys.argv:
        world()
        return
    groups = {}
    for code, out, first, body, blank, *opt in SHEETS:
        path = f"{SRC}/{code}.png" if os.path.exists(f"{SRC}/{code}.png") else f"{SRC}/{code}.jpg"  # o PNG é a versão maior
        h = Image.open(path).height
        o = opt[0] if opt else {}
        groups.setdefault(out, []).append((first, body * h / (TARGET[out] * OUT), frames_of(path, blank, o), o.get("fit", False)))
    feet = {}
    for out, sheets in groups.items():
        sizes = set()
        for first, factor, frames, fit in sheets:
            hs = [a.getbbox()[3] - a.getbbox()[1] for _, a in frames]
            for i, (rgb, a) in enumerate(frames):
                # fit: o Gemini desenhou umas figuras maiores do que outras na mesma folha; ficam todas da mesma altura
                px = shrink(rgb, a, factor * (hs[i] / sorted(hs)[len(hs) // 2] if fit else 1.0))
                px.save(f"{out}_{first + i}.png")
                feet.setdefault(os.path.basename(out), {})[first + i] = _feet(px)
                sizes.add(px.size)
                # auto-verificação: o frame tem desenho e nenhum píxel magenta do fundo
                assert px.getbbox(), f"{out}_{first + i}: vazio"
                pink = sum(1 for r, g, b, al in px.get_flattened_data() if al > 128 and r > 200 and b > 200 and g < 80)
                assert pink == 0, f"{out}_{first + i}: {pink} píxeis magenta"
        print(out, "frames:", sum(len(sh[2]) for sh in sheets), "tamanhos:", sorted(sizes))
    with open("art/anim/feet32.gd", "w", encoding="utf-8") as fh:
        fh.write("# Gerado por tools/cut_pixel.py — não editar à mão.\n")
        fh.write("## Pés dos frames 32-bit (píxeis da textura entre o fundo e a linha dos pés).\n")
        fh.write("const FEET := {\n")
        for name, d in feet.items():
            fh.write('\t"%s": %s,\n' % (name, [d[i] for i in sorted(d)]))
        fh.write("}\n")
    world()


if __name__ == "__main__":
    main()
