"""Folhas 32-bit do Gemini (tools/src/PX-xx.jpg, 4x2 frames sobre magenta) -> frames de pixel art limpos.
O Gemini desenha "píxeis" de ~8,6 px que não batem numa grelha certa, por isso a grelha não se adivinha:
cada personagem é re-pixelizada à mesma escala (FACTOR), com uma paleta comum a todas as folhas dela e sem
pontilhado, para os frames ficarem iguais entre si. O magenta do fundo (e a sombra magenta mais escura que o
Gemini às vezes deixa debaixo dos pés) fica transparente.
Escreve art/anim/<nome>_N.png no tamanho nativo e art/anim/feet32.gd com os pés de cada frame.
Uso: python -I tools/cut_pixel.py
"""
import os
import sys

from PIL import Image, ImageChops, ImageFilter

sys.path.insert(0, os.path.dirname(__file__))
from cut_anim import STEP, _components, _feet  # noqa: E402

SRC = "tools/src"
FACTOR = 8.6  # píxeis da imagem por píxel de arte (2752 / 320)
COLORS = 32
COLS, ROWS = 4, 2
## folha, saída, primeiro índice, espelhar (o Gemini desenha virado para a direita; o Strider do jogo olha para a esquerda)
SHEETS = [
    ("PX-01", "art/anim/strider32", 0, True),  # 0-7 andar
    ("PX-02", "art/anim/strider32", 8, True),  # 8-15 gadanha
]


def is_bg(r, g, b):
    """Magenta do fundo, a franja rosa do JPG e a sombra magenta escura (o roxo #7B2FBE da arte fica)."""
    return (r > 150 and b > 150 and g < 90) or (r > 90 and b > 90 and g < 40 and abs(r - b) < 50)


def cut(path):
    """Os 8 frames da folha, todos com a mesma caixa: centrados na célula e da mesma altura (pés alinhados).
    Cada mancha pertence ao frame onde está o seu centro (como em cut_anim.py): o golpe verde que o Gemini
    deixou passar para a célula do lado não suja o frame vizinho."""
    im = Image.open(path).convert("RGB")
    alpha = Image.new("L", im.size)
    alpha.putdata([0 if is_bg(*p) else 255 for p in im.get_flattened_data()])
    alpha = alpha.filter(ImageFilter.MinFilter(3)).filter(ImageFilter.MaxFilter(3))  # tira o pó solto
    cw, ch = im.width // COLS, im.height // ROWS
    small = alpha.filter(ImageFilter.MaxFilter(5)).resize((im.width // STEP, im.height // STEP), Image.NEAREST)

    def cell_of(x, y):
        return min(ROWS - 1, y * STEP // ch) * COLS + min(COLS - 1, x * STEP // cw)

    owner = [[] for _ in range(COLS * ROWS)]
    for cells in _components(small):
        if len(cells) < 12:
            continue
        xs, ys = [c[0] for c in cells], [c[1] for c in cells]
        if (max(xs) - min(xs)) * STEP > 1.2 * cw or (max(ys) - min(ys)) * STEP > 1.2 * ch:
            for c in cells:  # mancha que atravessa várias células: divide pela grelha
                owner[cell_of(*c)].append(c)
        else:
            owner[cell_of((min(xs) + max(xs)) // 2, (min(ys) + max(ys)) // 2)].extend(cells)
    masks, boxes = [], []
    for i, cells in enumerate(owner):
        m = Image.new("L", small.size)
        for c in cells:
            m.putpixel(c, 255)
        m = ImageChops.multiply(alpha, m.resize(im.size, Image.NEAREST).filter(ImageFilter.MaxFilter(5)))
        b = m.getbbox()
        assert b, f"{path}: frame {i + 1} vazio"
        r, c = divmod(i, COLS)
        masks.append(m)
        boxes.append((b[0] - c * cw, b[1] - r * ch, b[2] - c * cw, b[3] - r * ch))
    half = max(max(cw / 2 - b[0], b[2] - cw / 2) for b in boxes)
    top, bottom = min(b[1] for b in boxes), max(b[3] for b in boxes)
    frames = []
    for i in range(COLS * ROWS):
        r, c = divmod(i, COLS)
        box = (int(c * cw + cw / 2 - half), r * ch + top, int(c * cw + cw / 2 + half), r * ch + bottom)
        frames.append((im.crop(box), masks[i].crop(box)))
    return frames


def palette(frames):
    """Paleta comum: uma amostra dos píxeis opacos de todos os frames da personagem."""
    sample = []
    for rgb, a in frames:
        small, am = rgb.resize((rgb.width // 4, rgb.height // 4), Image.NEAREST), a.resize((rgb.width // 4, rgb.height // 4), Image.NEAREST)
        sample += [p for p, v in zip(small.get_flattened_data(), am.get_flattened_data()) if v]
    strip = Image.new("RGB", (len(sample), 1))
    strip.putdata(sample)
    return strip.quantize(COLORS, method=Image.Quantize.MEDIANCUT)


def pixelate(rgb, a, pal):
    """Cada píxel de arte = a cor mais comum do seu bloco (filtro de moda sobre a paleta); opaco se >= metade."""
    w, h = round(rgb.width / FACTOR), round(rgb.height / FACTOR)
    q = rgb.quantize(palette=pal, dither=Image.Dither.NONE).filter(ImageFilter.ModeFilter(7))
    m = a.resize((w, h), Image.BOX).point(lambda v: 255 if v >= 128 else 0)
    # o que é transparente fica (0, 0, 0, 0): sem cores escondidas por baixo
    return Image.composite(q.resize((w, h), Image.NEAREST).convert("RGBA"), Image.new("RGBA", (w, h)), m)


def main():
    groups = {}
    for code, out, first, mirror in SHEETS:
        groups.setdefault(out, []).append((first, mirror, cut(f"{SRC}/{code}.jpg")))
    feet = {}
    for out, sheets in groups.items():
        pal = palette([f for *_, frames in sheets for f in frames])
        sizes = set()
        for first, mirror, frames in sheets:
            for i, (rgb, a) in enumerate(frames):
                px = pixelate(rgb, a, pal)
                if mirror:
                    px = px.transpose(Image.Transpose.FLIP_LEFT_RIGHT)
                px.save(f"{out}_{first + i}.png")
                feet.setdefault(os.path.basename(out), {})[first + i] = _feet(px)
                sizes.add(px.size)
                # auto-verificação: o frame tem desenho e não passa das cores da paleta
                assert px.getbbox(), f"{out}_{first + i}: vazio"
                assert len(px.getcolors(4096) or []) <= COLORS + 1, f"{out}_{first + i}: cores a mais"
        print(out, "frames:", sum(len(f) for *_, f in sheets), "tamanhos:", sorted(sizes))
    with open("art/anim/feet32.gd", "w", encoding="utf-8") as fh:
        fh.write("# Gerado por tools/cut_pixel.py — não editar à mão.\n")
        fh.write("## Pés dos frames 32-bit (píxeis de arte entre o fundo da textura e a linha dos pés).\n")
        fh.write("const FEET := {\n")
        for name, d in feet.items():
            fh.write('\t"%s": %s,\n' % (name, [d[i] for i in sorted(d)]))
        fh.write("}\n")


if __name__ == "__main__":
    main()
