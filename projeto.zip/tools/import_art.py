"""Importa toda a arte do Gemini (tools/src/CODIGO.jpg) para art/. Corre de novo sempre que trocares uma folha.
Uso: python tools/import_art.py
"""
import os
import sys
from PIL import Image, ImageChops, ImageDraw, ImageFilter

sys.path.insert(0, os.path.dirname(__file__))
import cut_anim  # noqa: E402
import cut_sheet  # noqa: E402
from cut_sprites import key  # noqa: E402

SRC = "tools/src"

## folha, saída, escala, primeiro índice, assente no chão (o espectro flutua), espelhar (opcional).
## Escala: altura do frame 1 em píxeis, "x0.6" fixa, ou "=FOLHA*k" = a escala de outra folha vezes k.
## Uso rápido só para as animações: python tools/import_art.py --anims
ANIMS = [
    ("SPR-01", "art/anim/player", 228, 0, True),  # 0-3 andar, 4-7 gadanha
    ("SPR-08", "art/anim/player", 228, 8, True),  # 8-9 parado, 10-11 ferido, 12 a cair, 13 caído, 14-15 reanimado
    # 16-19 Lança de Almas, 20-23 Nova. Nesta folha o ceifeiro saiu ~13% mais pequeno (medido à mão
    # pelo capuz, porque a gadanha por cima da cabeça engana a altura do frame 1) e virado para a direita.
    ("SPR-09", "art/anim/player", "=SPR-08*1.13", 16, True, True),
    ("SPR-02", "art/anim/skeleton", 212, 0, True),  # 0-3 andar, 4-7 espadeirada
    ("SPR-05", "art/anim/skeleton", 212, 8, True),  # 8-9 parado, 10-11 ferido, 12-15 morte
    ("SPR-03", "art/anim/colossus", 265, 0, True),  # 0-3 andar, 4-7 murro no chão
    ("SPR-07", "art/anim/colossus", 265, 8, True),  # 8-9 parado, 10-11 ferido, 12-15 morte
    ("SPR-04", "art/anim/specter", 193, 0, False),  # 0-3 flutuar, 4-7 grito
    ("SPR-06", "art/anim/specter", 193, 8, False),  # 8-9 parado, 10-11 ferido, 12-15 morte
    ("SPR-10", "art/anim/warden", "x0.475", 0, True),  # 0-3 andar, 4-7 machadada
    ("SPR-11", "art/anim/warden", "x0.475", 8, True),  # 8-9 parado, 10 caído, 11 reanimado, 12-15 giro
    ("SPR-12", "art/anim/herald", "x0.6", 0, True),  # 0-3 andar, 4-7 sino no chão
    ("SPR-13", "art/anim/herald", "x0.6", 8, True),  # 8-11 invocar, 12-15 morte
]

SHEETS = [  # modo, folha, pasta, maior lado, [grelha], nomes por ordem de leitura
    # o chão e os adereços já são 32-bit (tools/cut_pixel.py, WORLD): as folhas pintadas PRP-01..03 e TIL-01 já não se cortam
    ("blob", "ICO-01", "art/icons", 128, ["bone", "ink", "ash", "potion_red", "potion_soul", "flask_empty", "flask_parasita", "flask_titanica", "flask_swift", "flask_echo", "flask_grave", "flask_wrath"]),
    ("blob", "ICO-02", "art/icons", 128, ["scythe", "greataxe", "sword", "staff", "hood", "helm", "robe", "chest_armor", "gloves", "boots", "belt", "ring", "amulet", "shield", "sealed", "relic"]),
    ("blob", "ICO-03", "art/icons", 160, ["sk_scythe", "sk_bolt", "sk_nova", "sk_raise", "sk_cleave", "sk_chop", "sk_curse", "sk_bonearmor", "sk_sacrifice", "sk_revive", "sk_ping", "sk_potion"]),
    ("blob", "ICO-04", "art/tree", 128, ["node", "node_on", "notable", "notable_on", "keystone", "keystone_on", "root", "root_on"]),
    ("blob", "UI-01", "art/ui", 360, ["orb_holder", "orb_red", "orb_soul", "ring_small", "ring_big", "joy_base", "joy_knob", "portrait_frame"]),
    ("blob", "UI-02", "art/ui", 400, ["panel", "slot", "bar", "box", "tooltip", "btn", "btn_on"]),
    ("gridbox", "VFX-02", "art/fx", 256, "4x2", ["ring_p1", "ring_p2", "ring_p3", "ring_p4", "revive", "beam_common", "beam_rare", "beam_unique"]),
    ("grid", "VFX-01", "art/fx", 256, "4x2", ["slash_0", "slash_1", "slash_2", "slash_3", "hit_0", "hit_1", "hit_2", "hit_3"]),
]


def fade_edges(im, margin=0.16):
    """Alfa a desvanecer nas bordas, para o mapa pintado se fundir com o chão em tiles."""
    w, h = im.size
    mx, my = int(w * margin), int(h * margin)
    row = Image.new("L", (w, 1))
    row.putdata([int(255 * min(1.0, min(x, w - 1 - x) / mx)) for x in range(w)])
    col = Image.new("L", (1, h))
    col.putdata([int(255 * min(1.0, min(y, h - 1 - y) / my)) for y in range(h)])
    mask = ImageChops.multiply(row.resize((w, h)), col.resize((w, h)))
    out = im.convert("RGBA")
    out.putalpha(mask)
    return out


def circle(im, size):
    im = im.convert("RGBA").resize((size, size), Image.LANCZOS)
    mask = Image.new("L", (size, size), 0)
    ImageDraw.Draw(mask).ellipse((0, 0, size - 1, size - 1), fill=255)
    im.putalpha(ImageChops.multiply(im.getchannel("A"), mask))
    return im


def keyed(im):
    out = Image.new("RGBA", im.size)
    out.putdata([key(p) for p in im.convert("RGB").get_flattened_data()])
    return out


def app_icons(src):
    """Ícones da app. Ícone normal: a imagem toda. Ícone adaptativo do Android: o telemóvel recorta o fundo em
    círculo ou quadrado e só mostra os 66% do meio, por isso a imagem vai a 80% por cima de uma cópia desfocada
    (a cara do canto continua visível); a frente fica transparente, senão aparece o logótipo do Godot."""
    icon = Image.open(src).convert("RGB")
    icon.resize((256, 256), Image.LANCZOS).save("icon.png")
    os.makedirs("art/app", exist_ok=True)
    icon.resize((192, 192), Image.LANCZOS).save("art/app/icon_192.png")
    bg = icon.resize((432, 432), Image.LANCZOS).filter(ImageFilter.GaussianBlur(18)).point(lambda v: int(v * 0.6))
    inner = 346
    mask = Image.new("L", (inner, inner), 0)
    ImageDraw.Draw(mask).rounded_rectangle((0, 0, inner - 1, inner - 1), radius=60, fill=255)
    bg.paste(icon.resize((inner, inner), Image.LANCZOS), ((432 - inner) // 2,) * 2, mask.filter(ImageFilter.GaussianBlur(10)))
    bg.save("art/app/adaptive_bg_432.png")
    Image.new("RGBA", (432, 432), (0, 0, 0, 0)).save("art/app/adaptive_fg_432.png")
    splash(icon)


def splash(icon):
    """Ecrã de arranque (project.godot): o ceifeiro do ícone, de bordas suaves, e o nome do jogo na letra de
    píxeis, desenhado a 16 px e ampliado 3x sem suavizar para os píxeis ficarem iguais."""
    from PIL import ImageFont
    art = icon.resize((360, 360), Image.LANCZOS).convert("RGBA")
    mask = Image.new("L", (360, 360), 0)
    ImageDraw.Draw(mask).rounded_rectangle((12, 12, 347, 347), radius=48, fill=255)
    art.putalpha(mask.filter(ImageFilter.GaussianBlur(10)))
    font = ImageFont.truetype("fonts/Alkhemikal.ttf", 16)
    w = int(font.getlength("Soulstrider")) + 4
    name = Image.new("L", (w, 20), 0)
    ImageDraw.Draw(name).text((2, 0), "Soulstrider", font=font, fill=255)
    name = name.point(lambda v: 255 if v > 100 else 0).resize((w * 3, 60), Image.NEAREST)
    out = Image.new("RGBA", (max(360, w * 3), 360 + 24 + 60), (0, 0, 0, 0))
    out.paste(art, ((out.width - 360) // 2, 0), art)
    out.paste(Image.new("RGBA", name.size, (200, 245, 210, 255)), ((out.width - name.width) // 2, 384), name)
    out.save("art/ui/splash.png")


def main():
    scales, feet = {}, {}
    for code, out, size, first, grounded, *mirror in ANIMS:
        if str(size).startswith("="):
            ref, _, k = size[1:].partition("*")
            size = "x%f" % (scales[ref] * float(k or 1))
        scales[code], offs = cut_anim.main(f"{SRC}/{code}.jpg", out, size, first, grounded, bool(mirror and mirror[0]))
        feet.setdefault(os.path.basename(out), {}).update({first + i: o for i, o in enumerate(offs)})
    with open("art/anim/feet.gd", "w", encoding="utf-8") as fh:
        fh.write("# Gerado por tools/import_art.py — não editar à mão.\n")
        fh.write("## Por frame: píxeis entre o fundo da textura e a linha dos pés, para ninguém flutuar.\n")
        fh.write("const FEET := {\n")
        for name, d in feet.items():
            fh.write('\t"%s": %s,\n' % (name, [d[i] for i in sorted(d)]))
        fh.write("}\n")
    if "--anims" in sys.argv:
        return
    for job in SHEETS:
        mode, code, folder, mx = job[:4]
        cut_sheet.main(mode, f"{SRC}/{code}.jpg", folder, mx, *job[4:-1], *job[-1])
    # versões pequenas para os StyleBoxTexture dos botões (as margens 9-slice desenham-se 1:1)
    for n, size in [("btn", (140, 64)), ("btn_on", (140, 64)), ("tooltip", (200, 158))]:
        Image.open(f"art/ui/{n}.png").resize(size, Image.LANCZOS).save(f"art/ui/{n}_s.png")
    os.makedirs("art/bg", exist_ok=True)
    for code, name, width in [("ILL-01", "title", 1600), ("ILL-02", "loading", 1280), ("BG-01", "tree", 1280)]:
        im = Image.open(f"{SRC}/{code}.jpg").convert("RGB")
        im.resize((width, round(im.height * width / im.width)), Image.LANCZOS).save(f"art/bg/{name}.webp", quality=88)
    # os mapas da praça e da cripta já são 32-bit (tools/cut_pixel.py, MAPS)
    app_icons(f"{SRC}/ICN-02.jpg")
    circle(Image.open(f"{SRC}/ICN-01.jpg"), 128).save("art/ui/portrait_strider.png")  # o retrato é o do ícone antigo
    # cabeça do Guardião na vista de frente da folha de personagem
    chr1 = Image.open(f"{SRC}/CHR-01.jpg")
    k = chr1.width / 2000  # coordenadas medidas na folha vista a 2000 px de largura
    circle(keyed(chr1.crop((int(170 * k), int(25 * k), int(470 * k), int(325 * k)))), 128).save("art/ui/portrait_warden.png")
    # auto-verificação: todos os ficheiros esperados existem
    expected = [f"art/anim/player_{i}.png" for i in range(24)]
    expected += [f"art/anim/{n}_{i}.png" for n in ["skeleton", "colossus", "specter", "warden", "herald"] for i in range(16)]
    expected += [f"{j[2]}/{n}.png" for j in SHEETS for n in j[-1]]
    missing = [f for f in expected if not os.path.exists(f)]
    assert not missing, missing
    print("arte importada:", len(expected), "ficheiros")


if __name__ == "__main__":
    main()
