"""Prepara os zips para o GitHub, como no Zero-Sum: projeto.zip (código, sons, letra, configuração) e
arte_<grupo>.zip com a arte, cada um com menos de 9,5 MB (o envio pelo navegador aceita até 10 MB por ficheiro).
O Actions (tools/ci/build-apk.yml) descompacta os arte_*.zip e depois o projeto.zip por cima, e faz o APK.
Uso: python tools/make_release.py build/release
Nunca entram: .godot/, testes e capturas, tools/src/ (folhas originais do Gemini), build/, docs/ (plano e prompts),
chaves, nem CLAUDE.md.
"""
import os
import sys
import zipfile

LIMIT = 9_500_000
SKIP_DIRS = {".godot", ".git", "build", "tests", "docs"}
SKIP_FILES = {"CLAUDE.md"}
SKIP_EXT = {".pem", ".keystore", ".jks"}
# Pacotes de arte por pastas, para que um pacote só mude quando a sua arte muda
GROUPS = [
    ("animacoes", ["art/anim/"]),
    ("cenario", ["art/props/", "art/tiles/", "art/bg/"]),
    ("interface", ["art/"]),  # o resto: ui, ícones, árvore, efeitos, ícone da app e os sprites antigos
]


def project_files(root):
    for dirpath, dirnames, filenames in os.walk(root):
        rel = os.path.relpath(dirpath, root).replace("\\", "/")
        dirnames[:] = [d for d in dirnames if not (rel == "." and d in SKIP_DIRS) and not (rel == "tools" and d == "src")]
        for f in filenames:
            if f in SKIP_FILES or os.path.splitext(f)[1] in SKIP_EXT:
                continue
            arc = f if rel == "." else f"{rel}/{f}"
            yield os.path.join(dirpath, f), arc


def write_zip(path, entries):
    with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as z:
        for src, arc in entries:
            z.write(src, arc)
    size = os.path.getsize(path)
    assert size < 10_000_000, f"{path} tem {size} bytes: partir em mais pacotes"
    print(f"{os.path.basename(path)}: {len(entries)} ficheiros, {size / 1e6:.1f} MB")


def main(out):
    os.makedirs(out, exist_ok=True)
    for old in os.listdir(out):
        if old.endswith(".zip"):
            os.remove(os.path.join(out, old))
    files = sorted(project_files("."), key=lambda e: e[1])
    assert not any(os.path.basename(arc) == "CLAUDE.md" for _, arc in files)
    art = [e for e in files if e[1].startswith("art/")]
    write_zip(os.path.join(out, "projeto.zip"), [e for e in files if not e[1].startswith("art/")])
    taken = set()
    for name, prefixes in GROUPS:
        group = [e for e in art if e[1] not in taken and any(e[1].startswith(p) for p in prefixes)]
        taken.update(arc for _, arc in group)
        packs, cur, size = [], [], 0
        for e in group:  # um grupo grande demais parte-se em _1, _2...
            s = os.path.getsize(e[0])
            if cur and size + s > LIMIT:
                packs.append(cur)
                cur, size = [], 0
            cur.append(e)
            size += s
        if cur:
            packs.append(cur)
        for i, pack in enumerate(packs):
            suffix = f"_{i + 1}" if len(packs) > 1 else ""
            write_zip(os.path.join(out, f"arte_{name}{suffix}.zip"), pack)
    assert taken == {arc for _, arc in art}


if __name__ == "__main__":
    main(sys.argv[1] if len(sys.argv) > 1 else "build/release")
