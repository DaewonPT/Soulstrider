"""Recorta uma folha com fundo magenta em PNGs transparentes, um por item.
Uso:
  python tools/cut_sheet.py blob FOLHA PASTA MAX nome1 nome2 ...   # acha cada item pela mancha
  python tools/cut_sheet.py grid FOLHA PASTA MAX COLSxROWS nome1 ...  # célula inteira (efeitos alinhados)
  python tools/cut_sheet.py gridbox ...                                # célula cortada ao conteúdo
Os nomes seguem a ordem de leitura: linha a linha, da esquerda para a direita.
MAX = maior lado do PNG final em píxeis (0 = sem reduzir).
"""
import os
import sys
from collections import deque
from PIL import Image, ImageFilter

sys.path.insert(0, os.path.dirname(__file__))
from cut_sprites import key  # noqa: E402

STEP = 4


def keyed(src):
    im = Image.open(src).convert("RGB")
    rgba = Image.new("RGBA", im.size)
    rgba.putdata([key(p) for p in im.get_flattened_data()])
    return rgba


def shrink(img, mx):
    if mx and max(img.size) > mx:
        s = mx / max(img.size)
        img = img.resize((max(1, round(img.width * s)), max(1, round(img.height * s))), Image.LANCZOS)
    return img


def blobs(rgba, n_expected):
    alpha = rgba.getchannel("A").point(lambda a: 255 if a > 60 else 0).filter(ImageFilter.MaxFilter(9))
    w, h = rgba.size[0] // STEP, rgba.size[1] // STEP
    small = alpha.resize((w, h), Image.NEAREST).load()
    seen, found = set(), []
    for y in range(h):
        for x in range(w):
            if small[x, y] > 128 and (x, y) not in seen:
                q, box, count = deque([(x, y)]), [x, y, x, y], 0
                seen.add((x, y))
                while q:
                    cx, cy = q.popleft()
                    count += 1
                    box = [min(box[0], cx), min(box[1], cy), max(box[2], cx), max(box[3], cy)]
                    for nx, ny in ((cx + 1, cy), (cx - 1, cy), (cx, cy + 1), (cx, cy - 1)):
                        if 0 <= nx < w and 0 <= ny < h and small[nx, ny] > 128 and (nx, ny) not in seen:
                            seen.add((nx, ny))
                            q.append((nx, ny))
                found.append((count, [v * STEP for v in box]))
    # os n maiores são os itens; o resto é poeira de brilho
    found = [b for _, b in sorted(found, reverse=True)[:n_expected]]
    assert len(found) == n_expected, f"esperava {n_expected}, achei {len(found)}"
    # linhas: por ordem do topo, um item entra na linha atual se o seu centro ainda cabe nela
    lines = []
    for b in sorted(found, key=lambda b: b[1]):
        cy = (b[1] + b[3]) / 2
        if lines and cy <= max(o[3] for o in lines[-1]):
            lines[-1].append(b)
        else:
            lines.append([b])
    return [b for line in lines for b in sorted(line, key=lambda b: (round(b[0] / 60), b[1]))]


def main(mode, src, out, mx, *rest):
    mx = int(mx)
    rgba = keyed(src)
    os.makedirs(out, exist_ok=True)
    if mode in ("grid", "gridbox"):
        cols, rows = map(int, rest[0].split("x"))
        names = rest[1:]
        cw, ch = rgba.size[0] // cols, rgba.size[1] // rows
        boxes = [[c * cw, r * ch, (c + 1) * cw, (r + 1) * ch] for r in range(rows) for c in range(cols)]
    else:
        names = rest
        boxes = blobs(rgba, len(names))
    for name, b in zip(names, boxes):
        crop = rgba.crop((max(b[0] - 6, 0), max(b[1] - 6, 0), min(b[2] + STEP + 6, rgba.width), min(b[3] + STEP + 6, rgba.height)))
        if mode != "grid":  # "grid" guarda a célula inteira para os frames ficarem alinhados
            crop = crop.crop(crop.getbbox())
        crop = shrink(crop, mx)
        crop.save(f"{out}/{name}.png")
        print(name, b, crop.size)


if __name__ == "__main__":
    main(*sys.argv[1:])
