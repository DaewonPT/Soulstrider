"""Gera a música do jogo (Ogg Vorbis 32 kHz estéreo) sem assets externos: órgão de tubos, coro, cordas graves,
celesta, tímpanos e o sino do Arauto (o bell() de make_sfx.py). Todas as faixas partilham o Motivo do Sino.
Uso: python tools/make_music.py art/music [--preview PASTA]
Cada faixa é um laço exato: a partitura é misturada em círculo (as caudas dão a volta ao início), o eco da catedral
é aplicado a duas voltas seguidas e fica só a segunda, por isso o fim cola no início sem estalo.
Precisa do ffmpeg no PATH (a CI não: os .ogg vão no repositório). Mesma semente, mesmos bytes.
"""
import math
import os
import random
import re
import subprocess
import sys
import tempfile
import time
from array import array
from itertools import accumulate, islice, repeat
from multiprocessing import Pool
from operator import add, mul, sub

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import make_sfx  # noqa: E402

make_sfx.RATE = RATE = 32000  # o sino da música é o mesmo sino do Arauto, só que a 32 kHz
TN = 16384  # tabelas grandes: os graves do órgão têm centenas de harmónicos
MASK = TN - 1
SIN = array("f", (math.sin(2 * math.pi * i / TN) for i in range(TN)))
MOTIF = ((74, 1), (72, 1), (69, 2), (70, 1), (69, 3))  # Motivo do Sino: Ré-Dó-Lá-Si♭-Lá, em todas as faixas
# acorde: (fundamental do pedal, vozes de cima)
CH = {"Dm": (38, (57, 62, 65)), "Bb": (46, (58, 62, 65)), "F": (41, (57, 60, 65)), "C": (36, (55, 60, 64)),
      "Gm": (43, (55, 58, 62)), "A": (45, (57, 61, 64)), "A7": (45, (55, 61, 64)), "Eb": (39, (55, 58, 63))}
GAIN = {"organ": 0.16, "choir": 0.11, "strings": 0.3, "celesta": 0.35, "bell": 0.9, "timp": 0.22, "drum": 0.3,
        "thump": 0.25, "drip": 0.25, "wind": 0.3}


def hz(m):
    return 440.0 * 2 ** ((m - 69) / 12)


def osc(tab, f, n, ph=0.0, fm=None):
    # leitura da tabela com acumulador de fase, tudo em map() para correr à velocidade do C
    inc = f * TN / RATE
    incs = repeat(inc, n) if fm is None else map(mul, repeat(inc), fm)
    return array("f", map(tab.__getitem__, map(MASK.__and__, map(int, islice(accumulate(incs, initial=ph), n)))))


def lfo(n, rate, depth, ph):
    return map(add, repeat(1.0), map(mul, repeat(depth), osc(SIN, rate, n, ph)))


def decay(n, d):
    return array("f", islice(accumulate(repeat(math.exp(-d / RATE)), mul, initial=1.0), n))


def scale(a, g):
    return array("f", map(mul, a, repeat(g)))


def mix(a, b, gb=1.0):
    return array("f", map(add, a, map(mul, b, repeat(gb))))


def env(hold, att, rel):
    # subida e descida suaves (seno²), a descida parte do nível a que a nota chegou
    att = max(1, att)
    e = [math.sin(i / att * math.pi / 2) ** 2 for i in range(min(att, hold))] + [1.0] * (hold - att)
    top = e[-1] if e else 0.0
    return array("f", e + [top * math.cos(i / rel * math.pi / 2) ** 2 for i in range(rel)])


def table(harm, seed=0):
    rnd = random.Random(seed)
    t = [0.0] * TN
    for k, a in harm:
        p = rnd.randrange(TN)  # fases soltas: os tubos não estão em fase, a onda fica menos pontiaguda
        t = list(map(add, t, map(mul, repeat(a), map(SIN.__getitem__, map(MASK.__and__, range(p, p + k * TN, k))))))
    peak = max(map(abs, t))
    return array("f", (v / peak for v in t))


# órgão: registos = (múltiplo da nota escrita, volume, tubo); 0.5 = 16', 1 = 8', 2 = 4', 3 = 2 2/3', 4 = 2'...
PIPE = {"p": (1, 0.35, 0.18, 0.1, 0.05, 0.03), "f": (1, 0.02, 0.18, 0.01, 0.05), "r": tuple(1 / j ** 0.7 for j in range(1, 19))}
STOPS = {"soft": ((1, 1.0, "p"), (2, 0.4, "p")),
         "flute": ((1, 1.0, "f"), (2, 0.3, "f")),
         "full": ((0.5, 0.5, "p"), (1, 1.0, "p"), (2, 0.7, "p"), (3, 0.3, "p"), (4, 0.4, "p"), (6, 0.2, "p"), (8, 0.15, "p")),
         "reed": ((0.5, 0.5, "p"), (1, 0.8, "p"), (1, 0.9, "r"), (2, 0.6, "p"), (3, 0.25, "p"), (4, 0.35, "p"), (6, 0.2, "p")),
         "pedal": ((0.5, 1.0, "f"), (1, 0.6, "p"), (2, 0.2, "p"))}
TABS = {}


def organ_tabs(stop, m):
    if (stop, m) not in TABS:
        f2 = hz(m) / 2
        low, high = {}, {}
        for mult, a, kind in STOPS[stop]:
            for j, h in enumerate(PIPE[kind], 1):
                k = round(2 * mult * j)  # em múltiplos de f/2
                if k * f2 < 11000:
                    side = low if mult <= 1 else high
                    side[k] = side.get(k, 0.0) + a * h * (1.0 if k * f2 < 3000 else 3000 / (k * f2))
        TABS[stop, m] = (table(sorted(low.items()), m), table(sorted(high.items()), m + 1) if high else None)
    return TABS[stop, m]


def organ(m, hold, stop):
    rel = int(0.22 * RATE)
    n = hold + rel
    low, high = organ_tabs(stop, m)
    rnd = random.Random(m)
    a = osc(low, hz(m) / 2, n, rnd.random() * TN)
    # as fileiras de cima ficam 1,5 cêntimos acima: o batimento lento é o que faz soar a tubos e não a sintetizador
    b = osc(high, hz(m) / 2 * 2 ** (1.5 / 1200), n, rnd.random() * TN) if high else a
    e = env(hold, int(0.045 * RATE), rel)
    chiff = [0.0] * n  # sopro do tubo ao falar
    lp = 0.0
    for i in range(min(n, int(0.04 * RATE))):
        lp += (rnd.uniform(-1, 1) - lp) * 0.3
        chiff[i] = lp * 0.25 * (1 - i / (0.04 * RATE))
    left = array("f", map(add, map(mul, mix(scale(a, 0.62), b, 0.38), e), chiff))
    right = array("f", map(add, map(mul, mix(scale(a, 0.62), b, 0.5), e), chiff))
    return left, right


# coro: harmónicos da glote (1/k) filtrados pelos formantes da vogal (ressoadores em cascata)
VOWELS = {"ah": ((800, 80), (1150, 90), (2900, 120), (3900, 130), (4950, 140)),
          "oo": ((350, 40), (600, 60), (2700, 100), (3800, 120), (4950, 120))}


def choir(m, hold, var):
    vowel, att = var
    f = hz(m)
    if (vowel, m) not in TABS:
        harm = []
        for k in range(1, int(7000 / f) + 1):
            g = 1.0 / k
            for F, B in VOWELS[vowel]:
                g *= F * F / math.sqrt((F * F - (k * f) ** 2) ** 2 + (k * f * B) ** 2)
            harm.append((k, g))
        TABS[vowel, m] = table(harm, m)
    tab = TABS[vowel, m]
    rel = int(1.6 * RATE)
    n = hold + rel
    rnd = random.Random(m * 7 + len(vowel))
    left, right = array("f", bytes(4 * n)), array("f", bytes(4 * n))
    for cents, gl, gr in ((-7, 0.85, 0.4), (0, 0.62, 0.62), (7, 0.4, 0.85)):
        # três cantores por nota, cada um com o seu vibrato e a sua deriva lenta
        fm = map(mul, lfo(n, rnd.uniform(4.8, 6.0), 0.0028, rnd.random() * TN), lfo(n, rnd.uniform(0.13, 0.31), 0.0012, rnd.random() * TN))
        s = osc(tab, f * 2 ** ((cents + rnd.uniform(-2, 2)) / 1200), n, rnd.random() * TN, fm)
        left, right = mix(left, s, gl), mix(right, s, gr)
    e = env(hold, int(att * RATE), rel)
    return array("f", map(mul, left, e)), array("f", map(mul, right, e))


def strings(m, hold, art):
    # serra limitada em banda, mais escura nos graves; dois naipes desafinados com vibrato
    f = hz(m)
    bright = 3500 if art == "marc" else 2200
    if ("saw", m, bright) not in TABS:
        TABS["saw", m, bright] = table([(k, math.exp(-k * f / bright) / k) for k in range(1, int(10000 / f) + 1)], m)
    tab = TABS["saw", m, bright]
    att, rel = {"marc": (0.012, 0.12), "pad": (0.35, 0.5), "slow": (1.5, 2.0), "drone": (3.0, 3.0)}[art]
    rel = int(rel * RATE)
    n = hold + rel
    rnd = random.Random(m + 3)
    left, right = array("f", bytes(4 * n)), array("f", bytes(4 * n))
    for cents, gl, gr in ((-6, 0.8, 0.45), (6, 0.45, 0.8)):
        s = osc(tab, f * 2 ** (cents / 1200), n, rnd.random() * TN, lfo(n, rnd.uniform(5.2, 6.0), 0.0015, rnd.random() * TN))
        left, right = mix(left, s, gl), mix(right, s, gr)
    e = env(hold, int(att * RATE), rel)
    if art == "marc":
        e = array("f", map(mul, e, decay(n, 3.0)))
    return array("f", map(mul, left, e)), array("f", map(mul, right, e))


def celesta(m, hold, var):
    f = hz(m)
    n = int(2.8 * RATE)
    out = array("f", bytes(4 * n))
    for r, a, d in ((1, 1.0, 1.4), (2, 0.18, 3.0), (3, 0.05, 5.0), (4.16, 0.03, 9.0)):
        out = mix(out, array("f", map(mul, osc(SIN, f * r, n), decay(n, d))), a)
    for i in range(64):  # martelo de feltro: 2 ms de subida
        out[i] *= i / 64
    return out, out


def bell(m, hold, far):
    out = array("f", make_sfx.bell(6.0 if m < 60 else 4.0, hz(m)))
    if far == "far":  # sino ao longe: perde os agudos
        lp = 0.0
        for i, v in enumerate(out):
            lp += (v - lp) * 0.35
            out[i] = lp
    return out, out


def timp(m, hold, var):
    # modos de uma pele afinada; o tom cai um pouco logo após a pancada
    rnd = random.Random(var)
    n = int(2.5 * RATE)
    f = hz(m)
    out = array("f", bytes(4 * n))
    glide = decay(n, 25.0)
    for r, a, d in ((1.0, 1.0, 2.2), (1.5, 0.7, 3.2), (1.99, 0.5, 4.5), (2.44, 0.35, 6.0), (2.89, 0.25, 7.5)):
        fm = map(add, repeat(1.0), map(mul, repeat(0.03), glide))
        out = mix(out, array("f", map(mul, osc(SIN, f * r, n, rnd.random() * TN, fm), decay(n, d))), a)
    lp = 0.0
    for i in range(int(0.04 * RATE)):  # baqueta
        lp += (rnd.uniform(-1, 1) - lp) * 0.5
        out[i] += lp * 0.8 * (1 - i / (0.04 * RATE))
    return out, out


def drum(m, hold, var):
    # tambor abafado de cortejo: pele de ruído e corpo a 185 Hz
    rnd = random.Random(var)
    n = int(0.5 * RATE)
    body = array("f", map(mul, osc(SIN, 185, n, rnd.random() * TN), decay(n, 30.0)))
    out, lo, hi = array("f", bytes(4 * n)), 0.0, 0.0
    for i in range(n):
        x = rnd.uniform(-1, 1)
        hi += (x - hi) * 0.5
        lo += (x - lo) * 0.08
        out[i] = (hi - lo) * math.exp(-22 * i / RATE) + 0.6 * body[i]
    return out, out


def thump(m, hold, var):
    # batida de coração: um baque grave com o tom a descer; os harmónicos deixam-na ouvir-se num telemóvel
    n = int(0.6 * RATE)
    if "thump" not in TABS:
        TABS["thump"] = table(((1, 1.0), (2, 0.5), (3, 0.3), (4, 0.15)))
    fm = map(add, repeat(1.0), map(mul, repeat(0.4), decay(n, 30.0)))
    out = array("f", map(mul, osc(TABS["thump"], hz(m), n, 0.0, fm), decay(n, 9.0)))
    return out, out


def drip(m, hold, var):
    # gota: 40 ms de seno a subir
    rnd = random.Random(var)
    n = int(0.12 * RATE)
    up = rnd.uniform(0.3, 0.7)
    fm = map(sub, repeat(1.0 + up), map(mul, repeat(up), decay(n, 40.0)))
    out = array("f", map(mul, osc(SIN, hz(m), n, 0.0, fm), decay(n, 45.0)))
    for i in range(32):
        out[i] *= i / 32
    return out, out


def wind(m, hold, seed):
    # vento: ruído filtrado em duas bandas com ondulações que dão voltas inteiras ao laço
    rnd = random.Random(seed)
    chans = []
    for ch in range(2):
        noise = array("f", (rnd.uniform(-1, 1) for _ in range(hold)))
        k1, k2, p1, p2 = rnd.randint(5, 9), rnd.randint(3, 6), rnd.random() * 6.3, rnd.random() * 6.3
        a = b = c = 0.0
        for x in noise[-RATE:]:  # aquecer o filtro com o fim: a amostra 0 continua a última
            a += (x - a) * 0.03
            b += (x - b) * 0.12
            c += (x - c) * 0.06
        out = array("f", bytes(4 * hold))
        for i, x in enumerate(noise):
            a += (x - a) * 0.03
            b += (x - b) * 0.12
            c += (x - c) * 0.06
            ph = 2 * math.pi * i / hold
            out[i] = a * (0.6 + 0.4 * math.sin(k1 * ph + p1)) + (b - c) * (0.5 + 0.5 * math.sin(k2 * ph + p2)) ** 2
        chans.append(out)
    return chans[0], chans[1]


VOICES = {"organ": organ, "choir": choir, "strings": strings, "celesta": celesta, "bell": bell, "timp": timp,
          "drum": drum, "thump": thump, "drip": drip, "wind": wind}


# ---- partituras: (tempo em batidas desde o início, batidas, voz, variante, nota MIDI, força, pan) ----

def line(e, at, notes, voice, var, vel, pan=0.0, shift=0):
    for m, d in notes:
        if m:
            e.append((at, d, voice, var, m + shift, vel, pan))
        at += d
    return at


def chord(e, at, beats, name, voice, var, vel, spread=0.5, shift=0):
    for k, m in enumerate(CH[name][1]):
        e.append((at, beats, voice, var, m + shift, vel, (k - 1) * spread))


def score_title(rnd):
    # "Réquiem do Coveiro": coral de órgão; na segunda metade entra o coro e o órgão pleno
    e = []
    mel = ((69, 2), (67, 1), (65, 1), (65, 2), (62, 2), (65, 1), (67, 1), (69, 2), (67, 4),
           (70, 2), (69, 1), (67, 1), (65, 2), (69, 2), (67, 1), (65, 1), (64, 2), (62, 4))
    for i, c in enumerate(["Dm", "Bb", "F", "C", "Gm", "Dm", "A", "Dm"] * 2):
        at, full = i * 4, i >= 8
        e.append((at, 4, "organ", "pedal", CH[c][0], 0.9, 0.0))
        chord(e, at, 4, c, "organ", "full" if full else "soft", 0.6 if full else 0.75, 0.25)
        if full:
            chord(e, at, 4, c, "choir", ("ah", 0.6), 0.45)
            e.append((at, 4, "strings", "pad", CH[c][0] + 12, 0.7, -0.3))
    line(e, 0, mel, "organ", "flute", 0.55, 0.2, 12)
    line(e, 32, mel, "choir", ("ah", 0.25), 0.9, 0.0, 12)
    line(e, 32, mel, "organ", "flute", 0.35, 0.2, 12)
    line(e, 0, MOTIF, "bell", "near", 0.45, 0.35)
    line(e, 32, MOTIF, "bell", "near", 0.5, -0.35)
    e += [(0, 8, "bell", "far", 50, 0.7, -0.5), (32, 8, "bell", "far", 50, 0.7, 0.5)]
    return e


def score_world(rnd):
    # "Vigília no Cemitério": drone de cordas, celesta só em metade dos compassos, sino ao longe, vento
    e = []
    blocks = (("Dm", 8), ("Bb", 4), ("Gm", 4), ("Dm", 8), ("A", 4), ("Dm", 4))
    plan = [c for c, k in blocks for _ in range(k)]
    for b in range(0, 32, 8):  # no bloco de Lá o drone larga o Ré, que chocaria com o Dó#
        e += [(b * 4, 32, "strings", "drone", 33 if b == 24 else 38, 0.4, -0.3), (b * 4, 32, "strings", "drone", 45, 0.32, 0.3)]
    b = 0
    for c, k in blocks:  # cordas graves a seguir a harmonia, devagar
        chord(e, b * 4, k * 4, c, "strings", "slow", 0.28, 0.6, -12)
        b += k
    for b, m, pan in ((0, 62, -0.6), (8, 62, 0.6), (16, 62, -0.6), (24, 57, 0.6)):
        e.append((b * 4, 8, "bell", "far", m, 0.5, pan))
    for b in (8, 24):
        chord(e, b * 4, 16, plan[b], "choir", ("oo", 3.0), 0.32, 0.7)
    for b in (4, 12, 20, 28):  # celesta: a semente escolhe o fragmento de cada bloco de 4 compassos
        shift = 5 if plan[b] == "Gm" else 0
        at, pan = b * 4 + rnd.choice((0, 1)), rnd.uniform(-0.4, 0.4)
        kind = "motivo" if b == 4 else rnd.choice(("motivo", "eco", "arpejo"))  # o primeiro bloco é sempre o Motivo do Sino
        if kind == "motivo":
            rhythm = rnd.choice(((1, 1, 2, 1, 3), (2, 1, 1, 2, 2), (1.5, 0.5, 2, 1, 3)))
            at = line(e, at, [(m, d) for (m, _), d in zip(MOTIF, rhythm)], "celesta", 0, 0.5, pan, shift)
            line(e, at + 2, MOTIF[-2:], "celesta", 0, 0.32, -pan, shift - 12)
        elif kind == "eco":
            line(e, at, MOTIF[:3], "celesta", 0, 0.5, pan, shift)
            line(e, at + 6, MOTIF[:3], "celesta", 0, 0.32, -pan, shift - 12)
        else:
            tones = [m + 12 for m in CH[plan[b]][1]]
            notes = tones + [tones[0] + 12] + tones[::-1]
            for m in notes:
                d = rnd.choice((1, 1, 2))
                e.append((at, d, "celesta", 0, m, rnd.uniform(0.35, 0.5), pan))
                at += d
                if at >= (b + 4) * 4 - 1:
                    break
    e.append((0, 128, "wind", rnd.randrange(1000), 0, 1.0, 0.0))
    return e


def score_crypt(rnd):
    # "Os Que Não Descansam": pedal em Ré, coro "oo" entre Ré menor e Mi bemol (frígio), gotas e um coração
    e = []
    low = {"Dm": (50, 53, 57), "Eb": (51, 55, 58), "Gm": (50, 55, 58)}
    for i, c in enumerate(["Dm", "Eb", "Dm", "Gm", "Eb"]):
        at = i * 16
        e += [(at, 16, "organ", "pedal", 38, 0.7, 0.0), (at, 16, "strings", "drone", 38, 0.5, -0.2)]
        for k, m in enumerate(low[c]):
            e.append((at, 16, "choir", ("oo", 2.5), m, 0.45, (k - 1) * 0.6))
    for bar in range(2, 18):
        for beat in (0, 2):
            e += [(bar * 4 + beat, 1, "thump", 0, 33, 0.5, 0.0), (bar * 4 + beat + 0.25, 1, "thump", 1, 31, 0.35, 0.0)]
    t = rnd.uniform(0, 2)
    while t < 79:
        e.append((t, 1, "drip", rnd.randrange(4), rnd.randint(90, 97), rnd.uniform(0.3, 0.6), rnd.uniform(-0.8, 0.8)))
        t += rnd.uniform(1.5, 3.5)
    line(e, 32, MOTIF, "bell", "far", 0.5, 0.3, -12)
    line(e, 48, MOTIF[:3], "celesta", 0, 0.25, -0.4, -12)
    return e


def score_cortejo(rnd):
    # "Marcha Fúnebre": tímpanos no 1 e no 3, ostinato Ré-Ré-Fá-Mi nas cordas, sino no 1.º de cada 4 compassos
    e = []
    plan = (["Dm", "Gm", "A", "Dm"] * 2 + ["Bb", "Gm", "A7", "Dm"] * 2) * 2
    shape = {"Dm": (0, 0, 3, 2), "Gm": (0, 0, 3, 2), "A": (0, 0, 4, 2), "A7": (0, 0, 4, 2), "Bb": (0, 0, 4, 2)}
    base = {"Dm": 50, "Gm": 43, "A": 45, "A7": 45, "Bb": 46}
    timp = {"Dm": 38, "Gm": 38, "A": 33, "A7": 33, "Bb": 38}
    for i, c in enumerate(plan):
        at, late = i * 4, i >= 16
        e.append((at, 4, "organ", "pedal", CH[c][0], 0.8, 0.0))
        chord(e, at, 4, c, "organ", "full" if late else "soft", 0.55 if late else 0.6, 0.3)
        if late:
            chord(e, at, 4, c, "choir", ("ah", 0.4), 0.42)
        e += [(at, 1, "timp", i % 3, timp[c], 1.0, -0.15), (at + 2, 1, "timp", 3 + i % 2, timp[c], 0.7, -0.15)]
        for k in range(8):
            e.append((at + k * 0.5, 0.5, "strings", "marc", base[c] + shape[c][k % 4], 1.1 if k % 4 == 0 else 0.8, 0.3))
        if i % 4 == 0:
            e.append((at, 4, "bell", "near", 62, 0.55, -0.45))
        if i % 4 == 3:  # rufo abafado no fim da frase
            for k in range(8):
                e.append((at + 3 + k * 0.125, 0.125, "drum", k % 4, 0, 0.25 + 0.08 * k, 0.2))
    for b in (16, 20, 24, 28):
        line(e, b * 4, MOTIF, "choir", ("ah", 0.15), 0.85, 0.0)
        line(e, b * 4, MOTIF, "organ", "flute", 0.4, 0.25, 12)
    line(e, 8 * 4, MOTIF, "organ", "flute", 0.45, 0.25)
    return e


def score_boss(rnd):
    # "O Arauto Fúnebre": 2 compassos de drone e rufo (os sinos do Arauto tocam por cima), depois tudo em Ré menor harmónico
    e = []
    cycle = ["Dm", "Bb", "Gm", "A", "Dm", "Eb", "A", "Dm"]
    e += [(0, 8, "organ", "pedal", 38, 0.8, 0.0), (0, 8, "strings", "pad", 38, 0.7, -0.2), (0, 8, "strings", "pad", 45, 0.6, 0.2)]
    for k in range(32):
        e.append((k * 0.25, 0.25, "timp", k % 5, 33, 0.25 + 0.6 * k / 32, 0.1))
    roots = {"Dm": 38, "Bb": 46, "Gm": 43, "A": 45, "Eb": 39}
    for i in range(30):
        c = cycle[i % 8]
        at = (i + 2) * 4
        e.append((at, 4, "organ", "pedal", CH[c][0], 1.0, 0.0))
        chord(e, at, 4, c, "organ", "reed" if i >= 16 else "full", 0.6, 0.3)
        chord(e, at, 4, c, "choir", ("ah", 0.2), 0.6)
        r = roots[c]
        for k, off in enumerate((0, 0, 12, 0, -1, 0, 3, 0)):
            e.append((at + k * 0.5, 0.5, "strings", "marc", r + off, 1.1 if k % 2 == 0 else 0.8, 0.25))
        tr = 38 if c in ("Dm", "Bb", "Gm") else 33
        for k in range(8):
            e.append((at + k * 0.5, 0.5, "timp", k % 5, tr if k % 2 == 0 else (33 if tr == 38 else 38), (1.0, 0.45, 0.7, 0.45, 0.9, 0.45, 0.7, 0.6)[k], -0.15))
        if i % 8 == 0:
            e.append((at, 4, "bell", "near", 62, 0.7, -0.4))
    for i in (2, 10, 18, 26):  # o motivo sobre Sol menor → Lá: o Si♭ contra o Lá maior é a nona menor do Arauto
        at = (i + 2) * 4
        line(e, at, MOTIF, "choir", ("ah", 0.08), 0.95, 0.0)
        line(e, at, MOTIF, "organ", "reed", 0.45, 0.2)
        if i >= 10:
            line(e, at, MOTIF, "bell", "near", 0.4, 0.4)
    return e


# id: (partitura, BPM, compassos, RT60 do eco, eco vs. som direto, LUFS, compasso onde começa a prévia)
TRACKS = {"title": (score_title, 60, 16, 3.2, 0.8, -18.0, 7),
          "world": (score_world, 60, 32, 3.5, 0.95, -20.0, 5),
          "crypt": (score_crypt, 50, 20, 4.5, 1.0, -20.0, 7),
          "cortejo": (score_cortejo, 80, 32, 2.6, 0.65, -18.0, 15),
          "boss": (score_boss, 120, 32, 2.0, 0.55, -18.0, 1)}


def impulse(rt60, wet, seed):
    # eco de catedral estéreo: reflexões iniciais + cauda de ruído que escurece (os agudos morrem duas vezes mais depressa)
    n = int(RATE * (rt60 + 0.3))
    pre = int(0.025 * RATE)
    chans = []
    for ch in range(2):
        rnd = random.Random(seed * 2 + ch)
        out, lp = array("f", bytes(4 * n)), 0.0
        for i in range(pre, n):
            t = (i - pre) / RATE
            x = rnd.gauss(0, 1)
            lp += (x - lp) * 0.22
            out[i] = (x * 0.35 * 10 ** (-3 * t / (rt60 * 0.45)) + lp * 10 ** (-3 * t / rt60)) * min(1.0, t / 0.06)
        for _ in range(6):
            out[pre + rnd.randrange(int(0.06 * RATE))] += rnd.uniform(0.3, 0.6) * rnd.choice((-1, 1)) * 8
        chans.append(out)
    energy = math.sqrt(sum(v * v for c in chans for v in c) / 2)
    for c in chans:
        for i in range(n):
            c[i] *= wet / energy
        c[0] += 1.0  # o som direto
    return chans


def interleave(left, right):
    out = array("f", bytes(8 * len(left)))
    out[0::2], out[1::2] = left, right
    return out


def ffmpeg(args, data=None):
    kw = {"input": data} if data is not None else {"stdin": subprocess.DEVNULL}
    p = subprocess.run(["ffmpeg", "-hide_banner", "-y", *args], capture_output=True, **kw)
    assert p.returncode == 0, p.stderr.decode(errors="replace")[-2000:]
    return p


RAW = ["-f", "f32le", "-ar", str(RATE), "-ac", "2"]
ENC = ["-c:a", "libvorbis", "-q:a", "2", "-map_metadata", "-1", "-fflags", "+bitexact", "-flags:a", "+bitexact"]


def loudness(path_or_raw):
    args = ["-i", path_or_raw] if isinstance(path_or_raw, str) else [*RAW, "-i", "-"]
    err = ffmpeg([*args, "-af", "ebur128=peak=true", "-f", "null", "-"], None if isinstance(path_or_raw, str) else path_or_raw).stderr.decode()
    summary = err[err.rfind("Summary:"):]
    return float(re.search(r"I:\s+(-?[\d.]+) LUFS", summary).group(1)), float(re.search(r"Peak:\s+(-?[\d.inf]+) dBFS", summary).group(1))


def build(job):
    tid, seed, out_path, preview = job
    t0 = time.time()
    score, bpm, bars, rt60, wet, lufs, pbar = TRACKS[tid]
    spb = RATE * 60 // bpm
    n = spb * 4 * bars
    left, right = array("f", bytes(4 * n)), array("f", bytes(4 * n))
    human = random.Random(seed)
    cache = {}
    for at, beats, voice, var, m, vel, pan in score(random.Random(seed + 100)):
        hold = int(beats * spb)
        key = (voice, var, m, hold)
        if key not in cache:
            cache[key] = VOICES[voice](m, hold, var)
        sl, sr = cache[key]
        start = int(at * spb)
        if voice != "wind":  # mão humana: ±8 ms e ±10% de força, sempre da mesma semente
            start += int(max(-0.008, min(0.008, human.gauss(0, 0.004))) * RATE)
            vel *= 1 + human.uniform(-0.1, 0.1)
        g = vel * GAIN[voice]
        for mixb, sig, gp in ((left, sl, math.cos((pan + 1) * math.pi / 4)), (right, sr, math.sin((pan + 1) * math.pi / 4))):
            i, pos = 0, start % n
            while i < len(sig):  # em círculo: a cauda que passa do fim entra no início
                k = min(len(sig) - i, n - pos)
                mixb[pos:pos + k] = array("f", map(add, mixb[pos:pos + k], map(mul, sig[i:i + k], repeat(g * gp * math.sqrt(2)))))
                i, pos = i + k, 0
    dry = interleave(left, right).tobytes()
    with tempfile.TemporaryDirectory() as tmp:
        ir = os.path.join(tmp, "ir.f32")
        with open(ir, "wb") as fh:
            fh.write(interleave(*impulse(rt60, wet, seed)).tobytes())
        # duas voltas seguidas pelo eco; a segunda já traz a cauda da primeira, por isso fecha o laço
        wet_raw = ffmpeg(["-filter_threads", "1", *RAW, "-i", "-", *RAW, "-i", ir, "-filter_complex",
                          f"[0:a]highpass=f=32,bass=g=-4:f=90,lowpass=f=11500[d];[d][1:a]afir=gtype=none:irnorm=-1,atrim=start_sample={n}:end_sample={2 * n}",
                          *RAW, "-"], dry + dry).stdout
    assert len(wet_raw) == 8 * n, (tid, len(wet_raw), 8 * n)
    i_lufs, tp = loudness(wet_raw)
    gain_db = min(lufs - i_lufs, -1.5 - tp)  # nunca acima de -1,5 dBTP
    final = array("f")
    final.frombytes(wet_raw)
    final = scale(final, 10 ** (gain_db / 20))
    pcm = array("f", final)
    for _ in range(4):
        ffmpeg([*RAW, "-i", "-", *ENC, out_path], pcm.tobytes())
        dec = decode(out_path)
        jump, near = seam(dec)
        if jump <= near:
            break
        # o Vorbis inventa o que vem depois do fim (extrapolação) e o fim descodificado desvia-se devagar até ~0,03;
        # mede-se esse desvio lento nos últimos 128 ms e tira-se ao PCM, para o fim voltar a colar no início
        w = 4096
        for c in (0, 1):
            drift = 0.0
            for k, i in enumerate(range(2 * (n - w) + c, 2 * n, 2)):
                drift += (dec[i] - final[i] - drift) * 0.05
                pcm[i] -= min(1.0, k / (w / 2)) * drift
    if preview:  # 20 s para ouvir no telemóvel, com entrada e saída suaves
        a = (pbar - 1) * 4 * spb
        clip = array("f", (final * 2)[2 * a:2 * a + 2 * 20 * RATE])
        fade = 2 * RATE
        for i in range(len(clip) // 2):
            g = min(1.0, i / (0.5 * RATE), (len(clip) // 2 - i) / fade)
            clip[2 * i] *= g
            clip[2 * i + 1] *= g
        ffmpeg([*RAW, "-i", "-", *ENC, preview + ".ogg"], clip.tobytes())
        ffmpeg([*RAW, "-i", "-", "-c:a", "libmp3lame", "-q:a", "4", "-map_metadata", "-1", "-fflags", "+bitexact", preview + ".mp3"], clip.tobytes())
    return tid, seed, out_path, n, time.time() - t0


def decode(path):
    dec = array("f")
    dec.frombytes(ffmpeg(["-i", path, *RAW, "-"]).stdout)
    return dec


def seam(dec):
    # salto da última amostra para a primeira contra o maior salto normal nos 50 ms de cada lado
    w = int(0.05 * RATE)
    jump = max(abs(dec[-2 + c] - dec[c]) for c in (0, 1))
    near = max(abs(dec[i + 2] - dec[i]) for i in [*range(len(dec) - 2 * w, len(dec) - 2), *range(0, 2 * w - 2)])
    return jump, near


def check(path):
    # duração, tamanho, loudness e a costura do laço, já depois do Vorbis
    dur = float(subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", path], capture_output=True, text=True).stdout)
    dec = decode(path)
    jump, near = seam(dec)
    i_lufs, tp = loudness(path)
    return dur, len(dec) // 2, os.path.getsize(path), i_lufs, tp, jump, near


if __name__ == "__main__":
    t0 = time.time()
    out = sys.argv[1]
    prev = sys.argv[sys.argv.index("--preview") + 1] if "--preview" in sys.argv else None
    os.makedirs(out, exist_ok=True)
    jobs = [(tid, 1, f"{out}/{tid}.ogg", prev and f"{prev}/{tid}") for tid in TRACKS]
    if prev:
        os.makedirs(prev, exist_ok=True)
        jobs.append(("world", 2, f"{prev}/world_2_completa.ogg", f"{prev}/world_2"))  # segunda semente, para escolher de ouvido
    with Pool(len(jobs)) as pool:
        done = pool.map(build, jobs)
    total = 0
    print(f"{'faixa':<10}{'semente':>8}{'duração':>10}{'alvo':>9}{'KB':>7}{'LUFS':>7}{'dBTP':>7}{'costura':>9}{'vizinha':>9}{'s':>6}")
    for tid, seed, path, n, secs in done:
        dur, frames, size, i_lufs, tp, jump, near = check(path)
        if seed == 1:
            total += size
        print(f"{tid:<10}{seed:>8}{dur:>10.3f}{n / RATE:>9.3f}{size // 1024:>7}{i_lufs:>7.1f}{tp:>7.1f}{jump:>9.4f}{near:>9.4f}{secs:>6.0f}")
        # auto-verificação: comprimento exato, sem estalo na costura, sem clipping
        assert abs(dur - n / RATE) <= 0.03 and frames == n, (tid, dur, frames, n)
        assert jump <= max(near, 0.002), (tid, jump, near)
        assert tp <= -1.0, (tid, tp)
    print(f"total {total / 1e6:.2f} MB em {time.time() - t0:.0f} s")
    assert total <= 4_500_000
