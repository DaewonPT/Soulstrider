"""Gera os sons de impacto (WAV mono 22 kHz) sem assets externos.
Uso: python tools/make_sfx.py sfx
hit = baque grave + estalo de osso; crit = o mesmo mais forte com um "ring" agudo; hurt = baque abafado;
bell = sino do Arauto; roar = rugido do chefe; boss = música de chefe em laço; chest = baú a abrir; levelup = subir de nível.
"""
import math
import os
import random
import struct
import sys
import wave

RATE = 22050


def render(dur, f0, f1, noise, crack, ring=0.0, seed=1):
    rnd = random.Random(seed)
    out, phase, lp = [], 0.0, 0.0
    n = int(dur * RATE)
    for i in range(n):
        t = i / RATE
        k = i / n
        phase += 2 * math.pi * (f0 + (f1 - f0) * min(1.0, t / 0.08)) / RATE
        body = math.sin(phase) * math.exp(-t * 18)  # baque com o tom a cair
        lp += (rnd.uniform(-1, 1) - lp) * 0.35  # ruído filtrado = carne/pano
        s = body + lp * noise * math.exp(-t * 30)
        if t < 0.025:
            s += rnd.uniform(-1, 1) * crack * (1 - t / 0.025)  # estalo inicial
        s += ring * math.sin(2 * math.pi * 1650 * t) * math.exp(-t * 14)
        out.append(s * (1 - k) ** 0.5)
    peak = max(abs(v) for v in out)
    return [v / peak * 0.9 for v in out]


def bell(dur=3.0, f0=150.0):
    # parciais inarmónicos de sino, cada um a morrer ao seu ritmo
    parts = [(0.5, 0.6, 0.9), (1.0, 1.0, 1.3), (1.19, 0.6, 1.8), (1.56, 0.45, 2.4), (2.0, 0.5, 2.8), (2.51, 0.3, 3.6), (3.0, 0.2, 4.5)]
    rnd = random.Random(4)
    out = []
    for i in range(int(dur * RATE)):
        t = i / RATE
        s = sum(a * math.sin(2 * math.pi * f0 * r * t) * math.exp(-t * d) for r, a, d in parts)
        if t < 0.01:
            s += rnd.uniform(-1, 1) * (1 - t / 0.01)
        out.append(s)
    return norm(out)


def roar(dur=1.6):
    rnd = random.Random(5)
    out, lp, phase = [], 0.0, 0.0
    for i in range(int(dur * RATE)):
        t = i / RATE
        env = min(1.0, t / 0.2) * min(1.0, (dur - t) / 0.5)
        lp += (rnd.uniform(-1, 1) - lp) * 0.08
        phase += 2 * math.pi * (75 - 25 * t / dur) / RATE
        growl = 0.6 + 0.4 * math.sin(2 * math.pi * 26 * t)
        out.append((lp * 3.0 * growl + 0.5 * math.sin(phase)) * env)
    return norm(out)


def drone(dur=4.0):
    # laço de 4 s: todas as frequências dão voltas inteiras para o loop não estalar
    out = []
    for i in range(int(dur * RATE)):
        t = i / RATE
        trem = 0.75 + 0.25 * math.sin(2 * math.pi * 0.5 * t)
        beat = t % 1.0
        thump = math.sin(2 * math.pi * 48 * beat) * math.exp(-beat * 9)
        s = (math.sin(2 * math.pi * 55 * t) + 0.6 * math.sin(2 * math.pi * 82.5 * t) + 0.3 * math.sin(2 * math.pi * 110 * t)) * trem
        out.append(s * 0.5 + thump * 0.8)
    return norm(out, 0.7)


def chime(notes, gap, dur, thump=False):
    out = []
    for i in range(int(dur * RATE)):
        t = i / RATE
        s = 0.0
        for n, f in enumerate(notes):
            dt = t - n * gap
            if dt >= 0:
                s += (math.sin(2 * math.pi * f * dt) + 0.3 * math.sin(4 * math.pi * f * dt)) * math.exp(-dt * 5)
        if thump:
            s += 1.5 * math.sin(2 * math.pi * (120 - 60 * min(1.0, t / 0.1)) * t) * math.exp(-t * 14)
        out.append(s)
    return norm(out)


def norm(out, level=0.9):
    peak = max(abs(v) for v in out)
    return [v / peak * level for v in out]


def save(path, samples):
    with wave.open(path, "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(RATE)
        w.writeframes(b"".join(struct.pack("<h", int(v * 32767)) for v in samples))


if __name__ == "__main__":
    out = sys.argv[1]
    os.makedirs(out, exist_ok=True)
    save(f"{out}/hit.wav", render(0.16, 190, 70, 0.9, 0.8, seed=1))
    save(f"{out}/crit.wav", render(0.32, 240, 55, 1.1, 1.2, ring=0.35, seed=2))
    save(f"{out}/hurt.wav", render(0.2, 120, 50, 0.6, 0.2, seed=3))
    save(f"{out}/bell.wav", bell())
    save(f"{out}/roar.wav", roar())
    save(f"{out}/boss.wav", drone())
    save(f"{out}/chest.wav", chime([880, 1320, 1760, 2640], 0.06, 1.4, thump=True))
    save(f"{out}/levelup.wav", chime([523, 659, 784, 1047], 0.09, 1.3))
    # auto-verificação: todos os ficheiros não vazios
    assert all(os.path.getsize(f"{out}/{n}.wav") > 1000 for n in ("hit", "crit", "hurt", "bell", "roar", "boss", "chest", "levelup"))
    print("ok")
