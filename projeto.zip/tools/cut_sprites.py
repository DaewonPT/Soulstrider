"""Recorta a folha de sprites (fundo magenta) em PNGs transparentes.
Uso: python tools/cut_sprites.py tools/src/sheet.jpg art
Os sprites são nomeados pela ordem de leitura (linha a linha, esquerda->direita) em NAMES.
"""
import sys
from collections import deque
from PIL import Image, ImageChops, ImageFilter

NAMES = ["player", "skeleton", "specter", "colossus", "tomb", "crypt", "tree", "monument",
         "bone", "ink", "ash", "orb"]
STEP = 4  # resolução da grelha usada para achar as manchas


def key(px):
    r, g, b = px
    m = min(r, b) - g  # quão "magenta" é o pixel
    a = 1.0 - min(1.0, max(0.0, (m - 35) / 70))
    if m > 0:  # tira o reflexo rosa das bordas
        r, b = int(r - m * (1 - a * 0.3)), int(b - m * (1 - a * 0.3))
    return (max(r, 0), g, max(b, 0), int(a * 255))


def main(src, out):
    im = Image.open(src).convert("RGB")
    rgba = Image.new("RGBA", im.size)
    rgba.putdata([key(p) for p in im.get_flattened_data()])
    alpha = rgba.getchannel("A").filter(ImageFilter.MaxFilter(9))
    w, h = im.size[0] // STEP, im.size[1] // STEP
    small = alpha.resize((w, h), Image.NEAREST).load()
    seen, blobs = set(), []
    for y in range(h):
        for x in range(w):
            if small[x, y] > 128 and (x, y) not in seen:
                q, box, cells = deque([(x, y)]), [x, y, x, y], []
                seen.add((x, y))
                while q:
                    cx, cy = q.popleft()
                    cells.append((cx, cy))
                    box = [min(box[0], cx), min(box[1], cy), max(box[2], cx), max(box[3], cy)]
                    for nx, ny in ((cx + 1, cy), (cx - 1, cy), (cx, cy + 1), (cx, cy - 1)):
                        if 0 <= nx < w and 0 <= ny < h and small[nx, ny] > 128 and (nx, ny) not in seen:
                            seen.add((nx, ny))
                            q.append((nx, ny))
                if len(cells) > 40:  # ignora ruído
                    blobs.append([v * STEP for v in box] + [cells])
    assert len(blobs) == len(NAMES), f"esperava {len(NAMES)} sprites, achei {len(blobs)}: {blobs}"
    # Agrupa por linhas usando o centro vertical do topo
    lines = []
    for b in sorted(blobs, key=lambda b: b[1]):
        for line in lines:
            if abs(line[0][1] - b[1]) < 90:
                line.append(b)
                break
        else:
            lines.append([b])
    ordered = [b for line in lines for b in sorted(line, key=lambda b: b[0])]
    for name, b in zip(NAMES, ordered):
        box = (max(b[0] - 4, 0), max(b[1] - 4, 0), min(b[2] + STEP + 4, im.size[0]), min(b[3] + STEP + 4, im.size[1]))
        # só os pixels desta mancha, para não puxar pedaços dos vizinhos
        mask = Image.new("L", (w, h))
        for c in b[4]:
            mask.putpixel(c, 255)
        mask = mask.resize(im.size, Image.NEAREST).filter(ImageFilter.MaxFilter(5))
        sprite = rgba.copy()
        sprite.putalpha(ImageChops.multiply(rgba.getchannel("A"), mask))
        crop = sprite.crop(box)
        crop = crop.crop(crop.getbbox())
        crop.save(f"{out}/{name}.png")
        print(name, box, crop.size)


if __name__ == "__main__":
    main(sys.argv[1], sys.argv[2])
