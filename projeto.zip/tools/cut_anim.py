"""Recorta uma folha de animação 4x2 (fundo magenta) em 8 frames PNG alinhados.
Uso: python tools/cut_anim.py FOLHA SAIDA ESCALA [PRIMEIRO_INDICE]
  ESCALA = altura do frame 1 em píxeis (ex.: 228), ou "x0.47" para uma escala fixa.
Cada frame leva as manchas cujo centro cai na sua célula, por isso o que o Gemini deixou passar
para a célula vizinha (uns pés, um rasto de luz) não suja o frame do lado.
Os frames de uma folha ficam todos do mesmo tamanho, centrados na célula. main() devolve
(escala, pés): para cada frame, os píxeis entre o fundo da imagem e a linha dos pés, sem contar
brilhos verdes/ciano, para o jogo assentar a personagem no chão em vez de a deixar flutuar.
"""
import os
import sys
from collections import deque
from PIL import Image, ImageChops, ImageFilter

sys.path.insert(0, os.path.dirname(__file__))
from cut_sprites import key  # noqa: E402

COLS, ROWS = 4, 2
STEP = 4  # resolução da grelha usada para achar as manchas


def _components(mask):
    """Manchas ligadas numa máscara pequena: lista de listas de (x, y)."""
    w, h = mask.size
    px = mask.load()
    seen = set()
    out = []
    for y in range(h):
        for x in range(w):
            if px[x, y] and (x, y) not in seen:
                q = deque([(x, y)])
                seen.add((x, y))
                cells = []
                while q:
                    cx, cy = q.popleft()
                    cells.append((cx, cy))
                    for nx, ny in ((cx + 1, cy), (cx - 1, cy), (cx, cy + 1), (cx, cy - 1)):
                        if 0 <= nx < w and 0 <= ny < h and px[nx, ny] and (nx, ny) not in seen:
                            seen.add((nx, ny))
                            q.append((nx, ny))
                out.append(cells)
    return out


def _glow(r, g, b):
    """Luz verde ou ciano (magia, rastos, chamas de alma), mesmo a mais fraca das bordas."""
    return g > 90 and (g * 10 > r * 13 or (b > 120 and r < 120))


def _feet(frame):
    """Píxeis do fundo da imagem até ao ponto mais baixo do corpo (ignora brilhos e magia)."""
    w, h = frame.size
    data = frame.getdata()
    for y in range(h - 1, -1, -1):
        for x in range(w):
            r, g, b, a = data[y * w + x]
            if a > 128 and not _glow(r, g, b):
                return h - 1 - y
    return 0


def main(src, out, size, first=0, grounded=True, mirror=False):
    im = Image.open(src).convert("RGB")
    rgba = Image.new("RGBA", im.size)
    rgba.putdata([key(p) for p in im.get_flattened_data()])
    W, H = im.size
    cw, ch = W // COLS, H // ROWS
    alpha = rgba.getchannel("A")
    small = alpha.point(lambda a: 255 if a > 60 else 0).filter(ImageFilter.MaxFilter(5))
    small = small.resize((W // STEP, H // STEP), Image.NEAREST)

    def cell_of(x, y):
        return min(ROWS - 1, y * STEP // ch) * COLS + min(COLS - 1, x * STEP // cw)

    owner = [[] for _ in range(COLS * ROWS)]
    for cells in _components(small):
        if len(cells) < 12:
            continue  # pó solto
        xs = [c[0] for c in cells]
        ys = [c[1] for c in cells]
        if (max(xs) - min(xs)) * STEP > 1.2 * cw or (max(ys) - min(ys)) * STEP > 1.2 * ch:
            for c in cells:  # mancha que atravessa várias células: divide pela grelha
                owner[cell_of(*c)].append(c)
        else:
            owner[cell_of((min(xs) + max(xs)) // 2, (min(ys) + max(ys)) // 2)].extend(cells)

    frames, boxes = [], []
    for i, cells in enumerate(owner):
        m = Image.new("L", small.size)
        for c in cells:
            m.putpixel(c, 255)
        m = m.resize(im.size, Image.NEAREST).filter(ImageFilter.MaxFilter(5))
        f = rgba.copy()
        f.putalpha(ImageChops.multiply(alpha, m))
        b = f.getchannel("A").point(lambda a: 255 if a > 128 else 0).getbbox()
        assert b, f"{src}: frame {i + 1} vazio"
        r, c = divmod(i, COLS)
        frames.append(f)
        boxes.append((b[0] - c * cw, b[1] - r * ch, b[2] - c * cw, b[3] - r * ch))
    # meia-largura simétrica em volta do centro da célula, para o sprite não "saltar" entre frames
    half = max(max(cw / 2 - b[0], b[2] - cw / 2) for b in boxes)
    top, bottom = min(b[1] for b in boxes), max(b[3] for b in boxes)
    s = float(size[1:]) if str(size).startswith("x") else int(size) / (boxes[0][3] - boxes[0][1])
    os.makedirs(os.path.dirname(out), exist_ok=True)
    feet = []
    for i, f in enumerate(frames):
        r, c = divmod(i, COLS)
        ox, oy = c * cw, r * ch
        f = f.crop((int(ox + cw / 2 - half), oy + top, int(ox + cw / 2 + half), oy + bottom))
        f = f.resize((max(1, round(f.width * s)), max(1, round(f.height * s))), Image.LANCZOS)
        if mirror:  # o Gemini desenhou esta folha virada para o outro lado
            f = f.transpose(Image.Transpose.FLIP_LEFT_RIGHT)
        f.save(f"{out}_{int(first) + i}.png")
        feet.append(_feet(f) if grounded else 0)
    print(out, first, f.size, "escala %.3f" % s, "pés", feet)
    return s, feet


if __name__ == "__main__":
    main(*sys.argv[1:])
