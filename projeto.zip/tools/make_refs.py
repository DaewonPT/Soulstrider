"""Imagens de referência para o Gemini (docs/referencias/): cada conversa nova do Gemini começa sem memória,
por isso cada parte dos prompts leva anexadas as personagens já aprovadas, no estilo final e à escala certa.
As 32-bit saem das folhas aprovadas do Gemini (tools/src/PX-xx), recortadas como no tools/cut_pixel.py e
postas à escala certa umas das outras (como no jogo), viradas para a direita, sobre magenta. As que ainda não têm 32-bit (o Colosso e
o Arauto) vão com os desenhos pintados, só para o design. As folhas pintadas do mundo, efeitos, ícones e
interface vão copiadas com o nome de sempre.
Uso: python -I tools/make_refs.py
"""
import os
import shutil
import sys

from PIL import Image, ImageFilter

sys.path.insert(0, os.path.dirname(__file__))
from cut_anim import _feet  # noqa: E402
from cut_pixel import SHEETS, SRC, TARGET, frames_of  # noqa: E402

OUT = "docs/referencias"
MAGENTA = (255, 0, 255, 255)
SCALE = 8


def sheet(frames, cols, name, scale=SCALE, w=None):
    """frames = [(imagem RGBA, pés)] -> uma folha 16:9 em magenta, todos com os pés na mesma linha por fila."""
    big = [(im.resize((im.width * scale, im.height * scale), Image.NEAREST), feet * scale) for im, feet in frames]
    rows = (len(big) + cols - 1) // cols
    cell_w = max(b.width for b, _ in big) + 64
    cell_h = max(b.height for b, _ in big) + 80
    w = w or max(cols * cell_w, int(rows * cell_h * 16 / 9))
    h = max(rows * cell_h, int(w * 9 / 16))
    out = Image.new("RGBA", (w, h), MAGENTA)
    pad_x = (w - cols * cell_w) // 2
    pad_y = (h - rows * cell_h) // 2
    for k, (b, feet) in enumerate(big):
        r, c = divmod(k, cols)
        x = pad_x + c * cell_w + (cell_w - b.width) // 2
        base = pad_y + (r + 1) * cell_h - 40  # linha dos pés da fila
        out.alpha_composite(b, (x, base - b.height + int(feet)))
    out.convert("RGB").save(f"{OUT}/{name}")
    print(name, out.size)


_cuts = {}


def orig(picks, px_per=7):
    """[(folha, frame 1-8)] -> recortes das folhas aprovadas, com a personagem de pé a TARGET x px_per píxeis."""
    res = []
    for code, n in picks:
        _, out, first, body, blank, *opt = next(sh for sh in SHEETS if sh[0] == code)
        path = f"{SRC}/{code}.png" if os.path.exists(f"{SRC}/{code}.png") else f"{SRC}/{code}.jpg"
        if code not in _cuts:
            _cuts[code] = (frames_of(path, blank, opt[0] if opt else {}), Image.open(path).height)
        frames, h = _cuts[code]
        rgb, a = frames[n - 1]
        im = rgb.convert("RGBA")
        im.putalpha(a.filter(ImageFilter.MinFilter(3)))
        k = TARGET[out] * px_per / (body * h)
        im = im.resize((round(im.width * k), round(im.height * k)), Image.NEAREST)
        res.append((im, _feet(im)))
    return res


def painted(name, idxs, mirror, height):
    res = []
    for i in idxs:
        im = Image.open(f"art/anim/{name}_{i}.png").convert("RGBA")
        im = im.crop(im.getbbox())
        im = im.resize((int(im.width * height / im.height), height), Image.LANCZOS)
        res.append((im.transpose(Image.Transpose.FLIP_LEFT_RIGHT) if mirror else im, 0))
    return res


def draft(code, name, k=4, colors=64):
    """Rascunho pixelizado de um mapa pintado, a k x k píxeis por píxel de arte: o Gemini, com o mapa pintado
    anexado, devolveu-o quase igual; partindo deste rascunho fica com a grelha de píxeis e o lugar de tudo."""
    src = Image.open(f"tools/src/{code}.jpg").convert("RGB")
    sm = src.resize((src.width // k, src.height // k), Image.BOX)
    q = sm.quantize(colors=colors, method=Image.Quantize.MAXCOVERAGE, kmeans=3, dither=Image.Dither.NONE)
    q.resize((sm.width * k, sm.height * k), Image.NEAREST).save(f"{OUT}/{name}")
    print(name)


def main():
    os.makedirs(OUT, exist_ok=True)
    # Elenco: as quatro personagens aprovadas lado a lado, ao tamanho relativo do jogo
    sheet(orig([("PX-03", 1), ("PX-09", 1), ("PX-15", 1), ("PX-17", 1)]), 4, "REF-01-elenco.png", scale=1)
    sheet(orig([("PX-03", 1), ("PX-01", 3), ("PX-02", 4), ("PX-05", 5), ("PX-06", 6), ("PX-52", 5)]), 3, "REF-02-ceifeiro.png", scale=1)
    sheet(orig([("PX-09", 1), ("PX-07", 3), ("PX-08", 4), ("PX-11", 5), ("PX-12", 7), ("PX-53", 5)]), 3, "REF-03-guardiao.png", scale=1)
    sheet(orig([("PX-15", 1), ("PX-13", 3), ("PX-14", 4), ("PX-15", 5), ("PX-16", 3), ("PX-16", 8)]), 3, "REF-04-esqueleto.png", scale=1)
    sheet(orig([("PX-17", 1), ("PX-17", 3), ("PX-17", 5), ("PX-17", 7)]), 4, "REF-05-espectro.png", scale=1)
    sheet(orig([("PX-23", 1), ("PX-21", 2), ("PX-22", 3), ("PX-24", 3)], 3), 4, "REF-06-colosso.png", scale=1)
    sheet(orig([("PX-26", 1), ("PX-25", 4), ("PX-26", 3), ("PX-27", 5)], 3), 4, "REF-07-arauto.png", scale=1)
    # Os desenhos pintados de que partiram (para refazer alguma folha deles com o design original)
    sheet(painted("colossus", [0, 4, 8], True, 900), 3, "REF-06-colosso-pintado.png", scale=1)
    sheet(painted("herald", [0, 4, 8], True, 900), 3, "REF-07-arauto-pintado.png", scale=1)
    # Folhas pintadas que as partes do mundo, efeitos, ícones, interface e intro redesenham
    for code in ["MAP-01", "MAP-02", "TIL-01", "PRP-01", "PRP-02", "PRP-03", "VFX-01", "VFX-02",
                 "ICO-01", "ICO-02", "ICO-03", "ICO-04", "UI-01", "UI-02", "ILL-01", "ILL-02", "BG-01"]:
        shutil.copy(f"tools/src/{code}.jpg", f"{OUT}/{code}.jpg")
    print("pintadas copiadas")
    # Mundo 32-bit aprovado (Parte 5) e o que falta redesenhar nesse estilo
    shutil.copy(f"{SRC}/PX-29.png", f"{OUT}/REF-08-chao-32bit.png")
    shutil.copy(f"{SRC}/PX-31.png", f"{OUT}/REF-09-aderecos-32bit.png")
    old = [Image.open(f"art/{n}.png").convert("RGBA") for n in ["tree", "tomb", "crypt"]]
    sheet([(im.resize((im.width * 700 // im.height, 700), Image.LANCZOS), 0) for im in old], 3, "REF-10-pintados.png", scale=1)
    draft("MAP-01", "MAP-01-rascunho.png")
    draft("MAP-02", "MAP-02-rascunho.png")


if __name__ == "__main__":
    main()
