"""Confere as traduções: cada texto que o jogador vê nos scripts tem de ter inglês em i18n.gd,
com os mesmos %d/%s pela mesma ordem. Sai com erro e a lista do que falta.
Uso: python -I tools/check_i18n.py
"""
import glob
import os
import re
import sys

ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..")
LIT = re.compile(r'"((?:[^"\\]|\\.)*)"')
PAIR = re.compile(r'"((?:[^"\\]|\\.)*)"\s*:\s*"((?:[^"\\]|\\.)*)"')
SPEC = re.compile(r"%[-+0#]*\d*(?:\.\d+)?[sdif%]")  # sem o espaço: "+30% sangramento" não é um formato
SKIP_FILES = {"i18n.gd", "app_update.gd", "gothic.gd"}
# Textos que ficam iguais nas duas línguas (nomes, números, formatos) ou que não são para o jogador
SAME = {
    "Soulstrider", "Soulstrider ", "Necro-Dominion", "Soulstrider: Necro-Dominion", "Strider", "Bleed & Bone",
    "Português", "English", "60", "PanelContainer", "Button", "HSlider", "Update", "Master", "Musica", "Efeitos",
    ".tmp", "%d!", "%d FPS", "%d%%", "%s — %s", "%s: %s", "%s\\n%s", "%s — %s%s", "%d %s", "+%d", "%s x%d",
    "skill_%d", "mailto:contact@pixellusitano.com", "Godot Engine\\n", "\\n\\nPirata One\\n", "\\n• %s: %s (%s)",
    "\\n", "\\n\\n", "  — ", "  ", "pt_PT", "en_GB", "en",
}


def ui_strings():
    for path in sorted(glob.glob(os.path.join(ROOT, "*.gd"))):
        name = os.path.basename(path)
        if name in SKIP_FILES:
            continue
        for n, line in enumerate(open(path, encoding="utf-8"), 1):
            if line.lstrip().startswith("#"):
                continue
            for s in LIT.findall(line.split(" #")[0]):
                core = s.strip()
                if s.startswith(("res://", "user://", "http", "@", "p2_", "ui_")) or not re.search(r"[A-Za-zÀ-ú]", s):
                    continue
                if re.fullmatch(r"[a-z0-9_]+", core) and core not in ("nenhum", "caído", "habilidades", "interagir", "poções", "menu"):
                    continue  # ids, ações, chaves de dicionário
                if s in SAME or core in SAME:
                    continue
                yield name, n, s, core


def main():
    en = {}
    for line in open(os.path.join(ROOT, "i18n.gd"), encoding="utf-8"):
        for k, v in PAIR.findall(line):
            en[k] = v
    missing, bad = [], []
    for name, n, s, core in ui_strings():
        key = s if s in en else core
        if key not in en:
            missing.append(f"{name}:{n}: {s!r}")
    for k, v in en.items():
        if SPEC.findall(k) != SPEC.findall(v):
            bad.append(f"{k!r} -> {v!r}")
    for m in missing:
        print("SEM TRADUÇÃO", m)
    for b in bad:
        print("FORMATOS DIFERENTES", b)
    print(f"{len(en)} traduções, {len(missing)} em falta, {len(bad)} com formatos diferentes")
    sys.exit(1 if missing or bad else 0)


if __name__ == "__main__":
    main()
