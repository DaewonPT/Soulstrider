"""Personagens do SpriteCook (tools/src/sc/) -> frames 32-bit do jogo (art/anim/<nome>32_N.png + feet32.gd).
Cada personagem tem um desenho-base (base_<nome>.png) e folhas de animação em tira (<nome>_<anim>.png, frames
quadrados lado a lado). O SpriteCook devolve cada animação à sua escala e com margens diferentes: o 1.º frame
é a pose do desenho-base, por isso dá a escala (altura igual à do base) e o encaixe (caixa alinhada pela
esquerda e por baixo). Todos os frames vão para uma tela comum por personagem, com o meio do corpo no meio da
tela e o chão na última linha (os pés ficam a 0). feet32.gd também leva a escala de cada personagem no jogo
(SCALE: altura de pé no ecrã base / altura do desenho-base).
Uso: python -I tools/import_spritecook.py
"""
import os

from PIL import Image

SRC = "tools/src/sc"
OUT = "art/anim"
TARGET = {"strider": 73, "warden": 80, "skeleton": 60, "specter": 58, "colossus": 174, "herald": 180}  # de pé, em píxeis do ecrã base
## Por personagem: (animação, primeiro frame no jogo, quais frames da tira usar). None = todos.
## "down": ferido, de joelhos / caído e a reerguer-se (o 1.º frame da tira é a pose parada, fica de fora).
ANIMS = {
    "strider": [("walk", 0, None), ("attack", 8, None), ("idle", 16, None), ("down", 24, [1, 2, 3, 4, 5, 5, 6, 7]),
                ("lance", 32, None), ("nova", 40, None), ("dodge", 48, None)],
    "warden": [("walk", 0, None), ("attack", 8, None), ("idle", 16, None), ("down", 24, [1, 3, 4, 5, 5, 6, 7, 7]),
               ("cleave", 32, None), ("armor", 40, None), ("dodge", 48, None)],
    "skeleton": [("walk", 0, None), ("attack", 8, None), ("idle", 16, None), ("hurt", 20, None), ("death", 24, None)],
    "specter": [("walk", 0, None), ("attack", 8, None), ("walk", 16, [0, 2, 4, 6]), ("hurt", 20, None), ("death", 24, None)],  # parado = metade do flutuar
    "colossus": [("walk", 0, None), ("attack", 8, None), ("idle", 16, None), ("hurt", 20, None), ("death", 24, None)],
    "herald": [("walk", 0, None), ("attack", 8, None), ("summon", 16, None), ("death", 24, None)],
}
FLOATS = {"specter"}  # sem chão: encaixa pelo fundo do desenho


def _frames(path):
    sheet = Image.open(path).convert("RGBA")
    fw = sheet.height
    frames = [sheet.crop((i * fw, 0, (i + 1) * fw, fw)) for i in range(sheet.width // fw)]
    if sheet.getchannel("A").getextrema()[0] == 255:  # gerada sem tirar o fundo: tira-o aqui
        frames = [_key(f) for f in frames]
    return frames


def _key(f, tol=18):
    """Fundo liso (cinzento) ligado às bordas -> transparente. A remoção automática do SpriteCook comia partes
    escuras (a capa do Guardião, o manto do Arauto); estas animações vêm com o fundo e recortam-se aqui."""
    w, h = f.size
    px = f.load()
    bg = px[0, 0]
    near = lambda c: abs(c[0] - bg[0]) <= tol and abs(c[1] - bg[1]) <= tol and abs(c[2] - bg[2]) <= tol
    seen = set()
    todo = [(x, y) for x in range(w) for y in (0, h - 1)] + [(x, y) for y in range(h) for x in (0, w - 1)]
    while todo:
        x, y = todo.pop()
        if (x, y) in seen or not (0 <= x < w and 0 <= y < h) or not near(px[x, y]):
            continue
        seen.add((x, y))
        px[x, y] = (0, 0, 0, 0)
        todo += [(x + 1, y), (x - 1, y), (x, y + 1), (x, y - 1)]
    # bolsos de fundo presos entre o machado, as pernas e a capa: só a cor exata do fundo (a arte usa outros cinzentos)
    for y in range(h):
        for x in range(w):
            c = px[x, y]
            if c[3] and abs(c[0] - bg[0]) <= 2 and abs(c[1] - bg[1]) <= 2 and abs(c[2] - bg[2]) <= 2:
                px[x, y] = (0, 0, 0, 0)
    return f


def _alpha_box(im, cut=100):
    return im.getchannel("A").point(lambda a: 255 if a > cut else 0).getbbox()


def _body_x(im, box):
    """Meio do corpo: a média das colunas com desenho no quarto de baixo (pés / fundo do manto), sem a arma."""
    x0, y0, x1, y1 = box
    a = im.getchannel("A").point(lambda v: 255 if v > 100 else 0)
    low = a.crop((x0, y1 - max(2, (y1 - y0) // 4), x1, y1))
    cols = [x for x in range(low.width) if low.crop((x, 0, x + 1, low.height)).getbbox()]
    return x0 + (cols[0] + cols[-1]) / 2.0 if cols else (x0 + x1) / 2.0


def character(name):
    base = Image.open(f"{SRC}/base_{name}.png").convert("RGBA")
    bb = _alpha_box(base)
    base_h = bb[3] - bb[1]
    ax = _body_x(base, bb) - bb[0]  # meio do corpo, contado da esquerda da caixa do base
    placed = {}  # índice no jogo -> (imagem já à escala do base, x do meio do corpo, y do chão)
    for anim, first, pick in ANIMS[name]:
        frames = _frames(f"{SRC}/{name}_{anim}.png")
        f0 = _alpha_box(frames[0])
        k = base_h / (f0[3] - f0[1])
        for j, i in enumerate(pick or range(len(frames))):
            f = frames[i]
            f = f.resize((round(f.width * k), round(f.height * k)), Image.Resampling.LANCZOS if abs(k - 1.0) > 0.02 else Image.Resampling.NEAREST)
            placed[first + j] = (f, f0[0] * k + ax, f0[3] * k)
    # Tela comum: o meio do corpo ao meio, o chão em baixo
    left = right = top = 0.0
    for f, cx, gy in placed.values():
        b = _alpha_box(f, 20)
        if b:
            left, right, top = max(left, cx - b[0]), max(right, b[2] - cx), max(top, gy - b[1])
    half = int(max(left, right)) + 2
    h = int(top) + 2
    feet = []
    for i in sorted(placed):
        f, cx, gy = placed[i]
        out = Image.new("RGBA", (2 * half, h))
        out.alpha_composite(f, (round(half - cx), round(h - gy)))
        out.save(f"{OUT}/{name}32_{i}.png")
        feet.append(0)
    assert sorted(placed) == list(range(len(placed))), f"{name}: faltam frames"
    return feet, TARGET[name] / base_h, (2 * half, h)


def main():
    feet, scale = {}, {}
    for name in ANIMS:
        if not os.path.exists(f"{SRC}/base_{name}.png"):
            continue
        feet[name + "32"], scale[name + "32"], size = character(name)
        print(name, len(feet[name + "32"]), "frames", size, "escala %.3f" % scale[name + "32"])
    with open(f"{OUT}/feet32.gd", "w", encoding="utf-8") as fh:
        fh.write("# Gerado por tools/import_spritecook.py — não editar à mão.\n")
        fh.write("## Pés dos frames 32-bit (píxeis da textura entre o fundo e a linha dos pés) e a escala de cada\n")
        fh.write("## personagem no jogo (altura de pé no ecrã base / altura do desenho).\n")
        fh.write("const FEET := {\n")
        for n, d in feet.items():
            fh.write('\t"%s": %s,\n' % (n, d))
        fh.write("}\nconst SCALE := {\n")
        for n, s in scale.items():
            fh.write('\t"%s": %.4f,\n' % (n, s))
        fh.write("}\n")


if __name__ == "__main__":
    main()
