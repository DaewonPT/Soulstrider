extends Node
## Co-op por Wi-Fi (rede local). O anfitrião corre o jogo todo com o seu herói; o convidado fica com o outro:
## manda os seus comandos e desenha o mundo que recebe (a cada frame só o que mudou, a cada segundo tudo).
## Autoload: a ligação sobrevive ao recomeçar da cena (morte, Erguer-se).

const AppUpdate := preload("res://app_update.gd")
const PORT := 24680
const FIND_PORT := 24681  # o anfitrião anuncia a sala por broadcast UDP a cada segundo
const TAG := "SOULSTRIDER"
const FULL_T := 1.0  # de quanto em quanto tempo vai tudo (repara o que se perdeu pelo caminho)
const PACKET := 1100  # bytes por pacote não fiável (o MTU do ENet é 1392)
const SYNCED := ["res://player.gd", "res://enemy.gd", "res://ally.gd", "res://loot.gd", "res://bolt.gd",
	"res://chest.gd", "res://tomb.gd", "res://fx.gd", "res://decoy.gd"]
const LOCAL := "res://fx.gd"  # efeitos: chegam uma vez e o convidado anima-os sozinho
const BASE := ["position", "visible", "modulate", "z_index"]
const SKIP := ["held", "touch_move", "lock_skills", "parts", "shape", "alpha"]  # os botões do convidado são dele; os efeitos refazem as partículas e a forma da semente (e a opacidade é a dele)
const TYPES := [TYPE_BOOL, TYPE_INT, TYPE_FLOAT, TYPE_STRING, TYPE_VECTOR2, TYPE_COLOR, TYPE_ARRAY, TYPE_DICTIONARY]
const MAIN_KEYS := ["level", "xp", "currency", "weapon", "flasks", "tomb", "cortejo", "circle", "circle_max", "wins", "crypt_rule", "map_circle", "zone", "arena_r", "rumble",
	"shake", "zoom_kick", "focus_t", "focus_pos", "guardian_met", "time", "kills", "teeth", "blood", "corpses", "sentinels", "track", "paused", "relics",
	"breath_end", "tide_next", "tide_dir", "rocks", "hammers", "trial", "eclipse_next", "eclipse_end", "tide_start",
	"event", "event_next", "mausoleum", "floor_end", "curses", "deep", "sanctum_rule", "camps_done"]  # crypt_rule e map_circle vão antes da zona: o convidado pinta a cripta já com a cor da sala
const TAPS := 3  # bits 3..5: Invocar/interagir, poção de vida, poção de alma
const ASKS := ["allocate", "cycle_support", "use_currency", "set_support", "set_soul", "respec", "forge_until"]  # o que o convidado pode pedir (Árvore, Arsenal e Forja)

var role := ""  # "" sem rede, "joining", "host", "guest"
var main  # a cena do jogo, quando existe
var guest_id := 0  # anfitrião: o peer do convidado
var guest_ready := false
var host_paused := false  # convidado: o anfitrião está num menu (o jogo dele parou)
var rooms := {}  # convidado à procura: ip -> {"level", "t"}
var beacon := PacketPeerUDP.new()
var finder := PacketPeerUDP.new()
var beacon_t := 0.0
var full_t := 0.0
var props := {}  # script -> nomes dos campos que viajam
var next_id := 1
var sent := {}  # anfitrião: id -> valores enviados
var sent_main := []
var nodes := {}  # convidado: id -> nó
var last_bits := 0
var dodge_t := 0.0  # convidado: a esquiva segue para o anfitrião durante uns frames, com a direção
var dodge_dir := Vector2.ZERO
var stance_t := 0.0  # convidado: o toque na postura segue durante uns frames
var trans_t := 0.0  # convidado: e o de libertar a Alma Transitória (#4), no bit 512
var asks := []  # convidado: o que fazer quando chega cada resposta do anfitrião (por ordem)
var taps := [0.0, 0.0, 0.0]


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	process_priority = 100  # depois do jogo: envia o frame já simulado
	multiplayer.peer_connected.connect(_peer_in)
	multiplayer.peer_disconnected.connect(_peer_out)
	multiplayer.connected_to_server.connect(func(): _hello.rpc_id(1, AppUpdate.VERSION_CODE))
	multiplayer.connection_failed.connect(func(): _lost("Não foi possível entrar na sala."))
	multiplayer.server_disconnected.connect(func(): _lost("A ligação ao anfitrião perdeu-se."))


func is_guest() -> bool:
	return role == "guest"


func host() -> Error:
	close()
	var peer := ENetMultiplayerPeer.new()
	var err := peer.create_server(PORT, 1)
	if err != OK:
		return err
	multiplayer.multiplayer_peer = peer
	role = "host"
	beacon.set_broadcast_enabled(true)
	beacon.set_dest_address("255.255.255.255", FIND_PORT)
	return OK


func join(ip: String) -> Error:
	close()
	var peer := ENetMultiplayerPeer.new()
	var err := peer.create_client(ip, PORT)
	if err != OK:
		return err
	multiplayer.multiplayer_peer = peer
	role = "joining"
	return OK


func close() -> void:
	if multiplayer.multiplayer_peer is ENetMultiplayerPeer:
		multiplayer.multiplayer_peer.close()
	multiplayer.multiplayer_peer = null
	role = ""
	guest_id = 0
	guest_ready = false
	host_paused = false
	beacon.close()
	stop_scan()
	sent.clear()
	nodes.clear()
	asks.clear()  # o que ficou por responder: ao voltar a entrar, as respostas iam para os pedidos errados


func scan() -> void:
	if not finder.is_bound():
		finder.bind(FIND_PORT)


func stop_scan() -> void:
	finder.close()
	rooms.clear()


func my_ip() -> String:
	for a in IP.get_local_addresses():
		if a.begins_with("192.168.") or a.begins_with("10.") or a.begins_with("172."):
			return a
	return "127.0.0.1"


## A cena do jogo chama isto no fim do _ready (também depois de recomeçar).
func attach(m) -> void:
	main = m
	if role == "guest":
		_guest_in.rpc_id(1)
	elif role == "host" and guest_ready:
		_add_guest()
		_reset.rpc_id(guest_id)


## Convidado: pede ao anfitrião uma mudança da Árvore ou do Arsenal (who = slot do herói, -1 = o jogo);
## after(resultado) corre quando a resposta chega, já com o jogo mudado.
func ask(who: int, method: String, args: Array, after: Callable) -> void:
	asks.append(after)
	_ask.rpc_id(1, who, method, args)


## Convidado: esquiva (B, botão do ecrã ou deslizar o dedo); quem a faz é o anfitrião.
func dodge(dir: Vector2) -> void:
	dodge_t = 0.15
	dodge_dir = dir


## Convidado: o toque num botão do ecrã (Invocar, poções) segue para o anfitrião durante uns frames.
func tap(i: int) -> void:
	taps[i] = 0.15


## Convidado: trocar de postura (Guarda ↔ Ira); quem troca é o anfitrião.
func stance() -> void:
	stance_t = 0.15


## Convidado: libertar a Alma Transitória (#4); quem a liberta é o anfitrião.
func trans() -> void:
	trans_t = 0.15


func _process(delta: float) -> void:
	if finder.is_bound():
		while finder.get_available_packet_count() > 0:
			var msg := finder.get_packet().get_string_from_utf8().split("|")
			if msg.size() == 3 and msg[0] == TAG and int(msg[1]) == AppUpdate.VERSION_CODE:
				rooms[finder.get_packet_ip()] = {"level": int(msg[2]), "t": Time.get_ticks_msec()}
		for ip in rooms.keys():
			if Time.get_ticks_msec() - rooms[ip].t > 3500:
				rooms.erase(ip)
	if not is_instance_valid(main):
		return
	if role == "host":
		beacon_t -= delta
		if guest_id == 0 and beacon_t <= 0.0:
			beacon_t = 1.0
			beacon.put_packet(("%s|%d|%d" % [TAG, AppUpdate.VERSION_CODE, main.level]).to_utf8_buffer())
		if guest_ready:
			_send(delta)
	elif role == "guest" and is_instance_valid(main.player):
		var p = main.player
		var move: Vector2 = p.touch_move if p.touch_move != Vector2.ZERO else Input.get_vector("move_left", "move_right", "move_up", "move_down")
		var bits := 0
		for i in 3:
			if Input.is_action_pressed("skill_%d" % (i + 1)) or p.held.get(p.order[i], false):
				bits |= 1 << i
		if p.auto_attack() and not main.trial_on("lamina"):  # na Lâmina Cega (#214) o golpe automático não sai
			bits |= 1
		if main.settings.boss_aim:
			bits |= 64
		if Input.is_action_just_pressed("interact") and Engine.get_process_frames() > main.hud.closed_frame:  # B: o mesmo que no anfitrião
			main.interact() if main.hud.hint_action != "" else dodge(move)
		for i in TAPS:
			taps[i] -= delta
			if taps[i] > 0.0 or (i > 0 and Input.is_action_pressed(["interact", "potion_hp", "potion_mp"][i])):
				bits |= 1 << (3 + i)
		dodge_t -= delta
		if dodge_t > 0.0:
			bits |= 128
		stance_t -= delta
		if stance_t > 0.0 or Input.is_action_just_pressed("stance"):
			bits |= 256
		trans_t -= delta
		if trans_t > 0.0:
			bits |= 512
		_input_in.rpc_id(1, move, bits, dodge_dir)


# ---------- Anfitrião ----------

## Os campos de um script que viajam: tipos simples (sem referências a outros nós).
func _props(path: String) -> Array:
	if not props.has(path):
		var names := BASE.duplicate()
		for p in load(path).get_script_property_list():
			if p.usage & PROPERTY_USAGE_SCRIPT_VARIABLE and p.type in TYPES and not p.name in SKIP:
				names.append(p.name)
		props[path] = names
	return props[path]


func _values(n, path: String) -> Array:
	var out := []
	for k in _props(path):
		var v = n.get(k)
		out.append(v.duplicate(true) if v is Array or v is Dictionary else v)
	return out


func _main_values() -> Array:
	var out := []
	for k in MAIN_KEYS:
		var v = get_tree().paused if k == "paused" else main.get(k)
		out.append(v.duplicate(true) if v is Array or v is Dictionary else v)
	return out


func _send(delta: float) -> void:
	full_t -= delta
	var full := full_t <= 0.0
	if full:
		full_t = FULL_T
	var spawns := []
	var deltas := []
	var alive := {}
	for n in main.get_children():
		var s: Script = n.get_script()
		if s == null or not s.resource_path in SYNCED or n.is_queued_for_deletion():
			continue
		if not n.has_meta("net"):
			n.set_meta("net", next_id)
			next_id += 1
		var id: int = n.get_meta("net")
		alive[id] = true
		if sent.has(id) and s.resource_path == LOCAL:
			continue
		var vals := _values(n, s.resource_path)
		if not sent.has(id):
			spawns.append([id, SYNCED.find(s.resource_path), vals])
		else:
			var d := _diff(sent[id], vals, full)
			if not d.is_empty():
				deltas.append([id] + d)
		sent[id] = vals
	var gone := sent.keys().filter(func(k): return not alive.has(k))
	for k in gone:
		sent.erase(k)
	if not spawns.is_empty() or not gone.is_empty():
		_world.rpc_id(guest_id, spawns, gone)
	var mv := _main_values()
	var md := _diff(sent_main, mv, full)
	sent_main = mv
	if full:
		_frame_sure.rpc_id(guest_id, md, deltas)
		return
	# Pacotes não fiáveis pequenos: acima do MTU partem-se e perde-se o pacote inteiro se faltar um pedaço
	var pack := []
	var size := var_to_bytes(md).size()
	for d in deltas:
		var n := var_to_bytes(d).size()
		if size + n > PACKET and not pack.is_empty():
			_frame.rpc_id(guest_id, md, pack)
			md = []
			pack = []
			size = 0
		pack.append(d)
		size += n
	if not md.is_empty() or not pack.is_empty():
		_frame.rpc_id(guest_id, md, pack)


## [índice, valor, índice, valor...] do que mudou (tudo, se full ou se não havia nada antes).
func _diff(old: Array, vals: Array, full: bool) -> Array:
	var d := []
	for i in vals.size():
		if full or i >= old.size() or vals[i] != old[i]:
			d.append(i)
			d.append(vals[i])
	return d


func _add_guest() -> void:
	sent.clear()
	sent_main = []
	full_t = 0.0
	if main.players.size() < 2:
		main.add_player(-2)


@rpc("any_peer", "call_remote", "reliable")
func _hello(code: int) -> void:
	var id := multiplayer.get_remote_sender_id()
	if role != "host" or not is_instance_valid(main):
		return
	if code != AppUpdate.VERSION_CODE:
		_refuse.rpc_id(id, "A versão do jogo é diferente: atualizem os dois telemóveis.")
	elif main.players.size() > 1 or guest_id != 0:
		_refuse.rpc_id(id, "A sala está cheia.")
	else:
		guest_id = id
		_welcome.rpc_id(id, main.player.hero, main.map_circle)


@rpc("any_peer", "call_remote", "reliable")
func _guest_in() -> void:
	if multiplayer.get_remote_sender_id() != guest_id or not is_instance_valid(main):
		return
	guest_ready = true
	_add_guest()
	main.hud.toast(tr("O %s entrou pela Wi-Fi!") % tr(main.players[1].hero_name))


## Só o que o painel do convidado pode fazer: a Árvore e os frascos do herói dele, e gastar moedas na arma.
@rpc("any_peer", "call_remote", "reliable")
func _ask(who: int, method: String, args: Array) -> void:
	if multiplayer.get_remote_sender_id() != guest_id:
		return
	if not is_instance_valid(main) or main.players.size() < 2:  # em plena recarga responde na mesma: as respostas casam com os pedidos pela ordem
		_answer.rpc_id(guest_id, null, [], [])
		return
	var arg: String = args[0] if args.size() == 1 and args[0] is String else ""
	var me = main.players[1]
	var result = null
	if method == "use_currency" and who == -1 and arg in ["ink", "ash", "bone", "lock0", "lock1", "unlock", "carmesim", "pena_bone", "pena_ink", "pena_ash"]:
		result = main.use_currency(arg)
	elif method == "forge_until" and who == -1 and main.SUFFIXES.has(arg):
		result = main.forge_until(arg)
	elif method == "allocate" and who == 1 and main.PASSIVES.has(arg):
		result = me.allocate(arg)
	elif method == "cycle_support" and who == 1 and arg in me.order:
		me.cycle_support(arg)
	elif method == "set_support" and who == 1 and args.size() == 2 and args[0] is String and args[1] is String:
		me.set_support(args[0], args[1])  # set_support confere que a habilidade é do herói dele e o frasco do grupo
	elif method == "set_soul" and who == 1 and args.size() == 1 and args[0] is String:
		me.set_soul(arg)
	elif method == "respec" and who == 1:
		result = me.respec()
	var heroes := []
	for p in main.players:
		heroes.append([p.slot, _values(p, "res://player.gd")])
	_answer.rpc_id(guest_id, result, heroes, _main_values())


@rpc("any_peer", "call_remote", "unreliable_ordered", 1)
func _input_in(move: Vector2, bits: int, dodge_to: Vector2) -> void:
	if multiplayer.get_remote_sender_id() != guest_id or not is_instance_valid(main) or main.players.size() < 2:
		return
	var p = main.players[1]
	p.touch_move = move.limit_length(1.0)
	for i in 3:
		p.held[p.order[i]] = bits & (1 << i) != 0
	p.boss_first = bits & 64 != 0
	var rise := bits & ~last_bits
	last_bits = bits
	if get_tree().paused:
		return
	if rise & 8:
		main.interact()
	if rise & 16:
		p.use_potion("hp")
	if rise & 32:
		p.use_potion("mp")
	if rise & 128:
		p.dodge(dodge_to)
	if rise & 256:
		p.toggle_stance()
	if rise & 512:
		p.use_trans()


func _peer_in(id: int) -> void:
	if role == "host" and guest_id != 0 and id != guest_id:
		_refuse.rpc_id(id, "A sala está cheia.")


func _peer_out(id: int) -> void:
	if role != "host" or id != guest_id:
		return
	guest_id = 0
	guest_ready = false
	last_bits = 0
	if is_instance_valid(main):
		main.drop_player()


## O anfitrião chama isto onde o convidado também tem de ver/ouvir (sons, avisos, flashes).
func echo(target: String, method: String, args: Array) -> void:
	if role == "host" and guest_ready:
		_event.rpc_id(guest_id, target, method, args)


# ---------- Convidado ----------

@rpc("authority", "call_remote", "reliable")
func _refuse(why: String) -> void:
	_lost(why)


@rpc("authority", "call_remote", "reliable")
func _welcome(h: String, c: int) -> void:
	role = "guest"
	Engine.set_meta("hero", h)  # o jogador 1 do convidado é o herói do anfitrião (main._first_hero confere-o)
	Engine.set_meta("map_circle", c)  # e o mapa é o do anfitrião, gerado uma só vez
	stop_scan()
	main = null
	Engine.set_meta("play_now", true)
	get_tree().paused = false
	get_tree().reload_current_scene()


func _lost(why: String) -> void:
	var was := role
	close()
	if was == "guest" and is_instance_valid(main):
		Engine.set_meta("net_note", why)  # o título mostra o aviso
		main.restart(true)
	elif was == "joining" and is_instance_valid(main):
		main.hud.toast(why)


## O anfitrião recomeçou a cena: tudo o que havia desaparece (os heróis ficam e são corrigidos).
@rpc("authority", "call_remote", "reliable")
func _reset() -> void:
	for id in nodes:
		if is_instance_valid(nodes[id]) and not nodes[id] in main.players:
			nodes[id].queue_free()
	nodes.clear()


@rpc("authority", "call_remote", "reliable")
func _world(spawns: Array, gone: Array) -> void:
	if not is_instance_valid(main):
		return
	for s in spawns:
		_spawn(s[0], SYNCED[s[1]], s[2])
	for id in gone:
		var n = nodes.get(id)
		nodes.erase(id)
		if is_instance_valid(n) and not n in main.players:
			if n == main.chest:
				main.chest = null
			n.queue_free()


func _spawn(id: int, path: String, vals: Array) -> void:
	var names: Array = _props(path)
	var n
	if path == "res://player.gd":
		var slot: int = vals[names.find("slot")]
		for p in main.players:
			if p.slot == slot:
				n = p
		if n == null:
			return
	else:
		n = load(path).new()
		if "main" in n:
			n.main = main
		_set_all(n, names, vals)
		if path == LOCAL:
			n.amount = main.EFFECTS[main.effects_level()]
			if n.kind != "num":  # os números de dano ficam sempre inteiros
				n.alpha = main.FX_ALPHA[main.settings.fx_alpha]
			main.add_child(n)
			return
		main.add_child(n)  # _ready (grupos, nomes) com os valores certos
		n.set_process(false)
	_set_all(n, names, vals)
	nodes[id] = n
	if path == "res://chest.gd":
		main.chest = n
	elif path == "res://enemy.gd" and n.reaper:  # o Ceifador (#216) não está no grupo dos inimigos: o HUD acha-o por aqui
		main.reaper = n
	elif path == "res://enemy.gd" and n.is_boss and main.zone == "crypt":
		main.guardian = n


func _set_all(n, names: Array, vals: Array) -> void:
	for i in names.size():
		n.set(names[i], vals[i])
	n.queue_redraw()


@rpc("authority", "call_remote", "unreliable_ordered", 2)
func _frame(md: Array, deltas: Array) -> void:
	_apply_frame(md, deltas)


@rpc("authority", "call_remote", "reliable", 3)
func _frame_sure(md: Array, deltas: Array) -> void:
	_apply_frame(md, deltas, true)


func _apply_frame(md: Array, deltas: Array, sure := false) -> void:
	if not is_instance_valid(main) or role != "guest":
		return
	for d in deltas:
		var n = nodes.get(d[0])
		if not is_instance_valid(n):
			continue
		var names: Array = _props(n.get_script().resource_path)
		for i in range(1, d.size(), 2):
			n.set(names[d[i]], d[i + 1])
		n.queue_redraw()
	_apply_main(md, sure)


func _apply_main(md: Array, sure := false) -> void:
	for i in range(0, md.size(), 2):
		var k: String = MAIN_KEYS[md[i]]
		var v = md[i + 1]
		match k:
			"track":
				main.play_track(v)
			"map_circle":
				if sure and v != main.map_circle:  # só os frames fiáveis vêm por ordem entre si: um atrasado desfazia a troca, com o sino e o negro a dobrar (chega no máximo FULL_T depois)
					main.build_map(v)
			"paused":
				host_paused = v
			"zone":
				if v != main.zone:
					main.zone = v
					main.zone_view(main.players[0].position)
			_:
				main.set(k, v)


@rpc("authority", "call_remote", "reliable")
func _answer(result, heroes: Array, mv: Array) -> void:
	if not is_instance_valid(main):
		return
	for h in heroes:
		for p in main.players:
			if p.slot == h[0]:
				_set_all(p, _props("res://player.gd"), h[1])
	var md := []
	for i in mv.size():
		md.append_array([i, mv[i]])
	_apply_main(md)
	if not asks.is_empty():
		asks.pop_front().call(result)


@rpc("authority", "call_remote", "reliable")
func _event(target: String, method: String, args: Array) -> void:
	if is_instance_valid(main):
		(main if target == "main" else main.hud).callv(method, args)
