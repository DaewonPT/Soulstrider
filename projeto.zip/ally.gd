extends Node2D
## Esqueleto erguido pela Alma Tumular: luta pelo herói que o ergueu durante uns segundos e desfaz-se.
## Os inimigos não o atacam; ele procura o inimigo mais perto ou fica junto do dono.

const Enemy := preload("res://enemy.gd")
const Feet := preload("res://art/anim/feet.gd")
const LIFE := 12.0
const ATTACK_T := 0.4

var main
var owner_p  # o herói que o ergueu
var life := LIFE
var t := 0.0
var attack_cd := 0.0
var attack_t := 0.0
var right := true
var half := false  # Alma Mitótica (#149): um de dois pequenos, metade do dano (viaja ao convidado)


func _ready() -> void:
	add_to_group("allies")
	if half:  # já vem certo antes do _ready, também no convidado (net._spawn)
		scale = Vector2(0.7, 0.7)
	main.spawn_fx("dust", position, 40.0, Color.WHITE)
	main.spawn_fx("ring", position, 50.0, Color(0.4, 1.0, 0.65))


func _process(delta: float) -> void:
	t += delta
	life -= delta
	attack_cd = maxf(0.0, attack_cd - delta)
	attack_t = maxf(0.0, attack_t - delta)
	queue_redraw()
	if life <= 0.0:
		main.spawn_fx("dust", position, 40.0, Color.WHITE)
		if not Net.is_guest():
			main.miasma(position, owner_p)
		queue_free()
		return
	var target = null
	var best := 420.0
	for e in main.enemies():
		var d: float = position.distance_to(e.position)
		if d < best:
			best = d
			target = e
	var goal := position
	if target != null:
		goal = target.position
	elif is_instance_valid(owner_p):
		goal = owner_p.position + Vector2(-50, 30)
	var to := goal - position
	var reach: float = target.radius + 16.0 if target != null else 40.0
	if to.length() > reach:
		position = main.walk(position, position + to.normalized() * 115.0 * main.blood_speed(position) * delta)
		right = to.x > 0.0
	elif target != null and attack_cd <= 0.0:
		attack_cd = 0.8
		attack_t = ATTACK_T
		target.take_damage((9.0 + main.level * 1.5) * (0.5 if half else 1.0), true, to.normalized())


func _draw() -> void:
	var f := 4 + mini(3, int((1.0 - attack_t / ATTACK_T) * 4.0)) if attack_t > 0.0 else int(t * 7.0) % 4
	var tex: Texture2D = Enemy.FRAMES["skeleton"][f]
	var a := clampf(life, 0.0, 1.0)  # desvanece no último segundo
	draw_set_transform(Vector2.ZERO, 0.0, Vector2(1.0, 0.4))
	draw_circle(Vector2.ZERO, 15.0, Color(0.3, 1.0, 0.6, 0.25 * a))
	var sc: float = Enemy.SCALES["skeleton"]
	draw_set_transform(Vector2.ZERO, 0.0, Vector2(sc * (1.0 if right else -1.0), sc))
	draw_texture(tex, Vector2(-tex.get_width() / 2.0, -tex.get_height() + Feet.FEET["skeleton"][f]), Color(0.55, 1.0, 0.7, 0.9 * a))
	draw_set_transform(Vector2.ZERO)
