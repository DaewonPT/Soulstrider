extends Node2D
## Esqueleto erguido pela Alma Tumular: luta pelo herói que o ergueu durante uns segundos e desfaz-se.
## Os inimigos não o atacam (só o guardião, que os atrai); ele procura o inimigo mais perto ou fica junto do dono.

const Enemy := preload("res://enemy.gd")
const Pix := preload("res://fx_pix.gd")
const LIFE := 12.0
const ATTACK_T := 0.4

var main
var owner_p  # o herói que o ergueu
var life := LIFE
var t := 0.0
var attack_cd := 0.0
var attack_t := 0.0
var right := true
var half := false  # Alma Mitótica (#149): um de dois pequenos, metade do dano (viaja ao convidado)
var fed := 0.0  # Comunhão dos Vermes-Deuses (#112): segundos de banquete que faltam (ataca 3× mais depressa)
## Esqueletos especializados (#11), pelo nó do dono: "arqueiro" dispara lascas de osso de longe, "guarda" leva um escudo
## de costelas e os mortos menores perto vão a ele (main.lure); "" o de sempre (viaja ao convidado, que os desenha)
var kind := ""
var body := "skeleton"  # Ressurreição de Elites (#179): o desenho de quem se ergueu (viaja ao convidado)
var power := 1.0  # e o dano: 3 no elite erguido, maior e com um anel dourado (viaja ao convidado)


func _ready() -> void:
	add_to_group("allies")
	if half:  # já vem certo antes do _ready, também no convidado (net._spawn)
		scale = Vector2(0.7, 0.7)
	main.spawn_fx("dust", position, 40.0, Color.WHITE)
	main.spawn_fx("ring", position, 50.0, Color(0.4, 1.0, 0.65))


func _process(delta: float) -> void:
	t += delta
	life -= delta
	attack_cd = maxf(0.0, attack_cd - delta)
	attack_t = maxf(0.0, attack_t - delta)
	fed = maxf(0.0, fed - delta)
	queue_redraw()
	if life <= 0.0:
		main.spawn_fx("dust", position, 40.0, Color.WHITE)
		if not Net.is_guest():
			main.miasma(position, owner_p)
		queue_free()
		return
	var target = null
	var best := 420.0
	for e in main.enemies():
		var d: float = position.distance_to(e.position)
		if d < best:
			best = d
			target = e
	var food: Array = []  # Comunhão dos Vermes-Deuses (#112): o morto recente mais perto, se o dono a tiver
	if is_instance_valid(owner_p) and owner_p.stat("vermes") > 0.0:
		food = main.grave_near(position)  # os abates dos últimos 5 s (os mesmos que o Alma Gatilho gasta), até 300 px
		for c in main.corpses:  # e os cadáveres do Espasmo (#9), que comidos já não rebentam
			if position.distance_to(c[0]) < (300.0 if food.is_empty() else position.distance_to(food[0])):
				food = c
		if t > 0.5 and not food.is_empty() and position.distance_to(food[0]) <= 40.0:  # ao nascer está em cima do próprio abate: esse não conta
			main.graves.erase(food)  # está numa das duas listas; na outra o erase não faz nada
			main.corpses.erase(food)
			main.spawn_fx("burst", food[0], 0.0, main.CORPSE_COLORS[1])
			fed = 8.0
			life = maxf(life, 4.0 if owner_p.stat("canibal") > 0.0 else LIFE)  # com o Canibalismo continuam a durar só 4 s; o elite erguido (#179) não perde os 20 s
			food = []
	var goal := position
	if target != null:
		goal = target.position
	elif not food.is_empty():
		goal = food[0]
	elif is_instance_valid(owner_p):
		goal = owner_p.position + Vector2(-50, 30)
	var to := goal - position
	var reach: float = target.radius + 16.0 if target != null else 40.0
	var archer: bool = kind == "arqueiro" and target != null and is_instance_valid(owner_p)  # sem dono (saiu da sala) bate de perto
	if archer:
		reach = 280.0
	var tide: bool = main.tide_on()  # Lago das Lamentações (#30): a maré de almas empurra-os e abranda-os a 60%
	var push: Vector2 = main.tide_push() + main.belt_push(position)  # e as passadeiras do Moinho de Carne (#202) levam-nos para a serra
	if push != Vector2.ZERO:
		position = main.walk(position, position + push * delta)
	if to.length() > reach:
		position = main.walk(position, position + to.normalized() * 115.0 * main.blood_speed(position) * (0.6 if tide else 1.0) * delta)
		right = to.x > 0.0
	elif target != null and attack_cd <= 0.0:
		attack_cd = 0.8 / 3.0 if fed > 0.0 else 0.8
		attack_t = ATTACK_T
		var hit: float = (9.0 + main.level * 1.5) * (0.5 if half else 1.0) * power
		if archer:  # uma lasca de osso que atravessa 2 monstros (S4); conta como do dono, como as Sentinelas
			right = to.x > 0.0
			var from := position + Vector2(0, -30)
			var b = main.spawn_bolt(from, from.direction_to(target.position + Vector2(0, -20)), hit, 10.0, owner_p, 0, true)
			b.pierce = 2
			b.quiet = true  # sem paragem de impacto: 4 arqueiros davam uma série delas
		else:
			target.hit_phys = false  # Exumação Espontânea (#102): o que o esqueleto mata não se ergue, só o que o herói mata
			target.take_damage(hit, true, to.normalized())


## Guardião de Tórax (#11): o escudo aguenta os golpes dos mortos que atrai, mas cada um tira-lhe tempo (um décimo do dano).
func take_damage(amount: float, _by := "", _src = null) -> void:
	life -= amount / 10.0
	main.spawn_fx("sparks", position + Vector2(0, -30), 0.0, Color(0.9, 0.86, 0.75))


func _draw() -> void:
	# os mesmos desenhos 32-bit dos esqueletos inimigos: 0-7 andar, 8-15 ataque
	var f := 8 + mini(7, int((1.0 - attack_t / ATTACK_T) * 8.0)) if attack_t > 0.0 else int(t * 13.0) % 8
	var tex: Texture2D = Enemy.FRAMES32[body][f]
	var a := clampf(life, 0.0, 1.0)  # desvanece no último segundo
	Pix.haze(self, Vector2.ZERO, 18.0, 8.0, Color(0.3, 1.0, 0.6), 0.6 * a)
	if power > 1.0:  # o elite erguido (#179): o anel dourado dos elites
		Pix.elite(self, Vector2.ZERO, 44.0, 18.0, Color(1, 1, 1, a))
	var sc: float = Enemy.Feet32.SCALE[body + "32"] * (1.3 if power > 1.0 else 1.0)
	draw_set_transform(Vector2.ZERO, 0.0, Vector2(sc * (1.0 if right else -1.0), sc))
	draw_texture(tex, Vector2(-tex.get_width() / 2.0, -tex.get_height() + Enemy.Feet32.FEET[body + "32"][f]), Color(0.55, 1.0, 0.7, 0.9 * a))
	draw_set_transform(Vector2.ZERO)
	var s := 1.0 if right else -1.0
	var bone := Color(0.9, 0.86, 0.75, a)
	if kind == "arqueiro":  # o arco de osso, à frente
		Pix.arc(self, Vector2(s * 10.0, -36.0), 16.0, 16.0, 0.075 if right else 0.575, 0.425 if right else 0.925, bone)
		draw_rect(Rect2(Pix.snap(self, Vector2(s * 17.0, -50.0)), Vector2(Pix.S, 28.0)), bone.darkened(0.35))  # a corda
	elif kind == "guarda":  # o escudo de costelas, à frente
		for i in 3:
			Pix.arc(self, Vector2(s * 4.0, -30.0), 20.0 + i * 5.0, 20.0 + i * 5.0, 0.107 if right else 0.607, 0.393 if right else 0.893, bone)
