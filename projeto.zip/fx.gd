extends Node2D
## Efeito visual curto: anel, faíscas, impacto, brilho do crítico,
## número de dano, explosão de subida de nível ou poeira.
## Em píxeis de 2 px (fx_pix.gd): impacto, golpe, sangue, rasto da esquiva, explosão sem fogo, pilar de luz da subida
## de nível, saque a voar para o herói e cura das poções.
## Efeitos adaptados de Sprite Fusion Pixel Art VFX (MIT, (c) 2026 Hugo Duprez)

const HIT := [preload("res://art/fx/hit_0.png"), preload("res://art/fx/hit_1.png"), preload("res://art/fx/hit_2.png"), preload("res://art/fx/hit_3.png")]
const Gothic := preload("res://gothic.gd")
const Pix := preload("res://fx_pix.gd")
const Loot := preload("res://loot.gd")
const SILHOUETTE := preload("res://silhouette.gdshader")
const PIXEL := ["impact", "slash", "blood", "dash", "explosion", "pillar", "pickup", "heal"]
const GRAVITY := 1900.0
const STAIN_LIFE := 3.0  # as manchas do sangue secam no último segundo, como as poças do Sangue no Solo (4 s)
const STAIN_STEPS := [0.35, 0.4, 1.0, 1.4, STAIN_LIFE]  # idades em que a mancha muda de tom ou perde o brilho (_stain)
const SQUASH := 0.54  # elipses no chão (vista de cima, como os anéis de art/fx)
# Partículas em parts: [tipo, posição, velocidade, vida, vida inicial, cor, tamanho, espera, chão (y local), extra]
enum { SPARK, MOTE, DUST, GRIT, DROP, STAIN, MIST, SMOKE, ROCK, LINE, STAR, BOKEH, HOME, RING, GLYPH, BUBBLE }

var kind := "ring"
var radius := 100.0
var dir := Vector2.RIGHT
var color := Color(0.35, 1.0, 0.6)
var text := ""
var sub := ""  # legenda pequena por cima do número ("CRÍTICO!")
var t := 0.0
var dur := 0.35
var parts := []  # [posição, velocidade, tamanho] por partícula
var drift := 0.0  # números: para que lado caem no fim do arco
var amount := 1.0  # Efeitos visuais nas Configurações: parte das partículas que se desenha
var alpha := 1.0  # Opacidade dos efeitos (#86): cada telemóvel a sua (main.spawn_fx; os números de dano ficam com 1)
var seed := 0  # o mesmo no anfitrião e no convidado: o mesmo desenho
var ramp := ""  # rampa de cores (Pix.RAMPS) pelo nome: a lista de cores não viaja
var ground := 0.0  # y do chão (os pés) em relação ao efeito: onde as gotas, faíscas e lascas caem
var shape := []  # forma sorteada no início (pontas do impacto, fios de sangue): não viaja, refaz-se da semente
var follow := -1  # slot do herói que o efeito segue (cura) ou para onde voa (saque)
var item := ""  # saque: o tipo, ou o nome do Frasco de Alma, para o ícone que voa
var aim := Vector2(0, -45)  # saque: o peito do herói, em relação ao efeito
var popped := false
var absorbed := 0
var rng := RandomNumberGenerator.new()
var under: Node2D  # camada do chão (z -9): manchas, poeira, fumo, a metade de trás dos anéis
var lit: Node2D  # camada de luz aditiva por cima
var mid: Node2D  # o ícone do saque, ou as faixas de luz que sobem pelo herói na cura (filtro suave)
var settled := false  # sangue: só restam manchas no chão (4 dos 5 s); o resto do efeito deixa de se mexer e desenhar
var stain_due := 0.0  # quando uma mancha do sangue muda a seguir (cai uma nova, alastra, seca um tom, desvanece)
var seg := PackedVector2Array()  # os riscos de 2 px das faíscas, aparas e riscos de velocidade: uma chamada por camada
var seg_c := PackedColorArray()


func _ready() -> void:
	z_index = 5
	modulate.a = alpha  # o convidado põe a dele antes do _ready (o modulate do anfitrião já traz a do anfitrião)
	if kind in PIXEL:
		_pixel_ready()
		return
	match kind:
		"sparks":
			for i in maxi(2, roundi(9 * amount)):
				parts.append([Vector2.ZERO, dir.rotated(randf_range(-0.6, 0.6)) * randf_range(260.0, 620.0), randf_range(6.0, 16.0)])
		"burst":
			dur = 0.9
			for i in maxi(4, roundi(18 * amount)):
				parts.append([Vector2.ZERO, Vector2.from_angle(randf() * TAU) * randf_range(150.0, 380.0) + Vector2(0, -160), randf_range(4.0, 8.0)])
		"dust":
			dur = 0.7
			z_index = 4
			for i in maxi(2, roundi(7 * amount)):
				var d := Vector2.from_angle(randf() * TAU)  # nascem afastadas: juntas no meio eram uma bola cinzenta
				parts.append([d * radius * 0.3, d * randf_range(40.0, 90.0) * radius / 60.0, randf_range(14.0, 26.0) * radius / 60.0])
		"num":
			z_index = 20
			dur = 0.8
			drift = randf_range(-1.0, 1.0)
		"hit":
			dur = 0.25
		"glow":
			dur = 0.18
		"column":
			dur = 0.6
		"arc":  # Alma Biomecânica (#144): raio aos zigue-zagues de 0 até dir * radius, refeito da semente (igual no convidado)
			dur = 0.18
			rng.seed = seed
			shape = [Vector2.ZERO]
			for i in range(1, 5):
				shape.append(dir * radius * i / 5.0 + dir.orthogonal() * rng.randf_range(-10.0, 10.0))
			shape.append(dir * radius)
	if kind in ["glow", "burst", "column"]:
		var m := CanvasItemMaterial.new()
		m.blend_mode = CanvasItemMaterial.BLEND_MODE_ADD
		material = m
		texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST  # o brilho aos degraus, como os píxeis


func _process(delta: float) -> void:
	t += delta
	if t >= dur:
		queue_free()
	if under:
		if not settled:
			var h = _hero()
			if h != null and kind == "heal":
				position = h.position.snapped(Vector2(Pix.S, Pix.S))
			elif h != null:
				aim = h.position + Vector2(0, -45) - position
			_step(delta)
			if kind != "blood" or t - delta < 0.09:  # a luz do sangue é só o clarão da ferida (até 0,09 s; este frame apaga-o)
				lit.queue_redraw()
			if mid:
				mid.queue_redraw()
			queue_redraw()
		if t >= stain_due if kind == "blood" else not kind in AIRBORNE:  # no chão do sangue só há manchas: só quando mudam
			under.queue_redraw()
		return
	for p in parts:
		p[0] += p[1] * delta
		p[1] *= exp(-(6.0 if kind == "sparks" else 2.0) * delta)
		if kind == "burst":
			p[1].y += 500.0 * delta
	queue_redraw()


func _draw() -> void:
	if under:
		_draw_front()
		return
	var k := t / dur
	var c := Color(color, 1.0 - k)
	match kind:
		"hit":
			var tex: Texture2D = HIT[mini(3, int(k * 4.0))]
			var s := radius / 115.0
			draw_set_transform(Vector2.ZERO, 0.0, Vector2(s, s))
			draw_texture(tex, -tex.get_size() / 2.0, Color(1.6, 1.2, 0.6) if color.g < 0.9 else Color.WHITE)
			draw_set_transform(Vector2.ZERO)
		"sparks":
			for p in parts:
				_seg(p[0], p[0] - p[1].normalized() * p[2] * (1.0 - k), c)
			_seg_flush(self, Pix.S)
		"burst":
			for p in parts:  # brilha menos a apagar-se: as estrelas encolhem
				Pix.sparkle(self, p[0], maxi(1, roundi(p[2] * 0.6 * (1.0 - k))), color, color.darkened(0.3))
		"dust":
			for p in parts:
				Pix.puff(self, p[0], p[2] * (0.6 + k), Color(0.42, 0.4, 0.36), 0.6 * (1.0 - k))
		"glow":
			Pix.glow(self, Vector2.ZERO, radius * (0.6 + k) * 1.2, color, 0.8 * (1.0 - k))
		"arc":  # brilho violeta largo e o miolo branco de 3 px
			for w in [[color, 0.55, 3.0], [Color.WHITE, 1.0, 1.0]]:
				for i in range(1, shape.size()):
					_seg(shape[i - 1], shape[i], Color(w[0], w[1] * (1.0 - k)))
				_seg_flush(self, Pix.S * w[2])
		"column":  # coluna de luz que sobe e desvanece (subida de nível com efeitos baixos): dois quadros que esmaecem para cima
			Pix.beam(self, Vector2(0, -40.0 * k), "gold", 110, int(t * 12.0) % 3, Color(1, 1, 1, 1.0 - k))
		"num":
			# Pop (cresce acima do tamanho e assenta), sobe, e desvanece no fim
			var pop := 1.0 + 0.6 * maxf(0.0, 1.0 - t / 0.12)
			var fade := clampf((1.0 - k) / 0.4, 0.0, 1.0)
			var size := int(radius * 1.15 * pop)  # a letra gótica é mais estreita: um pouco maior
			# Em arco: sobe depressa, abranda e descai para um dos lados
			var y := -110.0 * k + 70.0 * k * k
			var x := drift * 36.0 * k
			Gothic.draw_centered(self, x, y, text, size, Color(color, fade), 7)
			if sub != "":
				Gothic.draw_centered(self, x, y - size * 0.75, sub, 16, Color(1.0, 0.9, 0.6, fade), 5)
		_:
			var r := radius * (0.3 + 0.7 * k)  # do mesmo tamanho de sempre: em células, a afinar e a desfazer-se ao pontilhado
			var col: Color = color.lightened(0.5) if k < 0.25 else color if k < 0.6 else color.darkened(0.25)
			Pix.loop(self, Vector2.ZERO, r, r, col, 3 if k < 0.25 else 2 if k < 0.6 else 1, k < 0.6, 5 if k < 0.6 else 3 if k < 0.8 else 2)


# ---------- Efeitos em píxeis ----------
# Tempos e formas como na biblioteca (1 píxel = 2 px do mundo); o brilho é um quadro aditivo e os discos já vêm cozidos.

const SWEEP := 0.06  # golpe: a lâmina varre, fica e o rasto apaga-se
const HOLD := 0.06
const TRAIL := 0.24
const ARC := 1.3  # metade do arco do golpe (a do main.hit_arc)
const BANDS := [0.0, 0.22, 0.6, 1.0]  # fundura do crescente: gume, corpo, dentro
const DASH_T := 0.18  # a Esquiva Espectral (player.DASH_T)
const SKID := Color(0.13, 0.1, 0.2)
const SOOT2 := Color(0.09, 0.07, 0.11)
const UNDER := [DUST, SMOKE, STAIN]  # partículas que vão na camada do chão
const AIRBORNE := ["impact", "slash", "pickup"]  # nada na camada do chão: não se redesenha


func _pixel_ready() -> void:
	rng.seed = seed
	add_to_group("px_" + kind)  # main.fx_budget conta os vivos
	position = position.snapped(Vector2(Pix.S, Pix.S))  # o nó na grelha: os píxeis de 2 px batem com os do mundo
	texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	under = Node2D.new()
	under.z_as_relative = false
	under.z_index = -9
	under.draw.connect(_draw_under)
	add_child(under)
	lit = Node2D.new()
	lit.z_index = 1
	var m := CanvasItemMaterial.new()
	m.blend_mode = CanvasItemMaterial.BLEND_MODE_ADD
	lit.material = m
	lit.draw.connect(_draw_lit)
	add_child(lit)
	if kind in ["pickup", "heal"]:
		mid = Node2D.new()
		mid.z_index = -1
		mid.texture_filter = CanvasItem.TEXTURE_FILTER_LINEAR
		if kind == "heal":
			mid.material = ShaderMaterial.new()
			mid.material.shader = SILHOUETTE
		mid.draw.connect(_draw_mid)
		add_child(mid)
	shape = []  # o que vier do anfitrião não serve: refaz-se da semente
	parts = []
	var C := Pix.ramp(ramp)
	match kind:
		"impact":
			_impact_ready(C)
		"slash":
			_slash_ready(C)
		"blood":
			_blood_ready(C)
		"dash":
			_dash_ready()
		"explosion":
			_explosion_ready(C)
		"pillar":
			_pillar_ready()
		"pickup":
			dur = P_POP + 1.15
		"heal":
			_heal_ready()


func _hero():  # o herói de follow (pelo slot, que o convidado também tem)
	for p in get_parent().players if follow >= 0 else []:
		if p.slot == follow:
			return p
	return null


func _chance(p: float, delta: float) -> bool:  # a biblioteca sorteia por frame a 60 Hz: aqui pelo tempo
	var n := delta * 60.0  # em média p por 1/60 s a qualquer FPS (o 1-(1-p)^n dava mais a 120 FPS)...
	return rng.randf() < minf(p * n, 1.0 - pow(1.0 - minf(p, 1.0), n))  # ...mas a 30 FPS nunca mais do que dava


func _add(k: int, at: Vector2, v: Vector2, life: float, col := Color.WHITE, size := 1.0, wait := 0.0, floor_y := INF, extra: Variant = 0.0) -> void:
	parts.append([k, at, v, life, life, col, size, wait, floor_y, extra])


func _jitter() -> float:  # vista de cima: cada pedaço cai num chão um pouco à frente ou atrás
	return ground + rng.randf_range(-6.0, 6.0)


## Impacto: estrela de 8 pontas (2 frames), lascas, anel pontilhado, faíscas e um clarão. radius = tamanho (1, crítico 1,4).
func _impact_ready(C: Array) -> void:
	dur = 0.35
	var sz := radius
	var a0 := dir.angle()
	for i in 8:
		var a := a0 + i / 8.0 * TAU + rng.randf_range(-0.18, 0.18)
		var cb := cos(a - a0)  # mais comprida para onde o golpe empurra
		var ln := (7.0 + rng.randf_range(0.0, 3.0)) * sz * (1.0 + 1.8 * pow(maxf(0.0, cb), 3.0) + 0.6 * pow(maxf(0.0, -cb), 3.0))
		shape.append([a, ln * Pix.S, (1.5 + rng.randf_range(0.0, 0.6)) * sz * Pix.S])
	var longest := shape.duplicate()
	longest.sort_custom(func(p, q): return p[1] > q[1])
	for s in longest.slice(0, 4):  # quatro lascas voam ao longo das pontas maiores
		shape.append([s[0] + rng.randf_range(-0.15, 0.15), s[1] * 0.8, s[1] * rng.randf_range(5.0, 8.0), rng.randf_range(0.35, 0.6)])
	for i in roundi((6.0 + 12.0 * sz) * amount):
		var a := (a0 + PI if rng.randf() < 0.2 else a0) + rng.randf_range(-0.6, 0.6)
		_add(SPARK, Vector2.ZERO, Vector2.from_angle(a) * rng.randf_range(260.0, 900.0) * (0.6 + 0.4 * sz) - Vector2(0, 60), rng.randf_range(0.1, 0.3), C[1], 1.0, 0.0, _jitter())


func _draw_impact(C: Array) -> void:
	var f := maxi(1, ceili(t * 60.0 - 0.001))
	if f == 1:
		_star(1.0, 1.0, C[0], C[1], C[2], C[4])
	elif f == 2:
		_star(1.25, 0.55, C[1], C[2], C[3], C[4])
	var e := t - 2.0 / 60.0
	if f >= 3 and t < 0.13:
		var k := e / (0.13 - 2.0 / 60.0)
		var col: Color = C[2] if k < 0.4 else C[3] if k < 0.7 else C[4]
		for s in shape.slice(8):
			var span: float = s[3] * (1.0 - 0.4 * k)
			var f0: float = (s[0] - span / 2.0 + PI / 2.0) / TAU
			Pix.arc(self, Vector2.ZERO, s[1] + s[2] * e, s[1] + s[2] * e, f0, f0 + span / TAU, Color(col, 1.0 - k))
	if f >= 3 and t < 0.2:
		var k := e / (0.2 - 2.0 / 60.0)
		var col: Color = C[1] if k < 0.3 else C[2] if k < 0.6 else C[3]
		var r := (8.0 + 12.0 * Pix.out_cubic(k)) * radius * Pix.S
		Pix.loop(self, Vector2.ZERO, r, r, col, 2 if k < 0.5 else 1, false, 4 if k < 0.6 else 3 if k < 0.8 else 2)


## Três passagens por ponta (contorno, corpo com o miolo claro, núcleo) e o disco do meio.
func _star(sc: float, th: float, core: Color, inner: Color, body: Color, rim: Color) -> void:
	for s in shape.slice(0, 8):
		_tri(s[0], s[1] * sc + 1.6, s[2] * th + 1.6, rim)
	for s in shape.slice(0, 8):
		var hw: float = s[2] * th
		_tri(s[0], s[1] * sc, hw, body)
		var q := Transform2D(s[0], Vector2.ZERO)
		var l: float = s[1] * sc * 0.35
		draw_primitive(PackedVector2Array([q * Vector2(0, -hw), q * Vector2(l, -hw * 0.65), q * Vector2(l, hw * 0.65), q * Vector2(0, hw)]), PackedColorArray([inner]), PackedVector2Array())
	for s in shape.slice(0, 8):
		_tri(s[0], s[1] * sc * 0.55, s[2] * th * 0.45, core)
	var r := 2.4 * radius * sc * sqrt(th)
	Pix.disc(self, Vector2.ZERO, r + 0.8, inner)
	Pix.disc(self, Vector2.ZERO, r, core)


func _tri(a: float, l: float, hw: float, c: Color) -> void:
	var q := Transform2D(a, Vector2.ZERO)
	draw_primitive(PackedVector2Array([q * Vector2(0, -hw), q * Vector2(l, 0), q * Vector2(0, hw)]), PackedColorArray([c]), PackedVector2Array())


## Golpe da foice ou do machado: crescente numa elipse virada para a mira, com um eco por dentro, faíscas na ponta
## e aparas. radius = área do golpe; a largura cresce com ela (foice 27, machado 30); color.a < 1 é o eco.
func _slash_ready(C: Array) -> void:
	dur = 0.6
	modulate.a = color.a * alpha
	var w := radius * 24.0 / 84.0
	var end := _arc_at(radius - w * 0.3, ARC)
	var tan := (_arc_at(radius - w * 0.3, ARC + 0.05) - end).normalized()
	for i in roundi(10.0 * amount):  # faíscas na ponta da lâmina quando ela chega ao fim
		_add(SPARK, end, Vector2.from_angle(tan.angle() + rng.randf_range(-0.5, 0.5)) * rng.randf_range(300.0, 800.0), rng.randf_range(0.12, 0.35), C[1], 1.0, SWEEP, _jitter())
	if amount > 0.7:  # efeitos altos
		for i in roundi(16.0 * amount):  # aparas de luz atiradas para fora do arco
			var at := _arc_at(radius, -ARC + 2.0 * ARC * rng.randf_range(0.3, 1.0))
			_add(MOTE, at, at.normalized() * rng.randf_range(60.0, 200.0) - Vector2(0, 20), rng.randf_range(0.25, 0.55), C[2 + rng.randi() % 2], 0.6, SWEEP)


func _arc_at(r: float, a: float) -> Vector2:
	return Vector2(cos(a) * r, sin(a) * r * 0.6).rotated(dir.angle())


func _draw_slash(C: Array) -> void:
	var w := radius * 24.0 / 84.0
	if amount > 0.7:  # efeitos altos: o eco, mais fino e por dentro
		_blade(radius * 33.0 / 42.0, radius * 4.5 / 42.0, -ARC + 0.26, ARC - 0.11, 0.017, HOLD * 0.5, TRAIL * 5.0 / 6.0, C.slice(1))
	_blade(radius, w, -ARC, ARC, 0.0, HOLD, TRAIL, C)
	var g := t - SWEEP * 0.6  # o brilho na ponta
	if g > 0.0 and g < 0.22:
		Pix.sparkle(self, _arc_at(radius - w * 0.3, ARC), roundi(9.0 * Pix.out_back(minf(1.0, g / 0.05)) * (1.0 - g / 0.22)), C[1], C[3])


func _blade(r: float, w: float, b0: float, b1: float, t0: float, hold: float, trail: float, C: Array) -> void:
	var u := t - t0
	if u < 0.0:
		return
	var head := Pix.out_expo(u / SWEEP)
	var tail := Pix.smooth(SWEEP + hold, SWEEP + hold + trail, u)
	var span := b1 - b0
	var age := clampf(u / (SWEEP + hold + trail), 0.0, 1.0)
	if tail < 1.0:
		_crescent(r, w * (1.0 - tail * 0.55), b0 + span * tail, span * (head - tail), C, age)
	var th := 0.7 * (1.0 - clampf((u - SWEEP - hold) / (trail + 0.2), 0.0, 1.0))
	if tail > 0.02 and th > 0.0:  # o risco por onde a lâmina passou
		var pts := PackedVector2Array()
		for i in 9:
			pts.append(_arc_at(r - 1.0, b0 + span * tail * i / 8.0))
		draw_polyline(pts, Color(C[C.size() - 2], th), Pix.S)


## O crescente aos quadros: largura sin(π v^2,2)^0,6 ao longo do arco, cor pela fundura e pela idade, a ponta de trás a sumir.
func _crescent(r: float, w: float, ta: float, l: float, C: Array, age: float) -> void:
	if absf(l) < 0.02 or w < 0.6:
		return
	var n := 14 if amount > 0.5 else 8
	var rot := Transform2D(dir.angle(), Vector2.ZERO)
	var last := PackedVector2Array()  # os 4 pontos (gume, corpo, dentro, fim) da divisória anterior: cada um calcula-se uma vez
	var w0 := 0.0
	for j in n + 1:
		var v1 := float(j) / n
		var w1 := w * pow(maxf(0.0, sin(PI * pow(v1, 2.2))), 0.6)
		var b1 := ta + l * v1
		var arc := Vector2(cos(b1), sin(b1) * 0.6)  # _arc_at sem refazer o seno e o cosseno
		var pts := PackedVector2Array()
		for q in BANDS:
			pts.append(rot * (arc * (r - w1 * q)))
		if j > 0 and w0 + w1 >= 1.4:
			var vm := (v1 * 2.0 - 1.0 / n) * 0.5
			var f := minf(1.0, vm / 0.4)
			for b in 3:
				var q0: float = BANDS[b]
				var q1: float = BANDS[b + 1]
				var col: Color = Pix.RAMPS.bone[1] if b == 0 and age < 0.5 else C[clampi(roundi((q0 + q1) * 0.5 * (C.size() - 1) * 0.75 + age * 2.4 - vm * 0.8 + 0.4), 0, C.size() - 1)]
				draw_primitive(PackedVector2Array([last[b], pts[b], pts[b + 1], last[b + 1]]), PackedColorArray([Color(col, f)]), PackedVector2Array())
		last = pts
		w0 = w1


## Sangue: fios que rebentam da ferida, gotas que caem no chão e ficam manchas a secar (4 s, como as poças), névoa.
## radius = quantidade (0,5 ao começar a sangrar, 1 crítico, 1,5 morte); dir = para onde o golpe empurra.
## Vista de cima: cada gota anda no chão (o leque abre-se para os lados de dir) e tem a sua altura (extra) e velocidade
## a subir (chão), que a gravidade puxa até 0; a 0,6 da velocidade da biblioteca para o jorro ficar perto do monstro.
func _blood_ready(C: Array) -> void:
	dur = 1.0 + STAIN_LIFE + 1.0
	var n := radius
	var a0 := dir.angle()
	for i in 7:
		var u := (i - 3) / 3.0
		shape.append([a0 + u * 0.62 + rng.randf_range(-0.08, 0.08), (11.0 + 7.0 * (1.0 - absf(u)) + rng.randf_range(-2.0, 3.0)) * Pix.S, (1.3 + 0.6 * (1.0 - absf(u))) * Pix.S])
	for i in roundi(46.0 * n * amount):
		var s := 3 if rng.randf() < 0.12 else 2 if rng.randf() < 0.35 else 1
		var wait := rng.randf_range(0.0, 0.07)
		var sp := (rng.randf_range(260.0, 950.0) if s == 1 else rng.randf_range(200.0, 650.0) if s == 2 else rng.randf_range(150.0, 460.0)) * (1.0 - wait * 4.0)
		var a := a0 + rng.randf_range(-1.0, 1.0) * rng.randf_range(0.1, 0.65) * (1.2 if s == 1 else 0.8)
		_add(DROP, Vector2(0, ground) + dir * rng.randf_range(0.0, 16.0), Vector2.from_angle(a) * sp * 0.6, 3.0, C[1] if rng.randf() < 0.5 else C[2], s, wait, rng.randf_range(20.0, 150.0), ground)
	for i in roundi(14.0 * n * amount):  # o jacto: gotas rápidas num cone estreito
		_add(DROP, Vector2(0, ground), Vector2.from_angle(a0 + rng.randf_range(-0.12, 0.12)) * rng.randf_range(620.0, 1050.0) * 0.6, 3.0, C[2], 2.0 if rng.randf() < 0.25 else 1.0, i / 14.0 * 0.05, rng.randf_range(0.0, 60.0), ground)
	if amount > 0.5:
		for i in roundi(6.0 * sqrt(n)):
			_add(MIST, dir * rng.randf_range(4.0, 28.0), Vector2.from_angle(a0 + rng.randf_range(-0.5, 0.5)) * rng.randf_range(30.0, 110.0) - Vector2(0, 12), rng.randf_range(0.35, 0.6), C[3], rng.randf_range(2.5, 5.0), rng.randf_range(0.0, 0.05))


func _draw_blood(C: Array) -> void:
	if t >= 0.09:
		return
	var grow := Pix.out_cubic(t / 0.045)
	var brk := clampf((t - 0.04) / 0.05, 0.0, 1.0)  # os fios partem-se da ferida para fora
	for coat in 2:
		for s in shape:
			var l: float = s[1] * grow
			var d0 := l * brk
			var w: float = s[2] * (1.0 - brk * 0.5) + (1.4 if coat == 0 else 0.0)
			var q := Transform2D(s[0], Vector2.ZERO)
			var tip := 1.0 + (1.4 if coat == 0 else 0.0)
			draw_primitive(PackedVector2Array([q * Vector2(d0, -w), q * Vector2(l, -tip), q * Vector2(l, tip), q * Vector2(d0, w)]), PackedColorArray([C[4] if coat == 0 else C[2]]), PackedVector2Array())
			if coat == 1 and brk < 0.35:
				draw_primitive(PackedVector2Array([q * Vector2(d0, -w), q * Vector2(l * 0.35, -w * 0.7), q * Vector2(l * 0.35, w * 0.7), q * Vector2(d0, w)]), PackedColorArray([C[1]]), PackedVector2Array())
	if t < 0.035:
		Pix.disc(self, Vector2.ZERO, 2.6, C[1])
		Pix.disc(self, Vector2.ZERO, 1.5, C[0])


## Gota que tocou no chão: mancha deitada (1 a 3 linhas, inclinada pela velocidade, 0 a 2 salpicos ao lado);
## as grandes atiram 1 a 3 gotinhas que voltam a cair.
func _splat(i: int, p: Array) -> void:
	var v: Vector2 = p[2] - Vector2(0, p[8])
	var sp := v.length()
	var sd := 1.0 if v.x >= 0.0 else -1.0
	var s: float = p[6]
	var crown: bool = p[4] < 1.0
	var w := (0.5 + minf(0.6, sp / 1200.0) if s == 1.0 else s * 0.6 + minf(0.9, sp / 800.0)) * (0.5 if crown else 1.0)
	var sats := 2 if s >= 2.0 and sp > 350.0 else 1 if sp > 450.0 else 0
	parts[i] = [STAIN, p[1], Vector2(w, minf(1.0, absf(v.x) / 400.0)), t, sats, p[5], sd, 0.0, 1.0 if rng.randf() < 0.3 else 0.0, 0.0]
	stain_due = 0.0
	if not crown and s >= 2.0 and sp > 260.0:
		for k in rng.randi_range(1, 3):
			_add(DROP, p[1], Vector2(sd * rng.randf_range(10.0, 130.0) + rng.randf_range(-70.0, 70.0), rng.randf_range(-40.0, 40.0)) * 0.6, 0.8, p[5], 1.0, 0.0, rng.randf_range(80.0, 170.0), 0.0)


func _stain(ci: CanvasItem, p: Array, C: Array) -> void:
	var age: float = t - p[3]
	var fade := 1.0 - clampf(age - STAIN_LIFE, 0.0, 1.0)
	if fade <= 0.0:
		return
	# a próxima mudança desta mancha: alastra a cada frame; depois seca um tom ou desvanece, no máximo 15 vezes por segundo
	var due := t
	if age >= 0.12:
		due = t + 1.0 / 15.0
		for at in STAIN_STEPS:
			if age < at:
				due = maxf(due, p[3] + at)
				break
	stain_due = minf(stain_due, due)
	var w: float = p[2].x
	var lean: float = p[2].y
	var sd: float = p[6]
	var spread := Pix.smooth(0.0, 0.12, age)
	var hw := w * (0.55 + 0.45 * spread)
	var dry := mini(4, (1 if age < 0.35 else 2 if age < 1.4 else 3 if age < 3.2 else 4) + int(p[8]))
	var body := Color(C[dry], fade)
	var low := Color(C[mini(5, dry + 1)], fade)
	var o := Pix.cell(p[1])
	var x0 := -hw * (1.0 - 0.3 * lean)
	var x1 := hw * (1.0 + 0.8 * lean)
	var c0 := floori(x0 if sd > 0.0 else -x1)
	var c1 := ceili(x1 if sd > 0.0 else -x0)
	var cells := c1 - c0 + 1
	ci.draw_rect(Rect2(o + Vector2(c0 * Pix.S, 0), Vector2(cells * Pix.S, Pix.S)), body)
	if w > 1.0:
		ci.draw_rect(Rect2(o + Vector2(c0 * Pix.S, 0), Vector2(Pix.S, Pix.S)), low)
		ci.draw_rect(Rect2(o + Vector2(c1 * Pix.S, 0), Vector2(Pix.S, Pix.S)), low)
	if w > 1.6:  # por baixo, mais escura
		var k := ceili(cells * 0.6)
		ci.draw_rect(Rect2(o + Vector2((c0 + (cells - k) / 2) * Pix.S, Pix.S), Vector2(k * Pix.S, Pix.S)), low)
	if w > 2.2:
		var k := ceili(cells * 0.45)
		ci.draw_rect(Rect2(o + Vector2((c0 + (cells - k) / 2) * Pix.S, -Pix.S), Vector2(k * Pix.S, Pix.S)), Color(C[1], fade) if age < 1.0 else body)
	if age < 0.4 and w > 1.0:
		Pix.px(ci, o + Vector2(-sd * hw * 0.3 * Pix.S, 0), Color(C[0], fade))
	for k in int(p[4]):
		Pix.px(ci, o + Vector2(sd * (hw * (1.0 + 0.6 * lean) + (1.5 + 2.0 * k) * spread) * Pix.S, 0), body)


## Esquiva: poeira e fumo de cinzas onde parte, riscos de velocidade atrás do herói e a derrapagem onde chega.
## radius = distância do salto, dir = para onde. Os fantasmas do herói desenha-os ele (player.gd, do dash_cd).
func _dash_ready() -> void:
	dur = 1.0
	var ash: Array = Pix.RAMPS.ash
	for i in roundi(14.0 * amount):  # poeira que salta dos pés
		_add(DUST, Vector2(rng.randf_range(-6.0, 6.0), -2.0), Vector2.from_angle(rng.randf() * TAU) * rng.randf_range(32.0, 176.0) * Vector2(1.0, SQUASH) - Vector2(0, rng.randf_range(5.0, 45.0)), rng.randf_range(0.3, 0.65), ash[2], rng.randf_range(1.3, 2.8))
	var end := dir * radius
	for i in roundi(8.0 * amount):  # derrapa: poeira atirada para a frente quando chega
		_add(DUST, end + dir * 16.0 + Vector2(0, -2), dir * rng.randf_range(60.0, 260.0) - Vector2(0, rng.randf_range(20.0, 90.0)), rng.randf_range(0.4, 0.8), ash[2], rng.randf_range(1.5, 3.0), DASH_T)
	if amount <= 0.5:
		return
	for i in roundi(8.0 * amount):  # fumo de cinzas atirado para trás
		_add(SMOKE, Vector2(rng.randf_range(-6.0, 6.0), -rng.randf_range(2.0, 12.0)), -dir * rng.randf_range(80.0, 260.0) - Vector2(0, rng.randf_range(10.0, 50.0)), rng.randf_range(0.6, 1.1), ash[3], rng.randf_range(3.0, 6.0))
	var side := dir.orthogonal()
	var n := roundi(16.0 * amount)
	for i in n:  # riscos de velocidade: nascem atrás de onde o herói está nesse instante
		var at := dir * radius * float(i) / n - dir * rng.randf_range(8.0, 32.0) + side * rng.randf_range(-10.0, 10.0) - Vector2(0, rng.randf_range(4.0, 88.0))
		_add(LINE, at, -dir * rng.randf_range(32.0, 128.0), 0.2, Color.WHITE, 1.0, DASH_T * float(i) / n)


func _draw_dash(C: Array) -> void:
	if t < 0.08:  # o clarão e o anel no chão onde parte
		var k := t / 0.08
		Pix.ellipse(self, Vector2.ZERO, 10.0 * (0.5 + k) * Pix.S, 2.5 * (0.5 + k) * Pix.S, Color(C[0], 1.0 - k))
		var rx := (6.0 + 18.0 * k) * Pix.S
		Pix.loop(self, Vector2.ZERO, rx, rx * SQUASH, C[2], 1, false, 4 if k < 0.5 else 2)


## Explosão sem fogo (Espasmo Cadavérico, Alma Meteórica): clarão, dois anéis, onda no chão, faíscas, terra e pedras de
## osso que saltam e assentam, fumo da cor do estado. radius = tamanho (cadáver 0,7, Meteórica 1,4); color = anéis e clarão.
func _explosion_ready(C: Array) -> void:
	var rad := 36.0 * radius
	var power := 0.9 * pow(radius, 0.8)
	var earth := 1.0 if radius < 1.0 else 2.0
	var bone: Array = Pix.RAMPS.bone
	dur = 2.4 + rad / 60.0
	var mid := Vector2(0, -rad * 0.3)
	if amount > 0.5:  # fumo e poeira só nos efeitos médios e altos
		for i in 5 + roundi(10.0 * power * amount):
			var a := rng.randf() * TAU
			_add(SMOKE, mid + Vector2.from_angle(a) * rng.randf_range(0.1, 0.6) * rad, Vector2.from_angle(a) * rng.randf_range(30.0, 200.0) * Vector2(1.0, 0.6) - Vector2(0, 60), rng.randf_range(1.0, 2.2), C[C.size() - 3], rng.randf_range(0.13, 0.22) * rad, rng.randf_range(0.0, 0.3))
		for i in roundi(rad * 0.5 * amount):  # poeira rente ao chão, para os lados
			var a := rng.randf() * TAU
			_add(SMOKE, Vector2.from_angle(a) * rng.randf_range(0.0, 0.6) * rad * Vector2(1.0, SQUASH), Vector2.from_angle(a) * rng.randf_range(3.0, 9.5) * rad * Vector2(1.0, SQUASH), rng.randf_range(1.1, 2.2), C[3], rng.randf_range(3.0, 5.0) + rad / 24.0, rng.randf_range(0.0, 0.06))
	for i in roundi(minf(50.0, 80.0 * power) * amount):
		_add(SPARK, mid, Vector2.from_angle(rng.randf() * TAU) * rng.randf_range(320.0, 1200.0) * power * Vector2(1.0, 0.7) - Vector2(0, 140), rng.randf_range(0.18, 0.7), bone[1], 1.0, 0.0, _jitter())
	# vista de cima: a terra salta menos alto que na de lado (0,7 e 0,8) e cai espalhada por uma elipse no chão
	for i in roundi(minf(earth * rad * 2.6, 120.0) * amount):
		var u := rng.randf_range(-1.0, 1.0)
		var col: Color = [bone[2], bone[3], bone[3], bone[5]][rng.randi() % 4]
		_add(GRIT, Vector2(u * 0.25 * rad, -2), Vector2.from_angle(-PI / 2.0 + u * 0.9) * rng.randf_range(6.0, 19.0) * rad * 0.7 * (1.0 - 0.45 * absf(u)), rng.randf_range(1.2, 2.2), col, 2.0 if rng.randf() < 0.45 else 1.0, 0.0, ground + rng.randf_range(-0.6, 0.6) * rad * SQUASH)
	for i in maxi(4, roundi((12.0 if radius < 1.0 else 26.0) * amount)):
		_add(ROCK, Vector2(rng.randf_range(-0.4, 0.4) * rad, -6), Vector2(rng.randf_range(-9.0, 9.0) * rad * 0.4, -rng.randf_range(7.0, 16.0) * rad * 0.8), rng.randf_range(1.8, 2.6) + rad / 60.0, bone[3], rng.randi_range(1, 3), 0.0, ground + rng.randf_range(-0.5, 0.5) * rad * SQUASH, rng.randf() * TAU)


func _draw_explosion(ci: CanvasItem, front: bool) -> void:
	var rad := 36.0 * radius
	var mid := Vector2(0, -rad * 0.3)
	if not front and radius > 1.0:  # a cratera de fuligem (Meteórica)
		var a := 1.0 - Pix.smooth(dur - 0.8, dur, t)
		var grow := minf(1.0, t / 0.08)
		Pix.haze(ci, Vector2.ZERO, 22.0 * radius * grow * Pix.S, 22.0 * radius * grow * Pix.S * SQUASH, SOOT2, 0.85 * a, false)
		Pix.haze(ci, Vector2.ZERO, 13.0 * radius * grow * Pix.S, 13.0 * radius * grow * Pix.S * SQUASH, Pix.SOOT, a, false)
	var k := t / 0.5
	if k < 1.0:  # a onda no chão: a metade de trás por baixo de todos, a da frente por cima
		var bone: Array = Pix.RAMPS.bone
		var col: Color = [Color.WHITE, color.lightened(0.5), color, bone[2], bone[4]][mini(4, int(k * 5.0))]
		var wave := 80.0 * radius * Pix.S * Pix.out_cubic(k)
		Pix.arc(ci, Vector2.ZERO, wave, wave * SQUASH, 0.25 if front else 0.75, 0.75 if front else 1.25, Color(col, minf(1.0, 1.15 - k)), 2 if k < 0.5 else 1)
	if not front:
		return
	if t < 0.06:
		var f := 1.0 - t / 0.06
		var r := rad * 1.05 * (0.8 + 0.2 * f) / Pix.S
		Pix.disc(ci, mid, r + 1.2, color.darkened(0.3))
		Pix.disc(ci, mid, r, color.lightened(0.6) if f > 0.45 else color.lightened(0.3))
		Pix.disc(ci, mid, r * 0.6, Color.WHITE if f > 0.45 else color.lightened(0.6))
	for g in [[0.45, 2.7, 0.34, 3.0, color.lightened(0.45)], [0.3, 1.6, 0.22, 1.8, color]]:
		if t < g[2]:
			var f: float = 1.0 - t / g[2]
			var gr: float = rad * (g[0] + (g[1] - g[0]) * (1.0 - f * f * f))
			Pix.loop(ci, mid, gr, gr, g[4], maxi(1, roundi(g[3] * f)), false, 4 if f > 0.4 else 3 if f > 0.2 else 2)


## Pilar de luz da subida de nível (o holy-light): uma linha fina e estrelas a convergir, e aos 0,42 s a coluna de alma
## cai do topo da vista até aos pés, com fios, faixas a descer, auréolas a subir, anéis no chão e estrelas douradas.
## Fica 0,9 s (para o combate continuar legível), estreita e apaga-se.
const SLAM := 0.42
const NARROW := SLAM + 0.9
const OUT := NARROW + 0.5
const PW := 13.0  # meia largura da coluna, em células
const PBANDS := [[1.3, 4], [0.88, 3], [0.66, 2], [0.42, 1], [0.2, 0]]  # de fora para dentro: até onde vai e o tom


func _pillar_ready() -> void:
	dur = OUT + 0.5
	for i in 11:  # fios mais escuros que ondulam dentro da coluna
		shape.append([rng.randf_range(-0.85, 0.85), rng.randf_range(0.04, 0.11), rng.randf_range(1.0, 3.0)])


func _pillar_w() -> float:
	if t < SLAM:
		return 0.0
	if t < NARROW:
		return PW * (1.0 + 0.35 * exp(-(t - SLAM) * 9.0))
	return lerpf(PW, 0.6, Pix.out_cubic((t - NARROW) / 0.4))


func _pillar_step(delta: float, C: Array) -> void:
	var gold: Array = Pix.RAMPS.gold
	var stars := [Color.WHITE, gold[1], gold[2], C[2]]
	if t >= SLAM and t - delta < SLAM:  # a coluna bate no chão
		get_parent().shake = maxf(get_parent().shake, 6.0)
		for i in roundi(50.0 * amount):
			var s := 1.0 if rng.randf() < 0.5 else -1.0
			_add(STAR, Vector2(s * rng.randf_range(0.0, 20.0), -4), Vector2(s * rng.randf_range(120.0, 520.0), -rng.randf_range(40.0, 260.0)), rng.randf_range(0.4, 1.0), stars[rng.randi() % 4], rng.randf_range(0.8, 2.2), 0.0, INF, rng.randf() * 100.0)
	var w := _pillar_w()
	if t > SLAM and t < OUT:
		for i in 2:
			if _chance(0.7 * amount * clampf(w / PW, 0.0, 1.0), delta):
				_add(STAR if rng.randf() < 0.7 else BOKEH, Vector2(rng.randf_range(-w, w) * Pix.S * 1.4, -rng.randf_range(0.0, 200.0)), Vector2(rng.randf_range(-10.0, 10.0), -rng.randf_range(60.0, 170.0)), rng.randf_range(0.6, 1.3), stars[rng.randi() % 4], rng.randf_range(0.7, 2.0), 0.0, INF, rng.randf() * 100.0)
	elif t < SLAM and _chance(0.4 * amount, delta):  # estrelas que convergem para os pés antes da coluna
		var at := Vector2.from_angle(rng.randf() * TAU) * rng.randf_range(40.0, 90.0) * Vector2(1.0, SQUASH)
		_add(STAR, at - Vector2(0, 6), -at * 2.5, 0.38, gold[2], rng.randf_range(0.6, 1.2), 0.0, INF, rng.randf() * 100.0)


func _view_top() -> float:  # o topo da vista em y local: a coluna cai do céu, de fora do ecrã
	return minf(-120.0, Pix.cell(Vector2(0, (get_canvas_transform().affine_inverse() * Vector2.ZERO).y - global_position.y - 4.0)).y)


func _draw_pillar_under(C: Array) -> void:
	var gl := Pix.smooth(0.0, SLAM, t) * 0.5 if t < SLAM else 1.0 - Pix.smooth(NARROW, OUT, t)
	if gl > 0.01:  # o brilho no chão: elipses do escuro (fora) ao claro (dentro)
		var rx := (10.0 + (14.0 * t if t < SLAM else 34.0 + 4.0 * sin(t * 5.0))) * Pix.S
		for e in [[minf(1.0, gl * 1.15), 4, 0.5], [minf(1.0, gl * 0.9), 3, 0.85], [gl * 0.65, 2, 1.0], [gl * 0.35, 1, 1.0]]:
			Pix.ellipse(under, Vector2.ZERO, rx * e[0], rx * e[0] * SQUASH, Color(C[e[1]], e[2]))
	var top := _view_top()
	if t < SLAM:  # a linha-guia que desce do céu
		var a := Pix.smooth(0.0, SLAM * 0.8, t) * 0.7
		under.draw_primitive(PackedVector2Array([Vector2(0, top), Vector2(Pix.S, top), Vector2(Pix.S, 0), Vector2(0, 0)]),
			PackedColorArray([Color(C[1], a * 0.4), Color(C[1], a * 0.4), Color(C[1], a), Color(C[1], a)]), PackedVector2Array())
		return
	var w := _pillar_w()
	if w <= 0.05 or t > OUT + 0.2:
		return
	var fade := 1.0 - Pix.smooth(OUT - 0.25, OUT + 0.2, t)
	var end := 0.0
	if t - SLAM < 0.07:  # a coluna cai do céu em 0,07 s
		end = Pix.cell(Vector2(0, lerpf(top, 0.0, pow(clampf((t - SLAM) / 0.07, 0.0, 1.0) * 0.5 + 0.5, 3.0)))).y
	_pillar_bands(C, w, top, end, 0, fade)
	var off := fposmod(t * 1.9, 1.0) * 50.0 * Pix.S
	for j in range(-1, ceili(-top / (50.0 * Pix.S)) + 1):  # faixas mais claras que descem
		var y := Pix.cell(Vector2(0, top + off + j * 50.0 * Pix.S)).y
		if y >= top and y < end:
			_pillar_bands(C, w, y, minf(end, y + 4.0 * Pix.S), 1, fade)
	for s in shape:
		var x: float = (s[0] + 0.05 * sin(t * s[2] + s[0] * 9.0)) * w
		var lvl: int = 4
		for b in PBANDS:
			if absf(x) / w < b[0]:
				lvl = b[1]
		var hw := maxf(1.0, roundf(s[1] * w))
		under.draw_rect(Rect2(floorf(x - hw * 0.5) * Pix.S, top, hw * Pix.S, end - top), Color(C[maxi(0, lvl - 1)], fade))
	var gold: Array = Pix.RAMPS.gold
	for h0 in [SLAM, SLAM + 0.42, SLAM + 0.84]:  # auréolas douradas que sobem pela coluna
		var k: float = (t - h0) / 0.9
		if k < 0.0 or k > 1.0:
			continue
		var hr: float = w * Pix.S * 1.35 * (1.0 + 0.3 * k)
		Pix.loop(under, Vector2(0, -8.0 + k * top * 0.9), hr, hr * SQUASH, Color(Color.WHITE if k < 0.3 else gold[1], fade), 1, false, 4 if k < 0.5 else 3 if k < 0.75 else 2)


## As faixas verticais da coluna, de fora para dentro; shift 1 clareia um tom (as faixas que descem).
func _pillar_bands(C: Array, w: float, y0: float, y1: float, shift: int, fade: float) -> void:
	if y1 <= y0:
		return
	var hw := ceilf(1.3 * w) * Pix.S
	under.draw_rect(Rect2(-hw, y0, hw * 2.0, y1 - y0), Color(C[4 - shift], 0.35 * fade))  # a orla, meio transparente
	for b in PBANDS:
		hw = ceilf(b[0] * (0.84 if b[1] == 4 else 1.0) * w) * Pix.S
		under.draw_rect(Rect2(-hw, y0, hw * 2.0, y1 - y0), Color(C[maxi(0, b[1] - shift)], (0.7 if b[1] == 4 else 1.0) * fade))


func _draw_pillar() -> void:
	for i in 2:  # dois anéis no chão quando a coluna bate
		var k := (t - SLAM - 0.1 * i) / 0.55
		if k < 0.0 or k > 1.0:
			continue
		var e := Pix.out_cubic(k) * (0.7 if i == 1 else 1.0)
		var r := (14.0 + 90.0 * e) * Pix.S
		Pix.loop(self, Vector2.ZERO, r, r * SQUASH, Color.WHITE if k < 0.25 else Pix.RAMPS.gold[2], 2 if k < 0.4 else 1, k < 0.4, 5 if k < 0.6 else 3 if k < 0.8 else 2)


## Saque apanhado (o pickup): o ícone sobe, voa em arco para o peito do herói e rebenta num clarão com um anel e
## faíscas que voltam para ele (cada 3.ª que chega faz um anelzinho). radius = faíscas (0 um osso solto, 6 comum,
## 10 tinteiro, 14 cinzas e frascos, estes com uma estrela).
const P_LIFT := 0.06
const P_FLY := 0.18
const P_POP := P_LIFT + P_FLY


func _pickup_at() -> Vector2:  # onde vai o ícone
	if t < P_LIFT:
		return Vector2(0, -8.0 - 8.0 * Pix.out_cubic(t / P_LIFT))
	var u := pow(clampf((t - P_LIFT) / P_FLY, 0.0, 1.0), 2.2)
	var s := Vector2(0, -16)
	var m := Vector2((s.x + aim.x) / 2.0, minf(s.y, aim.y) - maxf(40.0, s.distance_to(aim) * 0.35))
	return s.lerp(m, u).lerp(m.lerp(aim, u), u)


func _pickup_step(C: Array) -> void:
	if t < P_POP:
		shape.push_front(_pickup_at())
		if shape.size() > 7:
			shape.pop_back()
		return
	if popped:
		return
	popped = true
	shape = [aim]  # onde rebentou
	_add(RING, aim, Vector2.ZERO, 0.4, C[2], 20.0)
	var n := roundi(radius * amount)
	for i in n:
		var a := i * TAU / n + rng.randf_range(-0.2, 0.2)
		_add(HOME, aim, Vector2.from_angle(a) * rng.randf_range(150.0, 300.0) - Vector2(0, 40), rng.randf_range(0.75, 1.05), C[rng.randi() % 3], 2.0 if rng.randf() < 0.4 else 1.0, 0.0, INF, [])


func _draw_pickup(C: Array) -> void:
	if t < P_POP:
		for i in range(1, shape.size()):  # o rasto do voo
			Pix.line(self, shape[i - 1], shape[i], C[2] if i < 3 else C[3])
		return
	var k := t - P_POP
	if k < 0.08:
		Pix.disc(self, shape[0], 7.0 * (1.0 - k / 0.08) + 1.0, C[0])
	if radius >= 14.0 and k < 0.5:  # os raros rebentam também numa estrela
		Pix.flare(self, shape[0], 10.0 * sin(k / 0.5 * PI), k * 2.0, Pix.RAMPS.gold[2], Pix.RAMPS.gold[3])


func _draw_mid() -> void:
	if kind == "pickup":
		var tex: Texture2D = Loot.FLASK_TEX[item] if Loot.FLASK_TEX.has(item) else Loot.TEX.get(item)
		var k := t - P_POP
		if tex == null or k >= 0.1:
			return
		var sc := Vector2(1.5, 0.6) if k >= 0.0 and k < 0.05 else Vector2(0.7, 1.45)  # esmagado ao rebentar
		if k < 0.0:  # esticado ao subir e a encolher no voo
			var fly := clampf((t - P_LIFT) / P_FLY, 0.0, 1.0)
			var lift := Pix.out_cubic(t / P_LIFT) if t < P_LIFT else 0.0
			sc = Vector2(1.0 - 0.25 * fly, 1.0 - 0.25 * fly) * Vector2(1.0 - 0.15 * lift, 1.0 + 0.2 * lift)
		var s := 38.0 / maxf(tex.get_width(), tex.get_height())
		mid.draw_set_transform(_pickup_at() if k < 0.0 else shape[0], 0.0, sc * s)
		mid.draw_texture(tex, -tex.get_size() / 2.0, Loot.TINT.get(item, Color.WHITE))  # os reagentes na cor deles
		mid.draw_set_transform(Vector2.ZERO)
		return
	# Cura: três faixas de luz sobem pelo desenho do herói (a silhueta numa cor, só as linhas da faixa)
	var h = _hero()
	if h == null or h.pose_tex == null:
		return
	var C := Pix.ramp(ramp)
	var k := Pix.smooth(0.0, 0.25, t) * _heal_fade()
	var tex: Texture2D = h.pose_tex
	var inv: Transform2D = h.pose.affine_inverse()
	mid.draw_set_transform_matrix(global_transform.affine_inverse() * h.global_transform * h.pose)
	for p0 in [0.1, 0.65, 1.2]:
		var q: float = (t - p0) / 0.4
		if q < 0.0 or q > 1.3:
			continue
		var yb := 4.0 - q * 112.0  # dos pés até acima da cabeça
		for b in [[0.0, 2.0, Color.WHITE, 1.5], [2.0, 8.0, C[1], 1.1], [8.0, 20.0, C[2], 0.45]]:
			var y0 := clampf((inv * Vector2(0, yb + b[0])).y, 0.0, tex.get_height())
			var y1 := clampf((inv * Vector2(0, yb + b[1])).y, 0.0, tex.get_height())
			if y1 - y0 >= 0.5:
				var r := Rect2(0, y0, tex.get_width(), y1 - y0)
				mid.draw_texture_rect_region(tex, r, r, Color(b[2], minf(1.0, k * b[3])))
	mid.draw_set_transform(Vector2.ZERO)


## Cura das poções (o heal): cruzes vermelhas (vida) ou gotas azuis (alma) que sobem a ondular, linha de luz nos pés,
## faixas pelo herói, riscos (vida) ou uma hélice com bolhas (alma). Segue o herói. radius = quantos glifos.
func _heal_ready() -> void:
	dur = 2.8
	for i in roundi(radius * maxf(0.5, amount)):
		_add(GLYPH, Vector2(rng.randf_range(-46.0, 46.0), -rng.randf_range(4.0, 70.0)), Vector2(0, -rng.randf_range(50.0, 90.0)), rng.randf_range(1.0, 1.4), Color.WHITE, 1.0 if rng.randf() < 0.45 else 0.0, 0.06 + i * 0.085 + rng.randf_range(0.0, 0.05), INF, rng.randf() * 1000.0)


func _heal_step(delta: float, C: Array) -> void:
	if t < 2.0 and _chance(0.45 * amount, delta):
		var big := rng.randf() < 0.3
		_add(STAR, Vector2(rng.randf_range(-34.0, 34.0), -rng.randf_range(0.0, 76.0)), Vector2(rng.randf_range(-8.0, 8.0), -rng.randf_range(30.0, 80.0)), rng.randf_range(0.5, 0.95), C[1] if rng.randf() < 0.5 else C[2], rng.randf_range(1.6, 2.6) if big else rng.randf_range(0.4, 0.9), 0.0, INF, rng.randf() * 100.0)
	if ramp == "soulblue" and t < 1.9 and _chance(0.16 * amount, delta):
		_add(BUBBLE, Vector2(rng.randf_range(-30.0, 30.0), -rng.randf_range(0.0, 40.0)), Vector2(0, -rng.randf_range(60.0, 110.0)), rng.randf_range(0.6, 1.1), C[2], 2.0 if rng.randf() < 0.3 else 1.0, 0.0, INF, rng.randf() * 10.0)


func _heal_fade() -> float:
	return 1.0 - Pix.smooth(1.9, 2.7, t)


func _draw_heal(ci: CanvasItem, front: bool, C: Array) -> void:
	var f := _heal_fade()
	var k := f * Pix.smooth(0.0, 0.25 if front else 0.2, t)
	if ramp == "soulblue":
		_helix(ci, front, C, k)
	elif not front:  # riscos de luz que sobem atrás do herói
		for i in roundi(22.0 * amount):
			var ph := fposmod(t * (1.1 + Pix.hashf(i, 3) * 0.8) + Pix.hashf(i, 1), 1.0)
			var at := Pix.cell(Vector2((Pix.hashf(i, 2) - 0.5) * 34.0 * (1.0 - ph * 0.3), -2.0 - ph * 74.0) * Pix.S)
			var a := sin(ph * PI) * k
			ci.draw_rect(Rect2(at, Vector2(Pix.S, Pix.S)), Color(C[1], a))
			ci.draw_rect(Rect2(at + Vector2(0, Pix.S), Vector2(Pix.S, Pix.S * 2.0)), Color(C[2], a * 0.75))
			ci.draw_rect(Rect2(at + Vector2(0, Pix.S * 3.0), Vector2(Pix.S, Pix.S * 2.0)), Color(C[4], a * 0.4))
	if not front:
		return
	# A linha de luz nos pés, que se abre em 0,45 s, e as faíscas que sobem dela
	var w := 19.5 * (1.0 - pow(1.0 - clampf(t / 0.45, 0.0, 1.0), 3.0))
	for b in [[1.0, 3, 0.45, 0], [0.65, 2, 0.8, 0], [0.3, 1, 1.0, 0], [0.75, 3, 0.25, -1], [0.35, 2, 0.35, -1]]:
		var hw := ceilf(w * b[0]) * Pix.S
		ci.draw_rect(Rect2(-hw, b[3] * Pix.S, hw * 2.0, Pix.S), Color(C[b[1]], f * b[2]))
	for i in 8:
		var ph := fposmod(t * (0.9 + Pix.hashf(i, 1) * 0.6) + Pix.hashf(i, 2), 1.0)
		var x := (Pix.hashf(i, 3) - 0.5) * 2.0 * w * Pix.S
		var a := sin(ph * PI) * f
		Pix.px(ci, Vector2(x, (-1.0 - ph * 22.0) * Pix.S), Color(Color.WHITE if ph < 0.25 else C[1], a))
		Pix.px(ci, Vector2(x, -ph * 22.0 * Pix.S), Color(C[2], a * 0.6))


## Hélice de dois fios pontilhados que sobe 70 células à volta do herói: a metade de trás por baixo, a da frente por cima.
func _helix(ci: CanvasItem, front: bool, C: Array, k: float) -> void:
	if k <= 0.0:
		return
	for s in 2:
		for i in 4:
			var ph := fposmod(t * 0.5 + i / 4.0 + s * 0.125, 1.0)
			var a := sin(ph * PI) * k
			var rx := 17.0 - ph * 7.0
			for d in 14:
				var th := ph * TAU * 1.6 + s * PI + t * 2.4 - d * 0.13
				if (sin(th) >= 0.0) != front:
					continue
				var at := Vector2(cos(th) * rx, -3.0 - ph * 70.0 + d * 0.7) * Pix.S
				var ad := a * (1.0 - d / 15.0) * (1.0 if front else 0.75)
				var c: Color = (Color.WHITE if d < 1 else C[1] if d < 4 else C[2] if d < 8 else C[3]) if front else C[3] if d < 5 else C[4]
				Pix.px(ci, at, Color(c, ad))
				if front and d < 6:
					Pix.px(ci, at + Vector2(0, Pix.S), Color(C[2] if d < 3 else C[3], ad))


func _step(delta: float) -> void:
	match kind:
		"pillar":
			_pillar_step(delta, Pix.ramp(ramp))
		"pickup":
			_pickup_step(Pix.ramp(ramp))
		"heal":
			_heal_step(delta, Pix.ramp(ramp))
	var moving := false
	for i in range(parts.size() - 1, -1, -1):
		var p: Array = parts[i]
		if p[0] == STAIN:
			continue
		moving = true
		if p[7] > 0.0:
			p[7] -= delta
			continue
		p[3] -= delta
		if p[3] <= 0.0:
			parts.remove_at(i)
			continue
		var v: Vector2 = p[2]
		match p[0]:
			SPARK:
				v.y += GRAVITY * 0.45 * delta
				v -= v * 2.2 * delta
			MOTE:
				v -= v * 0.6 * delta
			DUST:
				v -= v * 4.0 * delta
				v.y -= 10.0 * delta
			MIST:
				v -= v * 3.0 * delta
				v.y -= 6.0 * delta
			SMOKE:
				v.y -= 40.0 * delta
				v.x += sin(t * 1.3 + p[6]) * 16.0 * delta
				v -= v * Vector2(1.6, 1.2) * delta
			GRIT, ROCK:
				v.y += GRAVITY * delta
				v.x -= v.x * (0.8 if p[0] == GRIT else 0.25) * delta
				if p[0] == ROCK and p[2] != Vector2.ZERO:  # a pedra rola enquanto voa
					p[9] += (p[6] - 2.0) * 7.0 * delta + 3.0 * delta
			DROP:  # no chão anda e trava; a altura cai com a gravidade até tocar
				v -= v * 0.7 / p[6] * delta
				p[8] -= GRAVITY * delta
				p[9] += p[8] * delta
				p[1] += v * delta
				p[2] = v
				if p[9] <= 0.0 and p[8] < 0.0:
					_splat(i, p)
				continue
			LINE, RING:
				continue
			STAR:
				v -= v * 1.6 * delta
				v.y -= 10.0 * delta
			BOKEH:
				v -= v * 0.8 * delta
			GLYPH:  # sobe a ondular
				v.x = sin((p[4] - p[3]) * 4.5 + p[9]) * 16.0
			BUBBLE:
				v.x = sin(t * 7.0 + p[9]) * 22.0
			HOME:  # faísca do saque: abre-se e ao fim de 0,12 s volta para o peito do herói
				var age: float = p[4] - p[3]
				p[9].push_front(p[1])
				if p[9].size() > 5:
					p[9].pop_back()
				if age > 0.12:
					var to: Vector2 = aim - p[1]
					var d := to.length()
					if d < 9.0 and age - delta > 0.12:  # já voltava no frame anterior (um frame longo não as come à saída)
						parts.remove_at(i)
						if absorbed % 3 == 0:
							_add(RING, aim, Vector2.ZERO, 0.4, p[5], 12.0)
						absorbed += 1
						for k in 2:
							_add(STAR, aim + Vector2(rng.randf_range(-10.0, 10.0), rng.randf_range(-14.0, 10.0)), Vector2(rng.randf_range(-12.0, 12.0), -rng.randf_range(30.0, 80.0)), rng.randf_range(0.4, 0.8), p[5], 1.0 if rng.randf() < 0.3 else 0.5, 0.0, INF, rng.randf() * 100.0)
						continue
					v += (to / maxf(d, 0.01) * (380.0 + 900.0 * age) - v) * minf(1.0, delta * (3.0 + 22.0 * age))
				else:
					v -= v * 3.0 * delta
					v.y += 60.0 * delta
		var was: float = p[1].y
		p[1] += v * delta
		p[2] = v
		if v.y <= 0.0 or was > p[8] or p[1].y < p[8]:
			continue
		match p[0]:  # tocou no chão
			SPARK:
				p[2] = Vector2(v.x * 0.7, -v.y * 0.45)
				p[1].y = p[8] - 1.0
			GRIT, ROCK:
				p[1].y = p[8]
				if v.y > (260.0 if p[0] == GRIT else 140.0):
					p[2] = Vector2(v.x * 0.5, -v.y * (0.25 if p[0] == GRIT else 0.32))
				else:
					p[2] = Vector2.ZERO
					if p[0] == GRIT:
						p[3] = minf(p[3], 0.5)
	settled = kind == "blood" and not moving and t >= 0.09  # os fios e o clarão da ferida acabam aos 0,09 s


func _draw_front() -> void:
	var C := Pix.ramp(ramp)
	match kind:
		"impact":
			_draw_impact(C)
		"slash":
			_draw_slash(C)
		"blood":
			_draw_blood(C)
		"dash":
			_draw_dash(C)
		"explosion":
			_draw_explosion(self, true)
		"pillar":
			_draw_pillar()
		"pickup":
			_draw_pickup(C)
		"heal":
			_draw_heal(self, true, C)
	_draw_parts(self, false, C)


func _draw_under() -> void:
	var C := Pix.ramp(ramp)
	if kind == "explosion":
		_draw_explosion(under, false)
	elif kind == "dash" and t >= DASH_T:  # a marca da derrapagem
		var end := dir * radius
		Pix.line(under, end - dir * 70.0, end, Color(SKID, 0.8 * (1.0 - Pix.smooth(0.3, 0.7, t - DASH_T))))
	elif kind == "pillar":
		_draw_pillar_under(C)
	elif kind == "heal":
		_draw_heal(under, false, C)
	stain_due = INF
	_draw_parts(under, true, C)


func _draw_parts(ci: CanvasItem, back: bool, C: Array) -> void:
	var hotc: Array = Pix.RAMPS.bone if kind == "explosion" else C  # as faíscas da explosão são de osso
	for p in parts:
		if p[7] > 0.0 or (p[0] in UNDER) != back:
			continue
		var k: float = p[3] / p[4]
		var at: Vector2 = p[1]
		var v: Vector2 = p[2]
		match p[0]:
			SPARK:
				var sp := maxf(v.length(), 1.0)
				var u := v / sp * Pix.S * minf(9.0, 1.0 + sp * 0.011)
				var hot: Color = hotc[1] if k > 0.6 else hotc[2] if k > 0.3 else hotc[3]
				_seg(at - u, at - u * 0.4, hot if k > 0.5 else hotc[4])
				_seg(at - u * 0.45, at, hot)
			MOTE:
				var sp := maxf(v.length(), 1.0)
				var u: Vector2 = v / sp * Pix.S * minf(16.0, 0.5 + sp * 0.013) * p[6]
				var a := minf(1.0, k / 0.35)
				_seg(at - u, at - u * 0.35, Color(p[5].darkened(0.45), a))
				_seg(at - u * 0.4, at, Color(p[5], a))
			DUST:
				Pix.puff(ci, at, p[6] * (0.6 + (1.0 - k) * 0.9) * Pix.S, p[5], pow(k, 1.3) * 0.9)
			MIST:
				Pix.puff(ci, at, p[6] * (1.6 - 0.6 * k) * Pix.S, p[5], 0.6 * k * minf(1.0, (1.0 - k) * 8.0))
			SMOKE:
				var age := 1.0 - k
				var r: float = p[6] * (0.65 + minf(1.0, age * 2.5) * 0.45 + age * 0.5)
				var a := minf(1.0, age * 12.0) * minf(1.0, k * 2.4)
				Pix.puff(ci, at, r * Pix.S, p[5].darkened(0.3 + age * 0.5), 0.5 * a)
			GRIT:
				var g := ((position + at) / Pix.S).floor()
				if k > 0.25 or Pix.bayer(int(g.x), int(g.y)) < k * 4.0:
					Pix.px(ci, at, p[5], int(p[6]), int(p[6]))
			ROCK:
				var r: float = (0.6 + p[6] * 0.75) * Pix.S
				var q := Transform2D(p[9], at)
				var a := minf(1.0, p[3] / 0.5)
				ci.draw_primitive(_rock(q, r + Pix.S), PackedColorArray([Color(Pix.OUTLINE, a)]), PackedVector2Array())
				ci.draw_primitive(_rock(q, r), PackedColorArray([Color(p[5], a)]), PackedVector2Array())
				ci.draw_primitive(PackedVector2Array([q * Vector2(-r, 0), q * Vector2(0, -r * 0.8), q * Vector2.ZERO]), PackedColorArray([Color(Pix.RAMPS.bone[1], a)]), PackedVector2Array())
			DROP:
				at -= Vector2(0, p[9])
				v -= Vector2(0, p[8])
				var sp := maxf(v.length(), 1.0)
				var tail := minf(6.0, sp * 0.008) * Pix.S
				if tail >= Pix.S:
					Pix.line(ci, at - v / sp * tail, at - v / sp * Pix.S, C[2] if p[6] >= 2.0 else C[3])
				if p[6] >= 3.0:
					Pix.disc(ci, at, 1.7, C[4])
					Pix.disc(ci, at, 1.15, C[1])
				elif p[6] >= 2.0:
					Pix.px(ci, at, C[0])
					Pix.px(ci, at + Vector2(Pix.S, 0), C[1])
					Pix.px(ci, at + Vector2(0, Pix.S), C[2])
					Pix.px(ci, at + Vector2(Pix.S, Pix.S), C[3])
				else:
					Pix.px(ci, at, p[5])
			STAIN:
				_stain(ci, p, C)
			STAR:
				var tw := 0.6 + 0.4 * sin(t * (8.0 + fmod(p[9], 5.0)) + p[9])
				if p[6] < 1.0:
					if tw * k > 0.25:
						Pix.px(ci, at, Color.WHITE if tw > 0.8 else p[5])
				else:
					Pix.sparkle(ci, at, maxi(1, roundi(p[6] * tw * minf(1.0, k * 3.0))), p[5], p[5].darkened(0.25))
			BOKEH:
				var a := minf(1.0, (1.0 - k) * 5.0) * minf(1.0, k * 3.0) * (0.7 + 0.3 * sin(t * (2.0 + fmod(p[9], 3.0)) + p[9]))
				Pix.disc(ci, at, p[6], Color(p[5], 0.45 * a))
				Pix.disc(ci, at, p[6] * 0.5, Color(Color.WHITE, 0.5 * a))
			HOME:
				for j in range(1, p[9].size()):
					Pix.px(ci, p[9][j], Color(C[2] if j < 2 else C[3], 1.0 - j / 5.0))
				var arm := roundi(p[6] * minf(1.0, k * 3.0))
				if arm > 0:
					Pix.sparkle(ci, at, arm, p[5], p[5].darkened(0.2))
				else:
					Pix.px(ci, at, p[5])
			RING:
				var u := 1.0 - k
				var rr: float = (2.0 + p[6] / Pix.S * 2.0 * Pix.out_cubic(u)) * Pix.S
				Pix.loop(ci, at, rr, rr, C[0] if u < 0.3 else p[5], 2 if k > 0.5 else 1, false, 4 if u < 0.6 else 2)
			GLYPH:
				var age: float = p[4] - p[3]
				var glint := sin(age * 14.0 + p[9]) > 0.75
				var tex: ImageTexture
				if ramp == "soulblue":
					tex = Pix.glyph(C, false, 1 if age < 0.05 or p[6] == 0.0 else 0, 0, glint or age < 0.1)
				else:  # a cruz nasce pequena, passa do tamanho e assenta
					var big := 4 if p[6] > 0.0 else 2
					tex = Pix.glyph(C, true, big - 1 if age < 0.05 else big + 1 if age < 0.1 else big, int(p[6]), glint)
				var half := (tex.get_size() / 2.0).floor() * Pix.S
				ci.draw_texture_rect(tex, Rect2(Pix.cell(at) - half, tex.get_size() * Pix.S), false, Color(1, 1, 1, minf(1.0, k / 0.4)))
			BUBBLE:
				if p[3] < 0.07:  # rebenta em quatro pontos
					for d in [Vector2(1, 1), Vector2(-1, 1), Vector2(1, -1), Vector2(-1, -1)]:
						Pix.px(ci, at + d * (p[6] + 1.0) * Pix.S, C[1])
				else:
					var a := minf(1.0, p[3] / 0.3)
					Pix.loop(ci, at, (p[6] + 1.0) * Pix.S, (p[6] + 1.0) * Pix.S, Color(C[2], a))
					Pix.px(ci, at - Vector2(p[6], p[6]) * Pix.S * 0.5, Color(C[1], a))
			LINE:
				var u := 1.0 - k
				var l := v * (1.0 - u * 0.6)
				_seg(at, at + l.limit_length(6.0), Color(C[0], 1.0 - u))
				_seg(at + l.limit_length(6.0), at + l * 0.4, Color(C[1], 0.8 * (1.0 - u)))
				_seg(at + l * 0.4, at + l, Color(C[3], 0.4 * (1.0 - u)))
	if not seg.is_empty():  # por cima das outras partículas desta camada, como já ficavam quase sempre
		_seg_flush(ci, Pix.S)


func _seg_flush(ci: CanvasItem, w: float) -> void:
	ci.draw_multiline_colors(seg, seg_c, w)
	seg.clear()
	seg_c.clear()


## Pix.line para o lote de riscos (draw_multiline_colors no fim de _draw_parts).
func _seg(a: Vector2, b: Vector2, c: Color) -> void:
	seg.append((a / Pix.S).floor() * Pix.S + Vector2.ONE)
	seg.append((b / Pix.S).floor() * Pix.S + Vector2.ONE)
	seg_c.append(c)


func _rock(q: Transform2D, s: float) -> PackedVector2Array:  # pedra de quatro lados, achatada
	return PackedVector2Array([q * Vector2(s, 0), q * Vector2(0, s * 0.8), q * Vector2(-s, 0), q * Vector2(0, -s * 0.8)])


func _draw_lit() -> void:
	var C := Pix.ramp(ramp)
	match kind:
		"impact":
			var pop := exp(-t / 0.05)
			Pix.glow(lit, Vector2.ZERO, (22.0 * radius + 6.0) * Pix.S, C[4], 0.7 * pop)  # o C[3] do osso queimava o ecrã (3 juntos)
			Pix.glow(lit, Vector2.ZERO, (8.0 * radius + 2.0) * Pix.S, C[0], 0.7 * pop)
		"slash":
			var w := radius * 24.0 / 84.0
			if t < 0.3:  # o brilho que segue a cabeça da lâmina
				Pix.glow(lit, _arc_at(radius - 8.0, -ARC + 2.0 * ARC * Pix.out_expo(t / SWEEP)), 80.0 * radius / 84.0, C[3], 0.5 * (1.0 - t / 0.3))
			var g := t - SWEEP * 0.6
			if g > 0.0 and g < 0.22:
				Pix.glow(lit, _arc_at(radius - w * 0.3, ARC), (4.0 + 18.0 * (1.0 - g / 0.22)) * Pix.S, C[1], 0.6)
		"blood":
			if t < 0.09:
				Pix.glow(lit, Vector2.ZERO, 16.0 * Pix.S, C[1], 0.25 * (1.0 - t / 0.09))
		"dash":
			if t < DASH_T + 0.1:  # a luz que acompanha o herói no salto
				Pix.glow(lit, dir * radius * minf(1.0, t / DASH_T) + Vector2(0, -40), 40.0 * Pix.S, C[3], 0.35)
		"explosion":
			var rad := 36.0 * radius
			if t < 0.7:
				var f := 1.0 - t / 0.7
				Pix.glow(lit, Vector2(0, -rad * 0.3), rad * 3.4 * (0.55 + 0.45 * f), color, 0.54 * pow(radius, 0.8) * f * f)
			if t < 0.08:
				Pix.glow(lit, Vector2(0, -rad * 0.3), rad * 1.6, Color.WHITE, 0.6 * (1.0 - t / 0.08) ** 2)
		"pillar":
			var top := _view_top()
			var w := _pillar_w() * Pix.S
			if t < SLAM:
				Pix.glow(lit, Vector2(0, top + 20.0), 80.0, C[3], 0.28 * Pix.smooth(0.0, SLAM * 0.8, t))
				Pix.glow(lit, Vector2.ZERO, (10.0 + 14.0 * t) * Pix.S * 2.2, C[3], 0.25 * Pix.smooth(0.0, SLAM, t))
			elif t < OUT + 0.2:
				var fade := 1.0 - Pix.smooth(OUT - 0.25, OUT + 0.2, t)
				Pix.glow_box(lit, Rect2(-(w * 2.4 + 12.0), top, (w * 2.4 + 12.0) * 2.0, -top), C[2], 0.45 * fade)
				Pix.glow(lit, Vector2(0, top + 16.0), 140.0, C[3], 0.4 * fade)
				Pix.glow(lit, Vector2.ZERO, 34.0 * Pix.S * 2.2, C[3], 0.5 * (1.0 - Pix.smooth(NARROW, OUT, t)))
				if t < SLAM + 0.12:  # o clarão da batida
					Pix.glow(lit, Vector2(0, -40), 280.0, Pix.RAMPS.gold[2], 1.2 * (1.0 - (t - SLAM) / 0.12))
		"pickup":
			if t < P_POP:
				Pix.glow(lit, _pickup_at(), (14.0 + 2.0 * sin(t * 4.0)) * Pix.S, C[3], 0.45 + 0.4 * clampf((t - P_LIFT) / P_FLY, 0.0, 1.0))
			elif t < P_POP + 0.3:
				Pix.glow(lit, shape[0], 30.0 * Pix.S, C[2], (0.35 + 0.025 * radius) * (1.0 - (t - P_POP) / 0.3))  # mais forte quanto mais raro (vários juntos queimavam o herói)
		"heal":
			var f := _heal_fade() * Pix.smooth(0.0, 0.2, t)
			var w := 19.5 * Pix.S * (1.0 - pow(1.0 - clampf(t / 0.45, 0.0, 1.0), 3.0))
			Pix.glow_box(lit, Rect2(-44.0, -178.0, 88.0, 222.0), C[3], 0.45 * f)  # a coluna de luz suave
			Pix.glow_box(lit, Rect2(-w - 20.0, -20.0, (w + 20.0) * 2.0, 40.0), C[3], 0.35 * f)
			for p0 in [0.1, 0.65, 1.2]:  # a luz que acompanha as faixas pelo herói
				var q: float = (t - p0) / 0.4
				if q >= 0.0 and q <= 1.3:
					Pix.glow(lit, Vector2(0, 4.0 - q * 112.0), 28.0, C[2], 0.5 * f * (1.0 - q / 1.3))
	for p in parts:  # os anéis do saque são o clarão do efeito
		if p[0] == RING:
			Pix.glow(lit, p[1], 16.0 * Pix.S, C[2], 0.3 * p[3] / p[4])
	if amount <= 0.7:  # efeitos baixos e médios: só o clarão de cada efeito; a luz de cada partícula é dos altos
		return
	var gt := Pix.glow_tex()
	for p in parts:
		if p[7] > 0.0:
			continue
		var k: float = p[3] / p[4]
		match p[0]:
			SPARK:
				_shine(gt, p[1], 3.0 * Pix.S, p[5], 0.45 * k)
			MOTE:
				_shine(gt, p[1], (2.5 + p[6]) * Pix.S, p[5], 0.4 * k)
			STAR:
				_shine(gt, p[1], (3.0 + p[6] * 2.0) * Pix.S, p[5], 0.5 * k)
			BOKEH:
				_shine(gt, p[1], (3.0 + p[6] * 3.0) * Pix.S, p[5], 0.35 * minf(1.0, k * 3.0))
			HOME:
				_shine(gt, p[1], (3.0 + p[6] * 2.5) * Pix.S, p[5], 0.2)  # juntas perto do peito: cada uma pouca luz
			BUBBLE:
				_shine(gt, p[1], (4.0 + p[6] * 2.0) * Pix.S, C[3], 0.25)
			GLYPH:  # cada cruz ou gota com a sua luz
				_shine(gt, p[1], (9.0 + p[6] * 3.0) * Pix.S, C[2], 0.4 * minf(1.0, k * 2.0))


## Pix.glow de uma partícula, sem as duas chamadas pelo meio (dezenas por frame no pilar e nas faíscas).
func _shine(gt: Texture2D, at: Vector2, r: float, c: Color, k: float) -> void:
	if k > 0.01:
		lit.draw_texture_rect(gt, Rect2(at.x - r, at.y - r, r * 2.0, r * 2.0), false, Color(c, k))
