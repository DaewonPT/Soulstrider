extends Node2D
## Efeito visual curto: anel, golpe da gadanha, faíscas, impacto, brilho do crítico,
## número de dano, explosão de subida de nível ou poeira.

const SLASH := [preload("res://art/fx/slash_0.png"), preload("res://art/fx/slash_1.png"), preload("res://art/fx/slash_2.png"), preload("res://art/fx/slash_3.png")]
const HIT := [preload("res://art/fx/hit_0.png"), preload("res://art/fx/hit_1.png"), preload("res://art/fx/hit_2.png"), preload("res://art/fx/hit_3.png")]
const Gothic := preload("res://gothic.gd")

var kind := "ring"
var radius := 100.0
var dir := Vector2.RIGHT
var color := Color(0.35, 1.0, 0.6)
var text := ""
var sub := ""  # legenda pequena por cima do número ("CRÍTICO!")
var t := 0.0
var dur := 0.35
var parts := []  # [posição, velocidade, tamanho] por partícula


func _ready() -> void:
	z_index = 5
	match kind:
		"sparks":
			for i in 9:
				parts.append([Vector2.ZERO, dir.rotated(randf_range(-0.6, 0.6)) * randf_range(260.0, 620.0), randf_range(6.0, 16.0)])
		"burst":
			dur = 0.9
			for i in 18:
				parts.append([Vector2.ZERO, Vector2.from_angle(randf() * TAU) * randf_range(150.0, 380.0) + Vector2(0, -160), randf_range(4.0, 8.0)])
		"dust":
			dur = 0.7
			z_index = 4
			for i in 7:
				parts.append([Vector2.ZERO, Vector2.from_angle(randf() * TAU) * randf_range(40.0, 90.0) * radius / 60.0, randf_range(14.0, 26.0) * radius / 60.0])
		"num":
			z_index = 20
			dur = 0.8
		"hit":
			dur = 0.25
		"arc":
			dur = 0.3
		"glow":
			dur = 0.18
	if kind in ["glow", "burst"]:
		var m := CanvasItemMaterial.new()
		m.blend_mode = CanvasItemMaterial.BLEND_MODE_ADD
		material = m


func _process(delta: float) -> void:
	t += delta
	if t >= dur:
		queue_free()
	for p in parts:
		p[0] += p[1] * delta
		p[1] *= exp(-(6.0 if kind == "sparks" else 2.0) * delta)
		if kind == "burst":
			p[1].y += 500.0 * delta
	queue_redraw()


func _draw() -> void:
	var k := t / dur
	var c := Color(color, 1.0 - k)
	match kind:
		"arc":
			# O crescente da folha VFX-01 aponta para +x: roda para a direção do golpe
			var tex: Texture2D = SLASH[mini(3, int(k * 4.0))]
			var tint := Color(2.2, 0.35, 0.45) if color.r > color.g else Color.WHITE
			draw_set_transform(Vector2.ZERO, dir.angle(), Vector2.ONE * radius * 0.9 / 97.0)
			draw_texture(tex, -tex.get_size() / 2.0, tint)
			draw_set_transform(Vector2.ZERO)
		"hit":
			var tex: Texture2D = HIT[mini(3, int(k * 4.0))]
			var s := radius / 115.0
			draw_set_transform(Vector2.ZERO, 0.0, Vector2(s, s))
			draw_texture(tex, -tex.get_size() / 2.0, Color(1.6, 1.2, 0.6) if color.g < 0.9 else Color.WHITE)
			draw_set_transform(Vector2.ZERO)
		"sparks":
			for p in parts:
				draw_line(p[0], p[0] - p[1].normalized() * p[2] * (1.0 - k), c, 3.0)
		"burst":
			for p in parts:
				var s: float = p[2] * (1.0 - k * 0.5)
				var q: Vector2 = p[0]
				draw_colored_polygon(PackedVector2Array([q + Vector2(0, -s * 1.6), q + Vector2(s, 0), q + Vector2(0, s * 1.6), q + Vector2(-s, 0)]), c)
		"dust":
			for p in parts:
				draw_circle(p[0], p[2] * (0.6 + k), Color(0.42, 0.4, 0.36, 0.45 * (1.0 - k)))
		"glow":
			for i in 6:
				draw_circle(Vector2.ZERO, radius * (1.0 - i / 6.0) * (0.6 + k), Color(color, 0.16 * (1.0 - k)))
		"num":
			# Pop (cresce acima do tamanho e assenta), sobe, e desvanece no fim
			var pop := 1.0 + 0.6 * maxf(0.0, 1.0 - t / 0.12)
			var fade := clampf((1.0 - k) / 0.4, 0.0, 1.0)
			var size := int(radius * 1.15 * pop)  # a letra gótica é mais estreita: um pouco maior
			var y := -k * 50.0
			Gothic.draw_centered(self, 0.0, y, text, size, Color(color, fade), 7)
			if sub != "":
				Gothic.draw_centered(self, 0.0, y - size * 0.75, sub, 16, Color(1.0, 0.9, 0.6, fade), 5)
		_:
			var r := radius * (0.3 + 0.7 * k)
			draw_circle(Vector2.ZERO, r, Color(c, c.a * 0.15))
			draw_arc(Vector2.ZERO, r, 0.0, TAU, 48, c, 6.0 * (1.0 - k) + 2.0)
