extends Control
## Abertura do jogo (antes do título ou da intro): na escuridão acendem-se dois olhos, o Colosso emerge, os
## olhos passam de verde a vermelho de raiva, ruge (tremor, clarão, pó a cair) e o nome do jogo cai por cima.
## Um toque salta. No fim emite finished (o hud.gd segue para a intro ou para o título).

signal finished

const Gothic := preload("res://gothic.gd")
const Enemy := preload("res://enemy.gd")
const STUDIO := preload("res://art/ui/studio_logo.png")
const ROAR := preload("res://sfx/roar.wav")
const BELL := preload("res://sfx/bell.wav")
## Desenhos do Colosso 32-bit: parado (16) e de punhos erguidos (11), com o meio dos olhos medido em cada um.
const CALM := [16, Vector2(159, 85)]
const RAGE := [11, Vector2(123.5, 44)]
const EYE_GAP := 11.0  # distância entre os olhos, na textura (a forma e o brilho dos olhos medem-se por ela)
const EYES_AT := Vector2(0.5, 0.44)  # onde ficam os olhos no ecrã (fração)
static var SOFT := _soft()  # brilho redondo que se esbate até às bordas


static func _soft() -> GradientTexture2D:
	var g := GradientTexture2D.new()
	g.gradient = Gradient.new()
	g.gradient.colors = PackedColorArray([Color.WHITE, Color(1, 1, 1, 0)])
	g.fill = GradientTexture2D.FILL_RADIAL
	g.fill_from = Vector2(0.5, 0.5)
	g.fill_to = Vector2(1.0, 0.5)
	return g
const ROAR_AT := 2.5
const SLAM_AT := 3.6
const END := 6.2
const GREEN := Color(0.45, 1.0, 0.65)
const RED := Color(1.0, 0.12, 0.08)

var t := 0.0
var shake := 0.0
var flash := 0.0
var flash_col := Color.WHITE
var beats := {}
var dust := []  # [posição, velocidade, tamanho]
var done := false
var boss: Control  # o Colosso com píxeis nítidos
var over: Control  # pó, clarões, o nome do jogo
var rng := RandomNumberGenerator.new()


func _ready() -> void:
	rng.seed = 13
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	boss = Control.new()
	boss.set_anchors_preset(Control.PRESET_FULL_RECT)
	boss.mouse_filter = Control.MOUSE_FILTER_IGNORE
	boss.texture_filter = TEXTURE_FILTER_NEAREST
	boss.draw.connect(_draw_boss)
	add_child(boss)
	over = Control.new()
	over.set_anchors_preset(Control.PRESET_FULL_RECT)
	over.mouse_filter = Control.MOUSE_FILTER_IGNORE
	over.draw.connect(_draw_over.bind(over))
	add_child(over)
	_sound(ROAR, -16.0, 0.45)  # um ronco grave na escuridão


## Salta para o fim (um toque, A ou B).
func skip() -> void:
	t = maxf(t, END - 0.35)


func _input(event: InputEvent) -> void:
	if t > 0.3 and event.is_pressed() and not event.is_echo() and (event is InputEventScreenTouch \
			or event is InputEventJoypadButton or event is InputEventKey \
			or (event is InputEventMouseButton and not DisplayServer.is_touchscreen_available())):
		get_viewport().set_input_as_handled()
		skip()


func _process(delta: float) -> void:
	t += delta
	shake = maxf(0.0, shake - delta * 1.6)
	flash = maxf(0.0, flash - delta * 2.2)
	if _once("raio", 1.6):
		_flash(Color(0.8, 0.9, 1.0), 0.55)
	if _once("rugido", ROAR_AT):
		shake = 1.4
		_flash(RED, 0.5)
		_sound(ROAR, 0.0, 0.8)
		for i in 70:
			dust.append([Vector2(rng.randf_range(0, size.x), rng.randf_range(-200, 0)), rng.randf_range(160, 420), rng.randf_range(3, 7)])
	if _once("nome", SLAM_AT):
		shake = maxf(shake, 0.9)
		_flash(Color.WHITE, 0.6)
		_sound(BELL, -2.0)
	for d in dust:
		d[0].y += d[1] * delta
	if t >= END and not done:
		done = true
		finished.emit()
	queue_redraw()
	boss.queue_redraw()
	over.queue_redraw()


func _once(key: String, at: float) -> bool:
	if t < at or beats.has(key):
		return false
	beats[key] = true
	return true


func _flash(col: Color, a: float) -> void:
	flash_col = col
	flash = maxf(flash, a)


func _sound(stream: AudioStream, db: float, pitch := 1.0) -> void:
	var a := AudioStreamPlayer.new()
	a.stream = stream
	a.volume_db = db
	a.pitch_scale = pitch
	a.bus = "Efeitos"
	a.finished.connect(a.queue_free)
	add_child(a)
	a.play()


func _shake_off() -> Vector2:
	return Vector2(sin(t * 67.0), cos(t * 53.0)) * 18.0 * shake * shake


func _draw() -> void:
	draw_rect(Rect2(Vector2.ZERO, size), Color.BLACK)
	# Luz vermelha de baixo, a crescer com a raiva
	var heat := clampf((t - 1.2) / 1.3, 0.0, 1.0)
	for i in 5:
		var r := size.y * (0.9 - i * 0.14)
		draw_circle(Vector2(size.x / 2.0, size.y * 1.05), r, Color(0.5, 0.02, 0.0, 0.05 * heat))


func _draw_boss() -> void:
	var raging := t >= ROAR_AT
	var pose: Array = RAGE if raging else CALM
	var tex: Texture2D = Enemy.FRAMES32["colossus"][pose[0]]
	var sc := (lerpf(2.6, 3.0, clampf(t / SLAM_AT, 0.0, 1.0)) + (0.25 * maxf(0.0, 1.0 - (t - ROAR_AT) * 2.0) if raging else 0.0)) * 2.0 * Enemy.Feet32.SCALE["colossus32"]
	var u := EYE_GAP / 19.0  # os olhos foram desenhados para olhos a 19 píxeis um do outro
	var eyes := size * EYES_AT + _shake_off()
	# O corpo sai da escuridão; o raio mostra-o por um instante; com o nome do jogo fica na penumbra
	var light := clampf((t - 0.9) / 1.4, 0.0, 1.0) * 0.55
	light = maxf(light, flash * 1.4 if beats.has("raio") else 0.0)
	if t >= SLAM_AT:
		light = lerpf(light, 0.32, clampf((t - SLAM_AT) / 0.6, 0.0, 1.0))
	if raging and t < SLAM_AT:
		light = maxf(light, 0.75)
	var body := Color(light, light * 0.92, light * 0.9)
	boss.draw_texture_rect(tex, Rect2(eyes - pose[1] * sc, tex.get_size() * sc), false, body)
	# Os olhos: acendem-se verdes e passam a vermelho, a pulsar; no rugido explodem de raiva
	if t < 0.5:
		return
	var rage := clampf((t - 1.2) / 1.3, 0.0, 1.0)
	var col := GREEN.lerp(RED, rage)
	var pulse := 1.0 + 0.15 * sin(t * (6.0 + rage * 10.0))
	var burst := 1.0 + (1.6 * maxf(0.0, 1.0 - (t - ROAR_AT) * 1.5) if raging else 0.0)
	var on := clampf((t - 0.5) / 0.25, 0.0, 1.0)
	for side in [-1.0, 1.0]:
		var e := eyes + Vector2(side * EYE_GAP / 2.0 * sc, 0)
		var g := sc * u * 9.0 * pulse * burst  # brilho suave à volta
		boss.draw_texture_rect(SOFT, Rect2(e - Vector2(g, g), Vector2(g, g) * 2.0), false, Color(col, 0.55 * on))
		# O olho: uma fenda inclinada, mais baixa do lado do nariz (cenho de raiva), com o miolo quase branco
		var shape := PackedVector2Array()
		for p in [Vector2(-3.4, 1.4), Vector2(0.2, -1.5), Vector2(3.6, -0.9), Vector2(0.6, 1.3)]:
			shape.append(e + Vector2(-p.x * side, p.y) * sc * u * (1.0 + 0.25 * rage))
		boss.draw_colored_polygon(shape, Color(col, on))
		var core := PackedVector2Array()
		for p in shape:
			core.append(e + (p - e) * 0.5)
		boss.draw_colored_polygon(core, Color(col.lerp(Color.WHITE, 0.7), on))


func _draw_over(ci: Control) -> void:
	var vs := size
	for d in dust:
		ci.draw_rect(Rect2(d[0] + _shake_off(), Vector2(d[2], d[2])), Color(0.55, 0.5, 0.42, 0.8))
	if flash > 0.0:
		ci.draw_rect(Rect2(Vector2.ZERO, vs), Color(flash_col, flash * 0.6))
	if t >= SLAM_AT:
		var k := clampf((t - SLAM_AT) / 0.25, 0.0, 1.0)
		var sc := lerpf(3.0, 1.0, ease(k, 2.4))
		ci.draw_set_transform(Vector2(vs.x / 2.0, vs.y * 0.80) + _shake_off(), 0.0, Vector2(sc, sc))
		Gothic.draw_centered(ci, 0.0, 0.0, "SOULSTRIDER", 96, Color(0.85, 1.0, 0.88, k), 12)
		ci.draw_set_transform(Vector2.ZERO)
		var sub := clampf((t - SLAM_AT - 0.6) / 0.6, 0.0, 1.0)
		Gothic.draw_centered(ci, vs.x / 2.0, vs.y * 0.80 + 46.0, "Necro-Dominion", 32, Color(0.95, 0.8, 0.5, sub), 6)
		var credit := clampf((t - SLAM_AT - 1.1) / 0.6, 0.0, 1.0)
		ci.draw_texture_rect(STUDIO, Rect2(vs.x - 96.0, vs.y - 96.0, 72.0, 72.0), false, Color(1, 1, 1, credit))
		Gothic.draw(ci, Vector2(vs.x - 104.0 - Gothic.width("Um jogo Pixel Lusitano", 16), vs.y - 52.0), "Um jogo Pixel Lusitano", 16, Color(0.9, 0.85, 0.7, credit), 4)
	if t < 0.25:
		ci.draw_rect(Rect2(Vector2.ZERO, vs), Color(0, 0, 0, 1.0 - t / 0.25))
	if t > END - 0.35:
		ci.draw_rect(Rect2(Vector2.ZERO, vs), Color(0, 0, 0, clampf((t - (END - 0.35)) / 0.35, 0.0, 1.0)))
