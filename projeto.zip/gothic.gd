extends RefCounted
## Letra gótica do jogo: Alkhemikal, de jeti (títulos, também os dos cartões, nomes, números de dano).
## Licença CC BY 4.0 (fonts/Alkhemikal-LICENSE.txt): pode ir num jogo à venda, com crédito ao autor (está no
## Sobre). O Godot não põe .txt no APK sozinho: na predefinição de exportação, juntar "fonts/*.txt".
## É uma letra de píxeis desenhada a 16 px: importada sem suavizar e usada só em múltiplos de 16 (px()),
## senão os píxeis da letra ficam de tamanhos diferentes.
## O texto passa pela tradução (i18n.gd): o código escreve em português e aqui sai no idioma escolhido.

const FONT := preload("res://fonts/Alkhemikal.ttf")
## Letra do texto pequeno: Augusta (fonts/Augusta-LICENCA.txt, crédito no Sobre). A Alkhemikal só fica nítida
## em múltiplos de 16 e a 16 lia-se mal no telemóvel; a Augusta é suavizada e lê-se a qualquer tamanho.
## Se faltar um caractere, cai na Alkhemikal (fallbacks no Augusta.ttf.import).
const BODY := preload("res://fonts/Augusta.ttf")
const BODY_SIZE := 20  # painéis, botões, menus, descrições
const CARD_SIZE := 25  # corpo do cartão do toque longo
const TOAST_SIZE := 28


## Tamanho da letra arredondado ao múltiplo de 16 mais perto.
static func px(size: int) -> int:
	return maxi(16, roundi(size / 16.0) * 16)


static func width(text: String, size: int) -> float:
	return FONT.get_string_size(TranslationServer.translate(text), HORIZONTAL_ALIGNMENT_LEFT, -1, px(size)).x


## pos = início da linha de base. outline > 0 desenha contorno por baixo (como draw_string_outline).
static func draw(ci: CanvasItem, pos: Vector2, text: String, size: int, color: Color, outline := 0, outline_color := Color.BLACK) -> void:
	text = TranslationServer.translate(text)
	size = px(size)
	if outline > 0:
		ci.draw_string_outline(FONT, pos, text, HORIZONTAL_ALIGNMENT_LEFT, -1, size, outline, Color(outline_color, outline_color.a * color.a))
	ci.draw_string(FONT, pos, text, HORIZONTAL_ALIGNMENT_LEFT, -1, size, color)


static func draw_centered(ci: CanvasItem, center_x: float, baseline: float, text: String, size: int, color: Color, outline := 0) -> void:
	draw(ci, Vector2(center_x - width(text, size) / 2.0, baseline), text, size, color, outline)
