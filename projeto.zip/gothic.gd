extends RefCounted
## Letra gótica do jogo: Pirata One (títulos, nomes, números de dano, cartões).
## Licença SIL Open Font License 1.1 (fonts/PirataOne-OFL.txt): pode ir num jogo à venda,
## desde que o ficheiro da licença vá junto e a fonte não seja vendida sozinha. O Godot não põe .txt
## no APK sozinho: na predefinição de exportação, juntar "fonts/*.txt" aos ficheiros não-recurso.
## Escrever com maiúscula só no início ("Arauto Fúnebre"): em maiúsculas seguidas o D desta letra lê-se como V.

const FONT := preload("res://fonts/PirataOne-Regular.ttf")


static func width(text: String, size: int) -> float:
	return FONT.get_string_size(text, HORIZONTAL_ALIGNMENT_LEFT, -1, size).x


## pos = início da linha de base. outline > 0 desenha contorno por baixo (como draw_string_outline).
static func draw(ci: CanvasItem, pos: Vector2, text: String, size: int, color: Color, outline := 0, outline_color := Color.BLACK) -> void:
	if outline > 0:
		ci.draw_string_outline(FONT, pos, text, HORIZONTAL_ALIGNMENT_LEFT, -1, size, outline, Color(outline_color, outline_color.a * color.a))
	ci.draw_string(FONT, pos, text, HORIZONTAL_ALIGNMENT_LEFT, -1, size, color)


static func draw_centered(ci: CanvasItem, center_x: float, baseline: float, text: String, size: int, color: Color, outline := 0) -> void:
	draw(ci, Vector2(center_x - width(text, size) / 2.0, baseline), text, size, color, outline)
