extends Node2D
## Moeda, Frasco de Alma, peça de equipamento (0.4.8), orbe de sangue (cura) ou esfera de alma (mana) no chão. Recolha automática ao passar por cima (amigável para mobile).
## As raras têm um feixe de luz: Tinteiro dourado, Cinzas e Frascos verdes, montes de ossos cinzento; o equipamento pela raridade (Player.RARITY_RAMP: a única cor de brasa).
## Efeitos adaptados de Sprite Fusion Pixel Art VFX (MIT, (c) 2026 Hugo Duprez)

const Player := preload("res://player.gd")
const Pix := preload("res://fx_pix.gd")
const Gothic := preload("res://gothic.gd")
const RELIC := Color(0.8, 0.55, 1.0)  # o violeta das relíquias e das Almas Condensadas (#76)
## [nome, cor, tom do tinido ao cair (0 = sem tinido), tremor do ecrã]: quanto mais raro, mais agudo e mais forte.
const INFO := {
	"bone": ["Osso Ancestral", Color(0.95, 0.85, 0.55), 0.0, 0.0],
	"ink": ["Tinteiro de Sangue Negro", Color(0.85, 0.12, 0.18), 1.25, 3.0],
	"ash": ["Cinzas do Purgatório", Color(1.0, 0.6, 0.2), 1.5, 5.0],
	"flask": ["Frasco de Alma", Color(0.5, 1.0, 0.7), 0.0, 8.0],
	"blood": ["Esfera de Sangue", Color(0.85, 0.12, 0.18), 0.0, 0.0],
	"soul": ["Esfera de Alma", Color(0.35, 0.7, 1.0), 0.0, 0.0],
	"formao": ["Formão Cadavérico", Color(0.9, 0.86, 0.75), 1.5, 5.0],
	"carmesim": ["Tinteiro Carmesim", Color(1.0, 0.3, 0.4), 1.5, 5.0],
	"pena": ["Pena de Abutre", Color(0.85, 0.6, 0.3), 1.5, 5.0],
	"tomo": ["Tomo dos Nomes Esquecidos", Color(0.6, 0.75, 1.0), 1.5, 5.0],
	"relic": ["Relíquia de Família", RELIC, 0.0, 8.0],
	"transitoria": ["Alma Transitória", Color(0.4, 0.95, 0.9), 1.8, 6.0],  # Almas Transitórias (#4), dos elites e dos gigantes
	"coracao": ["Coração de Titã Petrificado", Color(0.78, 0.78, 0.72), 1.8, 6.0],  # Coração de Titã (#70): oferece-se no altar
	"arma": ["Alma da arma", Color(1.0, 0.62, 0.3), 1.8, 8.0],  # G7: a qual vai no campo flask (o nome no chão é o dela, main.FORMS)
	# G5 (Lote 10): os materiais da Forja de Peças (main.mats, nunca se perdem ao morrer)
	"enxofre": ["Enxofre de Sepultura", Color(0.95, 0.85, 0.3), 1.5, 5.0],
	"martelo": ["Martelo de Mamute", Color(0.95, 0.92, 0.82), 1.5, 5.0],
	"agulha": ["Agulha de Prata", Color(0.85, 0.9, 0.95), 1.5, 5.0],
	"cinza_maior": ["Cinzas Maiores", Color(1.0, 0.95, 0.75), 1.8, 7.0],
	"cinzel": ["Cinzel de Marfim", Color(0.95, 0.92, 0.82), 1.5, 5.0],
	# Lote 11: o Atlas dos Sepulcros (#185) e o Óleo de Lápide (#227); guardam-se com os materiais (main.mats), nunca vão para o túmulo
	"estaca": ["Estaca Fúnebre", Color(0.85, 0.72, 0.55), 1.8, 7.0],
	"oleo_lapide": ["Óleo de Lápide Profanada", Color(0.5, 0.8, 0.5), 1.8, 7.0],
}
const REAGENTS := ["formao", "carmesim", "pena", "tomo"]  # os reagentes da Forja (S2), que os chefes com nome deixam
const MATS := ["enxofre", "martelo", "agulha", "cinza_maior", "cinzel"]  # G5: os materiais (as Cinzas Maiores são as raras)
const KEEP := ["estaca", "oleo_lapide"]  # Lote 11: as Estacas Fúnebres e o Óleo de Lápide, que o Atlas gasta (não se forjam)
const SOUND := {"bone": "coin", "flask": "flask", "relic": "relic"}  # som próprio ao cair (#288); os outros tinem (INFO)
## Rampa de cores (fx_pix.gd) de cada um: o voo para o herói ao apanhar (fx.gd "pickup")
const RAMP := {"bone": "loot_bone", "ink": "loot_ink", "ash": "loot_ash", "flask": "soul", "blood": "bleed", "soul": "soulblue",
	"formao": "loot_bone", "carmesim": "loot_ink", "pena": "loot_ash", "tomo": "loot_ash", "relic": "soul", "transitoria": "soul", "coracao": "iron", "arma": "loot_ash",
	"enxofre": "gold", "martelo": "loot_bone", "agulha": "soulblue", "cinza_maior": "gold", "cinzel": "loot_bone", "estaca": "loot_bone", "oleo_lapide": "soul"}
const TEX := {
	"bone": preload("res://art/icons/bone.png"),
	"ink": preload("res://art/icons/ink.png"),
	"ash": preload("res://art/icons/ash.png"),
	"blood": preload("res://art/icons/ink.png"),
	"soul": preload("res://art/icons/potion_soul.png"),  # o ícone da poção de alma do HUD
	"formao": preload("res://art/icons/reag_formao.png"),  # SC-ICO9 (13/11/2026): os reagentes, os materiais, a Estaca, o Óleo e o Olho com ícone próprio (sem TINT)
	"carmesim": preload("res://art/icons/reag_carmesim.png"),
	"pena": preload("res://art/icons/reag_pena.png"),
	"tomo": preload("res://art/icons/reag_tomo.png"),
	"relic": preload("res://art/icons/relic.png"),
	"transitoria": preload("res://art/icons/soul_transitoria.png"),
	"coracao": preload("res://art/icons/reag_coracao.png"),
	"helm": preload("res://art/icons/helm.png"),  # Equipamento (0.4.8): as bases; os únicos são o ícone da base com a cor deles (TINT)
	"hood": preload("res://art/icons/hood.png"),
	"chest_armor": preload("res://art/icons/chest_armor.png"),
	"robe": preload("res://art/icons/robe.png"),
	"gloves": preload("res://art/icons/gloves.png"),
	"boots": preload("res://art/icons/boots.png"),
	"coroa": preload("res://art/icons/gear_coroa.png"),
	"penitente": preload("res://art/icons/chest_armor.png"),
	"garras": preload("res://art/icons/gloves.png"),
	"unhas": preload("res://art/icons/boots.png"),
	"amulet": preload("res://art/icons/gear_amulet.png"),  # SC-ICO8 (12/11/2026): os ícones próprios dos únicos novos, das almas da arma e das 2 bases do Pescoço
	"censer": preload("res://art/icons/gear_censer.png"),
	"elo": preload("res://art/icons/gear_elo.png"),
	"marcha": preload("res://art/icons/gear_marcha.png"),
	"visor": preload("res://art/icons/gear_visor.png"),
	"manoplas": preload("res://art/icons/gear_manoplas.png"),
	"noivo": preload("res://art/icons/gear_noivo.png"),
	"noiva": preload("res://art/icons/gear_noiva.png"),
	"parede": preload("res://art/icons/gear_parede.png"),
	"foice_longa": preload("res://art/icons/arma_foice_longa.png"),
	"juramento": preload("res://art/icons/arma_juramento.png"),
	"sino": preload("res://art/icons/arma_sino.png"),
	"cutelo": preload("res://art/icons/arma_cutelo.png"),
	"tibias": preload("res://art/icons/arma_tibias.png"),
	"basilisco": preload("res://art/icons/arma_basilisco.png"),
	"enxofre": preload("res://art/icons/mat_enxofre.png"),  # G5: o Enxofre um cristal (com o monte das Cinzas, as três pareciam uma só; num frasco, parecia um Frasco de Alma)
	"martelo": preload("res://art/icons/mat_martelo.png"),
	"agulha": preload("res://art/icons/mat_agulha.png"),
	"cinza_maior": preload("res://art/icons/mat_cinza_maior.png"),
	"cinzel": preload("res://art/icons/mat_cinzel.png"),
	"estaca": preload("res://art/icons/mat_estaca.png"),
	"oleo_lapide": preload("res://art/icons/mat_oleo_lapide.png"),
	"olho": preload("res://art/icons/gear_olho.png"),
}
## A cor por cima dos ícones que reaproveitam o de uma base: no chão, no voo para o herói (fx.gd), na mochila e na Forja (hud.gd). Os de
## ícone próprio (SC-ICO8 e SC-ICO9) não têm cor: o ícone já vem pintado. Ler sempre com TINT.get(k, Color.WHITE)
const TINT := {"penitente": Color(1.0, 0.45, 0.42), "garras": Color(0.78, 0.62, 0.45), "unhas": Color(0.6, 1.0, 0.62)}
const GEAR_FEEL := [[1.0, 0.0], [1.25, 3.0], [1.5, 6.0], [1.8, 9.0]]  # Equipamento (0.4.8): [tom do tinido, tremor] de cada raridade (Player.RARITY)
const FLASK_TEX := {
	"": preload("res://art/icons/flask_empty.png"),
	"parasita": preload("res://art/icons/flask_parasita.png"),
	"titanica": preload("res://art/icons/flask_titanica.png"),
	"veloz": preload("res://art/icons/flask_swift.png"),
	"eco": preload("res://art/icons/flask_echo.png"),
	"tumular": preload("res://art/icons/flask_grave.png"),
	"colerica": preload("res://art/icons/flask_wrath.png"),
	"roubo": preload("res://art/icons/flask_roubo.png"),
	"caotico": preload("res://art/icons/flask_caotico.png"),
	"mitotico": preload("res://art/icons/flask_mitotico.png"),
	"martir": preload("res://art/icons/flask_martir.png"),
	"gatilho": preload("res://art/icons/flask_gatilho.png"),
	"carga": preload("res://art/icons/flask_carga.png"),
	"eter": preload("res://art/icons/flask_eter.png"),
	"gravidade": preload("res://art/icons/flask_gravidade.png"),
	"meteoro": preload("res://art/icons/flask_meteoro.png"),
	"terramoto": preload("res://art/icons/flask_terramoto.png"),
	"voraz": preload("res://art/icons/flask_voraz.png"),
	"chumbo": preload("res://art/icons/flask_chumbo.png"),
	"biomecanica": preload("res://art/icons/flask_biomecanica.png"),
	"maldito_carcereiro": preload("res://art/icons/flask_maldito_carcereiro.png"),
	"furia": preload("res://art/icons/flask_furia.png"),
	"maldito_arauto": preload("res://art/icons/flask_maldito_arauto.png"),
	"vinganca": preload("res://art/icons/soul_vinganca.png"),
	"escriba": preload("res://art/icons/soul_escriba.png"),
	"cranios": preload("res://art/icons/soul_cranios.png"),
	"donzela": preload("res://art/icons/soul_donzela.png"),
}
const BEAM := {"ink": "gold", "bone": "bone", "blood": "bone", "soul": "bone", "arma": "loot_ash", "cinza_maior": "gold", "estaca": "gold", "oleo_lapide": "gold"}  # G5: as Cinzas Maiores, raras, com o feixe dourado  # a rampa do feixe; os outros, a verde dos únicos (a alma da arma, brasa como os únicos)
const BEAM_CAP := [3, 5, 8]  # feixes à vista, por nível de efeitos: os mais raros e, entre iguais, os mais perto (relíquias, reagentes e o Coração de Titã não contam: têm sempre)
const VIEW_PAD := 150.0  # a câmara e mais isto: o feixe de quem está logo abaixo do ecrã ainda se vê
const NAME_CAP := [5, 8, 10]  # e nomes, os mesmos primeiro: no fim de um Cortejo não tapam o ecrã
const RANK_EVERY := 20  # frames entre contas

var main
var kind := "bone"
var flask := ""  # qual Frasco de Alma, quando kind == "flask"
var amount := 1
var t := 0.0
var pop := Vector2.ZERO  # salta para fora do baú / do chefe e assenta
var label_y := -44.0
var lit: Node2D  # o brilho aditivo das estrelas do saque raro
var label: Label
static var _h := []  # Pix.hashf(i, k) das estrelas e dos pontos, iguais em todo o saque: calculados uma vez
static var _beams := {}  # quem tem feixe, por id do nó (de cada telemóvel: nada disto viaja)
static var _ranked := -1000  # o frame da última conta
static var _hid := {}  # Lote 7 C (e): o saque cujo feixe e brilhos tocariam no cartão do chefe à vista (ou, Lote 8, num botão do ecrã), por id do nó: sem eles até sair de lá


func _ready() -> void:
	# Não tapar o nome de outra moeda caída ao lado: sobe o nome até ficar livre
	for i in 8:
		var clash := false
		for o in get_tree().get_nodes_in_group("loot"):
			if absf(o.position.x - position.x) < 110.0 and absf(o.position.y + o.label_y - position.y - label_y) < 17.0:
				clash = true
				break
		if not clash:
			break
		label_y -= 18.0
	add_to_group("loot")
	var l := Label.new()
	label = l
	_ranked = -1000  # saque novo: conta outra vez já no próximo desenho
	var name_s: String = Player.gear_name(flask) if kind == "gear" else tr(main.FORMS[flask][0]) if kind == "arma" else tr(Player.SUPPORT_NAMES[flask] if kind == "flask" else INFO[kind][0])
	l.text = name_s if amount == 1 else "%s x%d" % [name_s, amount]
	l.add_theme_color_override("font_color", color())
	l.add_theme_color_override("font_outline_color", Color.BLACK)
	l.add_theme_constant_override("outline_size", 5)
	l.add_theme_font_size_override("font_size", 16)
	if Gothic.small_body:  # na Augusta, no tamanho do texto, e o da peça única maior (ver gothic.gd)
		l.add_theme_font_override("font", Gothic.BODY)
		l.add_theme_font_size_override("font_size", Gothic.body_px(21 if rarity() == 3 else 17))
	l.position = Vector2(-80, label_y)
	l.size = Vector2(160, 20)
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	l.visible = rule() == 0  # o filtro do saque (#76): "Luz e som" e "Só o ícone" tiram o nome
	l.z_index = 1  # por cima dos adereços e das personagens (z 0), debaixo do raio X e do escuro (z 3, main:542)
	add_child(l)
	# o raro cintila (tinteiro, cinzas, frascos, Almas Condensadas e Transitórias, reagentes, relíquias e o Coração de Titã), menos em "Só o ícone"
	if (kind in ["ink", "ash", "flask", "relic", "transitoria", "coracao", "arma"] or kind in REAGENTS or is_mat(kind) or rarity() > 0) and rule() < 2:
		lit = Node2D.new()
		lit.material = CanvasItemMaterial.new()
		lit.material.blend_mode = CanvasItemMaterial.BLEND_MODE_ADD
		lit.draw.connect(_glints.bind(true))
		add_child(lit)
	_drop_sound()


## Vai para main.mats (os materiais da Forja e, Lote 11, o que o Atlas gasta), nunca para as moedas nem para o túmulo.
static func is_mat(k: String) -> bool:
	return k in MATS or k in KEEP


## A cor do nome, do brilho e do voo: as Almas Condensadas ficam com o violeta das relíquias (#76).
func color() -> Color:
	if kind == "gear":
		return Player.rarity_color(rarity())
	return RELIC if kind == "flask" and flask in Player.SOULS else INFO[kind][1]


## A raridade de uma peça de equipamento (0 a 3, Player.RARITY); -1 no resto do saque.
func rarity() -> int:
	return int(flask.get_slice(":", 1)) if kind == "gear" else -1


## O tremor ao cair e a ordem dos feixes (rank): no equipamento, o da raridade.
func weight() -> float:
	return GEAR_FEEL[rarity()][1] if kind == "gear" else INFO[kind][3]


## Filtro do saque (#76), de cada telemóvel: 0 nome, luz e som · 1 luz e som · 2 só o ícone. Os frascos, os reagentes e
## as relíquias não passam por este filtro (os frascos contam para BEAM_CAP e NAME_CAP, em rank). Uma função e não um campo: nunca vai ao convidado.
func rule() -> int:
	if kind in ["bone", "blood", "soul"] or rarity() == 0:
		return main.settings.loot_common
	return main.settings.loot_rare if kind in ["ink", "ash"] or rarity() == 1 else 0


## O som ao cair (#288), só neste telemóvel (o convidado toca o seu, com o filtro dele). As esferas caem em silêncio, e
## o saque que já estava no chão quando o convidado entrou não toca.
func _drop_sound() -> void:
	if t > 0.5 or rule() == 2:
		return
	var tone: float = GEAR_FEEL[rarity()][0] if kind == "gear" else INFO[kind][2]
	if SOUND.has(kind):
		main.sfx(SOUND[kind], 0.0, true)
	elif tone > 0.0:
		main.sfx("chime", tone, true)


## Quem mostra feixe e nome, de RANK_EVERY em RANK_EVERY frames: a raridade é o tremor em INFO. A distância vai aos saltos
## de 96 px, para os feixes não trocarem a cada passo. O que está longe da câmara não gasta lugares.
static func rank(m) -> void:
	var f := Engine.get_process_frames()
	if f - _ranked < RANK_EVERY and f >= _ranked:
		return
	_ranked = f
	var all: Array = m.get_tree().get_nodes_in_group("loot").map(func(l): return [-l.weight(), l._near(), l.get_instance_id(), l])
	all.sort()
	_beams.clear()
	var lvl: int = m.effects_level()
	var beams := 0
	var names := 0
	var seen: Rect2 = m._view_rect().grow(VIEW_PAD)
	var band: Rect2 = m.hud.card_block()  # C (d): o cartão do chefe à vista
	var pads: Array = m.hud.pad_rects()  # Lote 7 C (g): e os botões do ecrã tátil
	_hid.clear()
	for a in all:
		var l = a[3]
		if not seen.has_point(l.position):
			l.label.visible = false
			continue
		var sure: bool = l.kind in ["relic", "coracao", "arma"] or l.kind in REAGENTS or is_mat(l.kind) or l.rarity() == 3
		var shine: Rect2 = l.get_global_transform_with_canvas() * Rect2(-46.0, -100.0, 92.0, 116.0)  # o feixe (até 60 px, mais alto a piscar) e as estrelas à volta do ícone
		if (band.has_area() and band.intersects(shine)) or pads.any(func(r): return r.intersects(shine)):
			_hid[a[2]] = true  # Lote 7 C (e): nem por cima do cartão do chefe; Lote 8 C (e): nem dos botões do ecrã tátil
		elif l.has_beam() and (sure or beams < BEAM_CAP[lvl]):
			beams += 0 if sure else 1
			_beams[a[2]] = true
		var nm: bool = l.rule() == 0 and (sure or names < NAME_CAP[lvl])
		var lr: Rect2 = l.label_rect()
		if nm and band.has_area() and band.intersects(l.label.get_global_transform_with_canvas() * Rect2(Vector2.ZERO, l.label.size)):
			nm = false  # o nome não fica por cima do "Chefe" nem do nome do cartão (volta quando o cartão sai)
		elif nm and (pads.any(func(r): return r.intersects(lr)) or m.hud.top_box().intersects(lr)):
			nm = false  # Lote 7 C (g): nem por cima de um botão do ecrã (volta quando o saque ou a câmara andam); Lote 9 C (f): nem da coluna de cima e do minimapa
		l.label.visible = nm
		if nm and not sure:
			names += 1


## O nome como se vê no ecrã: a largura do texto, ao meio da Label (que tem sempre 160 px).
func label_rect() -> Rect2:
	var tw: float = label.get_theme_font("font").get_string_size(label.text, HORIZONTAL_ALIGNMENT_LEFT, -1, label.get_theme_font_size("font_size")).x
	return label.get_global_transform_with_canvas() * Rect2((label.size.x - tw) / 2.0, 0.0, tw, label.size.y)


func _near() -> int:
	var p = main.nearest_player(position)
	return 0 if p == null else int(position.distance_to(p.position) / 96.0)


## Tem direito a feixe ("Só o ícone" apaga-o, #76); um osso solto nunca teve.
func has_beam() -> bool:
	return (kind != "bone" or amount > 1) and rarity() != 0 and rule() < 2


func _process(delta: float) -> void:
	t += delta
	if kind in ["blood", "soul"] and t > 8.0:
		queue_free()  # o orbe seca se ninguém o apanhar
		return
	position += pop * delta
	pop *= exp(-5.0 * delta)
	queue_redraw()
	var p = main.nearest_player(position)
	# Recolha automática (#77): o saque a menos de 110 px desliza para o herói; a Alma Gravitacional puxa de 260 px
	# (na Armadura de Ossos, que não bate, não conta)
	var pull := 260.0 if p != null and p.order.any(func(id): return id != "bonearmor" and p.skills[id].support == "gravidade") else 110.0
	if p != null and position.distance_to(p.position) < pull:
		position = position.move_toward(p.position, 240.0 * delta)
	if t > 0.4 and p != null and position.distance_to(p.position) < 40.0:
		main.collect(self)


func _draw() -> void:
	var c: Color = color()
	rank(main)
	var hid: bool = _hid.has(get_instance_id())  # Lote 7 C (e): sem feixe nem brilhos debaixo do cartão do chefe
	if _beams.has(get_instance_id()):
		var rn: String = Player.RARITY_RAMP[rarity()] if kind == "gear" else "necro" if c == RELIC else BEAM.get(kind, "soul")  # o violeta (relíquias e Almas Condensadas) sobe mais
		var g := lerpf(0.6, 1.0, minf(t / 0.4, 1.0))  # o feixe acende-se ao cair
		Pix.mark(self, Vector2.ZERO, rn)
		var hot := 1.5 if rarity() == 3 and int(t * 4.0) % 2 == 1 else 1.0  # B1: a peça única, mais alta e a piscar brasa e branco (parecia cinzas)
		Pix.beam(self, Vector2(0, 2), rn, 60 if rarity() == 3 else 44 if c == RELIC or rarity() >= 2 else 34, int(t * 8.0) % 3, Color(g * hot, g * hot * 0.96, g * hot * 0.92))
		if main.effects_level() > 0:
			Pix.motes(self, Vector2.ZERO, 12.0, 70.0, 4, t + position.x, Pix.ramp(rn))
	else:
		Pix.haze(self, Vector2.ZERO, 16.0 + sin(t * 5.0) * 2.0, 7.0, c.darkened(0.25), 0.36)
	var tex: Texture2D = FLASK_TEX[flask] if kind == "flask" else TEX[flask.get_slice(":", 0)] if kind in ["gear", "arma"] else TEX[kind]
	var sc := 38.0 / maxf(tex.get_width(), tex.get_height())
	var hop := sin(PI * minf(t / 0.45, 1.0)) * 26.0  # ao cair salta em arco
	draw_set_transform(Vector2(0, -8 + sin(t * 3.0) * 2.0 - hop), 0.0, Vector2(sc, sc))
	draw_texture(tex, -tex.get_size() / 2.0, TINT.get(flask.get_slice(":", 0) if kind in ["gear", "arma"] else kind, Color.WHITE))
	draw_set_transform(Vector2.ZERO)
	if lit:
		lit.visible = not hid
		var g := fmod(t - 2.5, 1.6)  # depois da queda só brilha 0,24 s de 1,6 em 1,6 s (_glints)
		if (t < 2.5 or g < 0.24) and not hid:
			_glints(false)
		if t < 2.5 or g < 0.34:  # mais uns frames para a luz se apagar
			lit.queue_redraw()


## Estrelas em píxeis (o sparkle): ao cair, uma estrela de 8 raios que cresce, roda e pulsa, estrelas pequenas à volta e
## pontos a piscar durante 2,5 s; depois um brilho a cada 1,6 s no canto do ícone. Só do t, que também viaja ao convidado.
## Efeitos médios e altos. light = a camada aditiva (os brilhos) ou o próprio saque (os raios).
func _glints(light: bool) -> void:
	var lvl: int = main.effects_level()
	if lvl == 0:
		return
	var ci: CanvasItem = lit if light else self
	var at := Vector2(0, -8 + sin(t * 3.0) * 2.0 - sin(PI * minf(t / 0.45, 1.0)) * 26.0)  # o meio do ícone, como em _draw
	var big := kind != "ink"
	var warm: Array = Pix.RAMPS.gold if big else Pix.RAMPS.loot_ink
	var cool: Array = Pix.RAMPS.soul if big else Pix.RAMPS.gold
	var size := 12.0 if big else 8.0
	if t >= 2.5:
		var g := fmod(t - 2.5, 1.6) / 1.6
		if g < 0.15:
			_flare(ci, light, at + Vector2(-8, -10), 0.5 * size * sin(g / 0.15 * PI), 0.4, warm)
		return
	var gone := 1.0 - Pix.smooth(1.9, 2.5, t)
	var pulse := 1.0 + 0.35 * exp(-pow(t - 0.9, 2.0) / 0.01) + 0.3 * exp(-pow(t - 1.5, 2.0) / 0.01)
	_flare(ci, light, at, size * Pix.out_back(t / 0.25) * gone * pulse, t * 0.7, warm)
	var k := size / 19.0  # a biblioteca mede tudo para uma estrela de 19
	if _h.is_empty():
		for i in 26:
			_h.append(range(8).map(func(n): return Pix.hashf(i, n)))
	for i in roundi(11.0 * main.EFFECTS[lvl]):
		var h: Array = _h[i]
		var u: float = (t - 0.1 - i * 0.17 - h[3] * 0.08) / lerpf(0.35, 0.6, h[4])
		if u > 0.0 and u < 1.0:
			var a: float = h[1] * TAU
			var d := lerpf(9.0, 32.0, h[2]) * k * Pix.S
			_flare(ci, light, at + Vector2(cos(a), sin(a) * 0.85) * d, lerpf(4.0, 8.5, h[5]) * k * pow(sin(u * PI), 0.7), lerpf(-2.0, 2.0, h[6]) * u + 0.4, cool if h[7] < 0.35 else warm)
	if light:
		return
	for i in 26:  # pontos que piscam a 12 Hz à volta
		var fr := floori(t * 12.0) + i * 3
		if Pix.hashf(fr, i) < 0.3 * gone:
			var a: float = _h[i][1] * TAU
			Pix.px(self, at + Vector2(cos(a), sin(a) * 0.8) * (6.0 + _h[i][2] * 40.0) * k * Pix.S, Color.WHITE if Pix.hashf(fr, 5) < 0.5 else warm[1])


func _flare(ci: CanvasItem, light: bool, at: Vector2, L: float, ang: float, r: Array) -> void:
	if L < 0.8:
		return
	if light:
		Pix.glow(ci, at, (4.0 + L * 1.4) * Pix.S, r[2], 0.5)
		Pix.glow(ci, at, (2.0 + L * 0.5) * Pix.S, Color.WHITE, 0.4)
	else:
		Pix.flare(ci, at, L, ang, r[2], r[3])
