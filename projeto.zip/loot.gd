extends Node2D
## Moeda no chão. Recolha automática ao passar por cima (amigável para mobile).
## As raras têm um feixe de luz: Tinteiro dourado, Cinzas verde, montes de ossos cinzento.

const INFO := {
	"bone": ["Osso Ancestral", Color(0.95, 0.85, 0.55)],
	"ink": ["Tinteiro de Sangue Negro", Color(0.85, 0.12, 0.18)],
	"ash": ["Cinzas do Purgatório", Color(1.0, 0.6, 0.2)],
}
const TEX := {
	"bone": preload("res://art/icons/bone.png"),
	"ink": preload("res://art/icons/ink.png"),
	"ash": preload("res://art/icons/ash.png"),
}
const BEAM := {
	"ink": preload("res://art/fx/beam_rare.png"),
	"ash": preload("res://art/fx/beam_unique.png"),
	"bone": preload("res://art/fx/beam_common.png"),
}

var main
var kind := "bone"
var amount := 1
var t := 0.0
var pop := Vector2.ZERO  # salta para fora do baú / do chefe e assenta


func _ready() -> void:
	var l := Label.new()
	var name_s: String = INFO[kind][0]
	l.text = name_s if amount == 1 else "%s x%d" % [name_s, amount]
	l.add_theme_color_override("font_color", INFO[kind][1])
	l.add_theme_color_override("font_outline_color", Color.BLACK)
	l.add_theme_constant_override("outline_size", 5)
	l.add_theme_font_size_override("font_size", 13)
	l.position = Vector2(-60, -44)
	l.size = Vector2(120, 20)
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	add_child(l)


func _process(delta: float) -> void:
	t += delta
	position += pop * delta
	pop *= exp(-5.0 * delta)
	queue_redraw()
	var p = main.nearest_player(position)
	if t > 0.4 and p != null and position.distance_to(p.position) < 40.0:
		main.collect(self)


func _draw() -> void:
	var c: Color = INFO[kind][1]
	if kind != "bone" or amount > 1:
		var beam: Texture2D = BEAM[kind]
		var h := 130.0 + sin(t * 4.0) * 6.0
		var w := h * beam.get_width() / beam.get_height()
		draw_texture_rect(beam, Rect2(-w / 2.0, -h + 8.0, w, h), false, Color(1, 1, 1, 0.7))
	draw_circle(Vector2.ZERO, 14.0 + sin(t * 5.0) * 3.0, Color(c, 0.2))
	var tex: Texture2D = TEX[kind]
	var sc := 38.0 / maxf(tex.get_width(), tex.get_height())
	draw_set_transform(Vector2(0, -8 + sin(t * 3.0) * 2.0), 0.0, Vector2(sc, sc))
	draw_texture(tex, -tex.get_size() / 2.0)
	draw_set_transform(Vector2.ZERO)
