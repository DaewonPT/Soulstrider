extends Node2D
## Moeda, Frasco de Alma, orbe de sangue (cura) ou esfera de alma (mana) no chão. Recolha automática ao passar por cima (amigável para mobile).
## As raras têm um feixe de luz: Tinteiro dourado, Cinzas e Frascos verdes, montes de ossos cinzento.

const Player := preload("res://player.gd")
const INFO := {
	"bone": ["Osso Ancestral", Color(0.95, 0.85, 0.55)],
	"ink": ["Tinteiro de Sangue Negro", Color(0.85, 0.12, 0.18)],
	"ash": ["Cinzas do Purgatório", Color(1.0, 0.6, 0.2)],
	"flask": ["Frasco de Alma", Color(0.5, 1.0, 0.7)],
	"blood": ["Orbe de Sangue", Color(0.85, 0.12, 0.18)],
	"soul": ["Esfera de Alma", Color(0.35, 0.7, 1.0)],
}
const TEX := {
	"bone": preload("res://art/icons/bone.png"),
	"ink": preload("res://art/icons/ink.png"),
	"ash": preload("res://art/icons/ash.png"),
	"blood": preload("res://art/icons/ink.png"),
	"soul": preload("res://art/icons/potion_soul.png"),  # o ícone da poção de alma do HUD
}
const FLASK_TEX := {
	"": preload("res://art/icons/flask_empty.png"),
	"parasita": preload("res://art/icons/flask_parasita.png"),
	"titanica": preload("res://art/icons/flask_titanica.png"),
	"veloz": preload("res://art/icons/flask_swift.png"),
	"eco": preload("res://art/icons/flask_echo.png"),
	"tumular": preload("res://art/icons/flask_grave.png"),
	"colerica": preload("res://art/icons/flask_wrath.png"),
	"roubo": preload("res://art/icons/flask_roubo.png"),
	"caotico": preload("res://art/icons/flask_caotico.png"),
	"mitotico": preload("res://art/icons/flask_mitotico.png"),
	"martir": preload("res://art/icons/flask_martir.png"),
	"gatilho": preload("res://art/icons/flask_gatilho.png"),
	"carga": preload("res://art/icons/flask_carga.png"),
	"eter": preload("res://art/icons/flask_eter.png"),
	"gravidade": preload("res://art/icons/flask_gravidade.png"),
}
const BEAM := {
	"ink": preload("res://art/fx/beam_rare.png"),
	"ash": preload("res://art/fx/beam_unique.png"),
	"flask": preload("res://art/fx/beam_unique.png"),
	"bone": preload("res://art/fx/beam_common.png"),
	"blood": preload("res://art/fx/beam_common.png"),
	"soul": preload("res://art/fx/beam_common.png"),
}

var main
var kind := "bone"
var flask := ""  # qual Frasco de Alma, quando kind == "flask"
var amount := 1
var t := 0.0
var pop := Vector2.ZERO  # salta para fora do baú / do chefe e assenta
var label_y := -44.0


func _ready() -> void:
	# Não tapar o nome de outra moeda caída ao lado: sobe o nome até ficar livre
	for i in 8:
		var clash := false
		for o in get_tree().get_nodes_in_group("loot"):
			if absf(o.position.x - position.x) < 110.0 and absf(o.position.y + o.label_y - position.y - label_y) < 17.0:
				clash = true
				break
		if not clash:
			break
		label_y -= 18.0
	add_to_group("loot")
	var l := Label.new()
	var name_s: String = tr(Player.SUPPORT_NAMES[flask] if kind == "flask" else INFO[kind][0])
	l.text = name_s if amount == 1 else "%s x%d" % [name_s, amount]
	l.add_theme_color_override("font_color", INFO[kind][1])
	l.add_theme_color_override("font_outline_color", Color.BLACK)
	l.add_theme_constant_override("outline_size", 5)
	l.add_theme_font_size_override("font_size", 16)
	l.position = Vector2(-80, label_y)
	l.size = Vector2(160, 20)
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	l.visible = not (main.settings.loot_names == 1 and kind in ["bone", "blood", "soul"] and amount == 1)  # "Só os raros"
	add_child(l)


func _process(delta: float) -> void:
	t += delta
	if kind in ["blood", "soul"] and t > 8.0:
		queue_free()  # o orbe seca se ninguém o apanhar
		return
	position += pop * delta
	pop *= exp(-5.0 * delta)
	queue_redraw()
	var p = main.nearest_player(position)
	if p != null and position.distance_to(p.position) < 260.0 and p.order.any(func(id): return id != "bonearmor" and p.skills[id].support == "gravidade"):  # Alma Gravítica: o saque desliza para o herói (na Armadura de Ossos, que não bate, não conta)
		position = position.move_toward(p.position, 240.0 * delta)
	if t > 0.4 and p != null and position.distance_to(p.position) < 40.0:
		main.collect(self)


func _draw() -> void:
	var c: Color = INFO[kind][1]
	if kind != "bone" or amount > 1:
		var beam: Texture2D = BEAM[kind]
		var h := 130.0 + sin(t * 4.0) * 6.0
		var w := h * beam.get_width() / beam.get_height()
		draw_texture_rect(beam, Rect2(-w / 2.0, -h + 8.0, w, h), false, Color(1, 1, 1, 0.7))
	draw_circle(Vector2.ZERO, 14.0 + sin(t * 5.0) * 3.0, Color(c, 0.2))
	var tex: Texture2D = FLASK_TEX[flask] if kind == "flask" else TEX[kind]
	var sc := 38.0 / maxf(tex.get_width(), tex.get_height())
	var hop := sin(PI * minf(t / 0.45, 1.0)) * 26.0  # ao cair salta em arco
	draw_set_transform(Vector2(0, -8 + sin(t * 3.0) * 2.0 - hop), 0.0, Vector2(sc, sc))
	draw_texture(tex, -tex.get_size() / 2.0)
	draw_set_transform(Vector2.ZERO)
