extends Node2D
## Moeda, Frasco de Alma, orbe de sangue (cura) ou esfera de alma (mana) no chão. Recolha automática ao passar por cima (amigável para mobile).
## As raras têm um feixe de luz: Tinteiro dourado, Cinzas e Frascos verdes, montes de ossos cinzento.
## Efeitos adaptados de Sprite Fusion Pixel Art VFX (MIT, (c) 2026 Hugo Duprez)

const Player := preload("res://player.gd")
const Pix := preload("res://fx_pix.gd")
## [nome, cor, tom do tinido ao cair (0 = em silêncio), tremor do ecrã]: quanto mais raro, mais agudo e mais forte.
const INFO := {
	"bone": ["Osso Ancestral", Color(0.95, 0.85, 0.55), 0.0, 0.0],
	"ink": ["Tinteiro de Sangue Negro", Color(0.85, 0.12, 0.18), 1.25, 3.0],
	"ash": ["Cinzas do Purgatório", Color(1.0, 0.6, 0.2), 1.5, 5.0],
	"flask": ["Frasco de Alma", Color(0.5, 1.0, 0.7), 1.8, 8.0],
	"blood": ["Esfera de Sangue", Color(0.85, 0.12, 0.18), 0.0, 0.0],
	"soul": ["Esfera de Alma", Color(0.35, 0.7, 1.0), 0.0, 0.0],
}
## Rampa de cores (fx_pix.gd) de cada um: o voo para o herói ao apanhar (fx.gd "pickup")
const RAMP := {"bone": "loot_bone", "ink": "loot_ink", "ash": "loot_ash", "flask": "soul", "blood": "bleed", "soul": "soulblue"}
const TEX := {
	"bone": preload("res://art/icons/bone.png"),
	"ink": preload("res://art/icons/ink.png"),
	"ash": preload("res://art/icons/ash.png"),
	"blood": preload("res://art/icons/ink.png"),
	"soul": preload("res://art/icons/potion_soul.png"),  # o ícone da poção de alma do HUD
}
const FLASK_TEX := {
	"": preload("res://art/icons/flask_empty.png"),
	"parasita": preload("res://art/icons/flask_parasita.png"),
	"titanica": preload("res://art/icons/flask_titanica.png"),
	"veloz": preload("res://art/icons/flask_swift.png"),
	"eco": preload("res://art/icons/flask_echo.png"),
	"tumular": preload("res://art/icons/flask_grave.png"),
	"colerica": preload("res://art/icons/flask_wrath.png"),
	"roubo": preload("res://art/icons/flask_roubo.png"),
	"caotico": preload("res://art/icons/flask_caotico.png"),
	"mitotico": preload("res://art/icons/flask_mitotico.png"),
	"martir": preload("res://art/icons/flask_martir.png"),
	"gatilho": preload("res://art/icons/flask_gatilho.png"),
	"carga": preload("res://art/icons/flask_carga.png"),
	"eter": preload("res://art/icons/flask_eter.png"),
	"gravidade": preload("res://art/icons/flask_gravidade.png"),
	"meteoro": preload("res://art/icons/flask_meteoro.png"),
	"terramoto": preload("res://art/icons/flask_terramoto.png"),
	"vinganca": preload("res://art/icons/soul_vinganca.png"),
	"escriba": preload("res://art/icons/soul_escriba.png"),
	"cranios": preload("res://art/icons/soul_cranios.png"),
	"donzela": preload("res://art/icons/soul_donzela.png"),
}
const BEAM := {
	"ink": preload("res://art/fx/beam_rare.png"),
	"ash": preload("res://art/fx/beam_unique.png"),
	"flask": preload("res://art/fx/beam_unique.png"),
	"bone": preload("res://art/fx/beam_common.png"),
	"blood": preload("res://art/fx/beam_common.png"),
	"soul": preload("res://art/fx/beam_common.png"),
}

var main
var kind := "bone"
var flask := ""  # qual Frasco de Alma, quando kind == "flask"
var amount := 1
var t := 0.0
var pop := Vector2.ZERO  # salta para fora do baú / do chefe e assenta
var label_y := -44.0
var lit: Node2D  # o brilho aditivo das estrelas do saque raro
static var _h := []  # Pix.hashf(i, k) das estrelas e dos pontos, iguais em todo o saque: calculados uma vez


func _ready() -> void:
	# Não tapar o nome de outra moeda caída ao lado: sobe o nome até ficar livre
	for i in 8:
		var clash := false
		for o in get_tree().get_nodes_in_group("loot"):
			if absf(o.position.x - position.x) < 110.0 and absf(o.position.y + o.label_y - position.y - label_y) < 17.0:
				clash = true
				break
		if not clash:
			break
		label_y -= 18.0
	add_to_group("loot")
	var l := Label.new()
	var name_s: String = tr(Player.SUPPORT_NAMES[flask] if kind == "flask" else INFO[kind][0])
	l.text = name_s if amount == 1 else "%s x%d" % [name_s, amount]
	l.add_theme_color_override("font_color", INFO[kind][1])
	l.add_theme_color_override("font_outline_color", Color.BLACK)
	l.add_theme_constant_override("outline_size", 5)
	l.add_theme_font_size_override("font_size", 16)
	l.position = Vector2(-80, label_y)
	l.size = Vector2(160, 20)
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	l.visible = not (main.settings.loot_names == 1 and kind in ["bone", "blood", "soul"] and amount == 1)  # "Só os raros"
	add_child(l)
	if kind in ["ink", "ash", "flask"]:  # o raro cintila (tinteiro, cinzas, frascos e Almas Condensadas)
		lit = Node2D.new()
		lit.material = CanvasItemMaterial.new()
		lit.material.blend_mode = CanvasItemMaterial.BLEND_MODE_ADD
		lit.draw.connect(_glints.bind(true))
		add_child(lit)


func _process(delta: float) -> void:
	t += delta
	if kind in ["blood", "soul"] and t > 8.0:
		queue_free()  # o orbe seca se ninguém o apanhar
		return
	position += pop * delta
	pop *= exp(-5.0 * delta)
	queue_redraw()
	var p = main.nearest_player(position)
	if p != null and position.distance_to(p.position) < 260.0 and p.order.any(func(id): return id != "bonearmor" and p.skills[id].support == "gravidade"):  # Alma Gravitacional: o saque desliza para o herói (na Armadura de Ossos, que não bate, não conta)
		position = position.move_toward(p.position, 240.0 * delta)
	if t > 0.4 and p != null and position.distance_to(p.position) < 40.0:
		main.collect(self)


func _draw() -> void:
	var c: Color = INFO[kind][1]
	if kind != "bone" or amount > 1:
		var beam: Texture2D = BEAM[kind]
		var h := 130.0 + sin(t * 4.0) * 6.0
		var w := h * beam.get_width() / beam.get_height()
		var g := lerpf(0.6, 1.0, minf(t / 0.4, 1.0))  # o feixe acende-se ao cair
		draw_texture_rect(beam, Rect2(-w / 2.0, -h + 8.0, w, h), false, Color(g, g, g, 0.7))
	draw_circle(Vector2.ZERO, 14.0 + sin(t * 5.0) * 3.0, Color(c, 0.2))
	var tex: Texture2D = FLASK_TEX[flask] if kind == "flask" else TEX[kind]
	var sc := 38.0 / maxf(tex.get_width(), tex.get_height())
	var hop := sin(PI * minf(t / 0.45, 1.0)) * 26.0  # ao cair salta em arco
	draw_set_transform(Vector2(0, -8 + sin(t * 3.0) * 2.0 - hop), 0.0, Vector2(sc, sc))
	draw_texture(tex, -tex.get_size() / 2.0)
	draw_set_transform(Vector2.ZERO)
	if lit:
		var g := fmod(t - 2.5, 1.6)  # depois da queda só brilha 0,24 s de 1,6 em 1,6 s (_glints)
		if t < 2.5 or g < 0.24:
			_glints(false)
		if t < 2.5 or g < 0.34:  # mais uns frames para a luz se apagar
			lit.queue_redraw()


## Estrelas em píxeis (o sparkle): ao cair, uma estrela de 8 raios que cresce, roda e pulsa, estrelas pequenas à volta e
## pontos a piscar durante 2,5 s; depois um brilho a cada 1,6 s no canto do ícone. Só do t, que também viaja ao convidado.
## Efeitos médios e altos. light = a camada aditiva (os brilhos) ou o próprio saque (os raios).
func _glints(light: bool) -> void:
	var lvl: int = main.effects_level()
	if lvl == 0:
		return
	var ci: CanvasItem = lit if light else self
	var at := Vector2(0, -8 + sin(t * 3.0) * 2.0 - sin(PI * minf(t / 0.45, 1.0)) * 26.0)  # o meio do ícone, como em _draw
	var big := kind != "ink"
	var warm: Array = Pix.RAMPS.gold if big else Pix.RAMPS.loot_ink
	var cool: Array = Pix.RAMPS.soul if big else Pix.RAMPS.gold
	var size := 12.0 if big else 8.0
	if t >= 2.5:
		var g := fmod(t - 2.5, 1.6) / 1.6
		if g < 0.15:
			_flare(ci, light, at + Vector2(-8, -10), 0.5 * size * sin(g / 0.15 * PI), 0.4, warm)
		return
	var gone := 1.0 - Pix.smooth(1.9, 2.5, t)
	var pulse := 1.0 + 0.35 * exp(-pow(t - 0.9, 2.0) / 0.01) + 0.3 * exp(-pow(t - 1.5, 2.0) / 0.01)
	_flare(ci, light, at, size * Pix.out_back(t / 0.25) * gone * pulse, t * 0.7, warm)
	var k := size / 19.0  # a biblioteca mede tudo para uma estrela de 19
	if _h.is_empty():
		for i in 26:
			_h.append(range(8).map(func(n): return Pix.hashf(i, n)))
	for i in roundi(11.0 * main.EFFECTS[lvl]):
		var h: Array = _h[i]
		var u: float = (t - 0.1 - i * 0.17 - h[3] * 0.08) / lerpf(0.35, 0.6, h[4])
		if u > 0.0 and u < 1.0:
			var a: float = h[1] * TAU
			var d := lerpf(9.0, 32.0, h[2]) * k * Pix.S
			_flare(ci, light, at + Vector2(cos(a), sin(a) * 0.85) * d, lerpf(4.0, 8.5, h[5]) * k * pow(sin(u * PI), 0.7), lerpf(-2.0, 2.0, h[6]) * u + 0.4, cool if h[7] < 0.35 else warm)
	if light:
		return
	for i in 26:  # pontos que piscam a 12 Hz à volta
		var fr := floori(t * 12.0) + i * 3
		if Pix.hashf(fr, i) < 0.3 * gone:
			var a: float = _h[i][1] * TAU
			Pix.px(self, at + Vector2(cos(a), sin(a) * 0.8) * (6.0 + _h[i][2] * 40.0) * k * Pix.S, Color.WHITE if Pix.hashf(fr, 5) < 0.5 else warm[1])


func _flare(ci: CanvasItem, light: bool, at: Vector2, L: float, ang: float, r: Array) -> void:
	if L < 0.8:
		return
	if light:
		Pix.glow(ci, at, (4.0 + L * 1.4) * Pix.S, r[2], 0.5)
		Pix.glow(ci, at, (2.0 + L * 0.5) * Pix.S, Color.WHITE, 0.4)
	else:
		Pix.flare(ci, at, L, ang, r[2], r[3])
