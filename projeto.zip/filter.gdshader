shader_type canvas_item;
// Filtro de ecrã por cima de tudo (Configurações > Jogo):
// daltonismo = passa a diferença que o olho não vê para cores que vê (ácido verde, sangue, fogo roxo);
// conforto ocular = menos azul e brancos mais baixos, para jogar à noite.

uniform sampler2D screen : hint_screen_texture, filter_nearest;
uniform int mode = 0;  // 0 nada, 1 protanopia, 2 deuteranopia, 3 tritanopia
uniform float comfort = 0.0;

vec3 to_lms(vec3 c) {
	return vec3(dot(c, vec3(17.8824, 43.5161, 4.11935)), dot(c, vec3(3.45565, 27.1554, 3.86714)),
		dot(c, vec3(0.0299566, 0.184309, 1.46709)));
}

vec3 to_rgb(vec3 l) {
	return vec3(dot(l, vec3(0.0809444479, -0.130504409, 0.116721066)),
		dot(l, vec3(-0.0102485335, 0.0540193266, -0.113614708)),
		dot(l, vec3(-0.000365296938, -0.00412161469, 0.693511405)));
}

void fragment() {
	vec3 c = texture(screen, SCREEN_UV).rgb;
	if (mode > 0) {
		// Como o vê quem tem esse daltonismo; o erro vai para os canais que ele distingue
		vec3 l = to_lms(c);
		if (mode == 1) {
			l = vec3(2.02344 * l.y - 2.52581 * l.z, l.y, l.z);
		} else if (mode == 2) {
			l = vec3(l.x, 0.494207 * l.x + 1.24827 * l.z, l.z);
		} else {
			l = vec3(l.x, l.y, -0.395913 * l.x + 0.801109 * l.y);
		}
		vec3 err = c - to_rgb(l);
		c = clamp(c + vec3(0.0, 0.7 * err.r + err.g, 0.7 * err.r + err.b), 0.0, 1.0);
	}
	vec3 warm = c * vec3(1.0, 0.9, 0.72);
	warm *= 1.0 - 0.18 * dot(warm, vec3(0.333));
	COLOR = vec4(mix(c, warm, comfort), 1.0);
}
