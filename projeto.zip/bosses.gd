extends RefCounted
## S7: os chefes com nome (enemy.boss). Só funções estáticas, sem nós: o convidado desenha-os com os campos do monstro,
## que já viajam (os membros, a corrente, a guilhotina, as pedras). Na cripta, um por descida: o Carcereiro, o Colosso
## Suturado (#31), o Monge Penitente Cego (#193) e o Carrasco Sem Rosto (#44); no Cortejo, o Guardião dos Monumentos
## (#204); no altar do cemitério, o Titã Petrificado (#70); no Santuário, o Deus Cadavérico (#50).

## [nome, o que diz o cartão, tamanho, cor, vida, velocidade]. A vida multiplica a de quem nasce: na cripta a do
## Carcereiro (o Monge e o Carrasco são Arautos, com 0,45 dela ficam iguais), no Cortejo e no altar a do colosso; no
## Santuário a do Arauto, x 1,5 (com a armadura de 40% os golpes diretos custam 1500 x 1,5 x a vida do Círculo).
const INFO := {
	"": ["Carcereiro da Cripta", "Guarda os mortos que não descansam", 1.0, Color.WHITE, 1.0, 1.0],
	"suturado": ["Colosso Suturado", "Corta-lhe os braços e as pernas para chegares ao núcleo", 1.35, Color(0.95, 0.78, 0.72), 1.0, 1.0],
	"monge": ["Monge Penitente Cego", "Caça pelo som: anda devagar e evita as habilidades com custo", 1.0, Color(0.7, 0.6, 0.5), 0.45, 1.5],
	"carrasco": ["Carrasco Sem Rosto", "Não deixes que te prenda", 1.0, Color(0.7, 0.64, 0.76), 0.45, 1.0],  # escuro, com o contorno claro (enemy._draw)
	"guardiao": ["Guardião dos Monumentos", "Parte as estátuas para lhe chegares", 1.3, Color(0.7, 0.72, 0.7), 2.3, 1.0],
	"tita": ["Titã Petrificado", "Desperta do altar", 1.5, Color(0.62, 0.62, 0.58), 2.5, 1.0],
	"santuario": ["Deus Cadavérico", "Primeira lei: a cura fere", 1.4, Color(1.0, 0.85, 0.5), 1.5, 1.0],
}
const LIMBS := [Vector2(-46, -110), Vector2(46, -110), Vector2(-26, -30), Vector2(26, -30)]  # Suturado: braço esq., braço dir., perna esq., perna dir. (x tamanho)
const CHAIN_T := 0.8  # Carrasco: o aviso da corrente, e quanto tempo prende
const ROOT_T := 1.6
const BLADE_V := 600.0  # e a guilhotina: a velocidade e quanto tempo varre
const BLADE_T := 1.2
const Pix := preload("res://fx_pix.gd")
const RAIN_T := 1.0  # Titã e Guardião: o aviso das pedras e da Pisada enche durante isto


## Faz de e o chefe id: nome, tamanho, cor, vida, velocidade e o que cada um precisa para começar.
static func make(e, id: String) -> void:
	var info: Array = INFO[id]
	e.boss = id
	e.title = info[0]
	e.grow(info[2])
	e.paint = info[3]
	e.max_hp *= info[4]
	e.hp = e.max_hp
	e.hp_chunk = e.max_hp
	e.speed *= info[5]
	e.heard = e.main.time  # o Monge só ouve o que soar depois de nascer
	e.goal = e.position
	e.boss_t = e.main.time + 3.0  # a 1.ª corrente, Pisada ou chuva de pedras
	if id == "suturado":
		e.limbs = [1.0, 1.0, 1.0, 1.0]
	elif id == "carrasco":
		e.summon_cd = INF  # a corrente e o sino; não chama mortos


## Um golpe no chefe: devolve por quanto se multiplica o dano que chega ao corpo (0 = não chega). O Suturado leva-o num
## membro enquanto tiver algum (o mais perto de quem bate; o dano contínuo vai passando de um para outro) e, sem nenhum,
## leva +25%; o Guardião não leva nada com uma estátua de pé; o golpe no Monge faz barulho onde ele está.
static func hurt(e, amount: float, dir: Vector2, flashes: bool) -> float:
	var m = e.main
	match e.boss:
		"suturado":
			var alive: Array = range(4).filter(func(i): return e.limbs[i] > 0.0)
			if alive.is_empty():
				return 1.25
			var i: int = alive[e.boss_n % alive.size()]
			if dir == Vector2.ZERO:
				e.boss_n += 1
			else:  # quem bate está do lado de onde o golpe vem
				alive.sort_custom(func(a, b): return (LIMBS[a] * e.size + dir * 120.0).length() < (LIMBS[b] * e.size + dir * 120.0).length())
				i = alive[0]
			e.limbs[i] = maxf(0.0, e.limbs[i] - amount / (e.max_hp * 0.12))  # cada membro aguenta 12% da vida
			var at: Vector2 = e.position + LIMBS[i] * e.size
			if flashes:
				m.number(at + Vector2(0, -18), str(roundi(amount)), 16.0, Color(1.0, 0.82, 0.72))
				if e.num_t > 0.5:
					e._number("Imune", 16.0, Color(0.75, 0.75, 0.75))
			if e.limbs[i] <= 0.0:  # o membro cai: pó, um crânio no chão (que rebenta como os cadáveres) e um rugido
				m.spawn_fx("dust", at, 70.0, Color(0.9, 0.8, 0.75))
				m.corpses.append([Vector2(at.x, e.position.y + 12.0), 0, m.time + m.CORPSE_T, clampf(e.max_hp * 0.05, 8.0, 90.0)])
				if m.corpses.size() > 8:
					m.corpses.pop_front()
				m.sfx("roar")
				m.shake = maxf(m.shake, 10.0)
				var legs: int = [2, 3].filter(func(k): return e.limbs[k] <= 0.0).size()
				e.speed = e.STATS.colossus[1] * e.mods.get("speed", 1.0) * pow(0.6, legs)  # cada perna a menos, 60%
				if e.limbs.max() <= 0.0:
					m.hud.name_card("O núcleo está exposto!", "", "")
			return 0.0
		"guardiao":
			if m.enemies().any(func(o): return o.anchor):
				if flashes and e.num_t > 0.3:
					e._number("Imune", 18.0, Color(0.75, 0.8, 0.75))
				return 0.0
		"monge":
			if flashes:
				m.noise(e.position, 0.0)
	return 1.0


## A cada frame, no anfitrião (enemy._move, antes de ver se está preso ou quebrado: o que já foi avisado cai sempre).
## Devolve true quando foi ele a mexer o chefe (o Monge).
static func tick(e, delta: float) -> bool:
	var m = e.main
	if e.rain_at > 0.0 and m.time >= e.rain_at:  # as pedras do Titã e a Pisada do Guardião caem
		for r in e.rain:
			m.boss_slam(r[0], r[1], e.dmg, e.who(), e, "hit")
		e.rain = []
		e.rain_at = 0.0
	var free: bool = e.awake and e.stagger_t <= 0.0 and e.statue_t <= 0.0 and e.pin_t <= 0.0 and e.windup_t <= 0.0 and e.blind_t <= 0.0
	match e.boss:
		"monge":
			return _monk(e, delta)
		"carrasco":
			_executioner(e, free)
		"guardiao":
			if e.boss_n == 0 and e.hp <= e.max_hp * 0.5:  # a meio da vida as estátuas erguem-se outra vez (uma vez só)
				e.boss_n = 1
				m.raise_statues(e)
				m.hud.toast("As estátuas erguem-se outra vez!")
			if free and m.time >= e.boss_t:  # a Pisada: um anel de 200 px à volta dele, a cada 6 s
				e.boss_t = m.time + 6.0
				e.rain = [[e.position, 200.0]]
				e.rain_at = m.time + RAIN_T
		"santuario":  # Santuário (#50): a cada 25% da vida perdida, a lei seguinte (main.LAWS), com o cartão dela
			var law := mini(4, 1 + int((1.0 - e.hp / e.max_hp) * 4.0))
			if law > m.sanctum_rule and m.sanctum_rule > 0:
				m.sanctum_rule = law
				m.hud.name_card(m.LAWS[law - 1][0], m.LAWS[law - 1][2], "Santuário")
				m.sfx("bell")
		"tita":
			var alive: Array = m.players.filter(func(p): return not p.dead)
			if free and m.time >= e.boss_t and not alive.is_empty():  # chuva de pedras: 3 avisos de 90 px em cima dos heróis, a cada 8 s
				e.boss_t = m.time + 8.0
				e.rain = range(3).map(func(i): return [alive[i % alive.size()].position + (Vector2.ZERO if i < alive.size() else Vector2.from_angle(randf() * TAU) * 140.0), 90.0])
				e.rain_at = m.time + RAIN_T
	return false


## Monge Penitente Cego (#193): só o barulho o guia. A um barulho novo a menos de 900 px corre para lá (x3, até 0,8 s) e
## bate o sino (150 px, dano x1,2), e só volta a reagir 1 s depois; senão anda devagar (x0,4) para o último que ouviu.
## Nunca persegue um herói nem chama mortos.
static func _monk(e, delta: float) -> bool:
	var m = e.main
	if e.stagger_t > 0.0 or e.statue_t > 0.0 or e.pin_t > 0.0:
		return false  # preso ou quebrado: o enemy._move trata disso
	var q = m.nearest_player(e.position)
	if q != null:
		e.target = q  # só para se virar para ele no desenho
		e.awake = e.awake or q.position.distance_to(e.position) < e.aggro
	e.slam_cd -= delta
	if e.act == "slam":  # o sino do Arauto: o aviso enche e cai
		e.act_t += delta
		if e.act_t >= e.ACT_T * 0.5 and not e.act_done:
			e.act_done = true
			m.boss_slam(e.position + Vector2(0, 10), 150.0, e.dmg * 1.2, e.who(), e)
		if e.act_t >= e.ACT_T:
			e.act = ""
			e.slam_cd = 1.0
		return true
	if e.act == "dash":
		e.act_t += delta
		var to: Vector2 = e.goal - e.position
		if to.length() < 24.0 or e.act_t >= 0.8:
			e._start("slam")
		else:
			e.position += to.limit_length(e.speed * 3.0 * delta)
		return true
	if m.noise_t > e.heard and e.slam_cd <= 0.0 and e.blind_t <= 0.0:  # um barulho novo
		e.heard = m.noise_t
		e.goal = m.noise_at
		if m.noise_at.distance_to(e.position) < 900.0:
			e._start("dash")
			return true
	var way: Vector2 = e.goal - e.position
	if way.length() > 24.0:
		e.position += way.normalized() * e.speed * 0.4 * delta
	return true


## Carrasco Sem Rosto (#44): a cada 5 s atira a corrente ao herói mais perto (até 700 px). 0,8 s de aviso e depois quem
## estiver a 20 px da linha leva 10% da vida e fica preso 1,6 s (esquivar através dela é esquiva perfeita, sem prisão).
## A cada 3.ª corrente, 0,5 s depois, aparece atrás de quem ela apanhou a guilhotina (1000 px), que 1 s depois varre para
## o Carrasco a 600 px/s: tira 35% da vida, e quem estiver preso é decapitado; a esquiva passa por baixo dela.
static func _executioner(e, free: bool) -> void:
	var m = e.main
	if e.chain_at > 0.0 and m.time >= e.chain_at:
		e.chain_at = 0.0
		m.sfx("hit")
		var hit = null
		for p in m.players:
			if not p.dead and Geometry2D.get_closest_point_to_segment(p.position, e.chain_from, e.chain_to).distance_to(p.position) < 20.0:
				var dodged: bool = p.dash_t > 0.0
				p.take_damage(p.max_hp * 0.1, e.who(), e)
				if not dodged and not p.dead:
					p.root_until = m.time + ROOT_T
					hit = p
		if e.boss_n % 3 == 0:
			var at: Vector2 = hit.position if hit != null else e.chain_to - e.chain_from.direction_to(e.chain_to) * 150.0
			e.blade_dir = at.direction_to(e.position)
			e.blade_from = at - e.blade_dir * 30.0
			e.blade_at = m.time + 1.5
			e.cut = []  # cada herói só leva com ela uma vez
	var s: float = (m.time - e.blade_at) * BLADE_V
	if e.blade_at > 0.0 and s >= 0.0 and s < BLADE_V * BLADE_T:
		for p in m.players:
			var v: Vector2 = p.position - e.blade_from
			if not p.dead and not p in e.cut and absf(v.dot(e.blade_dir) - s) < 30.0 and absf(v.cross(e.blade_dir)) < 500.0:
				e.cut.append(p)
				if p.root_until > m.time and p.dash_t <= 0.0:
					m.number(p.position + Vector2(0, -130), "Decapitado!", 24.0, Color(1.0, 0.2, 0.2))
					p.slay(e.who())
					continue
				if p.dash_t <= 0.0:
					m.number(p.position + Vector2(0, -130), "Guilhotina!", 22.0, Color(1.0, 0.35, 0.3))
				p.take_damage(p.max_hp * 0.35, e.who(), e)
	if free and m.time >= e.boss_t and e.act == "" and e.chain_at == 0.0:
		var q = m.nearest_player(e.position)
		if q != null and q.position.distance_to(e.position) < 700.0:
			e.boss_t = m.time + 5.0
			e.boss_n += 1
			e.chain_from = e.position
			e.chain_to = q.position + e.position.direction_to(q.position) * 150.0
			e.chain_at = m.time + CHAIN_T
			m.sfx("swing_heavy")


## O que cada telemóvel desenha do chefe, só com os campos que viajam. front = false: no chão, antes do desenho dele (os
## avisos das pedras e da Pisada); true: por cima (membros, corrente, guilhotina, raios das estátuas).
static func draw(e, front: bool) -> void:
	var m = e.main
	if e.dying:
		return
	if not front:
		for r in e.rain:  # enchem até cair, como o aviso do murro
			var at: Vector2 = r[0] - e.position
			Pix.warn(e, at, r[1], 1.0 - (e.rain_at - m.time) / RAIN_T)
		return
	match e.boss:
		"suturado":  # os membros cosidos, cada um com a sua barra
			for i in e.limbs.size():
				if e.limbs[i] > 0.0:
					var c: Vector2 = LIMBS[i] * e.size
					Pix.orb(e, c, 10, "bleed")
					e.draw_rect(Rect2(Pix.snap(e, c + Vector2(-14, -1)), Vector2(28, Pix.S)), Color(0.1, 0.05, 0.05))  # a costura
					for k in 4:
						e.draw_rect(Rect2(Pix.snap(e, c + Vector2(-12 + 8 * k, -7)), Vector2(Pix.S, 14)), Color(0.1, 0.05, 0.05))
					e.draw_rect(Rect2(c + Vector2(-22, 25), Vector2(44, 6)), Color(0, 0, 0, 0.7))
					e.draw_rect(Rect2(c + Vector2(-22, 25), Vector2(44 * e.limbs[i], 6)), Color(0.85, 0.2, 0.2))
		"carrasco":
			var hand := Vector2(0, e._top() * 0.45)
			if e.chain_at > m.time:  # o aviso: a linha vermelha por onde a corrente vai passar
				e.draw_line(e.chain_from - e.position, e.chain_to - e.position, Color(1.0, 0.15, 0.1, 0.35 + 0.3 * sin(m.time * 20.0)), 8.0)
			for p in m.players:  # quem está preso: a corrente de ferro esticada até ele
				if p.root_until > m.time and not p.dead:
					e.draw_line(hand, p.position - e.position + Vector2(0, -20), Color(0.15, 0.15, 0.17), 6.0)
					e.draw_line(hand, p.position - e.position + Vector2(0, -20), Color(0.6, 0.6, 0.66), 3.0)
			var s: float = (m.time - e.blade_at) * BLADE_V
			if e.blade_at > 0.0 and s > -BLADE_V and s < BLADE_V * BLADE_T:  # a guilhotina: 1 s parada a avisar e depois varre
				var c: Vector2 = e.blade_from - e.position + e.blade_dir * maxf(s, 0.0)
				var o: Vector2 = e.blade_dir.orthogonal() * 500.0
				if s < 0.0:
					e.draw_line(c - o, c + o, Color(1.0, 0.15, 0.1, 0.3 + 0.25 * sin(m.time * 16.0)), 10.0)
				else:
					e.draw_line(c - o, c + o, Color(0.12, 0.12, 0.14), 14.0)
					e.draw_line(c - o, c + o, Color(0.8, 0.82, 0.88), 6.0)
		"guardiao":  # os raios verde-pedra das estátuas até ele
			for o in m.enemies():
				if o.anchor:
					e.draw_line(Vector2(0, e._top() * 0.5), o.position - e.position + Vector2(0, o._top() * 0.5), Color(0.55, 0.85, 0.65, 0.45 + 0.2 * sin(m.time * 6.0)), 5.0)
