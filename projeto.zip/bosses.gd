extends RefCounted
## S7: os chefes com nome (enemy.boss). Lote 7: a Matriarca dos Vermes (#40, na cripta) e o Bispo dos Leprosos (#183, no Ossário
## dos Sepulcros). Só funções estáticas, sem nós: o convidado desenha-os com os campos do monstro,
## que já viajam (os membros, a corrente, a guilhotina, as pedras). Na cripta, um por descida: o Carcereiro, o Colosso
## Suturado (#31), o Monge Penitente Cego (#193), o Carrasco Sem Rosto (#44), o Arquivista de Crânios (#29) e a Sibila
## dos Ossos Quebrados (#213); no Cortejo, o Guardião dos Monumentos (#204); no altar do cemitério, o Titã Petrificado
## (#70); no Santuário, o Deus Cadavérico (#50). S13: os guardiões dos Sepulcros alternam a cada ida e o Mausoléu tem um
## chefe novo a cada 10 pisos: a Tecelã de Mortalhas (#207), o Marechal de Ferro (#201) e o Arquilich Blindado (#217).

## [nome, o que diz o cartão, tamanho, cor, vida, velocidade]. A vida multiplica a de quem nasce: na cripta a do
## Carcereiro (o Monge e o Carrasco são Arautos, com 0,45 dela ficam iguais), no Cortejo e no altar a do colosso; no
## Santuário a do Arauto, x 1,5 (com a armadura de 40% os golpes diretos custam 1500 x 1,5 x a vida do Círculo). A
## Tecelã nasce espectro: 18 x 21,7 = a vida de um colosso.
const INFO := {
	"": ["Carcereiro da Cripta", "Guarda os mortos que não descansam", 1.0, Color.WHITE, 1.0, 1.0],
	"suturado": ["Colosso Suturado", "Corta-lhe os braços e as pernas para chegares ao núcleo", 1.35, Color(0.95, 0.78, 0.72), 1.0, 1.0],
	"monge": ["Monge Penitente Cego", "Caça pelo som: anda devagar e evita as habilidades com custo", 1.0, Color(0.7, 0.6, 0.5), 0.45, 1.5],
	"carrasco": ["Carrasco Sem Rosto", "Não deixes que te prenda", 1.0, Color(0.7, 0.64, 0.76), 0.45, 1.0],  # escuro, com o contorno claro (enemy._draw)
	"guardiao": ["Guardião dos Monumentos", "Parte as estátuas para lhe chegares", 1.3, Color(0.7, 0.72, 0.7), 2.3, 1.0],
	"tita": ["Titã Petrificado", "Desperta do altar", 1.5, Color(0.62, 0.62, 0.58), 2.5, 1.0],
	"santuario": ["Deus Cadavérico", "Primeira lei: a cura fere", 1.4, Color(1.0, 0.85, 0.5), 1.5, 1.0],
	"arquivista": ["Arquivista de Crânios", "Copia as tuas habilidades: varia os golpes", 1.15, Color(0.92, 0.86, 0.7), 0.45, 1.0],
	"sibila": ["Sibila dos Ossos Quebrados", "Fecha-se ao que mais usas: varia os golpes", 1.1, Color(0.78, 0.72, 0.95), 0.45, 1.0],
	"tecela": ["Tecelã de Mortalhas", "Corta a agulha para te soltares", 2.2, Color(0.92, 0.92, 1.0), 21.7, 0.7],
	"marechal": ["Marechal de Ferro", "Desvia-te da investida e deixa-o bater na parede", 1.35, Color(0.66, 0.72, 0.86), 1.0, 1.0],
	"arquilich": ["Arquilich Blindado", "Devolve-lhe os feitiços para partir as runas", 1.2, Color(0.62, 0.74, 1.0), 0.45, 1.0],
	"matriarca": ["Matriarca dos Vermes", "Parte os ovos antes que rebentem", 1.45, Color(0.72, 0.92, 0.55), 1.0, 0.9],
	"bispo": ["Bispo dos Leprosos", "Derruba os penitentes: as orações protegem-no", 1.1, Color(1.3, 1.35, 1.05), 0.45, 1.0],  # mais claro que o Arauto, com o contorno claro (enemy._draw): no chão escuro dos Sepulcros era só uma sombra
	# Lote 9: as cores dos novos passam de 1 (mais claras do que o desenho) e todos levam o contorno claro (enemy._draw)
	"donzela_l": ["Donzela das Lâminas", "Só uma ataca de cada vez: bate na que brilha", 2.3, Color(0.85, 1.0, 1.25), 7.2, 1.0],  # #187: 3 x 18 x 7,2 = a vida de um colosso
	"donzela_c": ["Donzela dos Cabelos", "Só uma ataca de cada vez: bate na que brilha", 2.3, Color(1.1, 0.8, 1.25), 7.2, 1.0],
	"donzela_g": ["Donzela do Grito", "Só uma ataca de cada vez: bate na que brilha", 2.3, Color(1.3, 0.85, 0.85), 7.2, 1.0],
	"quimera": ["Quimera dos Reis", "Olha para a arma por cima dela", 1.6, Color(1.3, 1.15, 0.8), 1.0, 0.9],  # #190
	"rei_ouro": ["Rei de Ouro", "Os reis trocam de armas a cada quarto da vida", 1.3, Color(1.4, 1.2, 0.6), 1.2, 1.0],  # #34
	"rei_prata": ["Rei de Prata", "Os reis trocam de armas a cada quarto da vida", 1.3, Color(1.15, 1.22, 1.4), 1.2, 1.0],
	"rei_bronze": ["Rei de Bronze", "Os reis trocam de armas a cada quarto da vida", 1.3, Color(1.35, 0.92, 0.62), 1.2, 1.0],
	"amalgama": ["Amálgama Primordial", "Cinco chefes numa só alma: a cada quinto da vida veste outro", 1.7, Color(1.15, 1.05, 1.0), 2.5, 1.0],  # #220: o Arauto x 2,5
	"carruagem": ["Carruagem Fúnebre", "Parte as rodas para a parar", 1.0, Color.WHITE, 3.0, 1.0],  # #48: o colosso x 3, sem o desenho dele (draw_cart)
}
## Lote 9: o nome que fica na barra e no Livro dos Chefes (#187 e #34 lutam em grupo; o Carcereiro e o Arauto não têm boss)
const BOOK := {
	"carcereiro": ["Carcereiro da Cripta", "Guarda os mortos que não descansam"],
	"arauto": ["Arauto Fúnebre", "Mensageiro do Cortejo Fúnebre"],
	"donzelas": ["Triunvirato das Donzelas Mortas", "Só uma ataca de cada vez: bate na que brilha"],
	"reis": ["Os Reis Caídos", "Os reis trocam de armas a cada quarto da vida"],
}
const MAIDENS := ["donzela_l", "donzela_c", "donzela_g"]  # #187: a vez passa por esta ordem
const STYLES := ["espada", "machado", "foice", "cetro", "escudo"]  # #190: a arma da Quimera, uma por cada 20% da vida perdida
const GRAB := {"espada": "Pega na Espada!", "machado": "Pega no Machado!", "foice": "Pega na Foice!", "cetro": "Pega no Cetro!", "escudo": "Pega no Escudo!"}
const ROLES := ["escudo", "espada", "cetro"]  # #34: os papéis dos Reis; quem cai leva o Escudo primeiro
const KINGS := ["rei_ouro", "rei_prata", "rei_bronze"]
const PHASES := ["suturado", "carrasco", "monge", "guardiao", "santuario"]  # #220: a Amálgama veste-os um por cada 20% da vida
const ARMS := {"espada": preload("res://art/icons/sword.png"), "machado": preload("res://art/icons/greataxe.png"), "foice": preload("res://art/icons/scythe.png"),
	"cetro": preload("res://art/icons/staff.png"), "escudo": preload("res://art/icons/shield.png")}
const SCREAM_V := 350.0  # Donzela do Grito: o anel cresce a esta velocidade até SCREAM_R
const SCREAM_R := 520.0
const CART_V := 90.0  # #48: a carruagem anda a isto pela estrada (cada roda partida, x0,7) e larga 2 escoltas a cada 6 s, no máximo 8
const CART_T := 150.0
const WHEELS := [Vector2(-78, -40), Vector2(-8, 14)]  # as rodas que se veem (trás, frente), a andar para a direita; as de lá ficavam atrás do caixão (revisão do Lote 9). Por baixo da borda do caixão, só o cimo delas por cima dele
const CART_BODY := Rect2(-104, -166, 196, 184)  # o caixão x 2: os mesmos píxeis de 2 px das rodas (a x 2,2 não batiam com elas)
const CART_NOSE := Vector2(56, -4)  # a ponta da frente, onde a longarina acaba e começa o varal
const CART_LAMP := Vector2(-46, -140)  # a lanterna, no tampo (atrás da cruz)
const COFFIN := preload("res://art/props/coffin.png")
static var _coffin_ct: CanvasTexture
## S13: o corpo de cada um (spawn_kind; quem não está aqui nasce colosso). "arauto" é o Arauto Fúnebre dos Sepulcros e do Mausoléu, sem make.
const BASE := {"monge": "herald", "carrasco": "herald", "santuario": "herald", "arauto": "herald", "arquivista": "herald", "sibila": "herald", "arquilich": "herald", "tecela": "specter", "bispo": "herald",
	"donzela_l": "specter", "donzela_c": "specter", "donzela_g": "specter", "donzelas": "specter", "amalgama": "herald"}
const LIMBS := [Vector2(-46, -110), Vector2(46, -110), Vector2(-26, -30), Vector2(26, -30)]  # Suturado: braço esq., braço dir., perna esq., perna dir. (x tamanho)
const CHAIN_T := 0.8  # Carrasco: o aviso da corrente, e quanto tempo prende
const ROOT_T := 1.6
const BLADE_V := 600.0  # e a guilhotina: a velocidade e quanto tempo varre
const BLADE_T := 1.2
const Pix := preload("res://fx_pix.gd")
const RAIN_T := 1.0  # Titã e Guardião: o aviso das pedras e da Pisada enche durante isto
const STATUE := "Estátua Funerária"  # só estas guardam o Guardião (as agulhas da Tecelã também estão presas ao chão)
const WARDS := {"golpes": "bone", "feitiços": "necro", "sangue": "bleed"}  # Sibila: ao que se fecha e a cor do anel
const RUNE_N := 4  # Arquilich: as runas que o guardam
const SEW_T := 8.0  # Tecelã: quanto tempo o fio cose o herói ao chão
const EGG_T := 5.0  # Matriarca (#40): os ovos rebentam ao fim disto; no máximo 6 de cada vez
const EGG_MAX := 6
const PENITENT := "Penitente"  # Bispo (#183): os 6 que rezam por ele
const EGG := [Vector2(-10, 0), Vector2(-13, -8), Vector2(-12, -18), Vector2(-7, -26), Vector2(0, -29), Vector2(7, -26), Vector2(12, -18), Vector2(13, -8), Vector2(10, 0)]  # o ovo, de pé, com a sombra do lado direito
const EGG_SHADE := [Vector2(3, -1), Vector2(7, -8), Vector2(7, -18), Vector2(4, -26), Vector2(7, -26), Vector2(12, -18), Vector2(13, -8), Vector2(10, 0)]
static var old_lance := false  # a lança do Marechal como era no Lote 2 (uma barra lisa): só para a captura de antes e depois
const FEM := ["sibila", "tecela", "matriarca", "donzela_l", "donzela_c", "donzela_g", "quimera"]  # as chefes: "A %s caiu!" (main._on_enemy_killed)


## O corpo em que nasce o chefe id (o Arauto, o colosso ou o espectro).
static func spawn_kind(id: String) -> String:
	return BASE.get(id, "colossus")


## Faz de e o chefe id: nome, tamanho, cor, vida, velocidade e o que cada um precisa para começar.
static func make(e, id: String) -> void:
	var info: Array = INFO[id]
	e.boss = id
	e.is_boss = true  # S13: também o de corpo de espectro (a Tecelã): barra, postura e o XP de um colosso
	e.title = info[0]
	e.grow(info[2])
	e.paint = info[3]
	e.max_hp *= info[4]
	e.hp = e.max_hp
	e.hp_chunk = e.max_hp
	e.speed *= info[5]
	if e.kind == "specter":  # e a armadura de 40% dos colossos: a vida de um colosso custa o mesmo a gastar
		e.armor = e.STATS.colossus[4]
	e.heard = e.main.time  # o Monge só ouve o que soar depois de nascer
	e.goal = e.position
	e.boss_t = e.main.time + 3.0  # a 1.ª corrente, Pisada, chuva de pedras, investida ou fio
	if id == "suturado":
		e.limbs = [1.0, 1.0, 1.0, 1.0]
	elif id in ["carrasco", "arquivista", "arquilich", "bispo"]:
		e.summon_cd = INF  # a corrente e o sino, as habilidades copiadas, as esferas: não chamam mortos
	if id == "arquilich":
		e.runes = RUNE_N
	elif id == "matriarca":
		e.boss_k = e.main.time + 4.0  # os primeiros ovos
	elif id in MAIDENS:
		e.trio = "donzelas"
	elif id in KINGS:
		e.trio = "reis"
	elif id == "quimera":
		e.style = STYLES[0]
	elif id == "carruagem":
		e.limbs = [1.0, 1.0]  # as rodas
		e.speed = CART_V
		e.boss_t = e.main.time + 6.0  # as primeiras escoltas
	elif id == "amalgama":
		e.style = "amalgama"  # #220: o que a distingue do chefe que veste (e.boss muda a cada fase)
		phase(e, PHASES[0])


## Lote 9, #187: as três Donzelas, lado a lado em at; devolve-as pela ordem da vez.
static func maidens(m, at: Vector2, mods: Dictionary) -> Array:
	var out := []
	for i in 3:
		var d = m.spawn_enemy("specter", at + Vector2(-220 + 220 * i, -20 * (i % 2)), mods, false)
		make(d, MAIDENS[i])
		out.append(d)
	return out


## Lote 9: o id do chefe no Livro dos Chefes ("" quem não entra: os mortos normais, as Sentinelas, os Reforços...).
static func book_id(e) -> String:
	if e.trio != "":
		return e.trio
	if e.style == "amalgama":
		return "amalgama"
	if e.boss != "":
		return e.boss
	if e.kind == "herald":
		return "arauto"
	return "carcereiro" if e.title == INFO[""][0] else ""


## #220: a Amálgama veste o chefe id sem mexer na vida: os membros, a corrente, o ouvido, as estátuas ou a 4.ª lei do
## Santuário (a arena vai fechando, _amalgam). O que a fase de antes deixou no chão sai com ela.
static func phase(e, id: String) -> void:
	var m = e.main
	if e.boss == "guardiao":
		for o in m.enemies():
			if o.anchor and o.title == STATUE:
				m.spawn_fx("dust", o.position, 60.0, Color(0.8, 0.8, 0.75))
				o.queue_free()
	e.boss = id
	e.limbs = [1.0, 1.0, 1.0, 1.0] if id == "suturado" else []
	e.chain_at = 0.0
	e.blade_at = 0.0
	e.rain = []
	e.rain_at = 0.0
	e.later = []
	e.act = ""
	e.boss_n = 0
	e.boss_t = m.time + 3.0
	e.heard = m.time
	e.summon_cd = INF if id == "carrasco" else 11.0
	e.speed = e.STATS.herald[1] * e.mods.get("speed", 1.0)
	if id == "guardiao":
		e.boss_n = 1  # as estátuas só uma vez (o Guardião ergue-as outra vez a meio da vida)
		m.raise_statues(e)
	elif id == "santuario":
		m.sanctum_rule = 4


## Um golpe no chefe: devolve por quanto se multiplica o dano que chega ao corpo (0 = não chega). O Suturado leva-o num
## membro enquanto tiver algum (o mais perto de quem bate; o dano contínuo vai passando de um para outro) e, sem nenhum,
## leva +25%; o Guardião não leva nada com uma estátua de pé, nem o Arquilich com uma runa; a Sibila nada do tipo a que
## está fechada (o sangramento e o dano contínuo são "sangue", os golpes físicos "golpes", o resto "feitiços"); o golpe no
## Monge faz barulho onde ele está.
static func hurt(e, amount: float, dir: Vector2, flashes: bool) -> float:
	var m = e.main
	match e.boss:
		"suturado", "carruagem":  # Lote 9, #48: as 2 rodas da carruagem são membros (20% da vida cada), como os do Suturado
			var cart: bool = e.boss == "carruagem"
			var alive: Array = range(e.limbs.size()).filter(func(i): return e.limbs[i] > 0.0)
			if alive.is_empty():
				return 1.25
			var spots: Array = range(e.limbs.size()).map(func(k): return wheel_at(e, k) if cart else LIMBS[k] * e.size)
			var i: int = alive[e.boss_n % alive.size()]
			if dir == Vector2.ZERO:
				e.boss_n += 1
			else:  # quem bate está do lado de onde o golpe vem
				alive.sort_custom(func(a, b): return (spots[a] + dir * 120.0).length() < (spots[b] + dir * 120.0).length())
				i = alive[0]
			e.limbs[i] = maxf(0.0, e.limbs[i] - amount / (e.max_hp * (0.2 if cart else 0.12)))  # cada membro aguenta 12% da vida
			var at: Vector2 = e.position + spots[i]
			if flashes:
				m.number(at + Vector2(0, -18), str(roundi(amount)), 16.0, Color(1.0, 0.82, 0.72))
				if e.num_t > 0.5:
					e._number("Imune", 16.0, Color(0.75, 0.75, 0.75))
			if e.limbs[i] <= 0.0:  # o membro cai: pó, um crânio no chão (que rebenta como os cadáveres) e um rugido
				m.spawn_fx("dust", at, 70.0, Color(0.9, 0.8, 0.75))
				m.shake = maxf(m.shake, 10.0)
				if cart:  # a roda parte-se: lascas de ferro e a carruagem anda menos (sem nenhuma, para)
					m.spawn_fx("sparks", at + Vector2(0, -20), 0.0, Color(0.75, 0.8, 0.9), Vector2.UP)
					m.sfx("creak", 0.7)
					var gone: int = e.limbs.filter(func(l): return l <= 0.0).size()
					e.speed = CART_V * pow(0.7, gone) if gone < e.limbs.size() else 0.0
					if gone >= e.limbs.size():
						m.hud.name_card("A carruagem parou!", "", "")
					return 0.0
				m.corpses.append([Vector2(at.x, e.position.y + 12.0), 0, m.time + m.CORPSE_T, clampf(e.max_hp * 0.05, 8.0, 90.0)])
				if m.corpses.size() > 8:
					m.corpses.pop_front()
				m.sfx("roar")
				var legs: int = [2, 3].filter(func(k): return e.limbs[k] <= 0.0).size()
				e.speed = e.STATS[e.kind][1] * e.mods.get("speed", 1.0) * pow(0.6, legs)  # cada perna a menos, 60% (a Amálgama, #220, é um Arauto)
				if e.limbs.max() <= 0.0:
					m.hud.name_card("O núcleo está exposto!", "", "")
			return 0.0
		"quimera":  # #190: com o Escudo só passa 20% pela frente (de trás, tudo)
			if e.style == "escudo" and dir != Vector2.ZERO and e.target != null and dir.dot(e.position.direction_to(e.target.position)) < 0.0:
				if flashes and e.num_t > 0.3:
					e._number("Bloqueado", 18.0, Color(1.0, 0.9, 0.66))
				return 0.2
		"rei_ouro", "rei_prata", "rei_bronze":  # #34: o rei do Escudo só leva 25%
			if e.style == "escudo":
				return 0.25
		"donzela_l", "donzela_c", "donzela_g":  # #187: as que não estão na vez só levam 25%
			if e.turn_at <= 0.0:
				return 0.25
		"guardiao":
			if m.enemies().any(func(o): return o.anchor and o.title == STATUE):
				if flashes and e.num_t > 0.3:
					e._number("Imune", 18.0, Color(0.75, 0.8, 0.75))
				return 0.0
		"arquilich":
			if e.runes > 0:
				if flashes and e.num_t > 0.3:
					e._number("Imune", 18.0, Color(0.62, 0.74, 1.0))
				return 0.0
		"bispo":  # Bispo dos Leprosos (#183): com um penitente a rezar só passa 35% (não é imune: o Guardião já é)
			if penitents(m) > 0:
				return 0.35
		"sibila":
			var kind := "sangue" if not flashes else "golpes" if e.hit_phys else "feitiços"
			if kind == e.ward:
				if flashes and e.num_t > 0.3:
					e._number("Imune", 18.0, Color(0.78, 0.72, 0.95))
				return 0.0
			e.took[kind] = e.took.get(kind, 0.0) + amount
		"monge":
			if flashes:
				m.noise(e.position, 0.0)
	return 1.0


## A cada frame, no anfitrião (enemy._move, antes de ver se está preso ou quebrado: o que já foi avisado cai sempre).
## Devolve true quando foi ele a mexer o chefe (o Monge, a Tecelã, o Marechal a apontar e a investir).
static func tick(e, delta: float) -> bool:
	var m = e.main
	if e.style == "amalgama":  # #220: muda de chefe a cada 20% (e, na última fase, a arena vai fechando)
		_amalgam(e, delta)
	if e.rain_at > 0.0 and m.time >= e.rain_at:  # as pedras do Titã, a Pisada do Guardião e os círculos dos chefes novos caem
		var hit := []  # cada herói leva uma vez por chuva: numa investida curta os círculos do Marechal sobrepõem-se
		for r in e.rain:
			if r.size() > 2 and str(r[2]) == "cabelos":  # #187: os cabelos da Donzela fecham-se: quem ficou lá dentro fica preso
				_hair(m, r[0], r[1])
			elif r.size() > 2 and r[2] is String:  # [onde, raio, poça]: o ácido da Matriarca (#40) e a névoa do Bispo (#183) ficam no chão (S11)
				m.add_pool(r[0], r[2])
				m.spawn_fx("dust", r[0], 60.0, Color(0.6, 0.85, 0.4) if r[2] == "acido" else Color(0.7, 0.72, 0.6))
				m.sfx("hit", 0.8)
			elif r.size() > 2:  # [onde, raio, parte]: tira essa parte da vida a cada herói
				strike(m, r[0], r[1], r[2], e, hit)
			else:
				m.boss_slam(r[0], r[1], e.dmg, e.who(), e, "hit")
		e.rain = []
		e.rain_at = 0.0
	for w in e.later.filter(func(w): return m.time >= w[0]):
		e.later.erase(w)
		_later(e, w)
	var free: bool = e.awake and e.stagger_t <= 0.0 and e.statue_t <= 0.0 and e.pin_t <= 0.0 and e.windup_t <= 0.0 and e.blind_t <= 0.0
	match e.boss:
		"monge":
			return _monk(e, delta)
		"carrasco":
			_executioner(e, free)
		"guardiao":
			if e.boss_n == 0 and e.hp <= e.max_hp * 0.5:  # a meio da vida as estátuas erguem-se outra vez (uma vez só)
				e.boss_n = 1
				m.raise_statues(e)
				m.hud.toast("As estátuas erguem-se outra vez!")
			if free and m.time >= e.boss_t:  # a Pisada: um anel de 200 px à volta dele, a cada 6 s
				e.boss_t = m.time + 6.0
				e.rain = [[e.position, 200.0]]
				e.rain_at = m.time + RAIN_T
		"santuario":  # Santuário (#50): a cada 25% da vida perdida, a lei seguinte (main.LAWS), com o cartão dela
			var law := mini(4, 1 + int((1.0 - e.hp / e.max_hp) * 4.0))
			if law > m.sanctum_rule and m.sanctum_rule > 0:
				m.sanctum_rule = law
				m.hud.name_card(m.LAWS[law - 1][0], m.LAWS[law - 1][2], "Santuário")
				m.sfx("bell")
		"tita":
			var alive: Array = m.players.filter(func(p): return not p.dead)
			if free and m.time >= e.boss_t and not alive.is_empty():  # chuva de pedras: 3 avisos de 90 px em cima dos heróis, a cada 8 s
				e.boss_t = m.time + 8.0
				e.rain = range(3).map(func(i): return [alive[i % alive.size()].position + (Vector2.ZERO if i < alive.size() else Vector2.from_angle(randf() * TAU) * 140.0), 90.0])
				e.rain_at = m.time + RAIN_T
		"arquivista":
			_archivist(e, free)
		"sibila":
			_sibyl(e)
		"arquilich":
			_lich(e, free)
		"tecela":
			return _weaver(e, free, delta)
		"marechal":
			return _marshal(e, free, delta)
		"matriarca":
			_matriarch(e, free)
		"bispo":
			_bishop(e, free, delta)
		"donzela_l", "donzela_c", "donzela_g":
			return _maiden(e, free, delta)
		"quimera":
			_chimera(e, free)
		"rei_ouro", "rei_prata", "rei_bronze":
			return _king(e, free, delta)
		"carruagem":
			return _cart(e, delta)
	return false


## Um golpe em área que tira share da vida a cada herói a menos de r de at (a esquiva passa, como em todos os golpes).
## Quem já está em hit não leva outra vez; quem leva entra lá.
static func strike(m, at: Vector2, r: float, share: float, src, hit: Array) -> void:
	for p in m.players:
		if not p.dead and not p in hit and p.position.distance_to(at) < r:
			hit.append(p)
			p.take_damage(p.max_hp * share, src.who(), src)
	m.spawn_fx("ring", at, r, Color(0.4, 1.0, 0.6))
	m.spawn_fx("dust", at, 60.0, Color.WHITE)
	m.shake = maxf(m.shake, 8.0)
	m.sfx("hit")


## Os heróis vivos a menos de w px do segmento a-b (a Lança copiada, o fio da Tecelã).
static func _on_line(m, a: Vector2, b: Vector2, w: float) -> Array:
	return m.players.filter(func(p): return not p.dead and Geometry2D.get_closest_point_to_segment(p.position, a, b).distance_to(p.position) < w)


## O que o chefe deixou marcado para mais tarde (e.later = [hora, o quê, onde]).
static func _later(e, w: Array) -> void:
	var m = e.main
	match w[1]:
		"summon":  # o Erguer os Mortos copiado: dois mortos
			m.summon_minions(e, 2)
		"ring":  # a Ceifa de Ossos copiada: mais um anel
			m.boss_slam(w[2], 150.0, e.dmg, e.who(), e, "hit")
		"armor":  # a Armadura de Ossos copiada acaba
			e.armor = e.STATS[e.kind][4]
		"runes":  # o Arquilich: ao fim de 10 s sem runas, voltam duas
			e.runes = maxi(e.runes, 2)
			m.spawn_fx("ring", e.position, 140.0, Color(0.62, 0.74, 1.0))


## Monge Penitente Cego (#193): só o barulho o guia. A um barulho novo a menos de 900 px corre para lá (x3, até 0,8 s) e
## bate o sino (150 px, dano x1,2), e só volta a reagir 1 s depois; senão anda devagar (x0,4) para o último que ouviu.
## Nunca persegue um herói nem chama mortos.
static func _monk(e, delta: float) -> bool:
	var m = e.main
	if e.stagger_t > 0.0 or e.statue_t > 0.0 or e.pin_t > 0.0:
		return false  # preso ou quebrado: o enemy._move trata disso
	var q = m.nearest_player(e.position)
	if q != null:
		e.target = q  # só para se virar para ele no desenho
		e.awake = e.awake or q.position.distance_to(e.position) < e.aggro
	e.slam_cd -= delta
	if e.act == "slam":  # o sino do Arauto: o aviso enche e cai
		e.act_t += delta
		if e.act_t >= e.ACT_T * 0.5 and not e.act_done:
			e.act_done = true
			m.boss_slam(e.position + Vector2(0, 10), 150.0, e.dmg * 1.2, e.who(), e)
		if e.act_t >= e.ACT_T:
			e.act = ""
			e.slam_cd = 1.0
		return true
	if e.act == "dash":
		e.act_t += delta
		var to: Vector2 = e.goal - e.position
		if to.length() < 24.0 or e.act_t >= 0.8:
			e._start("slam")
		else:
			e.position += to.limit_length(e.speed * 3.0 * delta)
		return true
	if m.noise_t > e.heard and e.slam_cd <= 0.0 and e.blind_t <= 0.0:  # um barulho novo
		e.heard = m.noise_t
		e.goal = m.noise_at
		if m.noise_at.distance_to(e.position) < 900.0:
			e._start("dash")
			return true
	var way: Vector2 = e.goal - e.position
	if way.length() > 24.0:
		e.position += way.normalized() * e.speed * 0.4 * delta
	return true


## Carrasco Sem Rosto (#44): a cada 5 s atira a corrente ao herói mais perto (até 700 px). 0,8 s de aviso e depois quem
## estiver a 20 px da linha leva 10% da vida e fica preso 1,6 s (esquivar através dela é esquiva perfeita, sem prisão).
## A cada 3.ª corrente, 0,5 s depois, aparece atrás de quem ela apanhou a guilhotina (1000 px), que 1 s depois varre para
## o Carrasco a 600 px/s: tira 35% da vida, e quem estiver preso é decapitado; a esquiva passa por baixo dela.
static func _executioner(e, free: bool) -> void:
	var m = e.main
	if e.chain_at > 0.0 and m.time >= e.chain_at:
		e.chain_at = 0.0
		m.sfx("hit")
		var hit = null
		for p in m.players:
			if not p.dead and Geometry2D.get_closest_point_to_segment(p.position, e.chain_from, e.chain_to).distance_to(p.position) < 20.0:
				var dodged: bool = p.dash_t > 0.0
				p.take_damage(p.max_hp * 0.1, e.who(), e)
				if not dodged and not p.dead:
					p.root_until = m.time + ROOT_T
					hit = p
		if e.boss_n % 3 == 0:
			var at: Vector2 = hit.position if hit != null else e.chain_to - e.chain_from.direction_to(e.chain_to) * 150.0
			e.blade_dir = at.direction_to(e.position)
			e.blade_from = at - e.blade_dir * 30.0
			e.blade_at = m.time + 1.5
			e.cut = []  # cada herói só leva com ela uma vez
	_sweep(e, 0.35, true)
	if free and m.time >= e.boss_t and e.act == "" and e.chain_at == 0.0:
		var q = m.nearest_player(e.position)
		if q != null and q.position.distance_to(e.position) < 700.0:
			e.boss_t = m.time + 5.0
			e.boss_n += 1
			e.chain_from = e.position
			e.chain_to = q.position + e.position.direction_to(q.position) * 150.0
			e.chain_at = m.time + CHAIN_T
			m.sfx("swing_heavy")


## A guilhotina a varrer (o Carrasco e, sem corrente, a Foice da Quimera, #190): tira share da vida a quem ela apanha (uma
## vez por passagem; a esquiva passa por baixo) e, com behead, decapita quem está preso.
static func _sweep(e, share: float, behead: bool) -> void:
	var m = e.main
	var s: float = (m.time - e.blade_at) * BLADE_V
	if e.blade_at <= 0.0 or s < 0.0 or s >= BLADE_V * BLADE_T or e.blade_dir == Vector2.ZERO:
		return
	for p in m.players:
		var v: Vector2 = p.position - e.blade_from
		if not p.dead and not p in e.cut and absf(v.dot(e.blade_dir) - s) < 30.0 and absf(v.cross(e.blade_dir)) < 500.0:
			e.cut.append(p)
			if behead and p.root_until > m.time and p.dash_t <= 0.0:
				m.number(p.position + Vector2(0, -130), "Decapitado!", 24.0, Color(1.0, 0.2, 0.2))
				p.slay(e.who())
				continue
			if p.dash_t <= 0.0:
				m.number(p.position + Vector2(0, -130), "Guilhotina!", 22.0, Color(1.0, 0.35, 0.3))
			p.take_damage(p.max_hp * share, e.who(), e)


## Arquivista de Crânios (#29): 3,5 s depois de acordar, a 66% e a 33% da vida copia a habilidade que o herói mais perto
## mais usou nos últimos 20 s (player.used; no máximo 2: a 33% a de cada herói, ou as duas que mais usaste a solo). A cada
## 4 s lança a seguinte, com os avisos de sempre: a Lança é uma linha (15%), o Erguer os Mortos o sino e dois mortos, a
## foice e o machado um círculo à frente dele (18%), a Ceifa de Ossos três anéis e a Armadura de Ossos 70% de armadura 4 s.
static func _archivist(e, free: bool) -> void:
	var m = e.main
	if e.chain_at > 0.0 and m.time >= e.chain_at:  # a Lança copiada cai
		e.chain_at = 0.0
		for p in _on_line(m, e.chain_from, e.chain_to, 24.0):
			p.take_damage(p.max_hp * 0.15, e.who(), e)
		m.sfx("hit")
	if not e.awake:
		e.boss_t = m.time + 3.5  # a 1.ª cópia espera pelo cartão dele
		return
	var phase := 1 + int(e.hp <= e.max_hp * 0.66) + int(e.hp <= e.max_hp * 0.33)
	if phase > e.boss_n and (phase > 1 or m.time >= e.boss_t):
		e.boss_n = phase
		_copy(e, phase)
	if free and not e.copy.is_empty() and m.time >= e.boss_t and e.act == "" and e.chain_at == 0.0 and e.rain_at == 0.0:
		e.boss_t = m.time + 4.0
		_cast_copy(e, e.copy[e.boss_k % e.copy.size()])
		e.boss_k += 1


static func _copy(e, phase: int) -> void:
	var m = e.main
	var q = m.nearest_player(e.position)
	if q == null:
		return
	var got: Array
	var src = q  # de quem é a última cópia
	if phase >= 3:
		var other: Array = m.players.filter(func(p): return p != q and not p.dead)
		src = other[0] if not other.is_empty() else q
		got = [_most(q, [])]
		got.append(_most(src, got))
	else:
		got = (e.copy + [_most(q, e.copy)]).slice(-2)
	e.copy = got
	var shown: String = got[-1]
	for p in m.players:
		if p.skills.has(got[-1]):
			shown = p.skills[got[-1]].name
	# o cartão chega aos dois telemóveis: em co-op, com o nome de quem foi copiado
	m.hud.name_card(shown, "Copiou a tua habilidade!" if m.players.size() < 2 else e.tr("Copiou a habilidade do %s!") % e.tr(src.hero_name), e.title)
	m.sfx("roar")


## A habilidade que p mais usou nos últimos 20 s, fora as de skip; sem nenhuma, a 2.ª, a 3.ª e a 1.ª, por esta ordem.
static func _most(p, skip: Array) -> String:
	var n := {}
	for u in p.used:
		if p.main.time - u[1] < 20.0 and not u[0] in skip:
			n[u[0]] = n.get(u[0], 0) + 1
	var best := ""
	for id in n:
		if best == "" or n[id] > n[best]:
			best = id
	if best != "":
		return best
	for id in [p.order[1], p.order[2], p.order[0]]:
		if not id in skip:
			return id
	return p.order[1]


static func _cast_copy(e, id: String) -> void:
	var m = e.main
	var q = m.nearest_player(e.position)
	if q == null:
		return
	var aim: Vector2 = e.position.direction_to(q.position)
	e._start("cast")  # os desenhos de invocar do Arauto
	m.sfx("cast")
	match id:
		"bolt":
			e.chain_from = e.position
			e.chain_to = q.position + aim * 150.0
			e.chain_at = m.time + 0.7
		"nova":
			e.rain = [[e.position, 170.0]]
			e.rain_at = m.time + RAIN_T
			e.later.append([e.rain_at, "summon"])
		"cleave":
			e.rain = [[e.position, 150.0]]
			e.rain_at = m.time + RAIN_T
			e.later.append([e.rain_at + 0.2, "ring", e.position])
			e.later.append([e.rain_at + 0.4, "ring", e.position])
		"bonearmor":
			e.armor = 0.7
			e.later.append([m.time + 4.0, "armor"])
		_:  # a foice e o machado
			e.rain = [[e.position + aim * 90.0, 110.0, 0.18]]
			e.rain_at = m.time + RAIN_T


## Sibila dos Ossos Quebrados (#213): a cada 8 s (5 abaixo de metade da vida) fecha-se ao tipo de dano que mais a feriu
## desde a última vez (Bosses.hurt); sem dano nenhum, abre-se.
static func _sibyl(e) -> void:
	var m = e.main
	if m.time < e.boss_t:
		return
	e.boss_t = m.time + (5.0 if e.hp < e.max_hp * 0.5 else 8.0)
	var top := ""
	for k in e.took:
		if top == "" or e.took[k] > e.took[top]:
			top = k
	e.took = {}
	if top != "" and top != e.ward:
		e._number(e.tr("Imune a %s") % e.tr(top), 20.0, Color(0.78, 0.72, 0.95))
		m.spawn_fx("ring", e.position, 150.0, Color(0.78, 0.72, 0.95))
	e.ward = top


## Arquilich Blindado (#217): com runas não leva dano (Bosses.hurt). A cada 3,5 s lança uma esfera (orb_tick); cada uma
## que lhe devolvem parte uma runa. Sem runas fica 10 s vulnerável e voltam 2; a meio da vida voltam as 4 (uma vez).
static func _lich(e, free: bool) -> void:
	var m = e.main
	if e.boss_n == 0 and e.hp <= e.max_hp * 0.5:
		e.boss_n = 1
		e.runes = RUNE_N
		e.later = e.later.filter(func(w): return w[1] != "runes")
		m.hud.toast("As runas do Arquilich voltam todas!")
	if free and e.runes > 0 and m.time >= e.boss_t and e.act == "" and (m.zone != "sep" or m.enemies().size() < m.SEP_CAP):
		e.boss_t = m.time + 3.5
		e._start("cast")
		cast_orb(e)


## Uma esfera do Arquilich: um espectro de 1 de vida, desenhado em píxeis (draw_odd), sem XP nem saque, que conta para o SEP_CAP.
static func cast_orb(e):
	var m = e.main
	var q = m.nearest_player(e.position)
	if q == null:
		return null
	var dir: Vector2 = e.position.direction_to(q.position)
	var o = m.spawn_enemy("specter", m.walk(e.position, e.position + dir * (e.radius + 30.0)), e.mods, false)
	o.orb = true
	o.title = "Esfera do Arquilich"
	o.max_hp = 1.0
	o.hp = 1.0
	o.hp_chunk = 1.0
	o.speed = 200.0
	o.caster = e
	o.heading = dir
	o.boss_t = m.time + 6.0  # rebenta sozinha a esta hora
	m.sfx("cast")
	return o


## A esfera, no anfitrião (enemy._move): vira no máximo 2,5 rad/s para o herói mais perto e rebenta nele (60 px, 12%) ou
## ao fim de 6 s; quem esquiva através dela devolve-a. Devolvida, volta a 420 px/s ao Arquilich e parte-lhe uma runa.
## Desfaz-se quando ele cai, ou devolvida e presa (numa parede) ao fim de 4 s.
static func orb_tick(e, delta: float) -> void:
	var m = e.main
	var lich = e.caster
	if not is_instance_valid(lich) or lich.dying or (e.back and m.time >= e.boss_t):
		m.spawn_fx("dust", e.position + Vector2(0, -36), 30.0, Color(0.62, 0.74, 1.0))
		e.queue_free()
		return
	if e.back:
		e.target = lich
		if e.position.distance_to(lich.position) < lich.radius + 20.0:
			_rune_break(lich)
			e.queue_free()
			return
	else:
		e.target = m.nearest_player(e.position)
		if e.target != null and e.position.distance_to(e.target.position) < e.radius + 20.0 and e.target.dash_t > 0.0:
			reflect(e)
		elif e.target == null or m.time >= e.boss_t or e.position.distance_to(e.target.position) < e.radius + 20.0:
			strike(m, e.position, 60.0, 0.12, lich, [])
			e.queue_free()
			return
	var want: Vector2 = e.position.direction_to(e.target.position)
	var turn: float = e.heading.angle_to(want)
	e.heading = e.heading.rotated(turn if e.back else clampf(turn, -2.5 * delta, 2.5 * delta))
	e.position += e.heading * e.speed * delta


## Um golpe de herói na esfera (enemy.take_damage) ou uma esquiva através dela: volta para quem a lançou.
static func reflect(e) -> void:
	if e.back:
		return
	e.back = true
	e.speed = 420.0
	e.boss_t = e.main.time + 4.0  # se não chegar a ele até lá (presa numa parede), desfaz-se (orb_tick)
	if is_instance_valid(e.caster):
		e.heading = e.position.direction_to(e.caster.position)
	e.main.spawn_fx("sparks", e.position + Vector2(0, -36), 0.0, Color(1.0, 0.85, 0.4), e.heading)
	e.main.sfx("crit", 1.3)


static func _rune_break(e) -> void:
	var m = e.main
	if e.runes <= 0:
		return
	e.runes -= 1
	e._number("Runa partida!", 22.0, Color(0.62, 0.74, 1.0))
	m.spawn_fx("ring", e.position, 120.0, Color(0.62, 0.74, 1.0))
	m.shake = maxf(m.shake, 8.0)
	m.sfx("crit")
	if e.runes == 0:
		m.hud.toast("As runas caíram: o Arquilich está vulnerável!")
		e.later.append([m.time + 10.0, "runes"])


## Tecelã de Mortalhas (#207): fica a 250 px do herói mais perto e a cada 7 s atira-lhe um fio (0,8 s de aviso). Quem
## ele apanhar sem esquivar fica cosido ao chão 8 s por uma agulha: um monstro preso ao chão com 4% da vida dela, a que
## todos os golpes chegam; partida, solta-o (main._on_enemy_killed). Com alguém vivo cosido chama 2 espectros a cada 4 s.
static func _weaver(e, free: bool, delta: float) -> bool:
	var m = e.main
	_keep_in(e, 60.0)
	var sewn := false
	for o in m.enemies():  # a agulha só dura enquanto o herói dela está cosido: acabados os 8 s (ou se ele saiu), desfaz-se
		if o.pin_of < 0 or o.is_queued_for_deletion():
			continue
		var held: Array = m.players.filter(func(p): return p.slot == o.pin_of and p.root_until > m.time)
		if held.is_empty():
			m.spawn_fx("dust", o.position, 40.0, Color(0.92, 0.92, 1.0))
			o.queue_free()
		elif not held[0].dead:
			sewn = true
	if e.chain_at > 0.0 and m.time >= e.chain_at:
		e.chain_at = 0.0
		for p in _on_line(m, e.chain_from, e.chain_to, 20.0):
			if p.dash_t <= 0.0 and p.root_until <= m.time:
				_sew(e, p)
	if not sewn:
		e.boss_k = m.time + 4.0
	elif m.time >= e.boss_k:
		e.boss_k = m.time + 4.0
		m.summon_minions(e, 2, "specter")
	var q = m.nearest_player(e.position)
	if not free or q == null:
		return false
	e.target = q
	var to: Vector2 = q.position - e.position
	if absf(to.length() - 250.0) > 30.0:  # nem perto nem longe: a 250 px
		e.position += to.normalized() * signf(to.length() - 250.0) * e.speed * delta
	if m.time >= e.boss_t and e.chain_at == 0.0 and to.length() < 700.0:
		e.boss_t = m.time + 7.0
		e.chain_from = e.position
		e.chain_to = q.position + to.normalized() * 120.0
		e.chain_at = m.time + CHAIN_T
		m.sfx("swing_heavy")
	return true


static func _sew(e, p) -> void:
	var m = e.main
	p.root_until = m.time + SEW_T
	# a 80 px, abaixo do anel do herói (o nome e a barra não lhe caem em cima) e ainda ao alcance da foice (95 px)
	var n = m.spawn_enemy("skeleton", m.walk(p.position, p.position + Vector2(0, 80)), {"hp": e.max_hp * 0.04 / e.STATS.skeleton[0]}, false)
	n.anchor = true
	n.pin_of = p.slot
	n.title = "Agulha"
	m.number(p.position + Vector2(0, -130), "Cosido!", 22.0, Color(0.92, 0.92, 1.0))
	m.sfx("hit")


## Marechal de Ferro (#201), a pé: a cada 6 s aponta a lança (0,9 s de aviso, uma linha de 700 px por cima do herói mais
## perto) e investe a 900 px/s pelo walk (nunca sai do chão): 25% a cada herói em que toca (uma vez; a esquiva passa) e,
## 0,6 s depois de parar, 6 círculos de 60 px caem pelo caminho (12%). Se bate numa parede (ou na da arena), fica 2 s quebrado.
static func _marshal(e, free: bool, delta: float) -> bool:
	var m = e.main
	_keep_in(e, 40.0)  # a investida começa sempre dentro da arena
	if e.stagger_t > 0.0 or e.statue_t > 0.0 or e.pin_t > 0.0:  # quebrado, estátua ou preso: a investida acaba e o enemy._move trata disso
		e.chain_at = 0.0
		if e.act == "dash":
			e.act = ""
		return false
	if e.chain_at > 0.0:
		if m.time < e.chain_at:
			return true  # parado a apontar
		e.chain_at = 0.0
		e._start("dash")
		e.cut = []
	if e.act == "dash":
		e.act_t += delta
		var step: Vector2 = (e.chain_to - e.position).limit_length(900.0 * delta)
		var at: Vector2 = m.walk(e.position, e.position + step)
		var wall: bool = step.length() > 0.5 and at.distance_to(e.position) < step.length() * 0.6
		e.position = at
		for p in m.players:
			if not p.dead and not p in e.cut and p.position.distance_to(e.position) < e.radius + 20.0:
				e.cut.append(p)
				p.take_damage(p.max_hp * 0.25, e.who(), e)
		var reached: bool = e.position.distance_to(e.chain_to) < 1.0
		if reached and m.arena_r > 0.0 and e.chain_to.distance_to(m.monument_pos) > m.arena_r - 50.0:
			wall = true  # a parede da arena do Mausoléu
		if wall or reached or e.act_t > 1.5:
			e.act = ""
			var from: Vector2 = e.chain_from
			e.rain = range(6).map(func(i): return [from.lerp(e.position, (i + 0.5) / 6.0), 60.0, 0.12])
			e.rain_at = m.time + 0.6
			m.shake = maxf(m.shake, 10.0)
			if wall:
				e._stagger()
				e.stagger_t = 2.0
		return true
	if free and m.time >= e.boss_t:
		var q = m.nearest_player(e.position)
		if q != null and q.position.distance_to(e.position) < 900.0:
			e.boss_t = m.time + 6.0
			e.chain_from = e.position
			var aim: Vector2 = e.position.direction_to(q.position)
			e.chain_to = e.position + aim * 700.0
			var stop: Vector2 = _charge_stop(m, e.position, e.chain_to)
			if stop != e.chain_to:  # a linha acaba na parede onde ele vai bater (passava por ela até ao escuro); +40 px, para ainda lhe bater
				e.chain_to = e.position + aim * minf(700.0, (stop - e.position).dot(aim) + 40.0)
			if m.arena_r > 0.0 and e.chain_to.distance_to(m.monument_pos) > m.arena_r - 40.0:  # na arena do Mausoléu a linha acaba onde sai dela (vista do fim: o 1.º cruzamento é a saída, nunca a entrada)
				var k: float = Geometry2D.segment_intersects_circle(e.chain_to, e.position, m.monument_pos, m.arena_r - 40.0)
				if k > 0.0:
					e.chain_to = e.chain_to.lerp(e.position, k)
			e.chain_at = m.time + 0.9
			m.sfx("swing_heavy")
			return true
	return false


## Onde a linha da investida do Marechal sai do chão, a direito (passos de 15 px): é aí que ele bate na parede. O walk
## escorrega ao longo das paredes e, numa investida de lado, parava muito mais à frente (a linha ia parede fora). Sem
## parede pelo caminho, o fim da linha.
static func _charge_stop(m, from: Vector2, to: Vector2) -> Vector2:
	if m.zone == "world":
		return to  # no cemitério não há paredes (main.walk)
	var was: bool = m.on_floor(from)  # quem está dentro de uma parede sai a andar (main.walk): conta a 1.ª saída do chão
	var n := ceili(from.distance_to(to) / 15.0)
	for i in range(1, n + 1):
		var at: Vector2 = from.lerp(to, float(i) / n)
		var on: bool = m.on_floor(at)
		if was and not on:
			return at
		was = was or on
	return to


## Matriarca dos Vermes Cadavéricos (#40), um colosso que continua a dar o murro: a cada 6 s, 3 bolhas de ácido em cima dos
## heróis e ao pé deles (o aviso de 70 px enche 1 s e fica uma poça de ácido, S11); a cada 12 s, 3 ovos a 160-220 px dela,
## que rebentam ao fim de 5 s em 3 larvas (no máximo 6 ovos). A meio da vida, 6 ovos de uma vez e um rugido.
static func _matriarch(e, free: bool) -> void:
	var m = e.main
	var alive: Array = m.players.filter(func(p): return not p.dead)
	if not free or alive.is_empty():
		return
	if e.boss_n == 0 and e.hp <= e.max_hp * 0.5:
		e.boss_n = 1
		e.boss_k = m.time + 12.0
		lay(e, EGG_MAX)
		m.sfx("roar")
		m.shake = maxf(m.shake, 12.0)
	if m.time >= e.boss_t and e.rain_at == 0.0:
		e.boss_t = m.time + 6.0
		e.rain = range(3).map(func(i): return [alive[i % alive.size()].position + (Vector2.ZERO if i < alive.size() else Vector2.from_angle(randf() * TAU) * 140.0), 70.0, "acido"])
		e.rain_at = m.time + RAIN_T
	if m.time >= e.boss_k:
		e.boss_k = m.time + 12.0
		lay(e, 3)


## Os ovos da Matriarca: monstros presos ao chão com 1 de vida (qualquer golpe os parte), até EGG_MAX de cada vez.
static func lay(e, n: int) -> void:
	var m = e.main
	var have: int = m.enemies().filter(func(o): return o.hatch_at > 0.0).size()
	for i in mini(n, EGG_MAX - have):
		if m.zone == "sep" and m.enemies().size() >= m.SEP_CAP:
			break
		var at: Vector2 = m.walk(e.position, e.position + Vector2.from_angle(lerpf(-0.2, PI + 0.2, (i + randf() * 0.5) / n)) * randf_range(160.0, 220.0))  # dos lados e à frente dela: atrás, o corpo dela tapava-os
		var g = m.spawn_enemy("skeleton", at, {"hp": 1.0 / e.STATS.skeleton[0]}, false)
		g.anchor = true
		g.title = "Ovo"
		g.hatch_at = m.time + EGG_T
		m.spawn_fx("dust", at, 40.0, Color(0.6, 0.85, 0.4))
	m.sfx("hit", 0.7)


## O ovo rebenta: 3 Larvas, espectros pequenos e verdes que rebentam ao tocar num herói ou ao fim de 4 s, sem XP nem saque
## (como as Almas Rebeldes, enemy._move).
static func hatch(g) -> void:
	var m = g.main
	var lv: Dictionary = m.lvl_mods(m.sep_level() if m.zone == "sep" else m.level)
	for i in 3:
		if m.zone == "sep" and m.enemies().size() >= m.SEP_CAP:
			break
		var l = m.spawn_enemy("specter", g.position + Vector2.from_angle(TAU * i / 3.0) * 20.0, {"hp": lv.hp * 0.5, "speed": 1.2, "dmg": lv.dmg}, false)
		l.grow(0.55)
		l.paint = Color(0.72, 0.92, 0.55)
		l.title = "Larva"
		l.expire_at = m.time + 4.0
	m.spawn_fx("dust", g.position, 50.0, Color(0.6, 0.85, 0.4))
	m.sfx("hit", 1.2)
	g.queue_free()


## Bispo dos Leprosos (#183): ao acordar ajoelham-se 6 penitentes dos dois lados dele; com algum a rezar só leva 35% (hurt) e cura
## 0,4% da vida por segundo por cada um (até 2%). A cada 7 s, 2 incensários: névoa cáustica em cima dos heróis (90 px, S11:
## fere e não deixa curar). A meio da vida os que caíram voltam a ajoelhar-se.
static func _bishop(e, free: bool, delta: float) -> void:
	var m = e.main
	if not e.awake:
		return
	if e.boss_n == 0:
		e.boss_n = 1
		kneel(e)
	elif e.boss_n == 1 and e.hp <= e.max_hp * 0.5:
		e.boss_n = 2
		kneel(e)
		m.hud.toast("Os penitentes voltam a rezar!")
	var n := penitents(m)
	if n > 0:
		e.hp = minf(e.max_hp, e.hp + e.max_hp * minf(0.004 * n, 0.02) * delta)
	var alive: Array = m.players.filter(func(p): return not p.dead)
	if free and m.time >= e.boss_t and e.rain_at == 0.0 and not alive.is_empty():
		e.boss_t = m.time + 7.0
		e.rain = range(2).map(func(i): return [alive[i % alive.size()].position + (Vector2.ZERO if i < alive.size() else Vector2.from_angle(randf() * TAU) * 120.0), 90.0, "nevoa"])
		e.rain_at = m.time + RAIN_T


## Os penitentes que faltam (até 6), em duas filas de 3, uma de cada lado do Bispo (a 180-225 px), desencontradas e mais
## para a frente dele do que para trás; presos ao chão como as estátuas, com a pele do Enforcado e 5% da vida dele. A norte
## dele ficavam debaixo da barra do chefe e dos botões de cima, cortados pela borda do ecrã.
static func kneel(e) -> void:
	var m = e.main
	var have: Array = m.enemies().filter(func(o): return o.anchor and o.title == PENITENT)
	for row in 2:
		for k in 3:
			var at: Vector2 = e.position + Vector2((row * 2 - 1) * (180.0 + 40.0 * (k % 2)), -40.0 + 80.0 * k)
			if have.size() >= 6 or have.any(func(o): return o.position.distance_to(at) < 40.0):
				continue
			var s = m.spawn_enemy("skeleton", m.walk(e.position, at), {"hp": e.max_hp * 0.05 / e.STATS.skeleton[0], "dmg": 0.0}, false)
			s.anchor = true
			s.skin = "enforcado"
			s.paint = Color(0.75, 0.7, 0.62)
			s.title = PENITENT
			have.append(s)
			m.spawn_fx("dust", s.position, 40.0, Color(0.85, 0.8, 0.7))
	m.sfx("bell", 0.6)


## Quantos penitentes do Bispo ainda rezam.
static func penitents(m) -> int:
	return m.enemies().filter(func(o): return o.anchor and o.title == PENITENT).size()


## Lote 9: os do grupo trio ainda de pé (as Donzelas, #187, e os Reis, #34), pela ordem deles.
static func sisters(m, trio: String) -> Array:
	var order: Array = MAIDENS if trio == "donzelas" else KINGS
	var out: Array = m.enemies().filter(func(o): return o.trio == trio)
	out.sort_custom(func(a, b): return order.find(a.boss) < order.find(b.boss))
	return out


## #187 Triunvirato das Donzelas Mortas: três espectros que acordam juntos; só a da vez ataca (a cada 2,5 s) e brilha, as
## outras ficam meio apagadas, a 330 px, e só levam 25% (hurt). A vez passa a cada 8 s (5 s quando já falta uma). A das
## Lâminas: 3 linhas ténues e, 1 s depois, 12% a quem estiver em cada uma; a dos Cabelos: um círculo de 200 px num herói
## que, ao fechar, prende quem lá ficou mais 1,5 s; a do Grito: um anel que cresce dela até 520 px e tira 15% (e empurra)
## a quem apanha. A esquiva passa pelos três.
static func _maiden(e, free: bool, delta: float) -> bool:
	var m = e.main
	var sis: Array = sisters(m, "donzelas")
	if not e.awake:
		var near = m.nearest_player(e.position)
		e.awake = sis.any(func(o): return o.awake) or (near != null and near.position.distance_to(e.position) < e.aggro)
		if not e.awake:
			return true
	var span := 8.0 if sis.size() >= 3 else 5.0
	if not sis.any(func(o): return o.turn_at > 0.0):
		if not sis.is_empty() and sis[0] == e:  # ninguém na vez (a da vez caiu): a primeira das que ficam
			_give_turn(e, span)
	elif e.turn_at > 0.0:
		e.turn_at = minf(e.turn_at, m.time + span)  # ao cair a segunda, a vez de quem fica encurta
		if m.time >= e.turn_at:
			e.turn_at = 0.0
			_give_turn(sis[(sis.find(e) + 1) % sis.size()], span)
	if e.chain_at > 0.0 and m.time >= e.chain_at:  # as lâminas caem (com a vez já passada também: o que foi avisado cai sempre)
		e.chain_at = 0.0
		for b in e.blades:
			for p in _on_line(m, b[0], b[1], 22.0):
				p.take_damage(p.max_hp * 0.12, e.who(), e)
		e.blades = []
		m.sfx("swing_heavy", 1.3)
	_scream(e)
	if not free:
		return false  # quebrada, estátua ou presa: o enemy._move conta o tempo
	var q = m.nearest_player(e.position)
	if q == null:
		return true
	e.target = q
	var to: Vector2 = q.position - e.position
	var want := 180.0 if e.turn_at > 0.0 else 330.0
	if absf(to.length() - want) > 30.0:
		e.position += to.normalized() * signf(to.length() - want) * e.speed * delta
	_keep_in(e, 60.0)
	if e.turn_at <= 0.0 or m.time < e.boss_t or e.chain_at > 0.0 or e.rain_at > 0.0 or e.blade_at > 0.0:
		return true
	e.boss_t = m.time + 2.5
	var aim: Vector2 = to.normalized()
	match e.boss:
		"donzela_l":
			e.blades = [-0.22, 0.0, 0.22].map(func(a): return [e.position, e.position + aim.rotated(a) * 640.0])
			e.chain_at = m.time + 1.0
			m.sfx("swing", 1.4)
		"donzela_c":
			e.rain = [[q.position, 200.0, "cabelos"]]
			e.rain_at = m.time + RAIN_T
			m.sfx("cast", 0.8)
		"donzela_g":
			e.blade_from = e.position
			e.blade_dir = Vector2.ZERO  # um anel, não a guilhotina
			e.blade_at = m.time + 0.4
			e.cut = []
			m.sfx("roar", 1.4)
	return true


static func _give_turn(o, span: float) -> void:
	o.turn_at = o.main.time + span
	o.boss_t = o.main.time + 1.0  # o 1.º golpe da vez, 1 s depois
	o.main.spawn_fx("ring", o.position, 140.0, o.paint)


## O anel do Grito (#187): cresce SCREAM_V px/s a partir de blade_from; quem está na frente dele (± 25 px) leva 15% e é
## empurrado 90 px, uma vez.
static func _scream(e) -> void:
	var m = e.main
	if e.blade_at <= 0.0 or e.blade_dir != Vector2.ZERO:
		return
	var r: float = (m.time - e.blade_at) * SCREAM_V
	if r > SCREAM_R:
		e.blade_at = 0.0
		return
	if r < 0.0:
		return
	for p in m.players:
		if not p.dead and not p in e.cut and absf(p.position.distance_to(e.blade_from) - r) < 25.0:
			e.cut.append(p)
			if p.dash_t <= 0.0:
				p.take_damage(p.max_hp * 0.15, e.who(), e)
				p.position = m.walk(p.position, p.position + e.blade_from.direction_to(p.position) * 90.0)


## Os cabelos da Donzela (#187) fecham-se em at: quem lá ficou (sem esquivar) fica preso mais 1,5 s.
static func _hair(m, at: Vector2, r: float) -> void:
	for p in m.players:
		if not p.dead and p.dash_t <= 0.0 and p.position.distance_to(at) < r:
			p.root_until = maxf(p.root_until, m.time) + 1.5
			m.number(p.position + Vector2(0, -130), "Preso nos cabelos!", 22.0, Color(0.85, 0.6, 0.95))
	m.spawn_fx("ring", at, r, Color(0.85, 0.6, 0.95))
	m.sfx("hit", 0.8)


## #190 Quimera dos Reis: um colosso que muda de arma a cada 20% da vida perdida (cartão "Pega no Machado!"; o ícone por
## cima dela e da barra). Espada: um círculo de 120 px à frente dela (22%) a cada 2,5 s; Machado: a Pisada (220 px) a cada
## 4 s; Foice: a guilhotina do Carrasco, sem corrente (30%), a cada 6 s; Cetro: a chuva do Titã (4 de 80 px) e dois
## Porta-Estandartes a cada 8 s; Escudo: só leva 20% pela frente e anda mais devagar (o murro de sempre).
static func _chimera(e, free: bool) -> void:
	var m = e.main
	var k := clampi(int((1.0 - e.hp / e.max_hp) * 5.0), 0, 4)
	if STYLES.find(e.style) < k:  # nunca volta atrás (a vida sobe pouco)
		e.style = STYLES[k]
		e.speed = e.STATS.colossus[1] * e.mods.get("speed", 1.0) * INFO.quimera[5] * (0.7 if e.style == "escudo" else 1.0)
		e.boss_t = m.time + 1.5
		m.hud.name_card(GRAB[e.style], "", "")
		m.sfx("roar")
	_sweep(e, 0.3, false)
	var alive: Array = m.players.filter(func(p): return not p.dead)
	var busy: bool = e.rain_at > 0.0 or (e.blade_at > 0.0 and m.time < e.blade_at + BLADE_T)
	if not free or alive.is_empty() or m.time < e.boss_t or busy or e.style == "escudo":
		return
	var q = m.nearest_player(e.position)
	var aim: Vector2 = e.position.direction_to(q.position)
	m.sfx("swing_heavy")
	match e.style:
		"espada":
			e.boss_t = m.time + 2.5
			e.rain = [[e.position + aim * 110.0, 120.0, 0.22]]
			e.rain_at = m.time + RAIN_T
		"machado":
			e.boss_t = m.time + 4.0
			e.rain = [[e.position, 220.0]]
			e.rain_at = m.time + RAIN_T
		"foice":  # aparece atrás do herói e varre para ela
			e.boss_t = m.time + 6.0
			e.blade_dir = q.position.direction_to(e.position)
			e.blade_from = q.position - e.blade_dir * 200.0
			e.blade_at = m.time + 1.0
			e.cut = []
		"cetro":
			e.boss_t = m.time + 8.0
			e.rain = range(4).map(func(i): return [alive[i % alive.size()].position + (Vector2.ZERO if i < alive.size() else Vector2.from_angle(randf() * TAU) * 140.0), 80.0])
			e.rain_at = m.time + RAIN_T
			for i in 2:
				if m.zone == "sep" and m.enemies().size() >= m.SEP_CAP:
					break
				var s = m.spawn_enemy("skeleton", m.walk(e.position, e.position + Vector2(-90 + 180 * i, 60)), e.mods, false)
				s.skin = "estandarte"
				m.spawn_fx("dust", s.position, 40.0, Color.WHITE)


## #34 Os Reis Caídos: cada rei faz o do papel dele (style). Espada: a Pisada (220 px) a cada 4 s e o murro mais rápido;
## Cetro: a chuva do Titã (3 de 90 px) a cada 6 s e 2 mortos a cada 10 s; Escudo: põe-se entre o herói mais perto e os
## outros reis (e leva só 25%, hurt). A troca dos papéis é do main._kings_tick.
static func _king(e, free: bool, delta: float) -> bool:
	var m = e.main
	match e.style:
		"espada":
			if e.windup_t > e.WINDUP * 0.6:
				e.windup_t = e.WINDUP * 0.6
			if free and m.time >= e.boss_t and e.rain_at == 0.0:
				e.boss_t = m.time + 4.0
				e.rain = [[e.position, 220.0]]
				e.rain_at = m.time + RAIN_T
		"cetro":
			var alive: Array = m.players.filter(func(p): return not p.dead)
			if free and m.time >= e.boss_t and e.rain_at == 0.0 and not alive.is_empty():
				e.boss_t = m.time + 6.0
				e.rain = range(3).map(func(i): return [alive[i % alive.size()].position + (Vector2.ZERO if i < alive.size() else Vector2.from_angle(randf() * TAU) * 140.0), 90.0])
				e.rain_at = m.time + RAIN_T
			if free and m.time >= e.boss_k:
				e.boss_k = m.time + 10.0
				m.summon_minions(e, 2)
		"escudo":
			var q = m.nearest_player(e.position)
			var others: Array = sisters(m, "reis").filter(func(o): return o != e)
			if free and q != null and not others.is_empty() and q.position.distance_to(e.position) > 150.0:
				var mid := Vector2.ZERO
				for o in others:
					mid += o.position / others.size()
				e.target = q
				var way: Vector2 = mid.lerp(q.position, 0.55) - e.position
				if way.length() > 20.0:
					e.position += way.limit_length(e.speed * delta)
				return true
	return false


## #34: os papéis dos reis de pé, rodados k vezes; com menos reis cai o Escudo primeiro (depois a Espada). Um segundo parados.
static func crown(m, k: int) -> void:
	var alive: Array = sisters(m, "reis")
	var roles: Array = ROLES.slice(3 - alive.size())
	for i in alive.size():
		var o = alive[i]
		o.style = roles[(i + k) % roles.size()]
		o.boss_t = m.time + 1.0
		o.boss_k = m.time + 10.0
		o.attack_cd = 1.0
		o.windup_t = 0.0


## #48 Carruagem Fúnebre: anda pela estrada (main.CART_ROUTE, chain_to é o ponto a que vai: o convidado vira-a por ele) e
## nunca persegue ninguém; a cada 6 s saltam 2 escoltas (no máximo 8 de pé). Sem rodas para (hurt).
static func _cart(e, delta: float) -> bool:
	var m = e.main
	e.knock = Vector2.ZERO
	e.awake = true
	if e.stagger_t > 0.0 or e.statue_t > 0.0 or e.pin_t > 0.0:
		return false  # quebrada, de pedra ou presa: parada, e o enemy._move conta o tempo
	var to: Vector2 = e.chain_to - e.position
	if to.length() < 24.0:
		e.boss_k = (int(e.boss_k) + 1) % m.CART_ROUTE.size()
		e.chain_to = m.CART_ROUTE[e.boss_k]
		to = e.chain_to - e.position
	e.position += to.limit_length(e.speed * delta)
	if m.time >= e.boss_t:
		e.boss_t = m.time + 6.0
		if m.enemies().filter(func(o): return o.ev == 1 and o != e).size() < 8:
			for i in 2:
				m._ev_spawn("skeleton", m.walk(e.position, e.position + Vector2(-70 + 140 * i, 60)), m.lvl_mods(m.ev_level()))
	return true


## A roda i da carruagem (WHEELS), no desenho dela: espelhada quando vai para a esquerda.
static func wheel_at(e, i: int) -> Vector2:
	return Vector2(WHEELS[i].x * _cart_side(e), WHEELS[i].y)


## O caixão aos píxeis de 2 px, sem suavizar (como as peças do Pix), seja qual for o filtro do nó.
static func _coffin() -> CanvasTexture:
	if _coffin_ct == null:
		_coffin_ct = CanvasTexture.new()
		_coffin_ct.diffuse_texture = COFFIN
		_coffin_ct.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	return _coffin_ct


static func _cart_side(e) -> float:
	return -1.0 if e.chain_to.x < e.position.x - 1.0 else 1.0


## #220: a Amálgama Primordial veste o chefe seguinte a cada 20% da vida perdida (afunda-se e volta, rise_t, com o cartão
## "A Amálgama veste o …"); na última, o Deus Cadavérico, a arena fecha de 620 para 400 px em 20 s.
static func _amalgam(e, delta: float) -> void:
	var m = e.main
	var k := clampi(int((1.0 - e.hp / e.max_hp) * 5.0), 0, 4)
	if PHASES.find(e.boss) < k:
		phase(e, PHASES[k])
		e.rise_t = 1.4
		m.hud.name_card(e.tr("A Amálgama veste o %s") % e.tr(INFO[e.boss][0]), m.LAWS[3][2] if e.boss == "santuario" else INFO[e.boss][1], "")  # no Santuário, a 4.ª lei (phase)
		m.sfx("bell")
		m.shake = maxf(m.shake, 12.0)
	if e.boss == "santuario" and m.arena_r > 400.0:
		m.arena_r = maxf(400.0, m.arena_r - 11.0 * delta)
	_keep_in(e, 80.0)


## Na arena do Mausoléu os chefes que se mexem sozinhos ficam lá dentro, a gap px da borda (os heróis: main._process).
static func _keep_in(e, gap: float) -> void:
	var m = e.main
	if m.arena_r > 0.0:
		e.position = m.monument_pos + (e.position - m.monument_pos).limit_length(m.arena_r - gap)


## Bosses.guards (para a barra do chefe imune): [quantos o guardam, a palavra]; [0, ""] nos outros.
static func guards(e) -> Array:
	match e.boss:
		"suturado":
			return [e.limbs.filter(func(l): return l > 0.0).size(), "membros"]
		"guardiao":
			return [e.main.enemies().filter(func(o): return o.anchor and o.title == STATUE).size(), "estátuas"]
		"arquilich":
			return [e.runes, "runas"]
		"sibila":
			return [1 if e.ward != "" else 0, e.ward]
		"bispo":
			return [penitents(e.main), "penitentes"]
		"carruagem":  # #48: as rodas
			return [e.limbs.filter(func(l): return l > 0.0).size(), "rodas"]
	return [0, ""]


## O ícone por cima da barra do chefe: a habilidade que o Arquivista copiou por último, ou a arma da Quimera e de cada Rei
## (Lote 9; null nos outros).
static func icon(e) -> Texture2D:
	if ARMS.has(e.style):
		return ARMS[e.style]
	return e.main.hud.ICONS.get(e.copy[-1]) if not e.copy.is_empty() else null


## A coroa da Quimera e dos Reis, no desenho dele: na cabeça, do lado para onde o desenho olha (o mesmo lado do enemy._draw:
## o Rei de Prata com o alvo à mesma altura olhava para a esquerda com a coroa no ombro da direita).
static func crown_at(e) -> Vector2:
	var top: float = e._top()
	var fx := 1.0 if e.target == null or e.target.position.x > e.position.x else -1.0
	return Vector2(fx * 0.2 * -top, top * 0.88)


## O centro do disco da arma: logo por cima da coroa; se aí cai debaixo das barras dos chefes, logo por baixo delas, ao lado
## da cabeça (do lado de trás: por baixo da coroa tapava a cara).
static func icon_at(e) -> Vector2:
	var head := crown_at(e)
	var c := head + Vector2(0, -50)
	var hud = e.main.hud
	if hud != null and hud.stack_y > 0.0:
		var t: Transform2D = e.get_global_transform_with_canvas()
		var r: Rect2 = t * Rect2(c - Vector2(26, 26), Vector2(52, 52))
		if hud.name_blocked(r):
			c.x = head.x - signf(head.x) * 64.0
			c.y += maxf(0.0, hud.stack_y + 4.0 - r.position.y) / t.get_scale().y
	return c


## Lote 8 C (b): os avisos do chefe no chão (as pedras, a Pisada e as bolhas, que enchem até cair como o aviso do murro; a
## linha vermelha da corrente, da Lança copiada, do fio ou da investida; a guilhotina parada a avisar), no ci da camada do
## chão (main.ground, por baixo de todas as personagens). Coordenadas do mundo. main.warned diz onde foi cada um (o teste).
static func draw_warns(e, ci: Node2D) -> void:
	var m = e.main
	for r in e.rain:
		Pix.warn(ci, r[0], r[1], 1.0 - (e.rain_at - m.time) / RAIN_T, "necro" if r.size() > 2 and str(r[2]) == "cabelos" else "life")
		m.warned["rain"] = ci
	if e.chain_at > m.time and not e.blades.is_empty():  # #187: as lâminas invisíveis da Donzela, só um tracejado ténue em píxeis
		for b in e.blades:
			var u: Vector2 = b[0].direction_to(b[1])
			var n := u.orthogonal() * Pix.S
			for k in int(b[0].distance_to(b[1]) / 28.0):
				var p: Vector2 = b[0] + u * (28.0 * k + 40.0)
				for w in [-n, Vector2.ZERO, n]:
					Pix.line(ci, p + w, p + u * 16.0 + w, Color(0.85, 0.95, 1.0, 0.3))
		m.warned["chain"] = ci
	elif e.chain_at > m.time:
		ci.draw_line(e.chain_from, e.chain_to, Color(1.0, 0.15, 0.1, 0.35 + 0.3 * sin(m.time * 20.0)), 8.0)
		m.warned["chain"] = ci
	var s: float = (m.time - e.blade_at) * BLADE_V
	if e.blade_at > 0.0 and s > -BLADE_V and s < 0.0 and e.blade_dir != Vector2.ZERO:
		var o: Vector2 = e.blade_dir.orthogonal() * 500.0
		ci.draw_line(e.blade_from - o, e.blade_from + o, Color(1.0, 0.15, 0.1, 0.3 + 0.25 * sin(m.time * 16.0)), 10.0)
		m.warned["blade"] = ci


## Lote 8 C (f): a linha de a a b (no desenho de e) passa pelo cartão do chefe à vista? Então não se desenha (volta quando o
## cartão sai): os raios das estátuas do Guardião cruzavam a faixa do cartão. e.tether_cut diz se alguma ficou de fora (o teste).
static func _carded(e, a: Vector2, b: Vector2) -> bool:
	var band: Rect2 = e.main.hud.card_block() if e.main.hud != null else Rect2()
	if not band.has_area():
		return false
	var t: Transform2D = e.get_global_transform_with_canvas()
	var p: Vector2 = t * a
	var q: Vector2 = t * b
	var c := [band.position, Vector2(band.end.x, band.position.y), band.end, Vector2(band.position.x, band.end.y)]
	var hit: bool = band.has_point(p) or band.has_point(q) or range(4).any(func(i): return Geometry2D.segment_intersects_segment(p, q, c[i], c[(i + 1) % 4]) != null)
	if hit:
		e.tether_cut = true
	return hit


## O que cada telemóvel desenha do chefe por cima dele, só com os campos que viajam: membros, guilhotina a varrer, raios,
## runas (os avisos no chão são do draw_warns).
static func draw(e) -> void:
	var m = e.main
	e.tether_cut = false
	if e.dying:
		return
	var s: float = (m.time - e.blade_at) * BLADE_V
	if e.blade_at > 0.0 and s >= 0.0 and s < BLADE_V * BLADE_T and e.blade_dir != Vector2.ZERO:  # a guilhotina: depois do aviso (draw_warns), varre
		var c: Vector2 = e.blade_from - e.position + e.blade_dir * s
		var o: Vector2 = e.blade_dir.orthogonal() * 500.0
		e.draw_line(c - o, c + o, Color(0.12, 0.12, 0.14), 14.0)
		e.draw_line(c - o, c + o, Color(0.8, 0.82, 0.88), 6.0)
	var scream: float = (m.time - e.blade_at) * SCREAM_V
	if e.blade_at > 0.0 and e.blade_dir == Vector2.ZERO and scream >= 0.0 and scream <= SCREAM_R:  # #187: o anel do Grito, em píxeis
		var rr := maxf(snappedf(scream, 16.0), 16.0)  # aos degraus de 16 px: ~33 raios que ficam na cache dos anéis (um raio novo a cada frame recalculava-os a cada grito)
		Pix.loop(e, e.blade_from - e.position, rr, rr, Color(1.0, 0.72, 0.72, 0.9), 2, true)
		Pix.loop(e, e.blade_from - e.position, rr - 10.0, rr - 10.0, Color(1.0, 0.45, 0.45, 0.5), 1, false, 2)
	var mid := Vector2(0, e._top() * 0.5)
	if e.style == "amalgama":  # #220: as almas de que é feita a subir
		Pix.motes(e, Vector2(0, -20), 60.0 * e.size, -e._top() * 0.9, 8, m.time, Pix.ramp("soul"))
	if ARMS.has(e.style):  # #190 e #34: a coroa de ouro e, logo por cima dela, a arma de agora num disco escuro de aro dourado
		var head := crown_at(e)
		for k in [-1, 0, 1]:  # três pontas (cada peça é convexa) por cima do aro, com uma pedra em cada
			Pix.solid(e, head + Vector2(16 * k, -8), [Vector2(-6, 4), Vector2(0, -10 - 4 * (1 - absi(k))), Vector2(6, 4)], "gold", 2)
		Pix.solid(e, head, [Vector2(-22, -6), Vector2(22, -6), Vector2(22, 4), Vector2(-22, 4)], "gold", 3)
		for k in [-1, 0, 1]:
			Pix.px(e, head + Vector2(16 * k - 2, -2), Color(0.85, 0.15, 0.2) if k == 0 else Color(0.35, 0.6, 1.0), 2, 2)
		var c := icon_at(e)  # revisão do Lote 9: a 80-100 px dele, solta e sem fundo, lia-se como saque no chão
		Pix.disc(e, c, 13, Color(0.1, 0.06, 0.03))
		Pix.disc(e, c, 12, Color(0.85, 0.62, 0.25))
		Pix.disc(e, c, 11, Color(0.06, 0.04, 0.05))
		e.draw_texture_rect(ARMS[e.style], Rect2(c - Vector2(20, 20), Vector2(40, 40)), false)
	match e.boss:
		"suturado":  # os membros cosidos, cada um com a sua barra
			for i in e.limbs.size():
				if e.limbs[i] > 0.0:
					var c: Vector2 = LIMBS[i] * e.size
					Pix.orb(e, c, 10, "bleed")
					e.draw_rect(Rect2(Pix.snap(e, c + Vector2(-14, -1)), Vector2(28, Pix.S)), Color(0.1, 0.05, 0.05))  # a costura
					for k in 4:
						e.draw_rect(Rect2(Pix.snap(e, c + Vector2(-12 + 8 * k, -7)), Vector2(Pix.S, 14)), Color(0.1, 0.05, 0.05))
					e.draw_rect(Rect2(c + Vector2(-22, 25), Vector2(44, 6)), Color(0, 0, 0, 0.7))
					e.draw_rect(Rect2(c + Vector2(-22, 25), Vector2(44 * e.limbs[i], 6)), Color(0.85, 0.2, 0.2))
		"carrasco":  # quem está preso: a corrente de ferro esticada até ele
			var hand := Vector2(0, e._top() * 0.45)
			for p in m.players:
				var to: Vector2 = p.position - e.position + Vector2(0, -20)
				if p.root_until > m.time and not p.dead and not _carded(e, hand, to):
					e.draw_line(hand, to, Color(0.15, 0.15, 0.17), 6.0)
					e.draw_line(hand, to, Color(0.6, 0.6, 0.66), 3.0)
		"guardiao":  # os raios verde-pedra das estátuas até ele (C (f): os que cruzam o cartão do chefe esperam que ele saia)
			for o in m.enemies():
				var to: Vector2 = o.position - e.position + Vector2(0, o._top() * 0.5)
				if o.anchor and o.title == STATUE and not _carded(e, mid, to):
					e.draw_line(mid, to, Color(0.55, 0.85, 0.65, 0.45 + 0.2 * sin(m.time * 6.0)), 5.0)
		"bispo":  # as orações dos penitentes até ele, a dourado
			for o in m.enemies():
				var to: Vector2 = o.position - e.position + Vector2(0, o._top() * 0.6)
				if o.anchor and o.title == PENITENT and not _carded(e, mid, to):
					e.draw_line(mid, to, Color(1.0, 0.85, 0.4, 0.35 + 0.2 * sin(m.time * 4.0 + o.position.x)), 3.0)
		"arquivista":  # a Armadura de Ossos copiada
			if e.armor > 0.6:
				Pix.band(e, mid, 64.0 * e.size, 84.0 * e.size, "bone", 3.0, 6)
		"sibila":  # o anel da cor daquilo a que está fechada
			if e.ward != "":
				Pix.band(e, mid, 70.0 * e.size, 90.0 * e.size, WARDS[e.ward], 2.0, 8)
		"arquilich":  # as runas em volta
			for i in e.runes:
				var a: float = TAU * i / RUNE_N + m.time * 1.2
				var at: Vector2 = mid + Vector2(cos(a) * 80.0, sin(a) * 34.0) * e.size
				Pix.orb(e, at, 5, "soulblue")
				Pix.stamp(e, Pix._rune_tex(i, "bone"), at)
		"marechal":  # a lança de ferro, para o lado para onde investe (ou de quem persegue)
			var aim: float = (e.chain_to.x - e.position.x) if e.chain_at > m.time or e.act == "dash" else (e.target.position.x - e.position.x) if e.target != null else 1.0
			var sx := -1.0 if aim < 0.0 else 1.0
			if old_lance:
				var was := Vector2(30.0 * sx, e._top() * 0.45)
				Pix.solid(e, was, [Vector2(0, -6), Vector2(170 * sx, -3), Vector2(170 * sx, 3), Vector2(0, 6)], "iron")
				Pix.solid(e, was + Vector2(170 * sx, 0), [Vector2(0, -10), Vector2(30 * sx, 0), Vector2(0, 10)], "iron", 1)
				return
			# em píxeis, na mão da frente (o braço desce até ao joelho) e um pouco erguida: haste em 3 tons de ferro com contorno
			# escuro, o cone da guarda junto à mão e a ponta em folha, mais clara
			var hand := Vector2(-0.37 * e._top() * sx, e._top() * 0.2)
			var d := Vector2(sx, -0.13).normalized()
			var n := d.orthogonal()
			var parts := [[[d * -30.0 - n * 4.0, d * 150.0 - n * 2.5, d * 150.0 + n * 2.5, d * -30.0 + n * 4.0], 4],
				[[d * 4.0 - n * 10.0, d * 24.0 - n * 5.0, d * 24.0 + n * 5.0, d * 4.0 + n * 10.0], 5],  # a guarda
				[[d * 144.0 - n * 7.0, d * 190.0, d * 144.0 + n * 7.0, d * 137.0], 3]]  # a ponta
			for q in parts:  # por baixo, a mesma lança a negro, 1 célula para cada lado: o contorno de 1 célula perdia-se no chão escuro e na arma do herói. C (g): a mesma peça desviada (um polígono maior arredondava para baixo e ficava só por baixo, como uma sombra)
				for o in [Vector2(-Pix.S, 0), Vector2(Pix.S, 0), Vector2(0, -Pix.S), Vector2(0, Pix.S)]:
					Pix.solid(e, hand + o, q[0], "iron", q[1], Color.BLACK)
			for q in parts:
				Pix.solid(e, hand, q[0], "iron", q[1])


## #48: a Carruagem Fúnebre, composta, toda aos píxeis de 2 px: o caixão (x 2) assente numa longarina de madeira entre 2 rodas
## de ferro escuro (aro grosso, 6 raios de madeira que rodam com o caminho andado, iguais nos dois telemóveis, e o cubo com o
## eixo), puxada por 2 colossos (os desenhos de andar, a 0,8) presos por um varal e uma canga por cima dos ombros, com uma
## lanterna de alma no tampo (caixilho, telhado e chama). O contorno claro de todos os chefes novos. Vira-se para onde vai
## (chain_to).
static func draw_cart(e) -> void:
	var m = e.main
	var sx := _cart_side(e)
	var d: Vector2 = e.position.direction_to(e.chain_to) if e.position.distance_to(e.chain_to) > 1.0 else Vector2(sx, 0)
	var a := 1.0 if not e.dying else clampf((e._death_len() - e.death_t) / 0.5, 0.0, 1.0)
	var tint := Color(200, 200, 200, a) if e.flash > 0.07 else Color(1.8, 1.8, 1.8, a) if e.flash > 0.0 else Color(1, 1, 1, a)
	var I: Array = Pix.ramp("iron")
	var W: Array = Pix.ramp("ash")
	var wood := Color("7a4a24")  # a madeira da longarina, dos raios, do varal e da canga
	var roll: float = (e.position.x + e.position.y) / 28.0  # quanto rodou: do caminho andado
	var nose := Vector2(CART_NOSE.x * sx, CART_NOSE.y)
	var g := Pix.snap(e, Vector2.ZERO)  # o caixão, as barras e os raios na mesma grelha de 2 px do mundo
	var ln := func(p: Vector2, q: Vector2, c: Color) -> void:
		e.draw_line(g + Pix.cell(p) + Vector2.ONE, g + Pix.cell(q) + Vector2.ONE, Color(c, a), Pix.S)
	var beam := func(p: Vector2, q: Vector2, c: Color, n: int) -> void:  # barra de n células a começar em p-q, com contorno e o cimo mais claro
		var o := Vector2(0, Pix.S) if absf(q.x - p.x) >= absf(q.y - p.y) else Vector2(Pix.S, 0)
		for j in range(-1, n + 1):
			ln.call(p + o * j, q + o * j, Pix.OUTLINE if j < 0 or j == n else c.lightened(0.3) if j == 0 else c)
	Pix.haze(e, Vector2(-14 * sx, 4), 124.0, 46.0, Color.BLACK, 0.6 * a)
	var wheel := func(i: int) -> void:
		var c: Vector2 = wheel_at(e, i)
		if e.limbs.size() > i and e.limbs[i] <= 0.0:  # partida: lascas de ferro no chão
			for k in 4:
				Pix.px(e, c + Vector2(-18 + 11 * k, 26 - 4 * (k % 2)), Color(I[6 + k % 2], a), 3, 1)
			return
		Pix.loop(e, c, 28.0, 28.0, Color(W[4], a), 4, true)  # o aro: ferro escuro e grosso (4 células), com contorno
		Pix.loop(e, c, 26.0, 26.0, Color(W[2], a), 1)  # a luz do ferro
		Pix.loop(e, c, 22.0, 22.0, Color(wood.darkened(0.35), a), 1)  # e as cambas de madeira por dentro
		for k in 3:  # 6 raios de madeira de 2 células, a rodar
			var v := Vector2.from_angle(roll + k * PI / 3.0) * 20.0
			var o := Vector2(Pix.S, 0) if absf(v.y) > absf(v.x) else Vector2(0, Pix.S)
			ln.call(c + v, c - v, wood.lightened(0.2))
			ln.call(c + v + o, c - v + o, wood.darkened(0.35))
		Pix.orb(e, c, 3, "ash")  # o cubo, com a ponta do eixo
	# os dois colossos que a puxam: à frente dela (de lado, um atrás do outro; a vir para cá, lado a lado em baixo; a ir, em cima)
	var spots: Array
	var hitch: Vector2
	if absf(d.y) > absf(d.x) * 1.2:
		hitch = Vector2(6, 26) if d.y > 0.0 else Vector2(-6, -130)
		spots = [hitch + Vector2(-56, 110 if d.y > 0.0 else -70), hitch + Vector2(56, 118 if d.y > 0.0 else -62)]
	else:
		hitch = nose
		spots = [nose + Vector2(sx * 112, -46), nose + Vector2(sx * 168, 22)]
	spots.sort_custom(func(u, v): return u.y < v.y)
	var ahead: bool = spots.any(func(p): return p.y > hitch.y - 30.0)  # algum à frente do caixão (de lado e a vir para cá)
	var pullers := func(front: bool) -> void:
		var f: int = int(e.t * 10.0) % 8 if e.speed > 0.0 else 16 + int(e.t * 5.0) % 4
		var tex: Texture2D = e.get_script().FRAMES32.colossus[f]
		var sc: float = e.Feet32.SCALE["colossus32"] * 0.8
		var feet: float = e.Feet32.FEET["colossus32"][f]
		var face := sx if absf(d.x) > 0.05 else 1.0
		for p in spots:
			if (p.y > hitch.y - 30.0) != front:
				continue
			e.draw_set_transform(p, 0.0, Vector2(sc * face, sc))
			for o in [Vector2(-2, 0), Vector2(2, 0), Vector2(0, -2), Vector2(0, 2)]:
				e.draw_texture(tex, Vector2(-tex.get_width() / 2.0, -tex.get_height() + feet) + o / sc, Color(200, 200, 200, 0.35 * a))
			e.draw_texture(tex, Vector2(-tex.get_width() / 2.0, -tex.get_height() + feet), tint)
			e.draw_set_transform(Vector2.ZERO)
	var harness := func() -> void:  # a canga de madeira por cima dos ombros deles, com as ferragens de latão, e o varal até à carruagem
		var ch: Array = spots.map(func(p): return p + Vector2(0, -84))
		beam.call(hitch, (ch[0] + ch[1]) / 2.0, wood, 3)
		beam.call(ch[0], ch[1], wood, 3)
		for q in ch:
			Pix.orb(e, q, 2, "gold")
	pullers.call(false)
	if not ahead:
		harness.call()
	e.draw_set_transform(g, 0.0, Vector2(sx, 1.0))
	for o in [Vector2(-2, 0), Vector2(2, 0), Vector2(0, -2), Vector2(0, 2)]:
		e.draw_texture_rect(_coffin(), Rect2(CART_BODY.position + o, CART_BODY.size), false, Color(200, 200, 200, 0.35 * a))
	e.draw_texture_rect(_coffin(), CART_BODY, false, tint)
	e.draw_set_transform(Vector2.ZERO)
	beam.call(wheel_at(e, 0) - Vector2(0, 4), wheel_at(e, 1) - Vector2(0, 4), wood, 3)  # a longarina, de cubo a cubo, e até à frente
	beam.call(wheel_at(e, 1) - Vector2(0, 4), nose, wood, 3)
	wheel.call(0)
	wheel.call(1)
	pullers.call(true)
	if ahead:
		harness.call()
	# a lanterna de alma no tampo: o poste, a base, o vidro aceso com a chama, os montantes, o telhado e a argola
	var lamp := Vector2(CART_LAMP.x * sx, CART_LAMP.y)
	var la := Color(1, 1, 1, a)
	Pix.haze(e, lamp + Vector2(0, -26), 36.0, 32.0, Color(0.5, 1.0, 0.7), (0.3 + 0.08 * sin(m.time * 6.0)) * a)
	Pix.solid(e, lamp + Vector2(0, -5), [Vector2(-2, -5), Vector2(2, -5), Vector2(2, 5), Vector2(-2, 5)], "iron", 5, la)
	Pix.solid(e, lamp + Vector2(0, -11), [Vector2(-10, -2), Vector2(10, -2), Vector2(8, 3), Vector2(-8, 3)], "iron", 5, la)
	Pix.solid(e, lamp + Vector2(0, -25), [Vector2(-8, -12), Vector2(8, -12), Vector2(8, 12), Vector2(-8, 12)], "soul", 2, la, false)
	Pix.solid(e, lamp + Vector2(0, -17), [Vector2(-8, -4), Vector2(8, -4), Vector2(8, 4), Vector2(-8, 4)], "soul", 4, la, false)
	var fl := 2 * (int(m.time * 8.0) % 2)  # a chama a tremer, aos degraus (2 formas)
	Pix.solid(e, lamp + Vector2(0, -26), [Vector2(0, -9 - fl), Vector2(4, -2), Vector2(2, 5), Vector2(-2, 5), Vector2(-4, -2)], "soul", 0, la, false)
	for k in [-1, 1]:
		Pix.solid(e, lamp + Vector2(10 * k, -25), [Vector2(-2, -13), Vector2(2, -13), Vector2(2, 13), Vector2(-2, 13)], "iron", 6, la)
	Pix.solid(e, lamp + Vector2(0, -41), [Vector2(-14, 4), Vector2(14, 4), Vector2(6, -5), Vector2(-6, -5)], "iron", 4, la)
	Pix.solid(e, lamp + Vector2(0, -48), [Vector2(-2, -3), Vector2(2, -3), Vector2(2, 3), Vector2(-2, 3)], "iron", 5, la)
	Pix.loop(e, lamp + Vector2(0, -55), 4.0, 4.0, Color(I[5], a), 1, true)
	if e.dying:
		return
	for i in e.limbs.size():  # a vida da roda já ferida, por baixo dela
		if e.limbs[i] > 0.0 and e.limbs[i] < 1.0:
			var c: Vector2 = wheel_at(e, i) + Vector2(-20, 34)
			e.draw_rect(Rect2(c, Vector2(40, 5)), Color(0, 0, 0, 0.7))
			e.draw_rect(Rect2(c, Vector2(40 * e.limbs[i], 5)), Color(0.85, 0.2, 0.2))


## A esfera do Arquilich e a agulha da Tecelã: em píxeis, sem o desenho de um monstro (enemy._draw).
static func draw_odd(e) -> void:
	if e.dying:
		return
	var m = e.main
	if e.hatch_at > 0.0:  # o ovo da Matriarca (#40): o aviso no chão (enemy.draw_warns) enche até rebentar; perto do fim treme
		var k: float = 1.0 - (e.hatch_at - m.time) / EGG_T
		Pix.haze(e, Vector2(0, 2), 16.0, 6.0, Color.BLACK, 0.6)
		var wob := Vector2(roundf(sin(m.time * 30.0) * 2.0) if k > 0.75 else 0.0, 0.0)
		Pix.solid(e, wob, EGG, "rot", 3)
		Pix.solid(e, wob, EGG_SHADE, "rot", 5, Color.WHITE, false)
		Pix.px(e, wob + Vector2(-5, -20), Pix.RAMPS.rot[0], 2, 4)
		return
	if e.orb:  # dourada quando já foi devolvida
		Pix.haze(e, Vector2(0, -36), 22.0, 22.0, Color(1.0, 0.8, 0.4) if e.back else Color(0.35, 0.6, 1.0), 0.5)
		Pix.orb(e, Vector2(0, -36), 6, "gold" if e.back else "soulblue")
		return
	e.tether_cut = false
	for p in m.players:  # o fio branco: do herói cosido à agulha e dela até à Tecelã (nunca por cima do cartão do chefe)
		if p.slot == e.pin_of and not p.dead and not _carded(e, Vector2(0, -46), p.position - e.position + Vector2(0, -10)):
			e.draw_line(Vector2(0, -46), p.position - e.position + Vector2(0, -10), Color(0.95, 0.95, 1.0, 0.8), 2.0)
	for o in m.enemies():
		if o.boss == "tecela" and not _carded(e, Vector2(0, -46), o.position - e.position + Vector2(0, o._top() * 0.5)):
			e.draw_line(Vector2(0, -46), o.position - e.position + Vector2(0, o._top() * 0.5), Color(0.95, 0.95, 1.0, 0.55), 2.0)
	# espetada no chão: o buraco da linha em cima, a ponta enterrada, osso claro com o lado da luz e o da sombra
	Pix.haze(e, Vector2(0, -26), 14.0, 30.0, Color(0.92, 0.92, 1.0), 0.25)
	Pix.haze(e, Vector2.ZERO, 14.0, 5.0, Color.BLACK, 0.6)
	Pix.solid(e, Vector2(0, -26), [Vector2(-3, -26), Vector2(3, -26), Vector2(6, -20), Vector2(6, 16), Vector2(0, 26), Vector2(-6, 16), Vector2(-6, -20)], "bone", 1)
	var B := Pix.ramp("bone")
	e.draw_rect(Rect2(Pix.snap(e, Vector2(-4, -42)), Vector2(2, 32)), B[0])
	e.draw_rect(Rect2(Pix.snap(e, Vector2(4, -42)), Vector2(2, 32)), B[3])
	e.draw_rect(Rect2(Pix.snap(e, Vector2(0, -48)), Vector2(2, 6)), Pix.OUTLINE)
