extends Node2D
## Lança de Almas: projétil que explode no primeiro inimigo.
## Como num desenho animado: estica na direção do voo, faz uma curva e o rasto fica para trás.

const ORB := preload("res://art/orb.png")

var main
var by  # jogador que lançou (para o roubo de vida)
var raise := false  # Alma Tumular: quem morrer com ela ergue-se como aliado
var dir := Vector2.RIGHT
var dmg := 30.0
var r := 16.0
var life := 1.1
var age := 0.0
var line_pos := Vector2.ZERO  # o ponto na linha da mira: a Lança desvia-se dele e volta
var bend := 0.0
var trail := []  # posições anteriores, a mais recente primeiro


func _ready() -> void:
	z_index = 4
	line_pos = position
	bend = 18.0 if randf() < 0.5 else -18.0  # pouco: quem está na linha da mira continua a ser atingido


func _process(delta: float) -> void:
	age += delta
	trail.push_front(position)
	if trail.size() > 6:
		trail.pop_back()
	line_pos += dir * 640.0 * delta
	# Nada voa a direito: sai para um lado e volta à linha da mira aos 0,35 s
	position = line_pos + dir.orthogonal() * bend * sin(PI * minf(age / 0.35, 1.0))
	life -= delta
	# Na cripta rebenta nas paredes (a Lança voa 20 px acima do chão)
	if main.zone == "crypt" and not Geometry2D.is_point_in_polygon(position + Vector2(0, 20), main.crypt_floor):
		main.spawn_fx("ring", position, r * 2.0, Color(0.4, 0.9, 1.0))
		queue_free()
		return
	for e in main.enemies():
		if position.distance_to(e.position + Vector2(0, -20)) < r + e.radius:
			main.raise_by = by if raise else null
			main.hit_circle(position, r * 3.0, dmg, by)
			main.raise_by = null
			main.spawn_fx("ring", position, r * 3.0, Color(0.4, 0.9, 1.0))
			queue_free()
			return
	if life <= 0.0:
		queue_free()
	queue_redraw()


func _draw() -> void:
	for i in trail.size():
		draw_circle(trail[i] - position, r * (0.86 - i * 0.12), Color(0.4, 1.0, 0.7, 0.34 - i * 0.05))
	var v: Vector2 = position - trail[0] if not trail.is_empty() else dir
	var sc := r * 2.6 / ORB.get_width()
	draw_set_transform(Vector2.ZERO, (v if v.length() > 0.01 else dir).angle(), Vector2(sc * 1.45, sc * 0.75))
	draw_texture(ORB, -ORB.get_size() / 2.0)
	draw_set_transform(Vector2.ZERO)
