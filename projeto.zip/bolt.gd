extends Node2D
## Lança de Almas: projétil que explode no primeiro inimigo.

const ORB := preload("res://art/orb.png")

var main
var by  # jogador que lançou (para o roubo de vida)
var dir := Vector2.RIGHT
var dmg := 30.0
var r := 16.0
var life := 1.1


func _ready() -> void:
	z_index = 4


func _process(delta: float) -> void:
	position += dir * 640.0 * delta
	life -= delta
	# Na cripta rebenta nas paredes (a Lança voa 20 px acima do chão)
	if main.zone == "crypt" and not Geometry2D.is_point_in_polygon(position + Vector2(0, 20), main.crypt_floor):
		main.spawn_fx("ring", position, r * 2.0, Color(0.4, 0.9, 1.0))
		queue_free()
		return
	for e in main.enemies():
		if position.distance_to(e.position + Vector2(0, -20)) < r + e.radius:
			main.hit_circle(position, r * 3.0, dmg, by)
			main.spawn_fx("ring", position, r * 3.0, Color(0.4, 0.9, 1.0))
			queue_free()
			return
	if life <= 0.0:
		queue_free()
	queue_redraw()


func _draw() -> void:
	for i in range(1, 5):
		draw_circle(-dir * i * 10.0, r * (1.0 - i * 0.17), Color(0.4, 1.0, 0.7, 0.4 - i * 0.08))
	var sc := r * 2.6 / ORB.get_width()
	draw_set_transform(Vector2.ZERO, 0.0, Vector2(sc, sc))
	draw_texture(ORB, -ORB.get_size() / 2.0)
	draw_set_transform(Vector2.ZERO)
