extends Node2D
## Lança de Almas: projétil que explode no primeiro inimigo (com pierce, atravessa-os um a um).
## Como num desenho animado: estica na direção do voo, faz uma curva e o rasto fica para trás.

const ORB := preload("res://art/fx/soul_orb.png")  # 32-bit, desenhado píxel a píxel
const Pix := preload("res://fx_pix.gd")

var main
var by  # jogador que lançou (para o roubo de vida)
var raise := 0  # Alma Tumular (1) ou Mitótica (2): quantos aliados se erguem de quem morrer com ela
var support := ""  # o frasco da Lança (vai para main.cast_support enquanto rebenta)
var aff := 0  # Alma Caótica: 1 podridão, 2 necrose, 3 calcificação; 0 nenhuma (os estilhaços das Sentinelas)
var dir := Vector2.RIGHT
var dmg := 30.0
var r := 16.0
var life := 1.1
var age := 0.0
var line_pos := Vector2.ZERO  # o ponto na linha da mira: a Lança desvia-se dele e volta
var bend := 0.0
var trail := []  # posições anteriores, a mais recente primeiro
var bone := false  # Sentinelas Tumulares (#25): estilhaço de osso em vez do orbe da Lança (viaja ao convidado)
var seek = null  # o estilhaço persegue este monstro (só no anfitrião)
var tint := Color(0.95, 0.9, 0.75)  # cor do estilhaço: osso nas Sentinelas (#25), violeta no Espectro da Vingança (#143) (viaja ao convidado)
var quiet := false  # estilhaços das Almas Condensadas: sem paragem de impacto (vários seguidos davam uma série de paragens)
var skull := false  # Dança dos Crânios Flamejantes (#167): crânio em chamas em vez da lasca (viaja ao convidado)
var pierce := 0  # S4: quantos monstros ainda atravessa, um golpe a cada um, sem a explosão (0 = rebenta no primeiro)
var pin := false  # Lança-Ossos Balística (#103): estaca que leva quem atravessa e o prende onde parar (viaja ao convidado)
var pierced = []  # já atravessados (sem tipo: só o anfitrião)
var carried = []  # os que a estaca leva (sem tipo: só o anfitrião)


func _ready() -> void:
	z_index = 4
	line_pos = position
	bend = 18.0 if randf() < 0.5 else -18.0  # pouco: quem está na linha da mira continua a ser atingido
	if bone:
		bend = 0.0  # a sentinela não tem mão a tremer: com curva falhava quem anda de lado


func _process(delta: float) -> void:
	age += delta
	trail.push_front(position)
	if trail.size() > 6:
		trail.pop_back()
	if bone and is_instance_valid(seek) and not seek.dying:  # vira até 5 rad/s para o alvo, que entretanto andou
		var turn := dir.angle_to(line_pos.direction_to(seek.position + Vector2(0, -20)))
		dir = dir.rotated(clampf(turn, -5.0 * delta, 5.0 * delta))
	line_pos += dir * 640.0 * delta
	# Nada voa a direito: sai para um lado e volta à linha da mira aos 0,35 s
	position = line_pos + dir.orthogonal() * bend * sin(PI * minf(age / 0.35, 1.0))
	life -= delta
	for i in carried.size():  # a estaca leva-os espetados em fila atrás da ponta
		var c = carried[i]
		if is_instance_valid(c) and not c.dying:
			c.position = main.walk(c.position, position + Vector2(0, 20) - dir * 18.0 * i)
			c.knock = Vector2.ZERO
			c.pin_t = 0.3
	# Na cripta e nos Sepulcros rebenta nas paredes (a Lança voa 20 px acima do chão)
	if main.zone != "world" and not main.on_floor(position + Vector2(0, 20)):
		main.spawn_fx("ring", position, r * 2.0, Color(0.4, 0.9, 1.0))
		_end()
		return
	for e in (main.enemies() if pierce > 0 or not pin else []):  # a estaca cheia (pierce 0) já só leva os que tem
		if e in pierced or position.distance_to(e.position + Vector2(0, -20)) >= r + e.radius:
			continue
		main.raise_by = by if raise > 0 else null
		main.raise_n = raise
		main.cast_support = support
		main.cast_aff = aff
		main.quiet = quiet
		if pierce > 0:  # S4: atravessa-o, com um golpe só nele
			pierce -= 1
			pierced.append(e)
			main._impact([main._damage(e, dmg, by, position - dir * 30.0)], by)
			main._arcs([e], position, dmg, by)
			if pin and e.is_boss:  # a estaca não leva chefes: só os abranda
				e.slow_t = maxf(e.slow_t, 2.0)
			elif pin and not e.dummy and not e.dying:
				carried.append(e)
		else:
			main.hit_circle(position, r * 3.0, dmg, by)
		main.quiet = false
		main.raise_by = null
		main.cast_support = ""
		main.cast_aff = 0
		main.spawn_fx("ring", position, r * (2.0 if pierced.has(e) else 3.0), tint if bone else main.CORPSE_COLORS[aff] if aff > 0 else Color(0.4, 0.9, 1.0))
		if pierce <= 0 and not pin:
			queue_free()
			return
		if pierce <= 0:  # a estaca encheu: continua a voar com eles
			break
	if life <= 0.0:
		_end()
		return
	queue_redraw()


## A estaca para (acabou o voo ou bateu numa parede da cripta): quem ela leva fica preso 1,5 s onde ela parou.
func _end() -> void:
	for c in carried:
		if is_instance_valid(c) and not c.dying:
			c.pin_t = 1.5
			main.spawn_fx("dust", c.position, 40.0, Color(0.9, 0.86, 0.75))
	queue_free()


func _draw() -> void:
	var col := tint if bone else Color(0.4, 1.0, 0.7)
	for i in trail.size():
		Pix.haze(self, trail[i] - position, r * (0.86 - i * 0.12), r * (0.86 - i * 0.12), col, 0.7 - i * 0.1)
	var v: Vector2 = position - trail[0] if not trail.is_empty() else dir
	if skull:  # bola de fogo com o miolo amarelo, como os crânios em órbita
		Pix.orb(self, Vector2.ZERO, maxi(2, roundi(r * 0.3)), "loot_ash")
		return
	if bone:  # lasca de osso comprida e afiada que aponta para onde voa, em 16 direções (a estaca do #103, o dobro do comprimento)
		var k := 2.0 if pin else 1.0
		var a := snappedf((v if v.length() > 0.01 else dir).angle(), TAU / 16.0)
		Pix.solid(self, Vector2.ZERO, [Vector2(r * 1.8 * k, 0).rotated(a), Vector2(0, -r * 0.45).rotated(a), Vector2(-r * 1.4 * k, 0).rotated(a), Vector2(0, r * 0.45).rotated(a)], "bone", 1, col)
		return
	var sc := r * 2.6 / ORB.get_width()
	draw_set_transform(Vector2.ZERO, (v if v.length() > 0.01 else dir).angle(), Vector2(sc * 1.45, sc * 0.75))
	draw_texture(ORB, -ORB.get_size() / 2.0)
	draw_set_transform(Vector2.ZERO)
