extends Node2D
## Lança de Almas: projétil que explode no primeiro inimigo.
## Como num desenho animado: estica na direção do voo, faz uma curva e o rasto fica para trás.

const ORB := preload("res://art/orb.png")

var main
var by  # jogador que lançou (para o roubo de vida)
var raise := 0  # Alma Tumular (1) ou Mitótica (2): quantos aliados se erguem de quem morrer com ela
var support := ""  # o frasco da Lança (vai para main.cast_support enquanto rebenta)
var aff := 0  # Alma Caótica: 1 podridão, 2 necrose, 3 calcificação; 0 nenhuma (os estilhaços das Sentinelas)
var dir := Vector2.RIGHT
var dmg := 30.0
var r := 16.0
var life := 1.1
var age := 0.0
var line_pos := Vector2.ZERO  # o ponto na linha da mira: a Lança desvia-se dele e volta
var bend := 0.0
var trail := []  # posições anteriores, a mais recente primeiro
var bone := false  # Sentinelas Tumulares (#25): estilhaço de osso em vez do orbe da Lança (viaja ao convidado)
var seek = null  # o estilhaço persegue este monstro (só no anfitrião)


func _ready() -> void:
	z_index = 4
	line_pos = position
	bend = 18.0 if randf() < 0.5 else -18.0  # pouco: quem está na linha da mira continua a ser atingido
	if bone:
		bend = 0.0  # a sentinela não tem mão a tremer: com curva falhava quem anda de lado


func _process(delta: float) -> void:
	age += delta
	trail.push_front(position)
	if trail.size() > 6:
		trail.pop_back()
	if bone and is_instance_valid(seek) and not seek.dying:  # vira até 5 rad/s para o alvo, que entretanto andou
		var turn := dir.angle_to(line_pos.direction_to(seek.position + Vector2(0, -20)))
		dir = dir.rotated(clampf(turn, -5.0 * delta, 5.0 * delta))
	line_pos += dir * 640.0 * delta
	# Nada voa a direito: sai para um lado e volta à linha da mira aos 0,35 s
	position = line_pos + dir.orthogonal() * bend * sin(PI * minf(age / 0.35, 1.0))
	life -= delta
	# Na cripta rebenta nas paredes (a Lança voa 20 px acima do chão)
	if main.zone == "crypt" and not Geometry2D.is_point_in_polygon(position + Vector2(0, 20), main.crypt_floor):
		main.spawn_fx("ring", position, r * 2.0, Color(0.4, 0.9, 1.0))
		queue_free()
		return
	for e in main.enemies():
		if position.distance_to(e.position + Vector2(0, -20)) < r + e.radius:
			main.raise_by = by if raise > 0 else null
			main.raise_n = raise
			main.cast_support = support
			main.cast_aff = aff
			main.hit_circle(position, r * 3.0, dmg, by)
			main.raise_by = null
			main.cast_support = ""
			main.cast_aff = 0
			main.spawn_fx("ring", position, r * 3.0, Color(0.95, 0.9, 0.75) if bone else main.CORPSE_COLORS[aff] if aff > 0 else Color(0.4, 0.9, 1.0))
			queue_free()
			return
	if life <= 0.0:
		queue_free()
	queue_redraw()


func _draw() -> void:
	var col := Color(0.95, 0.9, 0.75) if bone else Color(0.4, 1.0, 0.7)
	for i in trail.size():
		draw_circle(trail[i] - position, r * (0.86 - i * 0.12), Color(col, 0.34 - i * 0.05))
	var v: Vector2 = position - trail[0] if not trail.is_empty() else dir
	if bone:  # lasca de osso comprida e afiada que aponta para onde voa
		draw_set_transform(Vector2.ZERO, (v if v.length() > 0.01 else dir).angle())
		draw_colored_polygon(PackedVector2Array([Vector2(r * 1.8, 0), Vector2(0, -r * 0.45), Vector2(-r * 1.4, 0), Vector2(0, r * 0.45)]), col)
		draw_set_transform(Vector2.ZERO)
		return
	var sc := r * 2.6 / ORB.get_width()
	draw_set_transform(Vector2.ZERO, (v if v.length() > 0.01 else dir).angle(), Vector2(sc * 1.45, sc * 0.75))
	draw_texture(ORB, -ORB.get_size() / 2.0)
	draw_set_transform(Vector2.ZERO)
