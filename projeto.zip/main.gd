extends Node2D
## Soulstrider: Necro-Dominion — protótipo. Mundo, loot, moedas, arma, co-op e o Cortejo Fúnebre.

const MAP := Rect2(-3200, -2400, 6400, 4800)
const Enemy := preload("res://enemy.gd")
const Loot := preload("res://loot.gd")
const Decoy := preload("res://decoy.gd")
const Fx := preload("res://fx.gd")
const Pix := preload("res://fx_pix.gd")
const Bolt := preload("res://bolt.gd")
const Player := preload("res://player.gd")
const Hud := preload("res://hud.gd")
const Chest := preload("res://chest.gd")
const Ally := preload("res://ally.gd")
const Tomb := preload("res://tomb.gd")
const SILHOUETTE := preload("res://silhouette.gdshader")
const FOG := preload("res://fog.gdshader")
const DARK := preload("res://dark.gdshader")
const Bosses := preload("res://bosses.gd")
const MAX_ALLIES := 4

const SUFFIXES := {
	"do Sangramento": {"bleed": 0.5},
	"da Ossada": {"dmg": 0.25},
	"da Vigília": {"regen": 3.0},
	"do Tutano": {"leech": 0.04},
	"do Coveiro Veloz": {"speed": 0.15},
	"da Podridão": {"rot": 1.0},  # #148: dano contínuo que pega a quem estiver encostado
	"da Calcificação": {"calcify": 1.0},  # #150: à 10.ª camada o inimigo vira estátua
	"da Necrose": {"necro": 1.0},  # #154: cada golpe uma camada (até 10), +5% de dano recebido por camada
}
const OFFENSIVE := ["do Sangramento", "da Ossada", "da Podridão", "da Calcificação", "da Necrose"]  # os que o Tinteiro Carmesim (#59) troca
const HIDDEN := {
	"Ruína dos Colossos: +60% dano a chefes": {"boss": 0.6},
	"Banquete Fúnebre: +5 vida por abate": {"kill_heal": 5.0},
	"Alma Faminta: +35% dano de feitiços": {"spell": 0.35},
}
const AFFIXES := {
	"blindados": ["Ossos Blindados", "inimigos +60% vida"],
	"furia": ["Fúria Espectral", "inimigos +35% velocidade"],
	"laminas": ["Lâminas Envenenadas", "inimigos +50% dano"],
	"legiao": ["Legião", "+60% escoltas"],
	"gemeo": ["Colosso Gémeo", "+1 colosso em cada onda"],
	"rebeldes": ["Almas Rebeldes", "mortos voltam e rebentam"],
	"sinos": ["Sineiros", "cala-os ou vem um colosso"],
	"ceifador": ["O Ceifador Ambulante", "a morte anda atrás de ti"],
	"eclipse": ["Eclipse Fúnebre", "a luz apaga-se: elites +30%"],
	"mares": ["Marés de Sangue Negro", "maré alta: fica nas pedras"],
	"dentes": ["Chuva de Dentes", "abriga-te nas pedras"],
}
const SEALS := ["blindados", "furia", "laminas", "legiao", "gemeo"]  # S8: os selos do Círculo (#27) são sempre estes 5
const CARDS := 6  # e o menu do Cortejo mostra 6 afixos de cada vez (affix_cards)
## Provações (Desafios, #37 e #214): [nome, o que muda]. Uma de cada vez, escolhida antes da 1.ª onda; dura o Cortejo.
const TRIALS := {
	"almas": ["Provação das Almas Rejeitadas", "Sem Frascos de Alma nem Alma Condensada. Saque a dobrar; a 1.ª vitória dá um Frasco que te falte."],
	"lamina": ["Provação da Lâmina Cega", "A arma não conta (sufixos, oculto e reforja) e os golpes básicos não saem: só habilidades. Saque a dobrar."],
}
## Eventos do cemitério (S9): [nome, o que fazer (no cartão), o aviso]. Um de cada vez, a cada 3 a 4 minutos, nunca o
## mesmo duas vezes seguidas.
const EVENTS := {
	"fenda": ["Fenda Necrótica", "Mata a horda antes de a fenda fechar", "Uma fenda necrótica abriu-se!"],
	"meteoro": ["Meteoro Funerário", "Sai do círculo vermelho e mata os elites da cratera", "Um meteoro funerário vai cair!"],
	"banquete": ["Banquete dos Espectros", "Trava os espectros antes que comam o titã", "Os espectros vêm para o banquete!"],
}
## Santuário dos Deuses Cadavéricos (#50): as 4 leis, uma a cada 25% da vida do deus: [nome, a lei, o que muda].
const LAWS := [
	["Primeira lei", "a cura fere", "O que te cura tira-te vida (nunca abaixo de 1)."],
	["Segunda lei", "a alma paga-se com sangue", "As habilidades custam vida em vez de alma (nunca matam)."],
	["Terceira lei", "a alma esvai-se", "Perdes 8 de alma por segundo; cada morte dá 30."],
	["Quarta lei", "só a morte cura", "As poções não fazem nada; cada morte cura 5% da vida."],
]
const FLOOR_T := 40.0  # Mausoléu Sem Fim (#27): quanto dura cada piso (os de chefe, até ele cair)
## Relíquias de Família (#58): [nome, lenda]. Caem dos chefes com nome; cada uma dá +1 ponto na Árvore a cada herói.
const RELICS := {
	"anel": ["Anel da Avó Coveira", "Enterrou três maridos. Nenhum ficou quieto."],
	"coracao": ["Coração Embalsamado de Herói", "Ainda bate quando alguém diz o nome dele."],
	"medalha": ["Medalha do Primeiro Ceifeiro", "Dada a quem ceifou mil almas sem perder a sua."],
	"chave": ["Chave da Cripta da Família", "Abre uma porta que já ninguém encontra."],
	"sino": ["Badalo do Sino Rachado", "Caiu do sino do Arauto na noite em que morreu pela primeira vez."],
}
const PILES := {"bone": "Ossos Ancestrais", "ink": "Tinteiros de Sangue Negro", "ash": "Cinzas do Purgatório"}  # o que a Pena de Abutre (#239) arrisca
const WAVES := 3
const REVIVE_T := 2.5
const CRIT := 0.12
const CRIT_MULT := 1.8
const ARENA_R := 620.0
const SFX := {
	"hit": preload("res://sfx/hit.wav"), "crit": preload("res://sfx/crit.wav"), "hurt": preload("res://sfx/hurt.wav"),
	"bell": preload("res://sfx/bell.wav"), "roar": preload("res://sfx/roar.wav"), "chest": preload("res://sfx/chest.wav"),
	"levelup": preload("res://sfx/levelup.wav"), "potion": preload("res://sfx/potion.wav"), "victory": preload("res://sfx/victory.wav"),
	"swing": preload("res://sfx/swing.wav"), "swing_heavy": preload("res://sfx/swing_heavy.wav"), "cast": preload("res://sfx/cast.wav"),
	"dash": preload("res://sfx/dash.wav"), "chime": preload("res://sfx/chime.wav"), "die": preload("res://sfx/die.wav"), "creak": preload("res://sfx/creak.wav"),
	"coin": preload("res://sfx/coin.wav"), "flask": preload("res://sfx/flask.wav"), "relic": preload("res://sfx/relic.wav"),  # saque a cair (#288)
}
## Música: faixas em laço (o laço liga-se em código, nunca pelo .import) e o volume de cada uma, em dB.
const MUSIC := {
	"title": preload("res://art/music/title.ogg"), "world": preload("res://art/music/world.ogg"), "crypt": preload("res://art/music/crypt.ogg"),
	"cortejo": preload("res://art/music/cortejo.ogg"), "boss": preload("res://art/music/boss.ogg"),
}
const MUSIC_DB := {"title": -8.0, "world": -8.0, "crypt": -8.0, "cortejo": -6.0, "boss": -4.0}
const XP := {"skeleton": 5, "specter": 4, "colossus": 60, "herald": 150, "enforcado": 5, "afogado": 5, "queimado": 5, "estandarte": 5}  # as peles (0.4.7) só para o Bestiário e a gravação: o abate paga pelo kind
const WEAR := ["enforcado", "afogado", "queimado", "estandarte"]  # as peles do Cortejo
const NO_BOSS_DROP := ["Coveiro", "Gigante Errante", "Reforço", "Sentinela"]  # colossos sem o Frasco de Alma garantido dos chefes (o Reforço dos Sineiros, #206; a Sentinela dos Sepulcros, uma por profundidade)
## Equipamento (0.4.8): o que cada morte larga, [hipótese, comum, mágica] (o resto é rara). Os chefes com nome largam sempre
## uma rara e, GEAR_UNIQUE das vezes, um único que o grupo ainda não tenha.
const GEAR_DROP := {"normal": [0.025, 0.7, 0.25], "elite": [0.3, 0.25, 0.55], "boss": [0.5, 0.0, 0.6], "named": [1.0, 0.0, 0.0]}
const GEAR_UNIQUE := 0.25  # ~30 min até ao 1.º único com 8 chefes com nome por hora (com 0,15 eram ~50 min, e 27% das horas sem nenhum)
const GEAR_FLOOR := 10  # peças à espera no chão: as de mais vão logo para o herói mais perto (cada uma custa um pouco por frame, aqui e na rede)
## Jogo gravado (no Android fica nos dados da app e passa de versão para versão).
const SAVE_PATH := "user://save.json"
const SETTINGS_PATH := "user://settings.cfg"
## Configurações: ficam fora do jogo gravado (um Novo jogo não as apaga). Escolhas = índice da lista no menu.
const SETTINGS := {
	"master": 1.0, "music": 0.8, "sfx": 1.0,
	"fps": 1, "res": 0, "effects": 2, "show_fps": false,
	"shake": true, "flash": true, "numbers": true,
	"ui": 0, "opacity": 0,
	"text": 1,  # tamanho do texto (#99): 80%, 100%, 115% ou 130%
	"vibe": 2,  # vibração: 0 desligada, 1 fraca, 2 média, 3 forte
	"thermal": true,  # proteção térmica: baixa os efeitos e os FPS sozinha quando o telemóvel aquece
	"lang": 0,  # 0 = português de Portugal, 1 = inglês britânico (sem ficheiro: o idioma do telemóvel)
	"intro_seen": false,  # a intro aparece sozinha só da primeira vez (depois, no Sobre)
	"hold_hint": false,  # o aviso "segura um botão para saber o que faz" já apareceu
	"lefty": false,  # canhoto: botões de habilidade à esquerda e joystick à direita
	"joy_fixed": false,  # joystick fixo no canto (de origem aparece onde o polegar toca)
	"joy_at": Vector2.ZERO,  # ou fixo onde o jogador o pôs (#271): fração da margem segura (no canhoto, espelhada); ZERO = no canto
	"deadzone": 1,
	"colorblind": 0,  # 0 desligado, 1 protanopia, 2 deuteranopia, 3 tritanopia
	"comfort": 0,  # conforto ocular: 0 desligado, 1 suave, 2 forte
	"minimap": true,
	"auto_attack": false,  # um polegar: o 1.º golpe sai sozinho com um inimigo ao alcance
	"boss_aim": false,  # a mira automática prefere os chefes
	"potion_ui": 2,  # botões de poção a 100%, 125% ou 150% (de origem os maiores: acertar no meio da luta)
	"hud_fade": false,  # longe de combate, o HUD fica quase transparente
	"loot_common": 0,  # filtro do saque (#76) dos ossos e das esferas: 0 nome, luz e som · 1 luz e som · 2 só o ícone
	"loot_rare": 0,  # e o mesmo para os tinteiros e as cinzas (os frascos, os reagentes e as relíquias mostram sempre tudo)
	"density": 2,  # monstros no mundo aberto (#284): 0 baixa, 1 média, 2 alta (a de sempre)
	"fx_alpha": 0,  # opacidade dos efeitos (#86): 100%, 70% ou 40% (os números de dano e os avisos dos chefes ficam inteiros)
}
const CHOICES := {"vibe": 4, "fps": 3, "res": 2, "effects": 3, "ui": 4, "opacity": 3, "text": 4, "fx_alpha": 3, "lang": 2, "deadzone": 3, "colorblind": 4, "comfort": 3, "potion_ui": 3, "loot_common": 3, "loot_rare": 3, "density": 3}  # quantas escolhas tem cada uma
const DEADZONES := [0.15, 0.25, 0.4]  # zona morta do stick e dos gatilhos (comandos com "drift" precisam da maior)
const I18n := preload("res://i18n.gd")
const FPS_CAPS := [30, 60, 0]  # 0 = o que o ecrã der
const OPACITY := [1.0, 0.75, 0.5]
const TEXT := [0.8, 1.0, 1.15, 1.3]  # tamanho do texto de cada escolha (#99)
const FX_ALPHA := [1.0, 0.7, 0.4]  # opacidade dos efeitos de cada escolha (#86)
const VIBE := [0.0, 0.5, 1.0, 1.6]  # força da vibração de cada escolha
const DUMMY_AT := Vector2(260, 140)  # boneco de treino (#287), ao lado do monumento
const BLOOD_R := 30.0  # Sangue no Solo (#23): raio de cada poça
const CORPSE_R := 90.0  # Espasmo Cadavérico (#115): raio da explosão de um cadáver
const CORPSE_T := 6.0  # quanto tempo fica no chão antes de rebentar sozinho
const CORPSE_COLORS := [Color(0.9, 0.86, 0.75), Color(0.45, 0.85, 0.25), Color(0.62, 0.36, 0.85), Color(0.8, 0.8, 0.75)]  # osso, podridão, necrose, calcificação
const EFFECTS := [0.35, 0.65, 1.0]  # parte das partículas que se desenha
const DENSITY := [14, 24, 35]  # máximo de monstros no mundo aberto de cada escolha (#284); o Cortejo e a cripta não mudam
const PROP_CAP := 720  # adereços de um mapa
const MAP_SLICE_US := 3000  # em jogo, o plano do mapa trabalha 3 ms por frame
const FLOOR_STEP := 256.0  # o chão redesenha-se quando a câmara se afasta tanto disto (a cada ~1,1 s a andar)
const WILD_STEP := 800.0  # de quantos em quantos px da praça os monstros sobem de nível
const WILD_FAR := 2400.0  # mais longe do que isto de todos os heróis, os soltos desaparecem (os do arranque nascem a 2012 no máximo)
const CAMPS_PER := 2  # acampamentos por zona: 8 no mapa
const CAMP_PACK := 6  # mortos de cada bando, além do elite com nome
const CAMP_WAKE := 1200.0  # o bando nasce a esta distância de um herói (fora do ecrã: 800 de meia largura a 20:9 + 170 do bando + o que se anda entre duas vistas, com esquiva)
## Comando com esquema Xbox (A em baixo, B à direita, X à esquerda, Y em cima), como o GameSir G8 Plus.
## Sem teclado: o jogo é para telemóvel (comando ou ecrã tátil).
const PAD_BUTTONS := {
	"move_left": [JOY_BUTTON_DPAD_LEFT], "move_right": [JOY_BUTTON_DPAD_RIGHT],
	"move_up": [JOY_BUTTON_DPAD_UP], "move_down": [JOY_BUTTON_DPAD_DOWN],
	"skill_1": [JOY_BUTTON_A], "skill_2": [JOY_BUTTON_X], "skill_3": [JOY_BUTTON_Y],
	"interact": [JOY_BUTTON_B], "menu": [JOY_BUTTON_START], "tree": [JOY_BUTTON_BACK], "stance": [JOY_BUTTON_RIGHT_STICK],
	"arsenal": [JOY_BUTTON_LEFT_STICK],
	"potion_hp": [JOY_BUTTON_LEFT_SHOULDER], "potion_mp": [JOY_BUTTON_RIGHT_SHOULDER],
}
const PAD_AXES := {
	"move_left": [JOY_AXIS_LEFT_X, -1.0], "move_right": [JOY_AXIS_LEFT_X, 1.0],
	"move_up": [JOY_AXIS_LEFT_Y, -1.0], "move_down": [JOY_AXIS_LEFT_Y, 1.0],
	"skill_1": [JOY_AXIS_TRIGGER_RIGHT, 1.0], "skill_2": [JOY_AXIS_TRIGGER_LEFT, 1.0],  # gatilhos RT/LT (Kishi, Backbone, DualSense)
}

## Chão: tiles isométricos 32-bit da folha SC-W1. LV = altura do vértice esquerdo do losango na textura;
## HH = meia altura da face de cima. Medido nas texturas cortadas (256 px de largura).
const TILES := {
	"cobble": preload("res://art/tiles/cobble.png"), "cobble_moss": preload("res://art/tiles/cobble_moss.png"),
	"grass": preload("res://art/tiles/grass.png"), "mud": preload("res://art/tiles/mud.png"),
	"slab": preload("res://art/tiles/slab.png"), "slab_roots": preload("res://art/tiles/slab_roots.png"),
	"bones": preload("res://art/tiles/bones.png"), "water": preload("res://art/tiles/water.png"),
	"sep_wet": preload("res://art/tiles/sep_wet.png"), "sep_flood": preload("res://art/tiles/sep_flood.png"),
	"sep_earth": preload("res://art/tiles/sep_earth.png"), "sep_thorn": preload("res://art/tiles/sep_thorn.png"),
	"sep_ember": preload("res://art/tiles/sep_ember.png"), "sep_ash": preload("res://art/tiles/sep_ash.png"),
	"sep_marble": preload("res://art/tiles/sep_marble.png"), "sep_bones": preload("res://art/tiles/sep_bones.png"),
}
const TILE_LV := {"cobble": 90.0, "cobble_moss": 90.0, "grass": 96.0, "mud": 90.0, "slab": 91.0, "slab_roots": 92.0, "bones": 90.0, "water": 93.0,
	"sep_wet": 90.0, "sep_flood": 90.0, "sep_earth": 92.0, "sep_thorn": 99.0, "sep_ember": 93.0, "sep_ash": 92.0, "sep_marble": 90.0, "sep_bones": 93.0}
const TILE_HH := 90.5
const TILE_SCALE := 0.55
## Praça central 32-bit (PX-33, redesenhada do MAP-01); o poço do meio fica debaixo do monumento.
const HUB := preload("res://art/bg/hub.webp")
const HUB_SPOT := Vector2(1376, 754)
const MON := preload("res://art/props/monument.png")
const MON_ON := preload("res://art/props/monument_on.png")
## Cripta dos Condenados: o mapa PX-34 (o MAP-02 em 32-bit, igual de sítio) fica numa zona à parte, por baixo do cemitério.
## Coordenadas medidas na imagem (2752x1536): o chão caminhável, a entrada, a porta do fundo e o Carcereiro.
const CRYPT := preload("res://art/bg/crypt.webp")
const CRYPT_ORIGIN := Vector2(-1376, 3400)
const CRYPT_FLOOR := [Vector2(1950, 520), Vector2(2230, 560), Vector2(2150, 830), Vector2(1750, 1000), Vector2(1450, 1180),
	Vector2(1150, 1250), Vector2(800, 1430), Vector2(300, 1450), Vector2(150, 1250), Vector2(500, 1120), Vector2(850, 940),
	Vector2(1350, 690), Vector2(1650, 570), Vector2(1800, 510)]
const CRYPT_IN := Vector2(450, 1300)
const CRYPT_OUT := Vector2(2040, 540)
const CRYPT_BOSS := Vector2(1880, 660)
const CRYPT_GLOWS := [Vector2(470, 960), Vector2(1270, 560), Vector2(1770, 400), Vector2(2290, 640)]
const CRYPT_DOOR := Vector2(-700, 900)  # escadas para a cripta, no cemitério
const SHRINE := Vector2(330, 120)  # o altar do cemitério, onde se oferece o Coração de Titã (#70)
const CRYPT_DOOR_TEX := preload("res://art/props/crypt_door.png")
## Salas da cripta (S6): o caminho do corredor, da entrada ao Carcereiro (pontos no chão, com folga de 80x60 px), e cada
## regra [nome, o que muda]. A 1.ª descida é a de sempre; as seguintes sorteiam outra, nunca a da última.
const CRYPT_PATH := [Vector2(650, 1300), Vector2(950, 1120), Vector2(1250, 960), Vector2(1500, 840), Vector2(1720, 720)]
const CRYPT_RULES := {
	"": ["Cripta dos Condenados", "Derrota o guardião e abre o relicário."],
	"cegas": ["Catacumbas Cegas", "Às escuras: só vês o que a tua tocha ilumina."],
	"silencio": ["Sanctum do Silêncio", "As habilidades com custo acordam os mortos à volta."],
	"miasma": ["Abismo do Miasma", "O ar envenena: mata elites para respirar."],
	"submersa": ["Cripta Submersa", "Bile no chão e marés de almas."],
	"chamas": ["Necrópole em Chamas Negras", "A alma arde: as habilidades com custo só funcionam nos abrigos de pedra."],
	"enxofre": ["Minas de Enxofre", "Os golpes em área rebentam as pedras de enxofre, em cadeia."],
	"forja": ["Forja das Almas Escravas", "Martelos gigantes esmagam o chão: sai do círculo vermelho."],
	"moinho": ["Moinho de Carne", "As passadeiras levam tudo para as serras."],
	"jardins": ["Jardins de Pedras Funerárias", "As gárgulas só se mexem quando lhes viras as costas."],
}
const CRYPT_TINT := {"": Color(0.74, 0.8, 0.78), "cegas": Color(0.86, 0.78, 0.62), "silencio": Color(0.7, 0.76, 0.88),
	"miasma": Color(0.66, 0.84, 0.58), "submersa": Color(0.6, 0.76, 0.84), "chamas": Color(0.78, 0.66, 0.86),
	"enxofre": Color(0.86, 0.82, 0.6), "forja": Color(0.88, 0.7, 0.6), "moinho": Color(0.84, 0.66, 0.66), "jardins": Color(0.72, 0.78, 0.72)}  # a cor de cada sala (nas Cegas, a da tocha)
const CRYPT_BOSSES := ["", "suturado", "monge", "carrasco"]  # S7: o chefe de cada descida, à vez ("" é o Carcereiro; bosses.gd)
const TORCH_R := 260.0  # Catacumbas Cegas (#26): a luz da tocha de cada herói
const TIDE_EVERY := 8.0  # Lago das Lamentações (#30): uma maré de almas a cada 8 s, que dura 2 s
const TIDE_T := 2.0
const CRYPT_DIR := Vector2(0.879, -0.476)  # o rumo do corredor, da entrada para o Carcereiro
## Armadilhas da cripta (B6): 6 pontos a espaços iguais ao longo do CRYPT_PATH (os martelos da Forja e as gárgulas dos
## Jardins), todos com mais de 170 px de chão à volta; e a forma de cada pedra de enxofre (28 px)
const CRYPT_SPOTS := [Vector2(740, 1250), Vector2(910, 1140), Vector2(1090, 1050), Vector2(1270, 950), Vector2(1450, 860), Vector2(1630, 770)]
const ROCK := [Vector2(-14, 3), Vector2(-9, -8), Vector2(1, -13), Vector2(12, -7), Vector2(14, 4), Vector2(4, 11), Vector2(-8, 10)]
## Adereços: textura, altura no ecrã, peso no sorteio. Os da 0.4.7 têm peso 0: entram nos Sepulcros (SEPS) e nas zonas que os pedem em "new".
const PROPS := {
	"grave_broken": [preload("res://art/props/grave_broken.png"), 72.0, 14],
	"graves3": [preload("res://art/props/graves3.png"), 62.0, 8],
	"tomb": [preload("res://art/tomb.png"), 66.0, 10],
	"fence": [preload("res://art/props/fence.png"), 70.0, 5],
	"fence_gate": [preload("res://art/props/fence_gate.png"), 76.0, 3],
	"coffin": [preload("res://art/props/coffin.png"), 46.0, 4],
	"coffin_open": [preload("res://art/props/coffin_open.png"), 46.0, 3],
	"candles": [preload("res://art/props/candles.png"), 52.0, 4],
	"skulls": [preload("res://art/props/skulls.png"), 46.0, 4],
	"roots": [preload("res://art/props/roots.png"), 56.0, 5],
	"bush": [preload("res://art/props/bush.png"), 62.0, 6],
	"statue": [preload("res://art/props/statue.png"), 112.0, 3],
	"lantern": [preload("res://art/props/lantern.png"), 122.0, 3],
	"tree": [preload("res://art/tree.png"), 150.0, 8],
	"cage_tree": [preload("res://art/props/cage_tree.png"), 230.0, 2],
	"crypt": [preload("res://art/crypt.png"), 140.0, 2],
	"chapel": [preload("res://art/props/chapel.png"), 230.0, 1],
	"gatehouse": [preload("res://art/props/gatehouse.png"), 220.0, 0],
	"rubble": [preload("res://art/props/rubble.png"), 150.0, 1],
	"cliff": [preload("res://art/props/cliff.png"), 160.0, 1],
	"shrine_off": [preload("res://art/props/shrine.png"), 90.0, 0],
	"waypoint_on": [preload("res://art/props/waypoint_on.png"), 110.0, 0],
	"wall_jardim": [preload("res://art/props/wall_jardim.png"), 170.0, 0],
	"mod_ossos": [preload("res://art/props/mod_ossos.png"), 170.0, 0],
	"mod_ossos_nicho": [preload("res://art/props/mod_ossos_nicho.png"), 170.0, 0],
	"mod_cisterna": [preload("res://art/props/mod_cisterna.png"), 170.0, 0],
	"mod_cisterna_grade": [preload("res://art/props/mod_cisterna_grade.png"), 170.0, 0],
	"mod_forno": [preload("res://art/props/mod_forno.png"), 170.0, 0],
	"mod_forno_boca": [preload("res://art/props/mod_forno_boca.png"), 170.0, 0],
	"mod_reis": [preload("res://art/props/mod_reis.png"), 170.0, 0],
	"mod_reis_nicho": [preload("res://art/props/mod_reis_nicho.png"), 170.0, 0],
	"sep_stairs": [preload("res://art/props/sep_stairs.png"), 170.0, 0],
	"sep_bonepile": [preload("res://art/props/sep_bonepile.png"), 60.0, 0],
	"sep_pipe": [preload("res://art/props/sep_pipe.png"), 90.0, 0],
	"sep_thorns": [preload("res://art/props/sep_thorns.png"), 70.0, 0],
	"sep_sapling": [preload("res://art/props/sep_sapling.png"), 110.0, 0],
	"sep_brazier": [preload("res://art/props/sep_brazier.png"), 70.0, 0],
	"sep_coal": [preload("res://art/props/sep_coal.png"), 46.0, 0],
	"sep_sarcophagus": [preload("res://art/props/sep_sarcophagus.png"), 64.0, 0],
	"sep_banner": [preload("res://art/props/sep_banner.png"), 130.0, 0],
}

## O mapa (0.4.5): quatro zonas à volta da praça. Peso de cada adereço na zona = PROPS[n][2] * props.get(n, 1). "new" (0.4.7): adereços que trocam REGION_NEW dos soltos da zona.
const REGION_NEW := 0.14
const GATE := Vector2(0, 2050)  # o Portão dos Reis, ao fundo da estrada: fechado até aos Sepulcros (0.4.6). Mais a sul a câmara já não desce e o herói fica atrás dos orbes
const SEP_CELL := Vector2(281.6, 199.1)  # uma casa: 2 colunas x 4 filas de losangos (TILE_SCALE)
const SEP_SIDE := 19  # casas de lado: 3 lotes de 5, 2 intervalos e 1 de margem de cada lado
const SEP_ORIGIN := Vector2(-2675.2, 5800)  # centrado em x; a cripta acaba em y = 4936
const SEP_BOUNDS := Rect2(-3475.2, 5400, 6950.4, 4582.9)  # as casas + 800 aos lados e 400 em cima e em baixo: junto a uma parede a câmara ainda anda (o comentário de GATE)
const SEP_LINK := 255  # na grelha: 0 parede, 255 corredor, N a sala N - 1
const SEP_CAP := 30  # uma sala só nasce se os vivos e ela couberem aqui, e sinos e invocações param (a separação custa o quadrado, maus_cap)
const SEP_DOOR_R := 110.0
const SEP_WALL := 150.0  # a largura de uma peça de parede (mod_*, a 170 de altura)
const SEP_RUIN := 188.0  # a da ruína do Jardim (wall_jardim)
const SEP_FIXED := ["wall_jardim", "sep_pipe"]  # peças com direção: espelhada ao calhas, uma parede diagonal fazia um V; e todas do mesmo tamanho, para colarem
const REGION_SPOTS := [Vector2(0, -1900), Vector2(2350, -150), Vector2(-2350, -150)]  # norte, este, oeste; o Campo fica sempre a sul
const REGION_ORDER := [["bosque", "pantano", "ossario"], ["ossario", "bosque", "pantano"], ["pantano", "ossario", "bosque"], ["bosque", "ossario", "pantano"], ["ossario", "pantano", "bosque"], ["pantano", "bosque", "ossario"]]  # (c - 1) % 6: a zona do norte, a mais perto do monumento, muda em todos os passos
const REGIONS := {
	"praca": {"name": "", "spec": 0.25, "tile": Color(0.6, 0.66, 0.62), "prop": Color(0.8, 0.88, 0.84), "paint": Color.WHITE, "skin": "", "map": Color(0.32, 0.32, 0.28), "props": {}},
	"bosque": {"name": "Bosque dos Enforcados", "camp": "O Enforcado", "spec": 0.55, "tile": Color(0.46, 0.6, 0.46), "prop": Color(0.7, 0.88, 0.72), "paint": Color(0.65, 1.0, 0.65), "skin": "enforcado", "map": Color(0.2, 0.42, 0.22),
		"props": {"tree": 5, "cage_tree": 5, "bush": 3, "roots": 3, "statue": 0, "crypt": 0, "chapel": 0, "rubble": 0, "cliff": 0}, "new": ["sep_thorns", "sep_sapling"],
		"stamp": [["cage_tree", Vector2(-170, -30)], ["cage_tree", Vector2(170, -50)], ["cage_tree", Vector2(0, -190)], ["shrine_off", Vector2(0, -60)], ["candles", Vector2(-80, 70)], ["candles", Vector2(80, 70)]]},
	"pantano": {"name": "Pântano dos Afogados", "camp": "A Afogada", "spec": 0.4, "tile": Color(0.46, 0.6, 0.62), "prop": Color(0.68, 0.86, 0.86), "paint": Color(0.6, 0.95, 1.0), "skin": "afogado", "map": Color(0.16, 0.36, 0.42),
		"props": {"lantern": 3, "candles": 3, "roots": 3, "coffin": 2, "coffin_open": 2, "fence": 0, "fence_gate": 0, "statue": 0, "crypt": 0, "rubble": 0, "cliff": 0}, "new": ["sep_pipe"],
		"stamp": [["chapel", Vector2(0, -200)], ["lantern", Vector2(-180, -30)], ["lantern", Vector2(180, -30)], ["shrine_off", Vector2(0, -60)], ["coffin_open", Vector2(-110, 90)]]},
	"ossario": {"name": "Grande Ossário", "camp": "O Rei dos Ossos", "spec": 0.1, "tile": Color(0.72, 0.68, 0.6), "prop": Color(0.95, 0.9, 0.8), "paint": Color(1.0, 0.9, 0.7), "skin": "", "map": Color(0.62, 0.56, 0.44),
		"props": {"skulls": 6, "rubble": 8, "cliff": 6, "coffin_open": 3, "crypt": 2, "tree": 0, "cage_tree": 0, "bush": 0, "roots": 0, "lantern": 0}, "new": ["sep_bonepile"],
		"stamp": [["cliff", Vector2(0, -210)], ["rubble", Vector2(-200, -60)], ["rubble", Vector2(200, -60)], ["shrine_off", Vector2(0, -60)], ["skulls", Vector2(-90, 90)], ["skulls", Vector2(90, 90)]]},
	"campo": {"name": "Campo do Portão dos Reis", "camp": "O Porta-Estandarte", "spec": 0.25, "tile": Color(0.8, 0.68, 0.44), "prop": Color(0.95, 0.84, 0.62), "paint": Color(1.0, 0.82, 0.55), "skin": "estandarte", "map": Color(0.42, 0.38, 0.24),
		"props": {"graves3": 2, "tomb": 2, "fence": 4, "fence_gate": 4, "statue": 4, "tree": 0, "bush": 0, "cage_tree": 0, "rubble": 0, "cliff": 0}, "new": ["sep_banner", "sep_sarcophagus"],
		"stamp": [["statue", Vector2(-170, -70)], ["statue", Vector2(170, -70)], ["fence_gate", Vector2(0, -180)], ["shrine_off", Vector2(0, -60)], ["fence", Vector2(-100, -175)], ["fence", Vector2(100, -175)]]},
}

## Os Sepulcros (0.4.6). O aspeto e a forma mudam a cada profundidade (sep_kind); as regras e o guardião, a cada 5, e depois outra vez, mais fortes (sep_block). Cada um com a sua arte (0.4.7): as tintas só escurecem, quase neutras (chão e global >= 0,85, as tintas das regiões, 0,46, tocavam no vazio; menos no Forno e no Jardim, para os veios acesos e as raízes brancas não lutarem com os avisos).
const SEPS := [
	{"name": "Ossário Fundo", "tile": Color(0.9, 0.88, 0.85), "prop": Color(0.92, 0.9, 0.87), "paint": Color(1.0, 0.9, 0.7), "skin": "", "tint": Color(0.92, 0.91, 0.89), "spec": 0.1, "floor": ["slab", "sep_bones"], "tints": [Color(0.7, 0.68, 0.66), Color(0.58, 0.56, 0.53)], "look": "ossos", "pairs": [["sep_bonepile", 1400, 40]],
		"north": ["mod_ossos"], "feature": "mod_ossos_nicho", "side": ["sep_bonepile", "grave_broken"], "south": ["sep_bonepile", "graves3", "coffin"], "wide": 2, "loop": false, "rules": ["jardins", "silencio"], "guard": "suturado", "guard_rule": ""},
	{"name": "Cisterna Alagada", "tile": Color(0.9, 0.92, 0.94), "prop": Color(0.9, 0.92, 0.94), "paint": Color(0.6, 0.95, 1.0), "skin": "afogado", "tint": Color(0.9, 0.92, 0.95), "spec": 0.4, "floor": ["sep_wet", "sep_flood"], "tints": [Color(0.94, 0.97, 1.0), Color(1.0, 1.0, 1.0)], "look": "cisterna", "pairs": [["sep_pipe", 0, 34]],
		"north": ["mod_cisterna"], "feature": "mod_cisterna_grade", "side": ["roots", "coffin"], "south": ["roots", "coffin"], "wide": 1, "loop": false, "rules": ["submersa", "cegas"], "guard": "monge", "guard_rule": "silencio"},
	{"name": "Jardim Morto", "tile": Color(0.8, 0.82, 0.78), "prop": Color(0.9, 0.92, 0.88), "paint": Color(0.65, 1.0, 0.65), "skin": "enforcado", "tint": Color(0.9, 0.93, 0.89), "spec": 0.55, "floor": ["mud", "sep_earth", "sep_thorn"], "tints": [Color(0.8, 0.82, 0.78), Color(0.8, 0.82, 0.78), Color(0.8, 0.82, 0.78)], "look": "jardim", "pairs": [],
		"north": ["wall_jardim", "wall_jardim", "tree"], "feature": "", "side": ["sep_thorns", "sep_sapling", "roots"], "south": ["sep_thorns", "sep_sapling", "bush"], "wide": 2, "loop": false, "rules": ["miasma", "jardins"], "guard": "carrasco", "guard_rule": "miasma"},
	{"name": "Forno Velho", "tile": Color(0.68, 0.64, 0.62), "prop": Color(0.92, 0.88, 0.85), "paint": Color(1.0, 0.7, 0.55), "skin": "queimado", "tint": Color(0.94, 0.9, 0.87), "spec": 0.15, "floor": ["slab", "sep_ash", "sep_ember"], "tints": [Color(0.8, 0.71, 0.65), Color(1.0, 0.95, 0.9), Color(0.92, 0.84, 0.78)], "look": "forno", "pairs": [["sep_brazier", 1400, 42], ["sep_coal", 2200, 36]],
		"north": ["mod_forno"], "feature": "mod_forno_boca", "side": ["sep_brazier", "sep_coal", "grave_broken"], "south": ["sep_coal", "sep_brazier", "coffin"], "wide": 1, "loop": true, "rules": ["forja", "enxofre"], "guard": "guardiao", "guard_rule": "forja"},
	{"name": "Túmulo dos Reis", "tile": Color(0.92, 0.91, 0.88), "prop": Color(0.94, 0.93, 0.9), "paint": Color(1.0, 0.82, 0.55), "skin": "estandarte", "tint": Color(0.94, 0.93, 0.9), "spec": 0.25, "floor": ["slab", "sep_marble"], "tints": [Color(0.74, 0.74, 0.82), Color(1.0, 1.0, 1.0)], "look": "tumulo", "pairs": [["sep_banner", 1140, 54], ["sep_sarcophagus", 2200, 86]],
		"north": ["mod_reis"], "feature": "mod_reis_nicho", "side": ["sep_sarcophagus", "sep_banner", "statue"], "south": ["sep_sarcophagus", "sep_banner", "graves3"], "wide": 2, "loop": false, "rules": ["cegas", "silencio", "miasma", "submersa", "enxofre", "forja", "jardins"], "guard": "arauto", "guard_rule": ""},
]

## Árvore dos Condenados: raízes que crescem da "raiz". pos = lugar no ecrã da árvore (640x380).
const PASSIVES := {
	"raiz": {"name": "Raiz", "desc": "Onde todos os condenados começam.", "req": "", "pos": Vector2(320, 340), "stats": {}},
	"densos": {"name": "Ossos Densos", "desc": "+30 vida máxima", "req": "raiz", "pos": Vector2(170, 280), "stats": {"hp_max": 30.0}},
	"tutano": {"name": "Tutano Faminto", "desc": "+3% do dano converte-se em vida", "req": "densos", "pos": Vector2(90, 180), "stats": {"leech": 0.03}},
	"medula": {"name": "Medula Sacrificial", "desc": "20% do dano recebido converte-se em barreira de ossos", "req": "densos", "pos": Vector2(70, 300), "stats": {"bone_barrier": 0.2}},
	"ossada": {"name": "Ossada Pesada", "desc": "+25% dano", "req": "tutano", "pos": Vector2(110, 60), "stats": {"dmg": 0.25}},
	"veias": {"name": "Veias Abertas", "desc": "+30% sangramento", "req": "raiz", "pos": Vector2(320, 240), "stats": {"bleed": 0.3}},
	"hemorragia": {"name": "Hemorragia", "desc": "+40% sangramento", "req": "veias", "pos": Vector2(320, 150), "stats": {"bleed": 0.4}},
	"bleedbone": {"name": "Sangue e Osso", "desc": "CHAVE: +80% sangramento e +15% dano, mas -30% dano de feitiços", "req": "hemorragia", "pos": Vector2(320, 50), "stats": {"bleed": 0.8, "dmg": 0.15, "spell": -0.3}},
	"hemofilia": {"name": "Hemofilia Espiritual", "desc": "Críticos em quem sangra deixam cair uma esfera que cura 5% da vida", "req": "hemorragia", "pos": Vector2(425, 120), "stats": {"hemo": 1.0}},
	"mente": {"name": "Mente Sepulcral", "desc": "+30 mana máxima", "req": "raiz", "pos": Vector2(470, 280), "stats": {"mana_max": 30.0}},
	"faminta": {"name": "Alma Faminta", "desc": "+25% dano de feitiços", "req": "mente", "pos": Vector2(550, 180), "stats": {"spell": 0.25}},
	"eco": {"name": "Eco Espectral", "desc": "+4 mana por segundo", "req": "faminta", "pos": Vector2(530, 60), "stats": {"regen": 4.0}},
	"coveiro": {"name": "Passo do Coveiro", "desc": "+12% velocidade", "req": "veias", "pos": Vector2(215, 170), "stats": {"speed": 0.12}},
	"dentes": {"name": "Dentes de Sepultura", "desc": "A esquiva deixa dentes no chão que abrandam os monstros em 40%", "req": "coveiro", "pos": Vector2(232, 96), "stats": {"teeth": 1.0}},
	"sentinelas": {"name": "Sentinelas Tumulares", "desc": "A esquiva finca uma lápide onde estavas (até 2) que dispara estilhaços de osso ao monstro mais perto durante 10 s", "req": "dentes", "pos": Vector2(215, 30), "stats": {"sentinel": 1.0}},
	"grito": {"name": "Grito de Guerra Fúnebre", "desc": "Ira: os mortos menores por perto entram em pânico e atacam-se uns aos outros durante 4 s (recarga 12 s)", "req": "medula", "pos": Vector2(165, 360), "stats": {"grito": 1.0}},
	"espasmo": {"name": "Espasmo Cadavérico", "desc": "Os mortos rebentam em 6 s ou ao teu golpe, com a Podridão, Necrose ou Calcificação", "req": "mente", "pos": Vector2(560, 330), "stats": {"corpse": 1.0}},
	"pacto": {"name": "Pacto de Carne e Ferro", "desc": "CHAVE: sem Esquiva Espectral, mas -30% dano recebido e cada golpe que levas faz rebentar espinhos de osso à tua volta", "req": "medula", "pos": Vector2(-90, 360), "stats": {"pacto": 1.0}},
	"vermes": {"name": "Comunhão dos Vermes-Deuses", "desc": "CHAVE: -50% vida máxima, mas os lacaios devoram os mortos recentes e atacam 3× mais depressa", "req": "espasmo", "pos": Vector2(720, 360), "stats": {"vermes": 1.0, "hp_mul": -0.5}},
	"canibal": {"name": "Canibalismo Espiritual", "desc": "CHAVE: cada lacaio que se desfaz cura 10% da vida e dá +8% dano (até 5), mas os lacaios duram só 4 s", "req": "tutano", "pos": Vector2(-90, 140), "stats": {"canibal": 1.0}},
	"semalma": {"name": "Sem Alma Própria", "desc": "CHAVE: a mana não se regenera: só vem das esferas de alma dos abates (30% cada); +40% dano de feitiços", "req": "faminta", "pos": Vector2(720, 200), "stats": {"semalma": 1.0, "spell": 0.4}},
	"frio": {"name": "Frio do Purgatório", "desc": "CHAVE: os golpes calcificam em vez de fazerem sangrar e as estátuas que morrem rebentam em lascas de osso, mas -20% dano", "req": "sentinelas", "pos": Vector2(215, -110), "stats": {"frio": 1.0, "calcify": 1.0, "dmg": -0.2}},
	"densidade_ossea": {"name": "Densidade Osteológica", "desc": "-3% dano recebido por cada lacaio teu de pé (até 4)", "req": "densos", "pos": Vector2(300, 430), "stats": {"ossea": 1.0}},
	"martir_aco": {"name": "Mártir do Aço Fúnebre", "desc": "15% do dano de sangramento que causas converte-se em barreira de ossos", "req": "veias", "pos": Vector2(410, 210), "stats": {"aco": 1.0}},
	"ectoplasma": {"name": "Hemorragia Ectoplasmática", "desc": "Críticos em quem sangra libertam ectoplasma: os lacaios a 4 m duram +3 s", "req": "hemofilia", "pos": Vector2(440, -50), "stats": {"ecto": 1.0}},
	"ecos": {"name": "Ecos do Último Suspiro", "desc": "A barreira de ossos a quebrar (com 10% da vida ou mais) petrifica os mortos menores a 5 m durante 1,5 s; os chefes só abrandam", "req": "grito", "pos": Vector2(40, 420), "stats": {"ecos": 1.0}},
	"simbioticas": {"name": "Almas Simbióticas", "desc": "Um lacaio teu desfaz-se para absorver o golpe que te ia matar (recarga 12 s)", "req": "espasmo", "pos": Vector2(580, 435), "stats": {"simb": 1.0}},
	"presenca": {"name": "Presença Cadavérica Intimidatória", "desc": "Os mortos menores a 3 m falham 30% dos ataques", "req": "grito", "pos": Vector2(165, 445), "stats": {"presenca": 1.0}},
	"sede": {"name": "Sede Ancestral", "desc": "Foice e machado roubam 1,5% da vida máxima do alvo por segundo durante 4 s (a cura por alvo até 3% da tua)", "req": "tutano", "pos": Vector2(-10, 50), "stats": {"sede": 1.0}},
	"sutura": {"name": "Sutura Biológica Instantânea", "desc": "A cura que passa da vida máxima converte-se em barreira de ossos (até 25% da vida)", "req": "medula", "pos": Vector2(-60, 250), "stats": {"sutura": 1.0}},
	"fragmentada": {"name": "Mente Fragmentada", "desc": "CHAVE: sem mana: as habilidades com custo bebem da poção de alma (60 = 1 carga, não se bebe) e fazem +40% dano; exclui Sem Alma Própria", "req": "faminta", "pos": Vector2(635, 95), "stats": {"fragmentada": 1.0}},
	"imolacao": {"name": "Imolação Funerária", "desc": "CHAVE: 40% do dano que levas arde como corrupção em vez de vida, mas na Sobrecarga de Alma perdes 6% da vida por segundo", "req": "eco", "pos": Vector2(660, -50), "stats": {"imolacao": 1.0}},
	"sangue": {"name": "Sangue Negro Impenetrável", "desc": "CHAVE: a vida que pagas (Ira, Frascos, Sobrecarga) volta a 3% por segundo, mas a poção de vida não faz nada; exclui o Lich de Ferro", "req": "sede", "pos": Vector2(-100, -60), "stats": {"sangue": 1.0}},
	"fome": {"name": "Fome Insaciável da Terra", "desc": "CHAVE: a terra engole os mortos e ergue um esqueleto teu a cada 2, mas sem lacaios de pé come-te 2% da vida por segundo (até metade)", "req": "espasmo", "pos": Vector2(720, 500), "stats": {"fome": 1.0}},
	"lich": {"name": "Apoteose do Lich de Ferro", "desc": "CHAVE: com as poções cheias és o Lich de Ferro: +30% dano, -20% dano recebido; toda a cura converte-se em barreira; exclui Sangue Negro", "req": "sutura", "pos": Vector2(-215, 215), "stats": {"lich": 1.0}},
	"circulacao": {"name": "Circulação Negra", "desc": "Até -35% de recarga quanto menos vida tiveres", "req": "ossada", "pos": Vector2(80, -70), "stats": {"circulacao": 1.0}},
	"arqueiros": {"name": "Arqueiros de Ossada", "desc": "Os teus esqueletos disparam de longe lascas de osso que atravessam 2 monstros; exclui os Guardiões de Tórax", "req": "densidade_ossea", "pos": Vector2(210, 535), "stats": {"arqueiros": 1.0}},
	"guardioes": {"name": "Guardiões de Tórax", "desc": "Os teus esqueletos levam escudos: os mortos menores a 300 px atacam-nos em vez de ti (cada golpe tira-lhes tempo); exclui os Arqueiros de Ossada", "req": "densidade_ossea", "pos": Vector2(390, 535), "stats": {"guardioes": 1.0}},
	"exumacao": {"name": "Exumação Espontânea", "desc": "Quem matas à foice, ao machado ou na Ceifa de Ossos tem 25% de hipótese de se erguer como esqueleto teu durante 10 s (os chefes não)", "req": "simbioticas", "pos": Vector2(545, 540), "stats": {"exumacao": 1.0}},
	# "hero": só esse herói o compra (S3); o outro vê-o fechado, com "(só o Strider)"
	"carrasco": {"name": "Carrasco de Sangue Negro", "desc": "Os monstros (elites também) ficam executáveis abaixo de 20% da vida e o teu machado executa-os sozinho; os chefes com nome não", "req": "circulacao", "pos": Vector2(-40, -140), "hero": "warden", "stats": {"carrasco": 1.0}},
	"falange": {"name": "Falange Espectral", "desc": "A esquiva perfeita ergue escudos espectrais: os monstros a 160 px voam para trás e ficam 0,8 s sem atacar (elites e colossos também; o Arauto não)", "req": "dentes", "pos": Vector2(330, -75), "stats": {"falange": 1.0}},
	"ressurreicao": {"name": "Ressurreição de Elites", "desc": "O elite que matas ergue-se como teu durante 20 s, com o triplo do dano de um esqueleto teu (um de cada vez; os chefes não)", "req": "exumacao", "pos": Vector2(545, 640), "stats": {"ressurreicao": 1.0}},
	"estacas": {"name": "Lança-Ossos Balística", "desc": "A Lança de Almas vira uma estaca que fura 3 monstros, arrasta-os e prende-os 1,5 s onde parar, até numa parede; os chefes só abrandam", "req": "faminta", "pos": Vector2(850, 120), "hero": "strider", "stats": {"estacas": 1.0}},
}

var player  # jogador 1 (o HUD e os controlos de toque são dele)
var players := []
var cam := Camera2D.new()
var level := 1
var xp := 0
var shake := 0.0
var zoom_kick := 0.0
var cam_zoom := 1.0
var focus_t := 0.0
var focus_pos := Vector2.ZERO
var rumble := 0.0  # o sino dobra antes de o Arauto aparecer
var arena_r := 0.0  # > 0: os jogadores ficam presos no círculo do monumento até o Arauto cair
var pad_of := [-1, -1]  # comando (device) de cada jogador; -1 = ainda nenhum
var raise_by = null  # herói cuja Alma Tumular está a bater agora (quem morrer ergue-se para ele)
var raise_n := 1  # e quantos se erguem de cada um (Alma Mitótica #149: dois pequenos)
var cast_support := ""  # frasco do golpe que está a bater agora (posto e limpo à volta do golpe, como o raise_by)
var quiet := false  # golpes sem paragem de impacto, tremor nem som (os espinhos do Pacto de Carne e Ferro; nos heróis, a Chuva de Dentes, #192)
var cast_aff := 0  # Alma Caótica (#147): estado que o golpe deixa (1 podridão, 2 necrose, 3 calcificação, cores de CORPSE_COLORS)
var arcing := false  # Alma Biomecânica (#144): os arcos a bater agora (um arco não solta mais arcos)
var chain_all := false  # e a volta da Ceifa de Ossos a bater agora (#153): os arcos ligam todos os que ela apanha
var flasks := ["", "parasita", "titanica"]  # Frascos de Alma que o grupo já tem
var tomb := {}  # {"pos": Vector2, "lost": {moeda: quantidade}} enquanto houver um túmulo por recuperar
var tomb_node
var saved := {}  # o que veio do ficheiro (o Guardião usa a parte dele quando entrar)
var saved_json := ""
var save_t := 2.0
var zone := "world"  # "world" = cemitério, "crypt" = cripta, "sep" = Sepulcros
var bounds := MAP
var crypt_floor := PackedVector2Array()
var guardian  # o Carcereiro da Cripta, enquanto vivo
var guardian_met := false
var crypt_n := 0  # descidas à cripta (S6; fica no jogo gravado): a 1.ª é sempre a sala de sempre
var crypt_rule := ""  # a regra da sala de agora (CRYPT_RULES; "" no cemitério); vai ao convidado
var crypt_last := ""  # a da última descida (a seguinte nunca a repete)
var sep := {}  # o plano do Sepulcro de agora (plan_sep), {} fora dele; cada telemóvel faz o seu
var sep_key := 0  # o número do Sepulcro: idas x 1000 + profundidade; vai ao convidado antes da zona
var sep_built := 0  # a chave para que este telemóvel construiu o mapa
var sep_grid := PackedByteArray()  # as casas (19 x 19): 0 parede, 255 corredor, N a sala N - 1
var sep_node := Node2D.new()  # os adereços do Sepulcro (y-sort com os heróis), fora do ciclo do net._send, como scenery
var sep_tall := []  # os adereços altos de lá (#92): tall fica só com os do mundo
var sep_doors := []  # os sprites das duas saídas do chefe: apagados até ele cair
var sep_aim := 1  # a sala para onde a seta aponta (cada telemóvel a sua)
var sep_done := 0  # 1 com o chefe caído: abre as duas saídas; vai ao convidado
var sep_streak := 0  # profundidades seguidas sem subir; vai ao convidado
var sep_bank := {}  # as moedas já lá dentro (com o saque do mundo e o relicário que vieram de fora): cair só perde metade do que veio depois (só no anfitrião)
var sep_elites := 0  # os elites que esta profundidade ainda vai ter (só no anfitrião)
var sep_runs := 0  # idas ao Portão; fica no jogo gravado e vai ao convidado (a seta lê-o)
var sep_max := 0  # a profundidade mais funda vencida; fica no jogo gravado
var gate_node: Sprite2D  # o Portão dos Reis, apagado até à 1.ª vitória
var breath_end := INF  # Abismo do Miasma (#38): quando acaba o ar (em time; INF = ar limpo)
var choke_t := 0.5  # e o próximo engasgo sem ar (só no anfitrião)
var tide_next := 0.0  # Lago das Lamentações (#30): quando começa a próxima maré de almas (em time)
var tide_dir := Vector2.RIGHT  # e para onde empurra, ao longo do corredor (um sentido por descida)
var rocks := []  # Minas de Enxofre (#43): [posição, quando rebenta (em time; 0 = intacta)]; vai ao convidado
var hammers := []  # Forja das Almas Escravas (#184): [posição, quando bate (em time)]; vai ao convidado
var saw_t := 0.5  # Moinho de Carne (#202): a próxima volta das serras (só no anfitrião)
var noise_at := Vector2.ZERO  # o último barulho (Sanctum do Silêncio, #46): onde e quando; o Monge (#193) vai lá (só no anfitrião)
var noise_t := -1.0
var dark := Node2D.new()  # Catacumbas Cegas (#26): o escuro (dark.gdshader), por cima das personagens
var tint := CanvasModulate.new()  # a cripta é mais escura
var sfx_last := {}
var fx_frame := -1  # efeitos em píxeis contados neste frame (fx_budget)
var fx_count := {}
var hud
var music := AudioStreamPlayer.new()  # o que se ouve; music_b só acaba de se apagar quando a faixa muda
var music_b := AudioStreamPlayer.new()
var music_tw: Tween
var track := ""  # a faixa de agora (vai ao convidado)
var settings := SETTINGS.duplicate()
var wiping := false  # Novo jogo: o jogo gravado foi apagado e nada o volta a escrever antes de recomeçar
var chest
var rng := RandomNumberGenerator.new()
var currency := {"bone": 0, "ink": 0, "ash": 0, "formao": 0, "carmesim": 0, "pena": 0, "tomo": 0, "coracao": 0}  # e os reagentes da Forja (S2) e o Coração de Titã (#70)
var kills := {}  # mortes de cada monstro (o Bestiário revela-os com elas)
var weapon := {"tier": 0, "suffixes": [], "hidden": "", "sealed": true, "locked": ""}  # locked: o sufixo que o Formão (#54) travou
var relics := []  # Relíquias de Família (#58) que o grupo já tem
var gear_drops := true  # os mortos largam equipamento (0.4.8); os testes desligam-no para as contas e as sementes dos outros lotes não mudarem
var cortejo := {"active": false, "wave": 0, "affixes": [], "alive": 0}
var circle := 1  # Círculos (#27): o círculo do Cortejo (cada um mais forte e com mais saque)
var circle_max := 1  # o mais alto aberto: quebrar o Cortejo nele abre o seguinte
var wins := 0  # Cortejos quebrados, em qualquer círculo
var trial := ""  # a Provação deste Cortejo (TRIALS; "" nenhuma); vai ao convidado
var proven := []  # as Provações já vencidas (fica no jogo gravado): a 1.ª vitória na das Almas dá um Frasco
var event := {}  # S9: o evento do cemitério de agora ({} nenhum): id, onde (pos), horas (at, end, next), vivos, por nascer, banquete; vai ao convidado
var event_next := 0.0  # e quando calha o próximo (em time); vai ao convidado
var event_last := ""  # o último que saiu (o seguinte nunca o repete; só no anfitrião)
var mausoleum := 0  # Mausoléu Sem Fim (#27): o piso de agora (0 = fora dele); vai ao convidado
var floor_end := 0.0  # e quando acaba (em time; INF num piso de chefe, até ele cair); vai ao convidado
var curses := []  # as maldições escolhidas (de SEALS; repetem-se e somam-se) até ao fim da descida
var maus_t := 0.0  # o próximo par de mortos do Mausoléu (só no anfitrião)
var deep := 0  # o piso mais fundo a que já se chegou (fica no jogo gravado); vai ao convidado
var sanctum_rule := 0  # Santuário dos Deuses Cadavéricos (#50): a lei de agora (1 a 4, LAWS; 0 = fora dele); vai ao convidado
var reaper  # O Ceifador Ambulante (#216): não está no grupo dos inimigos, por isso fica aqui (no convidado vem do net._spawn)
var eclipse_next := 0.0  # Eclipse Fúnebre (#182): quando cai o próximo e até quando dura o de agora (em time); vão ao convidado
var eclipse_end := 0.0
var tide_start := 0.0  # Marés de Sangue Negro (#212): quando sobe a próxima maré (em time; o aviso vem 3 s antes); vai ao convidado
var drip_t := 0.5  # a maré e a Chuva de Dentes (#192) tiram vida de meio em meio segundo (só no anfitrião)
var monument_pos := Vector2(0, -300)
var thermal := 0  # proteção térmica: 0 nada, 1 menos efeitos, 2 também 30 FPS (até fechar o jogo)
var thermal_t := 0.0
var monument: Sprite2D
var fog := Node2D.new()  # nevoeiro em píxeis (fog.gdshader), por baixo das personagens
var glows := []
var tile_rows := []  # o chão: uma Array por fila, cada ladrilho [textura, Rect2, cor]; desenha-se só à volta da câmara
var floor_node := Node2D.new()  # o chão (z -13); tiles (z -12) fica com a praça, a cripta e os brilhos
var floor_at := Vector2.INF  # o ponto à volta do qual o chão foi desenhado
var scenery := Node2D.new()  # os adereços do mapa (y-sort com os heróis); não entram no ciclo do net._send
var tall_fixed := []  # e o que não muda com o mapa: escadas, monumento, altar, estátuas da estrada, portão
var glows_fixed := []
var map_circle := 0  # o número (map_seed) para que o mapa foi feito; vai ao convidado antes da zona
var map_job := 0  # cada reconstrução é um número: a ultrapassada desiste
var map_busy := false
var map_builds := 0
var map_hash := 0
var map_ms := 0.0
var map_spots := {}  # região -> centro, neste mapa
var map_tex: ImageTexture  # o desenho do minimapa
var camps := []  # {"pos", "region"}: os acampamentos deste mapa (os dois telemóveis calculam-nos)
var camps_done := []  # índices já limpos; fica no jogo gravado; vai ao convidado; só uma vitória no Cortejo os repõe
var camp_left := {}  # índice -> [mortos por matar, elite de pé]; só no anfitrião
var camp_next := 0.0  # a próxima vista aos acampamentos (em time; só no anfitrião)
var region_now := ""  # só neste telemóvel
var region_t := 0.0
var teeth := []  # Dentes de Sepultura: [posição, tempo que falta] deixados pela esquiva
var blood := []  # Sangue no Solo (#23): [posição, quando seca (em time)] das poças dos monstros a sangrar
var sentinels := []  # Sentinelas Tumulares (#25): [posição, quando se desfaz, próximo tiro (em time), slot do herói], até 2 por herói
var corpses := []  # Espasmo Cadavérico (#9, #115): [posição, estado (0 osso, 1 podridão, 2 necrose, 3 calcificação), quando rebenta (em time), dano]
var graves := []  # Alma Gatilho: [posição, quando deixa de contar (em time)] dos últimos abates, até 3; só no anfitrião (não se desenha nem vai ao convidado)
var runes := []  # Escriba da Agonia (#155): [posição, quando se apaga (em time), slot do herói], até 6; só no anfitrião (ocultas: não se desenham nem vão ao convidado)
var spawn_t := 0.0
var giant_at := 0.0  # Cemitério dos Gigantes (#39): o Gigante Errante que caiu só volta a partir daqui (em time)
var time := 0.0
var tiles := Node2D.new()
var ground := Node2D.new()
var xray := Node2D.new()  # silhuetas de quem fica tapado por um adereço alto (#92), por cima de tudo
var tall := []  # Rect2 do meio de cada adereço alto (feitos em _prop)


func _ready() -> void:
	I18n.setup()
	for p in CRYPT_FLOOR:
		crypt_floor.append(CRYPT_ORIGIN + p)
	add_child(tint)
	_setup_input()
	for b in ["Musica", "Efeitos"]:  # canais de som com volume próprio nas Configurações
		if AudioServer.get_bus_index(b) == -1:
			AudioServer.add_bus()
			AudioServer.set_bus_name(AudioServer.bus_count - 1, b)
			AudioServer.set_bus_send(AudioServer.bus_count - 1, "Master")
	Input.joy_connection_changed.connect(_on_joy)
	rng.randomize()
	_reroll_weapon()
	if not Net.is_guest():  # o convidado joga o jogo do anfitrião
		saved = _read_save()
		_apply_save()
	load_settings()
	# y-sort ordena o desenho do pai junto com os filhos; o chão vai em filhos atrás de tudo.
	# tiles = desenhado uma vez por mapa; ground = nevoeiro e brilhos, redesenhado a cada frame.
	tiles.z_index = -12
	tiles.draw.connect(_draw_tiles)
	add_child(tiles)
	ground.z_index = -10
	ground.draw.connect(_draw_world)
	add_child(ground)
	xray.z_index = 3  # por cima dos adereços e das personagens (z 0), debaixo dos efeitos (4 e mais)
	xray.material = ShaderMaterial.new()
	xray.material.shader = SILHOUETTE
	xray.draw.connect(_draw_xray)
	add_child(xray)
	dark.z_index = 3  # com as silhuetas e depois delas: por cima das personagens, debaixo dos efeitos (4 e mais)
	dark.material = ShaderMaterial.new()
	dark.material.shader = DARK
	dark.draw.connect(_draw_dark)
	add_child(dark)
	var fn := FastNoiseLite.new()
	fn.frequency = 0.03
	fn.fractal_octaves = 4
	var noise := NoiseTexture2D.new()  # o ruído do nevoeiro, feito uma vez (o Godot gera-o noutro fio)
	noise.seamless = true
	noise.noise = fn
	fog.z_index = -9
	fog.material = ShaderMaterial.new()
	fog.material.shader = FOG
	fog.material.set_shader_parameter("field", noise)
	fog.draw.connect(_draw_fog)
	add_child(fog)
	floor_node.z_index = -13
	floor_node.draw.connect(_draw_floor)
	add_child(floor_node)
	scenery.y_sort_enabled = true
	add_child(scenery)
	sep_node.y_sort_enabled = true
	add_child(sep_node)
	_gen_fixed()
	var first := map_seed()  # já vem do jogo gravado (_apply_save)
	if Engine.has_meta("map_circle"):  # no convidado: o do anfitrião
		first = Engine.get_meta("map_circle")
		Engine.remove_meta("map_circle")
	build_map(first, false)
	player = add_player()
	cam.limit_left = int(MAP.position.x)
	cam.limit_top = int(MAP.position.y)
	cam.limit_right = int(MAP.end.x)
	cam.limit_bottom = int(MAP.end.y)
	cam.position_smoothing_enabled = true
	cam.position = player.position
	add_child(cam)
	for s in MUSIC.values():
		s.loop = true
	for m in [music, music_b]:
		m.bus = "Musica"
		m.process_mode = Node.PROCESS_MODE_ALWAYS  # a música não pára com os menus (o jogo pára)
		add_child(m)
	hud = Hud.new()
	hud.main = self
	add_child(hud)
	apply_settings()
	if Net.is_guest():
		_as_guest()
	else:
		_spawn_tomb()
		_spawn_dummy()
		event_next = rng.randf_range(180.0, 240.0)  # S9: o 1.º evento, daqui a 3 a 4 minutos
		for i in 14:
			spawn_wild("skeleton", Vector2(rng.randf_range(-900, 900), rng.randf_range(-1500, -1000)))
	_floor_tick()
	if Engine.has_meta("play_now"):
		Engine.remove_meta("play_now")  # Novo jogo / Erguer-se / entrar numa sala: entra direto no jogo
	else:
		hud.open_opening(hud.open_title if settings.intro_seen else hud.open_intro)
	Net.attach(self)


## Co-op por Wi-Fi, no convidado: os dois heróis só desenham o que o anfitrião manda; este telemóvel fica com o outro herói.
func _as_guest() -> void:
	player = add_player(-2)
	players.reverse()
	for p in players:
		p.set_process(false)
	hud.skills_for_player()


## O 2.º jogador da Wi-Fi saiu da sala: o anfitrião continua sozinho.
func drop_player() -> void:
	if players.size() < 2:
		return
	save_game()  # o equipamento e a Árvore do convidado ficam gravados antes de ele sair
	var p = players.pop_back()
	if raise_by == p:
		raise_by = null
	p.queue_free()
	pad_of[1] = -1
	_rebind()
	hud.toast(tr("O %s saiu da sala.") % tr(p.hero_name))
	if nearest_player(players[0].position) == null:  # quem ficou já tinha caído: sem ninguém para o reanimar, é a morte (no Mausoléu acaba a descida)
		_on_player_down(players[0])


## Jogador 1 é o herói escolhido (_first_hero); o jogador 2 fica com o outro e entra a qualquer momento (Menu no 2.º comando).
## pad = o comando dele (-1: fica com o próximo comando que carregar num botão).
func add_player(pad := -1) -> Node2D:
	var p := Player.new()
	p.main = self
	p.setup(_first_hero() if players.is_empty() else other_hero(), players.size())
	p.position = Vector2(0, 300) if players.is_empty() else players[0].position + Vector2(60, 0)
	p.points = level - 1 + relics.size()
	_apply_hero(p)
	p.refresh_stats()
	p.hp = p.max_hp
	p.hp_chunk = p.max_hp
	p.died.connect(_on_player_down.bind(p))
	players.append(p)
	add_child(p)
	pad_of[players.size() - 1] = pad
	_rebind()
	if players.size() > 1:
		hud.toast((tr("O %s entrou no Cortejo!") if pad != -1 else tr("O %s entrou — carrega num botão do 2.º comando.")) % tr(p.hero_name))
		if trial == "almas":  # a Provação das Almas (#37) é só a solo: com 2 heróis acaba ali e os frascos voltam
			trial = ""
			_unstash()
			hud.toast(tr("A Provação das Almas é só a solo: foi cancelada."))
	return p


## O herói do jogador 1: o escolhido no Novo jogo ou em Mudar de herói (no convidado, o do anfitrião), senão o gravado.
func _first_hero() -> String:
	var h = saved.get("hero", "strider")
	if Engine.has_meta("hero"):
		h = Engine.get_meta("hero")
		Engine.remove_meta("hero")
	return h if h in Player.HEROES else "strider"  # o jogo gravado e a rede não são de confiança


## O 2.º jogador (comando ou Wi-Fi) fica sempre com o outro herói: as duas partes do jogo gravado nunca se pisam.
func other_hero() -> String:
	return "strider" if players[0].hero == "warden" else "warden"


## Quem os monstros perseguem: um clone de osso perto (Esquiva Espectral), com taunt um Guardião de Tórax (#11) a 300 px
## (os chefes não caem nisso), ou o herói mais perto.
func lure(pos: Vector2, taunt := false):
	for d in get_tree().get_nodes_in_group("decoys"):
		if pos.distance_to(d.position) < 420.0:
			return d
	if taunt:
		for a in get_tree().get_nodes_in_group("allies"):
			if a.kind == "guarda" and a.life > 0.0 and pos.distance_to(a.position) < 300.0:
				return a
	return nearest_player(pos)


func spawn_decoy(p) -> void:
	var d := Decoy.new()
	d.main = self
	d.position = p.position
	d.hero = p.hero
	d.frame32 = p._frame32()
	d.flip = p.flip_s
	add_child(d)


func nearest_player(pos: Vector2):
	var best = null
	for p in players:
		if not p.dead and (best == null or pos.distance_squared_to(p.position) < pos.distance_squared_to(best.position)):
			best = p
	return best


func _on_player_down(p) -> void:
	if nearest_player(p.position) == null:
		var info := die(p.position)
		info.by = p.killed_by
		hud.open_death(info)
	else:
		hud.toast(tr("O %s caiu! Fica perto dele para o reanimar.") % tr(p.hero_name))


## Todos caíram: metade de cada recurso fica num túmulo no cemitério (onde se morreu ou, na cripta,
## ao pé das escadas). Um túmulo antigo por recuperar desfaz-se; nos Sepulcros, só o que se apanhou nesta ida, ao pé do
## Portão, e o túmulo antigo junta-se a este. Grava logo: fechar a app não salva nada.
func die(at: Vector2) -> Dictionary:
	_unstash()
	end_event()
	if mausoleum > 0:  # Mausoléu Sem Fim (#27): cair acaba a descida e guarda-se tudo, sem túmulo (o saque do chão também)
		var reached := mausoleum
		end_mode()
		_gather_loot()
		save_game()
		return {"lost": {}, "had_old": false, "deep": reached}
	end_mode()
	var lost := {}
	for k in currency:
		lost[k] = (maxi(currency[k] - sep_bank.get(k, 0), 0) if zone == "sep" else currency[k]) / 2  # nos Sepulcros, só o que se apanhou nesta ida
		currency[k] -= lost[k]
	var moved := zone == "sep" and not tomb.is_empty()
	var had_old := not tomb.is_empty() and not moved
	var keep := lost.duplicate()
	if moved:
		for k in keep:
			keep[k] += tomb.lost[k]  # tomb.lost tem sempre todas as moedas (_apply_save)
	tomb = {}
	if keep.values().any(func(v): return v > 0):
		var pos: Vector2 = at if zone == "world" else GATE + Vector2(0, -300) if zone == "sep" else CRYPT_DOOR + Vector2(0, 150)
		tomb = {"pos": pos.clamp(MAP.position + Vector2(80, 80), MAP.end - Vector2(80, 80)), "lost": keep}
	save_game()
	return {"lost": lost if lost.values().any(func(v): return v > 0) else {}, "had_old": had_old, "sep": zone == "sep", "moved": moved}


func _spawn_tomb() -> void:
	if tomb.is_empty():
		return
	tomb_node = Tomb.new()
	tomb_node.main = self
	tomb_node.position = tomb.pos
	add_child(tomb_node)


func recover_tomb() -> void:
	if tomb.is_empty():
		return
	var got := []
	for k in tomb.lost:
		currency[k] += tomb.lost[k]
		if tomb.lost[k] > 0:
			got.append("%s x%d" % [tr(Loot.INFO[k][0]), tomb.lost[k]])
	hud.toast(tr("Recuperaste do túmulo: %s") % ", ".join(got))
	spawn_fx("ring", tomb_node.position, 130.0, Color(0.4, 1.0, 0.65))
	sfx("chest")
	tomb_node.queue_free()
	tomb_node = null
	tomb = {}
	save_game()


func _process(delta: float) -> void:
	time += delta
	thermal_check(delta, Engine.get_frames_per_second())
	ground.queue_redraw()
	xray.queue_redraw()
	fog.queue_redraw()
	dark.visible = dark_on()  # o convidado também: a regra e as luzes vêm do anfitrião
	dark.queue_redraw()
	monument.texture = MON_ON if cortejo.active else MON
	gate_node.modulate = Color.WHITE if wins >= 1 else Color(0.45, 0.45, 0.5)
	_floor_tick()
	_region_tick(delta)
	_sep_tick()
	if Net.is_guest():  # quem simula é o anfitrião; aqui só a câmara
		_coop(delta)
		return
	if map_circle != map_seed() and hud.card_t <= 0.0 and cortejo.wave == 0 and not mode_on() and zone != "sep":  # o mapa segue o Círculo e as vitórias; as setas do menu do Cortejo não chegam aqui (o jogo está em pausa), o cartão da vitória fica à vista, e quem muda o Círculo e começa logo a onda ou um modo fica com este mapa até acabarem (a troca, a meio da luta, via-se sem o negro)
		build_map(map_seed())
	_music_pick()
	for i in range(teeth.size() - 1, -1, -1):
		teeth[i][1] -= delta
		if teeth[i][1] <= 0.0:
			teeth.remove_at(i)
	# guarda a hora a que seca, não um contador: assim a lista só muda (e só vai ao convidado) quando entra ou sai uma poça
	while not blood.is_empty() and blood[0][1] <= time:
		blood.pop_front()
	_sentinels()
	_runes()
	while not corpses.is_empty() and corpses[0][2] <= time:  # Espasmo Cadavérico: o mais antigo rebenta sozinho
		burst_corpse(corpses[0])
	if not teeth.is_empty():
		for e in enemies():
			for tooth in teeth:
				if e.position.distance_squared_to(tooth[0]) < 45.0 * 45.0:
					e.slow_t = maxf(e.slow_t, 0.4)  # sem encurtar um mais comprido (as Garras, main:1694)
					break
	save_t -= delta
	if save_t <= 0.0:
		save_t = 2.0
		save_game()
	if rumble > 0.0:
		rumble -= delta
		shake = maxf(shake, (2.6 - rumble) * 2.4)
	_coop(delta)
	_crypt_tick(delta)
	_cortejo_tick(delta)
	_event_tick()
	_mausoleum_tick(delta)
	# Carcereiro e os chefes dos Sepulcros: ao chegarem perto, ruge e aparece o cartão do chefe
	if zone != "world" and is_instance_valid(guardian) and not guardian_met:
		var q = nearest_player(guardian.position)
		if q != null and q.position.distance_to(guardian.position) < guardian.aggro:
			guardian_met = true
			if zone == "sep":
				guardian.heard = time  # o Monge só começa a ouvir agora
				focus_pos = guardian.position + Vector2(0, -40)  # a revelação (_coop)
				focus_t = 1.2
				spawn_fx("ring", guardian.position, 320.0, Color(0.4, 1.0, 0.6))
				if guardian.boss == "guardiao":  # as estátuas só ao acordar: senão eram 4 setas vermelhas desde o início
					raise_statues(guardian)
				elif guardian.title == "Sentinela":  # sozinha era um saco de pancada: a 55 px/s contra 230, e a foice chega mais longe do que o murro
					summon_minions(guardian, 3)
			hud.name_card(guardian.title, "Mensageiro do Cortejo Fúnebre" if guardian.title == "Arauto Fúnebre" else Bosses.INFO[guardian.boss][1])  # o Arauto tem boss == "", e essa frase é a do Carcereiro
			guardian.bar_fill = 0.0
			sfx("roar")
			shake = 12.0
			vibrate(250, 1.0)
	spawn_t -= delta
	if zone == "world" and spawn_t <= 0.0 and not cortejo.active and not mode_on() and nearest_player(player.position) != null:
		spawn_t = 0.9
		_wild_tick()
		if enemies().size() < DENSITY[settings.density]:  # os bandos contam: a escolha da densidade continua a ser um limite
			var dir := Vector2.from_angle(player.facing.angle() + rng.randf_range(-1.2, 1.2) if rng.randf() < 0.6 else rng.randf() * TAU)  # 60% à frente de quem anda
			var p: Vector2 = player.position + dir * 700.0
			if not MAP.grow(-40.0).has_point(p):
				p = player.position - dir * 700.0
			p = p.clamp(MAP.position + Vector2(40, 40), MAP.end - Vector2(40, 40))
			var e = spawn_wild("specter" if rng.randf() < REGIONS[region_at(p)].spec else "skeleton", p)
			if rng.randf() < 0.05 and not enemies().any(func(o): return o.elite and o.camp < 0):  # Elites (#277): no cemitério, um de cada vez
				e.make_elite()
		_giants()
	if time >= camp_next:
		camp_next = time + 0.25  # a passo ninguém vê um bando nascer, e quem sobe da cripta ainda está no negro
		_camps_tick()
		_sep_wake()


## Câmara no meio do grupo (com tremor e zoom de impacto); ninguém sai do ecrã nem da arena do chefe.
## Reanimar: aliado vivo perto de quem caiu.
func _coop(delta: float) -> void:
	var mid := Vector2.ZERO
	for p in players:
		mid += p.position
	mid /= players.size()
	# na arena do chefe a câmara fica entre o grupo e o monumento e afasta-se um pouco;
	# enquanto o Arauto se ergue e ruge, a câmara olha para ele (a revelação)
	cam.position = (mid + monument_pos) / 2.0 if arena_r > 0.0 else mid
	var focusing := focus_t > 0.0  # lido antes de descontar: no último frame a câmara ainda está no chefe
	if focusing:
		focus_t -= delta
		cam.position = focus_pos
	cam_zoom = lerpf(cam_zoom, 0.85 if arena_r > 0.0 else 1.0, 1.0 - exp(-2.0 * delta))
	cam.offset = Vector2(randf_range(-1, 1), randf_range(-1, 1)) * shake * (1.0 if settings.shake else 0.0)
	cam.zoom = Vector2.ONE * (cam_zoom + zoom_kick)
	shake = move_toward(shake, 0.0, 45.0 * delta)
	zoom_kick = move_toward(zoom_kick, 0.0, 0.4 * delta)
	if arena_r > 0.0:
		for p in players:
			var v: Vector2 = p.position - monument_pos
			if v.length() > arena_r - 30.0:
				p.position = monument_pos + v.normalized() * (arena_r - 30.0)
	if players.size() < 2 or Net.is_guest():
		return
	var half := get_viewport_rect().size / 2.0 / cam.zoom - Vector2(60, 90)
	for p in players:
		if zone != "sep" or not focusing:  # a revelação do chefe: a câmara foge do grupo 1,2 s e não pode arrastar ninguém pelas paredes
			p.position = p.position.clamp(cam.position - half, cam.position + half)
		if p.dead:
			var ally = nearest_player(p.position)
			if zone == "sep" and ally != null and not on_floor(p.position):  # arrastado para a parede: vai ter com o vivo (quem caiu não anda)
				p.position = ally.position
			var near: bool = ally != null and ally.position.distance_to(p.position) < 80.0
			p.revive_t = p.revive_t + delta if near else maxf(0.0, p.revive_t - delta)
			if p.revive_t >= REVIVE_T:
				p.revive()
				spawn_fx("ring", p.position, 90.0, Color(0.4, 1.0, 0.65))
				hud.toast(tr("O %s voltou à luta!") % tr(p.hero_name))
			p.queue_redraw()


## Subir de nível: cada jogador ganha um ponto na árvore e +8 de vida máxima, com explosão de luz.
func gain_xp(amount: int) -> void:
	xp += amount
	while xp >= xp_needed():
		xp -= xp_needed()
		level += 1
		hitstop(0.1)
		shake = maxf(shake, 6.0)
		vibrate(50, 0.6)
		for p in players:
			p.points += 1
			p.refresh_stats()
			p.heal(8.0)
			spawn_fx("burst", p.position + Vector2(0, -40), 0.0, Color(1.0, 0.85, 0.4))
			spawn_fx("glow", p.position + Vector2(0, -40), 90.0, Color(1.0, 0.85, 0.4))
			spawn_fx("ring", p.position, 180.0, Color(1.0, 0.85, 0.4))
			if effects_level() == 0:  # efeitos baixos: a coluna simples
				spawn_fx("column", p.position, 0.0, Color(1.0, 0.85, 0.4))
			else:  # o pilar de luz de alma que cai do céu, com estrelas douradas
				spawn_fx("pillar", p.position, 0.0, Color(1.0, 0.85, 0.4), Vector2.RIGHT, "soul")
		sfx("levelup")
		hud.level_up()


func xp_needed() -> int:
	return 40 * level


func _setup_input() -> void:
	for pfx in ["", "p2_"]:
		for name in PAD_BUTTONS:
			if not InputMap.has_action(pfx + name):
				InputMap.add_action(pfx + name, 0.25)
	_rebind()
	# Menus: o Godot já navega com a cruz e o stick, mas não traz o A (escolher) nem o B (voltar)
	for pair in [["ui_accept", JOY_BUTTON_A], ["ui_cancel", JOY_BUTTON_B]]:
		var ev := InputEventJoypadButton.new()
		ev.button_index = pair[1]
		ev.device = -1
		if not InputMap.action_has_event(pair[0], ev):
			InputMap.action_add_event(pair[0], ev)


## Liga as ações de um jogador a um comando: device >= 0 = só esse, -1 = qualquer comando, -2 = nenhum.
func _bind(pfx: String, device: int) -> void:
	for name in PAD_BUTTONS:
		var action: String = pfx + name
		InputMap.action_erase_events(action)
		if device == -2:
			continue
		for b in PAD_BUTTONS[name]:
			var ev := InputEventJoypadButton.new()
			ev.button_index = b
			ev.device = device
			InputMap.action_add_event(action, ev)
		if PAD_AXES.has(name):
			var ev := InputEventJoypadMotion.new()
			ev.axis = PAD_AXES[name][0]
			ev.axis_value = PAD_AXES[name][1]
			ev.device = device
			InputMap.action_add_event(action, ev)


## Jogador 1: o seu comando, ou qualquer um enquanto não se sabe qual é. Jogador 2: só o seu comando.
func _rebind() -> void:
	_bind("", pad_of[0] if pad_of[0] != -1 else (-1 if pad_of[1] == -1 else -2))
	_bind("p2_", pad_of[1] if pad_of[1] != -1 else -2)


## Quem é quem (o HUD chama isto a cada toque num comando, mesmo em pausa): o 1.º comando que mexe é do
## jogador 1; um comando novo que carregue em Menu ou A faz entrar o 2.º jogador; se ele entrou pelo
## ecrã de título, o 1.º botão de um comando novo fica para ele.
func on_pad_input(event: InputEvent) -> void:
	var press: bool = event is InputEventJoypadButton and event.pressed
	if not press and not (event is InputEventJoypadMotion and absf(event.axis_value) > 0.6):
		return
	var d: int = event.device
	if d in pad_of:
		return
	if pad_of[0] == -1:
		pad_of[0] = d
		_rebind()
	elif players.size() == 1:
		if press and event.button_index in [JOY_BUTTON_START, JOY_BUTTON_A]:
			add_player(d)
	elif pad_of[1] == -1 and press:
		pad_of[1] = d
		_rebind()
		hud.toast(tr("2.º comando ligado ao %s.") % tr(players[1].hero_name))


func _on_joy(device: int, connected: bool) -> void:
	var i: int = pad_of.find(device)
	if connected or i == -1:
		return
	pad_of[i] = -1
	_rebind()
	if i < players.size():
		hud.pad_lost(players[i].hero_name, i == 0)


# ---------- Jogo gravado ----------

## Nível, moedas, arma e, por herói, a Árvore e os Frascos de Alma (as configurações vão à parte).
## O sítio onde se está e os inimigos não: abre-se sempre no cemitério.
func _save_data() -> Dictionary:
	var heroes: Dictionary = saved.get("heroes", {}).duplicate() if saved.get("heroes") is Dictionary else {}
	for p in players:
		var sup := {}
		for id in p.order:
			sup[id] = p.skills[id].support
		var kept: Array = [sup, p.soul] if p.stash == null else p.stash  # na Provação das Almas (#37), os frascos guardados
		heroes[p.hero] = {"passives": p.passives, "points": p.points, "supports": kept[0], "soul": kept[1], "respecs": p.respecs, "gear": p.gear, "bag": p.bag}
	var t := {} if tomb.is_empty() else {"pos": [tomb.pos.x, tomb.pos.y], "lost": tomb.lost}
	var cur := currency.duplicate()
	if enemies().any(func(e): return e.boss == "tita"):  # o Titã (#70) acordado leva o Coração; fechar a app não o perde
		cur.coracao += 1
	if zone == "sep" and is_instance_valid(chest) and not chest.opened and not chest.locked and nearest_player(chest.position) != null:  # sep_max grava-se antes de o relicário se abrir: fechar a app não leva a vitória e deixa o saque; quem caiu, cai sem ele
		for r in chest.rewards:
			cur[r[0]] += r[1]
	return {"v": 1, "hero": players[0].hero, "level": level, "xp": xp, "currency": cur, "weapon": weapon, "heroes": heroes,
		"flasks": flasks, "tomb": t, "kills": kills, "circle": circle, "circle_max": circle_max, "wins": wins, "relics": relics, "crypt_n": crypt_n,
		"crypt_last": crypt_last, "proven": proven, "deep": deep, "camps_done": camps_done, "sep_runs": sep_runs, "sep_max": sep_max}


## Só escreve quando algo mudou. Escreve num ficheiro à parte e depois troca-o pelo verdadeiro:
## se a app morrer a meio da escrita, o jogo gravado antigo fica inteiro.
func save_game() -> void:
	if hud == null or wiping or Net.is_guest():
		return
	var d := _save_data()
	var s := JSON.stringify(d)
	if s == saved_json:
		return
	var tmp := SAVE_PATH + ".tmp"
	var f := FileAccess.open(tmp, FileAccess.WRITE)
	if f == null:
		return
	f.store_string(s)
	f.close()
	if DirAccess.rename_absolute(tmp, SAVE_PATH) == OK:
		saved_json = s
		saved = d


## A app vai para segundo plano ou fecha: o Android pode matá-la a seguir sem avisar.
func _notification(what: int) -> void:
	if what in [NOTIFICATION_APPLICATION_PAUSED, NOTIFICATION_APPLICATION_FOCUS_OUT, NOTIFICATION_WM_CLOSE_REQUEST]:
		save_game()


func has_save() -> bool:
	return FileAccess.file_exists(SAVE_PATH)


## Novo jogo: apaga o jogo gravado e recomeça já a jogar (as configurações ficam).
func new_game() -> void:
	wiping = true
	DirAccess.remove_absolute(ProjectSettings.globalize_path(SAVE_PATH))
	restart()


## Recomeça a cena: para o ecrã de título, ou direto para o jogo (Novo jogo, Erguer-se).
func restart(to_title := false) -> void:
	if not to_title:
		Engine.set_meta("play_now", true)
	else:
		Net.close()  # voltar ao título fecha a sala (ou sai dela)
	get_tree().paused = false
	get_tree().reload_current_scene()


# ---------- Configurações ----------

func load_settings() -> void:
	var cf := ConfigFile.new()
	if cf.load(SETTINGS_PATH) == OK:
		for k in SETTINGS:
			var v = cf.get_value("opcoes", k, SETTINGS[k])
			if typeof(v) == typeof(SETTINGS[k]) or (SETTINGS[k] is float and v is int):
				settings[k] = v
		if cf.get_value("opcoes", "vibrate", true) == false and not cf.has_section_key("opcoes", "vibe"):
			settings.vibe = 0  # até à 0.3.2 a vibração era só ligada / desligada
		if cf.get_value("opcoes", "loot_names", 0) == 1 and not cf.has_section_key("opcoes", "loot_common"):
			settings.loot_common = 1  # até à 0.4.3 havia só "Nomes no chão: Só os raros"
	else:
		settings.ui = int(_num(saved.get("ui"), 0))  # até à 0.2.0 o tamanho dos botões ia no jogo gravado
		settings.lang = 0 if OS.get_locale_language() == "pt" else 1
	for k in ["master", "music", "sfx"]:
		settings[k] = clampf(float(settings[k]), 0.0, 1.0)
	for k in CHOICES:
		settings[k] = clampi(int(settings[k]), 0, CHOICES[k] - 1)


func save_settings() -> void:
	var cf := ConfigFile.new()
	for k in settings:
		cf.set_value("opcoes", k, settings[k])
	cf.save(SETTINGS_PATH)


func set_setting(key: String, v) -> void:
	settings[key] = v
	apply_settings()
	save_settings()


func reset_settings() -> void:
	var seen: bool = settings.intro_seen  # repor não volta a mostrar a intro
	settings = SETTINGS.duplicate()
	settings.intro_seen = seen
	apply_settings()
	save_settings()


## Som por canal, FPS, resolução e botões no ecrã. Tremor, clarão, números e partículas leem-se na hora.
## Efeitos visuais de agora: os das Configurações, um degrau abaixo se a proteção térmica atuou.
func effects_level() -> int:
	return maxi(0, settings.effects - (1 if thermal >= 1 else 0))


## Proteção térmica (#313): o Godot não lê a temperatura, mas um telemóvel quente baixa o relógio do
## processador e os FPS caem. 12 s abaixo de 75% do limite: primeiro menos efeitos, depois 30 FPS.
func thermal_check(delta: float, fps: float) -> void:
	if not settings.thermal or thermal >= 2:
		return
	var cap: float = Engine.max_fps if Engine.max_fps > 0 else 60.0
	thermal_t = thermal_t + delta if fps < cap * 0.75 else maxf(0.0, thermal_t - delta * 2.0)
	if thermal_t >= 12.0:
		thermal_t = 0.0
		thermal += 1
		apply_settings()
		hud.toast("Proteção térmica: menos efeitos para o telemóvel não aquecer." if thermal == 1 else "Proteção térmica: 30 FPS para o telemóvel não aquecer.")


func apply_settings() -> void:
	for b in [["Master", "master"], ["Musica", "music"], ["Efeitos", "sfx"]]:
		var i := AudioServer.get_bus_index(b[0])
		var v: float = settings[b[1]]
		AudioServer.set_bus_volume_db(i, linear_to_db(maxf(v, 0.001)))
		AudioServer.set_bus_mute(i, v <= 0.0)
	TranslationServer.set_locale("en_GB" if settings.lang == 1 else "pt_PT")
	Engine.max_fps = FPS_CAPS[settings.fps]
	if thermal >= 2 and (Engine.max_fps == 0 or Engine.max_fps > 30):
		Engine.max_fps = 30
	# Poupança: desenha a 720p e estica (muito menos píxeis nos ecrãs grandes)
	get_tree().root.content_scale_mode = Window.CONTENT_SCALE_MODE_VIEWPORT if settings.res == 1 else Window.CONTENT_SCALE_MODE_CANVAS_ITEMS
	if hud != null:
		hud.set_ui_scale(settings.ui)
		hud.pad.modulate.a = OPACITY[settings.opacity]
		hud.set_lefty(settings.lefty)
		hud.set_filter(settings.colorblind, settings.comfort * 0.5)
		hud.set_potion_scale(settings.potion_ui)
		hud.set_text_scale(TEXT[settings.text])
	if player != null:
		player.boss_first = settings.boss_aim
	for pfx in ["", "p2_"]:
		for a in PAD_AXES:
			InputMap.action_set_deadzone(pfx + a, DEADZONES[settings.deadzone])


## Menu → Soltar personagem: quem ficou preso numa parede volta ao sítio de partida da zona.
func unstuck() -> void:
	var at: Vector2 = sep.get("start", Vector2(0, 300)) if zone == "sep" else CRYPT_ORIGIN + CRYPT_IN if zone == "crypt" else Vector2(0, 300)
	for i in players.size():
		players[i].position = at + Vector2(50 * i, 0)
	cam.position = at
	cam.reset_smoothing()


## Vibração no telemóvel e nos comandos (se estiver ligada nas Configurações).
## who = o herói a quem aconteceu (só vibra o telemóvel dele); sem who vibra em todos.
func vibrate(ms: int, strength := 0.6, who = null) -> void:
	if who != null and Net.role == "host" and who.slot == 1:
		Net.echo("main", "vibrate", [ms, strength])  # o Guardião da Wi-Fi sente-o no telemóvel dele
		return
	if who == null:
		Net.echo("main", "vibrate", [ms, strength])
	if settings.vibe == 0:
		return
	var k: float = VIBE[settings.vibe]
	strength = clampf(strength * k, 0.05, 1.0)
	ms = int(ms * minf(k, 1.3))
	Input.vibrate_handheld(ms, strength)
	for d in pad_of:
		if d >= 0:
			Input.start_joy_vibration(d, strength * 0.6, strength, ms / 1000.0)


## Lê o jogo gravado. Ficheiro em falta ou estragado: começa do zero, sem rebentar.
func _read_save() -> Dictionary:
	if not FileAccess.file_exists(SAVE_PATH):
		return {}
	var d = JSON.parse_string(FileAccess.get_file_as_string(SAVE_PATH))
	return d if d is Dictionary else {}


static func _num(v, default: float) -> float:
	return float(v) if v is int or v is float else default


## Cada valor é conferido: o que não fizer sentido fica como num jogo novo.
func _apply_save() -> void:
	level = clampi(int(_num(saved.get("level"), 1)), 1, 999)
	xp = clampi(int(_num(saved.get("xp"), 0)), 0, 1000000)
	var kl = saved.get("kills")
	if kl is Dictionary:
		for k in XP:
			if kl.has(k):
				kills[k] = clampi(int(_num(kl[k], 0)), 0, 100000000)
	# Círculos: os jogos gravados de antes deles abrem o II a quem já quebrou o Cortejo
	var hk: int = kills.get("herald", 0)
	circle_max = clampi(int(_num(saved.get("circle_max"), 2 if hk > 0 else 1)), 1, 99)
	circle = clampi(int(_num(saved.get("circle"), circle_max)), 1, circle_max)
	wins = clampi(int(_num(saved.get("wins"), hk)), 0, 100000000)
	crypt_n = clampi(int(_num(saved.get("crypt_n"), 0)), 0, 100000000)
	deep = clampi(int(_num(saved.get("deep"), 0)), 0, 100000)  # o recorde do Mausoléu (#27)
	sep_runs = clampi(int(_num(saved.get("sep_runs"), 0)), 0, 100000)
	sep_max = clampi(int(_num(saved.get("sep_max"), 0)), 0, 999)
	crypt_last = saved.crypt_last if saved.get("crypt_last") in CRYPT_RULES else ""  # morrer ou ir ao título não deixa repetir a sala
	if saved.get("camps_done") is Array:
		for i in saved.camps_done:
			var n := int(_num(i, -1.0))
			if n >= 0 and n < CAMPS_PER * 4 and not n in camps_done:
				camps_done.append(n)
	var c = saved.get("currency")
	if c is Dictionary:
		for k in currency:
			currency[k] = clampi(int(_num(c.get(k), 0)), 0, 1000000)
	var w = saved.get("weapon")
	if w is Dictionary and w.get("suffixes") is Array and String(w.get("hidden", "")) in HIDDEN:
		var suf: Array = w.suffixes.filter(func(s): return s is String and s in SUFFIXES)
		if suf.size() == 2:
			weapon = {"tier": clampi(int(_num(w.get("tier"), 0)), 0, 999), "suffixes": suf, "hidden": String(w.hidden), "sealed": w.get("sealed") != false,
				"locked": w.locked if w.get("locked") in suf else ""}  # os jogos gravados antes do Formão (#54) não o têm
	if saved.get("proven") is Array:
		for t in saved.proven:
			if t is String and TRIALS.has(t) and not t in proven:
				proven.append(t)
	if saved.get("relics") is Array:
		for r in saved.relics:
			if r is String and RELICS.has(r) and not r in relics:
				relics.append(r)
	if saved.get("flasks") is Array:
		for f in saved.flasks:
			if f is String and (f in Player.SUPPORTS or f in Player.SOULS) and not f in flasks:
				flasks.append(f)
	var t = saved.get("tomb")
	if t is Dictionary and t.get("pos") is Array and t.pos.size() == 2 and t.get("lost") is Dictionary:
		var lost := {}
		for k in currency:
			lost[k] = clampi(int(_num(t.lost.get(k), 0)), 0, 1000000)
		var pos := Vector2(_num(t.pos[0], 0.0), _num(t.pos[1], 0.0))
		if MAP.has_point(pos) and lost.values().any(func(v): return v > 0):
			tomb = {"pos": pos, "lost": lost}


func _apply_hero(p) -> void:
	var heroes = saved.get("heroes")
	var h = heroes.get(p.hero) if heroes is Dictionary else null
	if not h is Dictionary:
		return
	p.respecs = clampi(int(_num(h.get("respecs"), 0)), 0, 999)  # os jogos gravados antes de se poder refazer não o têm
	if h.get("passives") is Array:
		for id in h.passives:  # pela ordem gravada: cada nó só entra se a raiz dele já entrou (e se é deste herói, S3)
			if id is String and PASSIVES.has(id) and not id in p.passives and PASSIVES[id].req in p.passives and PASSIVES[id].get("hero", p.hero) == p.hero:
				p.passives.append(id)
	p.points = maxi(0, level + relics.size() - p.passives.size())  # os pontos vêm do nível e das Relíquias (#58): cada nó comprado gastou um (a Raiz é de graça)
	if h.get("supports") is Dictionary:
		for id in p.order:
			if h.supports.get(id) in p.SUPPORTS and not (id == p.order[0] and h.supports[id] in p.CURSED):
				p.skills[id].support = h.supports[id]
		if p.cursed_lock() != "":  # Frascos Malditos (#21): a habilidade presa fica vazia (com dois malditos, sai o segundo)
			p.skills[p.cursed_lock()].support = ""
	if h.get("soul") in p.SOULS:  # os jogos gravados antes das Almas Condensadas não a têm: fica sem nenhuma
		p.soul = h.soul
	p.gear = {}  # Equipamento (0.4.8): os jogos gravados de antes não o têm e ficam com os 4 lugares vazios
	p.bag = []
	if h.get("gear") is Dictionary:
		for s in Player.SLOTS:  # só os 4 lugares, e cada peça no lugar dela
			var it = h.gear.get(s)
			if Player.gear_ok(it) and Player.gear_slot(it) == s:
				p.gear[s] = it
	if h.get("bag") is Array:
		for it in h.bag:
			if Player.gear_ok(it) and p.bag.size() < Player.BAG_MAX:
				p.bag.append(it)


# ---------- Arma & moedas ----------

func stat(key: String) -> float:
	if trial_on("lamina"):  # Provação da Lâmina Cega (#214): nem sufixos, nem oculto, nem reforja
		return 0.0
	var v := 0.0
	for s in weapon.suffixes:
		v += SUFFIXES[s].get(key, 0.0)
	if not weapon.sealed:
		v += HIDDEN[weapon.hidden].get(key, 0.0)
	if key == "dmg":
		v += weapon.tier * 0.1
	return v


func weapon_text() -> String:
	# os sufixos e a propriedade oculta gravam-se em português: só se traduzem aqui, ao mostrar
	var hid: String = tr("[SELADO — usa Cinzas]") if weapon.sealed else tr(weapon.hidden)
	return tr("Foice do Coveiro +%d  %s\nOculto: %s") % [weapon.tier, ", ".join(weapon.suffixes.map(func(s): return tr("%s (travado)") % tr(s) if s == weapon.locked else tr(s))), hid]


func _reroll_weapon() -> void:
	var keys := SUFFIXES.keys()
	keys.shuffle()
	var i: int = weapon.suffixes.find(weapon.locked)
	if i >= 0:  # Formão (#54): o sufixo travado fica no sítio e só o outro se sorteia
		keys.erase(weapon.locked)
		weapon.suffixes[1 - i] = keys[0]
	else:
		weapon.suffixes = keys.slice(0, 2)
	weapon.hidden = HIDDEN.keys()[rng.randi() % HIDDEN.size()]
	weapon.sealed = true


func use_currency(kind: String) -> String:
	match kind:
		"ink":
			if currency.ink < 1:
				return "Sem Tinteiros de Sangue Negro."
			currency.ink -= 1
			_reroll_weapon()
			return "Novos sufixos sorteados — a propriedade oculta foi selada de novo."
		"ash":
			if not weapon.sealed:
				return "Nada selado para revelar."
			if currency.ash < 1:
				return "Sem Cinzas do Purgatório."
			currency.ash -= 1
			weapon.sealed = false
			return tr("Revelado: %s") % tr(weapon.hidden)
		"bone":
			if currency.bone < 5:
				return "Precisas de 5 Ossos Ancestrais."
			currency.bone -= 5
			weapon.tier += 1
			return tr("Foice reforjada: +%d") % weapon.tier
		"lock0", "lock1":  # Formão Cadavérico (#54): trava um dos dois sufixos (o Tinteiro sorteia só o outro)
			if currency.formao < 1:
				return "Sem Formões Cadavéricos."
			currency.formao -= 1
			weapon.locked = weapon.suffixes[int(kind[4])]
			return tr("Travaste o sufixo «%s».") % tr(weapon.locked)
		"unlock":  # destravar é de graça
			if weapon.locked == "":
				return "Nenhum sufixo travado."
			var was: String = weapon.locked
			weapon.locked = ""
			return tr("Destravaste o sufixo «%s».") % tr(was)
		"carmesim":  # Tinteiro Carmesim (#59): troca só os sufixos de ataque destravados, sem voltar a selar a propriedade oculta
			if currency.carmesim < 1:
				return "Sem Tinteiros Carmesim."
			var swap := range(2).filter(func(n): return weapon.suffixes[n] in OFFENSIVE and weapon.suffixes[n] != weapon.locked)
			if swap.is_empty():
				return "Sem sufixos de ataque para trocar."
			currency.carmesim -= 1
			var pool: Array = OFFENSIVE.filter(func(s): return not s in weapon.suffixes)  # pelo menos 3: cada troca é diferente
			pool.shuffle()
			for n in swap:
				weapon.suffixes[n] = pool.pop_back()
			return "Novos sufixos de ataque sorteados."
		"pena_bone", "pena_ink", "pena_ash":  # Pena de Abutre (#239): 75% a pilha dobra (até 1 000 000), 25% arde toda
			var k := kind.substr(5)
			if currency.pena < 1:
				return "Sem Penas de Abutre."
			if currency[k] < 1:
				return tr("Sem %s para arriscar.") % tr(PILES[k])
			currency.pena -= 1
			if rng.randf() < 0.75:
				currency[k] = mini(currency[k] * 2, 1000000)
				spawn_fx("ring", player.position, 130.0, Color(1.0, 0.85, 0.4))
				return tr("A Pena brilha: %s a dobrar!") % tr(PILES[k])
			var lost: int = currency[k]
			currency[k] = 0
			spawn_fx("dust", player.position, 70.0, Color(0.55, 0.5, 0.45))
			return tr("A Pena ardeu: perdeste %d %s.") % [lost, tr(PILES[k] if lost > 1 else "Cinza do Purgatório" if k == "ash" else Loot.INFO[k][0])]  # no saque, Cinzas é o monte
	return ""


## Forja contínua (#100): gasta Tinteiros, um a um, até sair o sufixo s (no máximo 200 de uma vez); o travado fica.
func forge_until(s: String) -> String:
	if s in weapon.suffixes:
		return tr("Já tens o sufixo «%s».") % tr(s)
	var n := 0
	while n < 200 and currency.ink > 0 and not s in weapon.suffixes:
		use_currency("ink")
		n += 1
	if n == 0:
		return "Sem Tinteiros de Sangue Negro."
	if s in weapon.suffixes:
		return tr("Saiu o sufixo «%s» ao primeiro Tinteiro.") % tr(s) if n == 1 else tr("Saiu o sufixo «%s» ao fim de %d Tinteiros.") % [tr(s), n]
	return tr("Acabaram os Tinteiros sem sair o sufixo «%s» (gastaste %d).") % [tr(s), n]


## kind "flask" com flask = o Frasco de Alma (veloz, eco, tumular, colerica).
func drop(kind: String, pos: Vector2, amount := 1, pop := Vector2.ZERO, flask := ""):
	var l := Loot.new()
	l.main = self
	l.kind = kind
	l.amount = amount
	l.pop = pop
	l.flask = flask
	l.position = pos + Vector2(rng.randf_range(-30, 30), rng.randf_range(-20, 20))
	add_child(l)  # o som de cair é do saque (loot.gd _drop_sound): cada telemóvel toca o seu
	shake = maxf(shake, l.weight())  # o raro treme o ecrã (o equipamento, pela raridade)
	return l


## Um reagente da Forja ao acaso (S2).
func _reagent() -> String:
	return Loot.REAGENTS[rng.randi() % Loot.REAGENTS.size()]


## Uma peça de equipamento no chão (0.4.8): o item vai no campo flask, como as relíquias. Com mais de GEAR_FLOOR no chão,
## esta vai logo para o herói mais perto.
func drop_gear(it: String, pos: Vector2, pop := Vector2.ZERO):
	var l = drop("gear", pos, 1, pop, it)
	if get_tree().get_nodes_in_group("loot").filter(func(o): return o.kind == "gear" and not o.is_queued_for_deletion()).size() > GEAR_FLOOR:  # as apanhadas neste frame ainda estão no grupo (como main:1407 e net:243)
		collect(l)
	return l


## Uma peça nova de raridade r (0 comum, 1 mágica, 2 rara, 3 única): a base ao calhas e r afixos diferentes, nunca o da
## base. Um único que o grupo já tenha (_unique_taken) não se repete: sem nenhum livre, sai uma rara.
func roll_gear(r: int) -> String:
	if r == 3:
		var free: Array = Player.UNIQUES.filter(func(u): return not _unique_taken(u))
		if not free.is_empty():
			return free[rng.randi() % free.size()] + ":3"
		r = 2
	var b: String = Player.BASES[rng.randi() % Player.BASES.size()]
	var keys: Array = Player.AFFIX.keys().filter(func(k): return k != Player.GEAR[b].key)
	var it := b + ":" + str(r)
	for i in r:
		it += ":" + keys.pop_at(rng.randi() % keys.size())
	return it


## Um único já é do grupo? Posto ou na mochila de quem joga, no jogo gravado do herói que não está a jogar (só existe em
## saved.heroes, main:1002), ou ainda no chão (os que vão sair não contam).
func _unique_taken(u: String) -> bool:
	var it := u + ":3"
	var held := []
	for q in players:
		held += q.gear.values() + q.bag
	var hs = saved.get("heroes")
	for id in Player.HEROES:
		var h = hs.get(id) if hs is Dictionary else null
		if h is Dictionary and not players.any(func(q): return q.hero == id):
			held += (h.gear.values() if h.get("gear") is Dictionary else []) + (h.bag if h.get("bag") is Array else [])
	return it in held or get_tree().get_nodes_in_group("loot").any(func(l): return l.kind == "gear" and l.flask == it and not l.is_queued_for_deletion())


## O equipamento que a morte de e larga (GEAR_DROP): os chefes com nome primeiro, depois os outros chefes, os elites e o resto.
func _drop_gear(e, named: bool) -> void:
	var row: Array = GEAR_DROP.named if named else GEAR_DROP.boss if e.is_boss else GEAR_DROP.elite if e.elite else GEAR_DROP.normal
	if not gear_drops or rng.randf() >= row[0]:
		return
	var x := rng.randf()
	var r: int = 3 if named and rng.randf() < GEAR_UNIQUE else 0 if x < row[1] else 1 if x < row[1] + row[2] else 2
	drop_gear(roll_gear(r), e.position, Vector2.from_angle(rng.randf() * TAU) * 140.0)


func collect(l) -> void:
	if l.is_queued_for_deletion():
		return  # já apanhada neste frame (ao mudar de zona e por estar perto)
	var to = nearest_player(l.position)
	if to != null and fx_budget("pickup", 4, 12):  # voa para o peito do herói e rebenta em faíscas, mais quanto mais raro
		var f := spawn_fx("pickup", l.position, 0.0 if l.kind == "bone" and l.amount == 1 else 14.0 if l.kind in ["ash", "flask", "relic", "transitoria", "coracao", "gear"] or l.kind in Loot.REAGENTS else 10.0 if l.kind == "ink" else 6.0, l.color(), Vector2.RIGHT, Player.RARITY_RAMP[l.rarity()] if l.kind == "gear" else Loot.RAMP[l.kind])
		f.follow = to.slot
		f.item = l.flask if l.kind == "flask" else l.flask.get_slice(":", 0) if l.kind == "gear" else l.kind
	if l.has_meta("prova") and not "almas" in proven:  # o Frasco da 1.ª vitória na Provação das Almas (#37)
		proven.append("almas")
	if l.kind == "blood":  # Hemofilia Espiritual: cura 5% da vida a quem o apanha
		var p = nearest_player(l.position)
		if p != null:
			p.heal(p.max_hp * 0.05)
			spawn_fx("glow", p.position + Vector2(0, -40), 55.0, Color(0.85, 0.12, 0.18))
			sfx("potion")
	elif l.kind == "soul":  # Sem Alma Própria (#132): 30% da alma ao herói mais perto que tenha a chave (o Guardião não a desperdiça)
		var keyed := players.filter(func(q): return not q.dead and q.stat("semalma") > 0.0)
		keyed.sort_custom(func(a, b): return a.position.distance_to(l.position) < b.position.distance_to(l.position))
		var p = keyed[0] if not keyed.is_empty() else nearest_player(l.position)
		if p != null:
			p.add_mana(p.max_mana * 0.3)  # com a Mente Fragmentada (#108) enche a poção de alma
			spawn_fx("glow", p.position + Vector2(0, -40), 55.0, Color(0.35, 0.7, 1.0))
			sfx("potion")
	elif l.kind == "transitoria":  # Alma Transitória (#4): uma alma de um só uso para o herói mais perto, durante 60 s
		var p = nearest_player(l.position)
		if p != null:
			p.trans_kind = Player.TRANS.keys()[rng.randi() % Player.TRANS.size()]
			p.trans_until = time + Player.TRANS_T
			hud.toast(tr("O %s apanhou uma Alma Transitória: %s!\nToca no botão dela (no comando, LS) para a libertar antes de 60 s.") % [tr(p.hero_name), tr(Player.TRANS[p.trans_kind])])  # com o nome: o aviso chega aos dois telemóveis
			sfx("chest")
	elif l.kind == "relic":  # Relíquia de Família (#58): +1 ponto na Árvore a cada herói; repetida vale ossos
		if l.flask in relics:
			currency.bone += 5
		else:
			relics.append(l.flask)
			for q in players:
				q.points += 1
			hud.name_card("Relíquia encontrada", RELICS[l.flask][0], "")  # sem o "Chefe" por cima
			hud.toast(RELICS[l.flask][1])
			sfx("chest")
			save_game()
	elif l.kind == "coracao":  # Coração de Titã (#70): diz onde se oferece
		currency.coracao += l.amount
		hud.toast("Coração de Titã Petrificado!\nOferece-o no altar do cemitério para acordar o Titã.")
		sfx("chest")
	elif l.kind == "gear":  # Equipamento (0.4.8): para quem está mais perto (to, main:1409); com todos caídos (Mausoléu, main:718), para o 1.º: nada se perde
		var q = to if to != null else players[0]
		var msg: String = q.take_gear(l.flask)
		if msg != "":  # a comum desfeita logo não avisa (só o número por cima do herói)
			hud.toast(msg)  # com o nome do herói: o aviso chega aos dois telemóveis (hud:605-607)
		if l.rarity() == 3:
			hud.name_card("Peça única encontrada", Player.gear_name(l.flask), "")  # como a relíquia (main:1444)
		if l.rarity() >= 2:
			sfx("chest")
	elif l.kind != "flask":
		currency[l.kind] += l.amount
	elif l.flask in flasks:
		currency.bone += 5  # repetido: vale ossos
	else:
		flasks.append(l.flask)
		hud.toast(tr("Encontraste o %s!\nPõe-no numa habilidade no Arsenal (não no golpe básico)." if l.flask in Player.CURSED else "Encontraste a %s! Põe-na numa habilidade no Arsenal." if l.flask in Player.SUPPORTS else "Encontraste uma Alma Condensada: %s! Equipa-a no Arsenal.") % tr(Player.SUPPORT_NAMES[l.flask]))
		sfx("chest")
		save_game()
	l.queue_free()


## Alma Tumular: o inimigo ergue-se como esqueleto do herói. No máximo 4; o mais antigo desfaz-se.
func spawn_ally(pos: Vector2, by, half := false) -> Node2D:
	var allies := get_tree().get_nodes_in_group("allies").filter(func(a): return a.life > 0.0)  # os desfeitos neste frame já não contam (a Mitótica ergue dois de uma vez)
	if allies.size() >= MAX_ALLIES:
		allies[0].life = 0.0
	var a := Ally.new()
	a.main = self
	a.owner_p = by
	a.half = half
	if by.stat("canibal") > 0.0:  # Canibalismo Espiritual (#122): lacaios de 4 s, para serem comidos depressa
		a.life = 4.0
	a.kind = "arqueiro" if by.stat("arqueiros") > 0.0 else "guarda" if by.stat("guardioes") > 0.0 else ""  # Esqueletos especializados (#11)
	a.position = pos
	add_child(a)
	return a


# ---------- Combate ----------

func enemies() -> Array:
	return get_tree().get_nodes_in_group("enemies")


func spawn_enemy(kind: String, pos: Vector2, mods: Dictionary, in_cortejo: bool):
	var e := Enemy.new()
	e.main = self
	e.cortejo = in_cortejo
	e.position = pos
	e.setup(kind, mods)
	e.killed.connect(_on_enemy_killed)
	add_child(e)
	return e


## ramp e ground só servem os efeitos em píxeis (fx.gd): a rampa de cores pelo nome e o chão em relação a pos.
func spawn_fx(kind: String, pos: Vector2, radius: float, color: Color, dir := Vector2.RIGHT, ramp := "", ground := 0.0) -> Fx:
	var f := Fx.new()
	f.kind = kind
	f.radius = radius
	f.color = color
	f.dir = dir
	f.position = pos
	f.amount = EFFECTS[effects_level()]
	f.alpha = FX_ALPHA[settings.fx_alpha]
	f.seed = randi()  # viaja ao convidado: o mesmo desenho dos dois lados (randi e não rng: não mexe nos críticos)
	f.ramp = ramp
	f.ground = ground
	add_child(f)
	return f


## Efeitos em píxeis por frame: um golpe pode acertar em 20, só os primeiros `cap` têm o efeito inteiro e os outros ficam
## com o antigo; e no máximo `live` vivos ao mesmo tempo (o sangue fica 5 s no chão). Com efeitos baixos, sempre o antigo.
func fx_budget(kind: String, cap: int, live: int) -> bool:
	if effects_level() == 0 or get_tree().get_node_count_in_group("px_" + kind) >= live:
		return false
	if Engine.get_process_frames() != fx_frame:
		fx_frame = Engine.get_process_frames()
		fx_count.clear()
	fx_count[kind] = fx_count.get(kind, 0) + 1
	return fx_count[kind] <= cap


func spawn_bolt(pos: Vector2, dir: Vector2, dmg: float, r: float, by, raise := 0, bone := false) -> Node2D:
	var b := Bolt.new()
	b.main = self
	b.by = by
	b.raise = raise
	b.bone = bone
	b.dir = dir
	b.dmg = dmg
	b.r = r
	b.position = pos + dir * 20.0
	add_child(b)
	return b


## Sentinelas Tumulares (#25): cada lápide fincada pela esquiva dispara um estilhaço de osso ao monstro mais perto (até 420 px)
## a cada 1,5 s. Guarda horas, não contadores: a lista só muda (e só vai ao convidado) ao fincar, disparar ou desfazer-se.
func _sentinels() -> void:
	for i in range(sentinels.size() - 1, -1, -1):
		var s: Array = sentinels[i]
		if s[1] <= time:
			sentinels.remove_at(i)
			continue
		if s[2] > time:
			continue
		s[2] = time + 1.5
		var best = null
		var best_d := 420.0
		for e in enemies():  # quem está a morrer já saiu do grupo
			var d: float = s[0].distance_to(e.position)
			if d < best_d:
				best_d = d
				best = e
		# o tiro conta como do herói que a fincou; se ele caiu (ou saiu da sala), do herói vivo mais perto
		var by = players[s[3]] if s[3] < players.size() and not players[s[3]].dead else nearest_player(s[0])
		if best == null or by == null:
			continue
		var from: Vector2 = s[0] + Vector2(0, -30)
		var dir := from.direction_to(best.position + Vector2(0, -20))
		spawn_bolt(from, dir, 8.0 + 1.5 * level, 10.0, by, 0, true).seek = best
		spawn_fx("sparks", from, 0.0, Color(0.95, 0.9, 0.75), dir)


## Escriba da Agonia (#155): a cada 90 px andados, o herói com a alma inscreve uma runa oculta (até 6 no grupo, 10 s); o
## primeiro monstro que a pise rebenta-a (dano em 80 px). Ocultas: o anel e os números são o único aviso.
func _runes() -> void:
	for p in players:
		if p.soul == "escriba" and not p.dead and p.position.distance_to(p.rune_at) >= 90.0:  # parado não escreve
			p.rune_at = p.position
			runes.append([p.position, time + 10.0, p.slot])
			if runes.size() > 6:
				runes.pop_front()
	while not runes.is_empty() and runes[0][1] <= time:  # todas duram 10 s: a mais antiga sai primeiro
		runes.pop_front()
	if runes.is_empty():
		return
	var foes := enemies()  # uma vez por frame: no máximo 6 runas × monstros
	for i in range(runes.size() - 1, -1, -1):
		var r: Array = runes[i]
		for e in foes:
			# o boneco de treino não anda (nunca pisa); quem morreu numa runa anterior deste frame já não conta
			if not e.dying and not e.dummy and r[0].distance_to(e.position) <= 20.0 + e.radius:
				runes.remove_at(i)
				# conta como do herói que a escreveu; se ele caiu (ou saiu da sala), do herói vivo mais perto
				var by = players[r[2]] if r[2] < players.size() and not players[r[2]].dead else nearest_player(r[0])
				if by != null:
					hit_circle(r[0], 80.0, 16.0 + 3.0 * level, by)
				spawn_fx("ring", r[0], 80.0, Color(0.9, 0.2, 0.25))  # o vermelho do cristal
				break


## Devolve [dano, crítico]. O inimigo trata do flash, número, faíscas e recuo. phys: golpe físico (foice, machado, Ceifa de Ossos).
func _damage(e, dmg: float, by, from: Vector2, phys := false) -> Array:
	if e.is_boss:
		dmg *= 1.0 + by.stat("boss")
	dmg *= 1.0 - e.armor * (0.6 if cast_support == "voraz" else 1.0)  # armadura (Colossos e Arauto); a Alma Voraz (#141) fura 40% dela
	if e.exposed_t > 0.0:
		dmg *= 3.0
	if e.stagger_t > 0.0:
		dmg *= 1.5
	if e.necro > 0:  # Necrose Galopante (#154): cada camada já posta faz levar +5%
		dmg *= 1.0 + e.necro * 0.05
	if e.rot_t > 0.0:  # Febre Sepulcral (#171): o podre que se mexe leva mais (esqueleto a andar +30%, até +60%)
		dmg *= 1.0 + minf(0.6, 0.3 * e.stride * e.speed / 85.0)
	if by.stat("rot") > 0.0:
		e.apply_rot(dmg * 0.3 * by.stat("rot"))
	if by.stat("calcify") > 0.0:
		e.add_calc()
	if by.stat("necro") > 0.0:
		e.add_necro()
	if phys and by.stat("garras") > 0.0:  # Garras do Coveiro Insone (#226): os golpes físicos prendem-lhe os pés (a 60% durante 1,5 s, enemy:343 e enemy:378; não se desenha nada)
		e.slow_t = maxf(e.slow_t, 1.5)
	match cast_aff:  # Alma Caótica (#147): uma camada do estado da vez, como os sufixos a 1,0
		1:
			e.apply_rot(dmg * 0.3)
		2:
			e.add_necro()
		3:
			e.add_calc()
	var crit: bool = rng.randf() < CRIT + by.stat("crit") + (0.35 if by.overload_t > 0.0 else 0.0)  # Sobrecarga de Alma: +35% de crítico; as peças (0.4.8) somam o delas
	if crit:
		dmg *= CRIT_MULT
	var dir: Vector2 = from.direction_to(e.position) if from.distance_to(e.position) > 1.0 else Vector2.from_angle(rng.randf() * TAU)
	if cast_support == "gravidade":  # Alma Gravitacional: puxa para o centro do golpe em vez de empurrar (nunca para lá dele)
		dir = -dir * minf(1.5, from.distance_to(e.position) / 120.0)  # /120: nem um crítico a 10 FPS o atira para lá do herói
	# Hemofilia Espiritual (#162): crítico em quem sangra deixa cair um orbe de sangue que cura (no máximo 6 no chão)
	if crit and e.bleed_t > 0.0 and not e.dummy and by.stat("hemo") > 0.0:
		if get_tree().get_nodes_in_group("loot").filter(func(l): return l.kind == "blood").size() < 6:
			drop("blood", e.position, 1, dir * 90.0)
	# Hemorragia Ectoplasmática (#110): crítico em quem sangra dá +3 s aos lacaios a 200 px (4 m); sem vida, curá-los é
	# dar-lhes tempo, até ao de um lacaio novo (4 s com o Canibalismo, como no banquete da Comunhão)
	if crit and e.bleed_t > 0.0 and not e.dummy and by.stat("ecto") > 0.0:
		for a in get_tree().get_nodes_in_group("allies"):
			var top: float = 4.0 if is_instance_valid(a.owner_p) and a.owner_p.stat("canibal") > 0.0 else Ally.LIFE
			if a.life > 0.0 and a.life < top and a.position.distance_to(e.position) < 200.0:  # life 0: mandado embora pelo tecto de 4, não volta
				a.life = minf(a.life + 3.0, top)
				spawn_fx("glow", a.position, 40.0, Color(0.4, 1.0, 0.65))  # o verde dos lacaios
	e.raise_owner = raise_by  # o último golpe decide se ele se ergue como aliado
	e.raise_n = raise_n
	e.hit_by = by  # e o frasco do golpe: o abate (_on_enemy_killed) lê-os, por isso ficam antes do take_damage
	e.hit_support = cast_support
	e.hit_phys = phys  # Exumação Espontânea (#102): só o abate físico ergue
	e.take_damage(dmg, true, dir, crit)
	return [dmg, crit]


## bleeds: os círculos que sangram são os do corpo a corpo (rodopio do machado, Ceifa de Ossos), logo físicos.
func hit_circle(origin: Vector2, radius: float, dmg: float, by, bleeds := false) -> void:
	var hits := []
	var struck := []  # em quem bateu (os arcos da Alma Biomecânica, #144)
	for e in enemies():
		if e.dying:  # morto a meio deste golpe (estilhaços do Frio do Purgatório): já não conta para o roubo de vida
			continue
		if e.position.distance_to(origin) <= radius + e.radius:
			hits.append(_damage(e, dmg, by, origin, bleeds))
			struck.append(e)
			if bleeds and by.stat("frio") <= 0.0:  # Frio do Purgatório (#104): calcifica em vez de sangrar
				e.apply_bleed(dmg * (0.35 + by.stat("bleed")), 3.0)
			if bleeds and by.stat("carrasco") > 0.0 and e.executable(by):  # Carrasco de Sangue Negro (#124): o rodopio do machado e a Ceifa de Ossos também executam
				soul_strike(e, by)
			if cast_support == "terramoto" and not e.dying and not e.dummy:  # Alma Sísmica (#173): braços de osso saem da fissura e prendem-no (o boneco não: parado, o dano por segundo saía errado)
				if e.is_boss:  # os chefes só abrandam, como nos Ecos (#114)
					e.slow_t = maxf(e.slow_t, 2.0)
				else:  # estátua e não quebrado: o quebrado deixava extrair a Alma Ancestral
					e.statue_t = maxf(e.statue_t, 1.0)
				spawn_fx("dust", e.position, 40.0, Color(0.8, 0.8, 0.75))  # a poeira cinzenta da estátua (sem arte nova)
	_impact(hits, by)
	_arcs(struck, origin, dmg, by)
	_strike_corpses(origin, radius)
	_arm_rocks(origin, radius)


## "Sangue e Osso": cada golpe corpo a corpo amaldiçoa com sangramento.
func hit_arc(origin: Vector2, dir: Vector2, radius: float, dmg: float, by) -> void:
	var hits := []
	var struck := []
	var exe: bool = by.stat("carrasco") > 0.0  # Carrasco de Sangue Negro (#124): o machado executa sozinho abaixo de 20%
	for e in enemies():
		if e.dying:
			continue
		var v: Vector2 = e.position - origin
		if v.length() <= radius + e.radius and (v.length() < 24.0 or absf(dir.angle_to(v)) < 1.3):
			hits.append(_damage(e, dmg, by, origin, true))
			struck.append(e)
			if by.stat("frio") <= 0.0:  # Frio do Purgatório (#104): o golpe calcifica em vez de sangrar
				e.apply_bleed(dmg * (0.35 + by.stat("bleed")), 3.0)
			if by.stat("sede") > 0.0:  # Sede Ancestral (#135): a foice e o machado bebem-lhe a vida durante 4 s
				e.drain_t = 4.0
				e.drain_by = by
			if exe and e.executable(by):
				soul_strike(e, by)
	_impact(hits, by)
	_arcs(struck, origin, dmg, by)
	_strike_corpses(origin, radius)


## Alma Biomecânica (#144): de cada alvo do golpe (até 3) saltam arcos de raio para os 2 monstros mais perto ainda por
## acertar (até 160 px), com 40% do dano; na volta da Ceifa de Ossos (chain_all, #153) ligam em roda, por ângulo, todos
## os que ela apanhou (25%). Os arcos não soltam mais arcos (arcing).
func _arcs(struck: Array, origin: Vector2, dmg: float, by) -> void:
	if cast_support != "biomecanica" or arcing or struck.is_empty():
		return
	arcing = true
	var links := []  # [de, para, parte do dano]
	if chain_all:
		struck.sort_custom(func(a, b): return origin.angle_to_point(a.position) < origin.angle_to_point(b.position))
		var n := struck.size()
		for i in (n if n > 2 else n - 1):  # com 3 ou mais fecha a roda; com 2 é um arco só
			links.append([struck[i], struck[(i + 1) % n], 0.25])
	else:
		var done := struck.duplicate()
		for s in struck.slice(0, 3):
			var near := enemies().filter(func(o): return not o in done and o.position.distance_to(s.position) < 160.0)
			near.sort_custom(func(a, b): return a.position.distance_squared_to(s.position) < b.position.distance_squared_to(s.position))
			for o in near.slice(0, 2):
				done.append(o)
				links.append([s, o, 0.4])
	for l in links:
		if not l[1].dying:  # morto por um arco anterior
			_damage(l[1], dmg * l[2], by, l[0].position)
			spawn_fx("arc", l[0].position + Vector2(0, -30), l[0].position.distance_to(l[1].position), Color(0.7, 0.5, 1.0), l[0].position.direction_to(l[1].position))
	arcing = false


## Um golpe = um tremor, um congelar e um som, mesmo que acerte em 20 inimigos.
## Crítico: congela mais, zoom de impacto e flash no ecrã.
func _impact(hits: Array, by) -> void:
	if hits.is_empty():
		return
	var dealt := 0.0
	var crit := false
	for h in hits:
		dealt += h[0]
		crit = crit or h[1]
	if cast_support == "eter" and not by.dead:  # Alma de Éter (#164): o roubo de vida, mais 5% do dano, volta como alma
		var gain: float = dealt * (0.05 + by.stat("leech"))
		by.add_mana(gain)
		if gain >= 1.0:  # só golpes que se notam: sem brilho a cada arranhão
			spawn_fx("glow", by.position + Vector2(0, -40), 40.0, Color(0.35, 0.7, 1.0))
	else:
		by.heal(dealt * by.stat("leech"))
	if quiet:
		return
	shake = maxf(shake, 9.0 if crit else 4.0)
	hitstop(0.08 if crit else 0.045)
	sfx("crit" if crit else "hit")
	if crit:
		zoom_kick = maxf(zoom_kick, 0.06)
		hud.flash(0.22)
		vibrate(35, 0.5, by)


func hitstop(dur: float) -> void:
	if Engine.time_scale < 1.0:
		return
	Engine.time_scale = 0.05
	await get_tree().create_timer(dur, true, false, true).timeout
	Engine.time_scale = 1.0


## `pitch` > 0 fixa o tom (o tinido do saque sobe com a raridade); 0 = variação aleatória de sempre.
## local: só neste telemóvel (o saque a cair toca em cada um, com o filtro de cada um).
func sfx(name: String, pitch := 0.0, local := false) -> void:
	if not local:
		Net.echo("main", "sfx", [name, pitch])
	var now := Time.get_ticks_msec()
	var key := name + str(pitch)  # tons diferentes no mesmo frame (saque do chefe) não se calam uns aos outros
	# o toque de vitória dura 3,5 s: o Arauto e o fim da onda não o tocam por cima; mortes e golpes em série (uma
	# Explosão que mata 20) soavam a metralhadora: no máximo um a cada 90 ms
	if now - sfx_last.get(key, -10000) < (3000 if name == "victory" else 90 if name in ["die", "swing"] else 40):
		return
	sfx_last[key] = now
	var a := AudioStreamPlayer.new()
	a.stream = SFX[name]
	a.pitch_scale = pitch if pitch > 0.0 else randf_range(0.9, 1.12)
	a.volume_db = -4.0
	a.bus = "Efeitos"
	a.finished.connect(a.queue_free)
	add_child(a)
	a.play()


## Troca de faixa em fusão: a nova entra em `music` (a que se ouve) e a antiga apaga-se em `music_b`.
## Sem fade explícito, o chefe entra depressa (os sinos do Arauto tocam por cima) e sai devagar.
func play_track(id: String, fade := -1.0) -> void:
	if id == track or not MUSIC.has(id):  # (o anfitrião acabado de recomeçar ainda manda "")
		return
	if fade < 0.0:
		fade = 0.3 if id == "boss" else 2.5 if track == "boss" else 1.5
	track = id
	if music_tw:
		music_tw.kill()  # senão o fim da fusão antiga calava a faixa nova (mundo → chefe → mundo depressa)
	music_b.stop()
	var old := music
	music = music_b
	music_b = old
	music.stream = MUSIC[id]
	music.volume_db = -40.0
	music.play()
	music_tw = create_tween().set_pause_mode(Tween.TWEEN_PAUSE_PROCESS).set_parallel()  # corre com o jogo em pausa
	music_tw.tween_property(music, "volume_db", MUSIC_DB[id], fade)
	if music_b.playing:
		music_tw.tween_property(music_b, "volume_db", -40.0, fade)
		music_tw.chain().tween_callback(music_b.stop)


## A faixa de agora: o chefe manda, depois o Cortejo (a marcha segue entre ondas), depois a zona.
## Só quem simula escolhe; o convidado recebe-a em "track".
func _music_pick() -> void:
	var id := "boss" if (arena_r > 0.0 and mausoleum % 10 == 0) or (is_instance_valid(guardian) and guardian_met) else "cortejo" if cortejo.wave > 0 or mausoleum > 0 else "world" if zone == "world" else "crypt"
	play_track(id)


func number(pos: Vector2, text: String, size: float, color: Color):
	var f := Fx.new()
	f.kind = "num"
	f.text = text
	f.radius = size
	f.color = color
	f.position = pos
	f.visible = settings.numbers
	add_child(f)
	return f


func _on_enemy_killed(e) -> void:
	# Fúria Póstuma (#169): quem mata a tempo volta com 20% da vida (antes das curas do abate, que a Fúria já não trava; a
	# Estátua Funerária e a Alma Rebelde também contam)
	if is_instance_valid(e.hit_by) and e.hit_by.furia_until > time:
		e.hit_by.furia_until = 0.0
		e.hit_by.hp = maxf(e.hit_by.hp, e.hit_by.max_hp * 0.2)
		number(e.hit_by.position + Vector2(0, -130), tr("De volta!"), 22.0, Color(1.0, 0.35, 0.3))
	if e.anchor:  # uma Estátua Funerária do Guardião (#204): só 5 de XP, sem saque nem cadáver, e não conta no Bestiário
		gain_xp(5)
		return
	if e.expire_at > 0.0:  # uma Alma Rebelde (#196) morta antes de rebentar: nem XP nem saque
		return
	var named: bool = (e == guardian and (zone != "sep" or sep_depth() % 5 == 0)) or e.kind == "herald" or e.boss != ""  # os chefes com nome (S2, S7): reagentes e relíquias (a Sentinela não)
	if e.is_boss:  # antes do XP: a pausa longa do chefe ganha à curta da subida de nível (hitstop ignora a segunda)
		shake = 16.0
		hitstop(0.18)
	gain_xp(XP[e.kind] * (5 if e.elite else 1) * (1 + (e.tier + 1) / 2))  # Elites (#277): o quíntuplo; e mais longe da praça, mais (tier 1 e 2: o dobro)
	if e.boss == "":  # o Bestiário conta os 4 mortos de sempre; os chefes com nome (S7) não
		var row: String = e.skin if e.skin != "" else e.kind  # cada morto na sua linha do Bestiário: um Enforcado não conta como Esqueleto
		kills[row] = kills.get(row, 0) + 1
	if e.title == "Gigante Errante":  # o próximo só daqui a 20 s
		giant_at = time + 20.0
	if e.elite and crypt_rule == "miasma" and breath_end < INF:  # Abismo do Miasma (#38): cada elite dá mais 20 s de ar (até 60)
		breath_end = minf(maxf(breath_end, time) + 20.0, time + 60.0)
		number(e.position + Vector2(0, e._top() - 40.0), tr("Sopro de Vida! +20 s"), 22.0, Color(0.5, 1.0, 0.55))
		spawn_fx("ring", e.position, 140.0, Color(0.5, 1.0, 0.55))
	if (e.kind == "herald" and e.boss == "") or e.boss == "guardiao":  # o chefe do Cortejo: o Arauto ou o Guardião dos Monumentos (#204)
		sfx("victory")
		hud.card_t = minf(hud.card_t, 0.4)
		if mausoleum > 0 or zone == "sep":  # no Mausoléu (#27) é o chefe do piso: o piso acaba e a arena fica; nos Sepulcros também não é o Cortejo que vacila
			floor_end = time
			hud.toast(tr("O %s caiu!") % tr(e.who()))
		else:
			arena_r = 0.0
			hud.toast("O Guardião dos Monumentos caiu! O Cortejo vacila..." if e.boss == "guardiao" else "O Arauto Fúnebre caiu! O Cortejo vacila...")
		if e.boss == "guardiao":
			for o in enemies():  # as estátuas caem com ele
				if o.anchor:
					o.queue_free()
		if e.boss == "" and not "maldito_arauto" in flasks:  # o Frasco Maldito dele (#21), sempre, enquanto o grupo não o tiver
			drop("flask", e.position, 1, Vector2.from_angle(rng.randf() * TAU) * 120.0, "maldito_arauto")
	if e == guardian:
		guardian = null
		sfx("victory")
		hud.card_t = minf(hud.card_t, 0.4)
		if zone == "sep":
			_sep_boss_down(e)
		else:
			var m := loot_mult(level)
			var rew := [["bone", int(6 * m)], ["ink", 2 + level / 3], ["ash", 1 + level / 4]]
			if rng.randf() < 0.5:  # e um reagente da Forja (S2), uma vez em duas
				rew.append([_reagent(), 1])
			if rng.randf() < 0.2:  # e o Coração de Titã (#70), uma vez em cinco
				rew.append(["coracao", 1])
			_spawn_chest(rew, e.position + Vector2(0, 40))
			hud.toast(tr("O %s caiu! O relicário da cripta está livre.") % tr(e.who()))
			if e.boss == "" and not "maldito_carcereiro" in flasks:  # o Frasco Maldito dele (#21), sempre, enquanto o grupo não o tiver
				drop("flask", e.position, 1, Vector2.from_angle(rng.randf() * TAU) * 120.0, "maldito_carcereiro")
		if crypt_rule == "miasma":  # e o ar do Abismo do Miasma (#38) limpa-se
			breath_end = INF
			number(e.position + Vector2(0, e._top() - 40.0), tr("O ar limpa-se."), 24.0, Color(0.5, 1.0, 0.55))
	if e.boss == "tita":  # o Titã Petrificado (#70): um relicário onde caiu (o do Cortejo que ficou por abrir vai para as moedas)
		var mt := loot_mult(level)
		_bank_chest()
		_spawn_chest([["bone", int(10 * mt)], ["ink", 3 + level / 3], ["ash", 2 + level / 4]], e.position + Vector2(0, 40))
		sfx("victory")
		hud.toast("O Titã Petrificado caiu! O relicário dele está livre.")
	if e.boss == "santuario":  # Santuário dos Deuses Cadavéricos (#50): as leis caem com o deus e fica um relicário grande
		end_mode()
		sfx("victory")
		hud.card_t = minf(hud.card_t, 0.4)
		var sa := circle_level()
		var sm := loot_mult(sa)
		_bank_chest()
		_spawn_chest([["bone", int(20 * sm)], ["ink", 5 + sa / 3], ["ash", 3 + sa / 4], [_reagent(), 1], [_reagent(), 1]], e.position + Vector2(0, 40))
		hud.toast("Venceste o Santuário!")
	for p in players:
		if not p.dead:
			p.heal(p.stat("kill_heal"))
			p.fill_potions(1.0 if e.is_boss else 0.5 if e.elite else 0.25)  # 4 mortes = 1 poção (um elite, meia)
			if sanctum_rule == 3:  # Santuário (#50), Terceira lei: cada morte dá 30 de alma
				p.add_mana(30.0)
			elif sanctum_rule == 4:  # e a Quarta: cada morte cura 5% da vida
				p.heal(p.max_hp * 0.05)
	if e.hit_support == "martir" and is_instance_valid(e.hit_by) and not e.hit_by.dead:  # Alma Mártir (#151): o abate devolve logo a Esquiva
		e.hit_by.dash_cd = 0.0
		spawn_fx("sparks", e.hit_by.position + Vector2(0, -40), 0.0, Color(0.6, 1.0, 0.9))  # o ciano da esquiva perfeita
	if e.elite and is_instance_valid(e.hit_by) and not e.hit_by.dead and e.hit_by.stat("ressurreicao") > 0.0 \
			and not get_tree().get_nodes_in_group("allies").any(func(a): return a.owner_p == e.hit_by and a.power > 1.0 and a.life > 0.0):
		# Ressurreição de Elites (#179): o elite ergue-se para quem o matou, com o desenho dele e o triplo do dano (um de cada vez)
		var el = spawn_ally(e.position, e.hit_by)
		el.body = e.skin if e.skin != "" else e.kind
		el.power = 3.0
		if e.hit_by.stat("canibal") <= 0.0:  # com o Canibalismo Espiritual dura os 4 s dos outros
			el.life = 20.0
	elif e.raise_owner != null and is_instance_valid(e.raise_owner) and not e.is_boss:
		for i in e.raise_n:  # Alma Mitótica (#149): dois pequenos lado a lado, sem nascer dentro das paredes da cripta
			spawn_ally(walk(e.position, e.position + Vector2(60 * i - 30 * (e.raise_n - 1), 0)), e.raise_owner, e.raise_n > 1)
	elif e.hit_phys and not e.is_boss and is_instance_valid(e.hit_by) and not e.hit_by.dead and e.hit_by.stat("exumacao") > 0.0 and rng.randf() < 0.25:
		# Exumação Espontânea (#102): quem cai a um golpe físico ergue-se, 1 vez em 4, como esqueleto de quem bateu, só 10 s
		var ex = spawn_ally(e.position, e.hit_by)
		ex.life = minf(ex.life, 10.0)
	elif e.kind != "herald" and players.any(func(q): return q.stat("corpse") > 0.0):
		# Espasmo Cadavérico (#9, #115): ou se ergue como lacaio, ou fica no chão com o estado de quem morreu
		# Fome Insaciável da Terra (#137): se quem o matou a tem, a terra engole-o (sem alternativa: o Espasmo de outro herói guarda os corpos)
		var eater = e.hit_by if is_instance_valid(e.hit_by) and not e.hit_by.dead and e.hit_by.stat("fome") > 0.0 else null
		if eater:
			eater.fome_n = mini(eater.fome_n + 1, 6)
			spawn_fx("dust", e.position, 50.0, Color(0.45, 0.3, 0.2))
		else:
			var aff := 1 if e.rot_t > 0.0 else 2 if e.necro > 0 else 3 if e.calc > 0 or e.statue_t > 0.0 else 0
			corpses.append([e.position, aff, time + CORPSE_T, clampf(e.max_hp * 0.4, 8.0, 90.0)])
			if corpses.size() > 8:  # poucos cadáveres: baratos de desenhar e de mandar ao convidado
				corpses.pop_front()
	if e.necro > 0:  # Pestilência Saltadora (#178): metade das camadas salta para cada um dos dois monstros mais perto
		var near := enemies().filter(func(o): return o.position.distance_to(e.position) < 240.0)
		near.sort_custom(func(a, b): return a.position.distance_to(e.position) < b.position.distance_to(e.position))
		for o in near.slice(0, 2):
			o.necro = mini(o.necro + ceili(e.necro / 2.0), o.NECRO_MAX)
			o.necro_wait = 4.0
			spawn_fx("sparks", o.position + Vector2(0, -20), 0.0, Color(0.62, 0.36, 0.85), e.position.direction_to(o.position))
		if not near.is_empty():
			spawn_fx("ring", e.position, 60.0, Color(0.62, 0.36, 0.85))
	# Frio do Purgatório (#104): a estátua que morre rebenta em lascas de osso com o dano de um cadáver; as lascas também
	# calcificam (estátuas em cadeia, cada monstro só morre uma vez) e, ao contrário do cadáver, levam o frasco do golpe
	if e.statue_t > 0.0 and is_instance_valid(e.hit_by) and not e.hit_by.dead and e.hit_by.stat("frio") > 0.0:
		spawn_fx("ring", e.position, CORPSE_R, CORPSE_COLORS[3])
		spawn_fx("dust", e.position, 60.0, CORPSE_COLORS[3])
		hit_circle(e.position, CORPSE_R, clampf(e.max_hp * 0.4, 8.0, 90.0), e.hit_by)
	# Sem Alma Própria (#132): com a chave no grupo, cada abate deixa uma esfera de alma (no máximo 6 no chão)
	if players.any(func(q): return not q.dead and q.stat("semalma") > 0.0):
		if get_tree().get_nodes_in_group("loot").filter(func(l): return l.kind == "soul").size() < 6:
			drop("soul", e.position, 1, Vector2.from_angle(rng.randf() * TAU) * 90.0)
	# Frascos de Alma e Almas Condensadas: os chefes deixam sempre um que o grupo ainda não tenha; os outros, raramente, mais quantos mais faltarem
	var missing: Array = (Player.SUPPORTS + Player.SOULS).filter(func(f): return not f in flasks and not f in Player.CURSED)  # os Malditos (#21) só os dá o chefe deles
	if not missing.is_empty() and ((e.is_boss and not e.title in NO_BOSS_DROP) or rng.randf() < 0.002 * missing.size() * (10.0 if e.elite else 1.0)):
		drop("flask", e.position, 1, Vector2.from_angle(rng.randf() * TAU) * 120.0, missing[rng.randi() % missing.size()])
	elif e.boss == "tita":  # o Titã (#70) deixa sempre um Frasco que falte ou, sem nenhum, uma Relíquia de Família
		var lost: Array = RELICS.keys().filter(func(r): return not r in relics)
		if not lost.is_empty():
			drop("relic", e.position, 1, Vector2.from_angle(rng.randf() * TAU) * 140.0, lost[rng.randi() % lost.size()])
	# Chefes com nome: 30% um reagente da Forja (S2) e, num sorteio à parte (o dos frascos dava uma a cada colosso do
	# Cortejo), 35% uma Relíquia de Família (#58) que o grupo ainda não tenha; ela vai no campo flask do saque
	if named:
		if rng.randf() < 0.3:
			drop(_reagent(), e.position, 1, Vector2.from_angle(rng.randf() * TAU) * 140.0)
		var gone: Array = RELICS.keys().filter(func(r): return not r in relics)
		if not gone.is_empty() and e.boss != "tita" and rng.randf() < 0.35:  # o Titã já deu o dele: um Frasco ou uma Relíquia
			drop("relic", e.position, 1, Vector2.from_angle(rng.randf() * TAU) * 140.0, gone[rng.randi() % gone.size()])
	# Elites e Gigantes Errantes (#277, #39): uma Alma Transitória (#4: 35% / 50%) e um reagente da Forja (4% / 15%)
	if e.elite or e.title == "Gigante Errante":
		if rng.randf() < (0.35 if e.elite else 0.5):
			drop("transitoria", e.position, 1, Vector2.from_angle(rng.randf() * TAU) * 140.0)
		if rng.randf() < (0.04 if e.elite else 0.15):
			drop(_reagent(), e.position, 1, Vector2.from_angle(rng.randf() * TAU) * 140.0)
	var n: int = 1 + (circle - 1) / 2 if e.cortejo else 1 + mausoleum / 5 + (e.tier + 1) / 2 + ((circle - 1) / 2 if e.wild or e.camp >= 0 else 0)  # Círculos: os mortos do Cortejo deixam mais de cada vez; no Mausoléu (#27), +1 a cada 5 pisos; no mundo aberto, com a distância e o Círculo
	if e.is_boss:
		for k in ["bone", "bone", "ink", "ash"]:
			drop(k, e.position, n, Vector2.from_angle(rng.randf() * TAU) * 160.0)
	else:
		graves.append([e.position, time + 5.0])  # Alma Gatilho: o abate fica 5 s à espera de ser gasto
		if graves.size() > 3:
			graves.pop_front()
		var r := rng.randf()
		if e.elite:  # sempre 2 Ossos e 1 Tinteiro, e uma Cinza 1 vez em 4
			drop("bone", e.position, 2 * n)
			drop("ink", e.position, n)
			if r < 0.25:
				drop("ash", e.position, n)
		elif r < 0.04:
			drop("ash", e.position, n)
		elif r < 0.10:
			drop("ink", e.position, n)
		elif r < 0.38:
			drop("bone", e.position, n)
	_drop_gear(e, named)  # Equipamento (0.4.8): named é o de main:1841
	if e.cortejo and cortejo.active and not e.is_boss and "rebeldes" in cortejo.affixes and rng.randf() < 0.2:
		# Almas Rebeldes (#196): volta como um fantasma veloz que rebenta ao tocar num herói ou ao fim de 4 s (fora da conta da onda)
		var r = spawn_enemy("specter", e.position, {"hp": e.mods.get("hp", 1.0) * 0.5, "speed": e.mods.get("speed", 1.0) * 1.6, "dmg": e.mods.get("dmg", 1.0)}, false)
		r.paint = Color(0.6, 0.8, 1.0)
		r.title = "Alma Rebelde"
		r.expire_at = time + 4.0
	if e.camp >= 0 and camp_left.has(e.camp):
		_camp_kill(e)
	if e.ev == 1 and not event.is_empty():  # S9: um dos mortos do evento
		event.alive -= 1
		if event.id == "meteoro" and e.elite and chest != null and chest.locked and not enemies().any(func(o): return o.ev == 1 and o.elite):
			chest.locked = false  # Meteoro Funerário (#218): sem elites na cratera, o relicário abre-se
			spawn_fx("ring", chest.position, 140.0, Color(1.0, 0.85, 0.4))
			sfx("chest")
			hud.toast("Os elites caíram: o relicário da cratera abriu-se!")
	if e.cortejo and cortejo.active:
		cortejo.alive -= 1
		if cortejo.alive <= 0:
			_wave_cleared()


# ---------- O Arauto Fúnebre ----------

## Entrada do chefe: fecha a arena, o sino dobra duas vezes (o mundo escurece e treme),
## e só então o Arauto sobe do chão; quando acaba de subir, ruge (boss_roar).
func _boss_intro(mods: Dictionary) -> void:
	arena_r = ARENA_R
	rumble = 2.6
	sfx("bell")
	var guard := wins % 2 == 1  # Guardião dos Monumentos (#204): depois da 1.ª vitória, um Cortejo sim, outro não
	hud.toast("As estátuas acordam... o Guardião dos Monumentos ergue-se." if guard else "O sino toca... o Arauto Fúnebre aproxima-se.")
	await get_tree().create_timer(1.3, false).timeout
	if not is_inside_tree() or not cortejo.active:
		return
	sfx("bell")
	await get_tree().create_timer(1.3, false).timeout
	if not is_inside_tree() or not cortejo.active:
		return
	var h = spawn_enemy("colossus" if guard else "herald", monument_pos + Vector2(280, -60), mods, true)  # ao lado do obelisco, à vista
	h.rise_t = 1.4
	if guard:
		Bosses.make(h, "guardiao")
		raise_statues(h)
	else:  # Arauto por Círculo: do II tem 2.ª fase a meio da vida; do IV bate e invoca mais depressa e o sino chega mais longe
		if circle >= 2:
			h.rage_at = 0.5
		if circle >= 4:
			h.haste = 1.35
			h.reach = 1.3
		if circle >= 6:
			h.title = "Arauto Ascendido"
	spawn_fx("dust", h.position, 140.0, Color.WHITE)
	focus_pos = h.position + Vector2(0, -40)
	focus_t = 3.2


func boss_roar(e) -> void:
	hitstop(0.08)
	shake = 18.0
	vibrate(350, 1.0)
	zoom_kick = maxf(zoom_kick, 0.06)
	sfx("roar")
	sfx("bell")
	spawn_fx("ring", e.position, 320.0, Color(0.4, 1.0, 0.6))
	spawn_fx("dust", e.position, 120.0, Color.WHITE)
	hud.name_card(e.who(), Bosses.INFO[e.boss][1] if e.boss != "" else "Mensageiro do Cortejo Fúnebre")
	e.bar_fill = 0.0


## 2.ª fase do Arauto (Círculo II em diante): o sino racha, ele fica vermelho e chama dois Coveiros.
func herald_rage(e) -> void:
	sfx("bell")
	shake = maxf(shake, 14.0)
	spawn_fx("ring", e.position, 260.0, Color(1.0, 0.3, 0.25))
	hud.toast("O sino racha! O Arauto chama os Coveiros.")
	for i in 2:
		var c = spawn_enemy("colossus", e.position + Vector2(-160 + 320 * i, 60), e.mods, e.cortejo)
		c.title = "Coveiro"
		spawn_fx("dust", c.position, 70.0, Color.WHITE)
		if e.cortejo and cortejo.active:
			cortejo.alive += 1


## Sino no chão: dano em área a quem estiver perto.
func boss_slam(pos: Vector2, r: float, dmg: float, by := "", src = null, sound := "bell") -> void:
	for p in players:
		if not p.dead and p.position.distance_to(pos) < r:
			if p.soul == "donzela" and p.iron_cd <= 0.0 and p.dash_t <= 0.0:  # Donzela de Ferro Móvel (#174): o golpe que apanha vira o herói em couraça (a esquivar não gasta a recarga)
				p.iron_cd = 25.0
				p.iron_t = 1.5
				number(p.position + Vector2(0, -120), tr("Donzela de Ferro!"), 20.0, Color(0.7, 0.76, 0.85))
				spawn_fx("ring", p.position, 80.0, Color(0.7, 0.76, 0.85))
			p.take_damage(dmg * (0.1 if p.iron_t > 0.0 else 1.0), by, src)
	spawn_fx("ring", pos, r, Color(0.4, 1.0, 0.6))
	spawn_fx("dust", pos, 90.0, Color.WHITE)
	shake = maxf(shake, 11.0)
	sfx(sound)
	_arm_rocks(pos, r)


## As 4 Estátuas Funerárias do Guardião dos Monumentos (#204), presas ao chão à volta do monumento, com 300 de vida (x a
## do Cortejo): enquanto houver uma de pé ele não leva dano. Fora do Cortejo: não contam para acabar a onda.
## Nos Sepulcros, à volta do meio da sala (nunca de g.position: uma estátua na parede deixava-o imune para sempre) e com 80 de vida.
func raise_statues(g) -> void:
	var at: Vector2 = sep.boss if zone == "sep" else monument_pos
	for off in [Vector2(320, 0), Vector2(-320, 0), Vector2(0, 260), Vector2(0, -260)]:
		var s = spawn_enemy("colossus", at + off, {"hp": (80.0 if zone == "sep" else 300.0) / Enemy.STATS.colossus[0] * g.mods.get("hp", 1.0), "dmg": g.mods.get("dmg", 1.0)}, false)
		s.anchor = true
		s.grow(0.5)
		s.paint = Enemy.STONE
		s.title = "Estátua Funerária"
		spawn_fx("dust", s.position, 80.0, Color(0.8, 0.8, 0.75))


## Sineiros (#206): o sino tocou sem ninguém o calar a tempo: chega um colosso com a força da onda, que conta para a acabar.
func ring_bell(e) -> void:
	sfx("bell")
	spawn_fx("ring", e.position, 260.0, Color(1.0, 0.82, 0.3))
	if zone == "sep" and enemies().size() >= SEP_CAP:
		return
	var c = spawn_enemy("colossus", e.position + Vector2(0, -60), e.mods, true)
	c.title = "Reforço"
	spawn_fx("dust", c.position, 90.0, Color.WHITE)
	if cortejo.active:
		cortejo.alive += 1


func summon_minions(e, n: int) -> void:
	for i in n:
		if zone == "sep" and enemies().size() >= SEP_CAP:
			return
		var pos: Vector2 = e.position + Vector2.from_angle(TAU * i / n + 0.4) * 110.0
		_wear(spawn_enemy("skeleton", pos, e.mods, e.cortejo))
		spawn_fx("dust", pos, 40.0, Color.WHITE)
		if e.cortejo and cortejo.active:
			cortejo.alive += 1


# ---------- Liga "Cortejo Fúnebre" ----------

func near_monument() -> bool:
	for p in players:
		if not cortejo.active and not mode_on() and not p.dead and p.position.distance_to(monument_pos) < 130.0:
			return true
	return false


func near_chest() -> bool:
	if chest == null or chest.opening >= 0.0 or chest.locked:  # o selado do Meteoro (#218) não tira a esquiva a meio da luta
		return false
	for p in players:
		if not p.dead and p.position.distance_to(chest.position) < 110.0:
			return true
	return false


func interact(who = null) -> void:
	if Net.is_guest():
		Net.tap(0)
		return
	for p in players:
		var e = soul_target(p)
		if e != null:
			soul_strike(e, p)
			return
	var door := near_door(who)
	if near_chest():
		chest.open()
	elif near_seal(who):
		pay_seal()
	elif door == "down":
		enter_crypt()
	elif door == "up":
		leave_crypt()
	elif door == "gate":
		if hud.panel == null:
			hud.open_gate()
	elif door == "sep_down":
		sep_descend()
	elif door == "sep_up":
		sep_leave()
	elif near_monument() and hud.panel == null:  # a mesma ordem da dica do HUD (em co-op cada herói pode estar ao pé de um)
		hud.open_cortejo()
	elif near_altar():
		wake_titan()


## Execução Espectral (#12) ou extração da Alma Ancestral (#16): o inimigo ao alcance de p (ou null).
func soul_target(p):
	if p.dead:
		return null
	for e in enemies():
		if (e.executable(p) or e.extractable()) and p.position.distance_to(e.position) < e.radius + 120.0:
			return e
	return null


func soul_strike(e, p) -> void:
	hitstop(0.14)
	hud.flash(0.3)
	shake = maxf(shake, 14.0)
	zoom_kick = maxf(zoom_kick, 0.08)
	vibrate(70, 0.8, p)
	var mid: Vector2 = e.position + Vector2(0, e._top() * 0.5)
	if e.extractable():  # a Alma Ancestral sai do peito do chefe quebrado
		e.extracted = true
		currency.bone += 3
		p.add_mana(30.0)
		number(mid + Vector2(0, -30), tr("Alma extraída! +3 Ossos"), 22.0, Color(0.6, 1.0, 0.75))
		spawn_fx("ring", e.position, e.radius * 3.0, Color(0.4, 1.0, 0.6))
		spawn_fx("glow", mid, 120.0, Color(0.5, 1.0, 0.7))
		e.take_damage(e.max_hp * 0.06, true, p.position.direction_to(e.position), true)
		sfx("chest")
		return
	number(mid + Vector2(0, -30), tr("Executado!"), 26.0, Color(0.75, 1.0, 0.95))
	spawn_fx("ring", e.position, 110.0, Color(0.75, 1.0, 0.95))
	spawn_fx("glow", mid, 90.0, Color(0.75, 1.0, 0.95))
	e.hit_by = p  # a execução é de quem executa (a Alma Mártir de outro herói não ganha a esquiva com ela)
	e.hit_support = ""
	e.take_damage(e.hp + 1.0, true, p.position.direction_to(e.position), true)
	p.add_mana(15.0)
	p.heal(p.max_hp * 0.05)
	sfx("crit")


## Cólera Póstuma (#17): o esqueleto erguido desfaz-se num miasma que cega quem está perto e cura o dono.
## Canibalismo Espiritual (#122): com a chave, o dono come-o em vez disso: +10% da vida e +8% de dano (até 5 camadas).
func miasma(pos: Vector2, by) -> void:
	if is_instance_valid(by) and not by.dead and by.stat("canibal") > 0.0:
		by.heal(by.max_hp * 0.1)
		by.canibal_n = mini(5, by.canibal_n + 1)
		spawn_fx("glow", by.position + Vector2(0, -40), 55.0, Color(0.4, 1.0, 0.65))  # o verde dos lacaios
		return
	for e in enemies():
		if e.position.distance_to(pos) < 130.0 + e.radius:
			e.blind_t = 2.5
	spawn_fx("ring", pos, 130.0, Color(0.45, 0.3, 0.5))
	spawn_fx("dust", pos, 90.0, Color(0.5, 0.4, 0.55))
	if is_instance_valid(by) and not by.dead:
		by.heal(by.max_hp * 0.06)


## Sangue no Solo (#23): em cima de uma poça de sangue, heróis e lacaios andam +25%.
func blood_speed(pos: Vector2) -> float:
	for pool in blood:
		if pos.distance_squared_to(pool[0]) < BLOOD_R * BLOOD_R:
			return 1.25
	return 1.0


## Explosão de Cadáveres (#9): rebenta com 40% da vida de quem morreu e, antes do golpe, passa o estado dele a quem
## estiver perto (podridão, 3 camadas de necrose ou 3 de calcificação): quem morrer da explosão herda-o.
func burst_corpse(c: Array) -> void:
	corpses.erase(c)
	var by = nearest_player(c[0])
	if by == null:
		return
	var col: Color = CORPSE_COLORS[c[1]]
	if fx_budget("explosion", 2, 4):  # rebenta em terra e pedras de osso, com o fumo e os anéis da cor do estado
		spawn_fx("explosion", c[0], 0.7, col, Vector2.RIGHT, ["ash", "rot", "necro", "bone"][c[1]])
	else:
		spawn_fx("burst", c[0], 0.0, col)
		spawn_fx("ring", c[0], CORPSE_R, col)
		spawn_fx("dust", c[0], 50.0, col)
	for e in enemies():
		if e.position.distance_to(c[0]) > CORPSE_R + e.radius:
			continue
		match c[1]:
			1:
				e.apply_rot(c[3] * 0.3)
			2:
				for k in 3:
					e.add_necro()
			3:
				for k in 3:
					e.add_calc()
	var raising = raise_by  # a explosão é do cadáver, não do golpe que a acordou: não ergue lacaios nem leva a Alma Caótica
	var aff := cast_aff
	var sup := cast_support  # nem leva o frasco dele (o herói mais perto do cadáver pode ser outro)
	raise_by = null
	cast_aff = 0
	cast_support = ""
	hit_circle(c[0], CORPSE_R, c[3], by)
	raise_by = raising
	cast_aff = aff
	cast_support = sup


## Espasmo Cadavérico (#115): um golpe que passa por cima de um cadáver com mais de meio segundo rebenta-o
## (a explosão também é um golpe: rebenta os que estiverem perto, em cadeia).
func _strike_corpses(origin: Vector2, radius: float) -> void:
	for c in corpses.duplicate():
		if c in corpses and origin.distance_to(c[0]) <= radius and c[2] - time < CORPSE_T - 0.5:
			burst_corpse(c)


## Alma Gatilho: o abate ainda por gastar mais perto de pos (até 300 px), ou [] se não houver; os de mais de 5 s saem.
func grave_near(pos: Vector2) -> Array:
	while not graves.is_empty() and graves[0][1] <= time:  # entram por ordem e todos duram 5 s: o mais antigo sai primeiro
		graves.pop_front()
	var best := []
	var best_d := 300.0
	for g in graves:
		var d: float = pos.distance_to(g[0])
		if d < best_d:
			best_d = d
			best = g
	return best


## Nível de área do mundo aberto (#27): o do Círculo e mais 2 a cada 800 px da praça (+1 de 2 em 2 Círculos: no V, 4). No Círculo I, perto da praça: nível 1, como antes.
func wild_tier(pos: Vector2) -> int:
	return int(pos.distance_to(monument_pos) / WILD_STEP)


func wild_level(pos: Vector2) -> int:
	return circle_level() + (2 + (circle - 1) / 2) * wild_tier(pos)


func spawn_wild(kind: String, at: Vector2):
	var e = spawn_enemy(kind, at, lvl_mods(wild_level(at)), false)
	e.wild = true
	e.tier = wild_tier(at)
	_wear(e)
	e.paint = wild_paint(region_at(at), e.tier, e.skin != "")
	return e


## 0.4.7: a pele de um esqueleto que nasceu sozinho: a da zona ou, no Cortejo, depois da 1.ª vitória, metade com uma das 4 ao calhas. Só muda o desenho e o nome. O dado é o global: main.rng fica como estava. spawn_enemy não veste: os testes querem o de sempre, e na cripta e nos modos ficam os de sempre.
func _wear(e) -> void:
	if e.kind != "skeleton":
		return
	if zone == "sep":
		e.skin = sep_kind(sep_depth()).skin
	elif e.cortejo:
		if wins >= 1 and randf() < 0.5:
			e.skin = WEAR[randi() % WEAR.size()]
	elif zone == "world" and not mode_on():
		e.skin = REGIONS[region_at(e.position)].skin


## A cor da região, a avermelhar com a distância: é assim que se lê o perigo (os monstros não mostram o nível). Quem tem pele tem as suas cores: fica só o avermelhar.
func wild_paint(region: String, tier: int, skinned := false) -> Color:
	return (Color.WHITE if skinned else REGIONS[region].paint).lerp(Color(1.0, 0.5, 0.4), tier * 0.12)


## Quem ficou para trás não gasta o limite de monstros (os chefes, os gigantes, os eventos e os dos testes não têm wild).
## Os bandos a dormir saem mais cedo: camp_left trá-los de volta como estavam.
func _wild_tick() -> void:
	_gather_loot(WILD_FAR)  # o saque esquecido custa em cada frame (e vai ao convidado a cada frame): vem ter connosco, como ao mudar de zona
	var chased: Array = enemies().filter(func(o): return o.camp >= 0 and o.awake).map(func(o): return o.camp)
	for e in enemies():
		if e.camp in chased and not e.awake:
			continue  # quem dorme espera por quem anda atrás do herói: senão o acampamento ficava vazio até esse morrer
		if e.wild or e.camp >= 0:
			var asleep: bool = e.camp >= 0 and not e.awake
			var far: float = CAMP_WAKE + 300.0 if asleep else WILD_FAR
			var at: Vector2 = camps[e.camp].pos if asleep else e.position  # quem dorme sai com o bando inteiro: parte dele saía, e o resto nascia à vista ao matar os que ficaram
			if players.all(func(q): return q.position.distance_squared_to(at) > far * far):
				e.queue_free()


## Os bandos só existem perto dos heróis: nascem a dormir (aggro 520, como na cripta) e, por acabar, voltam como ficaram.
func _camps_tick() -> void:
	if zone != "world" or cortejo.wave > 0 or arena_r > 0.0 or mode_on():
		return
	for i in camps.size():
		if i in camps_done:
			continue
		var at: Vector2 = camps[i].pos
		if players.any(func(q): return not q.dead and q.position.distance_to(at) < CAMP_WAKE) and not enemies().any(func(o): return o.camp == i):
			_camp_spawn(i)


func _camp_spawn(i: int) -> void:
	var c: Dictionary = camps[i]
	var reg: Dictionary = REGIONS[c.region]
	var mods := lvl_mods(wild_level(c.pos) + 1)
	if not camp_left.has(i):
		camp_left[i] = [CAMP_PACK, true]
	var left: Array = camp_left[i]
	for k in left[0] + (1 if left[1] else 0):
		var boss: bool = left[1] and k == 0
		var at: Vector2 = c.pos if boss else c.pos + Vector2.from_angle(TAU * k / 7.0 + 0.4) * rng.randf_range(90.0, 170.0)
		var e = spawn_enemy("skeleton" if boss or rng.randf() >= reg.spec else "specter", at, mods, false)
		e.aggro = 520.0
		e.camp = i
		e.tier = wild_tier(c.pos)
		if e.kind == "skeleton":  # o bando e o elite com o nome dele: a pele da região do acampamento, mesmo no que nasce do outro lado da fronteira
			e.skin = reg.skin
		e.paint = wild_paint(c.region, e.tier, e.skin != "")
		if boss:
			e.make_elite()
			e.title = reg.camp


## Um morto do acampamento: o último dá o saque, uma vez. Vai logo para o grupo: camps_done fica gravado e o saque do chão não.
func _camp_kill(e) -> void:
	var left: Array = camp_left[e.camp]
	if e.elite:
		left[1] = false
	else:
		left[0] -= 1
	if left[0] > 0 or left[1]:
		return
	camps_done.append(e.camp)
	var a: int = wild_level(camps[e.camp].pos) + 1
	for r in [["bone", int(5 * loot_mult(a))], ["ink", 1 + a / 4], ["ash", a / 6]]:
		if r[1] > 0:
			collect(drop(r[0], e.position, r[1]))
	if rng.randf() < 0.2:
		collect(drop(_reagent(), e.position))
	spawn_fx("pillar", e.position, 0.0, Color(1.0, 0.85, 0.4), Vector2.RIGHT, "gold")
	sfx("chest")
	hud.toast("Acampamento limpo: o saque é teu!")
	save_game()


## Cemitério dos Gigantes (#39): do Círculo III em diante andam no cemitério 2 Gigantes Errantes (3 do V em diante),
## colossos maiores e cor de terra que andam à toa até um herói chegar perto. Nascem a mais de 1100 px do grupo, um
## por vez; quem cai só volta 20 s depois.
func _giants() -> void:
	var cap := 0 if circle_max < 3 else 3 if circle_max >= 5 else 2
	if time < giant_at or enemies().filter(func(e): return e.title == "Gigante Errante").size() >= cap:
		return
	for i in 30:
		var at := Vector2(rng.randf_range(MAP.position.x + 200, MAP.end.x - 200), rng.randf_range(MAP.position.y + 200, MAP.end.y - 200))
		if players.all(func(q): return q.position.distance_to(at) > 1100.0):
			var g = spawn_enemy("colossus", at, lvl_mods(1 + 4 * (circle_max - 1)), false)
			g.grow(1.2)
			g.paint = Color(0.85, 0.8, 0.7)
			g.aggro = 600.0
			g.title = "Gigante Errante"
			g.wander = Vector2.ZERO
			return


## O altar do cemitério aceita um Coração de Titã (#70): fora do Cortejo e dos eventos (S9: o relicário do Titã tirava o
## lugar ao selado do Meteoro), sem outro Titã acordado e com um herói perto.
func near_altar() -> bool:
	if zone != "world" or cortejo.wave > 0 or mode_on() or not event.is_empty() or currency.get("coracao", 0) < 1 or enemies().any(func(e): return e.boss == "tita"):
		return false
	return players.any(func(p): return not p.dead and p.position.distance_to(SHRINE) < 130.0)


## Coração de Titã Petrificado (#70): oferecido no altar, ergue ao lado dele o Titã Petrificado (4 níveis acima do grupo,
## com 2,5 vezes a vida), que ruge ao acabar de subir (boss_roar).
func wake_titan() -> void:
	currency.coracao -= 1
	var ti = spawn_enemy("colossus", SHRINE + Vector2(0, 170), lvl_mods(level + 4), false)
	Bosses.make(ti, "tita")
	ti.rise_t = 1.4
	spawn_fx("dust", ti.position, 140.0, Color.WHITE)
	sfx("bell", 0.5)
	shake = maxf(shake, 10.0)
	focus_pos = ti.position + Vector2(0, -60)
	focus_t = 2.0
	hud.toast("Ofereceste o Coração de Titã: o altar treme...")


## Boneco de treino (#287): ao lado do monumento, sempre que se está no cemitério.
func _spawn_dummy() -> void:
	var d = spawn_enemy("skeleton", monument_pos + DUMMY_AT, {}, false)
	d.dummy = true
	d.title = "Boneco de treino"


# ---------- Cripta dos Condenados ----------

## "down" e "up": as escadas e a porta do fundo da cripta. "gate": o Portão dos Reis. "sep_up", "sep_down": as saídas dos Sepulcros (as do chefe só depois de ele cair).
## who: nos Sepulcros, só conta quem carregou. Sem isto o toque do convidado em "Descer" podia subir (a ordem de players é outra no anfitrião), e a esquiva de um herói tirava o grupo de lá quando o outro passava por uma saída. Fora dos Sepulcros não conta: a cripta e o cemitério ficam como hoje.
func near_door(who = null) -> String:
	if zone == "sep":
		if sep.is_empty():
			return ""
		for p in ([who] if who != null else players):
			var door := ""
			if not p.dead:
				if p.position.distance_to(sep.exit) < SEP_DOOR_R or (sep_done == 1 and p.position.distance_to(sep.up) < SEP_DOOR_R):
					door = "sep_up"
				elif sep_done == 1 and p.position.distance_to(sep.down) < SEP_DOOR_R:
					door = "sep_down"
			if door != "" and sep_calm(p):  # a meio de uma luta o botão é a esquiva
				return door
		return ""
	var at := CRYPT_DOOR if zone == "world" else CRYPT_ORIGIN + CRYPT_OUT
	for p in players:
		if not p.dead:
			if p.position.distance_to(at) < 130.0:
				return "down" if zone == "world" else "up"
			if zone == "world" and wins >= 1 and not map_busy and p.position.distance_to(GATE) < 170.0:
				return "gate"
	return ""


## Para onde aponta a seta do HUD: o túmulo por recuperar vem primeiro, depois o evento do cemitério (S9); depois da 1.ª
## vitória, o Portão até à 1.ª descida, e depois o acampamento por limpar mais perto; limpos todos (ou no Cortejo), o monumento.
func objective() -> Vector2:
	if zone == "sep":
		return _sep_goal()
	if zone == "crypt":
		return guardian.position if is_instance_valid(guardian) else CRYPT_ORIGIN + CRYPT_OUT
	if not tomb.is_empty():
		return tomb.pos
	if not event.is_empty():
		return event.pos
	var best := monument_pos
	if cortejo.wave > 0 or mode_on() or wins == 0:
		return best
	if sep_runs == 0:
		return GATE
	var near := INF
	for i in camps.size():
		var d: float = player.position.distance_squared_to(camps[i].pos)
		if d < near and not i in camps_done:
			near = d
			best = camps[i].pos
	return best


## Paredes da cripta e dos Sepulcros: o passo só vale se ficar no chão; senão desliza ao longo da parede ou fica parado.
func walk(from: Vector2, to: Vector2) -> Vector2:
	if zone == "world" or on_floor(to) or (zone == "sep" and not on_floor(from)):  # nos Sepulcros, quem nasceu ou foi puxado para dentro da parede sai a andar (invocações main:1982 e main:2032, limite do co-op main:795)
		return to
	for p in [Vector2(to.x, from.y), Vector2(from.x, to.y)]:
		if on_floor(p):
			return p
	return from


## É chão? Na cripta o polígono de sempre; nos Sepulcros, a grelha.
func on_floor(p: Vector2) -> bool:
	if zone == "sep":
		return _sep_byte(p) > 0
	return Geometry2D.is_point_in_polygon(p, crypt_floor)


func _sep_byte(p: Vector2) -> int:
	var c := Vector2i(((p - SEP_ORIGIN) / SEP_CELL).floor())
	return sep_grid[c.x + c.y * SEP_SIDE] if c.x >= 0 and c.y >= 0 and c.x < SEP_SIDE and c.y < SEP_SIDE and not sep_grid.is_empty() else 0


## A sala onde p está (-1 num corredor ou na parede).
func sep_room_at(p: Vector2) -> int:
	var v := _sep_byte(p)
	return v - 1 if v > 0 and v < SEP_LINK else -1


## Salas da cripta (S6), no anfitrião: sem ar no Abismo do Miasma (#38), 2,5% da vida a cada 0,5 s; a maré de almas do
## Lago das Lamentações (#30), que volta a cada 8 s; e as armadilhas (B6): as pedras de enxofre armadas rebentam, os
## martelos da Forja batem e as serras do Moinho cortam de meio em meio segundo.
func _crypt_tick(delta: float) -> void:
	if crypt_rule == "miasma":
		choke_t = 0.5 if time < breath_end else choke_t - delta
		if choke_t <= 0.0:
			choke_t = 0.5
			for p in players:
				if not p.dead:
					p.take_damage(p.max_hp * 0.025, "Miasma")
	elif crypt_rule == "submersa" and time >= tide_next + TIDE_T:
		tide_next += TIDE_EVERY
	elif crypt_rule == "enxofre":  # Minas de Enxofre (#43): 18% aos heróis a 120 px, 25% aos monstros e 8% aos chefes
		for k in rocks.filter(func(r): return r[1] > 0.0 and r[1] <= time):
			rocks.erase(k)
			_trap(k[0], 120.0, 0.18, 0.25, 0.08, "Pedra de enxofre")
			for o in rocks:  # em cadeia: as intactas a 160 px rebentam 0,25 s depois
				if o[1] == 0.0 and o[0].distance_to(k[0]) < 160.0:
					o[1] = time + 0.25
			if fx_budget("explosion", 2, 4):
				spawn_fx("explosion", k[0], 1.2, Color(1.0, 0.85, 0.3), Vector2.RIGHT, "gold")
			else:
				spawn_fx("ring", k[0], 120.0, Color(1.0, 0.85, 0.3))
				spawn_fx("dust", k[0], 70.0, Color(0.95, 0.85, 0.5))
			shake = maxf(shake, 10.0)
			sfx("hit", 0.5)
	elif crypt_rule == "forja":  # Forja das Almas Escravas (#184): 20% aos heróis a 90 px, 30% aos monstros e 6% aos chefes
		for h in hammers:
			var left: float = h[1] - time
			if zone == "sep" and not _view_rect().grow(300.0).has_point(h[0]):  # os martelos ficam nas 3 últimas salas: sem isto a Forja tremia a câmara desde a 1.ª, com nada à vista
				if left <= 0.0:
					h[1] = time + rng.randf_range(4.0, 6.0)
				continue
			if left <= Fx.SLAM and left + delta > Fx.SLAM and fx_budget("pillar", 2, 4):  # a coluna cai e chega ao chão com o martelo
				spawn_fx("pillar", h[0], 0.0, Color(0.7, 0.72, 0.8), Vector2.RIGHT, "iron")
			if left <= 0.0:
				h[1] = time + rng.randf_range(4.0, 6.0)
				_trap(h[0], 90.0, 0.2, 0.3, 0.06, "Martelo da Forja")
				spawn_fx("ring", h[0], 90.0, Color(0.7, 0.72, 0.8))
				spawn_fx("dust", h[0], 90.0, Color(0.6, 0.6, 0.65))
				shake = maxf(shake, 10.0)
				sfx("swing_heavy")
	elif crypt_rule == "moinho":  # Moinho de Carne (#202): a cada 0,5 s, 6% aos heróis, 25% aos monstros e 3% aos chefes
		saw_t -= delta
		if saw_t <= 0.0:
			saw_t = 0.5
			for b in belts():
				var saw: Vector2 = b[0] + b[1] * 130.0
				if _trap(saw, Pix.SAW_R, 0.06, 0.25, 0.03, "Serra"):
					spawn_fx("sparks", saw, 0.0, Color(1.0, 0.2, 0.15), b[1])


## Lago das Lamentações (#30): a maré de almas está a passar (o convidado lê-a das mesmas horas).
func tide_on() -> bool:
	return crypt_rule == "submersa" and time >= tide_next and time < tide_next + TIDE_T


## Cripta Submersa (#181): na bile os heróis andam a 70%, e na maré a 60% disso.
func terrain_speed() -> float:
	return (0.7 if crypt_rule == "submersa" else 1.0) * (0.6 if tide_on() else 1.0)


## O empurrão da maré, em px/s, nos heróis e nos lacaios (os monstros não).
func tide_push() -> Vector2:
	return tide_dir * 140.0 if tide_on() else Vector2.ZERO


## Necrópole em Chamas Negras (#35): os abrigos de pedra, [posição no mundo, raio]. No Cortejo com as Marés (#212) ou a
## Chuva de Dentes (#192), as 5 lajes à volta do monumento (a 300 px, de 72 em 72 graus) e o próprio monumento (S8).
func shelters() -> Array:
	if crypt_rule == "chamas":
		return [0, 2, 4].map(func(i): return [CRYPT_ORIGIN + CRYPT_PATH[i], 110.0])
	if zone == "world" and ("mares" in cortejo.affixes or "dentes" in cortejo.affixes):
		return range(5).map(func(i): return [monument_pos + Vector2.from_angle(TAU * i / 5.0) * 300.0, 90.0]) + [[monument_pos, 150.0]]
	return []


func sheltered(pos: Vector2) -> bool:
	return shelters().any(func(s): return pos.distance_to(s[0]) < s[1])


## Moinho de Carne das Trevas (#202): as 3 passadeiras (260x70 px, ao longo do corredor), [meio, para onde levam]; a do
## meio leva para a entrada. Cada uma acaba numa serra (meio + rumo x 130). Vêm das constantes: nada vai ao convidado.
func belts() -> Array:
	return [1, 2, 3].map(func(i): return [CRYPT_ORIGIN + CRYPT_PATH[i], CRYPT_DIR * (-1.0 if i == 2 else 1.0)]) if crypt_rule == "moinho" else []


## Em cima de uma passadeira: 120 px/s para a serra (heróis, monstros e lacaios).
func belt_push(pos: Vector2) -> Vector2:
	for b in belts():
		var v: Vector2 = pos - b[0]
		if absf(v.dot(b[1])) < 130.0 and absf(v.cross(b[1])) < 35.0:
			return b[1] * 120.0
	return Vector2.ZERO


## Minas de Enxofre (#43): um golpe em área (hit_circle, boss_slam) que chegue a uma pedra intacta arma-a; rebenta 0,25 s
## depois (_crypt_tick).
func _arm_rocks(pos: Vector2, r: float) -> void:
	for k in rocks:
		if k[1] == 0.0 and pos.distance_to(k[0]) <= r + 14.0:
			k[1] = time + 0.25


## Armadilhas da cripta (B6): quem estiver a menos de r leva uma parte da vida máxima (heróis hero, monstros mon, chefes
## boss). Não é um golpe: sem src (nem Pacto nem Falange), e a esquiva safa. Devolve se apanhou alguém.
func _trap(pos: Vector2, r: float, hero: float, mon: float, boss: float, by: String) -> bool:
	var hit := false
	for p in players:
		if not p.dead and p.position.distance_to(pos) < r:
			p.take_damage(p.max_hp * hero, by)
			hit = true
	for e in enemies():
		if e.position.distance_to(pos) < r + e.radius:
			e.take_damage(e.max_hp * (boss if e.is_boss else mon), true, pos.direction_to(e.position))
			hit = true
	return hit


## Sanctum do Silêncio (#46): o barulho acorda os mortos a dormir a menos de r, que vêm 20% mais depressa. Fica o sítio e
## a hora para o Monge Penitente Cego (#193); r 0 é um passo a correr ou um golpe nele (só um anel cinzento).
func noise(pos: Vector2, r: float) -> void:
	noise_at = pos
	noise_t = time
	if r <= 0.0:
		spawn_fx("ring", pos, 36.0, Color(0.6, 0.6, 0.6))
		return
	spawn_fx("ring", pos, r, Color(0.85, 0.9, 1.0)).dur = 1.2  # um anel pálido que se alarga devagar
	sfx("bell", 0.6)
	for e in enemies():
		if not e.awake and not e.dummy and e.position.distance_to(pos) < r:
			e.awake = true
			e.speed *= 1.2


## Catacumbas Cegas (#26): o escuro só cai nessa sala, e no Cortejo durante o Eclipse Fúnebre (#182).
func dark_on() -> bool:
	return crypt_rule == "cegas" or time < eclipse_end


## As luzes do escuro, Vector3(x, y, raio): a tocha de cada herói (a tremer 3%; caído, 120) e, na cripta, as 4 lâmpadas,
## a saída, os abrigos, as pedras de enxofre e as bigornas da Forja; no Eclipse (#182), o monumento. No máximo 16 (as do shader).
func lights() -> Array:
	var out := []
	for p in players:
		out.append(Vector3(p.position.x, p.position.y, 120.0 if p.dead else TORCH_R * (1.0 + 0.03 * sin(time * 9.0 + p.slot * 2.0))))
	var spots: Array = [[monument_pos, 200.0]] if zone == "world" else _zone_lights() + shelters() + rocks.map(func(k): return [k[0], 70.0]) + hammers.map(func(h): return [h[0], 90.0])
	for l in spots:
		out.append(Vector3(l[0].x, l[0].y, l[1]))
	return out.slice(0, 16)


## As luzes da zona: as lâmpadas e a saída da cripta; nos Sepulcros, só as que a câmara apanha (o shader tem 16).
func _zone_lights() -> Array:
	if zone == "sep":
		var at := cam.get_screen_center_position()
		return sep.get("lights", []).filter(func(l): return l[0].distance_squared_to(at) < 1100.0 * 1100.0)
	return CRYPT_GLOWS.map(func(g): return [CRYPT_ORIGIN + g, 150.0]) + [[CRYPT_ORIGIN + CRYPT_OUT, 120.0]]


## Está à luz de alguma? (às escuras, o minimapa só mostra os monstros que estão)
func lit(pos: Vector2, ls := []) -> bool:
	return (ls if not ls.is_empty() else lights()).any(func(l): return pos.distance_to(Vector2(l.x, l.y)) < l.z)


## Descer: o grupo inteiro vai para a entrada da cripta, que se enche de mortos e do Carcereiro. A sala muda a cada
## descida (S6): a 1.ª é a de sempre, as seguintes sorteiam uma regra que não seja a da última.
func enter_crypt() -> void:
	if cortejo.active:
		hud.toast("O Cortejo Fúnebre ainda não acabou.")
		return
	crypt_n += 1
	var pool: Array = CRYPT_RULES.keys().filter(func(k): return k != "" and k != crypt_last)
	crypt_rule = "" if crypt_n == 1 else pool[rng.randi() % pool.size()]
	crypt_last = crypt_rule
	_change_zone("crypt", CRYPT_ORIGIN + CRYPT_IN)
	guardian_met = false
	var mods := lvl_mods(level)
	var pick: String = CRYPT_BOSSES[(crypt_n - 1) % CRYPT_BOSSES.size()]  # S7: um chefe diferente a cada descida, à vez
	guardian = spawn_enemy("herald" if pick in ["monge", "carrasco"] else "colossus", CRYPT_ORIGIN + CRYPT_BOSS, {"hp": mods.hp * 1.8, "dmg": mods.dmg * 1.2}, false)
	guardian.title = "Carcereiro da Cripta"
	guardian.aggro = 480.0
	if pick != "":
		Bosses.make(guardian, pick)
	var n := 0
	for i in 600:
		if n >= (14 if crypt_rule in ["enxofre", "forja", "moinho", "jardins"] else 20):  # com armadilhas (B6) só 14, para lhes dar espaço
			break
		var p := Vector2(rng.randf_range(bounds.position.x, bounds.end.x), rng.randf_range(bounds.position.y, bounds.end.y))
		if Geometry2D.is_point_in_polygon(p, crypt_floor) and p.distance_to(CRYPT_ORIGIN + CRYPT_IN) > 620.0:
			var e = spawn_enemy("specter" if rng.randf() < 0.3 else "skeleton", p, mods, false)
			e.aggro = 260.0 if crypt_rule == "silencio" else 520.0  # Sanctum do Silêncio (#46): sono pesado, mas o barulho acorda-os
			if n < 2:  # Elites (#277): 2 em cada descida
				e.make_elite()
			n += 1
	_rule_setup(CRYPT_PATH.map(func(q): return CRYPT_ORIGIN + q), CRYPT_SPOTS.map(func(q): return CRYPT_ORIGIN + q), CRYPT_DIR, mods)
	hud.name_card(CRYPT_RULES[crypt_rule][0], CRYPT_RULES[crypt_rule][1], "")
	if crypt_rule != "":  # na de sempre o cartão já diz o que fazer
		hud.toast("Derrota o guardião e abre o relicário.")


## O que cada regra põe no chão, na cripta e nos Sepulcros. path: pontos do caminho (4 ou mais); spots: pontos com 170 px de chão à volta; dir: para onde vai o caminho.
func _rule_setup(path: Array, spots: Array, dir: Vector2, mods: Dictionary) -> void:
	if crypt_rule == "miasma":  # Abismo do Miasma (#38): 60 s de ar, e 3 elites no caminho para o renovar
		breath_end = time + 60.0
		for i in [1, 2, 3]:
			var el = spawn_enemy("skeleton", path[i], mods, false)
			_wear(el)
			el.aggro = 520.0
			el.make_elite()
	elif crypt_rule == "submersa":  # Lago das Lamentações (#30): a 1.ª maré daqui a 8 s, num dos sentidos
		tide_next = time + TIDE_EVERY
		tide_dir = dir * (1.0 if rng.randf() < 0.5 else -1.0)
	elif crypt_rule == "enxofre":  # Minas de Enxofre (#43): 2 pedras em cada ponto do caminho, uma de cada lado
		for q in path:
			for s in [-70.0, 70.0]:
				rocks.append([q + dir.orthogonal() * s, 0.0])
	elif crypt_rule == "forja":  # Forja das Almas Escravas (#184): um martelo em cada ponto, cada um no seu ritmo de 4 a 6 s
		for q in spots:
			hammers.append([q, time + rng.randf_range(4.0, 6.0)])
	elif crypt_rule == "jardins":  # Jardins de Pedras Funerárias (#208): uma gárgula em cada ponto
		for q in spots:
			var g = spawn_enemy("skeleton", q, {"hp": mods.hp * 3.0, "dmg": mods.dmg * 2.0}, false)
			g.grow(1.1)
			g.paint = Enemy.STONE
			g.title = "Gárgula"
			g.gargoyle = true
			g.aggro = 520.0


func leave_crypt() -> void:
	guardian = null
	_change_zone("world", CRYPT_DOOR + Vector2(0, 80))
	hud.toast("De volta ao cemitério.")


## Cada zona tem os seus inimigos e o seu baú; muda limites da câmara, escuridão e faz a transição a negro.
func _change_zone(z: String, at: Vector2) -> void:
	end_event()  # S9: o evento fica no cemitério
	zone = z
	rocks = []  # as armadilhas (B6) ficam na sala
	hammers = []
	for e in enemies():
		if e.boss == "tita":  # o Titã (#70) que fique de pé larga o Coração: não se perde com ele
			drop("coracao", e.position)
		e.queue_free()
	if is_instance_valid(reaper):  # o Ceifador (#216) não está no grupo dos inimigos
		reaper.queue_free()
	corpses.clear()  # os cadáveres ficam com a zona
	graves.clear()
	# O que ficou para trás vem connosco: moedas no chão e o relicário por abrir
	_gather_loot()
	_bank_chest()
	for i in players.size():
		players[i].position = at + Vector2(50 * i, 0)
		players[i].held.clear()
	zone_view(at)
	spawn_t = 2.0
	sfx("hit")
	if z == "world":
		crypt_rule = ""  # as regras da sala (S6) ficam lá em baixo
		_spawn_dummy()


## O saque do chão vai todo para o grupo (ao mudar de zona e ao cair no Mausoléu, #27); com far, só o que está mais longe do que isso de todos.
func _gather_loot(far := 0.0) -> void:
	for l in get_tree().get_nodes_in_group("loot"):
		if players.any(func(q): return q.position.distance_squared_to(l.position) < far * far):
			continue
		if l.kind in ["blood", "soul"]:  # os orbes de sangue e de alma não viajam: secam (senão davam de uma vez tudo o que estava no chão)
			l.queue_free()
			continue
		collect(l)


## A parte que se vê de mudar de zona (o convidado também a faz quando a zona do anfitrião muda).
func zone_view(at: Vector2) -> void:
	bounds = MAP if zone == "world" else SEP_BOUNDS if zone == "sep" else Rect2(CRYPT_ORIGIN, CRYPT.get_size())
	cam.limit_left = int(bounds.position.x)
	cam.limit_top = int(bounds.position.y)
	cam.limit_right = int(bounds.end.x)
	cam.limit_bottom = int(bounds.end.y)
	cam.position = at
	cam.reset_smoothing()
	tint.color = CRYPT_TINT[crypt_rule] if zone == "crypt" else sep_kind(sep_depth()).tint if zone == "sep" else Color.WHITE
	scenery.visible = zone != "sep"
	if zone != "sep":
		_sep_clear()  # o convidado não recarrega quando o anfitrião morre (net:126): tem de largar isto sozinho
	hud.fade()


## O relicário por abrir não se perde: o que tem vai direto para as moedas (ao mudar de zona e ao invocar outra onda).
func _bank_chest() -> void:
	if chest:
		if not chest.opened and not chest.locked:  # o selado do Meteoro (#218) perde-se
			for r in chest.rewards:
				currency[r[0]] += r[1]
			hud.toast("Levaste o relicário contigo.")
		chest.queue_free()
		chest = null


## Nível de área (#27): vida e dano dos mortos e o saque. A cripta usa o nível do grupo; o Cortejo, o do círculo.
func lvl_mods(a: int) -> Dictionary:
	return {"hp": 1.0 + 0.15 * (a - 1), "dmg": 1.0 + 0.08 * (a - 1)}


func loot_mult(a: int) -> float:
	return 1.0 + 0.2 * (a - 1)


## O nível de área do Cortejo: +4 por círculo acima do I.
func circle_level() -> int:
	return 1 + 4 * (circle - 1)


## Selos do Círculo: do II em diante os primeiros afixos já vêm presos, um por círculo acima do I (só os 5 de SEALS).
func circle_seals() -> Array:
	return SEALS.slice(0, circle - 1)


## S8: os 6 afixos do menu do Cortejo: os selos, os que já estão presos e o resto à sorte, com uma ordem que só muda com
## as vitórias e o círculo (o menu reabre igual entre ondas).
func affix_cards() -> Array:
	var out: Array = circle_seals() + cortejo.affixes.filter(func(k): return not k in circle_seals())
	var r := RandomNumberGenerator.new()
	r.seed = wins * 31 + circle
	var pool: Array = AFFIXES.keys()
	for i in range(pool.size() - 1, 0, -1):  # Fisher-Yates com este rng (o shuffle() usa o global)
		var j := r.randi_range(0, i)
		var k = pool[i]
		pool[i] = pool[j]
		pool[j] = k
	for k in pool:
		if out.size() < CARDS and not k in out:
			out.append(k)
	return out


## Saque do Círculo: +30% por círculo acima do I (linear, como o herói cresce; a fórmula da cripta disparava)
func circle_loot() -> float:
	return 1.0 + 0.3 * (circle - 1)


func reward_mult(affixes: Array) -> float:
	return (1.0 + 0.5 * affixes.size()) * circle_loot() * (2.0 if trial != "" else 1.0)  # as Provações dão o dobro


## A Provação id está a correr: escolhida e o Cortejo já começou.
func trial_on(id: String) -> bool:
	return trial == id and cortejo.wave > 0


func start_wave(affixes: Array) -> void:
	var seals := circle_seals()
	affixes = seals + affixes.filter(func(k): return not k in seals)
	cortejo.active = true
	cortejo.affixes = affixes
	cortejo.wave += 1
	end_event()  # S9: um evento a meio acaba
	_bank_chest()  # antes perdia-se o Relicário que ficasse por abrir no monumento
	var w: int = cortejo.wave
	var lm := lvl_mods(circle_level())
	var mods := {"hp": (1.0 + 0.45 * (w - 1)) * lm.hp, "speed": 1.0, "dmg": (1.0 + 0.15 * (w - 1)) * lm.dmg}
	if "blindados" in affixes: mods.hp *= 1.6
	if "furia" in affixes: mods.speed *= 1.35
	if "laminas" in affixes: mods.dmg *= 1.5
	var escorts := int((6 + 4 * w) * (1.6 if "legiao" in affixes else 1.0))
	eclipse_next = time + 20.0  # Eclipse Fúnebre (#182): o 1.º cai aos 20 s da onda
	tide_start = time + 15.0  # Marés de Sangue Negro (#212): a 1.ª sobe aos 15 s (o aviso aos 12)
	if w == 1 and trial == "almas":  # Provação das Almas Rejeitadas (#37): os frascos e a alma ficam guardados até ao fim
		for p in players:
			var sup := {}
			for id in p.order:
				sup[id] = p.skills[id].support
				p.skills[id].support = ""
			p.stash = [sup, p.soul]
			p.soul = ""
	var colossi := (0 if w == WAVES else 1) + (1 if "gemeo" in affixes else 0)
	_clear_world()
	for i in colossi:
		spawn_enemy("colossus", monument_pos + Vector2(-120 + 240 * i, -160), mods, true)
	for i in escorts:
		var p := monument_pos + Vector2.from_angle(rng.randf() * TAU) * rng.randf_range(220, 380)
		var e = spawn_enemy("specter" if rng.randf() < 0.3 else "skeleton", p, mods, true)
		_wear(e)
		if i < w:  # Elites (#277): tantos quantos a onda
			e.make_elite()
		elif i < w + 3 and "sinos" in affixes:  # Sineiros (#206): 3 escoltas tocam o sino quando um herói chega a 500 px
			e.ringer_at = -1.0
	if "ceifador" in affixes and not is_instance_valid(reaper):  # O Ceifador Ambulante (#216): nasce na borda da arena e fica até ao fim
		reaper = spawn_enemy("herald", monument_pos + Vector2.from_angle(rng.randf() * TAU) * ARENA_R, mods, false)
		reaper.reaper = true
		reaper.remove_from_group("enemies")  # ninguém lhe bate nem o conta
		reaper.paint = Color(0.1, 0.1, 0.15, 0.75)
		reaper.grow(1.1)
		reaper.title = "O Ceifador Ambulante"
	# na última onda o Arauto conta já, embora só apareça depois do sino
	cortejo.alive = colossi + escorts + (1 if w == WAVES else 0)
	spawn_fx("ring", monument_pos, 400.0, Color(0.9, 0.2, 0.25))
	hud.toast(tr("Cortejo Fúnebre — onda %d/%d   (recompensa x%.1f)") % [w, WAVES, reward_mult(affixes)])
	if w == WAVES:
		_boss_intro(mods)


## Os mortos do cemitério saem antes de uma onda ou de um modo (os do Cortejo ficam).
func _clear_world() -> void:
	for e in enemies():
		if e.boss == "tita":  # o Titã (#70) que fique de pé larga o Coração, que vai logo para as moedas (o chão não fica gravado)
			collect(drop("coracao", e.position))
		if not e.cortejo:
			e.queue_free()


## O que uma onda dá; o menu do Cortejo mostra exatamente isto antes de a invocar.
## A última onda soma o tesouro final, que vai para o Relicário selado.
func wave_rewards(w: int, affixes: Array) -> Dictionary:
	var m := reward_mult(affixes)
	var r := {"bone": int(4 * w * m), "ink": int(ceil(w * m * 0.6)), "ash": int(ceil((w - 1) * m * 0.6))}
	if w >= WAVES:
		r.ink += int(3 * m)
		r.ash += int(3 * m)
	return r


func _wave_cleared() -> void:
	var w: int = cortejo.wave
	var r := wave_rewards(w, cortejo.affixes)
	cortejo.active = false
	if w >= WAVES:
		_spawn_chest(r.keys().filter(func(k): return r[k] > 0).map(func(k): return [k, r[k]]) + [[_reagent(), 1]] + ([["coracao", 1]] if rng.randf() < 0.15 else []))  # e um reagente da Forja (S2); 15% um Coração de Titã (#70)
		if trial == "almas" and not "almas" in proven:  # a 1.ª vitória na Provação das Almas (#37): um Frasco que falte, ao pé do Relicário
			var lying: Array = get_tree().get_nodes_in_group("loot").filter(func(l): return l.kind == "flask").map(func(l): return l.flask)  # o do chefe ainda está no chão: não sai outra vez
			var miss: Array = (Player.SUPPORTS + Player.SOULS).filter(func(f): return not f in flasks and not f in lying and not f in Player.CURSED)
			if not miss.is_empty():  # só fica dada quando se apanha (collect): o saque do chão não fica gravado
				drop("flask", chest.position, 1, Vector2.from_angle(rng.randf() * TAU) * 120.0, miss[rng.randi() % miss.size()]).set_meta("prova", true)
		end_cortejo()
		hud.toast("O Cortejo foi quebrado! Um Relicário selado ergue-se no monumento.")
		# Círculos: cada vitória conta; no círculo mais alto abre o seguinte, e o próximo Cortejo já é nele
		wins += 1
		camps_done = []  # é o ciclo: limpar os acampamentos, vencer o Cortejo, voltar
		camp_left = {}
		var sub := tr("Vitória n.º %d") % wins
		if circle == circle_max and circle_max < 99:
			circle_max += 1
			circle = circle_max
			sub = tr("Círculo %d aberto: o cemitério mudou") % circle
		hud.name_card("Cortejo Quebrado", sub)
		sfx("victory")
		return
	for k in r:
		if r[k] > 0:
			drop(k, monument_pos, r[k])
	hud.open_cortejo()


func _spawn_chest(rewards: Array, pos := Vector2.INF) -> void:
	chest = Chest.new()
	chest.main = self
	chest.rewards = rewards
	chest.position = monument_pos + Vector2(0, 150) if pos == Vector2.INF else pos
	add_child(chest)
	spawn_fx("dust", chest.position, 70.0, Color.WHITE)
	spawn_fx("ring", chest.position, 120.0, Color(1.0, 0.85, 0.4))
	shake = maxf(shake, 8.0)
	sfx("hit")


func end_cortejo() -> void:
	cortejo = {"active": false, "wave": 0, "affixes": [], "alive": 0}
	arena_r = 0.0
	trial = ""  # a Provação dura um Cortejo
	eclipse_end = 0.0
	_unstash()
	if is_instance_valid(reaper):
		reaper.queue_free()
	reaper = null


## Provação das Almas Rejeitadas (#37): cada herói volta a ter os frascos e a alma que tinha (no fim do Cortejo ou ao morrer).
func _unstash() -> void:
	for p in players:
		if p.stash != null:
			for id in p.stash[0]:
				p.skills[id].support = p.stash[0][id]
			p.soul = p.stash[1]
			p.stash = null


## Afixos do Cortejo (S8), no anfitrião, durante as ondas: o Eclipse Fúnebre (#182) cai a cada 30 s e dura 10; a Maré de
## Sangue Negro (#212) sobe a cada 25 s e, nos 8 s em que está alta, tira 3% a quem estiver fora das pedras (heróis e
## lacaios; os monstros não); a Chuva de Dentes (#192) tira um pouco a quem não se abriga. De meio em meio segundo.
func _cortejo_tick(delta: float) -> void:
	if not cortejo.active:
		return
	var aff: Array = cortejo.affixes
	if "eclipse" in aff and time >= eclipse_next:
		eclipse_next = time + 30.0
		eclipse_end = time + 10.0
		hud.toast("Eclipse!")
		sfx("bell")
	if "mares" in aff and time >= tide_start + 8.0:  # a maré desce: a próxima sobe 25 s depois da anterior
		tide_start += 25.0
	drip_t -= delta
	if drip_t > 0.0:
		return
	drip_t = 0.5
	if tide_up():
		for p in players:
			if not p.dead and not sheltered(p.position):
				p.take_damage(p.max_hp * 0.03, "Maré de Sangue Negro")
		for a in get_tree().get_nodes_in_group("allies"):
			if not sheltered(a.position):
				a.life -= Ally.LIFE * 0.03
	if "dentes" in aff:
		quiet = true  # lascas pequenas: números cinzentos, sem tremor nem som
		for p in players:
			if not p.dead and not sheltered(p.position):
				p.take_damage(2.0 * lvl_mods(circle_level()).dmg, "Chuva de Dentes")
		quiet = false


## Marés de Sangue Negro (#212): a maré está alta (o convidado lê-a das mesmas horas).
func tide_up() -> bool:
	return cortejo.active and "mares" in cortejo.affixes and time >= tide_start and time < tide_start + 8.0


# ---------- Eventos do cemitério (S9) ----------

## O nível dos mortos e do saque dos eventos: 2 acima do grupo ou do Círculo escolhido.
func ev_level() -> int:
	return maxi(level, circle_level()) + 2


## S9, no anfitrião: a cada 3 a 4 minutos, com o cemitério calmo (sem Cortejo, arena, modo nem Titã acordado), começa um
## evento que não seja o último (se não der, fica para a vez seguinte); e o de agora avança.
func _event_tick() -> void:
	if event.is_empty():
		if time >= event_next:
			event_next = time + rng.randf_range(180.0, 240.0)
			if zone == "world" and cortejo.wave == 0 and arena_r == 0.0 and not mode_on() and not enemies().any(func(e): return e.boss == "tita" or e.title == "Titã Banqueteado"):
				var pool: Array = EVENTS.keys().filter(func(k): return k != event_last)
				start_event(pool[rng.randi() % pool.size()])
		return
	var mods := lvl_mods(ev_level())
	match event.id:
		"fenda":  # Fenda Necrótica (#42): 2 mortos a cada 0,5 s até 20 (e 2 elites do Círculo II em diante), sem olhar ao limite
			if event.left > 0 and time >= event.next:
				if event.left == 20 and circle_max >= 2:
					for i in 2:
						_ev_spawn("skeleton", event.pos + Vector2(-50 + 100 * i, 30), mods).make_elite()
				event.next += 0.5
				event.left -= 2
				for i in 2:
					_ev_spawn("specter" if rng.randf() < 0.3 else "skeleton", event.pos + Vector2.from_angle(rng.randf() * TAU) * rng.randf_range(20.0, 70.0), mods)
			elif time >= event.end:  # 90 s depois fecha-se, e os que ficaram desfazem-se sem deixar nada
				end_event()
				hud.toast("A fenda fechou-se.")
			elif event.left <= 0 and event.alive <= 0:  # todos mortos: um relicário na fenda
				_event_chest(1.0)
				hud.toast("A fenda fechou-se: o relicário é teu!")
				event = {}
		"meteoro":  # Meteoro Funerário (#218): cai 3 s depois do aviso; a cratera fica 120 s
			if event.left > 0 and time >= event.at:
				event.left = 0
				_land_meteor(mods)
			elif time >= event.end:
				var sealed: bool = chest != null and chest.locked
				end_event()
				hud.toast("A cratera apagou-se e levou o relicário selado." if sealed else "A cratera apagou-se.")
			elif event.left <= 0 and event.alive <= 0:  # a cratera limpa: o relicário (já aberto) fica
				event = {}
		"banquete":  # Banquete dos Espectros (#47): 4 ondas de 8 espectros, uma a cada 12 s, a caminho da carcaça
			if event.left > 0 and time >= event.next:
				event.left -= 1
				event.next = time + 12.0
				for i in 8:
					_ev_spawn("specter", event.pos + Vector2.from_angle(rng.randf() * TAU) * rng.randf_range(600.0, 700.0), mods).feast_to = event.pos
			elif event.left <= 0 and event.alive <= 0:
				if event.bar < 1.0:  # o titã não se ergueu: um relicário que vale mais quanto menos ele comeu
					_event_chest(2.0 - event.bar)
					hud.toast("O banquete acabou: o relicário é teu!")
				event = {}


## S9: começa o evento id (EVENTS) a uma distância de um herói vivo ao acaso, dentro do mapa, com o cartão e o aviso.
func start_event(id: String) -> void:
	var alive := players.filter(func(q): return not q.dead)
	if alive.is_empty():
		return
	var from: Vector2 = alive[rng.randi() % alive.size()].position
	var far := rng.randf_range(450.0, 600.0) if id == "fenda" else rng.randf_range(500.0, 700.0) if id == "meteoro" else 500.0
	var at := from
	for i in 12:  # um rumo que fique dentro do mapa e longe dos adereços altos (taparam a fenda, a cratera e a carcaça)
		at = from + Vector2.from_angle(rng.randf() * TAU) * far
		if MAP.grow(-150.0).has_point(at) and not tall.any(func(r): return r.grow(120.0).has_point(at)):
			break
	at = at.clamp(MAP.position + Vector2(150, 150), MAP.end - Vector2(150, 150))
	event_last = id
	event = {"id": id, "pos": at, "at": time + (2.0 if id == "fenda" else 3.0 if id == "meteoro" else 0.0), "end": time + (92.0 if id == "fenda" else 123.0 if id == "meteoro" else INF),
		"next": time + 2.0, "left": 20 if id == "fenda" else 4 if id == "banquete" else 1, "alive": 0, "bar": 0.0}
	if id == "fenda":  # 2 s de aviso: o anel, o pilar e o chão a tremer
		spawn_fx("ring", at, 160.0, Color(0.7, 0.4, 1.0))
		spawn_fx("pillar", at, 0.0, Color(0.7, 0.4, 1.0), Vector2.RIGHT, "necro")
	if id != "banquete":
		rumble = 2.6
	hud.name_card(EVENTS[id][0], EVENTS[id][1], "")
	hud.toast(EVENTS[id][2])
	sfx("bell", 0.7)


## Um morto do evento (ev = 1: a morte dele conta em event.alive), em at, com a força do evento.
func _ev_spawn(kind: String, at: Vector2, mods: Dictionary):
	var e = spawn_enemy(kind, at, mods, false)
	e.ev = 1
	_wear(e)
	event.alive += 1
	spawn_fx("dust", at, 40.0, Color(0.7, 0.55, 0.85))
	return e


## O relicário de um evento, na fenda ou na carcaça: ossos 8 x m, tinteiros 2 + nível/3, cinzas 1 + nível/5 e, 15%, um
## reagente da Forja (S2); tudo vezes k.
func _event_chest(k: float) -> void:
	var a := ev_level()
	var rew := [["bone", int(8 * loot_mult(a) * k)], ["ink", int((2 + a / 3) * k)], ["ash", int((1 + a / 5) * k)]]
	if rng.randf() < 0.15:
		rew.append([_reagent(), 1])
	_bank_chest()
	_spawn_chest(rew, event.pos)


## Meteoro Funerário (#218): a coluna, a explosão e 30% da vida a quem estiver no círculo (não é um golpe: a esquiva safa e
## não há Pacto nem Falange); fica a cratera, com 3 elites e 6 escoltas à volta do relicário selado, que só abre quando
## os elites caírem (ossos 10 x m, tinteiros 3 + nível/3, cinzas 2 + nível/4, um reagente e, 25%, um Coração de Titã).
func _land_meteor(mods: Dictionary) -> void:
	var at: Vector2 = event.pos
	spawn_fx("pillar", at, 0.0, Color(1.0, 0.5, 0.25), Vector2.RIGHT, "gold")
	if fx_budget("explosion", 2, 4):
		spawn_fx("explosion", at, 1.8, Color(1.0, 0.5, 0.25), Vector2.RIGHT, "gold")
	else:
		spawn_fx("ring", at, 140.0, Color(1.0, 0.5, 0.25))
	spawn_fx("dust", at, 140.0, Color(0.5, 0.45, 0.4))
	shake = 18.0
	sfx("roar")
	vibrate(200, 1.0)
	_trap(at, 140.0, 0.3, 0.5, 0.1, "Meteoro Funerário")
	if event.is_empty():  # a queda deitou o último herói: die() já acabou o evento
		return
	var a := ev_level()
	var rew := [["bone", int(10 * loot_mult(a))], ["ink", 3 + a / 3], ["ash", 2 + a / 4], [_reagent(), 1]]
	if rng.randf() < 0.25:  # o Coração de Titã (#70), uma vez em quatro
		rew.append(["coracao", 1])
	_bank_chest()
	_spawn_chest(rew, at)
	chest.locked = true
	for i in 9:  # 3 elites e 6 escoltas, à volta do relicário
		var e = _ev_spawn("skeleton" if i < 3 or rng.randf() < 0.7 else "specter", at + Vector2.from_angle(TAU * i / 9.0 + 0.3) * rng.randf_range(130.0, 200.0), mods)
		if i < 3:
			e.make_elite()


## Banquete dos Espectros (#47): o espectro chegou à carcaça e é comido (sem saque): +10% no banquete. A 100% ergue-se o
## Titã Banqueteado (um colosso maior, ao nível do evento) e os espectros que ainda vinham passam a caçar os heróis.
func feast(e) -> void:
	e.queue_free()
	if event.get("id") != "banquete":
		return
	event.alive -= 1
	event.bar = minf(1.0, snappedf(event.bar + 0.1, 0.01))  # snapped: dez vezes 0,1 dá 0,999…
	number(event.pos + Vector2(0, -110), tr("O banquete cresce"), 20.0, Color(1.0, 0.45, 0.4))
	spawn_fx("glow", event.pos + Vector2(0, -30), 70.0, Color(0.6, 0.85, 1.0))
	if event.bar < 1.0 or event.has("titan"):
		return
	event.titan = true
	event.left = 0
	for o in enemies():
		o.feast_to = Vector2.INF
	var t = _ev_spawn("colossus", event.pos, lvl_mods(ev_level()))
	t.grow(1.4)
	t.title = "Titã Banqueteado"
	spawn_fx("dust", t.position, 140.0, Color.WHITE)
	sfx("roar")
	shake = maxf(shake, 14.0)
	hud.name_card("Titã Banqueteado", "Comeu as almas que deixaste passar")


## S9: o evento acaba antes do tempo (descer à cripta, um Cortejo, cair) ou o tempo dele acabou: os mortos dele
## desfazem-se em pó, sem saque, e o relicário que ainda estiver selado vai com ele.
func end_event() -> void:
	if event.is_empty():
		return
	for e in enemies():
		if e.ev == 1:
			spawn_fx("dust", e.position, 50.0, Color(0.6, 0.55, 0.65))
			e.queue_free()
	if chest != null and chest.locked:
		chest.queue_free()
		chest = null
	event = {}


# ---------- Mausoléu Sem Fim (#27) e Santuário dos Deuses Cadavéricos (#50) ----------

## Um dos modos está a correr (a arena do monumento fica fechada).
func mode_on() -> bool:
	return mausoleum > 0 or sanctum_rule > 0


## Porque é que um modo não pode começar agora ("" se pode): nem a meio de um Cortejo, de um evento ou de outro modo.
func mode_block() -> String:
	if cortejo.wave > 0:
		return "O Cortejo Fúnebre ainda não acabou."
	if not event.is_empty():
		return "Acaba primeiro o evento do cemitério."
	if mode_on():
		return "Já estás num desafio."
	return ""


## Os modos fecham a arena do monumento, como o Cortejo (não são Provações: nenhuma começa com eles).
func _open_arena() -> bool:
	var why := mode_block()
	if why != "":
		hud.toast(why)
		return false
	_bank_chest()
	_clear_world()
	arena_r = ARENA_R
	spawn_fx("ring", monument_pos, 400.0, Color(0.9, 0.2, 0.25))
	return true


## Acaba o modo de agora: a arena abre-se e as maldições e as leis vão-se (os mortos que ficaram, ficam).
func end_mode() -> void:
	if mode_on():
		arena_r = 0.0
	mausoleum = 0
	floor_end = 0.0
	curses = []
	sanctum_rule = 0


## Mausoléu Sem Fim (#27): pisos de 40 s na arena do monumento, cada um um nível acima, a começar no do Círculo escolhido.
## A cada 5 pisos, uma maldição (os 5 selos, que se somam); um Coveiro nos pisos 5, 15…; nos 10, 20… o chefe. Abre depois
## da 1.ª vitória; o piso mais fundo fica no jogo gravado.
func start_mausoleum() -> void:
	if not _open_arena():
		return
	mausoleum = 1
	deep = maxi(deep, 1)
	floor_end = time + FLOOR_T
	curses = []
	maus_t = 0.0
	sfx("bell")
	hud.name_card("Mausoléu Sem Fim", "Aguenta 40 s em cada piso. Cair acaba a descida, sem túmulo.", "")
	_floor_start()


## A força dos mortos do piso: o nível do Círculo mais um por piso, com as maldições somadas.
func maus_mods() -> Dictionary:
	var lm := lvl_mods(circle_level() + mausoleum - 1)
	return {"hp": lm.hp * pow(1.6, curses.count("blindados")), "speed": pow(1.35, curses.count("furia")), "dmg": lm.dmg * pow(1.5, curses.count("laminas"))}


## Quantos mortos do piso de uma vez: 8 + piso (no máximo 24) e +60% por cada Legião, mas nunca mais de 48 (a separação
## dos monstros, enemy._move, custa o quadrado deles: com 3 ou 4 Legiões o telemóvel não aguentava).
func maus_cap() -> int:
	return mini(int(mini(8 + mausoleum, 24) * pow(1.6, curses.count("legiao"))), 48)


## No anfitrião: os mortos chegam à arena aos pares, até 8 + piso (no máximo 24; mais com a Legião, maus_cap), com elites do piso 3
## em diante (#277: 1, 2 do 8, 3 do 13); acabado o tempo do piso, desce-se ao seguinte.
func _mausoleum_tick(delta: float) -> void:
	if mausoleum == 0:
		return
	if time >= floor_end:
		_next_floor()
		return
	maus_t -= delta
	if maus_t > 0.0:
		return
	maus_t = 0.5
	var foes := enemies().filter(func(e): return not e.is_boss and not e.anchor and not e.dummy)
	if foes.size() >= maus_cap():
		return
	var elites: int = 0 if mausoleum < 3 else 1 if mausoleum < 8 else 2 if mausoleum < 13 else 3
	var have: int = foes.filter(func(e): return e.elite).size()
	var mods := maus_mods()
	for i in 2:
		var e = spawn_enemy("specter" if rng.randf() < 0.3 else "skeleton", monument_pos + Vector2.from_angle(rng.randf() * TAU) * rng.randf_range(460.0, 560.0), mods, false)
		spawn_fx("dust", e.position, 40.0, Color.WHITE)
		if have < elites:
			e.make_elite()
			have += 1


func _next_floor() -> void:
	mausoleum += 1
	deep = maxi(deep, mausoleum)
	floor_end = time + FLOOR_T
	number(monument_pos + Vector2(0, -280), tr("Piso %d") % mausoleum, 32.0, Color(0.85, 0.75, 1.0))
	sfx("bell", 0.8)
	_floor_start()
	if mausoleum % 5 == 1:  # depois dos pisos 5, 10, 15…: uma maldição
		hud.open_curses()


## O que cada piso traz ao começar: um colosso a mais por cada Colosso Gémeo; um Coveiro nos pisos 5, 15, 25…; nos 10,
## 20… o chefe, à vez o Arauto e o Guardião dos Monumentos (B7), e o piso só acaba quando ele cair.
func _floor_start() -> void:
	var mods := maus_mods()
	for i in curses.count("gemeo"):
		spawn_enemy("colossus", monument_pos + Vector2(-220 + 440 * (i % 2), -200 + 60 * (i / 2)), mods, false)
	if mausoleum % 10 == 5:
		var c = spawn_enemy("colossus", monument_pos + Vector2(0, -230), mods, false)
		c.title = "Coveiro"
		spawn_fx("dust", c.position, 90.0, Color.WHITE)
	elif mausoleum % 10 == 0:
		floor_end = INF
		var guard := mausoleum % 20 == 0
		var h = spawn_enemy("colossus" if guard else "herald", monument_pos + Vector2(280, -60), mods, false)
		h.rise_t = 1.4
		if guard:
			Bosses.make(h, "guardiao")
			raise_statues(h)
		spawn_fx("dust", h.position, 140.0, Color.WHITE)
		sfx("bell")
		focus_pos = h.position + Vector2(0, -40)
		focus_t = 2.0


## Santuário dos Deuses Cadavéricos (#50): no monumento, três sinos e ergue-se o Deus Cadavérico (um Arauto dourado e maior,
## com metade da vida a mais: com a armadura de 40%, os golpes diretos custam 1500 x 1,5 x a vida do Círculo, como o
## plano dizia antes da armadura), que muda a lei a cada 25% da vida (LAWS, Bosses.tick). Abre no Círculo 6; repete-se.
func start_sanctum() -> void:
	if not _open_arena():
		return
	sanctum_rule = 1
	rumble = 3.9
	hud.toast("Três sinos dobram... os Deuses Cadavéricos acordam.")
	for i in 3:
		sfx("bell")
		await get_tree().create_timer(1.3, false).timeout
		if not is_inside_tree() or sanctum_rule == 0:
			return
	var lm := lvl_mods(circle_level())
	var g = spawn_enemy("herald", monument_pos + Vector2(280, -60), {"hp": lm.hp, "dmg": lm.dmg}, false)
	Bosses.make(g, "santuario")
	g.rise_t = 1.4
	g.haste = 1.35
	g.reach = 1.3
	spawn_fx("dust", g.position, 140.0, Color.WHITE)
	focus_pos = g.position + Vector2(0, -40)
	focus_t = 3.2


# ---------- Os Sepulcros (0.4.6) ----------

func sep_depth() -> int:
	return sep_key % 1000


## O aspeto e a forma (chão, paredes, mortos, largura, voltas): a cada profundidade outro, para a 2 não parecer a 1 (a 5.ª de cada bloco é sempre o Túmulo dos Reis, o chão dos guardiões).
func sep_kind(d: int) -> Dictionary:
	return SEPS[(maxi(d, 1) - 1) % SEPS.size()]


## As regras e o guardião: a cada 5 profundidades.
func sep_block(d: int) -> Dictionary:
	return SEPS[(maxi(d, 1) - 1) / 5 % SEPS.size()]


## A força: um nível por profundidade, a partir do nível do grupo ou do último Círculo vencido (o que for maior). Nunca circle_level(): é o Círculo ainda por vencer, e as setas do menu do Cortejo mudavam-no em silêncio.
func sep_level() -> int:
	return maxi(level, 4 * circle_max - 7) + sep_depth() - 1


## O bónus do relicário, em %: 15 por profundidade seguida, até ao dobro (extra: o da próxima).
func sep_bonus(extra := 0) -> int:
	return mini(15 * (sep_streak + extra), 100)


## A regra sai da chave: a 1.ª de cada bloco não tem; o guardião tem a dele; as outras vão rodando no bloco, logo duas seguidas nunca são iguais.
func sep_rule(key: int) -> String:
	var d: int = key % 1000
	var kind := sep_block(d)
	if d % 5 == 1:
		return ""
	if d % 5 == 0:
		return kind.guard_rule
	return kind.rules[(d + key / 1000) % kind.rules.size()]


## Uma sala de 4 a 5 casas de lado dentro do lote (a do chefe, 5 x 5). next: para onde a seta aponta a partir dela.
func _sep_room(lot: Vector2i, type: String, next: int, r: RandomNumberGenerator) -> Dictionary:
	var w: int = 5 if type == "chefe" else 4 + r.randi() % 2
	var h: int = 5 if type == "chefe" else 4 + r.randi() % 2
	var at := Vector2i(1, 1) + lot * 6 + Vector2i(r.randi() % (6 - w), r.randi() % (6 - h))
	var world := Rect2(SEP_ORIGIN + Vector2(at) * SEP_CELL, Vector2(w, h) * SEP_CELL)
	var c := world.get_center()
	var spots := []
	for k in 8:
		spots.append(c + Vector2.from_angle(TAU * k / 8.0 + 0.4) * world.size * 0.31)
	return {"rect": Rect2i(at, Vector2i(w, h)), "world": world, "center": c, "type": type, "next": next, "spots": spots, "seen": false, "woken": type in ["entrada", "chefe"], "feature": null}


## Um corredor a direito entre as salas i e j, de lotes vizinhos: cada uma ocupa pelo menos 4 casas em 5, logo partilham pelo menos 3.
func _sep_link(rooms: Array, i: int, j: int, wide: int, r: RandomNumberGenerator) -> Dictionary:
	var a: Rect2i = rooms[i].rect
	var b: Rect2i = rooms[j].rect
	var side: bool = a.end.x <= b.position.x or b.end.x <= a.position.x  # lado a lado (senão, um por cima do outro)
	var lo: int = maxi(a.position.y, b.position.y) if side else maxi(a.position.x, b.position.x)
	var hi: int = mini(a.end.y, b.end.y) if side else mini(a.end.x, b.end.x)
	var at: int = lo + r.randi() % (hi - lo - wide + 1)
	var c: Rect2i
	if side:
		var x0: int = mini(a.end.x, b.end.x)
		c = Rect2i(x0, at, maxi(a.position.x, b.position.x) - x0, wide)
	else:
		var y0: int = mini(a.end.y, b.end.y)
		c = Rect2i(at, y0, wide, maxi(a.position.y, b.position.y) - y0)
	return {"rect": c, "world": Rect2(SEP_ORIGIN + Vector2(c.position) * SEP_CELL, Vector2(c.size) * SEP_CELL), "a": i, "b": j}


## turn: para onde olha uma peça de SEP_FIXED; as outras espelham-se ao calhas.
func _sep_prop(props: Array, what: String, at: Vector2, rp: RandomNumberGenerator, color: Color, turn := false) -> void:
	var fixed: bool = what in SEP_FIXED
	props.append([what, at, float(PROPS[what][1]) * (1.0 if fixed else 0.95 + rp.randf() * 0.1), turn if fixed else rp.randi() % 2 == 0, color.darkened(rp.randf() * (0.06 if fixed else 0.2))])


## Ruído de baixa frequência, de 0 a 255. Só inteiros: é o que decide o chão, e a mesma chave tem de dar o mesmo nos dois telemóveis.
func _sep_blot(nz: PackedByteArray, u: int, v: int, s: int) -> int:
	var i: int = u / s
	var j: int = v / s
	var a: int = nz[(i & 31) | (j & 31) << 5] * (s - u % s) + nz[((i + 1) & 31) | (j & 31) << 5] * (u % s)
	var b: int = nz[(i & 31) | ((j + 1) & 31) << 5] * (s - u % s) + nz[((i + 1) & 31) | ((j + 1) & 31) << 5] * (u % s)
	return (a * (s - v % s) + b * (v % s)) / (s * s)


## Uma mancha de ruído com a borda solta e sem losangos sozinhos (pareciam carimbos): conta só com 2 dos 4 vizinhos também na mancha.
func _sep_patch(nz: PackedByteArray, u: int, row: int, s: int, limit: int) -> bool:
	var near := 0
	for o in [Vector2i(1, 1), Vector2i(3, 1), Vector2i(1, 3), Vector2i(3, 3)]:
		if _sep_blot(nz, u + o.x, row + o.y, s) > limit:
			near += 1
	return near >= 2 and _sep_blot(nz, u + 2, row + 2, s) + (_sep_blot(nz, u + 9, row + 5, 2) - 128) / 3 > limit


## O chão de uma sala segue a peça dela: o índice em kind.floor de um losango (u em meios ladrilhos, row em filas). f: o losango debaixo da peça, x < 0 sem ela. Só inteiros, como _sep_blot.
func _sep_ground(look: String, u: int, row: int, f: Vector2i, nz: PackedByteArray, rt: RandomNumberGenerator) -> int:
	var has: bool = f.x >= 0
	var du: int = u - f.x
	var dr: int = row - f.y
	var d: int = 5 * du * du + 4 * dr * dr  # a distância à peça, ao quadrado, em unidades de 32 px
	match look:
		"jardim":  # ao calhas, losango a losango: é o que o Paulo gostou
			var roll: int = rt.randi() % 100
			return 2 if roll < 2 else 1 if roll < 24 else 0
		"cisterna":  # um canal que sai da grade e serpenteia até ao fim da sala; e umas poças soltas
			if has and absi(du - (absi((dr + 4) % 16 - 8) - 4) / 2) <= (2 if _sep_blot(nz, u, row, 3) > 120 else 1):
				return 1
			return 1 if _sep_patch(nz, u, row + 64, 4, 188) else 0
		"forno":  # cinza ao pé da boca, brasas à volta, e lajes mais longe
			var edge: int = 96 + _sep_blot(nz, u, row, 4) / 2 + _sep_blot(nz, u + 7, row + 3, 2)
			if not has:
				return 1 if _sep_patch(nz, u, row, 4, 190) else 0
			return 1 if d * 256 < 36 * edge else 2 if d * 256 < 140 * edge else 0
		"tumulo":  # o corredor de mármore: a direito de propósito
			return 1 if has and absi(du) <= 3 else 0
	# O ossário: manchas de ossos, mais ao pé do nicho
	return 1 if _sep_patch(nz, u, row, 5, 178 - (maxi(0, 320 - d) / 3 if has else 0)) else 0


## O centro do losango mais perto (a conta do chão de plan_sep): os adereços soltos ficam no meio de um ladrilho, nunca numa junta.
func _sep_tile(at: Vector2) -> Vector2:
	var tw := 256.0 * TILE_SCALE
	var hh := TILE_HH * TILE_SCALE
	var row := roundi((at.y - SEP_ORIGIN.y) / hh) + 2
	var half: float = tw / 2.0 if row % 2 == 1 else 0.0
	return SEP_ORIGIN + Vector2(-tw + (roundi((at.x - SEP_ORIGIN.x - half) / tw) + 1) * tw + half, -hh * 2.0 + row * hh)


## O Sepulcro da chave key: a mesma chave dá o mesmo mapa nos dois telemóveis, sem o mapa viajar.
func plan_sep(key: int) -> Dictionary:
	var d: int = key % 1000
	var kind := sep_kind(d)
	var s := 7717 + key * 15485
	var r := RandomNumberGenerator.new()  # as salas e os corredores
	r.seed = s
	var rp := RandomNumberGenerator.new()  # os adereços
	rp.seed = s + 1
	var rt := RandomNumberGenerator.new()  # o ladrilho de cada casa de chão
	rt.seed = s + 2
	# O caminho: 3 linhas de lotes, sempre para a frente: não há como encravar nem é preciso tentar outra vez
	var lots := []
	var col: int = r.randi() % 3
	for line in 3:
		lots.append(Vector2i(col, line))
		if line == 2:
			break
		var to: int = r.randi() % 3
		if line == 1 and lots.size() == 2 and to == col:  # pelo menos 4 salas
			to = (col + 1) % 3
		if lots.size() + absi(to - col) > 5:  # e no máximo 6
			to = col + signi(to - col)
		while col != to:
			col += signi(to - col)
			lots.append(Vector2i(col, line))
	var flow: int = r.randi() % 4  # de baixo para cima, de cima para baixo, ou de lado
	lots = lots.map(func(v): return [Vector2i(v.x, 2 - v.y), v, Vector2i(v.y, v.x), Vector2i(2 - v.y, v.x)][flow])
	var n: int = lots.size()
	var fights: Array = ["bando", "emboscada"] + (["sineiros"] if d >= 3 else [])
	var rooms := []
	for i in n:
		var type: String = "entrada" if i == 0 else "chefe" if i == n - 1 else fights[r.randi() % fights.size()]
		rooms.append(_sep_room(lots[i], type, mini(i + 1, n - 1), r))
	var links := []
	for i in n - 1:
		links.append(_sep_link(rooms, i, i + 1, kind.wide, r))
	# 1 ou 2 salas de desvio, em lotes livres ao lado de uma sala; no Forno ligam a todas as vizinhas (uma volta)
	var sides: Array = ["capela", "cofre"] if r.randi() % 2 == 0 else ["cofre", "capela"]
	for k in 1 + r.randi() % 2:
		var near := []
		for ly in 3:
			for lx in 3:
				var q := Vector2i(lx, ly)
				if not q in lots and lots.any(func(o): return absi(o.x - q.x) + absi(o.y - q.y) == 1):
					near.append(q)
		var lot: Vector2i = near[r.randi() % near.size()]
		var adj: Array = range(lots.size()).filter(func(o): return absi(lots[o].x - lot.x) + absi(lots[o].y - lot.y) == 1)
		rooms.append(_sep_room(lot, sides[k], adj[0], r))
		lots.append(lot)
		for o in adj:
			if kind.loop or o == adj[0]:
				links.append(_sep_link(rooms, o, rooms.size() - 1, kind.wide, r))
	var grid := PackedByteArray()
	grid.resize(SEP_SIDE * SEP_SIDE)
	grid.fill(0)
	for i in rooms.size():
		var ra: Rect2i = rooms[i].rect
		for y in range(ra.position.y, ra.end.y):
			for x in range(ra.position.x, ra.end.x):
				grid[x + y * SEP_SIDE] = i + 1
	for l in links:
		var la: Rect2i = l.rect
		for y in range(la.position.y, la.end.y):
			for x in range(la.position.x, la.end.x):
				grid[x + y * SEP_SIDE] = SEP_LINK
	# As paredes saem da grelha: o que se vê é o que trava. A margem de 1 casa deixa ver os vizinhos sem testar limites
	var props := []
	var prop_c: Color = kind.prop
	var pick := func(names: Array) -> String: return names[rp.randi() % names.size()]
	var tw := 256.0 * TILE_SCALE
	var hh := TILE_HH * TILE_SCALE
	# As portas: a saída fica longe de onde se nasce (o botão de interagir é também a esquiva); a do chefe a norte da sala dele
	var first: Rect2 = rooms[0].world
	var last: Dictionary = rooms[n - 1]
	var exit: Vector2 = first.get_center() + Vector2(0, -first.size.y / 2.0 + 50.0)
	var shift := 0  # a descida tem de ter parede atrás: sobre a boca de um corredor, as escadas flutuavam. Anda de meio em meio ladrilho até lá, longe da outra porta (só inteiros)
	var door0: int = (last.rect.position.x * 4 + last.rect.size.x * 2) * 704 - 2200
	for off in 40:
		var to: int = (off + 1) / 2 * 704 * (-1 if off % 2 == 1 else 1)
		var c0: int = (door0 + to - 1000) / 2816
		var c1: int = (door0 + to + 1000) / 2816
		if c0 >= last.rect.position.x and c1 < last.rect.end.x and grid[c0 + (last.rect.position.y - 1) * SEP_SIDE] == 0 and grid[c1 + (last.rect.position.y - 1) * SEP_SIDE] == 0 and absi(to - 4400) >= 2400:
			shift = to
			break
	var down: Vector2 = last.center + Vector2(-220.0 + shift / 10.0, -last.world.size.y / 2.0 + 50.0)
	var up: Vector2 = last.center + Vector2(220, -last.world.size.y / 2.0 + 50.0)
	# As armadilhas e as gárgulas ficam nas últimas 3 salas (a do chefe primeiro: o Guardião tem os martelos à volta)
	var spots := []
	for i in range(n - 1, n - 4, -1):
		spots.append(rooms[i].center + Vector2(-280, -130))
		spots.append(rooms[i].center + Vector2(280, 130))
	# Os adereços soltos: no meio de um ladrilho, longe das portas, das armadilhas e uns dos outros. Sem lugar, não há adereço
	var taken: Array = [exit, down, up] + spots
	var put := func(what: String, spot: Vector2, gap: float, turn: bool) -> bool:
		var q: Vector2 = _sep_tile(spot)
		if taken.any(func(o): return o.distance_to(q) < gap) or rooms.any(func(o): return o.feature != null and o.world.has_point(q) and absf(q.x - o.feature.x) < 300.0):  # o eixo da peça (o canal, o corredor de mármore) fica livre
			return false
		_sep_prop(props, what, q, rp, prop_c, turn)
		taken.append(q)
		return true
	# A peça de cada sala, na parede norte: no troço mais comprido, no meio ladrilho mais perto do meio da parede, longe das portas. Os pares à volta dela, espelhados e fora da grelha dos ladrilhos.
	# Só inteiros (x em décimos de píxel a contar de SEP_ORIGIN; uma casa tem 2816 x 1991, meio ladrilho 704): o que isto decide tem de dar o mesmo nos dois telemóveis
	var ww: int = int(SEP_WALL) * 10
	var marks := []  # o losango debaixo da peça de cada sala (o chão segue-a); x < 0 sem peça
	var paired := []
	var door_free := func(i: int, at: Vector2i) -> bool:
		var ra: Rect2i = rooms[i].rect
		var mid: int = (ra.position.x * 4 + ra.size.x * 2) * 704
		var doors: Array = [mid] if i == 0 else [mid - 2200 + shift, mid + 2200] if i == n - 1 else []
		var dy: int = at.y - ra.position.y * 1991 - 500
		return doors.all(func(o): return (at.x - o) * (at.x - o) + dy * dy >= 2890000)
	for i in rooms.size():
		var ra: Rect2i = rooms[i].rect
		var y: int = ra.position.y
		var mid: int = ra.position.x * 4 + ra.size.x * 2
		var u0 := -1
		var lo := 0
		var hi := 0
		if kind.feature != "" or rooms[i].type == "capela":
			var x: int = ra.position.x
			var best := Vector2i.ZERO
			while x < ra.end.x:
				var x1 := x
				while x1 < ra.end.x and grid[x1 + (y - 1) * SEP_SIDE] == 0:
					x1 += 1
				if x1 - x > best.y - best.x:
					best = Vector2i(x, x1)
				x = maxi(x1, x + 1)
			lo = best.x * 4 - (1 if grid[best.x - 1 + y * SEP_SIDE] == 0 else 0)
			hi = best.y * 4 - 1
			var aim: int = clampi(mid - 1, lo + 5, hi - 5) if hi - lo >= 10 else (lo + hi) / 2  # com lugar para os pares, se o troço der
			if rooms[i].type == "capela":  # a capela é a peça da sala dela (as velas vêm abaixo): o chão segue-a, sem pares e sem peça na parede
				u0 = aim
				rooms[i].feature = SEP_ORIGIN + Vector2(aim * 704, y * 1991 + 400) / 10.0
			else:
				for off in 40:  # de dentro para fora
					var u: int = aim + (off + 1) / 2 * (1 if off % 2 == 1 else -1)
					if u * 704 - ww / 2 >= lo * 704 - (0 if grid[best.x - 1 + y * SEP_SIDE] == 0 else 50) and u * 704 + ww / 2 <= hi * 704 and door_free.call(i, Vector2i(u * 704, y * 1991 - 60)):
						u0 = u
						rooms[i].feature = SEP_ORIGIN + Vector2(u * 704, y * 1991 - 60) / 10.0
						taken.append(rooms[i].feature)
						break
		marks.append(Vector2i(u0, 4 * y + 2))
		if u0 < 0 or rooms[i].type == "capela":
			continue
		for pair in kind.pairs:
			var off: int = pair[1] if pair[1] > 0 else (mini(u0 - lo, hi - u0) - 2) * 704  # 0: perto das pontas da parede
			var fits: bool = off > ww / 2
			for sx in [-1, 1]:
				var at := Vector2i(u0 * 704 + sx * off, y * 1991 - 60 + pair[2] * 10)
				if not door_free.call(i, at):
					fits = false
				for cx in [(at.x - 700) / 2816, (at.x + 700) / 2816]:  # no chão desta sala, com parede atrás e longe da boca de um corredor
					if grid[cx + y * SEP_SIDE] != i + 1 or grid[cx + (y - 1) * SEP_SIDE] != 0 or grid[cx - 1 + y * SEP_SIDE] == SEP_LINK or grid[cx + 1 + y * SEP_SIDE] == SEP_LINK:
						fits = false
			if fits:
				for sx in [-1, 1]:
					var q: Vector2 = SEP_ORIGIN + Vector2(u0 * 704 + sx * off, y * 1991 - 60 + pair[2] * 10) / 10.0
					props.append([pair[0], q, float(PROPS[pair[0]][1]), sx > 0, prop_c])
					taken.append(q)
					paired.append(q)
	# O que cada sala tem de ter
	var lights := []
	var glows := []
	for i in rooms.size():
		var room: Dictionary = rooms[i]
		var w: Rect2 = room.world
		var far: bool = (marks[i].x >= 0 and marks[i].x < room.rect.position.x * 4 + room.rect.size.x * 2 - 1) or (i == n - 1 and shift < -704)  # a peça para oeste, ou a descida no canto oeste: a lanterna de cima passa para o outro canto, para não ficar à frente delas
		for at in [Vector2(w.end.x - 90.0 if far else w.position.x + 90.0, w.position.y + 90.0), w.end - Vector2(90, 40)]:  # duas lanternas nos cantos
			var lamp: Vector2 = _sep_tile(at)
			_sep_prop(props, "lantern", lamp, rp, Color.WHITE)
			taken.append(lamp)
			lights.append([lamp, 150.0])
			glows.append([lamp, 70.0])
		match room.type:
			"emboscada":
				for q in room.spots:
					_sep_prop(props, "coffin_open", q, rp, prop_c)
				taken.append_array(room.spots)
			"capela":
				_sep_prop(props, "chapel", room.feature, rp, Color.WHITE)
				taken.append(room.feature)
				for sx in [-90.0, 90.0]:
					_sep_prop(props, "candles", room.center + Vector2(sx, 0), rp, Color.WHITE)
					glows.append([room.center + Vector2(sx, 0), 50.0])
	# As bordas: poucas coisas e um ladrilho para dentro, longe dos dentes do chão, nunca em duas casas seguidas da mesma borda nem num corredor de 1 casa (ficavam a meio do caminho)
	var low: Array = kind.south.filter(func(o): return PROPS[o][1] <= 70.0)  # a sul só coisas baixas, para não tapar o herói
	var edge := {}
	for y in SEP_SIDE:
		for x in SEP_SIDE:
			if grid[x + y * SEP_SIDE] == 0:
				continue
			var top: Vector2 = SEP_ORIGIN + Vector2(x, y) * SEP_CELL
			var to_n: bool = grid[x + (y - 1) * SEP_SIDE] == 0
			var to_s: bool = grid[x + (y + 1) * SEP_SIDE] == 0
			var to_e: bool = grid[x + 1 + y * SEP_SIDE] == 0
			if to_e != (grid[x - 1 + y * SEP_SIDE] == 0) and rp.randf() < 0.35 and not edge.has(Vector3i(x, y - 1, int(to_e))):
				var t: float = 0.75 if to_n else 0.25 if to_s else 0.25 + 0.5 * (rp.randi() % 2)
				var at: Vector2 = top + (Vector2(tw, SEP_CELL.y * (t - 0.25)) if to_e else Vector2(tw / 2.0, SEP_CELL.y * t))
				if put.call(pick.call(kind.side), at, 170.0, to_e):
					edge[Vector3i(x, y, int(to_e))] = true
			if to_s and not to_n and rp.randf() < 0.3 and not edge.has(Vector3i(x - 1, y, 2)) and put.call(pick.call(low), top + SEP_CELL / 2.0, 170.0, false):
				edge[Vector3i(x, y, 2)] = true
	# O recheio: até 2 por sala, no que as bordas deixaram, longe do meio (relicário, chefe, início) e da boca dos corredores
	for room in rooms:
		var w: Rect2 = room.world
		var fill := 0
		for tries in 9:
			var q: Vector2 = _sep_tile(w.position + Vector2(140 + rp.randi() % int(w.size.x - 350.0), 100 + rp.randi() % int(w.size.y - 250.0)))
			if fill < 2 and q.distance_to(room.center) > 220.0 and not links.any(func(l): return l.world.grow(170.0).has_point(q)) and put.call(pick.call(kind.south), q, 200.0, false):
				fill += 1
	# A parede norte, troço a troço, de canto a canto: vai de onde a fila de cima do chão começa (meio ladrilho antes da casa, se aí houver vazio) até onde acaba (meio ladrilho antes do fim). Peças iguais lado a lado, com os pés na linha; nada a sair por cima do vazio.
	# Sobrepostas pelo menos 10 px (os pilares são mais estreitos do que os capitéis: coladas, via-se o vazio entre eles); a peça da sala vem por cima e as lisas enchem o resto de cada lado
	for y in SEP_SIDE:
		var x := 0
		while x < SEP_SIDE:
			var x1 := x
			while x1 < SEP_SIDE and grid[x1 + y * SEP_SIDE] != 0 and grid[x1 + (y - 1) * SEP_SIDE] == 0:
				x1 += 1
			if x1 > x and kind.feature == "":  # a ruína do Jardim: solta, com árvores à frente
				var from: float = SEP_ORIGIN.x + x * SEP_CELL.x - (tw / 2.0 if grid[x - 1 + y * SEP_SIDE] == 0 else 0.0)
				var span: float = SEP_ORIGIN.x + x1 * SEP_CELL.x - tw / 2.0 - from
				var steps: int = ceili((span - SEP_RUIN) / SEP_RUIN) if span > SEP_RUIN * 1.6 else 0
				var bare := 2  # as peças de parede desde a última coisa à frente: é o que se quer ver
				for k in steps + 1:
					var at := Vector2(from + SEP_RUIN / 2.0 + (span - SEP_RUIN) * k / steps if steps > 0 else from + span / 2.0, SEP_ORIGIN.y + y * SEP_CELL.y - 6.0)
					_sep_prop(props, kind.north[0], at, rp, prop_c)
					var more: String = pick.call(kind.north)
					bare += 1
					if more != kind.north[0] and bare > 2 and absf(at.x - down.x) > 200.0:  # à frente da parede, nunca em vez dela: a parede não tem buracos; e nunca à frente das escadas
						_sep_prop(props, more, at + Vector2(0, 2), rp, prop_c)
						bare = 0
			elif x1 > x:
				var run0: int = x * 2816 - (704 if grid[x - 1 + y * SEP_SIDE] == 0 else 0)
				var run1: int = x1 * 2816 - 704
				var cuts: Array = []
				for i in rooms.size():
					if rooms[i].rect.position.y == y and rooms[i].type != "capela" and marks[i].x >= 0 and marks[i].x * 704 >= run0 and marks[i].x * 704 <= run1:
						cuts.append(marks[i].x * 704)
				cuts.sort()
				var a := run0
				for cut in cuts + [-1]:
					var b: int = cut - ww / 2 + 100 if cut >= 0 else run1
					if b > a:
						var steps: int = (b - a - 101) / (ww - 100) if b - a > ww else 0  # ceil((b - a - ww) / (ww - 100))
						for k in steps + 1:
							var mx: int = a + ww / 2 + (b - a - ww) * k / steps if steps > 0 else clampi((a + b) / 2, run0 + ww / 2, run1 - ww / 2)
							props.append([kind.north[0], SEP_ORIGIN + Vector2(mx, y * 1991 - 60) / 10.0, 170.0, false, prop_c])
					a = cut + ww / 2 - 100
				for cut in cuts:
					props.append([kind.feature, SEP_ORIGIN + Vector2(cut, y * 1991 - 60) / 10.0, 170.0, false, prop_c])
			x = maxi(x1, x + 1)
	props.append(["waypoint_on", exit, 110.0, false, Color.WHITE])
	props.append(["sep_stairs", down + Vector2(0, -56), 170.0, false, Color.WHITE])  # os pés na linha da parede; sep.down, onde se carrega, fica à frente delas
	props.append(["waypoint_on", up, 110.0, false, Color.WHITE])
	for at in [exit, down, up]:
		lights.append([at, 120.0])
		glows.append([at, 80.0])
	# Os losangos: cada casa de chão pinta os dela e, à volta, a orla mais escura, para os pés nunca pisarem o vazio.
	# Só inteiros. Um losango toca na casa se um canto da sua caixa lá cair: filas 4y+1 a 4y+7, colunas 2x+1 a 2x+3 (2x a 2x+3 nas filas ímpares)
	var cols := SEP_SIDE * 2 + 4
	var nrows := SEP_SIDE * 4 + 6
	var mask := PackedByteArray()
	mask.resize(nrows * cols)
	mask.fill(0)
	for y in SEP_SIDE:
		for x in SEP_SIDE:
			if grid[x + y * SEP_SIDE] == 0:
				continue
			var fl: int = 2 if grid[x + y * SEP_SIDE] == SEP_LINK else 2 + grid[x + y * SEP_SIDE]  # 2: corredor; 3 ou mais: a sala (grelha + 2)
			for row in range(4 * y + 1, 4 * y + 8):
				for c in range(2 * x + (1 if row % 2 == 0 else 0), 2 * x + 4):
					var core: bool = row >= 4 * y + 2 and row <= 4 * y + 5 and c >= 2 * x + 1 and c <= 2 * x + 2
					if core:
						mask[row * cols + c] = fl
					elif mask[row * cols + c] == 0:
						mask[row * cols + c] = 1
	var sz := TILE_SCALE * 1.03  # um pouco maior para não haver frestas, como plan_map
	var dark_c: Color = Color(kind.tile).darkened(0.75)  # a orla: o herói não pisa isto, e é o que desenha a parede
	var rows := []
	var kinds := []
	var nz := PackedByteArray()  # o ruído do chão: sai da chave
	nz.resize(1024)
	for i in 1024:
		nz[i] = rt.randi() % 256
	for row in nrows:
		var line := []
		line.resize(cols)  # null onde não há chão
		for c in cols:
			var m: int = mask[row * cols + c]
			if m == 0:
				continue
			var fl := 0
			if m > 2:
				fl = _sep_ground(kind.look, 2 * c + row % 2 - 2, row, marks[m - 3], nz, rt)
			elif m == 2 and kind.look != "tumulo" and rt.randi() % 25 == 0:  # os corredores: o ladrilho de base, raras vezes outro
				fl = 1
			var tk: String = kind.floor[fl]
			var tex: Texture2D = TILES[tk]
			var pos: Vector2 = SEP_ORIGIN + Vector2(-tw + c * tw + (tw / 2.0 if row % 2 == 1 else 0.0), -hh * 2.0 + row * hh)  # a mesma conta de plan_map (main:3392)
			line[c] = [tex, Rect2(pos.x - 128.0 * sz, pos.y - TILE_LV[tk] * sz, 256.0 * sz, tex.get_height() * sz), dark_c if m == 1 else kind.tints[0] if m == 2 else kind.tints[fl]]
			kinds.append(tk)
		rows.append(line)
	var path: Array = rooms.slice(0, n).map(func(q): return q.center)
	return {"grid": grid, "rooms": rooms, "links": links, "rows": rows, "props": props, "lights": lights, "glows": glows, "path": path, "spots": spots, "n": n,
		"start": first.get_center(), "exit": exit, "down": down, "up": up, "boss": last.center, "paired": paired, "sum": hash([grid, kinds, props.map(func(q): return q[0])])}


## Monta o plano neste telemóvel (nos dois: é o que se vê; as colisões só as usa o anfitrião). A direito, sem fatias: corre debaixo do negro de hud.fade().
func sep_build() -> void:
	_sep_clear()
	sep = plan_sep(sep_key)
	sep_built = sep_key
	sep_grid = sep.grid
	sep_aim = 1
	var from := tall.size()
	for q in sep.props:
		var tex: Texture2D = PROPS[q[0]][0]
		var sp := _prop(tex, q[1], q[2] / tex.get_height(), q[3], sep_node)
		sp.modulate = q[4]
		if q[0] == "sep_stairs" or q[1] == sep.up:
			sep_doors.append(sp)
	sep_tall = tall.slice(from)  # o _prop escreve em tall: fica lá só o mundo
	tall.resize(from)
	floor_node.queue_redraw()


func _sep_clear() -> void:
	for c in sep_node.get_children():
		c.queue_free()
	sep = {}
	sep_built = 0
	sep_tall = []
	sep_doors = []


## Nos dois telemóveis, antes do return do convidado. Testa o estado a cada frame: a chave e a zona podem chegar por qualquer ordem (net:531), e de uma profundidade para outra a zona não muda.
func _sep_tick() -> void:
	if zone != "sep":
		return
	if sep_built != sep_key and sep_key > 0:
		sep_build()
		zone_view(player.position)
	if sep.is_empty():
		return
	for q in players:
		var id := sep_room_at(q.position)
		if id >= 0:
			sep.rooms[id].seen = true
	for sp in sep_doors:
		sp.modulate = Color.WHITE if sep_done == 1 else Color(0.35, 0.35, 0.4)


## Toque no Portão: nem a meio de um Cortejo, de um evento ou de um modo. Cada ida é um mapa novo.
func sep_enter(d: int) -> void:
	var why := mode_block()
	if why != "":
		hud.toast(why)
		return
	sep_runs += 1
	sep_streak = 0
	_sep_go(d)
	sep_bank = currency.duplicate()  # depois: o saque do mundo e o relicário por abrir (_change_zone) vieram de fora, não contam como apanhados nesta ida


## Uma profundidade: chave nova, mapa novo, e o _change_zone guarda o saque e o relicário.
func _sep_go(d: int) -> void:
	guardian = null
	guardian_met = false
	sep_key = sep_runs * 1000 + mini(d, 999)
	sep_done = 0
	crypt_rule = sep_rule(sep_key)
	sep_elites = 1 if d < 8 else 2 if d < 13 else 3
	sep_build()
	_change_zone("sep", sep.start)
	var mods := lvl_mods(sep_level())
	_sep_boss(d, mods)
	_rule_setup(sep.path, sep.spots, Vector2.RIGHT, mods)
	hud.name_card(sep_kind(d).name, CRYPT_RULES[crypt_rule][1] if crypt_rule != "" else "Derrota o chefe e abre o relicário.", tr("Profundidade %d") % d)
	sfx("bell", 0.7)
	save_game()


func sep_descend() -> void:
	sep_streak += 1
	_sep_go(sep_depth() + 1)


func sep_leave() -> void:
	guardian = null
	sep_streak = 0
	_change_zone("world", GATE + Vector2(0, -230))  # fora dos 170 px da dica do Portão: senão a esquiva voltava a descer
	var got := []
	for k in currency:
		if currency[k] > sep_bank.get(k, 0):
			got.append("%s x%d" % [tr(Loot.INFO[k][0]), currency[k] - sep_bank.get(k, 0)])
	if got.is_empty():
		hud.toast("De volta ao cemitério.")
	else:
		hud.toast(tr("Trouxeste %s.") % ", ".join(got) + ("\n" + tr("Recorde: profundidade %d.") % sep_max if sep_max > 0 else ""))  # sem chefe vencido não há recorde
	save_game()


## No anfitrião, 4 vezes por segundo (o relógio de _camps_tick): as salas só se enchem com um herói lá dentro, porque o aggro não vê paredes.
func _sep_wake() -> void:
	if zone != "sep" or sep.is_empty():
		return
	for q in players:
		var id := sep_room_at(q.position)
		if q.dead or id < 0 or sep.rooms[id].woken:
			continue
		var room: Dictionary = sep.rooms[id]
		if room.type == "emboscada" and q.position.distance_to(room.center) > 250.0:  # os caixões esperam que chegues ao meio
			continue
		if room.type == "capela" and players.all(func(h): return not h.dead and h.hp >= h.max_hp * 0.95):  # de vida cheia não se gasta: fica para quando for preciso
			if not room.has("told"):
				room.told = true
				hud.toast("Uma capela: volta cá quando precisares.")
			continue
		match room.type:
			"capela":  # Capela: sem tocar em nada, a vida e as poções voltam; quem caiu levanta-se
				room.woken = true
				for h in players:
					if h.dead:
						h.revive()
					h.heal(h.max_hp)
					h.fill_potions(99.0)
					spawn_fx("glow", h.position + Vector2(0, -40), 90.0, Color(0.4, 1.0, 0.65))
				sfx("potion")
				hud.toast("Uma capela: a vida e as poções voltam.")
			"cofre":  # Cofre de Sangue (#32, #191): nunca no caminho obrigatório; o mesmo que o relicário da Sentinela e um reagente
				room.woken = true
				_bank_chest()
				_spawn_chest(_sep_rew(sep_level(), 1.0 + sep_bonus() / 100.0) + [[_reagent(), 1]], room.center)
				chest.locked = true
			_:
				var pack: int = 8 if room.type == "emboscada" else mini(5 + sep_depth() / 5, 8)
				if enemies().size() + pack <= mini(SEP_CAP, DENSITY[settings.density]):  # o teto conta a sala que vai nascer; senão espera. A "Quantidade de monstros" vale aqui também: é a alavanca do Paulo sem APK novo
					room.woken = true
					_sep_pack(room, pack)


## Bando, Emboscada (#195) ou Sineiros (#206): pack mortos a sair do pó, espalhados à volta da sala; os elites da profundidade vão saindo nos primeiros.
func _sep_pack(room: Dictionary, pack: int) -> void:
	var d := sep_depth()
	var kind := sep_kind(d)
	var mods := lvl_mods(sep_level())
	for i in pack:
		var at: Vector2 = room.spots[i * 3 % 8]  # 0, 3, 6, 1...: os pontos 0 a 3 ficavam todos na metade sul
		var e = spawn_enemy("specter" if rng.randf() < kind.spec else "skeleton", at, mods, false)
		_wear(e)
		e.paint = kind.paint if e.skin == "" else Color.WHITE
		e.tier = d / 5 * 2  # o XP e o saque sobem a cada 5 profundidades
		e.aggro = 260.0 if crypt_rule == "silencio" else INF  # Sanctum do Silêncio (#46): sono pesado
		spawn_fx("dust", at, 40.0, Color.WHITE)
		if sep_elites > 0:
			sep_elites -= 1
			e.make_elite()
		elif room.type == "sineiros" and i >= pack - 2:  # 2 sinos e não o bando todo: cada um traz um colosso
			e.ringer_at = -1.0  # ring_bell serve tal e qual: o colosso chama-se Reforço, sem o Frasco de chefe
	if room.type == "emboscada":
		sfx("bell", 0.6)
		hud.toast("Emboscada!")
	elif room.type == "sineiros":
		hud.toast("Sineiros: cala-os ou vem um colosso.")


## Há mortos na sala deste herói? Com eles o botão continua a ser a esquiva: ninguém sai nem paga por engano a meio de uma luta. Conta só a sala dele: um morto preso do outro lado da parede não tranca a porta.
func sep_calm(q) -> bool:
	var id := sep_room_at(q.position)
	return id < 0 or not enemies().any(func(e): return sep_room_at(e.position) == id)


## Pagar o Cofre: 25% da vida a cada herói de pé, nunca mata (pay_life). who: quem carregou (o botão de um herói não paga pelo que o outro está a fazer).
func near_seal(who = null) -> bool:
	if zone != "sep" or chest == null or not chest.locked:
		return false
	return ([who] if who != null else players).any(func(q): return not q.dead and q.position.distance_to(chest.position) < 110.0 and sep_calm(q))


func pay_seal() -> void:
	for q in players:
		if not q.dead:
			q.pay_life(q.max_hp * 0.25)
	chest.locked = false
	chest.open()
	spawn_fx("ring", chest.position, 120.0, Color(0.9, 0.15, 0.1))
	sfx("hurt")
	hud.toast("O cofre abriu-se: pagaste com sangue.")


## Nasce a dormir no meio da sala dele, como o Carcereiro. Sentinela no fim de cada profundidade; a cada 5, o guardião do bloco.
func _sep_boss(d: int, mods: Dictionary) -> void:
	var guard: bool = d % 5 == 0
	var pick: String = sep_block(d).guard if guard else ""
	var big: bool = pick in ["guardiao", "arauto"]  # já têm 2,3 vezes a vida do colosso
	guardian = spawn_enemy("herald" if pick in ["monge", "carrasco", "arauto"] else "colossus", sep.boss, {"hp": mods.hp * (1.0 if big else 1.8 if guard else 1.4), "dmg": mods.dmg * (1.2 if guard else 0.9)}, false)
	guardian.title = "Arauto Fúnebre" if pick == "arauto" else "Sentinela"
	guardian.paint = sep_kind(d).paint
	guardian.aggro = 480.0
	guardian.tier = d / 5 * 2
	if not guard:  # maior do que um Reforço; a 1.ª de cada bloco é a mais calma: as outras têm a Marca à distância e o golpe final com botão, sem o resto do make_elite
		guardian.grow(1.25)
		guardian.elite = d % 5 != 1
	elif pick == "arauto":  # com as fases do Cortejo
		guardian.rage_at = 0.5
		guardian.haste = 1.35
		guardian.reach = 1.3
	else:
		Bosses.make(guardian, pick)
		if pick == "monge":  # dorme mesmo: _monk não olha para awake e correr faz barulho; sem isto saía da sala antes de o verem
			guardian.heard = INF


## O relicário de uma Sentinela e o do Cofre: nunca dá 0 de nada.
func _sep_rew(a: int, k: float) -> Array:
	return [["bone", int(4.0 * loot_mult(a) * k)], ["ink", int((2 + a / 5) * k)], ["ash", int((1 + a / 8) * k)]]


## O chefe caiu: o relicário no meio da sala (no chão, mesmo que ele tenha caído noutro lado) e as duas saídas abrem-se.
func _sep_boss_down(e) -> void:
	var d := sep_depth()
	var a := sep_level()
	var m := loot_mult(a)
	var k := 1.0 + sep_bonus() / 100.0
	var rew: Array
	if d % 5 == 0:  # a fórmula da cripta x 1,5, um reagente certo e 20% de Coração
		rew = [["bone", int(9.0 * m * k)], ["ink", int((2 + a / 3) * 1.5 * k)], ["ash", int((1 + a / 4) * 1.5 * k)], [_reagent(), 1]]
		if rng.randf() < 0.2:
			rew.append(["coracao", 1])
		if d > sep_max:  # a 1.ª vitória sobre este guardião: a Relíquia em falta (há 5); sem nenhuma, cinzas a dobrar
			var gone: Array = RELICS.keys().filter(func(q): return not q in relics)
			if gone.is_empty():
				rew[2][1] *= 2
			else:
				collect(drop("relic", e.position, 1, Vector2.from_angle(rng.randf() * TAU) * 140.0, gone[rng.randi() % gone.size()]))  # já: sep_max fica gravado e o saque do chão não
	else:
		rew = _sep_rew(a, k)
	sep_done = 1
	var first_guard: bool = d % 5 == 0 and d > sep_max
	sep_max = maxi(sep_max, d)
	if is_instance_valid(chest) and chest.locked:  # só há um relicário de cada vez: o Cofre por pagar sai para dar lugar a este e volta quando se entrar na sala dele (_sep_wake). Só se perde ao descer
		for r in sep.rooms:
			if r.type == "cofre":
				r.woken = false
	_bank_chest()
	_spawn_chest(rew, sep.boss + Vector2(0, 60))
	hud.toast(tr("Guardião vencido: já podes começar na profundidade %d.") % (d + 1) if first_guard else "Abre o relicário. Depois, sobe ou arrisca mais fundo.")
	save_game()


## Dentro de uma sala, para a abertura que leva à seguinte (de uma sala de desvio, de volta); num corredor, para a sala a que ele vai dar. Com o chefe caído, primeiro o relicário: quem seguia a seta descia e levava-o sem o estrondo. É local: não precisa de guardian, que no convidado costuma faltar.
func _sep_goal() -> Vector2:
	if sep.is_empty():
		return player.position
	if sep_done == 1:
		return chest.position if is_instance_valid(chest) and not chest.opened and not chest.locked else sep.down
	var id := sep_room_at(player.position)
	if id >= 0:
		sep_aim = sep.rooms[id].next
		for l in sep.links:
			if id != sep_aim and id in [l.a, l.b] and sep_aim in [l.a, l.b]:
				return l.world.get_center()
	return sep.rooms[sep_aim].center


# ---------- Cenário ----------

## Adereços são Sprite2D com os pés na origem, para o y-sort pôr os heróis atrás deles.
func _prop(tex: Texture2D, pos: Vector2, sc: float, flip := false, to: Node = self) -> Sprite2D:
	var sp := Sprite2D.new()
	sp.texture = tex
	sp.offset = Vector2(0, -tex.get_height() / 2.0)
	sp.scale = Vector2(sc, sc)
	sp.flip_h = flip
	sp.position = pos
	to.add_child(sp)
	# Os altos (estátuas, lanternas, árvores, capelas, o monumento, as escadas da cripta) tapam quem passa atrás (#92);
	# guarda-se só o meio do desenho: as pontas são quase só vazio
	var box := tex.get_size() * sc
	if box.y >= 100.0:
		tall.append(Rect2(pos.x - box.x * 0.3, pos.y - box.y, box.x * 0.6, box.y))
	return sp


func _hub_rect() -> Rect2:
	return Rect2(monument_pos - HUB_SPOT, HUB.get_size())


## O número do mapa de agora: muda com o Círculo e a cada vitória. O 103 não pode ser múltiplo de 6 menos 1: a vitória
## normal (Círculo +1, vitórias +1) tem de mudar REGION_ORDER.
func map_seed() -> int:
	return circle + wins * 103


## O mapa do número c, no sítio, sem recarregar a cena. slice: em jogo, reparte o trabalho por vários frames.
func build_map(c: int, slice := true) -> void:
	c = maxi(c, 1)  # no convidado vem da rede
	map_circle = c
	map_job += 1
	map_busy = true
	var job := map_job
	var t0 := Time.get_ticks_usec()
	var plan: Dictionary = await plan_map(c, slice, job)
	if plan.is_empty():
		return  # uma reconstrução mais nova ficou com o lugar
	map_ms = (Time.get_ticks_usec() - t0) / 1000.0
	for e in enemies():
		if e.camp >= 0:
			e.queue_free()  # os bandos do mapa antigo; o que falta matar (camp_left) segue para o novo
	map_spots = plan.spots
	region_now = ""  # as zonas mudaram de sítio
	camps = plan.camps
	map_tex = plan.tex
	map_hash = plan.sum
	tile_rows = plan.rows
	tall = tall_fixed.duplicate()
	glows = glows_fixed.duplicate()
	floor_node.queue_redraw()
	if slice and cortejo.wave == 0 and zone == "world" and not mode_on():  # o negro tapa a troca, e o sino diz que o cemitério mudou (cada telemóvel o seu); na cripta não se vê, e se a onda ou o modo começou durante a troca não se corta a luta
		hud.fade()
		sfx("bell", 0.7, true)
		if hud.toast_t <= 0.0:
			hud.toast("O cemitério mudou.", true)
	var old := scenery.get_children()
	for i in maxi(old.size(), plan.props.size()):
		if i < old.size():
			old[i].queue_free()
		if i < plan.props.size():
			_place(plan.props[i])
		if slice and i % 60 == 59:
			await get_tree().process_frame
			if job != map_job or not is_inside_tree():
				return
	tiles.queue_redraw()  # os brilhos novos: tiles só se desenha uma vez por mapa
	map_busy = false
	map_builds += 1


## O mapa do número c, sem tocar em nós nem no rng do jogo: o mesmo c dá o mesmo mapa nos dois telemóveis.
func plan_map(c: int, slice := false, job := 0) -> Dictionary:
	var until := Time.get_ticks_usec() + MAP_SLICE_US
	var s := 6661 + c * 7919
	var r := RandomNumberGenerator.new()  # os centros e os acampamentos
	r.seed = s
	var rp := RandomNumberGenerator.new()  # os adereços
	rp.seed = s + 1
	var rt := RandomNumberGenerator.new()  # uma jogada por ladrilho, sempre consumida
	rt.seed = s + 2
	var rn := RandomNumberGenerator.new()  # os adereços "new" (0.4.7), à parte: rp segue igual, a praça e os lugares não mudam
	rn.seed = s + 3
	var noise := FastNoiseLite.new()
	noise.seed = s
	noise.frequency = 0.0012
	var noise2 := FastNoiseLite.new()
	noise2.seed = s + 13
	noise2.frequency = 0.004
	var hub := _hub_rect()
	var spots := {"campo": Vector2(0, 1650)}
	var order: Array = REGION_ORDER[(c - 1) % REGION_ORDER.size()]
	for i in order.size():
		spots[order[i]] = REGION_SPOTS[i] + Vector2(r.randf_range(-250.0, 250.0), r.randf_range(-200.0, 200.0))
	# Acampamentos: o 1.º do Campo é o do primeiro minuto; sem lugar, o centro da região (nunca parte o jogo)
	var sites := []
	for id in ["campo"] + order:
		for k in CAMPS_PER:
			var site: Vector2 = spots[id]
			for i in 200:
				var q: Vector2 = spots[id] + Vector2.from_angle(r.randf() * TAU) * r.randf_range(400.0, 1200.0)
				if MAP.grow(-280.0).has_point(q) and not hub.grow(220.0).has_point(q) and absf(q.x) > 420.0 and q.distance_to(CRYPT_DOOR) > 800.0 and q.distance_to(GATE) > 600.0 \
						and q.distance_to(Vector2(0, 300)) > 1200.0 and q.distance_to(monument_pos) > 1500.0 and _region_in(q, spots, hub) == id \
						and sites.all(func(o): return o.pos.distance_to(q) > 900.0) and (not sites.is_empty() or q.y < 1900.0):
					site = q
					break
			sites.append({"pos": site, "region": id})
	# Adereços: primeiro os de cada acampamento, depois os soltos (pesos acumulados por região; grelha de 256 px para não se atropelarem)
	var picks := {}
	for id in REGIONS:
		var names := []
		var sums := []
		var total := 0
		for n in PROPS:
			total += PROPS[n][2] * REGIONS[id].props.get(n, 1)
			names.append(n)
			sums.append(total)
		picks[id] = [names, sums, total]
	var props := []
	var big := [[CRYPT_DOOR, 170.0], [GATE, 300.0]]
	for site in sites:
		big.append([site.pos, 300.0])
		for st in REGIONS[site.region].stamp:
			props.append([st[0], site.pos + st[1], float(PROPS[st[0]][1]), false, REGIONS[site.region].prop])
	var inner := hub.grow(-260.0)
	var cells := {}
	for i in PROP_CAP * 4:
		if props.size() >= PROP_CAP:
			break
		if slice and Time.get_ticks_usec() > until:
			await get_tree().process_frame
			if job != map_job or not is_inside_tree():
				return {}
			until = Time.get_ticks_usec() + MAP_SLICE_US
		var pos := Vector2(rp.randf_range(MAP.position.x + 40, MAP.end.x - 40), rp.randf_range(MAP.position.y + 40, MAP.end.y - 40))
		if inner.has_point(pos) or (absf(pos.x) < 230.0 and pos.y > 0.0):
			continue
		var id := _region_in(pos, spots, hub)
		var kind: String = picks[id][0][picks[id][1].bsearch(rp.randi() % picks[id][2], false)]
		var h: float = PROPS[kind][1] * rp.randf_range(0.9, 1.1)
		var rad := h * 0.4
		var free := true
		for b in big:
			if pos.distance_to(b[0]) < rad + b[1]:
				free = false
				break
		var cell := Vector2i((pos / 256.0).floor())
		for x in range(-1, 2):
			for y in range(-1, 2):
				for o in cells.get(cell + Vector2i(x, y), []):
					if free and pos.distance_to(o[0]) < rad + o[1]:
						free = false
		if not free:
			continue
		if not cells.has(cell):
			cells[cell] = []
		cells[cell].append([pos, rad])
		var fresh: Array = REGIONS[id].get("new", [])
		if not fresh.is_empty() and rn.randf() < REGION_NEW:  # shortcut: a folga (rad) fica a do que saiu, um novo mais alto pode roçar num vizinho; mudar só se se notar
			var other: String = fresh[rn.randi() % fresh.size()]
			h *= PROPS[other][1] / PROPS[kind][1]
			kind = other
		props.append([kind, pos, h, rp.randf() < 0.5, Color(REGIONS[id].prop).darkened(rp.randf() * 0.2)])
	# Chão: losangos em fila, cada fila meia célula ao lado da anterior. O limite entre zonas lê a região um pouco ao lado (o ruído), para não ser uma linha reta
	var w := 256.0 * TILE_SCALE
	var hh := TILE_HH * TILE_SCALE
	var sz := TILE_SCALE * 1.03  # um pouco maior para não haver frestas entre losangos
	var rows := []
	var kinds := []
	var img := Image.create(64, 48, false, Image.FORMAT_RGB8)  # o minimapa: 100 px por píxel
	for row in int(MAP.size.y / hh) + 6:
		if slice and Time.get_ticks_usec() > until:
			await get_tree().process_frame
			if job != map_job or not is_inside_tree():
				return {}
			until = Time.get_ticks_usec() + MAP_SLICE_US
		var line := []
		for col in int(MAP.size.x / w) + 4:
			var pos := Vector2(MAP.position.x - w + col * w + (w / 2.0 if row % 2 == 1 else 0.0), MAP.position.y - hh * 2.0 + row * hh)
			var n := noise.get_noise_2d(pos.x, pos.y)
			var n2 := noise2.get_noise_2d(pos.x, pos.y)
			var id := _region_in(pos + Vector2(n, n2) * 220.0, spots, hub)
			var kind := _tile_at(id, pos, n, n2, rt.randf())
			var tex: Texture2D = TILES[kind]
			line.append([tex, Rect2(pos.x - 128.0 * sz, pos.y - TILE_LV[kind] * sz, 256.0 * sz, tex.get_height() * sz), REGIONS[id].tile])
			kinds.append(kind)
			var px := Vector2i(((pos - MAP.position) / 100.0).floor())
			if px.x >= 0 and px.y >= 0 and px.x < 64 and px.y < 48:
				img.set_pixelv(px, Color(0.1, 0.2, 0.3) if kind == "water" else Color(0.6, 0.55, 0.4) if kind.begins_with("cobble") else REGIONS[id].map)
		rows.append(line)
	return {"rows": rows, "props": props, "camps": sites, "spots": spots, "tex": ImageTexture.create_from_image(img), "sum": hash([kinds, props, sites])}


## Um adereço do plano: [nome, pos, altura, flip, cor].
func _place(q: Array) -> void:
	var tex: Texture2D = PROPS[q[0]][0]
	_prop(tex, q[1], q[2] / tex.get_height(), q[3], scenery).modulate = q[4]
	if q[0] in ["lantern", "candles"]:
		glows.append([q[1], 70.0 if q[0] == "lantern" else 50.0])


func _region_in(pos: Vector2, spots: Dictionary, hub: Rect2) -> String:
	if hub.has_point(pos):
		return "praca"
	var best := "campo"
	var near := INF
	for id in spots:
		var d: float = pos.distance_squared_to(spots[id])
		if d < near:
			near = d
			best = id
	return best


func region_at(pos: Vector2) -> String:
	return _region_in(pos, map_spots, _hub_rect())


## O nome da zona aparece ao entrar nela, só neste telemóvel (player é o herói dele).
func _region_tick(delta: float) -> void:
	region_t -= delta
	if region_t > 0.0:
		return
	region_t = 0.5
	if zone != "world" or cortejo.wave > 0 or mode_on():
		return
	var r := region_at(player.position)
	var text: String = REGIONS[r].name
	if player.position.distance_to(GATE) < 260.0:
		r = "portao"
		text = "O Portão dos Reis está aberto: desce aos Sepulcros." if wins >= 1 else "O Portão dos Reis está fechado. Quebra o Cortejo Fúnebre para o abrir."
	if text != "" and r != region_now and hud.toast_t <= 0.0:  # a praça não conta: voltar dela à mesma zona não repete o nome; e o nome espera pelo aviso que estiver à vista
		region_now = r
		hud.toast(text, true)


## O nome por cima de um lugar fixo do cemitério (as escadas da cripta, o Portão dos Reis).
func _name_label(text: String, at: Vector2, color: Color) -> void:
	var label := Label.new()
	label.text = text
	label.position = at
	label.size = Vector2(400, 32)
	label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	label.add_theme_font_size_override("font_size", 32)
	label.add_theme_color_override("font_color", color)
	label.add_theme_color_override("font_outline_color", Color.BLACK)
	label.add_theme_constant_override("outline_size", 6)
	add_child(label)


## O que não muda com o mapa, feito uma vez: as escadas, o monumento, o altar, a estrada de estátuas e o Portão dos Reis.
func _gen_fixed() -> void:
	_prop(CRYPT_DOOR_TEX, CRYPT_DOOR, 200.0 / CRYPT_DOOR_TEX.get_height())
	glows.append([CRYPT_DOOR + Vector2(0, 10), 100.0])
	_name_label("Cripta dos Condenados", CRYPT_DOOR + Vector2(-200, -248), Color(0.55, 1.0, 0.7))
	monument = _prop(MON, monument_pos, 230.0 / MON.get_height())
	var deco := [[preload("res://art/props/waypoint_on.png"), Vector2(-150, 420), 80.0], [preload("res://art/props/shrine_on.png"), SHRINE, 90.0]]
	for d in deco:
		_prop(d[0], d[1], d[2] / d[0].get_height())
		glows.append([d[1], 80.0])
	var statue: Texture2D = PROPS.statue[0]
	for y in range(680, 1961, 320):
		for x in [-190.0, 190.0]:
			_prop(statue, Vector2(x, y), PROPS.statue[1] / statue.get_height(), x > 0.0).modulate = REGIONS.campo.prop
	var gate: Texture2D = PROPS.gatehouse[0]
	gate_node = _prop(gate, GATE, 300.0 / gate.get_height())
	glows.append([GATE, 100.0])
	_name_label("Portão dos Reis", GATE + Vector2(-200, -348), Color(1.0, 0.85, 0.4))
	tall_fixed = tall.duplicate()
	glows_fixed = glows.duplicate()


func _tile_at(id: String, pos: Vector2, n: float, n2: float, roll: float) -> String:
	if absf(pos.x) < 110.0 and pos.y > 300.0 and pos.y < GATE.y + 50.0:  # a estrada da praça ao Portão dos Reis
		return "cobble_moss" if roll < 0.35 else "cobble"
	match id:
		"bosque":
			if n < -0.3:
				return "slab_roots" if roll < 0.4 else "mud"
			return "mud" if n > 0.25 else "bones" if roll < 0.02 else "grass"
		"pantano":
			if n2 > 0.1:
				return "water"
			return "slab_roots" if roll < 0.06 else "grass" if n < -0.1 else "mud"
		"ossario":
			if n2 > 0.1:
				return "bones"
			if n < 0.1:
				return "slab_roots" if roll < 0.3 else "slab"
			return "bones" if roll < 0.35 else "mud"
		"campo":  # lajes e ossos em terra cor de ferrugem: é a primeira zona que se vê e não pode ser o chão de sempre
			if n < -0.12 or pos.distance_to(GATE) < 420.0:
				return "slab_roots" if roll < 0.3 else "slab"
			if roll < 0.18:
				return "bones"
			return "mud" if n > 0.05 else "grass"
	if n2 > 0.55:  # a orla da praça: o chão de sempre
		return "water"
	if n < -0.38:
		return "slab_roots" if roll < 0.3 else "slab"
	if roll < 0.05:
		return "bones"
	return "mud" if n > 0.2 else "grass"


## O chão redesenha-se quando a câmara se afasta FLOOR_STEP do ponto à volta do qual foi desenhado. Uma âncora e não uma
## grelha: o tremor da câmara (cada golpe) trocava de casa quase todos os frames em cima de uma linha, e x = 0 é uma linha.
func _floor_tick() -> void:
	var at := cam.get_screen_center_position()
	if absf(at.x - floor_at.x) > FLOOR_STEP or absf(at.y - floor_at.y) > FLOOR_STEP:
		floor_at = at
		floor_node.queue_redraw()


## O que o chão tem de cobrir. 0,85: o zoom mais largo (arena); a folga é o passo e a saia dos ladrilhos.
func _floor_view() -> Rect2:
	var half := get_viewport_rect().size / 2.0 / 0.85 + Vector2.ONE * (FLOOR_STEP + 160.0)
	return Rect2(floor_at - half, half * 2.0)


## Os ladrilhos à volta da câmara, por ordem de filas: cada um tem uma saia que a fila seguinte tapa.
func _draw_floor() -> void:
	var rows: Array = sep.get("rows", []) if zone == "sep" else tile_rows
	var from: Vector2 = SEP_ORIGIN if zone == "sep" else MAP.position
	if zone != "sep":
		floor_node.draw_rect(MAP.grow(200.0), Color(0.05, 0.07, 0.06))
	var view := _floor_view()
	var w := 256.0 * TILE_SCALE
	var hh := TILE_HH * TILE_SCALE
	var r0 := clampi(int((view.position.y - from.y) / hh) + 2, 0, rows.size())
	var r1 := clampi(int((view.end.y - from.y) / hh) + 3, 0, rows.size())
	for r in range(r0, r1):
		var row: Array = rows[r]
		var c0 := clampi(int((view.position.x - from.x) / w), 0, row.size())
		var c1 := clampi(int((view.end.x - from.x) / w) + 3, 0, row.size())
		for c in range(c0, c1):
			var t = row[c]
			if t != null:  # nos Sepulcros há vazio
				floor_node.draw_texture_rect(t[0], t[1], false, t[2])
	if zone == "sep":  # os brilhos ficam aqui: glows e tiles são do mundo
		var glow: Texture2D = Fx.Pix.glow_tex()
		for g in sep.get("glows", []):
			floor_node.draw_texture_rect(glow, Rect2(g[0] - Vector2.ONE * g[1], Vector2.ONE * g[1] * 2.0), false, Color(0.35, 1.0, 0.6, 0.2))


## A praça, a cripta e os brilhos: desenhados uma vez por mapa.
func _draw_tiles() -> void:
	tiles.draw_texture_rect(HUB, _hub_rect(), false)
	tiles.draw_texture_rect(CRYPT, Rect2(CRYPT_ORIGIN, CRYPT.get_size()), false)
	var glow: Texture2D = Fx.Pix.glow_tex()
	for g in glows + CRYPT_GLOWS.map(func(p): return [CRYPT_ORIGIN + p, 140.0]):
		tiles.draw_texture_rect(glow, Rect2(g[0] - Vector2.ONE * g[1], Vector2.ONE * g[1] * 2.0), false, Color(0.35, 1.0, 0.6, 0.2))


func _draw_world() -> void:
	for pool in blood:  # Sangue no Solo (#23): poça escura que seca no último segundo
		var a: float = clampf(pool[1] - time, 0.0, 1.0)
		Pix.haze(ground, pool[0], BLOOD_R, BLOOD_R, Pix.RAMPS.bleed[3], 0.75 * a)
		Pix.haze(ground, pool[0] + Vector2(6, -4), BLOOD_R * 0.5, BLOOD_R * 0.5, Pix.RAMPS.bleed[2], 0.6 * a)
	for c in corpses:  # Espasmo Cadavérico: crânios com a cor do estado de quem morreu; piscam no último segundo e meio
		var tex: Texture2D = PROPS["skulls"][0]
		var sz := tex.get_size() * (28.0 / tex.get_height())
		var a: float = 0.9 if c[2] - time > 1.5 else 0.5 + 0.5 * sin(time * 12.0)
		ground.draw_texture_rect(tex, Rect2(c[0] - sz / 2.0, sz), false, Color(CORPSE_COLORS[c[1]], a))
	for e in enemies():  # Marca da Cova (#277): o aviso no chão enche até rebentar (a área é a mesma do golpe)
		if e.mark_end > time:
			Pix.warn(ground, e.mark_at, Enemy.MARK_R, 1.0 - (e.mark_end - time) / Enemy.MARK_T)
	for tooth in teeth:  # Dentes de Sepultura: três pontas de osso que se desfazem, a encolher aos degraus
		var h: float = ceilf(minf(1.0, tooth[1]) * 3.0) * 4.0
		for k in 3:
			Pix.solid(ground, tooth[0] + Vector2((k - 1) * 9.0, (k % 2) * 4.0), [Vector2(-4, 2), Vector2(4, 2), Vector2(0, -h)], "bone")
	for s in sentinels:  # Sentinelas Tumulares (#25): a lápide fincada, assente pelo pé como os adereços; desfaz-se no último segundo
		var tex: Texture2D = PROPS["grave_broken"][0]
		var w: float = 52.0 * tex.get_width() / tex.get_height()
		ground.draw_texture_rect(tex, Rect2(s[0] - Vector2(w / 2.0, 52.0), Vector2(w, 52.0)), false, Color(0.8, 0.88, 0.84, clampf(s[1] - time, 0.0, 1.0)))
	if cortejo.active and "mares" in cortejo.affixes:  # Marés de Sangue Negro (#212): o chão da arena escurece a vermelho nos 3 s de aviso e fica assim na maré
		var flood: float = clampf((time - tide_start + 3.0) / 3.0, 0.0, 1.0) if time < tide_start + 8.0 else 0.0
		Pix.flood(ground, monument_pos, ARENA_R, _view_rect(), Color(0.35, 0.0, 0.04), 0.5 * flood)
	for s in shelters():  # Chamas Negras (#35) e as lajes do Cortejo (S8): discos de pedra com um anel de runas a rodar devagar
		Pix.slab(ground, s[0], s[1], time)
	for k in rocks:  # Minas de Enxofre (#43): pedras amarelas a brilhar; a armada pisca a branco até rebentar
		Pix.haze(ground, k[0], 32.0, 32.0, Color(1.0, 0.9, 0.3), 0.45 + 0.125 * sin(time * 3.0))
		ground.draw_set_transform(k[0])
		ground.draw_colored_polygon(PackedVector2Array(ROCK), Color(1.0, 1.0, 0.85) if k[1] > 0.0 and int(time * 16.0) % 2 == 0 else Color(1.0, 0.9, 0.3))
		ground.draw_polyline(PackedVector2Array(ROCK + [ROCK[0]]), Color(0.35, 0.25, 0.05), 2.0)
		ground.draw_set_transform(Vector2.ZERO)
	for h in hammers:  # Forja das Almas Escravas (#184): a bigorna, um disco de ferro escuro; o aviso enche no último 1,2 s
		Pix.anvil(ground, h[0], 90.0)
		var w: float = 1.0 - (h[1] - time) / 1.2
		if w > 0.0:  # como o aviso do murro do Colosso
			Pix.warn(ground, h[0], 90.0, w)
	for b in belts():  # Moinho de Carne (#202): a passadeira com setas a andar para a serra, e a serra de 12 dentes a rodar
		Pix.belt(ground, b[0], b[1], 130.0, 35.0, time)
		Pix.saw(ground, b[0] + b[1] * 130.0, time)
	if not event.is_empty():  # S9: o que o evento deixa no chão (o convidado desenha-o do mesmo dicionário)
		var at: Vector2 = event.pos
		match event.id:
			"fenda":  # Fenda Necrótica (#42): uma elipse violeta a pulsar, que abre nos 2 s de aviso
				var fr: float = 90.0 * clampf(1.0 - (event.at - time) / 2.0, 0.2, 1.0) + 8.0 * sin(time * 5.0)
				Pix.fenda(ground, at, fr, time, effects_level())
			"meteoro":  # Meteoro Funerário (#218): o alvo vermelho enche até cair, como os outros avisos; depois a cratera
				if time < event.at:
					Pix.warn(ground, at, 140.0, 1.0 - (event.at - time) / 3.0)
				else:
					Pix.crater(ground, at, 220.0)
					Pix.haze(ground, at + Vector2(Pix.S, Pix.S), 120.0, 120.0, Color(0.65, 0.24, 0.05), 0.2 + 0.06 * sin(time * 2.0))  # brasas soltas no fundo: mais densas faziam riscas com a fuligem; a 1 célula do meio, os pontos caem em cima dos dela
			"banquete":  # Banquete dos Espectros (#47): a carcaça do titã deitada (o último desenho da morte do colosso)
				var tex: Texture2D = Enemy.FRAMES32.colossus[31]
				var sz: Vector2 = tex.get_size() * Enemy.Feet32.SCALE.colossus32
				ground.draw_texture_rect(tex, Rect2(at - Vector2(sz.x / 2.0, sz.y), sz), false, Color(0.72, 0.78, 0.8))
	# Brilho do monumento: verde em repouso, vermelho durante o Cortejo
	var glow := Color(0.9, 0.15, 0.2) if cortejo.active else Color(0.3, 1.0, 0.6)
	var gr := 110.0 + sin(time * 3.0) * 12.0
	Pix.haze(ground, monument_pos, gr, gr, glow.darkened(0.5), 0.3)
	# Arena do chefe: muro de chamas de alma que não deixa ninguém fugir
	if arena_r > 0.0:
		Pix.wall(ground, monument_pos, arena_r, _view_rect(), time, effects_level())
	ground.draw_rect(MAP, Color(0.2, 0.18, 0.15), false, 10.0)


## O mundo que a câmara apanha agora.
func _view_rect() -> Rect2:
	var half := get_viewport_rect().size / 2.0 / cam.zoom
	return Rect2(cam.get_screen_center_position() - half, half * 2.0)


## Nevoeiro do cemitério (o fog, num shader): um banco por baixo das personagens, mais denso e lento nos efeitos altos;
## efeitos baixos sem nevoeiro. Nenhum por cima delas: acinzentava o ecrã e os monstros liam-se mal.
## Um quadro do tamanho da vista; o ruído lê-se no mundo e não escorrega.
func _draw_fog() -> void:
	var lvl := effects_level()
	if zone != "world" or lvl == 0:
		return
	fog.material.set_shader_parameter("depth", 0.5 if lvl == 1 else 1.0)
	var half := get_viewport_rect().size / 2.0 / cam.zoom + Vector2(64, 64)
	fog.draw_rect(Rect2(cam.get_screen_center_position() - half, half * 2.0), Color.WHITE)


## Catacumbas Cegas (#26): o escuro, um quadro do tamanho da vista com as luzes de lights() (só com dark_on()).
func _draw_dark() -> void:
	var ls := lights()
	var arr := PackedVector3Array(ls)
	arr.resize(16)  # o shader tem sempre 16; count diz quantas valem
	dark.material.set_shader_parameter("lights", arr)
	dark.material.set_shader_parameter("count", ls.size())
	var half := get_viewport_rect().size / 2.0 / cam.zoom + Vector2(64, 64)
	dark.draw_rect(Rect2(cam.get_screen_center_position() - half, half * 2.0), Color.WHITE)


## Silhueta atrás das paredes (#92): quem fica tapado por um adereço alto desenha-se outra vez por cima dele, numa cor
## só (a do herói; vermelho nos monstros). Só entram na conta os adereços que a câmara apanha.
func _draw_xray() -> void:
	var half := get_viewport_rect().size / 2.0 / cam.zoom
	var view := Rect2(cam.get_screen_center_position() - half, half * 2.0)
	var near := (sep_tall if zone == "sep" else tall).filter(func(r): return view.intersects(r))
	if near.is_empty():
		return
	for c in players + enemies():
		# quem ainda sai do chão ou já está a morrer não tem silhueta (o desenho dele ainda/já não se vê)
		if (c in players or (c.rise_t <= 0.0 and not c.dying)) and behind_prop(c, near):
			xray.draw_set_transform_matrix(c.transform * c.pose)
			xray.draw_texture(c.pose_tex, Vector2.ZERO, Color(c.tint, 0.55) if c in players else Color(1.0, 0.25, 0.25, 0.45))


## O meio do desenho de c fica dentro de um adereço alto e os pés dele estão acima da base do adereço
## (o y-sort desenha o adereço depois dele). rects = tall, ou só os que estão à vista.
func behind_prop(c, rects: Array) -> bool:
	if c.pose_tex == null:
		return false
	var mid: Vector2 = c.transform * c.pose * (c.pose_tex.get_size() / 2.0)
	for r in rects:
		if r.end.y > c.position.y and r.has_point(mid):
			return true
	return false
