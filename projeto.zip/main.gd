extends Node2D
## Soulstrider: Necro-Dominion — protótipo. Mundo, loot, moedas, arma, co-op e o Cortejo Fúnebre.

const MAP := Rect2(-3200, -2400, 6400, 4800)
const Enemy := preload("res://enemy.gd")
const Loot := preload("res://loot.gd")
const Decoy := preload("res://decoy.gd")
const Fx := preload("res://fx.gd")
const Pix := preload("res://fx_pix.gd")
const Bolt := preload("res://bolt.gd")
const Player := preload("res://player.gd")
const Hud := preload("res://hud.gd")
const Chest := preload("res://chest.gd")
const Ally := preload("res://ally.gd")
const Tomb := preload("res://tomb.gd")
const SILHOUETTE := preload("res://silhouette.gdshader")
const FOG := preload("res://fog.gdshader")
const DARK := preload("res://dark.gdshader")
const Bosses := preload("res://bosses.gd")
const MAX_ALLIES := 4

const SUFFIXES := {
	"do Sangramento": {"bleed": 0.5},
	"da Ossada": {"dmg": 0.25},
	"da Vigília": {"regen": 3.0},
	"do Tutano": {"leech": 0.04},
	"do Coveiro Veloz": {"speed": 0.15},
	"da Podridão": {"rot": 1.0},  # #148: dano contínuo que pega a quem estiver encostado
	"da Calcificação": {"calcify": 1.0},  # #150: à 10.ª camada o inimigo vira estátua
	"da Necrose": {"necro": 1.0},  # #154: cada golpe uma camada (até 10), +5% de dano recebido por camada
}
const OFFENSIVE := ["do Sangramento", "da Ossada", "da Podridão", "da Calcificação", "da Necrose"]  # os que o Tinteiro Carmesim (#59) troca
const HIDDEN := {
	"Ruína dos Colossos: +60% dano a chefes": {"boss": 0.6},
	"Banquete Fúnebre: +5 vida por abate": {"kill_heal": 5.0},
	"Alma Faminta: +35% dano de feitiços": {"spell": 0.35},
}
const AFFIXES := {
	"blindados": ["Ossos Blindados", "inimigos +60% vida"],
	"furia": ["Fúria Espectral", "inimigos +35% velocidade"],
	"laminas": ["Lâminas Envenenadas", "inimigos +50% dano"],
	"legiao": ["Legião", "+60% escoltas"],
	"gemeo": ["Colosso Gémeo", "+1 colosso em cada onda"],
	"rebeldes": ["Almas Rebeldes", "mortos voltam e rebentam"],
	"sinos": ["Sineiros", "cala-os ou vem um colosso"],
	"ceifador": ["O Ceifador Ambulante", "a morte anda atrás de ti"],
	"eclipse": ["Eclipse Fúnebre", "a luz apaga-se: elites +30%"],
	"mares": ["Marés de Sangue Negro", "maré alta: fica nas pedras"],
	"dentes": ["Chuva de Dentes", "abriga-te nas pedras"],
}
const SEALS := ["blindados", "furia", "laminas", "legiao", "gemeo"]  # S8: os selos do Círculo (#27) são sempre estes 5
const CARDS := 6  # e o menu do Cortejo mostra 6 afixos de cada vez (affix_cards)
## Provações (Desafios, #37 e #214): [nome, o que muda]. Uma de cada vez, escolhida antes da 1.ª onda; dura o Cortejo.
const TRIALS := {
	"almas": ["Provação das Almas Rejeitadas", "Sem Frascos de Alma nem Alma Condensada. Saque a dobrar; a primeira vitória dá um Frasco que te falte."],
	"lamina": ["Provação da Lâmina Cega", "A arma não conta (sufixos, oculto e reforja) e os golpes básicos não saem: só habilidades. Saque a dobrar."],
}
## Eventos do cemitério (S9): [nome, o que fazer (no cartão), o aviso]. Um de cada vez, a cada 3 a 4 minutos, nunca o
## mesmo duas vezes seguidas.
const EVENTS := {
	"fenda": ["Fenda Necrótica", "Mata a horda antes de a fenda fechar", "Uma fenda necrótica abriu-se!"],
	"meteoro": ["Meteoro Funerário", "Sai do círculo vermelho e mata os elites da cratera", "Um meteoro funerário vai cair!"],
	"banquete": ["Banquete dos Espectros", "Trava os espectros antes que comam o titã", "Os espectros vêm para o banquete!"],
	"carruagem": ["Carruagem Fúnebre", "Parte as rodas para a parar", "Uma carruagem fúnebre passa na estrada!"],  # Lote 9, #48: do Círculo III em diante
}
const CART_ROUTE := [Vector2(0, 1550), Vector2(0, 500), Vector2(2350, -150), Vector2(0, -1900), Vector2(-2350, -150), Vector2(0, 500)]  # #48: a estrada da carruagem, à volta: do Portão (GATE) sobe a estrada de pedra (entre as estátuas) até à praça, depois este, norte, oeste e desce outra vez
## Santuário dos Deuses Cadavéricos (#50): as 4 leis, uma a cada 25% da vida do deus: [nome, a lei, o que muda].
const LAWS := [
	["Primeira lei", "a cura fere", "O que te cura tira-te vida (nunca abaixo de 1)."],
	["Segunda lei", "a alma paga-se com sangue", "As habilidades custam vida em vez de alma (nunca matam)."],
	["Terceira lei", "a alma esvai-se", "Perdes 8 de alma por segundo; cada morte dá 30."],
	["Quarta lei", "só a morte cura", "As poções não fazem nada; cada morte cura 5% da vida."],
]
const FLOOR_T := 40.0  # Mausoléu Sem Fim (#27): quanto dura cada piso (os de chefe, até ele cair)
## Relíquias de Família (#58): [nome, lenda]. Caem dos chefes com nome; cada uma dá +1 ponto na Árvore a cada herói.
const RELICS := {
	"anel": ["Anel da Avó Coveira", "Enterrou três maridos. Nenhum ficou quieto."],
	"coracao": ["Coração Embalsamado de Herói", "Ainda bate quando alguém diz o nome dele."],
	"medalha": ["Medalha do Primeiro Ceifeiro", "Dada a quem ceifou mil almas sem perder a sua."],
	"chave": ["Chave da Cripta da Família", "Abre uma porta que já ninguém encontra."],
	"sino": ["Badalo do Sino Rachado", "Caiu do sino do Arauto na noite em que morreu pela primeira vez."],
}
## G7 (Lote 8): as almas da arma, [nome, o que faz, a cor do golpe (fx_pix.gd)]. A foice é sempre a do grupo: leva uma de
## cada vez, escolhida na Forja, e só mexe no golpe básico (a foice do Strider e o machado do Cavaleiro). O ícone e a cor
## dele estão em Loot.TEX: a cor já vem no ícone (sem Loot.TINT desde a SC-ICO8).
const FORMS := {
	"foice_longa": ["Foice Longa", "Golpe básico com mais alcance: 40% mais área e 10% mais dano, mas 25% mais lento.", "ash"],  # osso velho, cinzento: o "bone" era o machado de sempre do Cavaleiro
	"juramento": ["Lâmina do Juramento Quebrado", "Partida ao meio: alcance curto, mas golpeia ao dobro da cadência.", "soulblue"],  # Lote 9 C (d): azul vivo (o "iron" era um risco claro que quase não se via)
	"sino": ["Sino da Agonia", "Cada golpe básico badala: 40% do dano a todos a 4 m do monstro.", "gold"],
	"cutelo": ["Cutelo da Peste Vermelha", "Os golpes básicos espalham ácido: os monstros a 3 m perdem metade da armadura durante 4 s, e sangram mais 25%.", "rot"],
	"tibias": ["Disparador de Tíbias", "A cada 3 golpes básicos sai também uma tíbia farpada que atravessa 5 monstros em linha (60% do dano).", "life"],  # Lote 9 C (d): vermelho (o "loot_bone" era o dourado do Sino)
	"basilisco": ["Dente de Basilisco Necrótico", "Nos chefes, cada golpe básico junta veneno, sem limite: quanto mais longa a luta, mais dói. Nos outros, sangram mais 30%.", "necro"],
}
const FORM_CHANCE := 0.4  # G7: um único de chefe com nome sai como alma da arma (se faltar alguma)
## #185 Atlas dos Sepulcros (Lote 11): as melhorias de cada bloco de 5 profundidades, [nome, Estacas Fúnebres], pela ordem dos bits de atlas
const ATLAS_UP := {"capela": ["Capela garantida", 1], "cofre": ["Cofre mais rico", 1], "pecas": ["O guardião larga 2 peças", 2], "coracao": ["Coração de Titã: 50% no guardião", 3]}
const ATLAS_MAX := 200  # blocos (999 profundidades / 5): o atlas nunca passa disto, nem na rede
const COMMON_MATS := ["enxofre", "martelo", "agulha", "cinzel"]  # G5: os materiais comuns (as Cinzas Maiores só dos guardiões, do Santuário e do Mausoléu)
const PILES := {"bone": "Ossos Ancestrais", "ink": "Tinteiros de Sangue Negro", "ash": "Cinzas do Purgatório"}  # o que a Pena de Abutre (#239) arrisca
const WAVES := 3
const REVIVE_T := 2.5
const CRIT := 0.12
const CRIT_MULT := 1.8
const ARENA_R := 620.0
const SFX := {
	"hit": preload("res://sfx/hit.wav"), "crit": preload("res://sfx/crit.wav"), "hurt": preload("res://sfx/hurt.wav"),
	"bell": preload("res://sfx/bell.wav"), "roar": preload("res://sfx/roar.wav"), "chest": preload("res://sfx/chest.wav"),
	"levelup": preload("res://sfx/levelup.wav"), "potion": preload("res://sfx/potion.wav"), "victory": preload("res://sfx/victory.wav"),
	"swing": preload("res://sfx/swing.wav"), "swing_heavy": preload("res://sfx/swing_heavy.wav"), "cast": preload("res://sfx/cast.wav"),
	"dash": preload("res://sfx/dash.wav"), "chime": preload("res://sfx/chime.wav"), "die": preload("res://sfx/die.wav"), "creak": preload("res://sfx/creak.wav"),
	"coin": preload("res://sfx/coin.wav"), "flask": preload("res://sfx/flask.wav"), "relic": preload("res://sfx/relic.wav"),  # saque a cair (#288)
}
## Música: faixas em laço (o laço liga-se em código, nunca pelo .import) e o volume de cada uma, em dB.
const MUSIC := {
	"title": preload("res://art/music/title.ogg"), "world": preload("res://art/music/world.ogg"), "crypt": preload("res://art/music/crypt.ogg"),
	"cortejo": preload("res://art/music/cortejo.ogg"), "boss": preload("res://art/music/boss.ogg"),
}
const MUSIC_DB := {"title": -8.0, "world": -8.0, "crypt": -8.0, "cortejo": -6.0, "boss": -4.0}
const XP := {"skeleton": 5, "specter": 4, "colossus": 60, "herald": 150, "enforcado": 5, "afogado": 5, "queimado": 5, "estandarte": 5}  # as peles (0.4.7) só para o Bestiário e a gravação: o abate paga pelo kind
const WEAR := ["enforcado", "afogado", "queimado", "estandarte"]  # as peles do Cortejo
const NO_BOSS_DROP := ["Coveiro", "Gigante Errante", "Reforço", "Sentinela"]  # colossos sem o Frasco de Alma garantido dos chefes (o Reforço dos Sineiros, #206; a Sentinela dos Sepulcros, uma por profundidade)
## Equipamento (0.4.8): o que cada morte larga, [hipótese, comum, mágica] (o resto é rara). Os chefes com nome largam sempre
## uma rara e, GEAR_UNIQUE das vezes, um único que o grupo ainda não tenha.
const GEAR_DROP := {"normal": [0.025, 0.7, 0.25], "elite": [0.3, 0.25, 0.55], "boss": [0.5, 0.0, 0.6], "named": [1.0, 0.0, 0.0]}
const GEAR_UNIQUE := 0.3  # 10 únicos desde o Lote 6 (0,25 passou a 0,3); com 0,25 eram ~30 min até ao 1.º com 8 chefes com nome por hora
const GEAR_FLOOR := 10  # peças à espera no chão: as de mais vão logo para o herói mais perto (cada uma custa um pouco por frame, aqui e na rede)
## Jogo gravado (no Android fica nos dados da app e passa de versão para versão).
const SAVE_PATH := "user://save.json"
const SETTINGS_PATH := "user://settings.cfg"
## Configurações: ficam fora do jogo gravado (um Novo jogo não as apaga). Escolhas = índice da lista no menu.
const SETTINGS := {
	"master": 1.0, "music": 0.8, "sfx": 1.0,
	"fps": 1, "res": 0, "effects": 2, "show_fps": false,
	"shake": true, "flash": true, "numbers": true,
	"ui": 0, "opacity": 0,
	"text": 1,  # tamanho do texto (#99): 80%, 100%, 115% ou 130%
	"vibe": 2,  # vibração: 0 desligada, 1 fraca, 2 média, 3 forte
	"thermal": true,  # proteção térmica: baixa os efeitos e os FPS sozinha quando o telemóvel aquece
	"lang": 0,  # 0 = português de Portugal, 1 = inglês britânico (sem ficheiro: o idioma do telemóvel)
	"intro_seen": false,  # a intro aparece sozinha só da primeira vez (depois, no Sobre)
	"hold_hint": false,  # o aviso "segura um botão para saber o que faz" já apareceu
	"lefty": false,  # canhoto: botões de habilidade à esquerda e joystick à direita
	"joy_fixed": false,  # joystick fixo no canto (de origem aparece onde o polegar toca)
	"joy_at": Vector2.ZERO,  # ou fixo onde o jogador o pôs (#271): fração da margem segura (no canhoto, espelhada); ZERO = no canto
	"deadzone": 1,
	"colorblind": 0,  # 0 desligado, 1 protanopia, 2 deuteranopia, 3 tritanopia
	"comfort": 0,  # conforto ocular: 0 desligado, 1 suave, 2 forte
	"minimap": true,
	"auto_attack": false,  # um polegar: o 1.º golpe sai sozinho com um inimigo ao alcance
	"boss_aim": false,  # a mira automática prefere os chefes
	"potion_ui": 2,  # botões de poção a 100%, 125% ou 150% (de origem os maiores: acertar no meio da luta)
	"hud_fade": false,  # longe de combate, o HUD fica quase transparente
	"loot_common": 0,  # filtro do saque (#76) dos ossos e das esferas: 0 nome, luz e som · 1 luz e som · 2 só o ícone
	"loot_rare": 0,  # e o mesmo para os tinteiros e as cinzas (os frascos, os reagentes e as relíquias mostram sempre tudo)
	"density": 2,  # monstros no mundo aberto (#284): 0 baixa, 1 média, 2 alta (a de sempre)
	"fx_alpha": 0,  # opacidade dos efeitos (#86): 100%, 70% ou 40% (os números de dano e os avisos dos chefes ficam inteiros)
	"bag_sort": 0,  # Filtrar e ordenar (#273): a mochila no Equipamento por lugar, raridade ou melhores (só a ordem à vista)
}
const CHOICES := {"vibe": 4, "fps": 3, "res": 2, "effects": 3, "ui": 4, "opacity": 3, "text": 4, "fx_alpha": 3, "lang": 2, "deadzone": 3, "colorblind": 4, "comfort": 3, "potion_ui": 3, "loot_common": 3, "loot_rare": 3, "density": 3, "bag_sort": 3}  # quantas escolhas tem cada uma
const DEADZONES := [0.15, 0.25, 0.4]  # zona morta do stick e dos gatilhos (comandos com "drift" precisam da maior)
const I18n := preload("res://i18n.gd")
const FPS_CAPS := [30, 60, 0]  # 0 = o que o ecrã der
const OPACITY := [1.0, 0.75, 0.5]
const TEXT := [0.8, 1.0, 1.15, 1.3]  # tamanho do texto de cada escolha (#99)
const FX_ALPHA := [1.0, 0.7, 0.4]  # opacidade dos efeitos de cada escolha (#86)
const VIBE := [0.0, 0.5, 1.0, 1.6]  # força da vibração de cada escolha
const DUMMY_AT := Vector2(260, 140)  # boneco de treino (#287), ao lado do monumento
const BLOOD_R := 30.0  # Sangue no Solo (#23): raio de cada poça
const CORPSE_R := 90.0  # Espasmo Cadavérico (#115): raio da explosão de um cadáver
const CORPSE_T := 6.0  # quanto tempo fica no chão antes de rebentar sozinho
const CORPSE_COLORS := [Color(0.9, 0.86, 0.75), Color(0.45, 0.85, 0.25), Color(0.62, 0.36, 0.85), Color(0.8, 0.8, 0.75)]  # osso, podridão, necrose, calcificação
const EFFECTS := [0.35, 0.65, 1.0]  # parte das partículas que se desenha
const DENSITY := [14, 24, 35]  # máximo de monstros no mundo aberto de cada escolha (#284); o Cortejo e a cripta não mudam
const PROP_CAP := 720  # adereços de um mapa
const MAP_SLICE_US := 3000  # em jogo, o plano do mapa trabalha 3 ms por frame
const FLOOR_STEP := 256.0  # o chão redesenha-se quando a câmara se afasta tanto disto (a cada ~1,1 s a andar)
const WILD_STEP := 800.0  # de quantos em quantos px da praça os monstros sobem de nível
const WILD_FAR := 2400.0  # mais longe do que isto de todos os heróis, os soltos desaparecem (os do arranque nascem a 2012 no máximo)
const CAMPS_PER := 2  # acampamentos por zona: 8 no mapa
const CAMP_PACK := 6  # mortos de cada bando, além do elite com nome
const CAMP_WAKE := 1200.0  # o bando nasce a esta distância de um herói (fora do ecrã: 800 de meia largura a 20:9 + 170 do bando + o que se anda entre duas vistas, com esquiva)
## Comando com esquema Xbox (A em baixo, B à direita, X à esquerda, Y em cima), como o GameSir G8 Plus.
## Sem teclado: o jogo é para telemóvel (comando ou ecrã tátil).
const PAD_BUTTONS := {
	"move_left": [JOY_BUTTON_DPAD_LEFT], "move_right": [JOY_BUTTON_DPAD_RIGHT],
	"move_up": [JOY_BUTTON_DPAD_UP], "move_down": [JOY_BUTTON_DPAD_DOWN],
	"skill_1": [JOY_BUTTON_A], "skill_2": [JOY_BUTTON_X], "skill_3": [JOY_BUTTON_Y],
	"interact": [JOY_BUTTON_B], "menu": [JOY_BUTTON_START], "tree": [JOY_BUTTON_BACK], "stance": [JOY_BUTTON_RIGHT_STICK],
	"arsenal": [JOY_BUTTON_LEFT_STICK],
	"potion_hp": [JOY_BUTTON_LEFT_SHOULDER], "potion_mp": [JOY_BUTTON_RIGHT_SHOULDER],
}
const PAD_AXES := {
	"move_left": [JOY_AXIS_LEFT_X, -1.0], "move_right": [JOY_AXIS_LEFT_X, 1.0],
	"move_up": [JOY_AXIS_LEFT_Y, -1.0], "move_down": [JOY_AXIS_LEFT_Y, 1.0],
	"skill_1": [JOY_AXIS_TRIGGER_RIGHT, 1.0], "skill_2": [JOY_AXIS_TRIGGER_LEFT, 1.0],  # gatilhos RT/LT (Kishi, Backbone, DualSense)
}

## Chão: tiles isométricos 32-bit da folha SC-W1. LV = altura do vértice esquerdo do losango na textura;
## HH = meia altura da face de cima. Medido nas texturas cortadas (256 px de largura).
const TILES := {
	"cobble": preload("res://art/tiles/cobble.png"), "cobble_moss": preload("res://art/tiles/cobble_moss.png"),
	"grass": preload("res://art/tiles/grass.png"), "mud": preload("res://art/tiles/mud.png"),
	"slab": preload("res://art/tiles/slab.png"), "slab_roots": preload("res://art/tiles/slab_roots.png"),
	"bones": preload("res://art/tiles/bones.png"), "water": preload("res://art/tiles/water.png"),
	"sep_wet": preload("res://art/tiles/sep_wet.png"), "sep_flood": preload("res://art/tiles/sep_flood.png"),
	"sep_earth": preload("res://art/tiles/sep_earth.png"), "sep_thorn": preload("res://art/tiles/sep_thorn.png"),
	"sep_ember": preload("res://art/tiles/sep_ember.png"), "sep_ash": preload("res://art/tiles/sep_ash.png"),
	"sep_marble": preload("res://art/tiles/sep_marble.png"), "sep_bones": preload("res://art/tiles/sep_bones.png"),
}
const TILE_LV := {"cobble": 90.0, "cobble_moss": 90.0, "grass": 96.0, "mud": 90.0, "slab": 91.0, "slab_roots": 92.0, "bones": 90.0, "water": 93.0,
	"sep_wet": 90.0, "sep_flood": 90.0, "sep_earth": 92.0, "sep_thorn": 99.0, "sep_ember": 93.0, "sep_ash": 92.0, "sep_marble": 90.0, "sep_bones": 93.0}
const TILE_HH := 90.5
const TILE_SCALE := 0.55
## Praça central 32-bit (PX-33, redesenhada do MAP-01); o poço do meio fica debaixo do monumento.
const HUB := preload("res://art/bg/hub.webp")
const HUB_SPOT := Vector2(1376, 754)
const MON := preload("res://art/props/monument.png")
const MON_ON := preload("res://art/props/monument_on.png")
## Cripta dos Condenados: o mapa PX-34 (o MAP-02 em 32-bit, igual de sítio) fica numa zona à parte, por baixo do cemitério.
## Coordenadas medidas na imagem (2752x1536): o chão caminhável, a entrada, a porta do fundo e o Carcereiro.
const CRYPT := preload("res://art/bg/crypt.webp")
const CRYPT_ORIGIN := Vector2(-1376, 3400)
const CRYPT_FLOOR := [Vector2(1950, 520), Vector2(2230, 560), Vector2(2150, 830), Vector2(1750, 1000), Vector2(1450, 1180),
	Vector2(1150, 1250), Vector2(800, 1430), Vector2(300, 1450), Vector2(150, 1250), Vector2(500, 1120), Vector2(850, 940),
	Vector2(1350, 690), Vector2(1650, 570), Vector2(1800, 510)]
const CRYPT_IN := Vector2(450, 1300)
const CRYPT_OUT := Vector2(2040, 540)
const CRYPT_BOSS := Vector2(1880, 660)
const CRYPT_GLOWS := [Vector2(470, 960), Vector2(1270, 560), Vector2(1770, 400), Vector2(2290, 640)]
const CRYPT_DOOR := Vector2(-700, 900)  # escadas para a cripta, no cemitério
const SHRINE := Vector2(330, 120)  # o altar do cemitério, onde se oferece o Coração de Titã (#70)
const CRYPT_DOOR_TEX := preload("res://art/props/crypt_door.png")
## Salas da cripta (S6): o caminho do corredor, da entrada ao Carcereiro (pontos no chão, com folga de 80x60 px), e cada
## regra [nome, o que muda]. A 1.ª descida é a de sempre; as seguintes sorteiam outra, nunca a da última.
const CRYPT_PATH := [Vector2(650, 1300), Vector2(950, 1120), Vector2(1250, 960), Vector2(1500, 840), Vector2(1720, 720)]
const CRYPT_RULES := {
	"": ["Cripta dos Condenados", "Derrota o guardião e abre o relicário."],
	"cegas": ["Catacumbas Cegas", "Às escuras: só vês o que a tua tocha ilumina."],
	"silencio": ["Sanctum do Silêncio", "As habilidades com custo acordam os mortos à volta."],
	"miasma": ["Abismo do Miasma", "O ar envenena: mata elites para respirar."],
	"submersa": ["Cripta Submersa", "Bile no chão e marés de almas."],
	"chamas": ["Necrópole em Chamas Negras", "A alma arde: as habilidades com custo só funcionam nos abrigos de pedra."],
	"enxofre": ["Minas de Enxofre", "Os golpes em área rebentam as pedras de enxofre, em cadeia."],
	"forja": ["Forja das Almas Escravas", "Martelos gigantes esmagam o chão: sai do círculo vermelho."],
	"moinho": ["Moinho de Carne", "As passadeiras levam tudo para as serras."],
	"jardins": ["Jardins de Pedras Funerárias", "As gárgulas só se mexem quando lhes viras as costas."],
	"costelas": ["Ossário Vivo", "As costelas fecham os corredores: passa quando abrirem."],
	"carcacas": ["Labirinto das Carcaças", "As portas de costelas pedem um lacaio... ou sangue."],
	"canopos": ["Salões do Embalsamador", "Abre os vasos à foice. Golpes em área libertam as almas."],
	"esquecidos": ["Abismo dos Esquecidos", "Sem mapa nem seta: segue as tochas negras."],
	"tendoes": ["Covil do Tecelão", "Teias de tendões: corta-as à foice ou ao machado."],
	"piche": ["Piche Funerário", "Atrai-os para o piche e lança-lhe fogo."],
	"poco": ["Poço da Danação", "O chão racha: não pares nas fendas. Empurra-os para o poço."],
}
const SEP_ONLY := ["costelas", "carcacas", "esquecidos", "poco"]  # S10: regras que só existem nos Sepulcros (a cripta não as sorteia)
const VESSEL := [Vector2(-27, -12), Vector2(-35, -24), Vector2(-34, -38), Vector2(34, -38), Vector2(35, -24), Vector2(27, -12)]  # o Recipiente de Sangue (#32): uma pia de pedra num pé, com a borda, a boca e o sangue lá dentro
const VESSEL_FOOT := [Vector2(-16, 0), Vector2(-18, -5), Vector2(-11, -14), Vector2(11, -14), Vector2(18, -5), Vector2(16, 0)]
const VESSEL_SHADE := [Vector2(14, -13), Vector2(20, -24), Vector2(20, -36), Vector2(33, -36), Vector2(34, -24), Vector2(27, -13)]
const VESSEL_LIP := [Vector2(-36, -38), Vector2(-30, -44), Vector2(30, -44), Vector2(36, -38), Vector2(30, -33), Vector2(-30, -33)]
const VESSEL_MOUTH := [Vector2(-28, -38), Vector2(-23, -42), Vector2(23, -42), Vector2(28, -38), Vector2(23, -35), Vector2(-23, -35)]
const VESSEL_HALF := [Vector2(-23, -37), Vector2(-19, -39), Vector2(19, -39), Vector2(23, -37), Vector2(19, -35), Vector2(-19, -35)]  # meio cheio: a toalha de sangue mais pequena, mais funda
const SLAB_H := 64.0  # as lajes de pedra que fecham as portas de sangue e os selos (#219), de pé na boca do corredor
const JAR_PAIR := [Vector2(30, 12), Vector2(-34, -14)]  # os vasos canópicos aos pares: a 72 px um do outro, a foice abre um sem o outro
const JAR_BODY := [Vector2(-9, 0), Vector2(-15, -8), Vector2(-17, -20), Vector2(-11, -33), Vector2(11, -33), Vector2(17, -20), Vector2(15, -8), Vector2(9, 0)]  # o vaso canópico (#219): o bojo, a sombra, o brilho, a cinta e as 4 tampas (homem, falcão, babuíno e chacal)
const JAR_SHADE := [Vector2(4, -1), Vector2(8, -8), Vector2(9, -20), Vector2(5, -32), Vector2(11, -33), Vector2(17, -20), Vector2(15, -8), Vector2(9, 0)]
const JAR_SHINE := [Vector2(-7, -3), Vector2(-12, -9), Vector2(-14, -20), Vector2(-9, -30), Vector2(-7, -30), Vector2(-10, -20), Vector2(-9, -9), Vector2(-5, -3)]
const JAR_BAND := [Vector2(-17, -24), Vector2(-17, -20), Vector2(17, -20), Vector2(17, -24)]
const JAR_LIDS := [[[Vector2(-12, -33), Vector2(-10, -44), Vector2(0, -49), Vector2(10, -44), Vector2(12, -33)]], [[Vector2(-11, -33), Vector2(-8, -45), Vector2(3, -53), Vector2(9, -42), Vector2(11, -33)]],
	[[Vector2(-13, -33), Vector2(-13, -43), Vector2(-7, -48), Vector2(7, -48), Vector2(13, -43), Vector2(13, -33)]],
	[[Vector2(-12, -33), Vector2(-9, -43), Vector2(9, -43), Vector2(12, -33)], [Vector2(-10, -41), Vector2(-8, -56), Vector2(-3, -42)], [Vector2(3, -42), Vector2(8, -56), Vector2(10, -41)]]]
const GATE_TICK := 10.7  # Ossário Vivo (#28): cada porta de costelas fecha a cada 10,7 s, 1,2 s depois de avisar, durante 3,2 s
const GATE_SHUT := 7.5
const GATE_WARN := 6.3
const CRYPT_TINT := {"": Color(0.74, 0.8, 0.78), "cegas": Color(0.86, 0.78, 0.62), "silencio": Color(0.7, 0.76, 0.88),
	"miasma": Color(0.66, 0.84, 0.58), "submersa": Color(0.6, 0.76, 0.84), "chamas": Color(0.78, 0.66, 0.86),
	"enxofre": Color(0.86, 0.82, 0.6), "forja": Color(0.88, 0.7, 0.6), "moinho": Color(0.84, 0.66, 0.66), "jardins": Color(0.72, 0.78, 0.72), "canopos": Color(0.86, 0.8, 0.66),
	"tendoes": Color(0.84, 0.7, 0.7), "piche": Color(0.8, 0.74, 0.66)}  # a cor de cada sala (nas Cegas, a da tocha)
const CRYPT_BOSSES := ["", "suturado", "monge", "carrasco", "arquivista", "sibila", "matriarca"]  # S7: o chefe de cada descida, à vez ("" é o Carcereiro; bosses.gd)
## S11, poças no chão (Lote 7): o raio de cada uma e a parte da vida máxima que tiram aos heróis a cada 0,5 s (o fogo tira
## também aos monstros: 3%, e 0,5% aos chefes). O piche não fere: espera pelo fogo.
const POOL_N := 12
const POOL_R := {"acido": 70.0, "nevoa": 90.0, "piche": 70.0, "fogo": 70.0}
const POOL_HIT := {"acido": 0.04, "nevoa": 0.03, "fogo": 0.015}
const POOL_FIRE := 6.0  # o piche arde 6 s e pega ao que estiver a 140 px 0,4 s depois
const HOLE_N := 9  # S12: buracos (só o Poço da Danação, #49)
const HOLE_WARN := 0.6
const HOLE_T := 12.0
const WEB_N := 10  # Covil do Tecelão (#36): teias de 80 px, 3 cortes cada
const WEB_R := 80.0
const MAUS_BOSSES := ["arauto", "guardiao", "marechal", "arquilich", "tecela", "quimera"]  # S13: o chefe dos pisos 10, 20, 30… do Mausoléu, à vez
const TORCH_R := 260.0  # Catacumbas Cegas (#26): a luz da tocha de cada herói
const TIDE_EVERY := 8.0  # Lago das Lamentações (#30): uma maré de almas a cada 8 s, que dura 2 s
const TIDE_T := 2.0
const CRYPT_DIR := Vector2(0.879, -0.476)  # o rumo do corredor, da entrada para o Carcereiro
## Armadilhas da cripta (B6): 6 pontos a espaços iguais ao longo do CRYPT_PATH (os martelos da Forja e as gárgulas dos
## Jardins), todos com mais de 170 px de chão à volta; e a forma de cada pedra de enxofre (28 px)
const CRYPT_SPOTS := [Vector2(740, 1250), Vector2(910, 1140), Vector2(1090, 1050), Vector2(1270, 950), Vector2(1450, 860), Vector2(1630, 770)]
const ROCK := [Vector2(-14, 3), Vector2(-9, -8), Vector2(1, -13), Vector2(12, -7), Vector2(14, 4), Vector2(4, 11), Vector2(-8, 10)]
## Adereços: textura, altura no ecrã, peso no sorteio. Os da 0.4.7 têm peso 0: entram nos Sepulcros (SEPS) e nas zonas que os pedem em "new".
const PROPS := {
	"grave_broken": [preload("res://art/props/grave_broken.png"), 72.0, 14],
	"graves3": [preload("res://art/props/graves3.png"), 62.0, 8],
	"tomb": [preload("res://art/tomb.png"), 66.0, 10],
	"fence": [preload("res://art/props/fence.png"), 70.0, 5],
	"fence_gate": [preload("res://art/props/fence_gate.png"), 76.0, 3],
	"coffin": [preload("res://art/props/coffin.png"), 46.0, 4],
	"coffin_open": [preload("res://art/props/coffin_open.png"), 46.0, 3],
	"candles": [preload("res://art/props/candles.png"), 52.0, 4],
	"skulls": [preload("res://art/props/skulls.png"), 46.0, 4],
	"roots": [preload("res://art/props/roots.png"), 56.0, 5],
	"bush": [preload("res://art/props/bush.png"), 62.0, 6],
	"statue": [preload("res://art/props/statue.png"), 112.0, 3],
	"lantern": [preload("res://art/props/lantern.png"), 122.0, 3],
	"tree": [preload("res://art/tree.png"), 150.0, 8],
	"cage_tree": [preload("res://art/props/cage_tree.png"), 230.0, 2],
	"crypt": [preload("res://art/crypt.png"), 140.0, 2],
	"chapel": [preload("res://art/props/chapel.png"), 230.0, 1],
	"gatehouse": [preload("res://art/props/gatehouse.png"), 220.0, 0],
	"rubble": [preload("res://art/props/rubble.png"), 150.0, 1],
	"cliff": [preload("res://art/props/cliff.png"), 160.0, 1],
	"shrine_off": [preload("res://art/props/shrine.png"), 90.0, 0],
	"waypoint_on": [preload("res://art/props/waypoint_on.png"), 110.0, 0],
	"wall_jardim": [preload("res://art/props/wall_jardim.png"), 170.0, 0],
	"mod_ossos": [preload("res://art/props/mod_ossos.png"), 170.0, 0],
	"mod_ossos_nicho": [preload("res://art/props/mod_ossos_nicho.png"), 170.0, 0],
	"mod_cisterna": [preload("res://art/props/mod_cisterna.png"), 170.0, 0],
	"mod_cisterna_grade": [preload("res://art/props/mod_cisterna_grade.png"), 170.0, 0],
	"mod_forno": [preload("res://art/props/mod_forno.png"), 170.0, 0],
	"mod_forno_boca": [preload("res://art/props/mod_forno_boca.png"), 170.0, 0],
	"mod_reis": [preload("res://art/props/mod_reis.png"), 170.0, 0],
	"mod_reis_nicho": [preload("res://art/props/mod_reis_nicho.png"), 170.0, 0],
	"sep_stairs": [preload("res://art/props/sep_stairs.png"), 170.0, 0],
	"sep_bonepile": [preload("res://art/props/sep_bonepile.png"), 60.0, 0],
	"sep_pipe": [preload("res://art/props/sep_pipe.png"), 90.0, 0],
	"sep_thorns": [preload("res://art/props/sep_thorns.png"), 70.0, 0],
	"sep_sapling": [preload("res://art/props/sep_sapling.png"), 110.0, 0],
	"sep_brazier": [preload("res://art/props/sep_brazier.png"), 70.0, 0],
	"sep_coal": [preload("res://art/props/sep_coal.png"), 46.0, 0],
	"sep_sarcophagus": [preload("res://art/props/sep_sarcophagus.png"), 64.0, 0],
	"sep_banner": [preload("res://art/props/sep_banner.png"), 130.0, 0],
}

## O mapa (0.4.5): quatro zonas à volta da praça. Peso de cada adereço na zona = PROPS[n][2] * props.get(n, 1). "new" (0.4.7): adereços que trocam REGION_NEW dos soltos da zona.
const REGION_NEW := 0.14
const GATE := Vector2(0, 2050)  # o Portão dos Reis, ao fundo da estrada: fechado até aos Sepulcros (0.4.6). Mais a sul a câmara já não desce e o herói fica atrás dos orbes
const SEP_CELL := Vector2(281.6, 199.1)  # uma casa: 2 colunas x 4 filas de losangos (TILE_SCALE)
const SEP_SIDE := 19  # casas de lado: 3 lotes de 5, 2 intervalos e 1 de margem de cada lado
const SEP_ORIGIN := Vector2(-2675.2, 5800)  # centrado em x; a cripta acaba em y = 4936
const SEP_BOUNDS := Rect2(-3475.2, 5400, 6950.4, 4582.9)  # as casas + 800 aos lados e 400 em cima e em baixo: junto a uma parede a câmara ainda anda (o comentário de GATE)
const SEP_LINK := 255  # na grelha: 0 parede, 255 corredor, N a sala N - 1
const SEP_CAP := 30  # uma sala só nasce se os vivos e ela couberem aqui, e sinos e invocações param (a separação custa o quadrado, maus_cap)
const SEP_DOOR_R := 110.0
const SEP_WALL := 150.0  # a largura de uma peça de parede (mod_*, a 170 de altura)
const TORCH_GAP := 200.0  # Abismo dos Esquecidos (#211), C (g): uma Tocha Negra fica a uma casa (141 px) e meio portal dos portais e das escadas
const SEP_RUIN := 188.0  # a da ruína do Jardim (wall_jardim)
const SEP_FIXED := ["wall_jardim", "sep_pipe"]  # peças com direção: espelhada ao calhas, uma parede diagonal fazia um V; e todas do mesmo tamanho, para colarem
const REGION_SPOTS := [Vector2(0, -1900), Vector2(2350, -150), Vector2(-2350, -150)]  # norte, este, oeste; o Campo fica sempre a sul
const REGION_ORDER := [["bosque", "pantano", "ossario"], ["ossario", "bosque", "pantano"], ["pantano", "ossario", "bosque"], ["bosque", "ossario", "pantano"], ["ossario", "pantano", "bosque"], ["pantano", "bosque", "ossario"]]  # (c - 1) % 6: a zona do norte, a mais perto do monumento, muda em todos os passos
const REGIONS := {
	"praca": {"name": "", "spec": 0.25, "tile": Color(0.6, 0.66, 0.62), "prop": Color(0.8, 0.88, 0.84), "paint": Color.WHITE, "skin": "", "map": Color(0.32, 0.32, 0.28), "props": {}},
	"bosque": {"name": "Bosque dos Enforcados", "camp": "O Enforcado", "spec": 0.55, "tile": Color(0.46, 0.6, 0.46), "prop": Color(0.7, 0.88, 0.72), "paint": Color(0.65, 1.0, 0.65), "skin": "enforcado", "map": Color(0.2, 0.42, 0.22),
		"props": {"tree": 5, "cage_tree": 5, "bush": 3, "roots": 3, "statue": 0, "crypt": 0, "chapel": 0, "rubble": 0, "cliff": 0}, "new": ["sep_thorns", "sep_sapling"],
		"stamp": [["cage_tree", Vector2(-170, -30)], ["cage_tree", Vector2(170, -50)], ["cage_tree", Vector2(0, -190)], ["shrine_off", Vector2(0, -60)], ["candles", Vector2(-80, 70)], ["candles", Vector2(80, 70)]]},
	"pantano": {"name": "Pântano dos Afogados", "camp": "A Afogada", "spec": 0.4, "tile": Color(0.46, 0.6, 0.62), "prop": Color(0.68, 0.86, 0.86), "paint": Color(0.6, 0.95, 1.0), "skin": "afogado", "map": Color(0.16, 0.36, 0.42),
		"props": {"lantern": 3, "candles": 3, "roots": 3, "coffin": 2, "coffin_open": 2, "fence": 0, "fence_gate": 0, "statue": 0, "crypt": 0, "rubble": 0, "cliff": 0}, "new": ["sep_pipe"],
		"stamp": [["chapel", Vector2(0, -200)], ["lantern", Vector2(-180, -30)], ["lantern", Vector2(180, -30)], ["shrine_off", Vector2(0, -60)], ["coffin_open", Vector2(-110, 90)]]},
	"ossario": {"name": "Grande Ossário", "camp": "O Rei dos Ossos", "spec": 0.1, "tile": Color(0.72, 0.68, 0.6), "prop": Color(0.95, 0.9, 0.8), "paint": Color(1.0, 0.9, 0.7), "skin": "", "map": Color(0.62, 0.56, 0.44),
		"props": {"skulls": 6, "rubble": 8, "cliff": 6, "coffin_open": 3, "crypt": 2, "tree": 0, "cage_tree": 0, "bush": 0, "roots": 0, "lantern": 0}, "new": ["sep_bonepile"],
		"stamp": [["cliff", Vector2(0, -210)], ["rubble", Vector2(-200, -60)], ["rubble", Vector2(200, -60)], ["shrine_off", Vector2(0, -60)], ["skulls", Vector2(-90, 90)], ["skulls", Vector2(90, 90)]]},
	"campo": {"name": "Campo do Portão dos Reis", "camp": "O Porta-Estandarte", "spec": 0.25, "tile": Color(0.8, 0.68, 0.44), "prop": Color(0.95, 0.84, 0.62), "paint": Color(1.0, 0.82, 0.55), "skin": "estandarte", "map": Color(0.42, 0.38, 0.24),
		"props": {"graves3": 2, "tomb": 2, "fence": 4, "fence_gate": 4, "statue": 4, "tree": 0, "bush": 0, "cage_tree": 0, "rubble": 0, "cliff": 0}, "new": ["sep_banner", "sep_sarcophagus"],
		"stamp": [["statue", Vector2(-170, -70)], ["statue", Vector2(170, -70)], ["fence_gate", Vector2(0, -180)], ["shrine_off", Vector2(0, -60)], ["fence", Vector2(-100, -175)], ["fence", Vector2(100, -175)]]},
}

## Os Sepulcros (0.4.6). O aspeto e a forma mudam a cada profundidade (sep_kind); as regras e o guardião, a cada 5, e depois outra vez, mais fortes (sep_block). O guardião de cada bloco alterna a cada ida ao Portão (S13: guard[sep_runs % tamanho], _sep_boss). Cada um com a sua arte (0.4.7): as tintas só escurecem, quase neutras (chão e global >= 0,85, as tintas das regiões, 0,46, tocavam no vazio; menos no Forno e no Jardim, para os veios acesos e as raízes brancas não lutarem com os avisos).
const SEPS := [
	{"name": "Ossário Fundo", "tile": Color(0.9, 0.88, 0.85), "prop": Color(0.92, 0.9, 0.87), "paint": Color(1.0, 0.9, 0.7), "skin": "", "tint": Color(0.92, 0.91, 0.89), "spec": 0.1, "floor": ["slab", "sep_bones"], "tints": [Color(0.7, 0.68, 0.66), Color(0.58, 0.56, 0.53)], "look": "ossos", "pairs": [["sep_bonepile", 1400, 40]],
		"north": ["mod_ossos"], "feature": "mod_ossos_nicho", "side": ["sep_bonepile", "grave_broken"], "south": ["sep_bonepile", "graves3", "coffin"], "wide": 2, "loop": false, "rules": ["jardins", "silencio", "costelas"], "guard": ["suturado", "bispo"], "guard_rule": ""},
	{"name": "Cisterna Alagada", "tile": Color(0.9, 0.92, 0.94), "prop": Color(0.9, 0.92, 0.94), "paint": Color(0.6, 0.95, 1.0), "skin": "afogado", "tint": Color(0.9, 0.92, 0.95), "spec": 0.4, "floor": ["sep_wet", "sep_flood"], "tints": [Color(0.94, 0.97, 1.0), Color(1.0, 1.0, 1.0)], "look": "cisterna", "pairs": [["sep_pipe", 0, 34]],
		"north": ["mod_cisterna"], "feature": "mod_cisterna_grade", "side": ["roots", "coffin"], "south": ["roots", "coffin"], "wide": 1, "loop": false, "rules": ["submersa", "cegas", "esquecidos", "tendoes"], "guard": ["monge", "tecela"], "guard_rule": "silencio"},
	{"name": "Jardim Morto", "tile": Color(0.8, 0.82, 0.78), "prop": Color(0.9, 0.92, 0.88), "paint": Color(0.65, 1.0, 0.65), "skin": "enforcado", "tint": Color(0.9, 0.93, 0.89), "spec": 0.55, "floor": ["mud", "sep_earth", "sep_thorn"], "tints": [Color(0.8, 0.82, 0.78), Color(0.8, 0.82, 0.78), Color(0.8, 0.82, 0.78)], "look": "jardim", "pairs": [],
		"north": ["wall_jardim", "wall_jardim", "tree"], "feature": "", "side": ["sep_thorns", "sep_sapling", "roots"], "south": ["sep_thorns", "sep_sapling", "bush"], "wide": 2, "loop": false, "rules": ["miasma", "jardins", "carcacas", "tendoes"], "guard": ["carrasco", "donzelas"], "guard_rule": "miasma"},
	{"name": "Forno Velho", "tile": Color(0.68, 0.64, 0.62), "prop": Color(0.92, 0.88, 0.85), "paint": Color(1.0, 0.7, 0.55), "skin": "queimado", "tint": Color(0.94, 0.9, 0.87), "spec": 0.15, "floor": ["slab", "sep_ash", "sep_ember"], "tints": [Color(0.8, 0.71, 0.65), Color(1.0, 0.95, 0.9), Color(0.92, 0.84, 0.78)], "look": "forno", "pairs": [["sep_brazier", 1400, 42], ["sep_coal", 2200, 36]],
		"north": ["mod_forno"], "feature": "mod_forno_boca", "side": ["sep_brazier", "sep_coal", "grave_broken"], "south": ["sep_coal", "sep_brazier", "coffin"], "wide": 1, "loop": true, "rules": ["forja", "enxofre", "canopos", "piche"], "guard": ["guardiao", "marechal"], "guard_rule": "forja"},
	{"name": "Túmulo dos Reis", "tile": Color(0.92, 0.91, 0.88), "prop": Color(0.94, 0.93, 0.9), "paint": Color(1.0, 0.82, 0.55), "skin": "estandarte", "tint": Color(0.94, 0.93, 0.9), "spec": 0.25, "floor": ["slab", "sep_marble"], "tints": [Color(0.74, 0.74, 0.82), Color(1.0, 1.0, 1.0)], "look": "tumulo", "pairs": [["sep_banner", 1140, 54], ["sep_sarcophagus", 2200, 86]],
		"north": ["mod_reis"], "feature": "mod_reis_nicho", "side": ["sep_sarcophagus", "sep_banner", "statue"], "south": ["sep_sarcophagus", "sep_banner", "graves3"], "wide": 2, "loop": false, "rules": ["cegas", "silencio", "miasma", "submersa", "enxofre", "forja", "jardins", "carcacas", "esquecidos", "canopos", "poco"], "guard": ["arauto", "arquilich", "quimera"], "guard_rule": ""},
]

## Árvore dos Condenados: raízes que crescem da "raiz". pos = lugar no ecrã da árvore (640x380).
const PASSIVES := {
	"raiz": {"name": "Raiz", "desc": "Onde todos os condenados começam.", "req": "", "pos": Vector2(320, 340), "stats": {}},
	"densos": {"name": "Ossos Densos", "desc": "+30 vida máxima", "req": "raiz", "pos": Vector2(170, 280), "stats": {"hp_max": 30.0}},
	"tutano": {"name": "Tutano Faminto", "desc": "+3% do dano converte-se em vida", "req": "densos", "pos": Vector2(90, 180), "stats": {"leech": 0.03}},
	"medula": {"name": "Medula Sacrificial", "desc": "20% do dano recebido converte-se em barreira de ossos", "req": "densos", "pos": Vector2(70, 300), "stats": {"bone_barrier": 0.2}},
	"ossada": {"name": "Ossada Pesada", "desc": "+25% dano", "req": "tutano", "pos": Vector2(110, 60), "stats": {"dmg": 0.25}},
	"veias": {"name": "Veias Abertas", "desc": "+30% sangramento", "req": "raiz", "pos": Vector2(320, 240), "stats": {"bleed": 0.3}},
	"hemorragia": {"name": "Hemorragia", "desc": "+40% sangramento", "req": "veias", "pos": Vector2(320, 150), "stats": {"bleed": 0.4}},
	"bleedbone": {"name": "Sangue e Osso", "desc": "CHAVE: +80% sangramento e +15% dano, mas -30% dano de feitiços", "req": "hemorragia", "pos": Vector2(320, 50), "stats": {"bleed": 0.8, "dmg": 0.15, "spell": -0.3}},
	"hemofilia": {"name": "Hemofilia Espiritual", "desc": "Críticos em quem sangra deixam cair uma esfera que cura 5% da vida", "req": "hemorragia", "pos": Vector2(425, 120), "stats": {"hemo": 1.0}},
	"mente": {"name": "Mente Sepulcral", "desc": "+30 mana máxima", "req": "raiz", "pos": Vector2(470, 280), "stats": {"mana_max": 30.0}},
	"faminta": {"name": "Alma Faminta", "desc": "+25% dano de feitiços", "req": "mente", "pos": Vector2(550, 180), "stats": {"spell": 0.25}},
	"eco": {"name": "Eco Espectral", "desc": "+4 mana por segundo", "req": "faminta", "pos": Vector2(530, 60), "stats": {"regen": 4.0}},
	"coveiro": {"name": "Passo do Coveiro", "desc": "+12% velocidade", "req": "veias", "pos": Vector2(215, 170), "stats": {"speed": 0.12}},
	"dentes": {"name": "Dentes de Sepultura", "desc": "A esquiva deixa dentes no chão que abrandam os monstros em 40%", "req": "coveiro", "pos": Vector2(232, 96), "stats": {"teeth": 1.0}},
	"sentinelas": {"name": "Sentinelas Tumulares", "desc": "A esquiva finca uma lápide onde estavas (até 2) que dispara estilhaços de osso ao monstro mais perto durante 10 s", "req": "dentes", "pos": Vector2(215, 30), "stats": {"sentinel": 1.0}},
	"grito": {"name": "Grito de Guerra Fúnebre", "desc": "Ira: os mortos menores por perto entram em pânico e atacam-se uns aos outros durante 4 s (recarga 12 s)", "req": "medula", "pos": Vector2(165, 360), "stats": {"grito": 1.0}},
	"espasmo": {"name": "Espasmo Cadavérico", "desc": "Os mortos rebentam em 6 s ou ao teu golpe, com a Podridão, Necrose ou Calcificação", "req": "mente", "pos": Vector2(560, 330), "stats": {"corpse": 1.0}},
	"pacto": {"name": "Pacto de Carne e Ferro", "desc": "CHAVE: sem Esquiva Espectral, mas -30% dano recebido e cada golpe que levas faz rebentar espinhos de osso à tua volta", "req": "medula", "pos": Vector2(-90, 360), "stats": {"pacto": 1.0}},
	"vermes": {"name": "Comunhão dos Vermes-Deuses", "desc": "CHAVE: -50% vida máxima, mas os lacaios devoram os mortos recentes e atacam 3× mais depressa", "req": "espasmo", "pos": Vector2(720, 360), "stats": {"vermes": 1.0, "hp_mul": -0.5}},
	"canibal": {"name": "Canibalismo Espiritual", "desc": "CHAVE: cada lacaio que se desfaz cura 10% da vida e dá +8% dano (até 5), mas os lacaios duram só 4 s", "req": "tutano", "pos": Vector2(-90, 140), "stats": {"canibal": 1.0}},
	"semalma": {"name": "Sem Alma Própria", "desc": "CHAVE: a mana não se regenera: só vem das esferas de alma dos abates (30% cada); +40% dano de feitiços", "req": "faminta", "pos": Vector2(720, 200), "stats": {"semalma": 1.0, "spell": 0.4}},
	"frio": {"name": "Frio do Purgatório", "desc": "CHAVE: os golpes calcificam em vez de fazerem sangrar e as estátuas que morrem rebentam em lascas de osso, mas -20% dano", "req": "sentinelas", "pos": Vector2(215, -110), "stats": {"frio": 1.0, "calcify": 1.0, "dmg": -0.2}},
	"densidade_ossea": {"name": "Densidade Osteológica", "desc": "-3% dano recebido por cada lacaio teu de pé (até 4)", "req": "densos", "pos": Vector2(300, 430), "stats": {"ossea": 1.0}},
	"martir_aco": {"name": "Mártir do Aço Fúnebre", "desc": "15% do dano de sangramento que causas converte-se em barreira de ossos", "req": "veias", "pos": Vector2(410, 210), "stats": {"aco": 1.0}},
	"ectoplasma": {"name": "Hemorragia Ectoplasmática", "desc": "Críticos em quem sangra libertam ectoplasma: os lacaios a 4 m duram +3 s", "req": "hemofilia", "pos": Vector2(440, -50), "stats": {"ecto": 1.0}},
	"ecos": {"name": "Ecos do Último Suspiro", "desc": "A barreira de ossos a quebrar (com 10% da vida ou mais) petrifica os mortos menores a 5 m durante 1,5 s; os chefes só abrandam", "req": "grito", "pos": Vector2(40, 420), "stats": {"ecos": 1.0}},
	"simbioticas": {"name": "Almas Simbióticas", "desc": "Um lacaio teu desfaz-se para absorver o golpe que te ia matar (recarga 12 s)", "req": "espasmo", "pos": Vector2(580, 435), "stats": {"simb": 1.0}},
	"presenca": {"name": "Presença Cadavérica Intimidatória", "desc": "Os mortos menores a 3 m falham 30% dos ataques", "req": "grito", "pos": Vector2(165, 445), "stats": {"presenca": 1.0}},
	"sede": {"name": "Sede Ancestral", "desc": "Foice e machado roubam 1,5% da vida máxima do alvo por segundo durante 4 s (a cura por alvo até 3% da tua)", "req": "tutano", "pos": Vector2(-10, 50), "stats": {"sede": 1.0}},
	"sutura": {"name": "Sutura Biológica Instantânea", "desc": "A cura que passa da vida máxima converte-se em barreira de ossos (até 25% da vida)", "req": "medula", "pos": Vector2(-60, 250), "stats": {"sutura": 1.0}},
	"fragmentada": {"name": "Mente Fragmentada", "desc": "CHAVE: sem mana: as habilidades com custo bebem da poção de alma (60 = 1 carga, não se bebe) e fazem +40% dano; exclui Sem Alma Própria", "req": "faminta", "pos": Vector2(635, 95), "stats": {"fragmentada": 1.0}},
	"imolacao": {"name": "Imolação Funerária", "desc": "CHAVE: 40% do dano que levas arde como corrupção em vez de vida, mas na Sobrecarga de Alma perdes 6% da vida por segundo", "req": "eco", "pos": Vector2(660, -50), "stats": {"imolacao": 1.0}},
	"sangue": {"name": "Sangue Negro Impenetrável", "desc": "CHAVE: a vida que pagas (Ira, Frascos, Sobrecarga) volta a 3% por segundo, mas a poção de vida não faz nada; exclui o Lich de Ferro", "req": "sede", "pos": Vector2(-100, -60), "stats": {"sangue": 1.0}},
	"fome": {"name": "Fome Insaciável da Terra", "desc": "CHAVE: a terra engole os mortos e ergue um esqueleto teu a cada 2, mas sem lacaios de pé come-te 2% da vida por segundo (até metade)", "req": "espasmo", "pos": Vector2(720, 500), "stats": {"fome": 1.0}},
	"lich": {"name": "Apoteose do Lich de Ferro", "desc": "CHAVE: com as poções cheias és o Lich de Ferro: +30% dano, -20% dano recebido; toda a cura converte-se em barreira; exclui Sangue Negro", "req": "sutura", "pos": Vector2(-215, 215), "stats": {"lich": 1.0}},
	"circulacao": {"name": "Circulação Negra", "desc": "Até -35% de recarga quanto menos vida tiveres", "req": "ossada", "pos": Vector2(80, -70), "stats": {"circulacao": 1.0}},
	"arqueiros": {"name": "Arqueiros de Ossada", "desc": "Os teus esqueletos disparam de longe lascas de osso que atravessam 2 monstros; exclui os Guardiões de Tórax", "req": "densidade_ossea", "pos": Vector2(210, 535), "stats": {"arqueiros": 1.0}},
	"guardioes": {"name": "Guardiões de Tórax", "desc": "Os teus esqueletos levam escudos: os mortos menores a 300 px atacam-nos em vez de ti (cada golpe tira-lhes tempo); exclui os Arqueiros de Ossada", "req": "densidade_ossea", "pos": Vector2(390, 535), "stats": {"guardioes": 1.0}},
	"exumacao": {"name": "Exumação Espontânea", "desc": "Quem matas à foice, ao machado ou na Ceifa de Ossos tem 25% de hipótese de se erguer como esqueleto teu durante 10 s (os chefes não)", "req": "simbioticas", "pos": Vector2(545, 540), "stats": {"exumacao": 1.0}},
	# "hero": só esse herói o compra (S3); o outro vê-o fechado, com "(só o Strider)"
	"carrasco": {"name": "Carrasco de Sangue Negro", "desc": "Os monstros (elites também) ficam executáveis abaixo de 20% da vida e o teu machado executa-os sozinho; os chefes com nome não", "req": "circulacao", "pos": Vector2(-40, -140), "hero": "warden", "stats": {"carrasco": 1.0}},
	"falange": {"name": "Falange Espectral", "desc": "A esquiva perfeita ergue escudos espectrais: os monstros a 160 px voam para trás e ficam 0,8 s sem atacar (elites e colossos também; o Arauto não)", "req": "dentes", "pos": Vector2(330, -75), "stats": {"falange": 1.0}},
	"ressurreicao": {"name": "Ressurreição de Elites", "desc": "O elite que matas ergue-se como teu durante 20 s, com o triplo do dano de um esqueleto teu (um de cada vez; os chefes não)", "req": "exumacao", "pos": Vector2(545, 640), "stats": {"ressurreicao": 1.0}},
	"estacas": {"name": "Lança-Ossos Balística", "desc": "A Lança de Almas vira uma estaca que fura 3 monstros, arrasta-os e prende-os 1,5 s onde parar, até numa parede; os chefes só abrandam", "req": "faminta", "pos": Vector2(850, 120), "hero": "strider", "stats": {"estacas": 1.0}},
}

var player  # jogador 1 (o HUD e os controlos de toque são dele)
var players := []
var cam := Camera2D.new()
var level := 1
var xp := 0
var xp_frac := 0.0  # Visor (#252): o que sobra dos +30% de cada ganho, para o seguinte (5 XP davam 7, +40%); só no anfitrião
var shake := 0.0
var zoom_kick := 0.0
var cam_zoom := 1.0
var focus_t := 0.0
var focus_pos := Vector2.ZERO
var rumble := 0.0  # o sino dobra antes de o Arauto aparecer
var arena_r := 0.0  # > 0: os jogadores ficam presos no círculo do monumento até o Arauto cair
var pad_of := [-1, -1]  # comando (device) de cada jogador; -1 = ainda nenhum
var raise_by = null  # herói cuja Alma Tumular está a bater agora (quem morrer ergue-se para ele)
var away_keep := [0.0, false]  # #91: a vida e o caído do herói do convidado quando perdeu a ligação (volta assim)
var raise_n := 1  # e quantos se erguem de cada um (Alma Mitótica #149: dois pequenos)
var cast_support := ""  # frasco do golpe que está a bater agora (posto e limpo à volta do golpe, como o raise_by)
var quiet := false  # golpes sem paragem de impacto, tremor nem som (os espinhos do Pacto de Carne e Ferro; nos heróis, a Chuva de Dentes, #192)
var cast_aff := 0  # Alma Caótica (#147): estado que o golpe deixa (1 podridão, 2 necrose, 3 calcificação, cores de CORPSE_COLORS)
var arcing := false  # Alma Biomecânica (#144): os arcos a bater agora (um arco não solta mais arcos)
var chain_all := false  # e a volta da Ceifa de Ossos a bater agora (#153): os arcos ligam todos os que ela apanha
var cast_basic := false  # G7: o golpe básico a bater agora (a alma da arma só mexe nele); posto e limpo à volta, como o cast_support
var basic_first = null  # e o primeiro monstro em que ele bateu (o Sino da Agonia badala a partir dele)
var warned = {}  # Lote 8 C (b): cada tipo de aviso desenhado neste frame e onde (sempre o ground); para o teste
var web_shapes := {}  # Lote 8: os traços de cada teia ([sítio, fios] -> [[cor, pontos]], pontas), feitos uma vez e não a cada frame
var old_ground := false  # Lote 8 C (c): os buracos, as chamas do piche e as teias como eram no Lote 7 (só para a captura de antes e depois)
var flasks := ["", "parasita", "titanica"]  # Frascos de Alma que o grupo já tem
var tomb := {}  # {"pos": Vector2, "lost": {moeda: quantidade}} enquanto houver um túmulo por recuperar
var tomb_node
var saved := {}  # o que veio do ficheiro (o Guardião usa a parte dele quando entrar)
var saved_json := ""
var save_t := 2.0
var zone := "world"  # "world" = cemitério, "crypt" = cripta, "sep" = Sepulcros
var bounds := MAP
var crypt_floor := PackedVector2Array()
var guardian  # o Carcereiro da Cripta, enquanto vivo
var guardian_met := false
var crypt_n := 0  # descidas à cripta (S6; fica no jogo gravado): a 1.ª é sempre a sala de sempre
var crypt_rule := ""  # a regra da sala de agora (CRYPT_RULES; "" no cemitério); vai ao convidado
var crypt_last := ""  # a da última descida (a seguinte nunca a repete)
var sep := {}  # o plano do Sepulcro de agora (plan_sep), {} fora dele; cada telemóvel faz o seu
var sep_key := 0  # o número do Sepulcro: idas x 1000 + profundidade; vai ao convidado antes da zona
var sep_built := 0  # a chave para que este telemóvel construiu o mapa
var sep_grid := PackedByteArray()  # as casas (19 x 19): 0 parede, 255 corredor, N a sala N - 1
var sep_node := Node2D.new()  # os adereços do Sepulcro (y-sort com os heróis), fora do ciclo do net._send, como scenery
var sep_tall := []  # os adereços altos de lá (#92): tall fica só com os do mundo
var sep_doors := []  # os sprites das duas saídas do chefe: apagados até ele cair
var sep_aim := 1  # a sala para onde a seta aponta (cada telemóvel a sua)
var sep_done := 0  # 1 com o chefe caído: abre as duas saídas; vai ao convidado
var sep_streak := 0  # profundidades seguidas sem subir; vai ao convidado
var sep_bank := {}  # as moedas já lá dentro (com o saque do mundo e o relicário que vieram de fora): cair só perde metade do que veio depois (só no anfitrião)
var sep_elites := 0  # os elites que esta profundidade ainda vai ter (só no anfitrião)
var sep_big = 0  # Óleo de Lápide (#227): dos elites que faltam, quantos ainda saem colossais (só no anfitrião)
var sep_oil := false  # Óleo de Lápide (#227): a ida de agora vai untada (4 elites colossais por profundidade e os relicários x 1,5); sai ao subir e ao cair; vai ao convidado
var atlas := ""  # #185 Atlas dos Sepulcros: um carácter por bloco de 5 profundidades, em hexadecimal, com um bit por melhoria (ATLAS_UP, pela ordem); fica no jogo gravado e vai ao convidado
var sep_runs := 0  # idas ao Portão; fica no jogo gravado e vai ao convidado (a seta lê-o)
var sep_max := 0  # a profundidade mais funda vencida; fica no jogo gravado
var bags := 0  # Bolsas de Almas (#72): 0 a 3, uma pela 1.ª vitória sobre os guardiões das profundidades 5, 10 e 15 (cada uma +4 na mochila dos dois heróis); fica no jogo gravado e vai ao convidado
var sep_max0 := 0  # o recorde quando a ida começou: ao subir, o painel diz se é recorde novo (só no anfitrião)
var gate_node: Sprite2D  # o Portão dos Reis, apagado até à 1.ª vitória
var place_labels := []  # os nomes dos lugares fixos (_name_label): somem-se por baixo da vida dos heróis, no canto de cima
var breath_end := INF  # Abismo do Miasma (#38): quando acaba o ar (em time; INF = ar limpo)
var choke_t := 0.5  # e o próximo engasgo sem ar (só no anfitrião)
var tide_next := 0.0  # Lago das Lamentações (#30): quando começa a próxima maré de almas (em time)
var tide_dir := Vector2.RIGHT  # e para onde empurra, ao longo do corredor (um sentido por descida)
var rocks := []  # Minas de Enxofre (#43): [posição, quando rebenta (em time; 0 = intacta)]; vai ao convidado
var hammers := []  # Forja das Almas Escravas (#184): [posição, quando bate (em time)]; vai ao convidado
var saw_t := 0.5  # Moinho de Carne (#202): a próxima volta das serras (só no anfitrião)
var gates := []  # S10: o estado de cada porta do Sepulcro (sep.gates, pela mesma ordem): sangue 0 a 2 (2 aberta), carcaça 1 aberta, selo 1 fechada; vai ao convidado
var jars := []  # Salões do Embalsamador (#219): [posição, 0 inteiro ou 1 aberto], no máximo 8; vai ao convidado
var gate_was = []  # as portas de costelas fechadas no frame anterior: o esmagar é no fecho (só no anfitrião)
var pools := []  # S11: [posição, raio, até quando (em time; o piche, quando pega fogo: INF à espera), tipo], no máximo 12; vai ao convidado
var holes := []  # S12: [posição, raio, quando abre (em time; 0 = laje rachada), até quando], no máximo 9; vai ao convidado
var webs := []  # Covil do Tecelão (#36): [posição, cortes que faltam], no máximo 10; vai ao convidado
var pool_t = 0.5  # o próximo meio segundo das poças (só no anfitrião)
var pit_open = false  # Poço da Danação (#49): os 4 buracos da sala do chefe já abriram (só no anfitrião)
var cracks = {}  # e há quanto tempo há um herói em cima de cada laje rachada, pela posição dela (só no anfitrião)
var noise_at := Vector2.ZERO  # o último barulho (Sanctum do Silêncio, #46): onde e quando; o Monge (#193) vai lá (só no anfitrião)
var noise_t := -1.0
var dark := Node2D.new()  # Catacumbas Cegas (#26): o escuro (dark.gdshader), por cima das personagens
var tint := CanvasModulate.new()  # a cripta é mais escura
var sfx_last := {}
var fx_frame := -1  # efeitos em píxeis contados neste frame (fx_budget)
var fx_count := {}
var hud
var music := AudioStreamPlayer.new()  # o que se ouve; music_b só acaba de se apagar quando a faixa muda
var music_b := AudioStreamPlayer.new()
var music_tw: Tween
var track := ""  # a faixa de agora (vai ao convidado)
var settings := SETTINGS.duplicate()
var wiping := false  # Novo jogo: o jogo gravado foi apagado e nada o volta a escrever antes de recomeçar
var mirror := false  # a cena do convidado (_as_guest): o jogo é o do anfitrião e nunca se grava aqui, nem com a ligação perdida (#91: aí o Net já não é convidado)
var chest
var rng := RandomNumberGenerator.new()
var currency := {"bone": 0, "ink": 0, "ash": 0, "formao": 0, "carmesim": 0, "pena": 0, "tomo": 0, "coracao": 0}  # e os reagentes da Forja (S2) e o Coração de Titã (#70)
## G5 (Lote 10): os materiais da Forja de Peças (Loot.MATS), à parte das moedas: nunca vão para o túmulo. Cada um entra aqui
## da 1.ª vez que cai (a Bolsa mostra só os que já se encontraram, os gastos a cinzento); fica no jogo gravado e vai ao convidado
var mats := {}
var kills := {}  # mortes de cada monstro (o Bestiário revela-os com elas)
var weapon := {"tier": 0, "suffixes": [], "hidden": "", "sealed": true, "locked": "", "form": ""}  # locked: o sufixo que o Formão (#54) travou; form: a alma da arma posta (G7, lê-se com get: os testes antigos não a têm)
var forms := []  # G7: as almas da arma que o grupo já encontrou (fica no jogo gravado e vai ao convidado)
var relics := []  # Relíquias de Família (#58) que o grupo já tem
var gear_drops := true  # os mortos largam equipamento (0.4.8); os testes desligam-no para as contas e as sementes dos outros lotes não mudarem
var cortejo := {"active": false, "wave": 0, "affixes": [], "alive": 0}
var circle := 1  # Círculos (#27): o círculo do Cortejo (cada um mais forte e com mais saque)
var circle_max := 1  # o mais alto aberto: quebrar o Cortejo nele abre o seguinte
var wins := 0  # Cortejos quebrados, em qualquer círculo
var trial := ""  # a Provação deste Cortejo (TRIALS; "" nenhuma); vai ao convidado
var proven := []  # as Provações já vencidas (fica no jogo gravado): a 1.ª vitória na das Almas dá um Frasco
var event := {}  # S9: o evento do cemitério de agora ({} nenhum): id, onde (pos), horas (at, end, next), vivos, por nascer, banquete; vai ao convidado
var event_next := 0.0  # e quando calha o próximo (em time); vai ao convidado
var event_last := ""  # o último que saiu (o seguinte nunca o repete; só no anfitrião)
var mausoleum := 0  # Mausoléu Sem Fim (#27): o piso de agora (0 = fora dele); vai ao convidado
var floor_end := 0.0  # e quando acaba (em time; INF num piso de chefe, até ele cair); vai ao convidado
var curses := []  # as maldições escolhidas (de SEALS; repetem-se e somam-se) até ao fim da descida
var maus_t := 0.0  # o próximo par de mortos do Mausoléu (só no anfitrião)
var deep := 0  # o piso mais fundo a que já se chegou (fica no jogo gravado); vai ao convidado
var sanctum_rule := 0  # Santuário dos Deuses Cadavéricos (#50): a lei de agora (1 a 4, LAWS; 0 = fora dele); vai ao convidado
var kings := false  # Lote 9, #34: Os Reis Caídos a decorrer (a arena fechada); vai ao convidado
var kings_k = 0  # e as trocas de armas já feitas, e a vida dos três somada (só no anfitrião)
var kings_hp = 0.0
var amalgama := false  # #220: a Amálgama Primordial a decorrer; vai ao convidado
var gods := 0  # vitórias no Santuário (#50): a primeira abre a Amálgama; fica no jogo gravado
var beaten := {}  # Livro dos Chefes: quantas vezes se venceu cada chefe com nome (Bosses.book_id; 0 = já visto); fica no jogo gravado e vai ao convidado
var reaper  # O Ceifador Ambulante (#216): não está no grupo dos inimigos, por isso fica aqui (no convidado vem do net._spawn)
var eclipse_next := 0.0  # Eclipse Fúnebre (#182): quando cai o próximo e até quando dura o de agora (em time); vão ao convidado
var eclipse_end := 0.0
var tide_start := 0.0  # Marés de Sangue Negro (#212): quando sobe a próxima maré (em time; o aviso vem 3 s antes); vai ao convidado
var drip_t := 0.5  # a maré e a Chuva de Dentes (#192) tiram vida de meio em meio segundo (só no anfitrião)
var monument_pos := Vector2(0, -300)
var thermal := 0  # proteção térmica: 0 nada, 1 menos efeitos, 2 também 30 FPS (até fechar o jogo)
var thermal_t := 0.0
var monument: Sprite2D
var fog := Node2D.new()  # nevoeiro em píxeis (fog.gdshader), por baixo das personagens
var glows := []
var tile_rows := []  # o chão: uma Array por fila, cada ladrilho [textura, Rect2, cor]; desenha-se só à volta da câmara
var floor_node := Node2D.new()  # o chão (z -13); tiles (z -12) fica com a praça, a cripta e os brilhos
var floor_at := Vector2.INF  # o ponto à volta do qual o chão foi desenhado
var scenery := Node2D.new()  # os adereços do mapa (y-sort com os heróis); não entram no ciclo do net._send
var tall_fixed := []  # e o que não muda com o mapa: escadas, monumento, altar, estátuas da estrada, portão
var glows_fixed := []
var map_circle := 0  # o número (map_seed) para que o mapa foi feito; vai ao convidado antes da zona
var map_job := 0  # cada reconstrução é um número: a ultrapassada desiste
var map_busy := false
var map_builds := 0
var map_hash := 0
var map_ms := 0.0
var map_spots := {}  # região -> centro, neste mapa
var map_tex: ImageTexture  # o desenho do minimapa
var camps := []  # {"pos", "region"}: os acampamentos deste mapa (os dois telemóveis calculam-nos)
var camps_done := []  # índices já limpos; fica no jogo gravado; vai ao convidado; só uma vitória no Cortejo os repõe
var camp_left := {}  # índice -> [mortos por matar, elite de pé]; só no anfitrião
var camp_next := 0.0  # a próxima vista aos acampamentos (em time; só no anfitrião)
var region_now := ""  # só neste telemóvel
var region_t := 0.0
var teeth := []  # Dentes de Sepultura: [posição, tempo que falta] deixados pela esquiva
var blood := []  # Sangue no Solo (#23): [posição, quando seca (em time)] das poças dos monstros a sangrar
var sentinels := []  # Sentinelas Tumulares (#25): [posição, quando se desfaz, próximo tiro (em time), slot do herói], até 2 por herói
var corpses := []  # Espasmo Cadavérico (#9, #115): [posição, estado (0 osso, 1 podridão, 2 necrose, 3 calcificação), quando rebenta (em time), dano]
var graves := []  # Alma Gatilho: [posição, quando deixa de contar (em time)] dos últimos abates, até 3; só no anfitrião (não se desenha nem vai ao convidado)
var runes := []  # Escriba da Agonia (#155): [posição, quando se apaga (em time), slot do herói], até 6; só no anfitrião (ocultas: não se desenham nem vão ao convidado)
var spawn_t := 0.0
var giant_at := 0.0  # Cemitério dos Gigantes (#39): o Gigante Errante que caiu só volta a partir daqui (em time)
var time := 0.0
var tiles := Node2D.new()
var ground := Node2D.new()
var xray := Node2D.new()  # silhuetas de quem fica tapado por um adereço alto (#92), por cima de tudo
var tall := []  # Rect2 do meio de cada adereço alto (feitos em _prop)


func _ready() -> void:
	I18n.setup()
	Pix.sheets_warm()  # as folhas dos efeitos do pixelfx já carregadas: o primeiro golpe não engasga
	for p in CRYPT_FLOOR:
		crypt_floor.append(CRYPT_ORIGIN + p)
	add_child(tint)
	_setup_input()
	for b in ["Musica", "Efeitos"]:  # canais de som com volume próprio nas Configurações
		if AudioServer.get_bus_index(b) == -1:
			AudioServer.add_bus()
			AudioServer.set_bus_name(AudioServer.bus_count - 1, b)
			AudioServer.set_bus_send(AudioServer.bus_count - 1, "Master")
	Input.joy_connection_changed.connect(_on_joy)
	rng.randomize()
	_reroll_weapon()
	if not Net.is_guest():  # o convidado joga o jogo do anfitrião
		saved = _read_save()
		_apply_save()
	load_settings()
	# y-sort ordena o desenho do pai junto com os filhos; o chão vai em filhos atrás de tudo.
	# tiles = desenhado uma vez por mapa; ground = nevoeiro e brilhos, redesenhado a cada frame.
	tiles.z_index = -12
	tiles.draw.connect(_draw_tiles)
	add_child(tiles)
	ground.z_index = -10
	ground.draw.connect(_draw_world)
	add_child(ground)
	xray.z_index = 3  # por cima dos adereços e das personagens (z 0), debaixo dos efeitos (4 e mais)
	xray.material = ShaderMaterial.new()
	xray.material.shader = SILHOUETTE
	xray.draw.connect(_draw_xray)
	add_child(xray)
	dark.z_index = 3  # com as silhuetas e depois delas: por cima das personagens, debaixo dos efeitos (4 e mais)
	dark.material = ShaderMaterial.new()
	dark.material.shader = DARK
	dark.draw.connect(_draw_dark)
	add_child(dark)
	var fn := FastNoiseLite.new()
	fn.frequency = 0.03
	fn.fractal_octaves = 4
	var noise := NoiseTexture2D.new()  # o ruído do nevoeiro, feito uma vez (o Godot gera-o noutro fio)
	noise.seamless = true
	noise.noise = fn
	fog.z_index = -9
	fog.material = ShaderMaterial.new()
	fog.material.shader = FOG
	fog.material.set_shader_parameter("field", noise)
	fog.draw.connect(_draw_fog)
	add_child(fog)
	floor_node.z_index = -13
	floor_node.draw.connect(_draw_floor)
	add_child(floor_node)
	scenery.y_sort_enabled = true
	add_child(scenery)
	sep_node.y_sort_enabled = true
	add_child(sep_node)
	_gen_fixed()
	var first := map_seed()  # já vem do jogo gravado (_apply_save)
	if Engine.has_meta("map_circle"):  # no convidado: o do anfitrião
		first = Engine.get_meta("map_circle")
		Engine.remove_meta("map_circle")
	build_map(first, false)
	player = add_player()
	cam.limit_left = int(MAP.position.x)
	cam.limit_top = int(MAP.position.y)
	cam.limit_right = int(MAP.end.x)
	cam.limit_bottom = int(MAP.end.y)
	cam.position_smoothing_enabled = true
	cam.position = player.position
	add_child(cam)
	for s in MUSIC.values():
		s.loop = true
	for m in [music, music_b]:
		m.bus = "Musica"
		m.process_mode = Node.PROCESS_MODE_ALWAYS  # a música não pára com os menus (o jogo pára)
		add_child(m)
	hud = Hud.new()
	hud.main = self
	add_child(hud)
	apply_settings()
	if Net.is_guest():
		_as_guest()
	else:
		_spawn_tomb()
		_spawn_dummy()
		event_next = rng.randf_range(180.0, 240.0)  # S9: o 1.º evento, daqui a 3 a 4 minutos
		for i in 14:
			spawn_wild("skeleton", Vector2(rng.randf_range(-900, 900), rng.randf_range(-1500, -1000)))
	_floor_tick()
	if Engine.has_meta("play_now"):
		Engine.remove_meta("play_now")  # Novo jogo / Erguer-se / entrar numa sala: entra direto no jogo
	else:
		hud.open_opening(hud.open_title if settings.intro_seen else hud.open_intro)
	Net.attach(self)


## Co-op por Wi-Fi, no convidado: os dois heróis só desenham o que o anfitrião manda; este telemóvel fica com o outro herói.
func _as_guest() -> void:
	mirror = true
	player = add_player(-2)
	players.reverse()
	for p in players:
		p.set_process(false)
	hud.skills_for_player()


## O 2.º jogador da Wi-Fi saiu da sala: o anfitrião continua sozinho.
func drop_player() -> void:
	if players.size() < 2:
		return
	save_game()  # o equipamento e a Árvore do convidado ficam gravados antes de ele sair
	var p = players.pop_back()
	var was_down: bool = p.dead  # caído ou à espera da ligação (#91): quando o outro caiu, a morte já foi decidida
	if hud.panel != null and hud.panel.has_meta("gear") and hud.gear_who >= players.size():  # o Equipamento dele estava aberto: os toques usavam o herói que sai
		hud._back()
	if raise_by == p:
		raise_by = null
	p.queue_free()
	pad_of[1] = -1
	_rebind()
	hud.toast(tr("O %s saiu da sala.") % tr(p.hero_name))
	if not was_down and nearest_player(players[0].position) == null:  # quem ficou já tinha caído: sem ninguém para o reanimar, é a morte (no Mausoléu acaba a descida)
		_on_player_down(players[0])


## #91: o convidado da Wi-Fi perdeu a ligação sem dizer adeus: o herói dele fica à espera (Net.away_t), caído, escondido e
## colado ao anfitrião (_coop). Os monstros, as armadilhas e as pancadas já não olham para quem está caído, ninguém o reanima
## e, se o anfitrião cair, é a morte (não há quem o levante). false: não há 2.º herói para guardar.
func player_away() -> bool:
	if players.size() < 2:
		return false
	var p = players[1]
	if p.away:  # caiu outra vez a meio de voltar (o _hello já o tinha aceitado): ficam a vida e o caído da 1.ª vez
		return true
	away_keep = [p.hp, p.dead]
	p.away = true
	p.dead = true
	p.visible = false
	p.held.clear()
	p.touch_move = Vector2.ZERO
	p.set_process(false)
	hud.toast(tr("O %s perdeu a ligação: à espera dele (%s).") % [tr(p.hero_name), "%d s" % roundi(Net.away_t)])
	if not away_keep[1] and nearest_player(players[0].position) == null:  # o anfitrião já tinha caído: sem o outro ninguém o levanta, é a morte (com os dois caídos já foi decidida)
		_on_player_down(players[0])
	return true


## #91: voltou a tempo: o herói dele volta como estava, ao lado do anfitrião.
func player_back() -> void:
	var p = players[1]
	p.away = false
	p.hp = away_keep[0]
	p.dead = away_keep[1]
	p.visible = true
	p.set_process(true)
	p.position = players[0].position + Vector2(60, 0)
	hud.toast(tr("O %s voltou!") % tr(p.hero_name))


## Jogador 1 é o herói escolhido (_first_hero); o jogador 2 fica com o outro e entra a qualquer momento (Menu no 2.º comando).
## pad = o comando dele (-1: fica com o próximo comando que carregar num botão).
func add_player(pad := -1) -> Node2D:
	var p := Player.new()
	p.main = self
	p.setup(_first_hero() if players.is_empty() else other_hero(), players.size())
	p.position = Vector2(0, 300) if players.is_empty() else players[0].position + Vector2(60, 0)
	p.points = level - 1 + relics.size()
	_apply_hero(p)
	p.refresh_stats()
	p.hp = p.max_hp
	p.hp_chunk = p.max_hp
	p.died.connect(_on_player_down.bind(p))
	players.append(p)
	add_child(p)
	pad_of[players.size() - 1] = pad
	_rebind()
	if players.size() > 1:
		hud.toast((tr("O %s entrou no Cortejo!") if pad != -1 else tr("O %s entrou — carrega num botão do segundo comando.")) % tr(p.hero_name))
		if trial == "almas":  # a Provação das Almas (#37) é só a solo: com 2 heróis acaba ali e os frascos voltam
			trial = ""
			_unstash()
			hud.toast(tr("A Provação das Almas é só a solo: foi cancelada."))
	return p


## O herói do jogador 1: o escolhido no Novo jogo ou em Mudar de herói (no convidado, o do anfitrião), senão o gravado.
func _first_hero() -> String:
	var h = saved.get("hero", "strider")
	if Engine.has_meta("hero"):
		h = Engine.get_meta("hero")
		Engine.remove_meta("hero")
	return h if h in Player.HEROES else "strider"  # o jogo gravado e a rede não são de confiança


## O 2.º jogador (comando ou Wi-Fi) fica sempre com o outro herói: as duas partes do jogo gravado nunca se pisam.
func other_hero() -> String:
	return "strider" if players[0].hero == "warden" else "warden"


## Quem os monstros perseguem: um clone de osso perto (Esquiva Espectral), com taunt um Guardião de Tórax (#11) a 300 px
## (os chefes não caem nisso), ou o herói mais perto.
func lure(pos: Vector2, taunt := false):
	for d in get_tree().get_nodes_in_group("decoys"):
		if pos.distance_to(d.position) < 420.0:
			return d
	if taunt:
		for a in get_tree().get_nodes_in_group("allies"):
			if a.kind == "guarda" and a.life > 0.0 and pos.distance_to(a.position) < 300.0:
				return a
	return nearest_player(pos)


func spawn_decoy(p) -> void:
	var d := Decoy.new()
	d.main = self
	d.position = p.position
	d.hero = p.hero
	d.frame32 = p._frame32()
	d.flip = p.flip_s
	add_child(d)


func nearest_player(pos: Vector2):
	var best = null
	for p in players:
		if not p.dead and (best == null or pos.distance_squared_to(p.position) < pos.distance_squared_to(best.position)):
			best = p
	return best


func _on_player_down(p) -> void:
	if nearest_player(p.position) == null:
		var info := die(p.position)
		info.by = p.killed_by
		hud.open_death(info)
	else:
		hud.toast(tr("O %s caiu! Fica perto dele para o reanimar.") % tr(p.hero_name))


## Todos caíram: metade de cada recurso fica num túmulo no cemitério (onde se morreu ou, na cripta,
## ao pé das escadas). Um túmulo antigo por recuperar desfaz-se; nos Sepulcros, só o que se apanhou nesta ida, ao pé do
## Portão, e o túmulo antigo junta-se a este. Grava logo: fechar a app não salva nada.
func die(at: Vector2) -> Dictionary:
	_unstash()
	end_event()
	if mausoleum > 0:  # Mausoléu Sem Fim (#27): cair acaba a descida e guarda-se tudo, sem túmulo (o saque do chão também)
		var reached := mausoleum
		end_mode()
		_gather_loot()
		save_game()
		return {"lost": {}, "had_old": false, "deep": reached}
	end_mode()
	sep_oil = false  # #227: cair acaba a ida untada
	var lost := {}
	for k in currency:
		lost[k] = (maxi(currency[k] - sep_bank.get(k, 0), 0) if zone == "sep" else currency[k]) / 2  # nos Sepulcros, só o que se apanhou nesta ida
		currency[k] -= lost[k]
	var moved := zone == "sep" and not tomb.is_empty()
	var had_old := not tomb.is_empty() and not moved
	var keep := lost.duplicate()
	if moved:
		for k in keep:
			keep[k] += tomb.lost[k]  # tomb.lost tem sempre todas as moedas (_apply_save)
	tomb = {}
	if keep.values().any(func(v): return v > 0):
		var pos: Vector2 = at if zone == "world" else GATE + Vector2(0, -300) if zone == "sep" else CRYPT_DOOR + Vector2(0, 150)
		tomb = {"pos": pos.clamp(MAP.position + Vector2(80, 80), MAP.end - Vector2(80, 80)), "lost": keep}
	save_game()
	return {"lost": lost if lost.values().any(func(v): return v > 0) else {}, "had_old": had_old, "sep": zone == "sep", "moved": moved}


func _spawn_tomb() -> void:
	if tomb.is_empty():
		return
	tomb_node = Tomb.new()
	tomb_node.main = self
	tomb_node.position = tomb.pos
	add_child(tomb_node)


func recover_tomb() -> void:
	if tomb.is_empty():
		return
	var got := []
	for k in tomb.lost:
		currency[k] += tomb.lost[k]
		if tomb.lost[k] > 0:
			got.append("%s x%d" % [tr(Loot.INFO[k][0]), tomb.lost[k]])
	hud.toast(tr("Recuperaste do túmulo: %s") % ", ".join(got))
	spawn_fx("ring", tomb_node.position, 130.0, Color(0.4, 1.0, 0.65))
	sfx("chest")
	tomb_node.queue_free()
	tomb_node = null
	tomb = {}
	save_game()


func _process(delta: float) -> void:
	time += delta
	thermal_check(delta, Engine.get_frames_per_second())
	ground.queue_redraw()
	xray.queue_redraw()
	fog.queue_redraw()
	dark.visible = dark_on()  # o convidado também: a regra e as luzes vêm do anfitrião
	dark.queue_redraw()
	monument.texture = MON_ON if cortejo.active else MON
	gate_node.modulate = Color.WHITE if wins >= 1 else Color(0.45, 0.45, 0.5)
	var screen := get_viewport_rect()
	for l in place_labels:  # o "Portão dos Reis" por baixo do nome e do retrato do herói não se lia, nem um nem outro; Lote 9 C (f): nem cortado pela borda, nem por baixo da coluna de cima e do minimapa
		var lr := place_label_rect(l)
		l.visible = screen.encloses(lr) and not hud.over_hud(lr)
	_floor_tick()
	_region_tick(delta)
	_sep_tick()
	if Net.is_guest():  # quem simula é o anfitrião; aqui só a câmara
		_coop(delta)
		return
	if map_circle != map_seed() and hud.card_t <= 0.0 and cortejo.wave == 0 and not mode_on() and zone != "sep":  # o mapa segue o Círculo e as vitórias; as setas do menu do Cortejo não chegam aqui (o jogo está em pausa), o cartão da vitória fica à vista, e quem muda o Círculo e começa logo a onda ou um modo fica com este mapa até acabarem (a troca, a meio da luta, via-se sem o negro)
		build_map(map_seed())
	_music_pick()
	for i in range(teeth.size() - 1, -1, -1):
		teeth[i][1] -= delta
		if teeth[i][1] <= 0.0:
			teeth.remove_at(i)
	# guarda a hora a que seca, não um contador: assim a lista só muda (e só vai ao convidado) quando entra ou sai uma poça
	while not blood.is_empty() and blood[0][1] <= time:
		blood.pop_front()
	_sentinels()
	_runes()
	while not corpses.is_empty() and corpses[0][2] <= time:  # Espasmo Cadavérico: o mais antigo rebenta sozinho
		burst_corpse(corpses[0])
	if not teeth.is_empty():
		for e in enemies():
			for tooth in teeth:
				if e.position.distance_squared_to(tooth[0]) < 45.0 * 45.0:
					e.slow_t = maxf(e.slow_t, 0.4)  # sem encurtar um mais comprido (as Garras, main:1694)
					break
	save_t -= delta
	if save_t <= 0.0:
		save_t = 2.0
		save_game()
	if rumble > 0.0:
		rumble -= delta
		shake = maxf(shake, (2.6 - rumble) * 2.4)
	_coop(delta)
	_crypt_tick(delta)
	_gates_tick()
	_ground_tick(delta)
	_cortejo_tick(delta)
	_event_tick()
	_mausoleum_tick(delta)
	_kings_tick()
	# Carcereiro e os chefes dos Sepulcros: ao chegarem perto, ruge e aparece o cartão do chefe
	if zone != "world" and is_instance_valid(guardian) and not guardian_met:
		var q = nearest_player(guardian.position)
		if q != null and q.position.distance_to(guardian.position) < guardian.aggro:
			guardian_met = true
			if zone == "sep":
				guardian.heard = time  # o Monge só começa a ouvir agora
				focus_pos = guardian.position + Vector2(0, -40)  # a revelação (_coop)
				focus_t = 1.2
				spawn_fx("ring", guardian.position, 320.0, Color(0.4, 1.0, 0.6))
				if guardian.boss == "guardiao":  # as estátuas só ao acordar: senão eram 4 setas vermelhas desde o início
					raise_statues(guardian)
				elif guardian.title == "Sentinela":  # sozinha era um saco de pancada: a 55 px/s contra 230, e a foice chega mais longe do que o murro
					summon_minions(guardian, 3)
			hud.name_card(Bosses.BOOK[guardian.trio][0] if guardian.trio != "" else guardian.title, "Mensageiro do Cortejo Fúnebre" if guardian.title == "Arauto Fúnebre" else Bosses.INFO[guardian.boss][1])  # o Arauto tem boss == "", e essa frase é a do Carcereiro; um grupo (as Donzelas), com o nome da barra dele
			meet(guardian)
			guardian.bar_fill = 0.0
			sfx("roar")
			shake = 12.0
			vibrate(250, 1.0)
	spawn_t -= delta
	if zone == "world" and spawn_t <= 0.0 and not cortejo.active and not mode_on() and nearest_player(player.position) != null:
		spawn_t = 0.9
		_wild_tick()
		if enemies().size() < DENSITY[settings.density]:  # os bandos contam: a escolha da densidade continua a ser um limite
			var dir := Vector2.from_angle(player.facing.angle() + rng.randf_range(-1.2, 1.2) if rng.randf() < 0.6 else rng.randf() * TAU)  # 60% à frente de quem anda
			var p: Vector2 = player.position + dir * 700.0
			if not MAP.grow(-40.0).has_point(p):
				p = player.position - dir * 700.0
			p = p.clamp(MAP.position + Vector2(40, 40), MAP.end - Vector2(40, 40))
			var e = spawn_wild("specter" if rng.randf() < REGIONS[region_at(p)].spec else "skeleton", p)
			if rng.randf() < 0.05 and not enemies().any(func(o): return o.elite and o.camp < 0):  # Elites (#277): no cemitério, um de cada vez
				e.make_elite()
		_giants()
	if time >= camp_next:
		camp_next = time + 0.25  # a passo ninguém vê um bando nascer, e quem sobe da cripta ainda está no negro
		_camps_tick()
		_sep_wake()


## Câmara no meio do grupo (com tremor e zoom de impacto); ninguém sai do ecrã nem da arena do chefe.
## Reanimar: aliado vivo perto de quem caiu.
func _coop(delta: float) -> void:
	var mid := Vector2.ZERO
	for p in players:
		mid += p.position
	mid /= players.size()
	# na arena do chefe a câmara fica entre o grupo e o monumento e afasta-se um pouco;
	# enquanto o Arauto se ergue e ruge, a câmara olha para ele (a revelação)
	cam.position = (mid + monument_pos) / 2.0 if arena_r > 0.0 else mid
	var focusing := focus_t > 0.0  # lido antes de descontar: no último frame a câmara ainda está no chefe
	if focusing:
		focus_t -= delta
		cam.position = focus_pos
	cam_zoom = lerpf(cam_zoom, 0.85 if arena_r > 0.0 else 1.0, 1.0 - exp(-2.0 * delta))
	cam.offset = Vector2(randf_range(-1, 1), randf_range(-1, 1)) * shake * (1.0 if settings.shake else 0.0)
	cam.zoom = Vector2.ONE * (cam_zoom + zoom_kick)
	shake = move_toward(shake, 0.0, 45.0 * delta)
	zoom_kick = move_toward(zoom_kick, 0.0, 0.4 * delta)
	if arena_r > 0.0:
		for p in players:
			var v: Vector2 = p.position - monument_pos
			if v.length() > arena_r - 30.0:
				p.position = monument_pos + v.normalized() * (arena_r - 30.0)
	if players.size() < 2 or Net.is_guest():
		return
	var half := get_viewport_rect().size / 2.0 / cam.zoom - Vector2(60, 90)
	for p in players:
		if p.away:  # #91: à espera da ligação, colado ao anfitrião (a câmara fica nele) e sem reanimar
			p.position = players[0].position
			continue
		if zone != "sep" or not focusing:  # a revelação do chefe: a câmara foge do grupo 1,2 s e não pode arrastar ninguém pelas paredes
			p.position = p.position.clamp(cam.position - half, cam.position + half)
		if p.dead:
			var ally = nearest_player(p.position)
			if zone == "sep" and ally != null and not on_floor(p.position):  # arrastado para a parede: vai ter com o vivo (quem caiu não anda)
				p.position = ally.position
			var near: bool = ally != null and ally.position.distance_to(p.position) < 80.0
			p.revive_t = p.revive_t + delta if near else maxf(0.0, p.revive_t - delta)
			if p.revive_t >= REVIVE_T:
				p.revive()
				spawn_fx("ring", p.position, 90.0, Color(0.4, 1.0, 0.65))
				hud.toast(tr("O %s voltou à luta!") % tr(p.hero_name))
			p.queue_redraw()


## Subir de nível: cada jogador ganha um ponto na árvore e +8 de vida máxima, com explosão de luz.
func gain_xp(amount: int) -> void:
	if players.any(func(q): return q.stat("visor") > 0.0):  # Visor da Agonia Perpétua (#252): o grupo ganha +30%
		xp_frac += amount * 0.3
		var extra := floori(xp_frac)
		xp_frac -= extra
		amount += extra
	xp += amount
	while xp >= xp_needed():
		xp -= xp_needed()
		level += 1
		hitstop(0.1)
		shake = maxf(shake, 6.0)
		vibrate(50, 0.6)
		for p in players:
			p.points += 1
			p.refresh_stats()
			p.heal(8.0)
			spawn_fx("burst", p.position + Vector2(0, -40), 0.0, Color(1.0, 0.85, 0.4))
			spawn_fx("glow", p.position + Vector2(0, -40), 90.0, Color(1.0, 0.85, 0.4))
			spawn_fx("ring", p.position, 180.0, Color(1.0, 0.85, 0.4))
			if effects_level() == 0:  # efeitos baixos: a coluna simples
				spawn_fx("column", p.position, 0.0, Color(1.0, 0.85, 0.4))
			else:  # o pilar de luz de alma que cai do céu, com estrelas douradas
				spawn_fx("pillar", p.position, 0.0, Color(1.0, 0.85, 0.4), Vector2.RIGHT, "soul")
		sfx("levelup")
		hud.level_up()


func xp_needed() -> int:
	return 40 * level


func _setup_input() -> void:
	for pfx in ["", "p2_"]:
		for name in PAD_BUTTONS:
			if not InputMap.has_action(pfx + name):
				InputMap.add_action(pfx + name, 0.25)
	_rebind()
	# Menus: o Godot já navega com a cruz e o stick, mas não traz o A (escolher) nem o B (voltar)
	for pair in [["ui_accept", JOY_BUTTON_A], ["ui_cancel", JOY_BUTTON_B]]:
		var ev := InputEventJoypadButton.new()
		ev.button_index = pair[1]
		ev.device = -1
		if not InputMap.action_has_event(pair[0], ev):
			InputMap.action_add_event(pair[0], ev)


## Liga as ações de um jogador a um comando: device >= 0 = só esse, -1 = qualquer comando, -2 = nenhum.
func _bind(pfx: String, device: int) -> void:
	for name in PAD_BUTTONS:
		var action: String = pfx + name
		InputMap.action_erase_events(action)
		if device == -2:
			continue
		for b in PAD_BUTTONS[name]:
			var ev := InputEventJoypadButton.new()
			ev.button_index = b
			ev.device = device
			InputMap.action_add_event(action, ev)
		if PAD_AXES.has(name):
			var ev := InputEventJoypadMotion.new()
			ev.axis = PAD_AXES[name][0]
			ev.axis_value = PAD_AXES[name][1]
			ev.device = device
			InputMap.action_add_event(action, ev)


## Jogador 1: o seu comando, ou qualquer um enquanto não se sabe qual é. Jogador 2: só o seu comando.
func _rebind() -> void:
	_bind("", pad_of[0] if pad_of[0] != -1 else (-1 if pad_of[1] == -1 else -2))
	_bind("p2_", pad_of[1] if pad_of[1] != -1 else -2)


## Quem é quem (o HUD chama isto a cada toque num comando, mesmo em pausa): o 1.º comando que mexe é do
## jogador 1; um comando novo que carregue em Menu ou A faz entrar o 2.º jogador; se ele entrou pelo
## ecrã de título, o 1.º botão de um comando novo fica para ele.
func on_pad_input(event: InputEvent) -> void:
	var press: bool = event is InputEventJoypadButton and event.pressed
	if not press and not (event is InputEventJoypadMotion and absf(event.axis_value) > 0.6):
		return
	var d: int = event.device
	if d in pad_of:
		return
	if pad_of[0] == -1:
		pad_of[0] = d
		_rebind()
	elif players.size() == 1:
		if press and event.button_index in [JOY_BUTTON_START, JOY_BUTTON_A]:
			add_player(d)
	elif pad_of[1] == -1 and press:
		pad_of[1] = d
		_rebind()
		hud.toast(tr("Segundo comando ligado ao %s.") % tr(players[1].hero_name))


func _on_joy(device: int, connected: bool) -> void:
	if hud != null and hud.panel_title == "Jogar a dois":  # UX 27: o aviso do comando segue o que se liga e desliga com o painel aberto
		hud.open_duo()
	var i: int = pad_of.find(device)
	if connected or i == -1:
		return
	pad_of[i] = -1
	_rebind()
	if i < players.size():
		hud.pad_lost(players[i].hero_name, i == 0)


# ---------- Jogo gravado ----------

## Nível, moedas, arma e, por herói, a Árvore e os Frascos de Alma (as configurações vão à parte).
## O sítio onde se está e os inimigos não: abre-se sempre no cemitério.
func _save_data() -> Dictionary:
	var heroes: Dictionary = saved.get("heroes", {}).duplicate() if saved.get("heroes") is Dictionary else {}
	for p in players:
		var sup := {}
		for id in p.order:
			sup[id] = p.skills[id].support
		var kept: Array = [sup, p.soul] if p.stash == null else p.stash  # na Provação das Almas (#37), os frascos guardados
		heroes[p.hero] = {"passives": p.passives, "points": p.points, "supports": kept[0], "soul": kept[1], "respecs": p.respecs, "gear": p.gear, "bag": p.bag, "locks": p.locks}
	var t := {} if tomb.is_empty() else {"pos": [tomb.pos.x, tomb.pos.y], "lost": tomb.lost}
	var cur := currency.duplicate()
	var mt := mats.duplicate()
	if enemies().any(func(e): return e.boss == "tita"):  # o Titã (#70) acordado leva o Coração; fechar a app não o perde
		cur.coracao += 1
	if zone == "sep" and is_instance_valid(chest) and not chest.opened and not chest.locked and nearest_player(chest.position) != null:  # sep_max grava-se antes de o relicário se abrir: fechar a app não leva a vitória e deixa o saque; quem caiu, cai sem ele
		for r in chest.rewards:
			if Loot.is_mat(r[0]):  # G5: um material do relicário vai para os materiais
				mt[r[0]] = mt.get(r[0], 0) + r[1]
			else:
				cur[r[0]] += r[1]
	return {"v": 1, "hero": players[0].hero, "level": level, "xp": xp, "currency": cur, "weapon": weapon, "heroes": heroes,
		"flasks": flasks, "tomb": t, "kills": kills, "circle": circle, "circle_max": circle_max, "wins": wins, "relics": relics, "crypt_n": crypt_n,
		"crypt_last": crypt_last, "proven": proven, "deep": deep, "camps_done": camps_done, "sep_runs": sep_runs, "sep_max": sep_max, "bags": bags, "forms": forms, "beaten": beaten, "gods": gods, "mats": mt, "atlas": atlas}


## Só escreve quando algo mudou. Escreve num ficheiro à parte e depois troca-o pelo verdadeiro:
## se a app morrer a meio da escrita, o jogo gravado antigo fica inteiro.
func save_game() -> void:
	if hud == null or wiping or mirror or Net.is_guest():
		return
	var d := _save_data()
	var s := JSON.stringify(d)
	if s == saved_json:
		return
	var tmp := SAVE_PATH + ".tmp"
	var f := FileAccess.open(tmp, FileAccess.WRITE)
	if f == null:
		return
	f.store_string(s)
	f.close()
	if DirAccess.rename_absolute(tmp, SAVE_PATH) == OK:
		saved_json = s
		saved = d


## A app vai para segundo plano ou fecha: o Android pode matá-la a seguir sem avisar.
func _notification(what: int) -> void:
	if what in [NOTIFICATION_APPLICATION_PAUSED, NOTIFICATION_APPLICATION_FOCUS_OUT, NOTIFICATION_WM_CLOSE_REQUEST]:
		save_game()


func has_save() -> bool:
	return FileAccess.file_exists(SAVE_PATH)


## Novo jogo: apaga o jogo gravado e recomeça já a jogar (as configurações ficam).
func new_game() -> void:
	wiping = true
	DirAccess.remove_absolute(ProjectSettings.globalize_path(SAVE_PATH))
	restart()


## Recomeça a cena: para o ecrã de título, ou direto para o jogo (Novo jogo, Erguer-se).
func restart(to_title := false) -> void:
	if not to_title:
		Engine.set_meta("play_now", true)
	else:
		Net.close()  # voltar ao título fecha a sala (ou sai dela)
	get_tree().paused = false
	get_tree().reload_current_scene()


# ---------- Configurações ----------

func load_settings() -> void:
	var cf := ConfigFile.new()
	if cf.load(SETTINGS_PATH) == OK:
		for k in SETTINGS:
			var v = cf.get_value("opcoes", k, SETTINGS[k])
			if typeof(v) == typeof(SETTINGS[k]) or (SETTINGS[k] is float and v is int):
				settings[k] = v
		if cf.get_value("opcoes", "vibrate", true) == false and not cf.has_section_key("opcoes", "vibe"):
			settings.vibe = 0  # até à 0.3.2 a vibração era só ligada / desligada
		if cf.get_value("opcoes", "loot_names", 0) == 1 and not cf.has_section_key("opcoes", "loot_common"):
			settings.loot_common = 1  # até à 0.4.3 havia só "Nomes no chão: Só os raros"
	else:
		settings.ui = int(_num(saved.get("ui"), 0))  # até à 0.2.0 o tamanho dos botões ia no jogo gravado
		settings.lang = 0 if OS.get_locale_language() == "pt" else 1
	for k in ["master", "music", "sfx"]:
		settings[k] = clampf(float(settings[k]), 0.0, 1.0)
	for k in CHOICES:
		settings[k] = clampi(int(settings[k]), 0, CHOICES[k] - 1)


func save_settings() -> void:
	var cf := ConfigFile.new()
	for k in settings:
		cf.set_value("opcoes", k, settings[k])
	cf.save(SETTINGS_PATH)


func set_setting(key: String, v) -> void:
	settings[key] = v
	apply_settings()
	save_settings()


func reset_settings() -> void:
	var seen: bool = settings.intro_seen  # repor não volta a mostrar a intro
	settings = SETTINGS.duplicate()
	settings.intro_seen = seen
	apply_settings()
	save_settings()


## Som por canal, FPS, resolução e botões no ecrã. Tremor, clarão, números e partículas leem-se na hora.
## Efeitos visuais de agora: os das Configurações, um degrau abaixo se a proteção térmica atuou.
func effects_level() -> int:
	return maxi(0, settings.effects - (1 if thermal >= 1 else 0))


## Proteção térmica (#313): o Godot não lê a temperatura, mas um telemóvel quente baixa o relógio do
## processador e os FPS caem. 12 s abaixo de 75% do limite: primeiro menos efeitos, depois 30 FPS.
func thermal_check(delta: float, fps: float) -> void:
	if not settings.thermal or thermal >= 2:
		return
	var cap: float = Engine.max_fps if Engine.max_fps > 0 else 60.0
	thermal_t = thermal_t + delta if fps < cap * 0.75 else maxf(0.0, thermal_t - delta * 2.0)
	if thermal_t >= 12.0:
		thermal_t = 0.0
		thermal += 1
		apply_settings()
		hud.toast("Proteção térmica: menos efeitos para o telemóvel não aquecer." if thermal == 1 else "Proteção térmica: 30 FPS para o telemóvel não aquecer.")


func apply_settings() -> void:
	for b in [["Master", "master"], ["Musica", "music"], ["Efeitos", "sfx"]]:
		var i := AudioServer.get_bus_index(b[0])
		var v: float = settings[b[1]]
		AudioServer.set_bus_volume_db(i, linear_to_db(maxf(v, 0.001)))
		AudioServer.set_bus_mute(i, v <= 0.0)
	TranslationServer.set_locale("en_GB" if settings.lang == 1 else "pt_PT")
	Engine.max_fps = FPS_CAPS[settings.fps]
	if thermal >= 2 and (Engine.max_fps == 0 or Engine.max_fps > 30):
		Engine.max_fps = 30
	# Poupança: desenha a 720p e estica (muito menos píxeis nos ecrãs grandes)
	get_tree().root.content_scale_mode = Window.CONTENT_SCALE_MODE_VIEWPORT if settings.res == 1 else Window.CONTENT_SCALE_MODE_CANVAS_ITEMS
	if hud != null:
		hud.set_ui_scale(settings.ui)
		hud.pad.modulate.a = OPACITY[settings.opacity]
		hud.set_lefty(settings.lefty)
		hud.set_filter(settings.colorblind, settings.comfort * 0.5)
		hud.set_potion_scale(settings.potion_ui)
		hud.set_text_scale(TEXT[settings.text])
	if player != null:
		player.boss_first = settings.boss_aim
	for pfx in ["", "p2_"]:
		for a in PAD_AXES:
			InputMap.action_set_deadzone(pfx + a, DEADZONES[settings.deadzone])


## Menu → Soltar personagem: quem ficou preso numa parede volta ao sítio de partida da zona.
func unstuck() -> void:
	var at: Vector2 = sep.get("start", Vector2(0, 300)) if zone == "sep" else CRYPT_ORIGIN + CRYPT_IN if zone == "crypt" else Vector2(0, 300)
	for i in players.size():
		players[i].position = at + Vector2(50 * i, 0)
	cam.position = at
	cam.reset_smoothing()


## Vibração no telemóvel e nos comandos (se estiver ligada nas Configurações).
## who = o herói a quem aconteceu (só vibra o telemóvel dele); sem who vibra em todos.
func vibrate(ms: int, strength := 0.6, who = null) -> void:
	if who != null and Net.role == "host" and who.slot == 1:
		Net.echo("main", "vibrate", [ms, strength])  # o Guardião da Wi-Fi sente-o no telemóvel dele
		return
	if who == null:
		Net.echo("main", "vibrate", [ms, strength])
	if settings.vibe == 0:
		return
	var k: float = VIBE[settings.vibe]
	strength = clampf(strength * k, 0.05, 1.0)
	ms = int(ms * minf(k, 1.3))
	Input.vibrate_handheld(ms, strength)
	for d in pad_of:
		if d >= 0:
			Input.start_joy_vibration(d, strength * 0.6, strength, ms / 1000.0)


## Lê o jogo gravado. Ficheiro em falta ou estragado: começa do zero, sem rebentar.
func _read_save() -> Dictionary:
	if not FileAccess.file_exists(SAVE_PATH):
		return {}
	var d = JSON.parse_string(FileAccess.get_file_as_string(SAVE_PATH))
	return d if d is Dictionary else {}


static func _num(v, default: float) -> float:
	return float(v) if v is int or v is float else default


## Cada valor é conferido: o que não fizer sentido fica como num jogo novo.
func _apply_save() -> void:
	level = clampi(int(_num(saved.get("level"), 1)), 1, 999)
	xp = clampi(int(_num(saved.get("xp"), 0)), 0, 1000000)
	var kl = saved.get("kills")
	if kl is Dictionary:
		for k in XP:
			if kl.has(k):
				kills[k] = clampi(int(_num(kl[k], 0)), 0, 100000000)
	# Círculos: os jogos gravados de antes deles abrem o II a quem já quebrou o Cortejo
	var hk: int = kills.get("herald", 0)
	circle_max = clampi(int(_num(saved.get("circle_max"), 2 if hk > 0 else 1)), 1, 99)
	circle = clampi(int(_num(saved.get("circle"), circle_max)), 1, circle_max)
	wins = clampi(int(_num(saved.get("wins"), hk)), 0, 100000000)
	crypt_n = clampi(int(_num(saved.get("crypt_n"), 0)), 0, 100000000)
	deep = clampi(int(_num(saved.get("deep"), 0)), 0, 100000)  # o recorde do Mausoléu (#27)
	sep_runs = clampi(int(_num(saved.get("sep_runs"), 0)), 0, 100000)
	sep_max = clampi(int(_num(saved.get("sep_max"), 0)), 0, 999)
	bags = maxi(clampi(int(_num(saved.get("bags"), 0)), 0, 3), [5, 10, 15].filter(func(d): return d <= sep_max).size())  # #72: quem já tinha vencido os guardiões antes das Bolsas recebe-as
	crypt_last = saved.crypt_last if saved.get("crypt_last") in CRYPT_RULES else ""  # morrer ou ir ao título não deixa repetir a sala
	if saved.get("camps_done") is Array:
		for i in saved.camps_done:
			var n := int(_num(i, -1.0))
			if n >= 0 and n < CAMPS_PER * 4 and not n in camps_done:
				camps_done.append(n)
	var c = saved.get("currency")
	if c is Dictionary:
		for k in currency:
			currency[k] = clampi(int(_num(c.get(k), 0)), 0, 1000000)
	if saved.get("mats") is Dictionary:  # G5: só os materiais que existem (os jogos gravados antes do Lote 10 não os têm)
		for k in saved.mats:
			if k is String and Loot.is_mat(k):
				mats[k] = clampi(int(_num(saved.mats[k], 0)), 0, 9999)
	var at = saved.get("atlas")  # #185: só hexadecimal, no máximo um carácter por bloco (os jogos gravados antes do Lote 11 não o têm)
	atlas = at.to_lower() if at is String and at.length() <= ATLAS_MAX and (at == "" or (at.is_valid_hex_number() and at[0] != "+" and at[0] != "-")) else ""
	var owed: int = range(5, sep_max + 1, 5).reduce(func(s, d): return s + (2 if d in [25, 50] else 1), 0)
	if not saved.has("atlas") and owed > 0:  # quem já tinha vencido guardiões antes do Atlas recebe as Estacas deles (como as Bolsas de Almas)
		mats.estaca = maxi(mats.get("estaca", 0), owed)
	gods = clampi(int(_num(saved.get("gods"), 0)), 0, 100000)  # Lote 9: as vitórias no Santuário (abrem a Amálgama)
	if saved.get("beaten") is Dictionary:  # e o Livro dos Chefes: só os que existem, com um número de 0 em diante
		for id in saved.beaten:
			if id is String and (Bosses.INFO.has(id) or Bosses.BOOK.has(id)) and not id.begins_with("donzela_") and not id.begins_with("rei_") and id != "":
				beaten[id] = clampi(int(_num(saved.beaten[id], 0)), 0, 100000000)
	else:  # os jogos gravados antes do Livro: o que se sabe (as vitórias no Cortejo, as descidas à cripta e o recorde do Mausoléu)
		# com as voltas da 0.4.9, não as de agora (os chefes novos nunca se tinham visto): o Cortejo dava à vez o Arauto e o Guardião
		if wins > 0:
			beaten.arauto = (wins + 1) / 2
		if wins > 1:
			beaten.guardiao = wins / 2
		for i in mini(crypt_n, 4):  # a cada descida, o chefe seguinte dos 4 da 0.4.9: vistos (as vitórias não ficavam gravadas)
			beaten[CRYPT_BOSSES[i] if CRYPT_BOSSES[i] != "" else "carcereiro"] = 0
		for i in clampi((deep - 1) / 10, 0, 5):  # os chefes dos pisos 10 a 50 que já ficaram para trás: na 0.4.9, à vez o Arauto e o Guardião
			var id: String = "arauto" if i % 2 == 0 else "guardiao"
			beaten[id] = maxi(beaten.get(id, 0), 1)
	if saved.get("forms") is Array:  # G7: as almas da arma encontradas (os jogos gravados antes do Lote 8 não as têm)
		for f in saved.forms:
			if f is String and FORMS.has(f) and not f in forms:
				forms.append(f)
	var w = saved.get("weapon")
	if w is Dictionary and w.get("suffixes") is Array and String(w.get("hidden", "")) in HIDDEN:
		var suf: Array = w.suffixes.filter(func(s): return s is String and s in SUFFIXES)
		if suf.size() == 2:
			weapon = {"tier": clampi(int(_num(w.get("tier"), 0)), 0, 999), "suffixes": suf, "hidden": String(w.hidden), "sealed": w.get("sealed") != false,
				"locked": w.locked if w.get("locked") in suf else "",  # os jogos gravados antes do Formão (#54) não o têm
				"form": w.form if w.get("form") in forms else ""}  # G7: só uma alma que o grupo encontrou
	if saved.get("proven") is Array:
		for t in saved.proven:
			if t is String and TRIALS.has(t) and not t in proven:
				proven.append(t)
	if saved.get("relics") is Array:
		for r in saved.relics:
			if r is String and RELICS.has(r) and not r in relics:
				relics.append(r)
	if saved.get("flasks") is Array:
		for f in saved.flasks:
			if f is String and (f in Player.SUPPORTS or f in Player.SOULS) and not f in flasks:
				flasks.append(f)
	var t = saved.get("tomb")
	if t is Dictionary and t.get("pos") is Array and t.pos.size() == 2 and t.get("lost") is Dictionary:
		var lost := {}
		for k in currency:
			lost[k] = clampi(int(_num(t.lost.get(k), 0)), 0, 1000000)
		var pos := Vector2(_num(t.pos[0], 0.0), _num(t.pos[1], 0.0))
		if MAP.has_point(pos) and lost.values().any(func(v): return v > 0):
			tomb = {"pos": pos, "lost": lost}


func _apply_hero(p) -> void:
	var heroes = saved.get("heroes")
	var h = heroes.get(p.hero) if heroes is Dictionary else null
	if not h is Dictionary:
		return
	p.respecs = clampi(int(_num(h.get("respecs"), 0)), 0, 999)  # os jogos gravados antes de se poder refazer não o têm
	if h.get("passives") is Array:
		for id in h.passives:  # pela ordem gravada: cada nó só entra se a raiz dele já entrou (e se é deste herói, S3)
			if id is String and PASSIVES.has(id) and not id in p.passives and PASSIVES[id].req in p.passives and PASSIVES[id].get("hero", p.hero) == p.hero:
				p.passives.append(id)
	p.points = maxi(0, level + relics.size() - p.passives.size())  # os pontos vêm do nível e das Relíquias (#58): cada nó comprado gastou um (a Raiz é de graça)
	if h.get("supports") is Dictionary:
		for id in p.order:
			if h.supports.get(id) in p.SUPPORTS and not (id == p.order[0] and h.supports[id] in p.CURSED):
				p.skills[id].support = h.supports[id]
		if p.cursed_lock() != "":  # Frascos Malditos (#21): a habilidade presa fica vazia (com dois malditos, sai o segundo)
			p.skills[p.cursed_lock()].support = ""
	if h.get("soul") in p.SOULS:  # os jogos gravados antes das Almas Condensadas não a têm: fica sem nenhuma
		p.soul = h.soul
	p.gear = {}  # Equipamento (0.4.8): os jogos gravados de antes não o têm e ficam com os 4 lugares vazios
	p.bag = []
	p.locks = []
	if h.get("gear") is Dictionary:
		for s in Player.SLOTS:  # só os 4 lugares, e cada peça no lugar dela
			var it = h.gear.get(s)
			if Player.gear_ok(it) and Player.gear_slot(it) == s:
				p.gear[s] = it
	if h.get("bag") is Array:
		for it in h.bag:
			if Player.gear_ok(it) and p.bag.size() < p.bag_cap():
				p.bag.append(it)
	if h.get("locks") is Array:  # Trancar peças (#78): só peças certas que o herói ainda tem
		for it in h.locks:
			if Player.gear_ok(it) and (it in p.bag or it in p.gear.values()) and not it in p.locks and p.locks.size() < Player.LOCKS_MAX:
				p.locks.append(it)


# ---------- Arma & moedas ----------

func stat(key: String) -> float:
	if trial_on("lamina"):  # Provação da Lâmina Cega (#214): nem sufixos, nem oculto, nem reforja
		return 0.0
	var v := 0.0
	for s in weapon.suffixes:
		v += SUFFIXES[s].get(key, 0.0)
	if not weapon.sealed:
		v += HIDDEN[weapon.hidden].get(key, 0.0)
	if key == "dmg":
		v += weapon.tier * 0.1
	return v


func weapon_text() -> String:
	# os sufixos e a propriedade oculta gravam-se em português: só se traduzem aqui, ao mostrar
	var hid: String = tr("[SELADO — usa Cinzas]") if weapon.sealed else tr(weapon.hidden)
	var txt: String = tr("Foice do Coveiro +%d  %s\nOculto: %s") % [weapon.tier, ", ".join(weapon.suffixes.map(func(s): return tr("%s (travado)") % tr(s) if s == weapon.locked else tr(s))), hid]
	return txt + "\n" + tr("Alma da arma: %s") % tr(FORMS[weapon.form][0]) if weapon.get("form", "") != "" else txt


## G7: a alma da arma que conta agora ("" sem nenhuma; na Provação da Lâmina Cega, #214, a foice não conta).
func form_on() -> String:
	return "" if trial_on("lamina") else weapon.get("form", "")


## G7: põe na foice uma alma já encontrada ("" tira-a). Na Forja; o convidado pede-a (net.gd, "set_form").
func set_form(id: String) -> String:
	if id != "" and not id in forms:
		return ""
	weapon.form = id
	if id != "" and hud != null:  # Lote 9 C (b): o aviso de a pôr na foice já foi cumprido
		hud.unsay("Põe-na na foice, na Forja.")
	return tr("Alma da arma: %s") % tr(FORMS[id][0]) if id != "" else tr("A foice ficou sem alma.")


func _reroll_weapon() -> void:
	var keys := SUFFIXES.keys()
	keys.shuffle()
	var i: int = weapon.suffixes.find(weapon.locked)
	if i >= 0:  # Formão (#54): o sufixo travado fica no sítio e só o outro se sorteia
		keys.erase(weapon.locked)
		weapon.suffixes[1 - i] = keys[0]
	else:
		weapon.suffixes = keys.slice(0, 2)
	weapon.hidden = HIDDEN.keys()[rng.randi() % HIDDEN.size()]
	weapon.sealed = true


func use_currency(kind: String) -> String:
	match kind:
		"ink":
			if currency.ink < 1:
				return "Sem Tinteiros de Sangue Negro."
			currency.ink -= 1
			_reroll_weapon()
			return "Novos sufixos sorteados — a propriedade oculta foi selada de novo."
		"ash":
			if not weapon.sealed:
				return "Nada selado para revelar."
			if currency.ash < 1:
				return "Sem Cinzas do Purgatório."
			currency.ash -= 1
			weapon.sealed = false
			return tr("Revelado: %s") % tr(weapon.hidden)
		"bone":
			if currency.bone < 5:
				return "Precisas de 5 Ossos Ancestrais."
			currency.bone -= 5
			weapon.tier += 1
			return tr("Foice reforjada: +%d") % weapon.tier
		"lock0", "lock1":  # Formão Cadavérico (#54): trava um dos dois sufixos (o Tinteiro sorteia só o outro)
			if currency.formao < 1:
				return "Sem Formões Cadavéricos."
			currency.formao -= 1
			weapon.locked = weapon.suffixes[int(kind[4])]
			return tr("Travaste o sufixo «%s».") % tr(weapon.locked)
		"unlock":  # destravar é de graça
			if weapon.locked == "":
				return "Nenhum sufixo travado."
			var was: String = weapon.locked
			weapon.locked = ""
			return tr("Destravaste o sufixo «%s».") % tr(was)
		"carmesim":  # Tinteiro Carmesim (#59): troca só os sufixos de ataque destravados, sem voltar a selar a propriedade oculta
			if currency.carmesim < 1:
				return "Sem Tinteiros Carmesim."
			var swap := range(2).filter(func(n): return weapon.suffixes[n] in OFFENSIVE and weapon.suffixes[n] != weapon.locked)
			if swap.is_empty():
				return "Sem sufixos de ataque para trocar."
			currency.carmesim -= 1
			var pool: Array = OFFENSIVE.filter(func(s): return not s in weapon.suffixes)  # pelo menos 3: cada troca é diferente
			pool.shuffle()
			for n in swap:
				weapon.suffixes[n] = pool.pop_back()
			return "Novos sufixos de ataque sorteados."
		"pena_bone", "pena_ink", "pena_ash":  # Pena de Abutre (#239): 75% a pilha dobra (até 1 000 000), 25% arde toda
			var k := kind.substr(5)
			if currency.pena < 1:
				return "Sem Penas de Abutre."
			if currency[k] < 1:
				return tr("Sem %s para arriscar.") % tr(PILES[k])
			currency.pena -= 1
			if rng.randf() < 0.75:
				currency[k] = mini(currency[k] * 2, 1000000)
				spawn_fx("ring", player.position, 130.0, Color(1.0, 0.85, 0.4))
				return tr("A Pena brilha: %s a dobrar!") % tr(PILES[k])
			var lost: int = currency[k]
			currency[k] = 0
			spawn_fx("dust", player.position, 70.0, Color(0.55, 0.5, 0.45))
			return tr("A Pena ardeu: perdeste %d %s.") % [lost, tr(PILES[k] if lost > 1 else "Cinza do Purgatório" if k == "ash" else Loot.INFO[k][0])]  # no saque, Cinzas é o monte
	return ""


## Forja contínua (#100): gasta Tinteiros, um a um, até sair o sufixo s (no máximo 200 de uma vez); o travado fica.
func forge_until(s: String) -> String:
	if s in weapon.suffixes:
		return tr("Já tens o sufixo «%s».") % tr(s)
	var n := 0
	while n < 200 and currency.ink > 0 and not s in weapon.suffixes:
		use_currency("ink")
		n += 1
	if n == 0:
		return "Sem Tinteiros de Sangue Negro."
	if s in weapon.suffixes:
		return tr("Saiu o sufixo «%s» ao primeiro Tinteiro.") % tr(s) if n == 1 else tr("Saiu o sufixo «%s» ao fim de %d Tinteiros.") % [tr(s), n]
	return tr("Acabaram os Tinteiros sem sair o sufixo «%s» (gastaste %d).") % [tr(s), n]


## kind "flask" com flask = o Frasco de Alma (veloz, eco, tumular, colerica).
func drop(kind: String, pos: Vector2, amount := 1, pop := Vector2.ZERO, flask := ""):
	var l := Loot.new()
	l.main = self
	l.kind = kind
	l.amount = amount
	l.pop = pop
	l.flask = flask
	l.position = pos + Vector2(rng.randf_range(-30, 30), rng.randf_range(-20, 20))
	add_child(l)  # o som de cair é do saque (loot.gd _drop_sound): cada telemóvel toca o seu
	shake = maxf(shake, l.weight())  # o raro treme o ecrã (o equipamento, pela raridade)
	return l


## Um reagente da Forja ao acaso (S2); com common, também um dos 4 materiais comuns da Forja de Peças (G5).
func _reagent(common := false) -> String:
	var pool: Array = Loot.REAGENTS + (COMMON_MATS if common else [])
	return pool[rng.randi() % pool.size()]


## Um dos 4 materiais comuns da Forja de Peças ao acaso (G5).
func _common_mat() -> String:
	return COMMON_MATS[rng.randi() % COMMON_MATS.size()]


## G5: o que se apanha ou sai de um relicário: um material vai para mats, o resto para as moedas.
func give(k: String, n: int) -> void:
	if Loot.is_mat(k):
		mats[k] = mini(mats.get(k, 0) + n, 9999)
	else:
		currency[k] += n


## Uma peça de equipamento no chão (0.4.8): o item vai no campo flask, como as relíquias. Com mais de GEAR_FLOOR no chão,
## esta vai logo para o herói mais perto.
func drop_gear(it: String, pos: Vector2, pop := Vector2.ZERO):
	var l = drop("gear", pos, 1, pop, it)
	if get_tree().get_nodes_in_group("loot").filter(func(o): return o.kind == "gear" and not o.is_queued_for_deletion()).size() > GEAR_FLOOR:  # as apanhadas neste frame ainda estão no grupo (como main:1407 e net:243)
		collect(l)
	return l


## Incensário Fúnebre (#63): a proteção do grupo em pos, a maior dos heróis de pé a 350 px (7 m; dois incensários não se somam).
func aura_at(pos: Vector2) -> float:
	var best := 0.0
	for q in players:
		if not q.dead and q.position.distance_to(pos) <= 350.0:
			best = maxf(best, q.stat("aura"))
	return best


## Uma peça nova de raridade r (0 comum, 1 mágica, 2 rara, 3 única): a base ao calhas e r afixos diferentes, nunca o da
## base, cada um com a força dele (G3: strong, dos elites e dos chefes, sai mais vezes no máximo). Um único que o grupo já
## tenha (_unique_taken) não se repete: sem nenhum livre, sai uma rara.
func roll_gear(r: int, strong := false) -> String:
	if r == 3:
		var free: Array = Player.UNIQUES.filter(func(u): return not _unique_taken(u))
		if not free.is_empty():
			return free[rng.randi() % free.size()] + ":3"
		r = 2
	var s: String = Player.SLOTS[rng.randi() % Player.SLOTS.size()]  # G2: o lugar primeiro (20% cada), depois uma base dele: mais bases num lugar não puxam mais peças para lá
	var bs: Array = Player.BASES.filter(func(k): return Player.GEAR[k].slot == s)
	var b: String = bs[rng.randi() % bs.size()]
	var keys: Array = Player.AFFIX.keys().filter(func(k): return k != Player.GEAR[b].key)
	var it := b + ":" + str(r)
	for i in r:
		it += ":" + keys.pop_at(rng.randi() % keys.size()) + Player.roll_level(rng, strong)
	return it


## Um único já é do grupo? Posto ou na mochila de quem joga, no jogo gravado do herói que não está a jogar (só existe em
## saved.heroes, main:1002), ou ainda no chão (os que vão sair não contam).
func _unique_taken(u: String) -> bool:
	var held := []
	for q in players:
		held += q.gear.values() + q.bag
	var hs = saved.get("heroes")
	for id in Player.HEROES:
		var h = hs.get(id) if hs is Dictionary else null
		if h is Dictionary and not players.any(func(q): return q.hero == id):
			held += (h.gear.values() if h.get("gear") is Dictionary else []) + (h.bag if h.get("bag") is Array else [])
	# G2: pela base ("elo"), não pela peça inteira: uma peça pode vir a levar mais marcas (G3)
	return held.any(func(x): return x is String and x.get_slice(":", 0) == u) or get_tree().get_nodes_in_group("loot").any(func(l): return l.kind == "gear" and l.flask.get_slice(":", 0) == u and not l.is_queued_for_deletion())


## O equipamento que a morte de e larga (GEAR_DROP): os chefes com nome primeiro, depois os outros chefes, os elites e o resto.
func _drop_gear(e, named: bool) -> void:
	var row: Array = GEAR_DROP.named if named else GEAR_DROP.boss if e.is_boss else GEAR_DROP.elite if e.elite else GEAR_DROP.normal
	if not gear_drops or rng.randf() >= row[0]:
		return
	var x := rng.randf()
	var r: int = 3 if named and rng.randf() < GEAR_UNIQUE else 0 if x < row[1] else 1 if x < row[1] + row[2] else 2
	if r == 3:  # G7: 40% das vezes, se faltar alguma, o único sai como uma alma da arma (nunca uma que já está no chão)
		var missing: Array = FORMS.keys().filter(func(f): return not f in forms and not get_tree().get_nodes_in_group("loot").any(func(l): return l.kind == "arma" and l.flask == f and not l.is_queued_for_deletion()))
		if not missing.is_empty() and rng.randf() < FORM_CHANCE:
			drop("arma", e.position, 1, Vector2.from_angle(rng.randf() * TAU) * 140.0, missing[rng.randi() % missing.size()])
			return
	drop_gear(roll_gear(r, named or e.is_boss or e.elite), e.position, Vector2.from_angle(rng.randf() * TAU) * 140.0)


func collect(l) -> void:
	if l.is_queued_for_deletion():
		return  # já apanhada neste frame (ao mudar de zona e por estar perto)
	var to = nearest_player(l.position)
	if to != null and fx_budget("pickup", 4, 12):  # voa para o peito do herói e rebenta em faíscas, mais quanto mais raro
		var f := spawn_fx("pickup", l.position, 0.0 if l.kind == "bone" and l.amount == 1 else 14.0 if l.kind in ["ash", "flask", "relic", "transitoria", "coracao", "gear", "arma"] or l.kind in Loot.REAGENTS or Loot.is_mat(l.kind) else 10.0 if l.kind == "ink" else 6.0, l.color(), Vector2.RIGHT, Player.RARITY_RAMP[l.rarity()] if l.kind == "gear" else Loot.RAMP[l.kind])
		f.follow = to.slot
		f.item = l.flask if l.kind == "flask" else l.flask.get_slice(":", 0) if l.kind in ["gear", "arma"] else l.kind
	if l.has_meta("prova") and not "almas" in proven:  # o Frasco da 1.ª vitória na Provação das Almas (#37)
		proven.append("almas")
	if l.kind == "blood":  # Hemofilia Espiritual: cura 5% da vida a quem o apanha
		var p = nearest_player(l.position)
		if p != null:
			p.heal(p.max_hp * 0.05)
			spawn_fx("glow", p.position + Vector2(0, -40), 55.0, Color(0.85, 0.12, 0.18))
			sfx("potion")
	elif l.kind == "soul":  # Sem Alma Própria (#132): 30% da alma ao herói mais perto que tenha a chave (o Guardião não a desperdiça)
		var keyed := players.filter(func(q): return not q.dead and q.stat("semalma") > 0.0)
		keyed.sort_custom(func(a, b): return a.position.distance_to(l.position) < b.position.distance_to(l.position))
		var p = keyed[0] if not keyed.is_empty() else nearest_player(l.position)
		if p != null:
			p.add_mana(p.max_mana * 0.3)  # com a Mente Fragmentada (#108) enche a poção de alma
			spawn_fx("glow", p.position + Vector2(0, -40), 55.0, Color(0.35, 0.7, 1.0))
			sfx("potion")
	elif l.kind == "transitoria":  # Alma Transitória (#4): uma alma de um só uso para o herói mais perto, durante 60 s
		var p = nearest_player(l.position)
		if p != null:
			p.trans_kind = Player.TRANS.keys()[rng.randi() % Player.TRANS.size()]
			p.trans_until = time + Player.TRANS_T
			hud.toast(tr("O %s apanhou uma Alma Transitória: %s!\nToca no botão dela (no comando, LS) para a libertar antes de 60 s.") % [tr(p.hero_name), tr(Player.TRANS[p.trans_kind])])  # com o nome: o aviso chega aos dois telemóveis
			sfx("chest")
	elif l.kind == "relic":  # Relíquia de Família (#58): +1 ponto na Árvore a cada herói; repetida vale ossos
		if l.flask in relics:
			currency.bone += 5
		else:
			relics.append(l.flask)
			for q in players:
				q.points += 1
			hud.name_card("Relíquia encontrada", RELICS[l.flask][0], "")  # sem o "Chefe" por cima
			hud.toast(RELICS[l.flask][1])
			sfx("chest")
			save_game()
	elif l.kind == "arma":  # G7: uma alma da arma nova; repetida vale ossos. Com outro cartão à vista (a Relíquia do 1.º guardião), vai num aviso
		if l.flask in forms:
			currency.bone += 5
		else:
			forms.append(l.flask)
			if hud.card_t > 0.0:
				hud.toast(tr("Alma da arma encontrada: %s.") % tr(FORMS[l.flask][0]) + "\n" + tr("Põe-na na foice, na Forja."))
			else:
				hud.name_card("Alma da arma encontrada", FORMS[l.flask][0], "")
				hud.toast("Põe-na na foice, na Forja.")
			sfx("chest")
			save_game()
	elif l.kind == "coracao":  # Coração de Titã (#70): diz onde se oferece
		currency.coracao += l.amount
		hud.toast("Coração de Titã Petrificado!\nOferece-o no altar do cemitério para acordar o Titã.")
		sfx("chest")
	elif l.kind == "gear":  # Equipamento (0.4.8): para quem está mais perto (to, main:1409); com todos caídos (Mausoléu, main:718), para o 1.º: nada se perde
		var q = to if to != null else players[0]
		var msg: String = q.take_gear(l.flask)
		if msg != "":  # a comum desfeita logo não avisa (só o número por cima do herói)
			hud.toast(msg)  # com o nome do herói: o aviso chega aos dois telemóveis (hud:605-607)
		if l.rarity() == 3:
			hud.name_card("Peça única encontrada", Player.gear_name(l.flask), "")  # como a relíquia (main:1444)
		if l.rarity() >= 2:
			sfx("chest")
	elif l.kind != "flask":
		give(l.kind, l.amount)  # G5: os materiais à parte das moedas
	elif l.flask in flasks:
		currency.bone += 5  # repetido: vale ossos
	else:
		flasks.append(l.flask)
		hud.toast(tr("Encontraste o %s!\nPõe-no numa habilidade no Arsenal (não no golpe básico)." if l.flask in Player.CURSED else "Encontraste a %s! Põe-na numa habilidade no Arsenal." if l.flask in Player.SUPPORTS else "Encontraste uma Alma Condensada: %s! Equipa-a no Arsenal.") % tr(Player.SUPPORT_NAMES[l.flask]))
		sfx("chest")
		save_game()
	l.queue_free()


## Alma Tumular: o inimigo ergue-se como esqueleto do herói. No máximo 4; o mais antigo desfaz-se.
func spawn_ally(pos: Vector2, by, half := false) -> Node2D:
	var allies := get_tree().get_nodes_in_group("allies").filter(func(a): return a.life > 0.0)  # os desfeitos neste frame já não contam (a Mitótica ergue dois de uma vez)
	if allies.size() >= MAX_ALLIES:
		allies[0].life = 0.0
	var a := Ally.new()
	a.main = self
	a.owner_p = by
	a.half = half
	if by.stat("canibal") > 0.0:  # Canibalismo Espiritual (#122): lacaios de 4 s, para serem comidos depressa
		a.life = 4.0
	a.kind = "arqueiro" if by.stat("arqueiros") > 0.0 else "guarda" if by.stat("guardioes") > 0.0 else ""  # Esqueletos especializados (#11)
	a.position = pos
	add_child(a)
	return a


# ---------- Combate ----------

func enemies() -> Array:
	return get_tree().get_nodes_in_group("enemies")


func spawn_enemy(kind: String, pos: Vector2, mods: Dictionary, in_cortejo: bool):
	var e := Enemy.new()
	e.main = self
	e.cortejo = in_cortejo
	e.position = pos
	e.setup(kind, mods)
	e.killed.connect(_on_enemy_killed)
	add_child(e)
	return e


## ramp e ground só servem os efeitos em píxeis (fx.gd): a rampa de cores pelo nome e o chão em relação a pos.
func spawn_fx(kind: String, pos: Vector2, radius: float, color: Color, dir := Vector2.RIGHT, ramp := "", ground := 0.0) -> Fx:
	var f := Fx.new()
	f.kind = kind
	f.radius = radius
	f.color = color
	f.dir = dir
	f.position = pos
	f.amount = EFFECTS[effects_level()]
	f.alpha = FX_ALPHA[settings.fx_alpha]
	f.seed = randi()  # viaja ao convidado: o mesmo desenho dos dois lados (randi e não rng: não mexe nos críticos)
	f.ramp = ramp
	f.ground = ground
	add_child(f)
	return f


## Efeitos em píxeis por frame: um golpe pode acertar em 20, só os primeiros `cap` têm o efeito inteiro e os outros ficam
## com o antigo; e no máximo `live` vivos ao mesmo tempo (o sangue fica 5 s no chão). Com efeitos baixos, sempre o antigo.
func fx_budget(kind: String, cap: int, live: int) -> bool:
	if effects_level() == 0 or get_tree().get_node_count_in_group("px_" + kind) >= live:
		return false
	if Engine.get_process_frames() != fx_frame:
		fx_frame = Engine.get_process_frames()
		fx_count.clear()
	fx_count[kind] = fx_count.get(kind, 0) + 1
	return fx_count[kind] <= cap


func spawn_bolt(pos: Vector2, dir: Vector2, dmg: float, r: float, by, raise := 0, bone := false) -> Node2D:
	var b := Bolt.new()
	b.main = self
	b.by = by
	b.raise = raise
	b.bone = bone
	b.dir = dir
	b.dmg = dmg
	b.r = r
	b.position = pos + dir * 20.0
	add_child(b)
	return b


## Sentinelas Tumulares (#25): cada lápide fincada pela esquiva dispara um estilhaço de osso ao monstro mais perto (até 420 px)
## a cada 1,5 s. Guarda horas, não contadores: a lista só muda (e só vai ao convidado) ao fincar, disparar ou desfazer-se.
func _sentinels() -> void:
	for i in range(sentinels.size() - 1, -1, -1):
		var s: Array = sentinels[i]
		if s[1] <= time:
			sentinels.remove_at(i)
			continue
		if s[2] > time:
			continue
		s[2] = time + 1.5
		var best = null
		var best_d := 420.0
		for e in enemies():  # quem está a morrer já saiu do grupo
			var d: float = s[0].distance_to(e.position)
			if d < best_d:
				best_d = d
				best = e
		# o tiro conta como do herói que a fincou; se ele caiu (ou saiu da sala), do herói vivo mais perto
		var by = players[s[3]] if s[3] < players.size() and not players[s[3]].dead else nearest_player(s[0])
		if best == null or by == null:
			continue
		var from: Vector2 = s[0] + Vector2(0, -30)
		var dir := from.direction_to(best.position + Vector2(0, -20))
		spawn_bolt(from, dir, 8.0 + 1.5 * level, 10.0, by, 0, true).seek = best
		spawn_fx("sparks", from, 0.0, Color(0.95, 0.9, 0.75), dir)


## Escriba da Agonia (#155): a cada 90 px andados, o herói com a alma inscreve uma runa oculta (até 6 no grupo, 10 s); o
## primeiro monstro que a pise rebenta-a (dano em 80 px). Ocultas: o anel e os números são o único aviso.
func _runes() -> void:
	for p in players:
		if p.soul == "escriba" and not p.dead and p.position.distance_to(p.rune_at) >= 90.0:  # parado não escreve
			p.rune_at = p.position
			runes.append([p.position, time + 10.0, p.slot])
			if runes.size() > 6:
				runes.pop_front()
	while not runes.is_empty() and runes[0][1] <= time:  # todas duram 10 s: a mais antiga sai primeiro
		runes.pop_front()
	if runes.is_empty():
		return
	var foes := enemies()  # uma vez por frame: no máximo 6 runas × monstros
	for i in range(runes.size() - 1, -1, -1):
		var r: Array = runes[i]
		for e in foes:
			# o boneco de treino não anda (nunca pisa); quem morreu numa runa anterior deste frame já não conta
			if not e.dying and not e.dummy and r[0].distance_to(e.position) <= 20.0 + e.radius:
				runes.remove_at(i)
				# conta como do herói que a escreveu; se ele caiu (ou saiu da sala), do herói vivo mais perto
				var by = players[r[2]] if r[2] < players.size() and not players[r[2]].dead else nearest_player(r[0])
				if by != null:
					hit_circle(r[0], 80.0, 16.0 + 3.0 * level, by)
				spawn_fx("ring", r[0], 80.0, Color(0.9, 0.2, 0.25))  # o vermelho do cristal
				break


## Devolve [dano, crítico]. O inimigo trata do flash, número, faíscas e recuo. phys: golpe físico (foice, machado, Ceifa de Ossos).
func _damage(e, dmg: float, by, from: Vector2, phys := false) -> Array:
	if e.is_boss:
		dmg *= 1.0 + by.stat("boss")
	dmg *= 1.0 - e.armor * (0.6 if cast_support == "voraz" else 1.0) * (0.5 if e.acid_until > time else 1.0)  # armadura (Colossos e Arauto); a Alma Voraz (#141) fura 40% dela; o ácido do Cutelo (G7), metade
	if cast_basic:  # G7: a alma da arma, só no golpe básico (depois da armadura: o ácido conta a partir do golpe seguinte)
		if basic_first == null:
			basic_first = e
		if form_on() == "cutelo":  # o ácido pega-se a quem está a 150 px (3 m) deste, ele incluído
			for o in enemies():
				if o.position.distance_to(e.position) <= 150.0:
					o.acid_until = time + 4.0
	if e.exposed_t > 0.0:
		dmg *= 3.0
	if e.stagger_t > 0.0:
		dmg *= 1.5
	if e.necro > 0:  # Necrose Galopante (#154): cada camada já posta faz levar +5%
		dmg *= 1.0 + e.necro * 0.05
	if e.rot_t > 0.0:  # Febre Sepulcral (#171): o podre que se mexe leva mais (esqueleto a andar +30%, até +60%)
		dmg *= 1.0 + minf(0.6, 0.3 * e.stride * e.speed / 85.0)
	if by.stat("rot") > 0.0:
		e.apply_rot(dmg * 0.3 * by.stat("rot"))
	if by.stat("calcify") > 0.0:
		e.add_calc()
	if by.stat("necro") > 0.0:
		e.add_necro()
	if phys and by.stat("garras") > 0.0:  # Garras do Coveiro Insone (#226): os golpes físicos prendem-lhe os pés (a 60% durante 1,5 s, enemy:343 e enemy:378; não se desenha nada)
		e.slow_t = maxf(e.slow_t, 1.5)
	match cast_aff:  # Alma Caótica (#147): uma camada do estado da vez, como os sufixos a 1,0
		1:
			e.apply_rot(dmg * 0.3)
		2:
			e.add_necro()
		3:
			e.add_calc()
	var crit: bool = rng.randf() < CRIT + by.stat("crit") + (0.35 if by.overload_t > 0.0 else 0.0)  # Sobrecarga de Alma: +35% de crítico; as peças (0.4.8) somam o delas
	if by.stat("costas") > 0.0 and (not e.awake or e.target != by):  # Manoplas do Ceifador Silencioso (#254): quem não olha para ti leva sempre crítico
		crit = true
	if crit:
		dmg *= CRIT_MULT + by.stat("crit_dmg")  # o Visor da Agonia Perpétua (#252): 1,8 passa a 2,3
	var dir: Vector2 = from.direction_to(e.position) if from.distance_to(e.position) > 1.0 else Vector2.from_angle(rng.randf() * TAU)
	if cast_support == "gravidade":  # Alma Gravitacional: puxa para o centro do golpe em vez de empurrar (nunca para lá dele)
		dir = -dir * minf(1.5, from.distance_to(e.position) / 120.0)  # /120: nem um crítico a 10 FPS o atira para lá do herói
	# Hemofilia Espiritual (#162): crítico em quem sangra deixa cair um orbe de sangue que cura (no máximo 6 no chão)
	if crit and e.bleed_t > 0.0 and not e.dummy and by.stat("hemo") > 0.0:
		if get_tree().get_nodes_in_group("loot").filter(func(l): return l.kind == "blood").size() < 6:
			drop("blood", e.position, 1, dir * 90.0)
	# Hemorragia Ectoplasmática (#110): crítico em quem sangra dá +3 s aos lacaios a 200 px (4 m); sem vida, curá-los é
	# dar-lhes tempo, até ao de um lacaio novo (4 s com o Canibalismo, como no banquete da Comunhão)
	if crit and e.bleed_t > 0.0 and not e.dummy and by.stat("ecto") > 0.0:
		for a in get_tree().get_nodes_in_group("allies"):
			var top: float = 4.0 if is_instance_valid(a.owner_p) and a.owner_p.stat("canibal") > 0.0 else Ally.LIFE
			if a.life > 0.0 and a.life < top and a.position.distance_to(e.position) < 200.0:  # life 0: mandado embora pelo tecto de 4, não volta
				a.life = minf(a.life + 3.0, top)
				spawn_fx("glow", a.position, 40.0, Color(0.4, 1.0, 0.65))  # o verde dos lacaios
	e.raise_owner = raise_by  # o último golpe decide se ele se ergue como aliado
	e.raise_n = raise_n
	e.hit_by = by  # e o frasco do golpe: o abate (_on_enemy_killed) lê-os, por isso ficam antes do take_damage
	e.hit_support = cast_support
	e.hit_phys = phys  # Exumação Espontânea (#102): só o abate físico ergue
	var hp0: float = e.hp
	e.take_damage(dmg, true, dir, crit)
	if cast_basic and e.is_boss and form_on() == "basilisco":  # Dente de Basilisco (G7): 3% do que cada golpe básico tirou fica a doer por segundo, sem fim (num chefe imune, nada)
		e.venom += (dmg if e.dummy else hp0 - e.hp) * 0.03
	return [dmg, crit]


## bleeds: os círculos que sangram são os do corpo a corpo (rodopio do machado, Ceifa de Ossos), logo físicos.
## fire: false nos que nunca acendem o piche (#166), seja qual for o raio: o rodopio do machado e os espinhos do Pacto.
func hit_circle(origin: Vector2, radius: float, dmg: float, by, bleeds := false, fire := true) -> void:
	var hits := []
	var struck := []  # em quem bateu (os arcos da Alma Biomecânica, #144)
	for e in enemies():
		if e.dying:  # morto a meio deste golpe (estilhaços do Frio do Purgatório): já não conta para o roubo de vida
			continue
		if e.position.distance_to(origin) <= radius + e.radius:
			hits.append(_damage(e, dmg, by, origin, bleeds))
			struck.append(e)
			if bleeds and by.stat("frio") <= 0.0:  # Frio do Purgatório (#104): calcifica em vez de sangrar
				e.apply_bleed(dmg * (0.35 + by.stat("bleed")) * _form_bleed(e), 3.0)
			if bleeds and by.stat("carrasco") > 0.0 and e.executable(by):  # Carrasco de Sangue Negro (#124): o rodopio do machado e a Ceifa de Ossos também executam
				soul_strike(e, by)
			if cast_support == "terramoto" and not e.dying and not e.dummy:  # Alma Sísmica (#173): braços de osso saem da fissura e prendem-no (o boneco não: parado, o dano por segundo saía errado)
				if e.is_boss:  # os chefes só abrandam, como nos Ecos (#114)
					e.slow_t = maxf(e.slow_t, 2.0)
				else:  # estátua e não quebrado: o quebrado deixava extrair a Alma Ancestral
					e.statue_t = maxf(e.statue_t, 1.0)
				spawn_fx("dust", e.position, 40.0, Color(0.8, 0.8, 0.75))  # a poeira cinzenta da estátua (sem arte nova)
	_impact(hits, by)
	_arcs(struck, origin, dmg, by)
	_strike_corpses(origin, radius)
	_area_hit(origin, radius, fire and (not bleeds or radius >= 150.0))  # Piche (#166): os feitiços e a Ceifa (150 px ou mais) acendem-no
	if bleeds and not webs.is_empty():  # Covil do Tecelão (#36): o rodopio do machado e a Ceifa cortam; os feitiços não
		_cut_webs(origin, radius, Vector2.ZERO)


## "Sangue e Osso": cada golpe corpo a corpo amaldiçoa com sangramento.
func hit_arc(origin: Vector2, dir: Vector2, radius: float, dmg: float, by) -> void:
	var hits := []
	var struck := []
	var exe: bool = by.stat("carrasco") > 0.0  # Carrasco de Sangue Negro (#124): o machado executa sozinho abaixo de 20%
	for e in enemies():
		if e.dying:
			continue
		var v: Vector2 = e.position - origin
		if v.length() <= radius + e.radius and (v.length() < 24.0 or absf(dir.angle_to(v)) < 1.3):
			hits.append(_damage(e, dmg, by, origin, true))
			struck.append(e)
			if by.stat("frio") <= 0.0:  # Frio do Purgatório (#104): o golpe calcifica em vez de sangrar
				e.apply_bleed(dmg * (0.35 + by.stat("bleed")) * _form_bleed(e), 3.0)
			if by.stat("sede") > 0.0:  # Sede Ancestral (#135): a foice e o machado bebem-lhe a vida durante 4 s
				e.drain_t = 4.0
				e.drain_by = by
			if exe and e.executable(by):
				soul_strike(e, by)
	_impact(hits, by)
	_arcs(struck, origin, dmg, by)
	_strike_corpses(origin, radius)
	_open_jars(origin, dir, radius)
	if not webs.is_empty():
		_cut_webs(origin, radius, dir)


## G7: o golpe básico com o Cutelo da Peste Vermelha (+25%) ou, fora dos chefes, com o Dente de Basilisco (+30%) sangra mais.
func _form_bleed(e) -> float:
	if not cast_basic:
		return 1.0
	var f := form_on()
	return 1.25 if f == "cutelo" else 1.3 if f == "basilisco" and not e.is_boss else 1.0


## Alma Biomecânica (#144): de cada alvo do golpe (até 3) saltam arcos de raio para os 2 monstros mais perto ainda por
## acertar (até 160 px), com 40% do dano; na volta da Ceifa de Ossos (chain_all, #153) ligam em roda, por ângulo, todos
## os que ela apanhou (25%). Os arcos não soltam mais arcos (arcing).
func _arcs(struck: Array, origin: Vector2, dmg: float, by) -> void:
	if cast_support != "biomecanica" or arcing or struck.is_empty():
		return
	arcing = true
	var links := []  # [de, para, parte do dano]
	if chain_all:
		struck.sort_custom(func(a, b): return origin.angle_to_point(a.position) < origin.angle_to_point(b.position))
		var n := struck.size()
		for i in (n if n > 2 else n - 1):  # com 3 ou mais fecha a roda; com 2 é um arco só
			links.append([struck[i], struck[(i + 1) % n], 0.25])
	else:
		var done := struck.duplicate()
		for s in struck.slice(0, 3):
			var near := enemies().filter(func(o): return not o in done and o.position.distance_to(s.position) < 160.0)
			near.sort_custom(func(a, b): return a.position.distance_squared_to(s.position) < b.position.distance_squared_to(s.position))
			for o in near.slice(0, 2):
				done.append(o)
				links.append([s, o, 0.4])
	for l in links:
		if not l[1].dying:  # morto por um arco anterior
			_damage(l[1], dmg * l[2], by, l[0].position)
			spawn_fx("arc", l[0].position + Vector2(0, -30), l[0].position.distance_to(l[1].position), Color(0.7, 0.5, 1.0), l[0].position.direction_to(l[1].position))
	arcing = false


## Um golpe = um tremor, um congelar e um som, mesmo que acerte em 20 inimigos.
## Crítico: congela mais, zoom de impacto e flash no ecrã.
func _impact(hits: Array, by) -> void:
	if hits.is_empty():
		return
	var dealt := 0.0
	var crit := false
	for h in hits:
		dealt += h[0]
		crit = crit or h[1]
	if cast_support == "eter" and not by.dead:  # Alma de Éter (#164): o roubo de vida, mais 5% do dano, volta como alma
		var gain: float = dealt * (0.05 + by.stat("leech"))
		by.add_mana(gain)
		if gain >= 1.0:  # só golpes que se notam: sem brilho a cada arranhão
			spawn_fx("glow", by.position + Vector2(0, -40), 40.0, Color(0.35, 0.7, 1.0))
	else:
		by.heal(dealt * by.stat("leech"))
	if quiet:
		return
	shake = maxf(shake, 9.0 if crit else 4.0)
	hitstop(0.08 if crit else 0.045)
	sfx("crit" if crit else "hit")
	if crit:
		zoom_kick = maxf(zoom_kick, 0.06)
		hud.flash(0.22)
		vibrate(35, 0.5, by)


func hitstop(dur: float) -> void:
	if Engine.time_scale < 1.0:
		return
	Engine.time_scale = 0.05
	await get_tree().create_timer(dur, true, false, true).timeout
	Engine.time_scale = 1.0


## `pitch` > 0 fixa o tom (o tinido do saque sobe com a raridade); 0 = variação aleatória de sempre.
## local: só neste telemóvel (o saque a cair toca em cada um, com o filtro de cada um).
func sfx(name: String, pitch := 0.0, local := false) -> void:
	if not local:
		Net.echo("main", "sfx", [name, pitch])
	var now := Time.get_ticks_msec()
	var key := name + str(pitch)  # tons diferentes no mesmo frame (saque do chefe) não se calam uns aos outros
	# o toque de vitória dura 3,5 s: o Arauto e o fim da onda não o tocam por cima; mortes e golpes em série (uma
	# Explosão que mata 20) soavam a metralhadora: no máximo um a cada 90 ms
	if now - sfx_last.get(key, -10000) < (3000 if name == "victory" else 90 if name in ["die", "swing"] else 40):
		return
	sfx_last[key] = now
	var a := AudioStreamPlayer.new()
	a.stream = SFX[name]
	a.pitch_scale = pitch if pitch > 0.0 else randf_range(0.9, 1.12)
	a.volume_db = -4.0
	a.bus = "Efeitos"
	a.finished.connect(a.queue_free)
	add_child(a)
	a.play()


## Troca de faixa em fusão: a nova entra em `music` (a que se ouve) e a antiga apaga-se em `music_b`.
## Sem fade explícito, o chefe entra depressa (os sinos do Arauto tocam por cima) e sai devagar.
func play_track(id: String, fade := -1.0) -> void:
	if id == track or not MUSIC.has(id):  # (o anfitrião acabado de recomeçar ainda manda "")
		return
	if fade < 0.0:
		fade = 0.3 if id == "boss" else 2.5 if track == "boss" else 1.5
	track = id
	if music_tw:
		music_tw.kill()  # senão o fim da fusão antiga calava a faixa nova (mundo → chefe → mundo depressa)
	music_b.stop()
	var old := music
	music = music_b
	music_b = old
	music.stream = MUSIC[id]
	music.volume_db = -40.0
	music.play()
	music_tw = create_tween().set_pause_mode(Tween.TWEEN_PAUSE_PROCESS).set_parallel()  # corre com o jogo em pausa
	music_tw.tween_property(music, "volume_db", MUSIC_DB[id], fade)
	if music_b.playing:
		music_tw.tween_property(music_b, "volume_db", -40.0, fade)
		music_tw.chain().tween_callback(music_b.stop)


## A faixa de agora: o chefe manda, depois o Cortejo (a marcha segue entre ondas), depois a zona.
## Só quem simula escolhe; o convidado recebe-a em "track".
func _music_pick() -> void:
	var id := "boss" if (arena_r > 0.0 and mausoleum % 10 == 0) or (is_instance_valid(guardian) and guardian_met) else "cortejo" if cortejo.wave > 0 or mausoleum > 0 else "world" if zone == "world" else "crypt"
	play_track(id)


func number(pos: Vector2, text: String, size: float, color: Color):
	var f := Fx.new()
	f.kind = "num"
	f.text = text
	f.radius = size
	f.color = color
	f.position = pos
	f.visible = settings.numbers
	add_child(f)
	return f


func _on_enemy_killed(e) -> void:
	# Fúria Póstuma (#169): quem mata a tempo volta com 20% da vida (antes das curas do abate, que a Fúria já não trava; a
	# Estátua Funerária e a Alma Rebelde também contam)
	if is_instance_valid(e.hit_by) and e.hit_by.furia_until > time:
		e.hit_by.furia_until = 0.0
		e.hit_by.hp = maxf(e.hit_by.hp, e.hit_by.max_hp * 0.2)
		number(e.hit_by.position + Vector2(0, -130), tr("De volta!"), 22.0, Color(1.0, 0.35, 0.3))
	if e.anchor:  # uma Estátua Funerária do Guardião (#204), uma agulha da Tecelã (#207), um ovo da Matriarca (#40) ou um penitente do Bispo (#183): só 5 de XP, sem saque nem cadáver, e não conta no Bestiário
		gain_xp(5)
		if e.hatch_at > 0.0:  # o ovo partido: uma mancha verde
			spawn_fx("dust", e.position, 50.0, Color(0.55, 0.85, 0.35))
		for q in players:
			if q.slot == e.pin_of:  # a agulha partida solta o herói que ela cosia
				q.root_until = time
				number(q.position + Vector2(0, -130), "Livre!", 22.0, Color(0.92, 0.92, 1.0))
		return
	if e.expire_at > 0.0 or e.orb:  # uma Alma Rebelde (#196) morta antes de rebentar ou uma esfera do Arquilich (#217): nem XP nem saque
		return
	# S13 (Lote 9): de um grupo (as Donzelas, #187; os Reis, #34) só o último conta como chefe com nome: uma relíquia, uma peça
	# e um reagente pela luta toda. O guardião do Sepulcro passa à irmã que fica; os reis que ficam repartem os papéis
	var last: bool = e.trio == "" or not enemies().any(func(o): return o.trio == e.trio)
	if not last and e == guardian:
		guardian = Bosses.sisters(self, e.trio)[0]
	elif not last and e.trio == "reis":
		Bosses.crown(self, kings_k)
	var book: String = Bosses.book_id(e)
	if book != "" and last:  # o Livro dos Chefes
		beaten[book] = beaten.get(book, 0) + 1
	var amal: bool = e.style == "amalgama"  # #220: veste outro chefe (e.boss), mas a morte é a dela
	var named: bool = ((e == guardian and (zone != "sep" or sep_depth() % 5 == 0)) or e.kind == "herald" or e.boss != "") and last  # os chefes com nome (S2, S7): reagentes e relíquias (a Sentinela não)
	if e.is_boss:  # antes do XP: a pausa longa do chefe ganha à curta da subida de nível (hitstop ignora a segunda)
		shake = 16.0
		hitstop(0.18)
	gain_xp(XP["colossus" if e.boss != "" and e.kind == "specter" else e.kind] * (5 if e.elite else 1) * (1 + (e.tier + 1) / 2))  # a Tecelã (#207), espectro, paga como um colosso  # Elites (#277): o quíntuplo; e mais longe da praça, mais (tier 1 e 2: o dobro)
	if e.boss == "":  # o Bestiário conta os 4 mortos de sempre; os chefes com nome (S7) não
		var row: String = e.skin if e.skin != "" else e.kind  # cada morto na sua linha do Bestiário: um Enforcado não conta como Esqueleto
		kills[row] = kills.get(row, 0) + 1
	if e.title == "Gigante Errante":  # o próximo só daqui a 20 s
		giant_at = time + 20.0
	if e.elite and crypt_rule == "miasma" and breath_end < INF:  # Abismo do Miasma (#38): cada elite dá mais 20 s de ar (até 60)
		breath_end = minf(maxf(breath_end, time) + 20.0, time + 60.0)
		number(e.position + Vector2(0, e._top() - 40.0), tr("Sopro de Vida! +20 s"), 22.0, Color(0.5, 1.0, 0.55))
		spawn_fx("ring", e.position, 140.0, Color(0.5, 1.0, 0.55))
	if ((e.kind == "herald" and e.boss == "") or e.boss == "guardiao" or e.floor_boss) and not amal:  # o chefe do Cortejo: o Arauto ou o Guardião dos Monumentos (#204); ou o de um piso do Mausoléu (S13)
		sfx("victory")
		hud.card_t = minf(hud.card_t, 0.4)
		if mausoleum > 0 or zone == "sep":  # no Mausoléu (#27) é o chefe do piso: o piso acaba e a arena fica; nos Sepulcros também não é o Cortejo que vacila
			floor_end = time
			if e.floor_boss:  # G5: o chefe de cada 10 pisos deixa umas Cinzas Maiores
				drop("cinza_maior", e.position, 1, Vector2.from_angle(rng.randf() * TAU) * 140.0)
				drop("oleo_lapide", e.position, 1, Vector2.from_angle(rng.randf() * TAU) * 140.0)  # #227: e um Óleo de Lápide
			hud.toast(tr("A %s caiu!" if e.boss in Bosses.FEM else "O %s caiu!") % tr(e.who()))
		else:
			arena_r = 0.0
			hud.toast("O Guardião dos Monumentos caiu! O Cortejo vacila..." if e.boss == "guardiao" else "O Arauto Fúnebre caiu! O Cortejo vacila...")
		if e.boss == "guardiao":
			for o in enemies():  # as estátuas caem com ele
				if o.anchor and o.title == Bosses.STATUE:
					o.queue_free()
		if e.boss == "" and not "maldito_arauto" in flasks:  # o Frasco Maldito dele (#21), sempre, enquanto o grupo não o tiver
			drop("flask", e.position, 1, Vector2.from_angle(rng.randf() * TAU) * 120.0, "maldito_arauto")
	if e.boss == "tecela":  # as agulhas partem-se com ela e soltam quem coseram
		for o in enemies():
			if o.pin_of >= 0:
				o.take_damage(o.hp)
	elif e.boss in ["matriarca", "bispo"]:  # os ovos por chocar (#40) e os penitentes (#183) desfazem-se com quem os pôs ali
		for o in enemies():
			if o.hatch_at > 0.0 or (o.anchor and o.title == Bosses.PENITENT):
				spawn_fx("dust", o.position, 40.0, Color(0.8, 0.78, 0.7))
				o.queue_free()
	if e == guardian:
		guardian = null
		sfx("victory")
		hud.card_t = minf(hud.card_t, 0.4)
		if zone == "sep":
			_sep_boss_down(e)
		else:
			var m := loot_mult(level)
			var rew := [["bone", int(6 * m)], ["ink", 2 + level / 3], ["ash", 1 + level / 4]]
			if rng.randf() < 0.5:  # e um reagente da Forja (S2), uma vez em duas
				rew.append([_reagent(), 1])
			if rng.randf() < 0.2:  # e o Coração de Titã (#70), uma vez em cinco
				rew.append(["coracao", 1])
			_spawn_chest(rew, e.position + Vector2(0, 40))
			hud.toast(tr("A %s caiu! O relicário da cripta está livre." if e.boss in Bosses.FEM else "O %s caiu! O relicário da cripta está livre.") % tr(e.who()))
			if e.boss == "" and not "maldito_carcereiro" in flasks:  # o Frasco Maldito dele (#21), sempre, enquanto o grupo não o tiver
				drop("flask", e.position, 1, Vector2.from_angle(rng.randf() * TAU) * 120.0, "maldito_carcereiro")
		if crypt_rule == "miasma":  # e o ar do Abismo do Miasma (#38) limpa-se
			breath_end = INF
			number(e.position + Vector2(0, e._top() - 40.0), tr("O ar limpa-se."), 24.0, Color(0.5, 1.0, 0.55))
	if e.boss == "tita":  # o Titã Petrificado (#70): um relicário onde caiu (o do Cortejo que ficou por abrir vai para as moedas)
		var mt := loot_mult(level)
		_bank_chest()
		_spawn_chest([["bone", int(10 * mt)], ["ink", 3 + level / 3], ["ash", 2 + level / 4]], e.position + Vector2(0, 40))
		sfx("victory")
		hud.toast("O Titã Petrificado caiu! O relicário dele está livre.")
	if amal:  # #220 Amálgama Primordial: as estátuas e as leis caem com ela; o relicário do Santuário x 1,5, mais 2 reagentes, e uma peça única
		for o in enemies():
			if o.anchor and o.title == Bosses.STATUE:
				o.queue_free()
		end_mode()
		sfx("victory")
		hud.card_t = minf(hud.card_t, 0.4)
		var aa := circle_level()
		var am := loot_mult(aa)
		_bank_chest()
		_spawn_chest([["bone", int(30 * am)], ["ink", int((5 + aa / 3) * 1.5)], ["ash", int((3 + aa / 4) * 1.5)], [_reagent(), 1], [_reagent(), 1], [_reagent(), 1], [_reagent(), 1], ["cinza_maior", 3], ["oleo_lapide", 1]], e.position + Vector2(0, 40))  # o do Santuário x 1,5, com as Cinzas Maiores e o Óleo dele
		drop_gear(roll_gear(3, true), e.position, Vector2.from_angle(rng.randf() * TAU) * 140.0)  # G3: sem único livre, uma rara de chefe
		hud.toast("Venceste a Amálgama Primordial!")
	elif e.trio == "reis" and last:  # #34 Os Reis Caídos: o relicário do Santuário, uma peça rara por herói e uma Relíquia que falte
		end_mode()
		sfx("victory")
		hud.card_t = minf(hud.card_t, 0.4)
		var ka := circle_level()
		var km := loot_mult(ka)
		_bank_chest()
		_spawn_chest([["bone", int(20 * km)], ["ink", 5 + ka / 3], ["ash", 3 + ka / 4], [_reagent(), 1], [_reagent(), 1], ["cinza_maior", 2], ["oleo_lapide", 1]], e.position + Vector2(0, 40))
		for q in players:
			drop_gear(roll_gear(2, true), e.position, Vector2.from_angle(rng.randf() * TAU) * 140.0)  # G3: forças de chefe
		var lost_relics: Array = RELICS.keys().filter(func(r): return not r in relics)
		if not lost_relics.is_empty():
			drop("relic", e.position, 1, Vector2.from_angle(rng.randf() * TAU) * 140.0, lost_relics[rng.randi() % lost_relics.size()])
		hud.toast("Venceste os Reis Caídos!")
	if e.boss == "santuario" and not amal:  # Santuário dos Deuses Cadavéricos (#50): as leis caem com o deus e fica um relicário grande
		gods += 1  # Lote 9: a primeira vitória abre a Amálgama Primordial (#220)
		end_mode()
		sfx("victory")
		hud.card_t = minf(hud.card_t, 0.4)
		var sa := circle_level()
		var sm := loot_mult(sa)
		_bank_chest()
		_spawn_chest([["bone", int(20 * sm)], ["ink", 5 + sa / 3], ["ash", 3 + sa / 4], [_reagent(), 1], [_reagent(), 1], ["cinza_maior", 2], ["oleo_lapide", 1]], e.position + Vector2(0, 40))  # G5: e 2 Cinzas Maiores; #227: e um Óleo de Lápide
		hud.toast("Venceste o Santuário!")
	for p in players:
		if not p.dead:
			p.heal(p.stat("kill_heal"))
			p.fill_potions(1.0 if e.is_boss else 0.5 if e.elite else 0.25)  # 4 mortes = 1 poção (um elite, meia)
			if sanctum_rule == 3:  # Santuário (#50), Terceira lei: cada morte dá 30 de alma
				p.add_mana(30.0)
			elif sanctum_rule == 4:  # e a Quarta: cada morte cura 5% da vida
				p.heal(p.max_hp * 0.05)
	if e.hit_support == "martir" and is_instance_valid(e.hit_by) and not e.hit_by.dead:  # Alma Mártir (#151): o abate devolve logo a Esquiva
		e.hit_by.dash_cd = 0.0
		spawn_fx("sparks", e.hit_by.position + Vector2(0, -40), 0.0, Color(0.6, 1.0, 0.9))  # o ciano da esquiva perfeita
	if e.elite and is_instance_valid(e.hit_by) and not e.hit_by.dead and e.hit_by.stat("ressurreicao") > 0.0 \
			and not get_tree().get_nodes_in_group("allies").any(func(a): return a.owner_p == e.hit_by and a.power > 1.0 and a.life > 0.0):
		# Ressurreição de Elites (#179): o elite ergue-se para quem o matou, com o desenho dele e o triplo do dano (um de cada vez)
		var el = spawn_ally(e.position, e.hit_by)
		el.body = e.skin if e.skin != "" else e.kind
		el.power = 3.0
		if e.hit_by.stat("canibal") <= 0.0:  # com o Canibalismo Espiritual dura os 4 s dos outros
			el.life = 20.0
	elif e.raise_owner != null and is_instance_valid(e.raise_owner) and not e.is_boss:
		for i in e.raise_n:  # Alma Mitótica (#149): dois pequenos lado a lado, sem nascer dentro das paredes da cripta
			spawn_ally(walk(e.position, e.position + Vector2(60 * i - 30 * (e.raise_n - 1), 0)), e.raise_owner, e.raise_n > 1)
	elif e.hit_phys and not e.is_boss and is_instance_valid(e.hit_by) and not e.hit_by.dead and e.hit_by.stat("exumacao") > 0.0 and rng.randf() < 0.25:
		# Exumação Espontânea (#102): quem cai a um golpe físico ergue-se, 1 vez em 4, como esqueleto de quem bateu, só 10 s
		var ex = spawn_ally(e.position, e.hit_by)
		ex.life = minf(ex.life, 10.0)
	elif e.kind != "herald" and players.any(func(q): return q.stat("corpse") > 0.0):
		# Espasmo Cadavérico (#9, #115): ou se ergue como lacaio, ou fica no chão com o estado de quem morreu
		# Fome Insaciável da Terra (#137): se quem o matou a tem, a terra engole-o (sem alternativa: o Espasmo de outro herói guarda os corpos)
		var eater = e.hit_by if is_instance_valid(e.hit_by) and not e.hit_by.dead and e.hit_by.stat("fome") > 0.0 else null
		if eater:
			eater.fome_n = mini(eater.fome_n + 1, 6)
			spawn_fx("dust", e.position, 50.0, Color(0.45, 0.3, 0.2))
		else:
			var aff := 1 if e.rot_t > 0.0 else 2 if e.necro > 0 else 3 if e.calc > 0 or e.statue_t > 0.0 else 0
			corpses.append([e.position, aff, time + CORPSE_T, clampf(e.max_hp * 0.4, 8.0, 90.0)])
			if corpses.size() > 8:  # poucos cadáveres: baratos de desenhar e de mandar ao convidado
				corpses.pop_front()
	if e.necro > 0:  # Pestilência Saltadora (#178): metade das camadas salta para cada um dos dois monstros mais perto
		var near := enemies().filter(func(o): return o.position.distance_to(e.position) < 240.0)
		near.sort_custom(func(a, b): return a.position.distance_to(e.position) < b.position.distance_to(e.position))
		for o in near.slice(0, 2):
			o.necro = mini(o.necro + ceili(e.necro / 2.0), o.NECRO_MAX)
			o.necro_wait = 4.0
			spawn_fx("sparks", o.position + Vector2(0, -20), 0.0, Color(0.62, 0.36, 0.85), e.position.direction_to(o.position))
		if not near.is_empty():
			spawn_fx("ring", e.position, 60.0, Color(0.62, 0.36, 0.85))
	# Frio do Purgatório (#104): a estátua que morre rebenta em lascas de osso com o dano de um cadáver; as lascas também
	# calcificam (estátuas em cadeia, cada monstro só morre uma vez) e, ao contrário do cadáver, levam o frasco do golpe
	if e.statue_t > 0.0 and is_instance_valid(e.hit_by) and not e.hit_by.dead and e.hit_by.stat("frio") > 0.0:
		spawn_fx("ring", e.position, CORPSE_R, CORPSE_COLORS[3])
		if fx_budget("pfx_shatter", 3, 8):  # a estátua parte-se em lascas de gelo (a folha começa no estoiro: a estátua é a do jogo)
			spawn_fx("pfx_shatter", e.position, 1.0, Color.WHITE)
		else:
			spawn_fx("dust", e.position, 60.0, CORPSE_COLORS[3])
		hit_circle(e.position, CORPSE_R, clampf(e.max_hp * 0.4, 8.0, 90.0), e.hit_by)
	# Sem Alma Própria (#132): com a chave no grupo, cada abate deixa uma esfera de alma (no máximo 6 no chão)
	if players.any(func(q): return not q.dead and q.stat("semalma") > 0.0):
		if get_tree().get_nodes_in_group("loot").filter(func(l): return l.kind == "soul").size() < 6:
			drop("soul", e.position, 1, Vector2.from_angle(rng.randf() * TAU) * 90.0)
	# Frascos de Alma e Almas Condensadas: os chefes deixam sempre um que o grupo ainda não tenha; os outros, raramente, mais quantos mais faltarem
	var missing: Array = (Player.SUPPORTS + Player.SOULS).filter(func(f): return not f in flasks and not f in Player.CURSED)  # os Malditos (#21) só os dá o chefe deles
	if not missing.is_empty() and ((e.is_boss and last and not e.title in NO_BOSS_DROP) or rng.randf() < 0.002 * missing.size() * (10.0 if e.elite else 1.0)):
		drop("flask", e.position, 1, Vector2.from_angle(rng.randf() * TAU) * 120.0, missing[rng.randi() % missing.size()])
	elif e.boss == "tita":  # o Titã (#70) deixa sempre um Frasco que falte ou, sem nenhum, uma Relíquia de Família
		var lost: Array = RELICS.keys().filter(func(r): return not r in relics)
		if not lost.is_empty():
			drop("relic", e.position, 1, Vector2.from_angle(rng.randf() * TAU) * 140.0, lost[rng.randi() % lost.size()])
	# Chefes com nome: 30% um reagente da Forja (S2) e, num sorteio à parte (o dos frascos dava uma a cada colosso do
	# Cortejo), 35% uma Relíquia de Família (#58) que o grupo ainda não tenha; ela vai no campo flask do saque
	if named:
		if rng.randf() < 0.3:  # G5: o sorteio também traz os 4 materiais comuns
			drop(_reagent(true), e.position, 1, Vector2.from_angle(rng.randf() * TAU) * 140.0)
		var gone: Array = RELICS.keys().filter(func(r): return not r in relics)
		if not gone.is_empty() and e.boss != "tita" and e.trio != "reis" and rng.randf() < 0.35:  # o Titã já deu o dele: um Frasco ou uma Relíquia; os Reis (#34) dão sempre uma
			drop("relic", e.position, 1, Vector2.from_angle(rng.randf() * TAU) * 140.0, gone[rng.randi() % gone.size()])
	# Elites e Gigantes Errantes (#277, #39): uma Alma Transitória (#4: 35% / 50%) e um reagente da Forja (4% / 15%)
	if e.elite or e.title == "Gigante Errante":
		if rng.randf() < (0.35 if e.elite else 0.5):
			drop("transitoria", e.position, 1, Vector2.from_angle(rng.randf() * TAU) * 140.0)
		if rng.randf() < (0.04 if e.elite else 0.15):
			drop(_reagent(), e.position, 1, Vector2.from_angle(rng.randf() * TAU) * 140.0)
		if rng.randf() < (0.03 if e.elite else 0.1):  # G5: um material comum da Forja de Peças (3% / 10%)
			drop(_common_mat(), e.position, 1, Vector2.from_angle(rng.randf() * TAU) * 140.0)
	var n: int = 1 + (circle - 1) / 2 if e.cortejo else 1 + mausoleum / 5 + (e.tier + 1) / 2 + ((circle - 1) / 2 if e.wild or e.camp >= 0 else 0)  # Círculos: os mortos do Cortejo deixam mais de cada vez; no Mausoléu (#27), +1 a cada 5 pisos; no mundo aberto, com a distância e o Círculo
	if e.is_boss:
		for k in ["bone", "bone", "ink", "ash"]:
			drop(k, e.position, n, Vector2.from_angle(rng.randf() * TAU) * 160.0)
	else:
		graves.append([e.position, time + 5.0])  # Alma Gatilho: o abate fica 5 s à espera de ser gasto
		if graves.size() > 3:
			graves.pop_front()
		var r := rng.randf()
		if e.elite:  # sempre 2 Ossos e 1 Tinteiro, e uma Cinza 1 vez em 4
			drop("bone", e.position, 2 * n)
			drop("ink", e.position, n)
			if r < 0.25:
				drop("ash", e.position, n)
		elif r < 0.04:
			drop("ash", e.position, n)
		elif r < 0.10:
			drop("ink", e.position, n)
		elif r < 0.38:
			drop("bone", e.position, n)
	if last:  # S13 (Lote 9): de um grupo, só o último larga equipamento
		_drop_gear(e, named)  # Equipamento (0.4.8): named é o de main:1841
	if e.cortejo and cortejo.active and not e.is_boss and "rebeldes" in cortejo.affixes and rng.randf() < 0.2:
		# Almas Rebeldes (#196): volta como um fantasma veloz que rebenta ao tocar num herói ou ao fim de 4 s (fora da conta da onda)
		var r = spawn_enemy("specter", e.position, {"hp": e.mods.get("hp", 1.0) * 0.5, "speed": e.mods.get("speed", 1.0) * 1.6, "dmg": e.mods.get("dmg", 1.0)}, false)
		r.paint = Color(0.6, 0.8, 1.0)
		r.title = "Alma Rebelde"
		r.expire_at = time + 4.0
	if e.camp >= 0 and camp_left.has(e.camp):
		_camp_kill(e)
	if e.ev == 1 and not event.is_empty():  # S9: um dos mortos do evento
		event.alive -= 1
		if e.boss == "carruagem":  # Carruagem Fúnebre (#48): parada e partida, o relicário fica onde ela caiu (e 1 em 4 um Coração de Titã)
			event.pos = e.position
			_event_chest(2.0, 0.25)
			hud.toast("A carruagem fúnebre caiu: o relicário é teu!")
			for o in enemies():  # as escoltas que ficam são mortos como os outros: contavam no evento seguinte
				o.ev = 0
			event = {}
		elif event.id == "meteoro" and e.elite and chest != null and chest.locked and not enemies().any(func(o): return o.ev == 1 and o.elite):
			chest.locked = false  # Meteoro Funerário (#218): sem elites na cratera, o relicário abre-se
			spawn_fx("ring", chest.position, 140.0, Color(1.0, 0.85, 0.4))
			sfx("chest")
			hud.toast("Os elites caíram: o relicário da cratera abriu-se!")
	if e.cortejo and cortejo.active:
		cortejo.alive -= 1
		if cortejo.alive <= 0:
			_wave_cleared()


# ---------- O Arauto Fúnebre ----------

## Entrada do chefe: fecha a arena, o sino dobra duas vezes (o mundo escurece e treme),
## e só então o Arauto sobe do chão; quando acaba de subir, ruge (boss_roar).
func _boss_intro(mods: Dictionary) -> void:
	arena_r = ARENA_R
	rumble = 2.6
	sfx("bell")
	var guard := wins % 2 == 1  # Guardião dos Monumentos (#204): depois da 1.ª vitória, um Cortejo sim, outro não
	hud.toast("As estátuas acordam... o Guardião dos Monumentos ergue-se." if guard else "O sino toca... o Arauto Fúnebre aproxima-se.")
	await get_tree().create_timer(1.3, false).timeout
	if not is_inside_tree() or not cortejo.active:
		return
	sfx("bell")
	await get_tree().create_timer(1.3, false).timeout
	if not is_inside_tree() or not cortejo.active:
		return
	var h = spawn_enemy("colossus" if guard else "herald", monument_pos + Vector2(280, -60), mods, true)  # ao lado do obelisco, à vista
	h.rise_t = 1.4
	if guard:
		Bosses.make(h, "guardiao")
		raise_statues(h)
	else:  # Arauto por Círculo: do II tem 2.ª fase a meio da vida; do IV bate e invoca mais depressa e o sino chega mais longe
		if circle >= 2:
			h.rage_at = 0.5
		if circle >= 4:
			h.haste = 1.35
			h.reach = 1.3
		if circle >= 6:
			h.title = "Arauto Ascendido"
	spawn_fx("dust", h.position, 140.0, Color.WHITE)
	focus_pos = h.position + Vector2(0, -40)
	focus_t = 3.2


func boss_roar(e) -> void:
	hitstop(0.08)
	shake = 18.0
	vibrate(350, 1.0)
	zoom_kick = maxf(zoom_kick, 0.06)
	sfx("roar")
	sfx("bell")
	spawn_fx("ring", e.position, 320.0, Color(0.4, 1.0, 0.6))
	spawn_fx("dust", e.position, 120.0, Color.WHITE)
	if e.style != "amalgama" or e.boss == Bosses.PHASES[0]:  # a Amálgama (#220), a mudar de pele, já tem o cartão dela
		hud.name_card(Bosses.BOOK[e.trio][0] if e.trio != "" else e.who(), Bosses.INFO[e.boss][1] if e.boss != "" else "Mensageiro do Cortejo Fúnebre")  # um grupo, com o nome da barra dele
	e.bar_fill = 0.0
	meet(e)


## 2.ª fase do Arauto (Círculo II em diante): o sino racha, ele fica vermelho e chama dois Coveiros.
func herald_rage(e) -> void:
	sfx("bell")
	shake = maxf(shake, 14.0)
	spawn_fx("ring", e.position, 260.0, Color(1.0, 0.3, 0.25))
	hud.toast("O sino racha! O Arauto chama os Coveiros.")
	for i in 2:
		var c = spawn_enemy("colossus", e.position + Vector2(-160 + 320 * i, 60), e.mods, e.cortejo)
		c.title = "Coveiro"
		spawn_fx("dust", c.position, 70.0, Color.WHITE)
		if e.cortejo and cortejo.active:
			cortejo.alive += 1


## Sino no chão: dano em área a quem estiver perto.
func boss_slam(pos: Vector2, r: float, dmg: float, by := "", src = null, sound := "bell") -> void:
	for p in players:
		if not p.dead and p.position.distance_to(pos) < r:
			if p.soul == "donzela" and p.iron_cd <= 0.0 and p.dash_t <= 0.0:  # Donzela de Ferro Móvel (#174): o golpe que apanha vira o herói em couraça (a esquivar não gasta a recarga)
				p.iron_cd = 25.0
				p.iron_t = 1.5
				number(p.position + Vector2(0, -120), tr("Donzela de Ferro!"), 20.0, Color(0.7, 0.76, 0.85))
				spawn_fx("ring", p.position, 80.0, Color(0.7, 0.76, 0.85))
			p.take_damage(dmg * (0.1 if p.iron_t > 0.0 else 1.0), by, src)
	spawn_fx("ring", pos, r, Color(0.4, 1.0, 0.6))
	spawn_fx("dust", pos, 90.0, Color.WHITE)
	shake = maxf(shake, 11.0)
	sfx(sound)
	_area_hit(pos, r)


## As 4 Estátuas Funerárias do Guardião dos Monumentos (#204), presas ao chão à volta do monumento, com 300 de vida (x a
## do Cortejo): enquanto houver uma de pé ele não leva dano. Fora do Cortejo: não contam para acabar a onda.
## Nos Sepulcros, à volta do meio da sala (nunca de g.position: uma estátua na parede deixava-o imune para sempre) e com 80 de vida.
func raise_statues(g) -> void:
	var at: Vector2 = sep.boss if zone == "sep" else monument_pos
	for off in [Vector2(320, 0), Vector2(-320, 0), Vector2(0, 260), Vector2(0, -260)]:
		var s = spawn_enemy("colossus", at + off, {"hp": (80.0 if zone == "sep" else 300.0) / Enemy.STATS.colossus[0] * g.mods.get("hp", 1.0), "dmg": g.mods.get("dmg", 1.0)}, false)
		s.anchor = true
		s.grow(0.5)
		s.paint = Enemy.STONE
		s.title = "Estátua Funerária"
		spawn_fx("dust", s.position, 80.0, Color(0.8, 0.8, 0.75))


## Sineiros (#206): o sino tocou sem ninguém o calar a tempo: chega um colosso com a força da onda, que conta para a acabar.
func ring_bell(e) -> void:
	sfx("bell")
	spawn_fx("ring", e.position, 260.0, Color(1.0, 0.82, 0.3))
	if zone == "sep" and enemies().size() >= SEP_CAP:
		return
	var c = spawn_enemy("colossus", e.position + Vector2(0, -60), e.mods, true)
	c.title = "Reforço"
	spawn_fx("dust", c.position, 90.0, Color.WHITE)
	if cortejo.active:
		cortejo.alive += 1


func summon_minions(e, n: int, kind := "skeleton") -> void:
	for i in n:
		if zone == "sep" and enemies().size() >= SEP_CAP:
			return
		var pos: Vector2 = e.position + Vector2.from_angle(TAU * i / n + 0.4) * 110.0
		_wear(spawn_enemy(kind, pos, e.mods, e.cortejo))
		if fx_budget("pfx_rise_s", 4, 12):  # o círculo do pixelfx abre-se e estoira aos pés de cada um
			spawn_fx("pfx_rise_s", pos, 1.0, Color.WHITE)
		else:
			spawn_fx("dust", pos, 40.0, Color.WHITE)
		if e.cortejo and cortejo.active:
			cortejo.alive += 1


# ---------- Liga "Cortejo Fúnebre" ----------

func near_monument() -> bool:
	for p in players:
		if not cortejo.active and not mode_on() and not p.dead and p.position.distance_to(monument_pos) < 130.0:
			return true
	return false


func near_chest() -> bool:
	if chest == null or chest.opening >= 0.0 or chest.locked:  # o selado do Meteoro (#218) não tira a esquiva a meio da luta
		return false
	for p in players:
		if not p.dead and p.position.distance_to(chest.position) < 110.0:
			return true
	return false


func interact(who = null) -> void:
	if Net.is_guest():
		Net.tap(0)
		return
	for p in players:
		var e = soul_target(p)
		if e != null:
			soul_strike(e, p)
			return
	var door := near_door(who)
	var gi := near_gate(who)
	if near_chest():
		chest.open()
	elif gi >= 0:  # S10: o recipiente do Cofre (#32) e as portas de carcaças (#191); paga quem carregou
		use_gate(gi, who if who != null else nearest_player(sep.gates[gi][3]))
	elif door == "down":
		enter_crypt()
	elif door == "up":
		leave_crypt()
	elif door == "gate":
		if hud.panel == null:
			hud.open_gate()
	elif door == "sep_down":
		sep_descend()
	elif door == "sep_up":
		sep_leave()
	elif near_monument() and hud.panel == null:  # a mesma ordem da dica do HUD (em co-op cada herói pode estar ao pé de um)
		hud.open_cortejo()
	elif near_altar():
		wake_titan()


## Execução Espectral (#12) ou extração da Alma Ancestral (#16): o inimigo ao alcance de p (ou null).
func soul_target(p):
	if p.dead:
		return null
	for e in enemies():
		if (e.executable(p) or e.extractable()) and p.position.distance_to(e.position) < e.radius + 120.0:
			return e
	return null


func soul_strike(e, p) -> void:
	hitstop(0.14)
	hud.flash(0.3)
	shake = maxf(shake, 14.0)
	zoom_kick = maxf(zoom_kick, 0.08)
	vibrate(70, 0.8, p)
	var mid: Vector2 = e.position + Vector2(0, e._top() * 0.5)
	if e.extractable():  # a Alma Ancestral sai do peito do chefe quebrado
		e.extracted = true
		currency.bone += 3
		p.add_mana(30.0)
		number(mid + Vector2(0, -30), tr("Alma extraída! +3 Ossos"), 22.0, Color(0.6, 1.0, 0.75))
		spawn_fx("ring", e.position, e.radius * 3.0, Color(0.4, 1.0, 0.6))
		spawn_fx("glow", mid, 120.0, Color(0.5, 1.0, 0.7))
		e.take_damage(e.max_hp * 0.06, true, p.position.direction_to(e.position), true)
		sfx("chest")
		return
	number(mid + Vector2(0, -30), tr("Executado!"), 26.0, Color(0.75, 1.0, 0.95))
	spawn_fx("ring", e.position, 110.0, Color(0.75, 1.0, 0.95))
	spawn_fx("glow", mid, 90.0, Color(0.75, 1.0, 0.95))
	e.hit_by = p  # a execução é de quem executa (a Alma Mártir de outro herói não ganha a esquiva com ela)
	e.hit_support = ""
	e.take_damage(e.hp + 1.0, true, p.position.direction_to(e.position), true)
	p.add_mana(15.0)
	p.heal(p.max_hp * 0.05)
	sfx("crit")


## Cólera Póstuma (#17): o esqueleto erguido desfaz-se num miasma que cega quem está perto e cura o dono.
## Canibalismo Espiritual (#122): com a chave, o dono come-o em vez disso: +10% da vida e +8% de dano (até 5 camadas).
func miasma(pos: Vector2, by) -> void:
	if is_instance_valid(by) and not by.dead and by.stat("canibal") > 0.0:
		by.heal(by.max_hp * 0.1)
		by.canibal_n = mini(5, by.canibal_n + 1)
		spawn_fx("glow", by.position + Vector2(0, -40), 55.0, Color(0.4, 1.0, 0.65))  # o verde dos lacaios
		return
	for e in enemies():
		if e.position.distance_to(pos) < 130.0 + e.radius:
			e.blind_t = 2.5
	spawn_fx("ring", pos, 130.0, Color(0.45, 0.3, 0.5))
	spawn_fx("dust", pos, 90.0, Color(0.5, 0.4, 0.55))
	if is_instance_valid(by) and not by.dead:
		by.heal(by.max_hp * 0.06)


## Sangue no Solo (#23): em cima de uma poça de sangue, heróis e lacaios andam +25%; numa teia de tendões (#36), a metade.
func blood_speed(pos: Vector2) -> float:
	var k := 0.5 if web_at(pos) >= 0 else 1.0
	for pool in blood:
		if pos.distance_squared_to(pool[0]) < BLOOD_R * BLOOD_R:
			return 1.25 * k
	return k


## Covil do Tecelão (#36): a teia onde pos está (-1 fora de todas). Os monstros não a sentem.
func web_at(pos: Vector2) -> int:
	for i in webs.size():
		if pos.distance_squared_to(webs[i][0]) < WEB_R * WEB_R:
			return i
	return -1


## S11: há uma poça deste tipo em pos? (a névoa do Bispo, #183, não deixa curar)
func pool_at(pos: Vector2, kind: String) -> bool:
	return pools.any(func(q): return q[3] == kind and pos.distance_squared_to(q[0]) < q[1] * q[1])


## S11: uma poça nova (a mais velha sai ao passar das 12). O ácido da Matriarca (#40) e a névoa do Bispo (#183) secam; o
## piche (#166) fica até arder.
func add_pool(at: Vector2, kind: String) -> void:
	pools.append([at, POOL_R[kind], tick16(time + (8.0 if kind == "acido" else 6.0)) if kind != "piche" else INF, kind])
	pools = pools.slice(maxi(0, pools.size() - POOL_N))


## As horas das poças e dos buracos aos 1/16 de segundo: cabem em 4 bytes na rede (com as 12 poças e as 10 teias a mudar no
## mesmo frame o pacote rápido ficava perto dos 1100).
static func tick16(t: float) -> float:
	return snappedf(t, 0.0625)


## Piche Funerário (#166): a poça de piche i pega fogo; as outras a 140 px pegam 0,4 s depois (em cadeia, _ground_tick).
func ignite(i: int) -> void:
	var q: Array = pools[i]
	q[3] = "fogo"
	q[2] = tick16(time + POOL_FIRE)
	for o in pools:
		if o[3] == "piche" and o[0].distance_to(q[0]) < 140.0:
			o[2] = minf(o[2], tick16(time + 0.4))
	if fx_budget("explosion", 2, 4):
		spawn_fx("explosion", q[0], 0.8, Color(1.0, 0.55, 0.2), Vector2.RIGHT, "loot_ash")
	else:
		spawn_fx("ring", q[0], q[1], Color(1.0, 0.55, 0.2))
	sfx("hit", 0.6)


## Covil do Tecelão (#36): o golpe que chega a uma teia corta-lhe um dos 3 tendões (dir ZERO: um círculo); sem nenhum, sai.
func _cut_webs(origin: Vector2, radius: float, dir: Vector2) -> void:
	for i in range(webs.size() - 1, -1, -1):
		var v: Vector2 = webs[i][0] - origin
		if v.length() <= radius + WEB_R and (dir == Vector2.ZERO or v.length() < WEB_R + 40.0 or absf(dir.angle_to(v)) < 1.3):
			webs[i][1] -= 1
			spawn_fx("sparks", webs[i][0] + Vector2(0, -10), 0.0, Color(0.85, 0.3, 0.3), dir if dir != Vector2.ZERO else Vector2.UP)
			if webs[i][1] <= 0:
				spawn_fx("dust", webs[i][0], 60.0, Color(0.8, 0.5, 0.5))
				webs.remove_at(i)


## Explosão de Cadáveres (#9): rebenta com 40% da vida de quem morreu e, antes do golpe, passa o estado dele a quem
## estiver perto (podridão, 3 camadas de necrose ou 3 de calcificação): quem morrer da explosão herda-o.
func burst_corpse(c: Array) -> void:
	corpses.erase(c)
	var by = nearest_player(c[0])
	if by == null:
		return
	var col: Color = CORPSE_COLORS[c[1]]
	if fx_budget("explosion", 2, 4):  # rebenta em terra e pedras de osso, com o fumo e os anéis da cor do estado
		spawn_fx("explosion", c[0], 0.7, col, Vector2.RIGHT, ["ash", "rot", "necro", "bone"][c[1]])
	else:
		spawn_fx("burst", c[0], 0.0, col)
		spawn_fx("ring", c[0], CORPSE_R, col)
		spawn_fx("dust", c[0], 50.0, col)
	for e in enemies():
		if e.position.distance_to(c[0]) > CORPSE_R + e.radius:
			continue
		match c[1]:
			1:
				e.apply_rot(c[3] * 0.3)
			2:
				for k in 3:
					e.add_necro()
			3:
				for k in 3:
					e.add_calc()
	var raising = raise_by  # a explosão é do cadáver, não do golpe que a acordou: não ergue lacaios nem leva a Alma Caótica
	var aff := cast_aff
	var sup := cast_support  # nem leva o frasco dele (o herói mais perto do cadáver pode ser outro)
	raise_by = null
	cast_aff = 0
	cast_support = ""
	hit_circle(c[0], CORPSE_R, c[3], by)
	raise_by = raising
	cast_aff = aff
	cast_support = sup


## Espasmo Cadavérico (#115): um golpe que passa por cima de um cadáver com mais de meio segundo rebenta-o
## (a explosão também é um golpe: rebenta os que estiverem perto, em cadeia).
func _strike_corpses(origin: Vector2, radius: float) -> void:
	for c in corpses.duplicate():
		if c in corpses and origin.distance_to(c[0]) <= radius and c[2] - time < CORPSE_T - 0.5:
			burst_corpse(c)


## Alma Gatilho: o abate ainda por gastar mais perto de pos (até 300 px), ou [] se não houver; os de mais de 5 s saem.
func grave_near(pos: Vector2) -> Array:
	while not graves.is_empty() and graves[0][1] <= time:  # entram por ordem e todos duram 5 s: o mais antigo sai primeiro
		graves.pop_front()
	var best := []
	var best_d := 300.0
	for g in graves:
		var d: float = pos.distance_to(g[0])
		if d < best_d:
			best_d = d
			best = g
	return best


## Nível de área do mundo aberto (#27): o do Círculo e mais 2 a cada 800 px da praça (+1 de 2 em 2 Círculos: no V, 4). No Círculo I, perto da praça: nível 1, como antes.
func wild_tier(pos: Vector2) -> int:
	return int(pos.distance_to(monument_pos) / WILD_STEP)


func wild_level(pos: Vector2) -> int:
	return circle_level() + (2 + (circle - 1) / 2) * wild_tier(pos)


func spawn_wild(kind: String, at: Vector2):
	var e = spawn_enemy(kind, at, lvl_mods(wild_level(at)), false)
	e.wild = true
	e.tier = wild_tier(at)
	_wear(e)
	e.paint = wild_paint(region_at(at), e.tier, e.skin != "")
	return e


## 0.4.7: a pele de um esqueleto que nasceu sozinho: a da zona ou, no Cortejo, depois da 1.ª vitória, metade com uma das 4 ao calhas. Só muda o desenho e o nome. O dado é o global: main.rng fica como estava. spawn_enemy não veste: os testes querem o de sempre, e na cripta e nos modos ficam os de sempre.
func _wear(e) -> void:
	if e.kind != "skeleton":
		return
	if zone == "sep":
		e.skin = sep_kind(sep_depth()).skin
	elif e.cortejo:
		if wins >= 1 and randf() < 0.5:
			e.skin = WEAR[randi() % WEAR.size()]
	elif zone == "world" and not mode_on():
		e.skin = REGIONS[region_at(e.position)].skin


## A cor da região, a avermelhar com a distância: é assim que se lê o perigo (os monstros não mostram o nível). Quem tem pele tem as suas cores: fica só o avermelhar.
func wild_paint(region: String, tier: int, skinned := false) -> Color:
	return (Color.WHITE if skinned else REGIONS[region].paint).lerp(Color(1.0, 0.5, 0.4), tier * 0.12)


## Quem ficou para trás não gasta o limite de monstros (os chefes, os gigantes, os eventos e os dos testes não têm wild).
## Os bandos a dormir saem mais cedo: camp_left trá-los de volta como estavam.
func _wild_tick() -> void:
	_gather_loot(WILD_FAR)  # o saque esquecido custa em cada frame (e vai ao convidado a cada frame): vem ter connosco, como ao mudar de zona
	var chased: Array = enemies().filter(func(o): return o.camp >= 0 and o.awake).map(func(o): return o.camp)
	for e in enemies():
		if e.camp in chased and not e.awake:
			continue  # quem dorme espera por quem anda atrás do herói: senão o acampamento ficava vazio até esse morrer
		if e.wild or e.camp >= 0:
			var asleep: bool = e.camp >= 0 and not e.awake
			var far: float = CAMP_WAKE + 300.0 if asleep else WILD_FAR
			var at: Vector2 = camps[e.camp].pos if asleep else e.position  # quem dorme sai com o bando inteiro: parte dele saía, e o resto nascia à vista ao matar os que ficaram
			if players.all(func(q): return q.position.distance_squared_to(at) > far * far):
				e.queue_free()


## Os bandos só existem perto dos heróis: nascem a dormir (aggro 520, como na cripta) e, por acabar, voltam como ficaram.
func _camps_tick() -> void:
	if zone != "world" or cortejo.wave > 0 or arena_r > 0.0 or mode_on():
		return
	for i in camps.size():
		if i in camps_done:
			continue
		var at: Vector2 = camps[i].pos
		if players.any(func(q): return not q.dead and q.position.distance_to(at) < CAMP_WAKE) and not enemies().any(func(o): return o.camp == i):
			_camp_spawn(i)


func _camp_spawn(i: int) -> void:
	var c: Dictionary = camps[i]
	var reg: Dictionary = REGIONS[c.region]
	var mods := lvl_mods(wild_level(c.pos) + 1)
	if not camp_left.has(i):
		camp_left[i] = [CAMP_PACK, true]
	var left: Array = camp_left[i]
	for k in left[0] + (1 if left[1] else 0):
		var boss: bool = left[1] and k == 0
		var at: Vector2 = c.pos if boss else c.pos + Vector2.from_angle(TAU * k / 7.0 + 0.4) * rng.randf_range(90.0, 170.0)
		var e = spawn_enemy("skeleton" if boss or rng.randf() >= reg.spec else "specter", at, mods, false)
		e.aggro = 520.0
		e.camp = i
		e.tier = wild_tier(c.pos)
		if e.kind == "skeleton":  # o bando e o elite com o nome dele: a pele da região do acampamento, mesmo no que nasce do outro lado da fronteira
			e.skin = reg.skin
		e.paint = wild_paint(c.region, e.tier, e.skin != "")
		if boss:
			e.make_elite()
			e.title = reg.camp


## Um morto do acampamento: o último dá o saque, uma vez. Vai logo para o grupo: camps_done fica gravado e o saque do chão não.
func _camp_kill(e) -> void:
	var left: Array = camp_left[e.camp]
	if e.elite:
		left[1] = false
	else:
		left[0] -= 1
	if left[0] > 0 or left[1]:
		return
	camps_done.append(e.camp)
	var a: int = wild_level(camps[e.camp].pos) + 1
	for r in [["bone", int(5 * loot_mult(a))], ["ink", 1 + a / 4], ["ash", a / 6]]:
		if r[1] > 0:
			collect(drop(r[0], e.position, r[1]))
	if rng.randf() < 0.2:
		collect(drop(_reagent(), e.position))
	spawn_fx("pillar", e.position, 0.0, Color(1.0, 0.85, 0.4), Vector2.RIGHT, "gold")
	sfx("chest")
	hud.toast("Acampamento limpo: o saque é teu!")
	save_game()


## Cemitério dos Gigantes (#39): do Círculo III em diante andam no cemitério 2 Gigantes Errantes (3 do V em diante),
## colossos maiores e cor de terra que andam à toa até um herói chegar perto. Nascem a mais de 1100 px do grupo, um
## por vez; quem cai só volta 20 s depois.
func _giants() -> void:
	var cap := 0 if circle_max < 3 else 3 if circle_max >= 5 else 2
	if time < giant_at or enemies().filter(func(e): return e.title == "Gigante Errante").size() >= cap:
		return
	for i in 30:
		var at := Vector2(rng.randf_range(MAP.position.x + 200, MAP.end.x - 200), rng.randf_range(MAP.position.y + 200, MAP.end.y - 200))
		if players.all(func(q): return q.position.distance_to(at) > 1100.0):
			var g = spawn_enemy("colossus", at, lvl_mods(1 + 4 * (circle_max - 1)), false)
			g.grow(1.2)
			g.paint = Color(0.85, 0.8, 0.7)
			g.aggro = 600.0
			g.title = "Gigante Errante"
			g.wander = Vector2.ZERO
			return


## O altar do cemitério aceita um Coração de Titã (#70): fora do Cortejo e dos eventos (S9: o relicário do Titã tirava o
## lugar ao selado do Meteoro), sem outro Titã acordado e com um herói perto.
func near_altar() -> bool:
	if zone != "world" or cortejo.wave > 0 or mode_on() or not event.is_empty() or currency.get("coracao", 0) < 1 or enemies().any(func(e): return e.boss == "tita"):
		return false
	return players.any(func(p): return not p.dead and p.position.distance_to(SHRINE) < 130.0)


## Coração de Titã Petrificado (#70): oferecido no altar, ergue ao lado dele o Titã Petrificado (4 níveis acima do grupo,
## com 2,5 vezes a vida), que ruge ao acabar de subir (boss_roar).
func wake_titan() -> void:
	currency.coracao -= 1
	var ti = spawn_enemy("colossus", SHRINE + Vector2(0, 170), lvl_mods(level + 4), false)
	Bosses.make(ti, "tita")
	ti.rise_t = 1.4
	spawn_fx("dust", ti.position, 140.0, Color.WHITE)
	sfx("bell", 0.5)
	shake = maxf(shake, 10.0)
	focus_pos = ti.position + Vector2(0, -60)
	focus_t = 2.0
	hud.toast("Ofereceste o Coração de Titã: o altar treme...")


## Boneco de treino (#287): ao lado do monumento, sempre que se está no cemitério.
func _spawn_dummy() -> void:
	var d = spawn_enemy("skeleton", monument_pos + DUMMY_AT, {}, false)
	d.dummy = true
	d.title = "Boneco de treino"


# ---------- Cripta dos Condenados ----------

## "down" e "up": as escadas e a porta do fundo da cripta. "gate": o Portão dos Reis. "sep_up", "sep_down": as saídas dos Sepulcros (as do chefe só depois de ele cair).
## who: nos Sepulcros, só conta quem carregou. Sem isto o toque do convidado em "Descer" podia subir (a ordem de players é outra no anfitrião), e a esquiva de um herói tirava o grupo de lá quando o outro passava por uma saída. Fora dos Sepulcros não conta: a cripta e o cemitério ficam como hoje.
func near_door(who = null) -> String:
	if zone == "sep":
		if sep.is_empty():
			return ""
		for p in ([who] if who != null else players):
			var door := ""
			if not p.dead:
				if p.position.distance_to(sep.exit) < SEP_DOOR_R or (sep_done == 1 and p.position.distance_to(sep.up) < SEP_DOOR_R):
					door = "sep_up"
				elif sep_done == 1 and p.position.distance_to(sep.down) < SEP_DOOR_R:
					door = "sep_down"
			if door != "" and sep_calm(p):  # a meio de uma luta o botão é a esquiva
				return door
		return ""
	var at := CRYPT_DOOR if zone == "world" else CRYPT_ORIGIN + CRYPT_OUT
	for p in players:
		if not p.dead:
			if p.position.distance_to(at) < 130.0:
				return "down" if zone == "world" else "up"
			if zone == "world" and wins >= 1 and not map_busy and p.position.distance_to(GATE) < 170.0:
				return "gate"
	return ""


## Para onde aponta a seta do HUD: o túmulo por recuperar vem primeiro, depois o evento do cemitério (S9); depois da 1.ª
## vitória, o Portão até à 1.ª descida, e depois o acampamento por limpar mais perto; limpos todos (ou no Cortejo), o monumento.
func objective() -> Vector2:
	if zone == "sep":
		return _sep_goal()
	if zone == "crypt":
		return guardian.position if is_instance_valid(guardian) else CRYPT_ORIGIN + CRYPT_OUT
	if not tomb.is_empty():
		return tomb.pos
	if not event.is_empty():
		return event.pos
	var best := monument_pos
	if cortejo.wave > 0 or mode_on() or wins == 0:
		return best
	if sep_runs == 0:
		return GATE
	var near := INF
	for i in camps.size():
		var d: float = player.position.distance_squared_to(camps[i].pos)
		if d < near and not i in camps_done:
			near = d
			best = camps[i].pos
	return best


## Paredes da cripta e dos Sepulcros: o passo só vale se ficar no chão; senão desliza ao longo da parede ou fica parado.
func walk(from: Vector2, to: Vector2) -> Vector2:
	if zone == "world" or on_floor(to) or (zone == "sep" and not on_floor(from)):  # nos Sepulcros, quem nasceu ou foi puxado para dentro da parede sai a andar (invocações main:1982 e main:2032, limite do co-op main:795)
		return to
	for p in [Vector2(to.x, from.y), Vector2(from.x, to.y)]:
		if on_floor(p):
			return p
	return from


## É chão? Na cripta o polígono de sempre; nos Sepulcros, a grelha sem as portas fechadas (S10).
func on_floor(p: Vector2) -> bool:
	if zone == "sep":
		var b := _sep_byte(p)
		return b > 0 and (b != SEP_LINK or not _gate_shut(p)) and (holes.is_empty() or not _in_hole(p))  # as faixas das portas são casas de corredor: nas salas não há que ver; e os buracos abertos do Poço (S12)
	return Geometry2D.is_point_in_polygon(p, crypt_floor)


## S12: p está num buraco aberto do Poço da Danação (#49)? As lajes rachadas e as que ainda avisam são chão.
func _in_hole(p: Vector2) -> bool:
	for h in holes:
		if h[2] > 0.0 and time >= h[2] and time < h[3] and p.distance_squared_to(h[0]) < h[1] * h[1]:
			return true
	return false


## S10: p está numa porta fechada? O on_floor corre em cada passo de cada monstro: primeiro a faixa (um Rect2 por corredor, do plano), e só a que tem p vê a regra dela.
func _gate_shut(p: Vector2) -> bool:
	var gs: Array = sep.get("gates", [])
	for i in gs.size():
		if gs[i][2].has_point(p) and not gate_open(i):
			return true
	return false


## A porta i está aberta? A de sangue só com o recipiente cheio (#32). As outras abrem-se todas com o chefe acordado e de
## vez com ele caído: a sala dele nunca prende ninguém. As costelas pela hora (#28: os dois telemóveis têm a mesma), as
## carcaças depois do sacrifício (#191) e os selos com a sala limpa (#219).
func gate_open(i: int) -> bool:
	var st: int = gates[i] if i < gates.size() else 0
	var kd: String = sep.gates[i][1]
	if kd == "sangue":
		return st >= 2
	if sep_done == 1 or guardian_met:
		return true
	if kd == "costela":
		return fposmod(time + i * 2.5, GATE_TICK) <= GATE_SHUT
	return st > 0 if kd == "carcaca" else st == 0


## O corredor li tem uma porta de sangue fechada? O Cofre e o corredor dele ficam fora do minimapa até abrir.
func link_hidden(li: int) -> bool:
	var gs: Array = sep.get("gates", [])
	return range(gs.size()).any(func(i): return gs[i][0] == li and gs[i][1] == "sangue" and not gate_open(i))


## S10: a porta onde who (sem who, qualquer herói de pé) pode carregar: o Recipiente de Sangue a 110 px, a Porta de
## Costelas a 130 px da faixa. Nunca com um morto acordado a 400 px (a meio de uma luta o botão é a esquiva); o chefe a
## dormir no meio da sala dele não conta (sep_calm contava, e um recipiente à porta dele ficava sem botão). -1 sem nenhuma.
func near_gate(who = null) -> int:
	if zone != "sep" or sep.is_empty():
		return -1
	for i in sep.gates.size():
		var g: Array = sep.gates[i]
		if not g[1] in ["sangue", "carcaca"] or gate_open(i):
			continue
		for q in ([who] if who != null else players):
			if not q.dead and (q.position.distance_to(g[3]) < 110.0 if g[1] == "sangue" else g[2].grow(130.0).has_point(q.position)) and not enemies().any(func(e): return e.awake and not e.anchor and e.position.distance_to(q.position) < 400.0):  # a distância primeiro: corre a cada frame
				return i
	return -1


## Quem carregou paga a parte dele: 15% da vida no recipiente (2 vezes enchem-no; a dois, cada um a sua) ou, na Porta de
## Costelas, o lacaio dele mais perto (até 300 px) ou 20% da vida. pay_life nunca mata.
func use_gate(i: int, q) -> void:
	var g: Array = sep.gates[i]
	var mid: Vector2 = g[2].get_center()
	if g[1] == "sangue":
		q.pay_life(q.max_hp * 0.15)
		gates[i] = mini(gates[i] + 1, 2)
		spawn_fx("glow", g[3] + Vector2(0, -24), 60.0, Color(0.9, 0.15, 0.1))
		sfx("hurt")
		if gates[i] >= 2:
			spawn_fx("ring", mid, 140.0, Color(0.9, 0.15, 0.1))
			sfx("chest")
			hud.toast("O cofre abriu-se: pagaste com sangue.")
		return
	var lacaio = null
	for a in get_tree().get_nodes_in_group("allies"):
		if a.owner_p == q and a.life > 0.0 and a.position.distance_to(q.position) < 300.0 and (lacaio == null or q.position.distance_squared_to(a.position) < q.position.distance_squared_to(lacaio.position)):
			lacaio = a
	if lacaio != null:
		lacaio.life = 0.0
		spawn_fx("sparks", lacaio.position, 0.0, Color(0.95, 0.9, 0.8), lacaio.position.direction_to(mid))
	else:
		q.pay_life(q.max_hp * 0.2)
		sfx("hurt")
	gates[i] = 1
	spawn_fx("ring", mid, 130.0, Color(0.95, 0.9, 0.8))
	spawn_fx("dust", mid, 90.0, Color(0.9, 0.86, 0.78))
	sfx("creak")


## S10, no anfitrião, a cada frame: as costelas avisam (pó) e esmagam quem apanham a fechar (#28).
func _gates_tick() -> void:
	if zone != "sep" or sep.is_empty():
		return
	var gs: Array = sep.gates
	if gate_was.size() != gs.size():
		gate_was = gs.map(func(_g): return 0)
	for i in gs.size():
		if gs[i][1] != "costela":
			continue
		var stage: int = 2 if not gate_open(i) else 1 if fposmod(time + i * 2.5, GATE_TICK) > GATE_WARN and sep_done == 0 and not guardian_met else 0
		if stage == gate_was[i]:
			continue
		gate_was[i] = stage
		if stage == 2:
			_crush(gs[i])
		elif stage == 1 and _view_rect().grow(200.0).intersects(gs[i][2]):
			spawn_fx("dust", gs[i][2].get_center(), 90.0, Color(0.9, 0.86, 0.78))
			sfx("creak", 0.8)


## As costelas fecham: quem está na faixa leva 20% (heróis), 30% (monstros) ou 6% (chefes), a esquiva safa (_trap), e sai
## empurrado para o lado mais perto, 40 px para lá da faixa. Um herói caído lá dentro vai para o companheiro.
func _crush(g: Array) -> void:
	var band: Rect2 = g[2]
	var ax: Vector2 = g[4]
	var mid := band.get_center()
	var half: float = band.size.dot(ax) / 2.0
	var hit := false
	for c in players + enemies():
		if not band.has_point(c.position) or (not c in players and c.anchor):
			continue
		if c in players and c.dead:
			var mate = players.filter(func(o): return o != c and not o.dead)
			if not mate.is_empty():
				c.position = mate[0].position
			continue
		if c in players:
			c.take_damage(c.max_hp * 0.2, "Costelas")
		else:
			c.take_damage(c.max_hp * (0.06 if c.is_boss else 0.3), true, ax)
		var s: float = (c.position - mid).dot(ax)
		c.position += ax * ((half + 40.0) * (1.0 if s >= 0.0 else -1.0) - s)
		hit = true
	spawn_fx("dust", mid, 110.0, Color(0.9, 0.86, 0.78))
	if hit:
		shake = maxf(shake, 10.0)
		sfx("swing_heavy")


## Lote 7, no anfitrião, a cada frame. S11: as poças secam e o piche à espera pega fogo (em cadeia, ignite); de meio em meio
## segundo cada poça fere quem lá está (_pool_hit). S12: as lajes e os buracos do Poço da Danação (#49).
func _ground_tick(delta: float) -> void:
	if not pools.is_empty():
		for i in range(pools.size() - 1, -1, -1):
			if i >= pools.size() or pools[i][2] > time:
				continue
			if pools[i][3] == "piche":
				ignite(i)
			else:
				pools.remove_at(i)
		pool_t -= delta
		if pool_t <= 0.0:
			pool_t = 0.5
			_pool_hit()
	if zone == "sep" and (not holes.is_empty() or crypt_rule == "poco"):
		_holes_tick(delta)


## S11: o meio segundo das poças, pelo caminho das armadilhas (_trap: sem quem bata, nem Pacto nem Falange; a esquiva safa).
## Ácido (#40) 4% e névoa (#183) 3% aos heróis; o fogo do piche (#166) 1,5% aos heróis, 3% aos monstros e 0,5% aos chefes.
func _pool_hit() -> void:
	for q in pools:
		var share: float = POOL_HIT.get(q[3], 0.0)
		if share <= 0.0:
			continue
		for p in players:
			if not p.dead and p.position.distance_to(q[0]) < q[1]:
				p.take_damage(p.max_hp * share, {"acido": "Ácido", "nevoa": "Névoa cáustica", "fogo": "Piche em chamas"}[q[3]])
		if q[3] == "fogo":
			for e in enemies():
				if not e.dummy and e.position.distance_to(q[0]) < q[1] + e.radius:
					e.take_damage(e.max_hp * (0.005 if e.is_boss else 0.03), false)


## S12, Poço da Danação (#49): quem pisa uma laje rachada 0,8 s racha-a (avisa 0,6 s e abre 12 s); quem lá estiver ao abrir
## cai. O sítio seguro de cada herói (fora de lajes e buracos) segue-o. Com o chefe a meio da vida abrem 4 buracos de
## 90 px nos cantos da sala dele até ao fim da luta (as plataformas instáveis), nunca debaixo dele.
func _holes_tick(delta: float) -> void:
	for p in players:
		if not p.dead and sep_room_at(p.position) >= 0 and holes.all(func(h): return p.position.distance_to(h[0]) > h[1] + 20.0):
			p.safe = p.position
	for i in range(holes.size() - 1, -1, -1):
		var h: Array = holes[i]
		if h[2] == 0.0:  # a laje rachada: conta o tempo de quem está em cima
			var on: bool = players.any(func(p): return not p.dead and p.position.distance_to(h[0]) < h[1])
			var t: float = cracks.get(h[0], 0.0) + delta if on else 0.0
			cracks[h[0]] = t
			if t >= 0.8:
				h[2] = tick16(time + HOLE_WARN)
				h[3] = h[2] + HOLE_T
				spawn_fx("dust", h[0], 70.0, Color(0.6, 0.56, 0.5))
				sfx("creak", 0.7)
		elif time >= h[3]:
			holes.remove_at(i)
		elif time >= h[2] and time - delta < h[2]:  # abriu agora
			_hole_open(h)
	if not pit_open and crypt_rule == "poco" and is_instance_valid(guardian) and guardian_met and guardian.hp <= guardian.max_hp * 0.5:
		pit_open = true
		var room: Dictionary = sep.rooms[sep.n - 1]
		var w: Rect2 = room.world
		for s in [Vector2(-1, -1), Vector2(1, -1), Vector2(-1, 1), Vector2(1, 1)]:
			var at: Vector2 = w.get_center() + s * w.size * Vector2(0.3, 0.28)
			if at.distance_to(guardian.position) > 90.0 + guardian.radius + 30.0:
				holes.append([at, 90.0, tick16(time + HOLE_WARN), INF])
		holes = holes.slice(maxi(0, holes.size() - HOLE_N))
		hud.toast("O chão da sala abre-se!")
		sfx("roar")
	for p in players:  # quem está num buraco aberto cai: quando abre e, a meio de uma esquiva, quando ela acaba lá dentro
		if (p.dead or p.dash_t <= 0.0) and _in_hole(p.position):
			_fall(p)


## S12: o herói p cai (12% da vida, "Abismo") e volta ao pé do companheiro de pé ou ao último sítio seguro. Os buracos da sala
## do chefe abrem debaixo de quem lá está parado: aí o sítio seguro ficou lá dentro e ele vai para a beira, do lado do meio da sala.
func _fall(p) -> void:
	var mate: Array = players.filter(func(o): return o != p and not o.dead and not _in_hole(o.position))
	var back: Vector2 = mate[0].position if not mate.is_empty() else p.safe if p.safe != null else sep.start
	for h in holes:
		if h[2] > 0.0 and time >= h[2] and time < h[3] and back.distance_to(h[0]) < h[1]:
			var r: int = sep_room_at(h[0])
			back = h[0] + h[0].direction_to(sep.rooms[r].center if r >= 0 else sep.start) * (h[1] + 30.0)
			break
	if not p.dead:
		p.take_damage(p.max_hp * 0.12, "Abismo")
		number(p.position + Vector2(0, -130), tr("Caíste!"), 22.0, Color(0.7, 0.4, 1.0))
	p.position = back if not _in_hole(back) else sep.start  # nunca dentro de outro buraco: cairia outra vez no frame seguinte


## S12: o buraco h abriu (os heróis lá dentro caem no _holes_tick; a esquiva salta por cima); os lacaios desfazem-se; os
## monstros caem e morrem (plunge); os chefes e o que está preso ao chão ficam à beira.
func _hole_open(h: Array) -> void:
	spawn_fx("dust", h[0], h[1] * 1.2, Color(0.45, 0.42, 0.4))
	shake = maxf(shake, 8.0)
	sfx("swing_heavy", 0.6)
	for a in get_tree().get_nodes_in_group("allies"):
		if a.position.distance_to(h[0]) < h[1]:
			a.life = 0.0
	for e in enemies():
		if e.position.distance_to(h[0]) >= h[1]:
			continue
		if e.is_boss or e.anchor:
			e.position = h[0] + h[0].direction_to(e.position + Vector2(0.01, 0)) * (h[1] + e.radius + 6.0)
		else:
			plunge(e)


## S12: o monstro e cai num buraco aberto (empurrado, a meio de um golpe, ou lá dentro quando abriu): "Danado!" a violeta e
## morre com o abate de quem lhe bateu por último; o saque fica à beira.
func plunge(e) -> void:
	var best: Array = holes[0]
	for h in holes:
		if h[0].distance_to(e.position) - h[1] < best[0].distance_to(e.position) - best[1]:
			best = h
	number(e.position + Vector2(0, e._top() - 20.0), tr("Danado!"), 24.0, Color(0.7, 0.4, 1.0))
	e.position = best[0] + best[0].direction_to(e.position + Vector2(0.01, 0)) * (best[1] + 6.0)
	e.knock = Vector2.ZERO
	spawn_fx("dust", e.position, 40.0, Color(0.5, 0.4, 0.55))
	e.take_damage(e.hp + 1.0, false)


## S12: as lajes rachadas de uma sala de luta que acorda, nos pontos 1, 4 e 6, nenhuma a menos de 200 px de uma porta.
func _crack(id: int) -> void:
	var room: Dictionary = sep.rooms[id]
	for k in [1, 4, 6]:
		var q: Vector2 = room.spots[k]
		if [sep.exit, sep.down, sep.up].any(func(o): return o.distance_to(q) < 200.0) or sep.links.any(func(l): return id in [l.a, l.b] and l.world.grow(200.0).has_point(q)):
			continue
		holes.append([q, 70.0, 0.0, INF])
	holes = holes.slice(maxi(0, holes.size() - HOLE_N))


func _sep_byte(p: Vector2) -> int:
	var c := Vector2i(((p - SEP_ORIGIN) / SEP_CELL).floor())
	return sep_grid[c.x + c.y * SEP_SIDE] if c.x >= 0 and c.y >= 0 and c.x < SEP_SIDE and c.y < SEP_SIDE and not sep_grid.is_empty() else 0


## A sala onde p está (-1 num corredor ou na parede).
func sep_room_at(p: Vector2) -> int:
	var v := _sep_byte(p)
	return v - 1 if v > 0 and v < SEP_LINK else -1


## Salas da cripta (S6), no anfitrião: sem ar no Abismo do Miasma (#38), 2,5% da vida a cada 0,5 s; a maré de almas do
## Lago das Lamentações (#30), que volta a cada 8 s; e as armadilhas (B6): as pedras de enxofre armadas rebentam, os
## martelos da Forja batem e as serras do Moinho cortam de meio em meio segundo.
func _crypt_tick(delta: float) -> void:
	if crypt_rule == "miasma":
		choke_t = 0.5 if time < breath_end else choke_t - delta
		if choke_t <= 0.0:
			choke_t = 0.5
			for p in players:
				if not p.dead:
					p.take_damage(p.max_hp * 0.025, "Miasma")
	elif crypt_rule == "submersa" and time >= tide_next + TIDE_T:
		tide_next += TIDE_EVERY
	elif crypt_rule == "enxofre":  # Minas de Enxofre (#43): 18% aos heróis a 120 px, 25% aos monstros e 8% aos chefes
		for k in rocks.filter(func(r): return r[1] > 0.0 and r[1] <= time):
			rocks.erase(k)
			_trap(k[0], 120.0, 0.18, 0.25, 0.08, "Pedra de enxofre")
			for o in rocks:  # em cadeia: as intactas a 160 px rebentam 0,25 s depois
				if o[1] == 0.0 and o[0].distance_to(k[0]) < 160.0:
					o[1] = time + 0.25
			if fx_budget("explosion", 2, 4):
				spawn_fx("explosion", k[0], 1.2, Color(1.0, 0.85, 0.3), Vector2.RIGHT, "gold")
			else:
				spawn_fx("ring", k[0], 120.0, Color(1.0, 0.85, 0.3))
				spawn_fx("dust", k[0], 70.0, Color(0.95, 0.85, 0.5))
			shake = maxf(shake, 10.0)
			sfx("hit", 0.5)
	elif crypt_rule == "forja":  # Forja das Almas Escravas (#184): 20% aos heróis a 90 px, 30% aos monstros e 6% aos chefes
		for h in hammers:
			var left: float = h[1] - time
			if zone == "sep" and not _view_rect().grow(300.0).has_point(h[0]):  # os martelos ficam nas 3 últimas salas: sem isto a Forja tremia a câmara desde a 1.ª, com nada à vista
				if left <= 0.0:
					h[1] = time + rng.randf_range(4.0, 6.0)
				continue
			if left <= Fx.SLAM and left + delta > Fx.SLAM and fx_budget("pillar", 2, 4):  # a coluna cai e chega ao chão com o martelo
				spawn_fx("pillar", h[0], 0.0, Color(0.7, 0.72, 0.8), Vector2.RIGHT, "iron")
			if left <= 0.0:
				h[1] = time + rng.randf_range(4.0, 6.0)
				_trap(h[0], 90.0, 0.2, 0.3, 0.06, "Martelo da Forja")
				spawn_fx("ring", h[0], 90.0, Color(0.7, 0.72, 0.8))
				spawn_fx("dust", h[0], 90.0, Color(0.6, 0.6, 0.65))
				shake = maxf(shake, 10.0)
				sfx("swing_heavy")
	elif crypt_rule == "moinho":  # Moinho de Carne (#202): a cada 0,5 s, 6% aos heróis, 25% aos monstros e 3% aos chefes
		saw_t -= delta
		if saw_t <= 0.0:
			saw_t = 0.5
			for b in belts():
				var saw: Vector2 = b[0] + b[1] * 130.0
				if _trap(saw, Pix.SAW_R, 0.06, 0.25, 0.03, "Serra"):
					spawn_fx("sparks", saw, 0.0, Color(1.0, 0.2, 0.15), b[1])


## Lago das Lamentações (#30): a maré de almas está a passar (o convidado lê-a das mesmas horas).
func tide_on() -> bool:
	return crypt_rule == "submersa" and time >= tide_next and time < tide_next + TIDE_T


## Cripta Submersa (#181): na bile os heróis andam a 70%, e na maré a 60% disso.
func terrain_speed() -> float:
	return (0.7 if crypt_rule == "submersa" else 1.0) * (0.6 if tide_on() else 1.0)


## O empurrão da maré, em px/s, nos heróis e nos lacaios (os monstros não).
func tide_push() -> Vector2:
	return tide_dir * 140.0 if tide_on() else Vector2.ZERO


## Necrópole em Chamas Negras (#35): os abrigos de pedra, [posição no mundo, raio]. No Cortejo com as Marés (#212) ou a
## Chuva de Dentes (#192), as 5 lajes à volta do monumento (a 300 px, de 72 em 72 graus) e o próprio monumento (S8).
func shelters() -> Array:
	if crypt_rule == "chamas":
		return [0, 2, 4].map(func(i): return [CRYPT_ORIGIN + CRYPT_PATH[i], 110.0])
	if zone == "world" and ("mares" in cortejo.affixes or "dentes" in cortejo.affixes):
		return range(5).map(func(i): return [monument_pos + Vector2.from_angle(TAU * i / 5.0) * 300.0, 90.0]) + [[monument_pos, 150.0]]
	return []


func sheltered(pos: Vector2) -> bool:
	return shelters().any(func(s): return pos.distance_to(s[0]) < s[1])


## Moinho de Carne das Trevas (#202): as 3 passadeiras (260x70 px, ao longo do corredor), [meio, para onde levam]; a do
## meio leva para a entrada. Cada uma acaba numa serra (meio + rumo x 130). Vêm das constantes: nada vai ao convidado.
func belts() -> Array:
	return [1, 2, 3].map(func(i): return [CRYPT_ORIGIN + CRYPT_PATH[i], CRYPT_DIR * (-1.0 if i == 2 else 1.0)]) if crypt_rule == "moinho" else []


## Em cima de uma passadeira: 120 px/s para a serra (heróis, monstros e lacaios).
func belt_push(pos: Vector2) -> Vector2:
	for b in belts():
		var v: Vector2 = pos - b[0]
		if absf(v.dot(b[1])) < 130.0 and absf(v.cross(b[1])) < 35.0:
			return b[1] * 120.0
	return Vector2.ZERO


## Um golpe em área (hit_circle, boss_slam). Minas de Enxofre (#43): a pedra intacta a que chegue arma-se e rebenta 0,25 s
## depois (_crypt_tick). Salões do Embalsamador (#219): o vaso canópico inteiro estilhaça e solta 2 Almas Canópicas,
## velozes, que rebentam ao tocar num herói ou ao fim de 4 s, sem XP nem saque (como as Almas Rebeldes, #196). Piche
## Funerário (#166): com fire (os feitiços e a Ceifa, nunca o sino de um chefe), o piche a que chegue pega fogo.
func _area_hit(pos: Vector2, r: float, fire := false) -> void:
	if fire:
		for i in pools.size():
			if pools[i][3] == "piche" and pos.distance_to(pools[i][0]) <= r + pools[i][1]:
				ignite(i)
	for k in rocks:
		if k[1] == 0.0 and pos.distance_to(k[0]) <= r + 14.0:
			k[1] = time + 0.25
	for j in jars:
		if j[1] == 0 and pos.distance_to(j[0]) <= r + 14.0:
			j[1] = 1
			spawn_fx("dust", j[0], 50.0, Color(1.0, 0.85, 0.5))
			sfx("hit", 0.7)
			var m := lvl_mods(sep_level() if zone == "sep" else level)
			for s in [-1.0, 1.0]:
				if zone == "sep" and enemies().size() >= SEP_CAP:
					break
				var c = spawn_enemy("specter", j[0] + Vector2(24.0 * s, 0), {"hp": m.hp * 0.6, "speed": 1.4, "dmg": m.dmg}, false)
				c.paint = Color(1.0, 0.85, 0.5)
				c.title = "Alma Canópica"
				c.expire_at = time + 4.0


## Salões do Embalsamador (#219): a foice abre com cuidado o vaso a que chega (30 px de folga): 2 Ossos, 40% um Tinteiro, 5% um reagente.
func _open_jars(origin: Vector2, dir: Vector2, radius: float) -> void:
	for j in jars:
		var v: Vector2 = j[0] - origin
		if j[1] == 0 and v.length() <= radius + 30.0 and (v.length() < 40.0 or absf(dir.angle_to(v)) < 1.3):
			j[1] = 1
			drop("bone", j[0], 2)
			if rng.randf() < 0.4:
				drop("ink", j[0])
			if rng.randf() < 0.05:
				drop(_reagent(), j[0])
			spawn_fx("glow", j[0] + Vector2(0, -20), 40.0, Color(1.0, 0.85, 0.5))
			sfx("chime", 1.2)


## Armadilhas da cripta (B6): quem estiver a menos de r leva uma parte da vida máxima (heróis hero, monstros mon, chefes
## boss). Não é um golpe: sem src (nem Pacto nem Falange), e a esquiva safa. Devolve se apanhou alguém.
func _trap(pos: Vector2, r: float, hero: float, mon: float, boss: float, by: String) -> bool:
	var hit := false
	for p in players:
		if not p.dead and p.position.distance_to(pos) < r:
			p.take_damage(p.max_hp * hero, by)
			hit = true
	for e in enemies():
		if e.position.distance_to(pos) < r + e.radius:
			e.take_damage(e.max_hp * (boss if e.is_boss else mon), true, pos.direction_to(e.position))
			hit = true
	return hit


## Sanctum do Silêncio (#46): o barulho acorda os mortos a dormir a menos de r, que vêm 20% mais depressa. Fica o sítio e
## a hora para o Monge Penitente Cego (#193); r 0 é um passo a correr ou um golpe nele (só um anel cinzento).
func noise(pos: Vector2, r: float) -> void:
	noise_at = pos
	noise_t = time
	if r <= 0.0:
		spawn_fx("ring", pos, 36.0, Color(0.6, 0.6, 0.6))
		return
	spawn_fx("ring", pos, r, Color(0.85, 0.9, 1.0)).dur = 1.2  # um anel pálido que se alarga devagar
	sfx("bell", 0.6)
	for e in enemies():
		if not e.awake and not e.dummy and e.position.distance_to(pos) < r:
			e.awake = true
			e.speed *= 1.2


## Catacumbas Cegas (#26): o escuro só cai nessa sala, e no Cortejo durante o Eclipse Fúnebre (#182).
func dark_on() -> bool:
	return crypt_rule in ["cegas", "esquecidos"] or time < eclipse_end


## As luzes do escuro, Vector3(x, y, raio): a tocha de cada herói (a tremer 3%; caído, 120) e, na cripta, as 4 lâmpadas,
## a saída, os abrigos, as pedras de enxofre e as bigornas da Forja; no Eclipse (#182), o monumento. No máximo 16 (as do shader).
func lights() -> Array:
	var out := []
	for p in players:
		var eye: float = 1.4 if p.stat("olho") > 0.0 and crypt_rule in ["cegas", "esquecidos"] else 1.0  # Olho do Primeiro Rei (#258): a tocha vai mais longe
		out.append(Vector3(p.position.x, p.position.y, 120.0 if p.dead else (220.0 if crypt_rule == "esquecidos" else TORCH_R) * eye * (1.0 + 0.03 * sin(time * 9.0 + p.slot * 2.0))))  # Abismo dos Esquecidos (#211): a tocha mais curta, são as negras que mostram o caminho
	var spots: Array = [[monument_pos, 200.0]] if zone == "world" else _zone_lights() + shelters() + rocks.map(func(k): return [k[0], 70.0]) + hammers.map(func(h): return [h[0], 90.0])
	for l in spots:
		out.append(Vector3(l[0].x, l[0].y, l[1]))
	return out.slice(0, 16)


## As luzes da zona: as lâmpadas e a saída da cripta; nos Sepulcros, só as que a câmara apanha (o shader tem 16).
func _zone_lights() -> Array:
	if zone == "sep":
		var at := cam.get_screen_center_position()
		return sep.get("lights", []).filter(func(l): return l[0].distance_squared_to(at) < 1100.0 * 1100.0)
	return CRYPT_GLOWS.map(func(g): return [CRYPT_ORIGIN + g, 150.0]) + [[CRYPT_ORIGIN + CRYPT_OUT, 120.0]]


## Está à luz de alguma? (às escuras, o minimapa só mostra os monstros que estão)
func lit(pos: Vector2, ls := []) -> bool:
	return (ls if not ls.is_empty() else lights()).any(func(l): return pos.distance_to(Vector2(l.x, l.y)) < l.z)


## Descer: o grupo inteiro vai para a entrada da cripta, que se enche de mortos e do Carcereiro. A sala muda a cada
## descida (S6): a 1.ª é a de sempre, as seguintes sorteiam uma regra que não seja a da última.
func enter_crypt() -> void:
	if cortejo.active:
		hud.toast("O Cortejo Fúnebre ainda não acabou.")
		return
	crypt_n += 1
	var pool: Array = CRYPT_RULES.keys().filter(func(k): return k != "" and k != crypt_last and not k in SEP_ONLY)
	crypt_rule = "" if crypt_n == 1 else pool[rng.randi() % pool.size()]
	crypt_last = crypt_rule
	_change_zone("crypt", CRYPT_ORIGIN + CRYPT_IN)
	guardian_met = false
	var mods := lvl_mods(level)
	var pick: String = CRYPT_BOSSES[(crypt_n - 1) % CRYPT_BOSSES.size()]  # S7: um chefe diferente a cada descida, à vez
	guardian = spawn_enemy(Bosses.spawn_kind(pick), CRYPT_ORIGIN + CRYPT_BOSS, {"hp": mods.hp * 1.8, "dmg": mods.dmg * 1.2}, false)
	guardian.title = "Carcereiro da Cripta"
	guardian.aggro = 480.0
	if pick != "":
		Bosses.make(guardian, pick)
	var n := 0
	for i in 600:
		if n >= (14 if crypt_rule in ["enxofre", "forja", "moinho", "jardins", "canopos"] else 20):  # com armadilhas (B6) e vasos (#219) só 14, para lhes dar espaço
			break
		var p := Vector2(rng.randf_range(bounds.position.x, bounds.end.x), rng.randf_range(bounds.position.y, bounds.end.y))
		if Geometry2D.is_point_in_polygon(p, crypt_floor) and p.distance_to(CRYPT_ORIGIN + CRYPT_IN) > 620.0:
			var e = spawn_enemy("specter" if rng.randf() < 0.3 else "skeleton", p, mods, false)
			e.aggro = 260.0 if crypt_rule == "silencio" else 520.0  # Sanctum do Silêncio (#46): sono pesado, mas o barulho acorda-os
			if n < 2:  # Elites (#277): 2 em cada descida
				e.make_elite()
			n += 1
	_rule_setup(CRYPT_PATH.map(func(q): return CRYPT_ORIGIN + q), CRYPT_SPOTS.map(func(q): return CRYPT_ORIGIN + q), CRYPT_DIR, mods)
	hud.name_card(CRYPT_RULES[crypt_rule][0], CRYPT_RULES[crypt_rule][1], "")
	if crypt_rule != "":  # na de sempre o cartão já diz o que fazer
		hud.toast("Derrota o guardião e abre o relicário.")


## O que cada regra põe no chão, na cripta e nos Sepulcros. path: pontos do caminho (4 ou mais); spots: pontos com 170 px de chão à volta; dir: para onde vai o caminho.
func _rule_setup(path: Array, spots: Array, dir: Vector2, mods: Dictionary) -> void:
	if crypt_rule == "miasma":  # Abismo do Miasma (#38): 60 s de ar, e 3 elites no caminho para o renovar
		breath_end = time + 60.0
		for i in [1, 2, 3]:
			var el = spawn_enemy("skeleton", path[i], mods, false)
			_wear(el)
			el.aggro = 520.0
			el.make_elite()
	elif crypt_rule == "submersa":  # Lago das Lamentações (#30): a 1.ª maré daqui a 8 s, num dos sentidos
		tide_next = time + TIDE_EVERY
		tide_dir = dir * (1.0 if rng.randf() < 0.5 else -1.0)
	elif crypt_rule == "enxofre":  # Minas de Enxofre (#43): 2 pedras em cada ponto do caminho, uma de cada lado
		for q in path:
			for s in [-70.0, 70.0]:
				rocks.append([q + dir.orthogonal() * s, 0.0])
	elif crypt_rule == "forja":  # Forja das Almas Escravas (#184): um martelo em cada ponto, cada um no seu ritmo de 4 a 6 s
		for q in spots:
			hammers.append([q, time + rng.randf_range(4.0, 6.0)])
	elif crypt_rule == "canopos" and zone == "crypt":  # Salões do Embalsamador (#219): tantos vasos canópicos como pontos, aos pares num ponto sim, num não (nos Sepulcros vêm com cada sala, _seal)
		jars = _jar_pairs(range(0, spots.size(), 2).map(func(k): return spots[k]))
	elif crypt_rule == "piche":  # Piche Funerário (#166): 8 poças de piche, nos pontos das armadilhas e no caminho (na cripta o caminho passa colado aos pontos: as 2 dele ficam a 135 px, uma de cada lado, sem tocar noutra)
		for q in (spots + [path[1] + dir.orthogonal() * 135.0, path[3] - dir.orthogonal() * 135.0] if zone == "crypt" else spots + path.slice(1, 3)).slice(0, 8):
			add_pool(q, "piche")
	elif crypt_rule == "tendoes":  # Covil do Tecelão (#36): uma teia em cada ponto do caminho (nos Sepulcros, a meio de cada corredor) e uma à entrada de cada sala de luta
		var at: Array = path
		if zone == "sep":
			at = []
			for i in sep.n - 1:
				var lw: Rect2 = sep.links[i].world
				var ax: Vector2 = _link_axis(sep.rooms, sep.links[i])
				var to: float = signf((sep.rooms[i + 1].center - sep.rooms[i].center).dot(ax))
				at.append(lw.get_center())
				if i + 1 < sep.n - 1:
					at.append(lw.get_center() + ax * to * (lw.size.dot(ax) / 2.0 + 110.0))
		webs = at.slice(0, WEB_N).map(func(q): return [q, 3])
	elif crypt_rule == "jardins":  # Jardins de Pedras Funerárias (#208): uma gárgula em cada ponto
		for q in spots:
			var g = spawn_enemy("skeleton", q, {"hp": mods.hp * 3.0, "dmg": mods.dmg * 2.0}, false)
			g.grow(1.1)
			g.paint = Enemy.STONE
			g.title = "Gárgula"
			g.gargoyle = true
			g.aggro = 520.0


func leave_crypt() -> void:
	guardian = null
	_change_zone("world", CRYPT_DOOR + Vector2(0, 80))
	hud.toast("De volta ao cemitério.")


## Cada zona tem os seus inimigos e o seu baú; muda limites da câmara, escuridão e faz a transição a negro.
func _change_zone(z: String, at: Vector2) -> void:
	hud.drop_toasts()  # os avisos de onde se estava ficam lá
	end_event()  # S9: o evento fica no cemitério
	zone = z
	rocks = []  # as armadilhas (B6) ficam na sala
	hammers = []
	jars = []  # e os vasos (#219) e as portas (S10)
	gates = []
	gate_was = []
	pools = []  # e as poças, os buracos e as teias (Lote 7)
	holes = []
	webs = []
	pit_open = false
	cracks = {}
	for e in enemies():
		if e.boss == "tita":  # o Titã (#70) que fique de pé larga o Coração: não se perde com ele
			drop("coracao", e.position)
		e.queue_free()
	if is_instance_valid(reaper):  # o Ceifador (#216) não está no grupo dos inimigos
		reaper.queue_free()
	corpses.clear()  # os cadáveres ficam com a zona
	graves.clear()
	# O que ficou para trás vem connosco: moedas no chão e o relicário por abrir
	_gather_loot()
	_bank_chest()
	for i in players.size():
		players[i].position = at + Vector2(50 * i, 0)
		players[i].held.clear()
	zone_view(at)
	spawn_t = 2.0
	sfx("hit")
	if z == "world":
		crypt_rule = ""  # as regras da sala (S6) ficam lá em baixo
		_spawn_dummy()


## O saque do chão vai todo para o grupo (ao mudar de zona e ao cair no Mausoléu, #27); com far, só o que está mais longe do que isso de todos.
func _gather_loot(far := 0.0) -> void:
	for l in get_tree().get_nodes_in_group("loot"):
		if players.any(func(q): return q.position.distance_squared_to(l.position) < far * far):
			continue
		if l.kind in ["blood", "soul"]:  # os orbes de sangue e de alma não viajam: secam (senão davam de uma vez tudo o que estava no chão)
			l.queue_free()
			continue
		collect(l)


## A parte que se vê de mudar de zona (o convidado também a faz quando a zona do anfitrião muda).
func zone_view(at: Vector2) -> void:
	bounds = MAP if zone == "world" else SEP_BOUNDS if zone == "sep" else Rect2(CRYPT_ORIGIN, CRYPT.get_size())
	cam.limit_left = int(bounds.position.x)
	cam.limit_top = int(bounds.position.y)
	cam.limit_right = int(bounds.end.x)
	cam.limit_bottom = int(bounds.end.y)
	cam.position = at
	cam.reset_smoothing()
	tint.color = CRYPT_TINT[crypt_rule] if zone == "crypt" else sep_kind(sep_depth()).tint if zone == "sep" else Color.WHITE
	scenery.visible = zone != "sep"
	if zone != "sep":
		_sep_clear()  # o convidado não recarrega quando o anfitrião morre (net:126): tem de largar isto sozinho
	hud.fade()


## O relicário por abrir não se perde: o que tem vai direto para as moedas (ao mudar de zona e ao invocar outra onda).
func _bank_chest() -> void:
	if chest:
		if not chest.opened and not chest.locked:  # o selado do Meteoro (#218) perde-se
			for r in chest.rewards:
				give(r[0], r[1])
			hud.toast("Levaste o relicário contigo.")
		chest.queue_free()
		chest = null


## Nível de área (#27): vida e dano dos mortos e o saque. A cripta usa o nível do grupo; o Cortejo, o do círculo.
func lvl_mods(a: int) -> Dictionary:
	return {"hp": 1.0 + 0.15 * (a - 1), "dmg": 1.0 + 0.08 * (a - 1)}


func loot_mult(a: int) -> float:
	return 1.0 + 0.2 * (a - 1)


## O nível de área do Cortejo: +4 por círculo acima do I.
func circle_level() -> int:
	return 1 + 4 * (circle - 1)


## Selos do Círculo: do II em diante os primeiros afixos já vêm presos, um por círculo acima do I (só os 5 de SEALS).
func circle_seals() -> Array:
	return SEALS.slice(0, circle - 1)


## S8: os 6 afixos do menu do Cortejo: os selos, os que já estão presos e o resto à sorte, com uma ordem que só muda com
## as vitórias e o círculo (o menu reabre igual entre ondas).
func affix_cards() -> Array:
	var out: Array = circle_seals() + cortejo.affixes.filter(func(k): return not k in circle_seals())
	var r := RandomNumberGenerator.new()
	r.seed = wins * 31 + circle
	var pool: Array = AFFIXES.keys()
	for i in range(pool.size() - 1, 0, -1):  # Fisher-Yates com este rng (o shuffle() usa o global)
		var j := r.randi_range(0, i)
		var k = pool[i]
		pool[i] = pool[j]
		pool[j] = k
	for k in pool:
		if out.size() < CARDS and not k in out:
			out.append(k)
	return out


## Saque do Círculo: +30% por círculo acima do I (linear, como o herói cresce; a fórmula da cripta disparava)
func circle_loot() -> float:
	return 1.0 + 0.3 * (circle - 1)


func reward_mult(affixes: Array) -> float:
	return (1.0 + 0.5 * affixes.size()) * circle_loot() * (2.0 if trial != "" else 1.0)  # as Provações dão o dobro


## A Provação id está a correr: escolhida e o Cortejo já começou.
func trial_on(id: String) -> bool:
	return trial == id and cortejo.wave > 0


func start_wave(affixes: Array) -> void:
	if cortejo.wave > 0:  # C (i): os avisos da onda de antes (a esperar pelo painel entre ondas) já não dizem nada
		hud.drop_toasts()
	var seals := circle_seals()
	affixes = seals + affixes.filter(func(k): return not k in seals)
	cortejo.active = true
	cortejo.affixes = affixes
	cortejo.wave += 1
	end_event()  # S9: um evento a meio acaba
	_bank_chest()  # antes perdia-se o Relicário que ficasse por abrir no monumento
	var w: int = cortejo.wave
	var lm := lvl_mods(circle_level())
	var mods := {"hp": (1.0 + 0.45 * (w - 1)) * lm.hp, "speed": 1.0, "dmg": (1.0 + 0.15 * (w - 1)) * lm.dmg}
	if "blindados" in affixes: mods.hp *= 1.6
	if "furia" in affixes: mods.speed *= 1.35
	if "laminas" in affixes: mods.dmg *= 1.5
	var escorts := int((6 + 4 * w) * (1.6 if "legiao" in affixes else 1.0))
	eclipse_next = time + 20.0  # Eclipse Fúnebre (#182): o 1.º cai aos 20 s da onda
	tide_start = time + 15.0  # Marés de Sangue Negro (#212): a 1.ª sobe aos 15 s (o aviso aos 12)
	if w == 1 and trial == "almas":  # Provação das Almas Rejeitadas (#37): os frascos e a alma ficam guardados até ao fim
		for p in players:
			var sup := {}
			for id in p.order:
				sup[id] = p.skills[id].support
				p.skills[id].support = ""
			p.stash = [sup, p.soul]
			p.soul = ""
	var colossi := (0 if w == WAVES else 1) + (1 if "gemeo" in affixes else 0)
	_clear_world()
	for i in colossi:
		spawn_enemy("colossus", monument_pos + Vector2(-120 + 240 * i, -160), mods, true)
	for i in escorts:
		var p := monument_pos + Vector2.from_angle(rng.randf() * TAU) * rng.randf_range(220, 380)
		var e = spawn_enemy("specter" if rng.randf() < 0.3 else "skeleton", p, mods, true)
		_wear(e)
		if i < w:  # Elites (#277): tantos quantos a onda
			e.make_elite()
		elif i < w + 3 and "sinos" in affixes:  # Sineiros (#206): 3 escoltas tocam o sino quando um herói chega a 500 px
			e.ringer_at = -1.0
	if "ceifador" in affixes and not is_instance_valid(reaper):  # O Ceifador Ambulante (#216): nasce na borda da arena e fica até ao fim
		reaper = spawn_enemy("herald", monument_pos + Vector2.from_angle(rng.randf() * TAU) * ARENA_R, mods, false)
		reaper.reaper = true
		reaper.remove_from_group("enemies")  # ninguém lhe bate nem o conta
		reaper.paint = Color(0.1, 0.1, 0.15, 0.75)
		reaper.grow(1.1)
		reaper.title = "O Ceifador Ambulante"
	# na última onda o Arauto conta já, embora só apareça depois do sino
	cortejo.alive = colossi + escorts + (1 if w == WAVES else 0)
	spawn_fx("ring", monument_pos, 400.0, Color(0.9, 0.2, 0.25))
	if fx_budget("pfx_rise", 1, 1):  # o Invocar: o círculo do pixelfx no monumento, o estoiro e o demónio que sobe e se desfaz
		spawn_fx("pfx_rise", monument_pos + Vector2(0, 2), 1.0, Color.WHITE)  # 2 px abaixo: na ordem pela altura fica à frente do monumento
	hud.toast(tr("Cortejo Fúnebre — onda %d de %d   (recompensa x%.1f)") % [w, WAVES, reward_mult(affixes)])
	if w == WAVES:
		_boss_intro(mods)


## Os mortos do cemitério saem antes de uma onda ou de um modo (os do Cortejo ficam).
func _clear_world() -> void:
	for e in enemies():
		if e.boss == "tita":  # o Titã (#70) que fique de pé larga o Coração, que vai logo para as moedas (o chão não fica gravado)
			collect(drop("coracao", e.position))
		if not e.cortejo:
			e.queue_free()


## O que uma onda dá; o menu do Cortejo mostra exatamente isto antes de a invocar.
## A última onda soma o tesouro final, que vai para o Relicário selado.
func wave_rewards(w: int, affixes: Array) -> Dictionary:
	var m := reward_mult(affixes)
	var r := {"bone": int(4 * w * m), "ink": int(ceil(w * m * 0.6)), "ash": int(ceil((w - 1) * m * 0.6))}
	if w >= WAVES:
		r.ink += int(3 * m)
		r.ash += int(3 * m)
	return r


func _wave_cleared() -> void:
	var w: int = cortejo.wave
	var r := wave_rewards(w, cortejo.affixes)
	cortejo.active = false
	if w >= WAVES:
		_spawn_chest(r.keys().filter(func(k): return r[k] > 0).map(func(k): return [k, r[k]]) + [[_reagent(), 1]] + ([["coracao", 1]] if rng.randf() < 0.15 else []))  # e um reagente da Forja (S2); 15% um Coração de Titã (#70)
		if trial == "almas" and not "almas" in proven:  # a 1.ª vitória na Provação das Almas (#37): um Frasco que falte, ao pé do Relicário
			var lying: Array = get_tree().get_nodes_in_group("loot").filter(func(l): return l.kind == "flask").map(func(l): return l.flask)  # o do chefe ainda está no chão: não sai outra vez
			var miss: Array = (Player.SUPPORTS + Player.SOULS).filter(func(f): return not f in flasks and not f in lying and not f in Player.CURSED)
			if not miss.is_empty():  # só fica dada quando se apanha (collect): o saque do chão não fica gravado
				drop("flask", chest.position, 1, Vector2.from_angle(rng.randf() * TAU) * 120.0, miss[rng.randi() % miss.size()]).set_meta("prova", true)
		end_cortejo()
		hud.toast("O Cortejo foi quebrado! Um Relicário selado ergue-se no monumento.")
		# Círculos: cada vitória conta; no círculo mais alto abre o seguinte, e o próximo Cortejo já é nele
		wins += 1
		camps_done = []  # é o ciclo: limpar os acampamentos, vencer o Cortejo, voltar
		camp_left = {}
		var sub := tr("Vitória número %d") % wins
		if circle == circle_max and circle_max < 99:
			circle_max += 1
			circle = circle_max
			sub = tr("Círculo %d aberto: o cemitério mudou") % circle
		hud.name_card("Cortejo Quebrado", sub)
		sfx("victory")
		return
	for k in r:
		if r[k] > 0:
			drop(k, monument_pos, r[k])
	hud.open_cortejo()


func _spawn_chest(rewards: Array, pos := Vector2.INF) -> void:
	chest = Chest.new()
	chest.main = self
	chest.rewards = rewards
	chest.position = monument_pos + Vector2(0, 150) if pos == Vector2.INF else pos
	add_child(chest)
	spawn_fx("dust", chest.position, 70.0, Color.WHITE)
	spawn_fx("ring", chest.position, 120.0, Color(1.0, 0.85, 0.4))
	shake = maxf(shake, 8.0)
	sfx("hit")


func end_cortejo() -> void:
	hud.drop_toasts()  # a onda e o chefe dela já não estão à vista
	cortejo = {"active": false, "wave": 0, "affixes": [], "alive": 0}
	arena_r = 0.0
	trial = ""  # a Provação dura um Cortejo
	eclipse_end = 0.0
	_unstash()
	if is_instance_valid(reaper):
		reaper.queue_free()
	reaper = null


## Provação das Almas Rejeitadas (#37): cada herói volta a ter os frascos e a alma que tinha (no fim do Cortejo ou ao morrer).
func _unstash() -> void:
	for p in players:
		if p.stash != null:
			for id in p.stash[0]:
				p.skills[id].support = p.stash[0][id]
			p.soul = p.stash[1]
			p.stash = null


## Afixos do Cortejo (S8), no anfitrião, durante as ondas: o Eclipse Fúnebre (#182) cai a cada 30 s e dura 10; a Maré de
## Sangue Negro (#212) sobe a cada 25 s e, nos 8 s em que está alta, tira 3% a quem estiver fora das pedras (heróis e
## lacaios; os monstros não); a Chuva de Dentes (#192) tira um pouco a quem não se abriga. De meio em meio segundo.
func _cortejo_tick(delta: float) -> void:
	if not cortejo.active:
		return
	var aff: Array = cortejo.affixes
	if "eclipse" in aff and time >= eclipse_next:
		eclipse_next = time + 30.0
		eclipse_end = time + 10.0
		hud.toast("Eclipse!")
		sfx("bell")
	if "mares" in aff and time >= tide_start + 8.0:  # a maré desce: a próxima sobe 25 s depois da anterior
		tide_start += 25.0
	drip_t -= delta
	if drip_t > 0.0:
		return
	drip_t = 0.5
	if tide_up():
		for p in players:
			if not p.dead and not sheltered(p.position):
				p.take_damage(p.max_hp * 0.03, "Maré de Sangue Negro")
		for a in get_tree().get_nodes_in_group("allies"):
			if not sheltered(a.position):
				a.life -= Ally.LIFE * 0.03
	if "dentes" in aff:
		quiet = true  # lascas pequenas: números cinzentos, sem tremor nem som
		for p in players:
			if not p.dead and not sheltered(p.position):
				p.take_damage(2.0 * lvl_mods(circle_level()).dmg, "Chuva de Dentes")
		quiet = false


## Marés de Sangue Negro (#212): a maré está alta (o convidado lê-a das mesmas horas).
func tide_up() -> bool:
	return cortejo.active and "mares" in cortejo.affixes and time >= tide_start and time < tide_start + 8.0


# ---------- Eventos do cemitério (S9) ----------

## O nível dos mortos e do saque dos eventos: 2 acima do grupo ou do Círculo escolhido.
func ev_level() -> int:
	return maxi(level, circle_level()) + 2


## S9, no anfitrião: a cada 3 a 4 minutos, com o cemitério calmo (sem Cortejo, arena, modo nem Titã acordado), começa um
## evento que não seja o último (se não der, fica para a vez seguinte); e o de agora avança.
func _event_tick() -> void:
	if event.is_empty():
		if time >= event_next:
			event_next = time + rng.randf_range(180.0, 240.0)
			if zone == "world" and cortejo.wave == 0 and arena_r == 0.0 and not mode_on() and not enemies().any(func(e): return e.boss == "tita" or e.title == "Titã Banqueteado"):
				var pool: Array = EVENTS.keys().filter(func(k): return k != event_last and (k != "carruagem" or circle_max >= 3))  # a carruagem (#48) do Círculo III em diante
				start_event(pool[rng.randi() % pool.size()])
		return
	var mods := lvl_mods(ev_level())
	match event.id:
		"fenda":  # Fenda Necrótica (#42): 2 mortos a cada 0,5 s até 20 (e 2 elites do Círculo II em diante), sem olhar ao limite
			if event.left > 0 and time >= event.next:
				if event.left == 20 and circle_max >= 2:
					for i in 2:
						_ev_spawn("skeleton", event.pos + Vector2(-50 + 100 * i, 30), mods).make_elite()
				event.next += 0.5
				event.left -= 2
				for i in 2:
					_ev_spawn("specter" if rng.randf() < 0.3 else "skeleton", event.pos + Vector2.from_angle(rng.randf() * TAU) * rng.randf_range(20.0, 70.0), mods)
			elif time >= event.end:  # 90 s depois fecha-se, e os que ficaram desfazem-se sem deixar nada
				end_event()
				hud.toast("A fenda fechou-se.")
			elif event.left <= 0 and event.alive <= 0:  # todos mortos: um relicário na fenda
				_event_chest(1.0)
				hud.toast("A fenda fechou-se: o relicário é teu!")
				event = {}
		"meteoro":  # Meteoro Funerário (#218): cai 3 s depois do aviso; a cratera fica 120 s
			if event.left > 0 and time >= event.at:
				event.left = 0
				_land_meteor(mods)
			elif time >= event.end:
				var sealed: bool = chest != null and chest.locked
				end_event()
				hud.toast("A cratera apagou-se e levou o relicário selado." if sealed else "A cratera apagou-se.")
			elif event.left <= 0 and event.alive <= 0:  # a cratera limpa: o relicário (já aberto) fica
				event = {}
		"banquete":  # Banquete dos Espectros (#47): 4 ondas de 8 espectros, uma a cada 12 s, a caminho da carcaça
			if event.left > 0 and time >= event.next:
				event.left -= 1
				event.next = time + 12.0
				for i in 8:
					_ev_spawn("specter", event.pos + Vector2.from_angle(rng.randf() * TAU) * rng.randf_range(600.0, 700.0), mods).feast_to = event.pos
			elif event.left <= 0 and event.alive <= 0:
				if event.bar < 1.0:  # o titã não se ergueu: um relicário que vale mais quanto menos ele comeu
					_event_chest(2.0 - event.bar)
					hud.toast("O banquete acabou: o relicário é teu!")
				event = {}
		"carruagem":  # Carruagem Fúnebre (#48): parada e partida dá o relicário (_on_enemy_killed); 150 s sem a parar, passou
			if time >= event.end and not enemies().any(func(c): return c.boss == "carruagem" and c.limbs.max() <= 0.0):  # parada já não passa
				end_event()
				hud.toast("A carruagem passou... levou o relicário com ela.")
				return
			for c in enemies():  # a seta do objetivo vai atrás dela (aos saltos de 150 px: o evento vai inteiro ao convidado a cada mudança)
				if c.boss == "carruagem" and c.position.distance_to(event.pos) > 150.0:
					event.pos = c.position


## S9: começa o evento id (EVENTS) a uma distância de um herói vivo ao acaso, dentro do mapa, com o cartão e o aviso.
func start_event(id: String) -> void:
	var alive := players.filter(func(q): return not q.dead)
	if alive.is_empty():
		return
	var from: Vector2 = alive[rng.randi() % alive.size()].position
	var far := rng.randf_range(450.0, 600.0) if id == "fenda" else rng.randf_range(500.0, 700.0) if id == "meteoro" else 500.0
	var at := from
	for i in 12:  # um rumo que fique dentro do mapa e longe dos adereços altos (taparam a fenda, a cratera e a carcaça)
		at = from + Vector2.from_angle(rng.randf() * TAU) * far
		if MAP.grow(-150.0).has_point(at) and not tall.any(func(r): return r.grow(120.0).has_point(at)):
			break
	at = at.clamp(MAP.position + Vector2(150, 150), MAP.end - Vector2(150, 150))
	var road: Array = cart_start(from) if id == "carruagem" else []
	if id == "carruagem":  # #48: na estrada, a chegar perto de quem a vai ver passar
		at = road[0]
	event_last = id
	event = {"id": id, "pos": at, "at": time + (2.0 if id == "fenda" else 3.0 if id == "meteoro" else 0.0), "end": time + (92.0 if id == "fenda" else 123.0 if id == "meteoro" else INF),
		"next": time + 2.0, "left": 20 if id == "fenda" else 4 if id == "banquete" else 1, "alive": 0, "bar": 0.0}
	if id == "carruagem":
		event.end = time + Bosses.CART_T
		event.left = 0
		var c = _ev_spawn("colossus", at, lvl_mods(ev_level()))
		Bosses.make(c, "carruagem")
		c.boss_k = road[1]
		c.chain_to = CART_ROUTE[road[1]]
		c.radius = 72.0  # do tamanho do desenho: os golpes chegam-lhe pelas rodas
		meet(c)
	if id == "fenda":  # 2 s de aviso: o anel, o pilar e o chão a tremer
		spawn_fx("ring", at, 160.0, Color(0.7, 0.4, 1.0))
		spawn_fx("pillar", at, 0.0, Color(0.7, 0.4, 1.0), Vector2.RIGHT, "necro")
	if id != "banquete":
		rumble = 2.6
	hud.name_card(EVENTS[id][0], EVENTS[id][1], "")
	hud.toast(EVENTS[id][2])
	sfx("bell", 0.7)


## Um morto do evento (ev = 1: a morte dele conta em event.alive), em at, com a força do evento.
func _ev_spawn(kind: String, at: Vector2, mods: Dictionary):
	var e = spawn_enemy(kind, at, mods, false)
	e.ev = 1
	_wear(e)
	event.alive += 1
	spawn_fx("dust", at, 40.0, Color(0.7, 0.55, 0.85))
	return e


## O relicário de um evento, na fenda ou na carcaça: ossos 8 x m, tinteiros 2 + nível/3, cinzas 1 + nível/5 e, 15%, um
## reagente da Forja (S2); tudo vezes k. heart: a parte das vezes em que vem um Coração de Titã (a carruagem, #48).
func _event_chest(k: float, heart := 0.0) -> void:
	var a := ev_level()
	var rew := [["bone", int(8 * loot_mult(a) * k)], ["ink", int((2 + a / 3) * k)], ["ash", int((1 + a / 5) * k)]]
	if rng.randf() < 0.15:
		rew.append([_reagent(), 1])
	if rng.randf() < heart:
		rew.append(["coracao", 1])
	_bank_chest()
	_spawn_chest(rew, event.pos)


## Meteoro Funerário (#218): a coluna, a explosão e 30% da vida a quem estiver no círculo (não é um golpe: a esquiva safa e
## não há Pacto nem Falange); fica a cratera, com 3 elites e 6 escoltas à volta do relicário selado, que só abre quando
## os elites caírem (ossos 10 x m, tinteiros 3 + nível/3, cinzas 2 + nível/4, um reagente e, 25%, um Coração de Titã).
func _land_meteor(mods: Dictionary) -> void:
	var at: Vector2 = event.pos
	spawn_fx("pillar", at, 0.0, Color(1.0, 0.5, 0.25), Vector2.RIGHT, "gold")
	if fx_budget("explosion", 2, 4):
		spawn_fx("explosion", at, 1.8, Color(1.0, 0.5, 0.25), Vector2.RIGHT, "gold")
	else:
		spawn_fx("ring", at, 140.0, Color(1.0, 0.5, 0.25))
	spawn_fx("dust", at, 140.0, Color(0.5, 0.45, 0.4))
	shake = 18.0
	sfx("roar")
	vibrate(200, 1.0)
	_trap(at, 140.0, 0.3, 0.5, 0.1, "Meteoro Funerário")
	if event.is_empty():  # a queda deitou o último herói: die() já acabou o evento
		return
	var a := ev_level()
	var rew := [["bone", int(10 * loot_mult(a))], ["ink", 3 + a / 3], ["ash", 2 + a / 4], [_reagent(), 1]]
	if rng.randf() < 0.25:  # o Coração de Titã (#70), uma vez em quatro
		rew.append(["coracao", 1])
	_bank_chest()
	_spawn_chest(rew, at)
	chest.locked = true
	for i in 9:  # 3 elites e 6 escoltas, à volta do relicário
		var e = _ev_spawn("skeleton" if i < 3 or rng.randf() < 0.7 else "specter", at + Vector2.from_angle(TAU * i / 9.0 + 0.3) * rng.randf_range(130.0, 200.0), mods)
		if i < 3:
			e.make_elite()


## Banquete dos Espectros (#47): o espectro chegou à carcaça e é comido (sem saque): +10% no banquete. A 100% ergue-se o
## Titã Banqueteado (um colosso maior, ao nível do evento) e os espectros que ainda vinham passam a caçar os heróis.
func feast(e) -> void:
	e.queue_free()
	if event.get("id") != "banquete":
		return
	event.alive -= 1
	event.bar = minf(1.0, snappedf(event.bar + 0.1, 0.01))  # snapped: dez vezes 0,1 dá 0,999…
	number(event.pos + Vector2(0, -110), tr("O banquete cresce"), 20.0, Color(1.0, 0.45, 0.4))
	spawn_fx("glow", event.pos + Vector2(0, -30), 70.0, Color(0.6, 0.85, 1.0))
	if event.bar < 1.0 or event.has("titan"):
		return
	event.titan = true
	event.left = 0
	for o in enemies():
		o.feast_to = Vector2.INF
	var t = _ev_spawn("colossus", event.pos, lvl_mods(ev_level()))
	t.grow(1.4)
	t.title = "Titã Banqueteado"
	spawn_fx("dust", t.position, 140.0, Color.WHITE)
	sfx("roar")
	shake = maxf(shake, 14.0)
	hud.name_card("Titã Banqueteado", "Comeu as almas que deixaste passar")


## S9: o evento acaba antes do tempo (descer à cripta, um Cortejo, cair) ou o tempo dele acabou: os mortos dele
## desfazem-se em pó, sem saque, e o relicário que ainda estiver selado vai com ele.
func end_event() -> void:
	if event.is_empty():
		return
	for e in enemies():
		if e.ev == 1:
			spawn_fx("dust", e.position, 50.0, Color(0.6, 0.55, 0.65))
			e.queue_free()
	if chest != null and chest.locked:
		chest.queue_free()
		chest = null
	event = {}


# ---------- Mausoléu Sem Fim (#27) e Santuário dos Deuses Cadavéricos (#50) ----------

## Um dos modos está a correr (a arena do monumento fica fechada).
func mode_on() -> bool:
	return mausoleum > 0 or sanctum_rule > 0 or kings or amalgama


## Porque é que um modo não pode começar agora ("" se pode): nem a meio de um Cortejo, de um evento ou de outro modo.
func mode_block() -> String:
	if cortejo.wave > 0:
		return "O Cortejo Fúnebre ainda não acabou."
	if not event.is_empty():
		return "Acaba primeiro o evento do cemitério."
	if mode_on():
		return "Já estás num desafio."
	return ""


## Os modos fecham a arena do monumento, como o Cortejo (não são Provações: nenhuma começa com eles).
func _open_arena() -> bool:
	var why := mode_block()
	if why != "":
		hud.toast(why)
		return false
	_bank_chest()
	_clear_world()
	arena_r = ARENA_R
	spawn_fx("ring", monument_pos, 400.0, Color(0.9, 0.2, 0.25))
	return true


## Acaba o modo de agora: a arena abre-se e as maldições e as leis vão-se (os mortos que ficaram, ficam).
func end_mode() -> void:
	if mode_on():
		arena_r = 0.0
	mausoleum = 0
	floor_end = 0.0
	curses = []
	sanctum_rule = 0
	kings = false
	amalgama = false


## Mausoléu Sem Fim (#27): pisos de 40 s na arena do monumento, cada um um nível acima, a começar no do Círculo escolhido.
## A cada 5 pisos, uma maldição (os 5 selos, que se somam); um Coveiro nos pisos 5, 15…; nos 10, 20… o chefe. Abre depois
## da 1.ª vitória; o piso mais fundo fica no jogo gravado.
func start_mausoleum() -> void:
	if not _open_arena():
		return
	mausoleum = 1
	deep = maxi(deep, 1)
	floor_end = time + FLOOR_T
	curses = []
	maus_t = 0.0
	sfx("bell")
	hud.name_card("Mausoléu Sem Fim", "Aguenta 40 s em cada piso. Cair acaba a descida, sem túmulo.", "")
	_floor_start()


## A força dos mortos do piso: o nível do Círculo mais um por piso, com as maldições somadas.
func maus_mods() -> Dictionary:
	var lm := lvl_mods(circle_level() + mausoleum - 1)
	return {"hp": lm.hp * pow(1.6, curses.count("blindados")), "speed": pow(1.35, curses.count("furia")), "dmg": lm.dmg * pow(1.5, curses.count("laminas"))}


## Quantos mortos do piso de uma vez: 8 + piso (no máximo 24) e +60% por cada Legião, mas nunca mais de 48 (a separação
## dos monstros, enemy._move, custa o quadrado deles: com 3 ou 4 Legiões o telemóvel não aguentava).
func maus_cap() -> int:
	return mini(int(mini(8 + mausoleum, 24) * pow(1.6, curses.count("legiao"))), 48)


## No anfitrião: os mortos chegam à arena aos pares, até 8 + piso (no máximo 24; mais com a Legião, maus_cap), com elites do piso 3
## em diante (#277: 1, 2 do 8, 3 do 13); acabado o tempo do piso, desce-se ao seguinte.
func _mausoleum_tick(delta: float) -> void:
	if mausoleum == 0:
		return
	if time >= floor_end:
		_next_floor()
		return
	maus_t -= delta
	if maus_t > 0.0:
		return
	maus_t = 0.5
	var foes := enemies().filter(func(e): return not e.is_boss and not e.anchor and not e.dummy)
	if foes.size() >= maus_cap():
		return
	var elites: int = 0 if mausoleum < 3 else 1 if mausoleum < 8 else 2 if mausoleum < 13 else 3
	var have: int = foes.filter(func(e): return e.elite).size()
	var mods := maus_mods()
	for i in 2:
		var e = spawn_enemy("specter" if rng.randf() < 0.3 else "skeleton", monument_pos + Vector2.from_angle(rng.randf() * TAU) * rng.randf_range(460.0, 560.0), mods, false)
		spawn_fx("dust", e.position, 40.0, Color.WHITE)
		if have < elites:
			e.make_elite()
			have += 1


func _next_floor() -> void:
	mausoleum += 1
	deep = maxi(deep, mausoleum)
	floor_end = time + FLOOR_T
	number(monument_pos + Vector2(0, -280), tr("Piso %d") % mausoleum, 32.0, Color(0.85, 0.75, 1.0))
	sfx("bell", 0.8)
	_floor_start()
	if mausoleum % 5 == 1:  # depois dos pisos 5, 10, 15…: uma maldição
		hud.open_curses()


## O que cada piso traz ao começar: um colosso a mais por cada Colosso Gémeo; um Coveiro nos pisos 5, 15, 25…; nos 10,
## 20… o chefe, à vez (MAUS_BOSSES: o Arauto, o Guardião dos Monumentos, o Marechal, o Arquilich e a Tecelã), e o piso
## só acaba quando ele cair.
func _floor_start() -> void:
	var mods := maus_mods()
	for i in curses.count("gemeo"):
		spawn_enemy("colossus", monument_pos + Vector2(-220 + 440 * (i % 2), -200 + 60 * (i / 2)), mods, false)
	if mausoleum % 10 == 5:
		var c = spawn_enemy("colossus", monument_pos + Vector2(0, -230), mods, false)
		c.title = "Coveiro"
		spawn_fx("dust", c.position, 90.0, Color.WHITE)
	elif mausoleum % 10 == 0:
		floor_end = INF
		var pick: String = MAUS_BOSSES[(mausoleum / 10 - 1) % MAUS_BOSSES.size()]
		var h = spawn_enemy(Bosses.spawn_kind(pick), monument_pos + Vector2(280, -60), mods, false)
		h.rise_t = 1.4
		h.floor_boss = true
		if pick != "arauto":
			Bosses.make(h, pick)
		if not pick in ["arauto", "guardiao"]:  # com a vida do Arauto e do Guardião (2,3 colossos): o chefe de cada piso é mais forte do que o de antes
			h.max_hp *= 2.3
			h.hp = h.max_hp
			h.hp_chunk = h.max_hp
		if pick == "guardiao":
			raise_statues(h)
		spawn_fx("dust", h.position, 140.0, Color.WHITE)
		sfx("bell")
		focus_pos = h.position + Vector2(0, -40)
		focus_t = 2.0


## Santuário dos Deuses Cadavéricos (#50): no monumento, três sinos e ergue-se o Deus Cadavérico (um Arauto dourado e maior,
## com metade da vida a mais: com a armadura de 40%, os golpes diretos custam 1500 x 1,5 x a vida do Círculo, como o
## plano dizia antes da armadura), que muda a lei a cada 25% da vida (LAWS, Bosses.tick). Abre no Círculo 6; repete-se.
func start_sanctum() -> void:
	if not _open_arena():
		return
	sanctum_rule = 1
	rumble = 3.9
	hud.toast("Três sinos dobram... os Deuses Cadavéricos acordam.")
	for i in 3:
		sfx("bell")
		await get_tree().create_timer(1.3, false).timeout
		if not is_inside_tree() or sanctum_rule == 0:
			return
	var lm := lvl_mods(circle_level())
	var g = spawn_enemy("herald", monument_pos + Vector2(280, -60), {"hp": lm.hp, "dmg": lm.dmg}, false)
	Bosses.make(g, "santuario")
	g.rise_t = 1.4
	g.haste = 1.35
	g.reach = 1.3
	spawn_fx("dust", g.position, 140.0, Color.WHITE)
	focus_pos = g.position + Vector2(0, -40)
	focus_t = 3.2


## Lote 9, #34 Os Reis Caídos (Desafios, do Círculo 4 em diante): no monumento, três colossos coroados (Ouro, Prata e Bronze,
## 1,3 vezes maiores, com 1,2 vezes a vida de um colosso do Círculo), um com o Escudo, outro com a Espada e outro com o
## Cetro (Bosses._king). A cada quarto da vida dos três somada, trocam de armas (_kings_tick). Os três caídos: o relicário
## do Santuário, uma peça rara por herói e uma Relíquia que falte (_on_enemy_killed).
func start_kings() -> void:
	if not _open_arena():
		return
	kings = true
	kings_k = 0
	rumble = 2.6
	sfx("bell")
	var lm := lvl_mods(circle_level())
	kings_hp = 0.0
	for i in 3:
		var k = spawn_enemy("colossus", monument_pos + Vector2(-300 + 300 * i, -60 + 40 * (i % 2)), {"hp": lm.hp, "dmg": lm.dmg}, false)
		Bosses.make(k, Bosses.KINGS[i])
		kings_hp += k.max_hp
		spawn_fx("dust", k.position, 120.0, Color.WHITE)
		meet(k)
	Bosses.crown(self, 0)
	hud.name_card("Os Reis Caídos", "Os reis trocam de armas a cada quarto da vida", "")
	focus_pos = monument_pos + Vector2(0, -100)
	focus_t = 2.0


## #34, no anfitrião: a cada 25% da vida dos três reis somada (os caídos contam 0), trocam de armas, com o cartão.
func _kings_tick() -> void:
	if not kings:
		return
	var alive: Array = Bosses.sisters(self, "reis")
	if alive.is_empty() or kings_hp <= 0.0:
		return
	var hp := 0.0
	for k in alive:
		hp += maxf(k.hp, 0.0)
	var want := mini(3, int((1.0 - hp / kings_hp) * 4.0))
	if want > kings_k:
		kings_k = want
		Bosses.crown(self, kings_k)
		hud.name_card("Os Reis trocam de armas!", "", "")
		sfx("bell")
		shake = maxf(shake, 10.0)


## Lote 9, #220 Amálgama Primordial (Desafios, depois da primeira vitória no Santuário): um Arauto 1,7 vezes maior, com 2,5
## vezes a vida do Círculo e a armadura de 40%, que veste um chefe a cada 20% da vida (Bosses._amalgam): o Suturado, o
## Carrasco, o Monge, o Guardião e o Deus Cadavérico, com a 4.ª lei e a arena a fechar. Caída: o relicário do Santuário
## x 1,5, mais dois reagentes e uma peça única.
func start_amalgama() -> void:
	if not _open_arena():
		return
	amalgama = true
	rumble = 3.0
	sfx("bell")
	var lm := lvl_mods(circle_level())
	var g = spawn_enemy("herald", monument_pos + Vector2(280, -60), {"hp": lm.hp, "dmg": lm.dmg}, false)
	Bosses.make(g, "amalgama")
	g.rise_t = 1.4
	spawn_fx("dust", g.position, 160.0, Color.WHITE)
	focus_pos = g.position + Vector2(0, -40)
	focus_t = 3.2


## Lote 9: o Livro dos Chefes conta o chefe e como já visto (0 vitórias), se ainda não estiver lá.
func meet(e) -> void:
	var id: String = Bosses.book_id(e)
	if id != "" and not beaten.has(id):
		beaten[id] = 0


## #48: onde a carruagem entra na estrada: 450 px antes do ponto da estrada mais perto de from, no mesmo troço; devolve
## [o sítio, o índice do ponto da estrada para onde vai].
func cart_start(from: Vector2) -> Array:
	var best := [INF, Vector2.ZERO, 0]
	for i in CART_ROUTE.size():
		var a: Vector2 = CART_ROUTE[i]
		var b: Vector2 = CART_ROUTE[(i + 1) % CART_ROUTE.size()]
		var q := Geometry2D.get_closest_point_to_segment(from, a, b)
		if q.distance_to(from) < best[0]:
			best = [q.distance_to(from), q - a.direction_to(b) * minf(450.0, q.distance_to(a)), (i + 1) % CART_ROUTE.size()]
	return [best[1], best[2]]


# ---------- Os Sepulcros (0.4.6) ----------

func sep_depth() -> int:
	return sep_key % 1000


## O aspeto e a forma (chão, paredes, mortos, largura, voltas): a cada profundidade outro, para a 2 não parecer a 1 (a 5.ª de cada bloco é sempre o Túmulo dos Reis, o chão dos guardiões).
func sep_kind(d: int) -> Dictionary:
	return SEPS[(maxi(d, 1) - 1) % SEPS.size()]


## As regras e o guardião: a cada 5 profundidades.
func sep_block(d: int) -> Dictionary:
	return SEPS[(maxi(d, 1) - 1) / 5 % SEPS.size()]


## A força: um nível por profundidade, a partir do nível do grupo ou do último Círculo vencido (o que for maior). Nunca circle_level(): é o Círculo ainda por vencer, e as setas do menu do Cortejo mudavam-no em silêncio.
func sep_level() -> int:
	return maxi(level, 4 * circle_max - 7) + sep_depth() - 1


## O bónus do relicário, em %: 15 por profundidade seguida, até ao dobro (extra: o da próxima).
func sep_bonus(extra := 0) -> int:
	return mini(15 * (sep_streak + extra), 100)


## A regra sai da chave: a 1.ª de cada bloco não tem; o guardião tem a dele; as outras vão rodando no bloco, logo duas seguidas nunca são iguais.
func sep_rule(key: int) -> String:
	var d: int = key % 1000
	var kind := sep_block(d)
	if d % 5 == 1:
		return ""
	if d % 5 == 0:
		return kind.guard_rule
	return kind.rules[(d + key / 1000) % kind.rules.size()]


## Uma sala de 4 a 5 casas de lado dentro do lote (a do chefe, 5 x 5). next: para onde a seta aponta a partir dela.
func _sep_room(lot: Vector2i, type: String, next: int, r: RandomNumberGenerator) -> Dictionary:
	var w: int = 5 if type == "chefe" else 4 + r.randi() % 2
	var h: int = 5 if type == "chefe" else 4 + r.randi() % 2
	var at := Vector2i(1, 1) + lot * 6 + Vector2i(r.randi() % (6 - w), r.randi() % (6 - h))
	var world := Rect2(SEP_ORIGIN + Vector2(at) * SEP_CELL, Vector2(w, h) * SEP_CELL)
	var c := world.get_center()
	var spots := []
	for k in 8:
		spots.append(c + Vector2.from_angle(TAU * k / 8.0 + 0.4) * world.size * 0.31)
	return {"rect": Rect2i(at, Vector2i(w, h)), "world": world, "center": c, "type": type, "next": next, "spots": spots, "seen": false, "woken": type in ["entrada", "chefe"], "feature": null}


## Um corredor a direito entre as salas i e j, de lotes vizinhos: cada uma ocupa pelo menos 4 casas em 5, logo partilham pelo menos 3.
func _sep_link(rooms: Array, i: int, j: int, wide: int, r: RandomNumberGenerator) -> Dictionary:
	var a: Rect2i = rooms[i].rect
	var b: Rect2i = rooms[j].rect
	var side: bool = a.end.x <= b.position.x or b.end.x <= a.position.x  # lado a lado (senão, um por cima do outro)
	var lo: int = maxi(a.position.y, b.position.y) if side else maxi(a.position.x, b.position.x)
	var hi: int = mini(a.end.y, b.end.y) if side else mini(a.end.x, b.end.x)
	var at: int = lo + r.randi() % (hi - lo - wide + 1)
	var c: Rect2i
	if side:
		var x0: int = mini(a.end.x, b.end.x)
		c = Rect2i(x0, at, maxi(a.position.x, b.position.x) - x0, wide)
	else:
		var y0: int = mini(a.end.y, b.end.y)
		c = Rect2i(at, y0, wide, maxi(a.position.y, b.position.y) - y0)
	return {"rect": c, "world": Rect2(SEP_ORIGIN + Vector2(c.position) * SEP_CELL, Vector2(c.size) * SEP_CELL), "a": i, "b": j}


## turn: para onde olha uma peça de SEP_FIXED; as outras espelham-se ao calhas.
func _sep_prop(props: Array, what: String, at: Vector2, rp: RandomNumberGenerator, color: Color, turn := false) -> void:
	var fixed: bool = what in SEP_FIXED
	props.append([what, at, float(PROPS[what][1]) * (1.0 if fixed else 0.95 + rp.randf() * 0.1), turn if fixed else rp.randi() % 2 == 0, color.darkened(rp.randf() * (0.06 if fixed else 0.2))])


## Ruído de baixa frequência, de 0 a 255. Só inteiros: é o que decide o chão, e a mesma chave tem de dar o mesmo nos dois telemóveis.
func _sep_blot(nz: PackedByteArray, u: int, v: int, s: int) -> int:
	var i: int = u / s
	var j: int = v / s
	var a: int = nz[(i & 31) | (j & 31) << 5] * (s - u % s) + nz[((i + 1) & 31) | (j & 31) << 5] * (u % s)
	var b: int = nz[(i & 31) | ((j + 1) & 31) << 5] * (s - u % s) + nz[((i + 1) & 31) | ((j + 1) & 31) << 5] * (u % s)
	return (a * (s - v % s) + b * (v % s)) / (s * s)


## Uma mancha de ruído com a borda solta e sem losangos sozinhos (pareciam carimbos): conta só com 2 dos 4 vizinhos também na mancha.
func _sep_patch(nz: PackedByteArray, u: int, row: int, s: int, limit: int) -> bool:
	var near := 0
	for o in [Vector2i(1, 1), Vector2i(3, 1), Vector2i(1, 3), Vector2i(3, 3)]:
		if _sep_blot(nz, u + o.x, row + o.y, s) > limit:
			near += 1
	return near >= 2 and _sep_blot(nz, u + 2, row + 2, s) + (_sep_blot(nz, u + 9, row + 5, 2) - 128) / 3 > limit


## O chão de uma sala segue a peça dela: o índice em kind.floor de um losango (u em meios ladrilhos, row em filas). f: o losango debaixo da peça, x < 0 sem ela. Só inteiros, como _sep_blot.
func _sep_ground(look: String, u: int, row: int, f: Vector2i, nz: PackedByteArray, rt: RandomNumberGenerator) -> int:
	var has: bool = f.x >= 0
	var du: int = u - f.x
	var dr: int = row - f.y
	var d: int = 5 * du * du + 4 * dr * dr  # a distância à peça, ao quadrado, em unidades de 32 px
	match look:
		"jardim":  # ao calhas, losango a losango: é o que ficou melhor
			var roll: int = rt.randi() % 100
			return 2 if roll < 2 else 1 if roll < 24 else 0
		"cisterna":  # um canal que sai da grade e serpenteia até ao fim da sala; e umas poças soltas
			if has and absi(du - (absi((dr + 4) % 16 - 8) - 4) / 2) <= (2 if _sep_blot(nz, u, row, 3) > 120 else 1):
				return 1
			return 1 if _sep_patch(nz, u, row + 64, 4, 188) else 0
		"forno":  # cinza ao pé da boca, brasas à volta, e lajes mais longe
			var edge: int = 96 + _sep_blot(nz, u, row, 4) / 2 + _sep_blot(nz, u + 7, row + 3, 2)
			if not has:
				return 1 if _sep_patch(nz, u, row, 4, 190) else 0
			return 1 if d * 256 < 36 * edge else 2 if d * 256 < 140 * edge else 0
		"tumulo":  # o corredor de mármore: a direito de propósito
			return 1 if has and absi(du) <= 3 else 0
	# O ossário: manchas de ossos, mais ao pé do nicho
	return 1 if _sep_patch(nz, u, row, 5, 178 - (maxi(0, 320 - d) / 3 if has else 0)) else 0


## O centro do losango mais perto (a conta do chão de plan_sep): os adereços soltos ficam no meio de um ladrilho, nunca numa junta.
func _sep_tile(at: Vector2) -> Vector2:
	var tw := 256.0 * TILE_SCALE
	var hh := TILE_HH * TILE_SCALE
	var row := roundi((at.y - SEP_ORIGIN.y) / hh) + 2
	var half: float = tw / 2.0 if row % 2 == 1 else 0.0
	return SEP_ORIGIN + Vector2(-tw + (roundi((at.x - SEP_ORIGIN.x - half) / tw) + 1) * tw + half, -hh * 2.0 + row * hh)


## O Sepulcro da chave key: a mesma chave dá o mesmo mapa nos dois telemóveis, sem o mapa viajar.
func plan_sep(key: int) -> Dictionary:
	var d: int = key % 1000
	var kind := sep_kind(d)
	var rule := sep_rule(key)
	var s := 7717 + key * 15485
	var r := RandomNumberGenerator.new()  # as salas e os corredores
	r.seed = s
	var rp := RandomNumberGenerator.new()  # os adereços
	rp.seed = s + 1
	var rt := RandomNumberGenerator.new()  # o ladrilho de cada casa de chão
	rt.seed = s + 2
	# O caminho: 3 linhas de lotes, sempre para a frente: não há como encravar nem é preciso tentar outra vez
	var lots := []
	var col: int = r.randi() % 3
	for line in 3:
		lots.append(Vector2i(col, line))
		if line == 2:
			break
		var to: int = r.randi() % 3
		if line == 1 and lots.size() == 2 and to == col:  # pelo menos 4 salas
			to = (col + 1) % 3
		if lots.size() + absi(to - col) > 5:  # e no máximo 6
			to = col + signi(to - col)
		while col != to:
			col += signi(to - col)
			lots.append(Vector2i(col, line))
	var flow: int = r.randi() % 4  # de baixo para cima, de cima para baixo, ou de lado
	lots = lots.map(func(v): return [Vector2i(v.x, 2 - v.y), v, Vector2i(v.y, v.x), Vector2i(2 - v.y, v.x)][flow])
	var n: int = lots.size()
	var fights: Array = ["bando", "emboscada"] + (["sineiros"] if d >= 3 else [])
	var rooms := []
	for i in n:
		var type: String = "entrada" if i == 0 else "chefe" if i == n - 1 else fights[r.randi() % fights.size()]
		rooms.append(_sep_room(lots[i], type, mini(i + 1, n - 1), r))
	var links := []
	for i in n - 1:
		links.append(_sep_link(rooms, i, i + 1, kind.wide, r))
	# 1 ou 2 salas de desvio, em lotes livres ao lado de uma sala; no Forno ligam a todas as vizinhas (uma volta). O Cofre
	# fica sempre num beco (S10: uma só porta de sangue). No Labirinto das Carcaças (#191) a capela liga a todas as
	# vizinhas e há uma 3.ª sala, um Bando sem saída, se houver lote livre
	var sides: Array = ["capela", "cofre"] if r.randi() % 2 == 0 else ["cofre", "capela"]
	var sure: bool = atlas_has((d - 1) / 5, "capela")  # #185: a Capela garantida do Atlas é sempre uma das salas de desvio (o r tira o mesmo: o caminho não muda)
	var maze: bool = rule == "carcacas"
	var count: int = 1 + r.randi() % 2
	if sure:  # a Capela primeiro, e o Cofre que o sorteio trazia fica (só com uma sala de desvio, a Capela tirava-lhe o lugar)
		count = 2 if sides[0] == "cofre" else count
		sides = ["capela", "cofre"]
	for k in count + (1 if maze else 0):
		var hub: Array = range(lots.size()).filter(func(o): return rooms[o].type != "cofre")  # nada se liga ao Cofre: um 2.º corredor entrava sem pagar
		var near := []
		for ly in 3:
			for lx in 3:
				var q := Vector2i(lx, ly)
				if not q in lots and hub.any(func(o): return absi(lots[o].x - q.x) + absi(lots[o].y - q.y) == 1):
					near.append(q)
		if near.is_empty():
			break
		var lot: Vector2i = near[r.randi() % near.size()]
		var adj: Array = hub.filter(func(o): return absi(lots[o].x - lot.x) + absi(lots[o].y - lot.y) == 1)
		var what: String = sides[k] if k < count else "bando"
		rooms.append(_sep_room(lot, what, adj[0], r))
		lots.append(lot)
		for o in adj:
			if o == adj[0] or ((kind.loop or maze) and what == "capela"):
				links.append(_sep_link(rooms, o, rooms.size() - 1, kind.wide, r))
	var gates := _sep_gates(rooms, links, n, rule)
	var torches := []  # Abismo dos Esquecidos (#211): duas Tochas Negras à boca de cada corredor do caminho e uma a meio dele
	if rule == "esquecidos":
		for i in n - 1:
			var lw: Rect2 = links[i].world
			var ax: Vector2 = _link_axis(rooms, links[i])
			var to: float = signf((rooms[i + 1].center - rooms[i].center).dot(ax))
			var mouth: Vector2 = lw.get_center() - ax * to * (lw.size.dot(ax) / 2.0 + 60.0)
			torches.append_array([mouth + ax.orthogonal() * 90.0, mouth - ax * to * 70.0 - ax.orthogonal() * 90.0, lw.get_center()])
	var grid := PackedByteArray()
	grid.resize(SEP_SIDE * SEP_SIDE)
	grid.fill(0)
	for i in rooms.size():
		var ra: Rect2i = rooms[i].rect
		for y in range(ra.position.y, ra.end.y):
			for x in range(ra.position.x, ra.end.x):
				grid[x + y * SEP_SIDE] = i + 1
	for l in links:
		var la: Rect2i = l.rect
		for y in range(la.position.y, la.end.y):
			for x in range(la.position.x, la.end.x):
				grid[x + y * SEP_SIDE] = SEP_LINK
	# As paredes saem da grelha: o que se vê é o que trava. A margem de 1 casa deixa ver os vizinhos sem testar limites
	var props := []
	var prop_c: Color = kind.prop
	var pick := func(names: Array) -> String: return names[rp.randi() % names.size()]
	var tw := 256.0 * TILE_SCALE
	var hh := TILE_HH * TILE_SCALE
	# As portas: a saída fica longe de onde se nasce (o botão de interagir é também a esquiva); a do chefe a norte da sala dele
	var first: Rect2 = rooms[0].world
	var last: Dictionary = rooms[n - 1]
	var exit: Vector2 = first.get_center() + Vector2(0, -first.size.y / 2.0 + 50.0)
	var shift := 0  # a descida tem de ter parede atrás: sobre a boca de um corredor, as escadas flutuavam. Anda de meio em meio ladrilho até lá, longe da outra porta (só inteiros)
	var door0: int = (last.rect.position.x * 4 + last.rect.size.x * 2) * 704 - 2200
	for off in 40:
		var to: int = (off + 1) / 2 * 704 * (-1 if off % 2 == 1 else 1)
		var c0: int = (door0 + to - 1000) / 2816
		var c1: int = (door0 + to + 1000) / 2816
		if c0 >= last.rect.position.x and c1 < last.rect.end.x and grid[c0 + (last.rect.position.y - 1) * SEP_SIDE] == 0 and grid[c1 + (last.rect.position.y - 1) * SEP_SIDE] == 0 and absi(to - 4400) >= 2400:
			shift = to
			break
	var down: Vector2 = last.center + Vector2(-220.0 + shift / 10.0, -last.world.size.y / 2.0 + 50.0)
	var up: Vector2 = last.center + Vector2(220, -last.world.size.y / 2.0 + 50.0)
	if rule == "esquecidos":  # C (g): as duas tochas da boca ficam a uma casa (200 px do centro) dos portais, das escadas e dos recipientes: o par vai mais para dentro da sala ou mais para os lados
		var big: Array = [exit, down, up] + gates.filter(func(g): return g[1] == "sangue").map(func(g): return g[3])
		var clear := func(at: Vector2, room: Rect2) -> bool: return room.grow(-40.0).has_point(at) and big.all(func(o): return o.distance_to(at) >= TORCH_GAP)
		for i in n - 1:
			var lw: Rect2 = links[i].world
			var ax: Vector2 = _link_axis(rooms, links[i])
			var to: float = signf((rooms[i + 1].center - rooms[i].center).dot(ax))
			var pair := []
			for depth in [60.0, 130.0, 200.0, 270.0, 340.0]:  # o 1.º é o sítio de sempre
				for side in [90.0, 160.0, 230.0]:
					for lag in [70.0, -70.0]:  # Lote 7 C (i): uma mais funda do que a outra (à mesma altura pareciam um par numa fila)
						var c: Vector2 = lw.get_center() - ax * to * (lw.size.dot(ax) / 2.0 + depth)
						var c2: Vector2 = lw.get_center() - ax * to * (lw.size.dot(ax) / 2.0 + depth + lag)
						if pair.is_empty() and depth + lag >= 40.0 and clear.call(c + ax.orthogonal() * side, rooms[i].world) and clear.call(c2 - ax.orthogonal() * side, rooms[i].world):
							pair = [c + ax.orthogonal() * side, c2 - ax.orthogonal() * side]
			if not pair.is_empty():
				torches[3 * i] = pair[0]
				torches[3 * i + 1] = pair[1]
	# As armadilhas e as gárgulas ficam nas últimas 3 salas (a do chefe primeiro: o Guardião tem os martelos à volta)
	var spots := []
	for i in range(n - 1, n - 4, -1):
		spots.append(rooms[i].center + Vector2(-280, -130))
		spots.append(rooms[i].center + Vector2(280, 130))
	# Os adereços soltos: no meio de um ladrilho, longe das portas, das armadilhas e uns dos outros. Sem lugar, não há adereço
	var taken: Array = [exit, down, up] + spots + torches + gates.filter(func(g): return g[1] == "sangue").map(func(g): return g[3])  # e os recipientes de sangue e as tochas
	var put := func(what: String, spot: Vector2, gap: float, turn: bool) -> bool:
		var q: Vector2 = _sep_tile(spot)
		if taken.any(func(o): return o.distance_to(q) < gap) or gates.any(func(g): return g[2].grow(80.0).has_point(q)) or rooms.any(func(o): return o.feature != null and o.world.has_point(q) and absf(q.x - o.feature.x) < 300.0):  # o eixo da peça (o canal, o corredor de mármore) e as portas (um monte de crânios caía em cima das lajes) ficam livres
			return false
		_sep_prop(props, what, q, rp, prop_c, turn)
		taken.append(q)
		return true
	# A peça de cada sala, na parede norte: no troço mais comprido, no meio ladrilho mais perto do meio da parede, longe das portas. Os pares à volta dela, espelhados e fora da grelha dos ladrilhos.
	# Só inteiros (x em décimos de píxel a contar de SEP_ORIGIN; uma casa tem 2816 x 1991, meio ladrilho 704): o que isto decide tem de dar o mesmo nos dois telemóveis
	var ww: int = int(SEP_WALL) * 10
	var marks := []  # o losango debaixo da peça de cada sala (o chão segue-a); x < 0 sem peça
	var paired := []
	var door_free := func(i: int, at: Vector2i) -> bool:
		var ra: Rect2i = rooms[i].rect
		var mid: int = (ra.position.x * 4 + ra.size.x * 2) * 704
		var doors: Array = [mid] if i == 0 else [mid - 2200 + shift, mid + 2200] if i == n - 1 else []
		var dy: int = at.y - ra.position.y * 1991 - 500
		return doors.all(func(o): return (at.x - o) * (at.x - o) + dy * dy >= 2890000)
	for i in rooms.size():
		var ra: Rect2i = rooms[i].rect
		var y: int = ra.position.y
		var mid: int = ra.position.x * 4 + ra.size.x * 2
		var u0 := -1
		var lo := 0
		var hi := 0
		if kind.feature != "" or rooms[i].type == "capela":
			var x: int = ra.position.x
			var best := Vector2i.ZERO
			while x < ra.end.x:
				var x1 := x
				while x1 < ra.end.x and grid[x1 + (y - 1) * SEP_SIDE] == 0:
					x1 += 1
				if x1 - x > best.y - best.x:
					best = Vector2i(x, x1)
				x = maxi(x1, x + 1)
			lo = best.x * 4 - (1 if grid[best.x - 1 + y * SEP_SIDE] == 0 else 0)
			hi = best.y * 4 - 1
			var aim: int = clampi(mid - 1, lo + 5, hi - 5) if hi - lo >= 10 else (lo + hi) / 2  # com lugar para os pares, se o troço der
			if rooms[i].type == "capela":  # a capela é a peça da sala dela (as velas vêm abaixo): o chão segue-a, sem pares e sem peça na parede
				u0 = aim
				rooms[i].feature = SEP_ORIGIN + Vector2(aim * 704, y * 1991 + 400) / 10.0
			else:
				for off in 40:  # de dentro para fora
					var u: int = aim + (off + 1) / 2 * (1 if off % 2 == 1 else -1)
					if u * 704 - ww / 2 >= lo * 704 - (0 if grid[best.x - 1 + y * SEP_SIDE] == 0 else 50) and u * 704 + ww / 2 <= hi * 704 and door_free.call(i, Vector2i(u * 704, y * 1991 - 60)):
						u0 = u
						rooms[i].feature = SEP_ORIGIN + Vector2(u * 704, y * 1991 - 60) / 10.0
						taken.append(rooms[i].feature)
						break
		marks.append(Vector2i(u0, 4 * y + 2))
		if u0 < 0 or rooms[i].type == "capela":
			continue
		for pair in kind.pairs:
			var off: int = pair[1] if pair[1] > 0 else (mini(u0 - lo, hi - u0) - 2) * 704  # 0: perto das pontas da parede
			var fits: bool = off > ww / 2
			for sx in [-1, 1]:
				var at := Vector2i(u0 * 704 + sx * off, y * 1991 - 60 + pair[2] * 10)
				if not door_free.call(i, at):
					fits = false
				for cx in [(at.x - 700) / 2816, (at.x + 700) / 2816]:  # no chão desta sala, com parede atrás e longe da boca de um corredor
					if grid[cx + y * SEP_SIDE] != i + 1 or grid[cx + (y - 1) * SEP_SIDE] != 0 or grid[cx - 1 + y * SEP_SIDE] == SEP_LINK or grid[cx + 1 + y * SEP_SIDE] == SEP_LINK:
						fits = false
			if fits:
				for sx in [-1, 1]:
					var q: Vector2 = SEP_ORIGIN + Vector2(u0 * 704 + sx * off, y * 1991 - 60 + pair[2] * 10) / 10.0
					props.append([pair[0], q, float(PROPS[pair[0]][1]), sx > 0, prop_c])
					taken.append(q)
					paired.append(q)
	# O que cada sala tem de ter
	var lights := []
	var glows := []
	for i in rooms.size():
		var room: Dictionary = rooms[i]
		var w: Rect2 = room.world
		var far: bool = (marks[i].x >= 0 and marks[i].x < room.rect.position.x * 4 + room.rect.size.x * 2 - 1) or (i == n - 1 and shift < -704)  # a peça para oeste, ou a descida no canto oeste: a lanterna de cima passa para o outro canto, para não ficar à frente delas
		for at in [Vector2(w.end.x - 90.0 if far else w.position.x + 90.0, w.position.y + 90.0), w.end - Vector2(90, 40)]:  # duas lanternas nos cantos
			var lamp: Vector2 = _sep_tile(at)
			_sep_prop(props, "lantern", lamp, rp, Color.WHITE)
			taken.append(lamp)
			lights.append([lamp, 150.0])
			glows.append([lamp, 70.0])
		match room.type:
			"emboscada":
				for q in room.spots:
					_sep_prop(props, "coffin_open", q, rp, prop_c)
				taken.append_array(room.spots)
			"capela":
				_sep_prop(props, "chapel", room.feature, rp, Color.WHITE)
				taken.append(room.feature)
				for sx in [-90.0, 90.0]:
					_sep_prop(props, "candles", room.center + Vector2(sx, 0), rp, Color.WHITE)
					glows.append([room.center + Vector2(sx, 0), 50.0])
	# As bordas: poucas coisas e um ladrilho para dentro, longe dos dentes do chão, nunca em duas casas seguidas da mesma borda nem num corredor de 1 casa (ficavam a meio do caminho)
	var low: Array = kind.south.filter(func(o): return PROPS[o][1] <= 70.0)  # a sul só coisas baixas, para não tapar o herói
	var edge := {}
	for y in SEP_SIDE:
		for x in SEP_SIDE:
			if grid[x + y * SEP_SIDE] == 0:
				continue
			var top: Vector2 = SEP_ORIGIN + Vector2(x, y) * SEP_CELL
			var to_n: bool = grid[x + (y - 1) * SEP_SIDE] == 0
			var to_s: bool = grid[x + (y + 1) * SEP_SIDE] == 0
			var to_e: bool = grid[x + 1 + y * SEP_SIDE] == 0
			if to_e != (grid[x - 1 + y * SEP_SIDE] == 0) and rp.randf() < 0.35 and not edge.has(Vector3i(x, y - 1, int(to_e))):
				var t: float = 0.75 if to_n else 0.25 if to_s else 0.25 + 0.5 * (rp.randi() % 2)
				var at: Vector2 = top + (Vector2(tw, SEP_CELL.y * (t - 0.25)) if to_e else Vector2(tw / 2.0, SEP_CELL.y * t))
				if put.call(pick.call(kind.side), at, 170.0, to_e):
					edge[Vector3i(x, y, int(to_e))] = true
			if to_s and not to_n and rp.randf() < 0.3 and not edge.has(Vector3i(x - 1, y, 2)) and put.call(pick.call(low), top + SEP_CELL / 2.0, 170.0, false):
				edge[Vector3i(x, y, 2)] = true
	# O recheio: até 2 por sala, no que as bordas deixaram, longe do meio (relicário, chefe, início) e da boca dos corredores
	for room in rooms:
		var w: Rect2 = room.world
		var fill := 0
		for tries in 9:
			var q: Vector2 = _sep_tile(w.position + Vector2(140 + rp.randi() % int(w.size.x - 350.0), 100 + rp.randi() % int(w.size.y - 250.0)))
			if fill < 2 and q.distance_to(room.center) > 220.0 and not links.any(func(l): return l.world.grow(170.0).has_point(q)) and put.call(pick.call(kind.south), q, 200.0, false):
				fill += 1
	# A parede norte, troço a troço, de canto a canto: vai de onde a fila de cima do chão começa (meio ladrilho antes da casa, se aí houver vazio) até onde acaba (meio ladrilho antes do fim). Peças iguais lado a lado, com os pés na linha; nada a sair por cima do vazio.
	# Sobrepostas pelo menos 10 px (os pilares são mais estreitos do que os capitéis: coladas, via-se o vazio entre eles); a peça da sala vem por cima e as lisas enchem o resto de cada lado
	for y in SEP_SIDE:
		var x := 0
		while x < SEP_SIDE:
			var x1 := x
			while x1 < SEP_SIDE and grid[x1 + y * SEP_SIDE] != 0 and grid[x1 + (y - 1) * SEP_SIDE] == 0:
				x1 += 1
			if x1 > x and kind.feature == "":  # a ruína do Jardim: solta, com árvores à frente
				var from: float = SEP_ORIGIN.x + x * SEP_CELL.x - (tw / 2.0 if grid[x - 1 + y * SEP_SIDE] == 0 else 0.0)
				var span: float = SEP_ORIGIN.x + x1 * SEP_CELL.x - tw / 2.0 - from
				var steps: int = ceili((span - SEP_RUIN) / SEP_RUIN) if span > SEP_RUIN * 1.6 else 0
				var bare := 2  # as peças de parede desde a última coisa à frente: é o que se quer ver
				for k in steps + 1:
					var at := Vector2(from + SEP_RUIN / 2.0 + (span - SEP_RUIN) * k / steps if steps > 0 else from + span / 2.0, SEP_ORIGIN.y + y * SEP_CELL.y - 6.0)
					_sep_prop(props, kind.north[0], at, rp, prop_c)
					var more: String = pick.call(kind.north)
					bare += 1
					if more != kind.north[0] and bare > 2 and absf(at.x - down.x) > 200.0:  # à frente da parede, nunca em vez dela: a parede não tem buracos; e nunca à frente das escadas
						_sep_prop(props, more, at + Vector2(0, 2), rp, prop_c)
						bare = 0
			elif x1 > x:
				var run0: int = x * 2816 - (704 if grid[x - 1 + y * SEP_SIDE] == 0 else 0)
				var run1: int = x1 * 2816 - 704
				var cuts: Array = []
				for i in rooms.size():
					if rooms[i].rect.position.y == y and rooms[i].type != "capela" and marks[i].x >= 0 and marks[i].x * 704 >= run0 and marks[i].x * 704 <= run1:
						cuts.append(marks[i].x * 704)
				cuts.sort()
				var a := run0
				for cut in cuts + [-1]:
					var b: int = cut - ww / 2 + 100 if cut >= 0 else run1
					if b > a:
						var steps: int = (b - a - 101) / (ww - 100) if b - a > ww else 0  # ceil((b - a - ww) / (ww - 100))
						for k in steps + 1:
							var mx: int = a + ww / 2 + (b - a - ww) * k / steps if steps > 0 else clampi((a + b) / 2, run0 + ww / 2, run1 - ww / 2)
							props.append([kind.north[0], SEP_ORIGIN + Vector2(mx, y * 1991 - 60) / 10.0, 170.0, false, prop_c])
					a = cut + ww / 2 - 100
				for cut in cuts:
					props.append([kind.feature, SEP_ORIGIN + Vector2(cut, y * 1991 - 60) / 10.0, 170.0, false, prop_c])
			x = maxi(x1, x + 1)
	props.append(["waypoint_on", exit, 110.0, false, Color.WHITE])
	props.append(["sep_stairs", down + Vector2(0, -56), 170.0, false, Color.WHITE])  # os pés na linha da parede; sep.down, onde se carrega, fica à frente delas
	props.append(["waypoint_on", up, 110.0, false, Color.WHITE])
	for at in [exit, down, up]:
		lights.append([at, 120.0])
		glows.append([at, 80.0])
	for at in torches:
		lights.append([at, 130.0])
	# Os losangos: cada casa de chão pinta os dela e, à volta, a orla mais escura, para os pés nunca pisarem o vazio.
	# Só inteiros. Um losango toca na casa se um canto da sua caixa lá cair: filas 4y+1 a 4y+7, colunas 2x+1 a 2x+3 (2x a 2x+3 nas filas ímpares)
	var cols := SEP_SIDE * 2 + 4
	var nrows := SEP_SIDE * 4 + 6
	var mask := PackedByteArray()
	mask.resize(nrows * cols)
	mask.fill(0)
	for y in SEP_SIDE:
		for x in SEP_SIDE:
			if grid[x + y * SEP_SIDE] == 0:
				continue
			var fl: int = 2 if grid[x + y * SEP_SIDE] == SEP_LINK else 2 + grid[x + y * SEP_SIDE]  # 2: corredor; 3 ou mais: a sala (grelha + 2)
			for row in range(4 * y + 1, 4 * y + 8):
				for c in range(2 * x + (1 if row % 2 == 0 else 0), 2 * x + 4):
					var core: bool = row >= 4 * y + 2 and row <= 4 * y + 5 and c >= 2 * x + 1 and c <= 2 * x + 2
					if core:
						mask[row * cols + c] = fl
					elif mask[row * cols + c] == 0:
						mask[row * cols + c] = 1
	var sz := TILE_SCALE * 1.03  # um pouco maior para não haver frestas, como plan_map
	var dark_c: Color = Color(kind.tile).darkened(0.75)  # a orla: o herói não pisa isto, e é o que desenha a parede
	var rows := []
	var kinds := []
	var nz := PackedByteArray()  # o ruído do chão: sai da chave
	nz.resize(1024)
	for i in 1024:
		nz[i] = rt.randi() % 256
	for row in nrows:
		var line := []
		line.resize(cols)  # null onde não há chão
		for c in cols:
			var m: int = mask[row * cols + c]
			if m == 0:
				continue
			var fl := 0
			if m > 2:
				fl = _sep_ground(kind.look, 2 * c + row % 2 - 2, row, marks[m - 3], nz, rt)
			elif m == 2 and kind.look != "tumulo" and rt.randi() % 25 == 0:  # os corredores: o ladrilho de base, raras vezes outro
				fl = 1
			var tk: String = kind.floor[fl]
			var tex: Texture2D = TILES[tk]
			var pos: Vector2 = SEP_ORIGIN + Vector2(-tw + c * tw + (tw / 2.0 if row % 2 == 1 else 0.0), -hh * 2.0 + row * hh)  # a mesma conta de plan_map (main:3392)
			line[c] = [tex, Rect2(pos.x - 128.0 * sz, pos.y - TILE_LV[tk] * sz, 256.0 * sz, tex.get_height() * sz), dark_c if m == 1 else kind.tints[0] if m == 2 else kind.tints[fl]]
			kinds.append(tk)
		rows.append(line)
	var path: Array = rooms.slice(0, n).map(func(q): return q.center)
	return {"grid": grid, "rooms": rooms, "links": links, "rows": rows, "props": props, "lights": lights, "glows": glows, "path": path, "spots": spots, "n": n,
		"start": first.get_center(), "exit": exit, "down": down, "up": up, "boss": last.center, "paired": paired, "gates": gates, "torches": torches, "sure": sure,
		"sum": hash([grid, kinds, props.map(func(q): return q[0]), gates.map(func(g): return [g[0], g[1]])])}


## Ao comprido de um corredor: RIGHT entre salas lado a lado, DOWN entre uma por cima da outra (a conta de _sep_link).
func _link_axis(rooms: Array, l: Dictionary) -> Vector2:
	var a: Rect2i = rooms[l.a].rect
	var b: Rect2i = rooms[l.b].rect
	return Vector2.RIGHT if a.end.x <= b.position.x or b.end.x <= a.position.x else Vector2.DOWN


## S10, as portas dos Sepulcros: [corredor, tipo, a faixa que fecha (a casa do meio do corredor, de lado a lado), o ponto
## onde se carrega, o rumo do corredor]. Saem da chave, iguais nos dois telemóveis. Uma por corredor: o do Cofre é de sangue (#32, o
## recipiente fica do lado do caminho, a 120 px); com a regra, as costelas (#28: os do caminho menos o 1.º e os de
## desvio), as carcaças (#191: os do caminho do 2.º em diante) ou os selos (#219: os das salas de luta).
func _sep_gates(rooms: Array, links: Array, n: int, rule: String) -> Array:
	var out := []
	var fights := ["bando", "emboscada", "sineiros"]
	for i in links.size():
		var l: Dictionary = links[i]
		var kd := ""
		if rooms[l.b].type == "cofre":
			kd = "sangue"
		elif rule == "costelas" and i >= 1:
			kd = "costela"
		elif rule == "carcacas" and i >= 1 and i < n - 1:
			kd = "carcaca"
		elif rule == "canopos" and (rooms[l.a].type in fights or rooms[l.b].type in fights):
			kd = "selo"
		if kd == "":
			continue
		var c: Rect2i = l.rect
		var ax := _link_axis(rooms, l)
		var mid := Rect2i(c.position.x + c.size.x / 2, c.position.y, 1, c.size.y) if ax.x > 0.0 else Rect2i(c.position.x, c.position.y + c.size.y / 2, c.size.x, 1)
		var band := Rect2(SEP_ORIGIN + Vector2(mid.position) * SEP_CELL, Vector2(mid.size) * SEP_CELL)
		var at: Vector2 = band.get_center()
		if kd == "sangue":  # encostado a um lado do corredor: quem passa ao meio não o tapa
			at -= ax * signf((rooms[l.b].center - at).dot(ax)) * (band.size.dot(ax) / 2.0 + 120.0) - ax.orthogonal() * minf(band.size.dot(ax.orthogonal().abs()) / 2.0 - 50.0, 90.0)
		out.append([i, kd, band, at, ax])
	return out


## Monta o plano neste telemóvel (nos dois: é o que se vê; as colisões só as usa o anfitrião). A direito, sem fatias: corre debaixo do negro de hud.fade().
func sep_build() -> void:
	_sep_clear()
	sep = plan_sep(sep_key)
	sep_built = sep_key
	sep_grid = sep.grid
	sep_aim = 1
	var from := tall.size()
	for q in sep.props:
		var tex: Texture2D = PROPS[q[0]][0]
		var sp := _prop(tex, q[1], q[2] / tex.get_height(), q[3], sep_node)
		sp.modulate = q[4]
		if q[0] == "sep_stairs" or q[1] == sep.up:
			sep_doors.append(sp)
	sep_tall = tall.slice(from)  # o _prop escreve em tall: fica lá só o mundo
	tall.resize(from)
	floor_node.queue_redraw()


func _sep_clear() -> void:
	for c in sep_node.get_children():
		c.queue_free()
	sep = {}
	sep_built = 0
	sep_tall = []
	sep_doors = []


## Nos dois telemóveis, antes do return do convidado. Testa o estado a cada frame: a chave e a zona podem chegar por qualquer ordem (net:531), e de uma profundidade para outra a zona não muda.
func _sep_tick() -> void:
	if zone != "sep":
		return
	if (sep_built != sep_key or (Net.is_guest() and sep.get("sure", false) != atlas_has((sep_depth() - 1) / 5, "capela"))) and sep_key > 0:  # #185: no convidado, a Capela garantida pode chegar depois da chave (o anfitrião só a compra no cemitério)
		sep_build()
		zone_view(player.position)
	if sep.is_empty():
		return
	for q in players:
		var id := sep_room_at(q.position)
		if id >= 0:
			sep.rooms[id].seen = true
	for sp in sep_doors:
		sp.modulate = Color.WHITE if sep_done == 1 else Color(0.35, 0.35, 0.4)


## Toque no Portão: nem a meio de um Cortejo, de um evento ou de um modo. Cada ida é um mapa novo. oil: o Atlas ungiu-a com um
## Óleo de Lápide (#227), que se gasta já.
func sep_enter(d: int, oil := false) -> void:
	var why := mode_block()
	if why != "":
		hud.toast(why)
		return
	sep_oil = oil and mats.get("oleo_lapide", 0) > 0
	if sep_oil:
		mats.oleo_lapide -= 1
	sep_runs += 1
	sep_streak = 0
	sep_max0 = sep_max
	_sep_go(d)
	sep_bank = currency.merged(mats)  # depois: o saque do mundo e o relicário por abrir (_change_zone) vieram de fora, não contam como apanhados nesta ida; G5: os materiais também, para a volta


## Uma profundidade: chave nova, mapa novo, e o _change_zone guarda o saque e o relicário.
func _sep_go(d: int) -> void:
	guardian = null
	guardian_met = false
	sep_key = sep_runs * 1000 + mini(d, 999)
	sep_done = 0
	crypt_rule = sep_rule(sep_key)
	sep_elites = (1 if d < 8 else 2 if d < 13 else 3) + (4 if sep_oil else 0)
	sep_big = 4 if sep_oil else 0
	sep_build()
	_change_zone("sep", sep.start)
	gates = sep.gates.map(func(_g): return 0)  # S10: todas fechadas (as de costelas seguem a hora)
	var mods := lvl_mods(sep_level())
	_sep_boss(d, mods)
	_rule_setup(sep.path, sep.spots, Vector2.RIGHT, mods)
	hud.name_card(sep_kind(d).name, CRYPT_RULES[crypt_rule][1] if crypt_rule != "" else "Derrota o chefe e abre o relicário.", tr("Profundidade %d · Untada") % d if sep_oil else tr("Profundidade %d") % d)
	sfx("bell", 0.7)
	save_game()


func sep_descend() -> void:
	sep_streak += 1
	_sep_go(sep_depth() + 1)


func sep_leave() -> void:
	guardian = null
	sep_streak = 0
	sep_oil = false  # #227: o óleo dura a ida
	var reached := sep_depth()
	_change_zone("world", GATE + Vector2(0, -230))  # fora dos 170 px da dica do Portão: senão a esquiva voltava a descer
	var got := {}
	var said := []
	var now: Dictionary = currency.merged(mats)  # G5: os materiais apanhados também se dizem
	for k in now:
		if now[k] > sep_bank.get(k, 0):
			got[k] = now[k] - sep_bank.get(k, 0)
			said.append("%s x%d" % [tr(Loot.INFO[k][0]), got[k]])
	if got.is_empty():
		hud.toast("De volta ao cemitério.")
	else:  # B6: um painel com o que trouxe, até onde chegou e o recorde; o convidado fica com o aviso
		Net.echo("hud", "toast", [tr("Trouxeste %s.") % ", ".join(said) + ("\n" + tr("Recorde: profundidade %d.") % sep_max if sep_max > 0 else "")])  # sem chefe vencido não há recorde
		hud.open_run_end(got, reached, sep_max, sep_max > sep_max0)
	save_game()


## No anfitrião, 4 vezes por segundo (o relógio de _camps_tick): as salas só se enchem com um herói lá dentro, porque o aggro não vê paredes.
func _sep_wake() -> void:
	if zone != "sep" or sep.is_empty():
		return
	for q in players:
		var id := sep_room_at(q.position)
		if q.dead or id < 0 or sep.rooms[id].woken:
			continue
		var room: Dictionary = sep.rooms[id]
		if room.type == "emboscada" and q.position.distance_to(room.center) > 250.0:  # os caixões esperam que chegues ao meio
			continue
		if room.type == "capela" and players.all(func(h): return h.away or (not h.dead and h.hp >= h.max_hp * 0.95)):  # de vida cheia não se gasta: fica para quando for preciso (o herói à espera da ligação, #91, não conta)
			if not room.has("told"):
				room.told = true
				hud.toast("Uma capela: volta cá quando precisares.")
			continue
		match room.type:
			"capela":  # Capela: sem tocar em nada, a vida e as poções voltam; quem caiu levanta-se
				room.woken = true
				for h in players:
					if h.away:  # #91: à espera da ligação ninguém o levanta (o player_back repõe-no como estava)
						continue
					if h.dead:
						h.revive()
					h.heal(h.max_hp)
					h.fill_potions(99.0)
					spawn_fx("glow", h.position + Vector2(0, -40), 90.0, Color(0.4, 1.0, 0.65))
				sfx("potion")
				hud.toast("Uma capela: a vida e as poções voltam.")
			"cofre":  # Cofre de Sangue (#32): nunca no caminho obrigatório; já se pagou à porta (o recipiente, S10): o mesmo que o relicário da Sentinela e um reagente
				room.woken = true
				_bank_chest()
				_spawn_chest(_sep_rew(sep_level(), cofre_k()) + [[_reagent(), 1]], room.center)
			_:
				var pack: int = 8 if room.type == "emboscada" else mini(5 + sep_depth() / 5, 8)
				if enemies().size() + pack <= mini(SEP_CAP, DENSITY[settings.density]):  # o teto conta a sala que vai nascer; senão espera. A "Quantidade de monstros" vale aqui também: é a alavanca sem APK novo
					room.woken = true
					_sep_pack(room, pack)
					if crypt_rule == "canopos":
						_seal(id, q)
					elif crypt_rule == "poco":  # Poço da Danação (#49): as lajes rachadas da sala
						_crack(id)
	if crypt_rule == "canopos":  # as câmaras herméticas abrem-se com a sala limpa
		for i in sep.rooms.size():
			if sep.rooms[i].get("sealed", false) and not enemies().any(func(e): return sep_room_at(e.position) == i):
				sep.rooms[i].sealed = false
		for i in sep.gates.size():
			if sep.gates[i][1] == "selo" and i < gates.size():
				var l: Dictionary = sep.links[sep.gates[i][0]]
				gates[i] = 1 if [l.a, l.b].any(func(o): return sep.rooms[o].get("sealed", false)) else 0


## Salões do Embalsamador (#219): dois vasos à volta de cada ponto, um à frente e outro atrás (espelhados num ponto sim, num
## não), postos à mão: um em cada ponto, viam-se numa fila a direito.
func _jar_pairs(at: Array) -> Array:
	var out := []
	for i in at.size() * 2:
		out.append([at[i / 2] + JAR_PAIR[i % 2] * Vector2(1.0 if (i / 2) % 2 == 0 else -1.0, 1.0), 0])
	return out


## Salões do Embalsamador (#219), câmaras herméticas: a sala de luta que acorda fecha os corredores (selos de pedra) até
## ficar limpa, com 4 vasos canópicos ao pé das portas (os das salas já limpas saem). O herói de pé que ficou de fora, até 900 px, vem
## para dentro, ao ponto da sala mais perto dele.
func _seal(id: int, by) -> void:
	var room: Dictionary = sep.rooms[id]
	room.sealed = true
	var doors: Array = sep.gates.filter(func(g): return g[1] == "selo" and id in [sep.links[g[0]].a, sep.links[g[0]].b]).map(func(g): return g[2].get_center())
	var by_door: Array = room.spots.duplicate()  # os dois pares nos pontos mais perto das portas que a sala fecha: quem chega vê-os logo
	by_door.sort_custom(func(a, b): return doors.reduce(func(m, o): return minf(m, a.distance_to(o)), INF) < doors.reduce(func(m, o): return minf(m, b.distance_to(o)), INF))
	jars = jars.filter(func(j): return sep.rooms[maxi(sep_room_at(j[0]), 0)].get("sealed", false)) + _jar_pairs(by_door.slice(0, 2))
	jars = jars.slice(maxi(0, jars.size() - 8))
	var inner: Rect2 = room.world.grow(-90.0)
	for h in players:
		if h != by and not h.dead and sep_room_at(h.position) != id and h.position.distance_to(room.center) < 900.0:
			h.position = h.position.clamp(inner.position, inner.end)
			spawn_fx("dust", h.position, 70.0, Color.WHITE)
			number(h.position + Vector2(0, -120), tr("Selado!"), 22.0, Color(0.85, 0.8, 0.7))
	spawn_fx("ring", room.center, 300.0, Color(0.75, 0.7, 0.62))
	sfx("bell", 0.5)


## Bando, Emboscada (#195) ou Sineiros (#206): pack mortos a sair do pó, espalhados à volta da sala; os elites da profundidade vão saindo nos primeiros.
func _sep_pack(room: Dictionary, pack: int) -> void:
	var d := sep_depth()
	var kind := sep_kind(d)
	var mods := lvl_mods(sep_level())
	for i in pack:
		var at: Vector2 = room.spots[i * 3 % 8]  # 0, 3, 6, 1...: os pontos 0 a 3 ficavam todos na metade sul
		var e = spawn_enemy("specter" if rng.randf() < kind.spec else "skeleton", at, mods, false)
		_wear(e)
		e.paint = kind.paint if e.skin == "" else Color.WHITE
		e.tier = d / 5 * 2  # o XP e o saque sobem a cada 5 profundidades
		e.aggro = 260.0 if crypt_rule == "silencio" else INF  # Sanctum do Silêncio (#46): sono pesado
		spawn_fx("dust", at, 40.0, Color.WHITE)
		if room.type == "sineiros" and i >= pack - 2:  # 2 sinos e não o bando todo: cada um traz um colosso. Antes dos elites: com o Óleo (#227) eram todos elites e a sala ficava sem sinos
			e.ringer_at = -1.0  # ring_bell serve tal e qual: o colosso chama-se Reforço, sem o Frasco de chefe
		elif sep_elites > 0:
			sep_elites -= 1
			e.make_elite()
			if sep_big > 0:  # Óleo de Lápide (#227): os 4 primeiros elites de cada profundidade, colossais
				sep_big -= 1
				e.size *= 1.3
				e.radius *= 1.3
				e.max_hp *= 1.5
				e.hp = e.max_hp
				e.hp_chunk = e.max_hp
	if room.type == "emboscada":
		sfx("bell", 0.6)
		hud.toast("Emboscada!")
	elif room.type == "sineiros":
		hud.toast("Sineiros: cala-os ou vem um colosso.")


## Há mortos na sala deste herói? Com eles o botão continua a ser a esquiva: ninguém sai nem paga por engano a meio de uma luta. Conta só a sala dele: um morto preso do outro lado da parede não tranca a porta.
func sep_calm(q) -> bool:
	var id := sep_room_at(q.position)
	return id < 0 or not enemies().any(func(e): return sep_room_at(e.position) == id)


## Nasce a dormir no meio da sala dele, como o Carcereiro. Sentinela no fim de cada profundidade; a cada 5, o guardião do bloco.
func _sep_boss(d: int, mods: Dictionary) -> void:
	var guard: bool = d % 5 == 0
	var guards: Array = sep_block(d).guard
	var pick: String = guards[sep_key / 1000 % guards.size()] if guard else ""  # S13: um guardião a cada ida (sep_runs vai na chave: os dois telemóveis concordam)
	var big: bool = pick in ["guardiao", "arauto"]  # já têm 2,3 vezes a vida do colosso
	if pick == "donzelas":  # Lote 9, #187: as três; o guardião é a 1.ª e passa à irmã que fica (_on_enemy_killed)
		var three: Array = Bosses.maidens(self, sep.boss, {"hp": mods.hp * 1.8, "dmg": mods.dmg * 1.2})
		for o in three:
			o.aggro = 480.0
			o.tier = d / 5 * 2
		guardian = three[0]
		return
	guardian = spawn_enemy(Bosses.spawn_kind(pick), sep.boss, {"hp": mods.hp * (1.0 if big else 1.8 if guard else 1.4), "dmg": mods.dmg * (1.2 if guard else 0.9)}, false)
	guardian.title = "Arauto Fúnebre" if pick == "arauto" else "Sentinela"
	guardian.paint = sep_kind(d).paint
	guardian.aggro = 480.0
	guardian.tier = d / 5 * 2
	if not guard:  # maior do que um Reforço; a 1.ª de cada bloco é a mais calma: as outras têm a Marca à distância e o golpe final com botão, sem o resto do make_elite
		guardian.grow(1.25)
		guardian.elite = d % 5 != 1
	elif pick == "arauto":  # com as fases do Cortejo
		guardian.rage_at = 0.5
		guardian.haste = 1.35
		guardian.reach = 1.3
	else:
		Bosses.make(guardian, pick)
		if pick == "monge":  # dorme mesmo: _monk não olha para awake e correr faz barulho; sem isto saía da sala antes de o verem
			guardian.heard = INF


## O relicário do Cofre: o bónus de seguidas, x 1,5 com o Óleo de Lápide (#227) e x 1,5 com o Cofre mais rico do Atlas (#185).
func cofre_k() -> float:
	return (1.0 + sep_bonus() / 100.0) * (1.5 if sep_oil else 1.0) * (1.5 if atlas_has((sep_depth() - 1) / 5, "cofre") else 1.0)


## #185: o bloco b (profundidades 5b+1 a 5b+5) tem a melhoria id do Atlas?
func atlas_has(b: int, id: String) -> bool:
	return b >= 0 and b < atlas.length() and (atlas[b].hex_to_int() & (1 << ATLAS_UP.keys().find(id))) != 0


## #185: compra a melhoria id do bloco b com Estacas Fúnebres (só no anfitrião: o Atlas é dele). Só os blocos que o Atlas mostra.
func buy_atlas(b: int, id: String) -> bool:
	if not ATLAS_UP.has(id) or b < 0 or b > sep_max / 5 or b >= ATLAS_MAX or atlas_has(b, id) or mats.get("estaca", 0) < ATLAS_UP[id][1]:
		return false
	mats.estaca -= ATLAS_UP[id][1]
	atlas = atlas.rpad(b + 1, "0")
	atlas = atlas.left(b) + String.num_int64(atlas[b].hex_to_int() | (1 << ATLAS_UP.keys().find(id)), 16) + atlas.substr(b + 1)
	save_game()
	return true


## Olho Mumificado do Primeiro Rei (#258): algum herói o tem posto (o minimapa e o brilho do Cofre são de todos).
func eye_on() -> bool:
	return players.any(func(q): return q.stat("olho") > 0.0)


## O relicário de uma Sentinela e o do Cofre: nunca dá 0 de nada.
func _sep_rew(a: int, k: float) -> Array:
	return [["bone", int(4.0 * loot_mult(a) * k)], ["ink", int((2 + a / 5) * k)], ["ash", int((1 + a / 8) * k)]]


## O chefe caiu: o relicário no meio da sala (no chão, mesmo que ele tenha caído noutro lado) e as duas saídas abrem-se.
func _sep_boss_down(e) -> void:
	var d := sep_depth()
	var a := sep_level()
	var m := loot_mult(a)
	var k := (1.0 + sep_bonus() / 100.0) * (1.25 if crypt_rule == "carcacas" else 1.2 if crypt_rule == "esquecidos" else 1.0) * (1.5 if sep_oil else 1.0)  # o Labirinto (#191) e o Abismo (#211) pagam o caminho mais difícil; o Óleo de Lápide (#227), x 1,5
	var blk: int = (d - 1) / 5  # #185: as melhorias do Atlas deste bloco
	var rew: Array
	var relic := false  # a Relíquia em falta (ou a Foice Longa) mostrou o cartão dela
	if d % 5 == 0:  # a fórmula da cripta x 1,5, um reagente certo e 20% de Coração
		rew = [["bone", int(9.0 * m * k)], ["ink", int((2 + a / 3) * 1.5 * k)], ["ash", int((1 + a / 4) * 1.5 * k)], [_reagent(), 1], ["cinza_maior", 1]]  # G5: e umas Cinzas Maiores
		if rng.randf() < (0.5 if atlas_has(blk, "coracao") else 0.2):
			rew.append(["coracao", 1])
		if d > sep_max:  # a 1.ª vitória sobre este guardião: a Relíquia em falta (há 5); sem nenhuma, cinzas a dobrar
			collect(drop("estaca", e.position, 2 if d in [25, 50] else 1, Vector2.UP * 140.0))  # #185: e as Estacas Fúnebres do Atlas, já (como a Relíquia: sep_max fica gravado e o relicário não)
			var gone: Array = RELICS.keys().filter(func(q): return not q in relics)
			if gone.is_empty():
				rew[2][1] *= 2
			else:
				collect(drop("relic", e.position, 1, Vector2.from_angle(rng.randf() * TAU) * 140.0, gone[rng.randi() % gone.size()]))  # já: sep_max fica gravado e o saque do chão não
				relic = true
		if not "foice_longa" in forms:  # G7: o guardião da profundidade 5 dá a Foice Longa (já, como a Relíquia); a quem já o tinha vencido antes desta versão, o próximo guardião
			collect(drop("arma", e.position, 1, Vector2.from_angle(rng.randf() * TAU) * 140.0, "foice_longa"))
			relic = true  # o cartão dela (ou o aviso, por baixo do da Relíquia): a Bolsa vai num aviso
	else:
		rew = _sep_rew(a, k) + ([[_common_mat(), 1]] if d >= 3 else [])  # G5: a Sentinela, da profundidade 3 em diante, um material comum
		if d >= 6 and rng.randf() < 0.1:  # #227: e, da 6 em diante, 1 vez em 10, um Óleo de Lápide
			rew.append(["oleo_lapide", 1])
	sep_done = 1
	for h in holes:  # Poço da Danação (#49): os buracos da sala do chefe fecham-se com ele
		if h[3] == INF and h[2] > 0.0:
			h[3] = time
	var first_guard: bool = d % 5 == 0 and d > sep_max
	sep_max = maxi(sep_max, d)
	var bag_line := ""
	if first_guard and d <= 15 and bags < 3:  # Bolsas de Almas (#72): os 3 primeiros guardiões, uma vez, para ninguém as perder
		bags += 1
		var more: String = tr("+4 lugares na mochila (%d de 20)") % player.bag_cap()
		if relic:  # a Relíquia em falta acabou de mostrar o cartão dela: a Bolsa vai no aviso do guardião vencido (um lugar a menos na fila)
			bag_line = tr("%s: %s") % [tr("Bolsa de Almas"), more] + "\n"
		else:
			hud.name_card("Bolsa de Almas", more, "")
	_bank_chest()  # só há um relicário de cada vez: o do Cofre por abrir vai para as moedas
	_spawn_chest(rew, sep.boss + Vector2(0, 60))
	if d % 5 == 0 and atlas_has(blk, "pecas"):  # #185: O guardião larga 2 peças (mágicas ou raras, com as forças dos chefes)
		for i in 2:
			drop_gear(roll_gear(1 + rng.randi() % 2, true), e.position, Vector2.from_angle(rng.randf() * TAU) * 140.0)
	hud.toast(bag_line + (tr("Guardião vencido: já podes começar na profundidade %d.") % (d + 1) if first_guard else tr("Abre o relicário. Depois, sobe ou arrisca mais fundo.")))
	save_game()


## Dentro de uma sala, para a abertura que leva à seguinte (de uma sala de desvio, de volta); num corredor, para a sala a que ele vai dar. Com o chefe caído, primeiro o relicário: quem seguia a seta descia e levava-o sem o estrondo. É local: não precisa de guardian, que no convidado costuma faltar.
func _sep_goal() -> Vector2:
	if sep.is_empty():
		return player.position
	if sep_done == 1:
		return chest.position if is_instance_valid(chest) and not chest.opened and not chest.locked else sep.down
	var id := sep_room_at(player.position)
	if id >= 0:
		sep_aim = sep.rooms[id].next
		for l in sep.links:
			if id != sep_aim and id in [l.a, l.b] and sep_aim in [l.a, l.b]:
				return l.world.get_center()
	return sep.rooms[sep_aim].center


# ---------- Cenário ----------

## Adereços são Sprite2D com os pés na origem, para o y-sort pôr os heróis atrás deles.
func _prop(tex: Texture2D, pos: Vector2, sc: float, flip := false, to: Node = self) -> Sprite2D:
	var sp := Sprite2D.new()
	sp.texture = tex
	sp.offset = Vector2(0, -tex.get_height() / 2.0)
	sp.scale = Vector2(sc, sc)
	sp.flip_h = flip
	sp.position = pos
	to.add_child(sp)
	# Os altos (estátuas, lanternas, árvores, capelas, o monumento, as escadas da cripta) tapam quem passa atrás (#92);
	# guarda-se só o meio do desenho: as pontas são quase só vazio
	var box := tex.get_size() * sc
	if box.y >= 100.0:
		tall.append(Rect2(pos.x - box.x * 0.3, pos.y - box.y, box.x * 0.6, box.y))
	return sp


func _hub_rect() -> Rect2:
	return Rect2(monument_pos - HUB_SPOT, HUB.get_size())


## O número do mapa de agora: muda com o Círculo e a cada vitória. O 103 não pode ser múltiplo de 6 menos 1: a vitória
## normal (Círculo +1, vitórias +1) tem de mudar REGION_ORDER.
func map_seed() -> int:
	return circle + wins * 103


## O mapa do número c, no sítio, sem recarregar a cena. slice: em jogo, reparte o trabalho por vários frames.
func build_map(c: int, slice := true) -> void:
	c = maxi(c, 1)  # no convidado vem da rede
	map_circle = c
	map_job += 1
	map_busy = true
	var job := map_job
	var t0 := Time.get_ticks_usec()
	var plan: Dictionary = await plan_map(c, slice, job)
	if plan.is_empty():
		return  # uma reconstrução mais nova ficou com o lugar
	map_ms = (Time.get_ticks_usec() - t0) / 1000.0
	for e in enemies():
		if e.camp >= 0:
			e.queue_free()  # os bandos do mapa antigo; o que falta matar (camp_left) segue para o novo
	map_spots = plan.spots
	region_now = ""  # as zonas mudaram de sítio
	camps = plan.camps
	map_tex = plan.tex
	map_hash = plan.sum
	tile_rows = plan.rows
	tall = tall_fixed.duplicate()
	glows = glows_fixed.duplicate()
	floor_node.queue_redraw()
	if slice and cortejo.wave == 0 and zone == "world" and not mode_on():  # o negro tapa a troca, e o sino diz que o cemitério mudou (cada telemóvel o seu); na cripta não se vê, e se a onda ou o modo começou durante a troca não se corta a luta
		hud.fade()
		sfx("bell", 0.7, true)
		if hud.toast_t <= 0.0:
			hud.toast("O cemitério mudou.", true)
	var old := scenery.get_children()
	for i in maxi(old.size(), plan.props.size()):
		if i < old.size():
			old[i].queue_free()
		if i < plan.props.size():
			_place(plan.props[i])
		if slice and i % 60 == 59:
			await get_tree().process_frame
			if job != map_job or not is_inside_tree():
				return
	tiles.queue_redraw()  # os brilhos novos: tiles só se desenha uma vez por mapa
	map_busy = false
	map_builds += 1


## O mapa do número c, sem tocar em nós nem no rng do jogo: o mesmo c dá o mesmo mapa nos dois telemóveis.
func plan_map(c: int, slice := false, job := 0) -> Dictionary:
	var until := Time.get_ticks_usec() + MAP_SLICE_US
	var s := 6661 + c * 7919
	var r := RandomNumberGenerator.new()  # os centros e os acampamentos
	r.seed = s
	var rp := RandomNumberGenerator.new()  # os adereços
	rp.seed = s + 1
	var rt := RandomNumberGenerator.new()  # uma jogada por ladrilho, sempre consumida
	rt.seed = s + 2
	var rn := RandomNumberGenerator.new()  # os adereços "new" (0.4.7), à parte: rp segue igual, a praça e os lugares não mudam
	rn.seed = s + 3
	var noise := FastNoiseLite.new()
	noise.seed = s
	noise.frequency = 0.0012
	var noise2 := FastNoiseLite.new()
	noise2.seed = s + 13
	noise2.frequency = 0.004
	var hub := _hub_rect()
	var spots := {"campo": Vector2(0, 1650)}
	var order: Array = REGION_ORDER[(c - 1) % REGION_ORDER.size()]
	for i in order.size():
		spots[order[i]] = REGION_SPOTS[i] + Vector2(r.randf_range(-250.0, 250.0), r.randf_range(-200.0, 200.0))
	# Acampamentos: o 1.º do Campo é o do primeiro minuto; sem lugar, o centro da região (nunca parte o jogo)
	var sites := []
	for id in ["campo"] + order:
		for k in CAMPS_PER:
			var site: Vector2 = spots[id]
			for i in 200:
				var q: Vector2 = spots[id] + Vector2.from_angle(r.randf() * TAU) * r.randf_range(400.0, 1200.0)
				if MAP.grow(-280.0).has_point(q) and not hub.grow(220.0).has_point(q) and absf(q.x) > 420.0 and q.distance_to(CRYPT_DOOR) > 800.0 and q.distance_to(GATE) > 600.0 \
						and q.distance_to(Vector2(0, 300)) > 1200.0 and q.distance_to(monument_pos) > 1500.0 and _region_in(q, spots, hub) == id \
						and sites.all(func(o): return o.pos.distance_to(q) > 900.0) and (not sites.is_empty() or q.y < 1900.0):
					site = q
					break
			sites.append({"pos": site, "region": id})
	# Adereços: primeiro os de cada acampamento, depois os soltos (pesos acumulados por região; grelha de 256 px para não se atropelarem)
	var picks := {}
	for id in REGIONS:
		var names := []
		var sums := []
		var total := 0
		for n in PROPS:
			total += PROPS[n][2] * REGIONS[id].props.get(n, 1)
			names.append(n)
			sums.append(total)
		picks[id] = [names, sums, total]
	var props := []
	var big := [[CRYPT_DOOR, 170.0], [GATE, 300.0]]
	for site in sites:
		big.append([site.pos, 300.0])
		for st in REGIONS[site.region].stamp:
			props.append([st[0], site.pos + st[1], float(PROPS[st[0]][1]), false, REGIONS[site.region].prop])
	var inner := hub.grow(-260.0)
	var cells := {}
	for i in PROP_CAP * 4:
		if props.size() >= PROP_CAP:
			break
		if slice and Time.get_ticks_usec() > until:
			await get_tree().process_frame
			if job != map_job or not is_inside_tree():
				return {}
			until = Time.get_ticks_usec() + MAP_SLICE_US
		var pos := Vector2(rp.randf_range(MAP.position.x + 40, MAP.end.x - 40), rp.randf_range(MAP.position.y + 40, MAP.end.y - 40))
		if inner.has_point(pos) or (absf(pos.x) < 230.0 and pos.y > 0.0):
			continue
		var id := _region_in(pos, spots, hub)
		var kind: String = picks[id][0][picks[id][1].bsearch(rp.randi() % picks[id][2], false)]
		var h: float = PROPS[kind][1] * rp.randf_range(0.9, 1.1)
		var rad := h * 0.4
		var free := true
		for b in big:
			if pos.distance_to(b[0]) < rad + b[1]:
				free = false
				break
		var cell := Vector2i((pos / 256.0).floor())
		for x in range(-1, 2):
			for y in range(-1, 2):
				for o in cells.get(cell + Vector2i(x, y), []):
					if free and pos.distance_to(o[0]) < rad + o[1]:
						free = false
		if not free:
			continue
		if not cells.has(cell):
			cells[cell] = []
		cells[cell].append([pos, rad])
		var fresh: Array = REGIONS[id].get("new", [])
		if not fresh.is_empty() and rn.randf() < REGION_NEW:  # shortcut: a folga (rad) fica a do que saiu, um novo mais alto pode roçar num vizinho; mudar só se se notar
			var other: String = fresh[rn.randi() % fresh.size()]
			h *= PROPS[other][1] / PROPS[kind][1]
			kind = other
		props.append([kind, pos, h, rp.randf() < 0.5, Color(REGIONS[id].prop).darkened(rp.randf() * 0.2)])
	# Chão: losangos em fila, cada fila meia célula ao lado da anterior. O limite entre zonas lê a região um pouco ao lado (o ruído), para não ser uma linha reta
	var w := 256.0 * TILE_SCALE
	var hh := TILE_HH * TILE_SCALE
	var sz := TILE_SCALE * 1.03  # um pouco maior para não haver frestas entre losangos
	var rows := []
	var kinds := []
	var img := Image.create(64, 48, false, Image.FORMAT_RGB8)  # o minimapa: 100 px por píxel
	for row in int(MAP.size.y / hh) + 6:
		if slice and Time.get_ticks_usec() > until:
			await get_tree().process_frame
			if job != map_job or not is_inside_tree():
				return {}
			until = Time.get_ticks_usec() + MAP_SLICE_US
		var line := []
		for col in int(MAP.size.x / w) + 4:
			var pos := Vector2(MAP.position.x - w + col * w + (w / 2.0 if row % 2 == 1 else 0.0), MAP.position.y - hh * 2.0 + row * hh)
			var n := noise.get_noise_2d(pos.x, pos.y)
			var n2 := noise2.get_noise_2d(pos.x, pos.y)
			var id := _region_in(pos + Vector2(n, n2) * 220.0, spots, hub)
			var kind := _tile_at(id, pos, n, n2, rt.randf())
			var tex: Texture2D = TILES[kind]
			line.append([tex, Rect2(pos.x - 128.0 * sz, pos.y - TILE_LV[kind] * sz, 256.0 * sz, tex.get_height() * sz), REGIONS[id].tile])
			kinds.append(kind)
			var px := Vector2i(((pos - MAP.position) / 100.0).floor())
			if px.x >= 0 and px.y >= 0 and px.x < 64 and px.y < 48:
				img.set_pixelv(px, Color(0.1, 0.2, 0.3) if kind == "water" else Color(0.6, 0.55, 0.4) if kind.begins_with("cobble") else REGIONS[id].map)
		rows.append(line)
	return {"rows": rows, "props": props, "camps": sites, "spots": spots, "tex": ImageTexture.create_from_image(img), "sum": hash([kinds, props, sites])}


## Um adereço do plano: [nome, pos, altura, flip, cor].
func _place(q: Array) -> void:
	var tex: Texture2D = PROPS[q[0]][0]
	_prop(tex, q[1], q[2] / tex.get_height(), q[3], scenery).modulate = q[4]
	if q[0] in ["lantern", "candles"]:
		glows.append([q[1], 70.0 if q[0] == "lantern" else 50.0])


func _region_in(pos: Vector2, spots: Dictionary, hub: Rect2) -> String:
	if hub.has_point(pos):
		return "praca"
	var best := "campo"
	var near := INF
	for id in spots:
		var d: float = pos.distance_squared_to(spots[id])
		if d < near:
			near = d
			best = id
	return best


func region_at(pos: Vector2) -> String:
	return _region_in(pos, map_spots, _hub_rect())


## O nome da zona aparece ao entrar nela, só neste telemóvel (player é o herói dele).
func _region_tick(delta: float) -> void:
	region_t -= delta
	if region_t > 0.0:
		return
	region_t = 0.5
	if zone != "world" or cortejo.wave > 0 or mode_on():
		return
	var r := region_at(player.position)
	var text: String = REGIONS[r].name
	if player.position.distance_to(GATE) < 260.0:
		r = "portao"
		text = "O Portão dos Reis está aberto: desce aos Sepulcros." if wins >= 1 else "O Portão dos Reis está fechado. Quebra o Cortejo Fúnebre para o abrir."
	if text != "" and r != region_now and hud.toast_t <= 0.0:  # a praça não conta: voltar dela à mesma zona não repete o nome; e o nome espera pelo aviso que estiver à vista
		region_now = r
		hud.toast(text, true)


## O nome por cima de um lugar fixo do cemitério (as escadas da cripta, o Portão dos Reis).
func _name_label(text: String, at: Vector2, color: Color) -> void:
	var label := Label.new()
	label.text = text
	label.position = at
	label.size = Vector2(400, 32)
	label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	label.add_theme_font_size_override("font_size", 32)
	label.add_theme_color_override("font_color", color)
	label.add_theme_color_override("font_outline_color", Color.BLACK)
	label.add_theme_constant_override("outline_size", 6)
	add_child(label)
	place_labels.append(label)


## O nome de um lugar fixo como se vê no ecrã: a largura do texto, ao meio da Label.
func place_label_rect(l: Label) -> Rect2:
	var tw: float = l.get_theme_font("font").get_string_size(tr(l.text), HORIZONTAL_ALIGNMENT_LEFT, -1, l.get_theme_font_size("font_size")).x
	return l.get_global_transform_with_canvas() * Rect2((l.size.x - tw) / 2.0, 0.0, tw, l.size.y)


## O que não muda com o mapa, feito uma vez: as escadas, o monumento, o altar, a estrada de estátuas e o Portão dos Reis.
func _gen_fixed() -> void:
	_prop(CRYPT_DOOR_TEX, CRYPT_DOOR, 200.0 / CRYPT_DOOR_TEX.get_height())
	glows.append([CRYPT_DOOR + Vector2(0, 10), 100.0])
	_name_label("Cripta dos Condenados", CRYPT_DOOR + Vector2(-200, -248), Color(0.55, 1.0, 0.7))
	monument = _prop(MON, monument_pos, 230.0 / MON.get_height())
	var deco := [[preload("res://art/props/waypoint_on.png"), Vector2(-150, 420), 80.0], [preload("res://art/props/shrine_on.png"), SHRINE, 90.0]]
	for d in deco:
		_prop(d[0], d[1], d[2] / d[0].get_height())
		glows.append([d[1], 80.0])
	var statue: Texture2D = PROPS.statue[0]
	for y in range(680, 1961, 320):
		for x in [-190.0, 190.0]:
			_prop(statue, Vector2(x, y), PROPS.statue[1] / statue.get_height(), x > 0.0).modulate = REGIONS.campo.prop
	var gate: Texture2D = PROPS.gatehouse[0]
	gate_node = _prop(gate, GATE, 300.0 / gate.get_height())
	glows.append([GATE, 100.0])
	_name_label("Portão dos Reis", GATE + Vector2(-200, -348), Color(1.0, 0.85, 0.4))
	tall_fixed = tall.duplicate()
	glows_fixed = glows.duplicate()


func _tile_at(id: String, pos: Vector2, n: float, n2: float, roll: float) -> String:
	if absf(pos.x) < 110.0 and pos.y > 300.0 and pos.y < GATE.y + 50.0:  # a estrada da praça ao Portão dos Reis
		return "cobble_moss" if roll < 0.35 else "cobble"
	match id:
		"bosque":
			if n < -0.3:
				return "slab_roots" if roll < 0.4 else "mud"
			return "mud" if n > 0.25 else "bones" if roll < 0.02 else "grass"
		"pantano":
			if n2 > 0.1:
				return "water"
			return "slab_roots" if roll < 0.06 else "grass" if n < -0.1 else "mud"
		"ossario":
			if n2 > 0.1:
				return "bones"
			if n < 0.1:
				return "slab_roots" if roll < 0.3 else "slab"
			return "bones" if roll < 0.35 else "mud"
		"campo":  # lajes e ossos em terra cor de ferrugem: é a primeira zona que se vê e não pode ser o chão de sempre
			if n < -0.12 or pos.distance_to(GATE) < 420.0:
				return "slab_roots" if roll < 0.3 else "slab"
			if roll < 0.18:
				return "bones"
			return "mud" if n > 0.05 else "grass"
	if n2 > 0.55:  # a orla da praça: o chão de sempre
		return "water"
	if n < -0.38:
		return "slab_roots" if roll < 0.3 else "slab"
	if roll < 0.05:
		return "bones"
	return "mud" if n > 0.2 else "grass"


## O chão redesenha-se quando a câmara se afasta FLOOR_STEP do ponto à volta do qual foi desenhado. Uma âncora e não uma
## grelha: o tremor da câmara (cada golpe) trocava de casa quase todos os frames em cima de uma linha, e x = 0 é uma linha.
func _floor_tick() -> void:
	var at := cam.get_screen_center_position()
	if absf(at.x - floor_at.x) > FLOOR_STEP or absf(at.y - floor_at.y) > FLOOR_STEP:
		floor_at = at
		floor_node.queue_redraw()


## O que o chão tem de cobrir. 0,85: o zoom mais largo (arena); a folga é o passo e a saia dos ladrilhos.
func _floor_view() -> Rect2:
	var half := get_viewport_rect().size / 2.0 / 0.85 + Vector2.ONE * (FLOOR_STEP + 160.0)
	return Rect2(floor_at - half, half * 2.0)


## Os ladrilhos à volta da câmara, por ordem de filas: cada um tem uma saia que a fila seguinte tapa.
func _draw_floor() -> void:
	var rows: Array = sep.get("rows", []) if zone == "sep" else tile_rows
	var from: Vector2 = SEP_ORIGIN if zone == "sep" else MAP.position
	if zone != "sep":
		floor_node.draw_rect(MAP.grow(200.0), Color(0.05, 0.07, 0.06))
	var view := _floor_view()
	var w := 256.0 * TILE_SCALE
	var hh := TILE_HH * TILE_SCALE
	var r0 := clampi(int((view.position.y - from.y) / hh) + 2, 0, rows.size())
	var r1 := clampi(int((view.end.y - from.y) / hh) + 3, 0, rows.size())
	for r in range(r0, r1):
		var row: Array = rows[r]
		var c0 := clampi(int((view.position.x - from.x) / w), 0, row.size())
		var c1 := clampi(int((view.end.x - from.x) / w) + 3, 0, row.size())
		for c in range(c0, c1):
			var t = row[c]
			if t != null:  # nos Sepulcros há vazio
				floor_node.draw_texture_rect(t[0], t[1], false, t[2])
	if zone == "sep":  # os brilhos ficam aqui: glows e tiles são do mundo
		var glow: Texture2D = Fx.Pix.glow_tex()
		for g in sep.get("glows", []):
			floor_node.draw_texture_rect(glow, Rect2(g[0] - Vector2.ONE * g[1], Vector2.ONE * g[1] * 2.0), false, Color(0.35, 1.0, 0.6, 0.2))


## A praça, a cripta e os brilhos: desenhados uma vez por mapa.
func _draw_tiles() -> void:
	tiles.draw_texture_rect(HUB, _hub_rect(), false)
	tiles.draw_texture_rect(CRYPT, Rect2(CRYPT_ORIGIN, CRYPT.get_size()), false)
	var glow: Texture2D = Fx.Pix.glow_tex()
	for g in glows + CRYPT_GLOWS.map(func(p): return [CRYPT_ORIGIN + p, 140.0]):
		tiles.draw_texture_rect(glow, Rect2(g[0] - Vector2.ONE * g[1], Vector2.ONE * g[1] * 2.0), false, Color(0.35, 1.0, 0.6, 0.2))


func _draw_world() -> void:
	for pool in blood:  # Sangue no Solo (#23): poça escura que seca no último segundo
		var a: float = clampf(pool[1] - time, 0.0, 1.0)
		Pix.haze(ground, pool[0], BLOOD_R, BLOOD_R, Pix.RAMPS.bleed[3], 0.75 * a)
		Pix.haze(ground, pool[0] + Vector2(6, -4), BLOOD_R * 0.5, BLOOD_R * 0.5, Pix.RAMPS.bleed[2], 0.6 * a)
	for c in corpses:  # Espasmo Cadavérico: crânios com a cor do estado de quem morreu; piscam no último segundo e meio
		var tex: Texture2D = PROPS["skulls"][0]
		var sz := tex.get_size() * (28.0 / tex.get_height())
		var a: float = 0.9 if c[2] - time > 1.5 else 0.5 + 0.5 * sin(time * 12.0)
		ground.draw_texture_rect(tex, Rect2(c[0] - sz / 2.0, sz), false, Color(CORPSE_COLORS[c[1]], a))
	warned = {}
	for tooth in teeth:  # Dentes de Sepultura: três pontas de osso que se desfazem, a encolher aos degraus
		var h: float = ceilf(minf(1.0, tooth[1]) * 3.0) * 4.0
		for k in 3:
			Pix.solid(ground, tooth[0] + Vector2((k - 1) * 9.0, (k % 2) * 4.0), [Vector2(-4, 2), Vector2(4, 2), Vector2(0, -h)], "bone")
	for s in sentinels:  # Sentinelas Tumulares (#25): a lápide fincada, assente pelo pé como os adereços; desfaz-se no último segundo
		var tex: Texture2D = PROPS["grave_broken"][0]
		var w: float = 52.0 * tex.get_width() / tex.get_height()
		ground.draw_texture_rect(tex, Rect2(s[0] - Vector2(w / 2.0, 52.0), Vector2(w, 52.0)), false, Color(0.8, 0.88, 0.84, clampf(s[1] - time, 0.0, 1.0)))
	if cortejo.active and "mares" in cortejo.affixes:  # Marés de Sangue Negro (#212): o chão da arena escurece a vermelho nos 3 s de aviso e fica assim na maré
		var flood: float = clampf((time - tide_start + 3.0) / 3.0, 0.0, 1.0) if time < tide_start + 8.0 else 0.0
		Pix.flood(ground, monument_pos, ARENA_R, _view_rect(), Color(0.35, 0.0, 0.04), 0.5 * flood)
	for s in shelters():  # Chamas Negras (#35) e as lajes do Cortejo (S8): discos de pedra com um anel de runas a rodar devagar
		Pix.slab(ground, s[0], s[1], time)
	for k in rocks:  # Minas de Enxofre (#43): pedras amarelas a brilhar; a armada pisca a branco até rebentar
		Pix.haze(ground, k[0], 32.0, 32.0, Color(1.0, 0.9, 0.3), 0.45 + 0.125 * sin(time * 3.0))
		ground.draw_set_transform(k[0])
		ground.draw_colored_polygon(PackedVector2Array(ROCK), Color(1.0, 1.0, 0.85) if k[1] > 0.0 and int(time * 16.0) % 2 == 0 else Color(1.0, 0.9, 0.3))
		ground.draw_polyline(PackedVector2Array(ROCK + [ROCK[0]]), Color(0.35, 0.25, 0.05), 2.0)
		ground.draw_set_transform(Vector2.ZERO)
	for h in hammers:  # Forja das Almas Escravas (#184): a bigorna, um disco de ferro escuro; o aviso enche no último 1,2 s
		Pix.anvil(ground, h[0], 90.0)
		var w: float = 1.0 - (h[1] - time) / 1.2
		if w > 0.0:  # como o aviso do murro do Colosso
			Pix.warn(ground, h[0], 90.0, w)
	for b in belts():  # Moinho de Carne (#202): a passadeira com setas a andar para a serra, e a serra de 12 dentes a rodar
		Pix.belt(ground, b[0], b[1], 130.0, 35.0, time)
		Pix.saw(ground, b[0] + b[1] * 130.0, time)
	if zone == "sep" and not sep.is_empty():  # S10: as portas, os recipientes e as tochas negras (o convidado desenha-os do plano e de gates)
		var view := _view_rect().grow(160.0)
		for i in sep.gates.size():
			if view.intersects(sep.gates[i][2]) or view.has_point(sep.gates[i][3]):
				_draw_gate(i, sep.gates[i])
		if eye_on():  # Olho do Primeiro Rei (#258): o Cofre por pisar pulsa a azul de 2 em 2 s (cada telemóvel o seu; seen muda nos dois, woken só no anfitrião)
			var k: float = fposmod(time, 2.0) / 2.0
			for r in sep.rooms:
				if r.type == "cofre" and not r.seen and view.has_point(r.center):  # revisão final: um selo de pedaços e runas, achatado como o chão (o anel fino a crescer lia-se como um círculo liso)
					Pix.ward(ground, r.center, 128.0, k)
		for at in sep.torches:  # Abismo dos Esquecidos (#211): um pau de ferro com a chama negra
			if view.has_point(at):
				Pix.haze(ground, at + Vector2(0, -70), 30.0, 30.0, Color(0.55, 0.3, 0.9), 0.3)
				Pix.solid(ground, at, [Vector2(-4, 0), Vector2(-3, -64), Vector2(3, -64), Vector2(4, 0)], "iron", 5)
				Pix.solid(ground, at + Vector2(0, -62), [Vector2(-9, 0), Vector2(-7, -8), Vector2(7, -8), Vector2(9, 0)], "iron", 4)
				Pix.stand(ground, Pix.flame_tex("necro", (int(time * 8.0) + int(at.x)) % 4, 1.3), at + Vector2(0, -68))
	for j in jars:  # Salões do Embalsamador (#219): o vaso de osso com a tampa dourada (4 cabeças); aberto, só o vaso com a boca escura
		var head: int = int(absf(j[0].x + j[0].y)) % JAR_LIDS.size()
		Pix.haze(ground, j[0] + Vector2(0, -2), 20.0, 7.0, Color.BLACK, 0.55)
		Pix.solid(ground, j[0], JAR_BODY, "bone", 3)
		Pix.solid(ground, j[0], JAR_SHADE, "bone", 5, Color.WHITE, false)  # a sombra de um lado e o brilho do outro: lisos, eram cúpulas às riscas
		Pix.solid(ground, j[0], JAR_SHINE, "bone", 1, Color.WHITE, false)
		Pix.solid(ground, j[0], JAR_BAND, "soulblue", 5)
		if j[1] == 0:
			for lid in JAR_LIDS[head]:
				Pix.solid(ground, j[0], lid, "gold", 4)
		else:
			Pix.haze(ground, j[0] + Vector2(0, -34), 10.0, 4.0, Pix.SOOT, 0.9, false)
	if not pools.is_empty() or not holes.is_empty() or not webs.is_empty():
		_draw_ground(_view_rect().grow(120.0))
	if not event.is_empty():  # S9: o que o evento deixa no chão (o convidado desenha-o do mesmo dicionário)
		var at: Vector2 = event.pos
		match event.id:
			"fenda":  # Fenda Necrótica (#42): uma elipse violeta a pulsar, que abre nos 2 s de aviso
				var fr: float = 90.0 * clampf(1.0 - (event.at - time) / 2.0, 0.2, 1.0) + 8.0 * sin(time * 5.0)
				Pix.fenda(ground, at, fr, time, effects_level())
			"meteoro":  # Meteoro Funerário (#218): o alvo vermelho enche até cair, como os outros avisos; depois a cratera
				if time < event.at:
					Pix.warn(ground, at, 140.0, 1.0 - (event.at - time) / 3.0)
				else:
					Pix.crater(ground, at, 220.0)
					Pix.haze(ground, at + Vector2(Pix.S, Pix.S), 120.0, 120.0, Color(0.65, 0.24, 0.05), 0.2 + 0.06 * sin(time * 2.0))  # brasas soltas no fundo: mais densas faziam riscas com a fuligem; a 1 célula do meio, os pontos caem em cima dos dela
			"banquete":  # Banquete dos Espectros (#47): a carcaça do titã deitada (o último desenho da morte do colosso)
				var tex: Texture2D = Enemy.FRAMES32.colossus[31]
				var sz: Vector2 = tex.get_size() * Enemy.Feet32.SCALE.colossus32
				ground.draw_texture_rect(tex, Rect2(at - Vector2(sz.x / 2.0, sz.y), sz), false, Color(0.72, 0.78, 0.8))
	# Brilho do monumento: verde em repouso, vermelho durante o Cortejo
	var glow := Color(0.9, 0.15, 0.2) if cortejo.active else Color(0.3, 1.0, 0.6)
	var gr := 110.0 + sin(time * 3.0) * 12.0
	Pix.haze(ground, monument_pos, gr, gr, glow.darkened(0.5), 0.3)
	# Arena do chefe: muro de chamas de alma que não deixa ninguém fugir
	if arena_r > 0.0:
		Pix.wall(ground, monument_pos, arena_r, _view_rect(), time, effects_level())
	# Os avisos no fim do chão, por cima de tudo o que lá está (poças, piche a arder, lajes, a maré, o muro), como quando eram
	# do nó do monstro; e por baixo de todas as personagens (Lote 8 C (b))
	for e in enemies():  # Marca da Cova (#277): o aviso no chão enche até rebentar (a área é a mesma do golpe)
		if e.mark_end > time:
			Pix.warn(ground, e.mark_at, Enemy.MARK_R, 1.0 - (e.mark_end - time) / Enemy.MARK_T)
		e.draw_warns(ground)  # e os dos golpes e dos chefes
	ground.draw_rect(MAP, Color(0.2, 0.18, 0.15), false, 10.0)


## Lote 8 C (c): a teia do Covil do Tecelão (#36) em tendões soltos: n fios de comprimentos e ângulos desiguais, cada um
## dobrado a meio, mais grossos ao pé do nó; entre vizinhos, fios que descaem para o meio; nós de carne nas pontas. Cada
## teia sai sempre igual (do sítio dela) nos dois telemóveis; um corte tira dois fios.
func _draw_web(at: Vector2, n: int) -> void:
	var key := Vector3(at.x, at.y, n)
	if not web_shapes.has(key):
		if web_shapes.size() > 40:  # as de outras salas
			web_shapes.clear()
		web_shapes[key] = _web_shape(at, n)
	var w: Array = web_shapes[key]
	for l in w[0]:  # uma chamada por cor (eram 9 por fio, refeitos a cada frame)
		ground.draw_multiline(l[1], l[0], Pix.S)
	for tip in w[1]:
		Pix.dot(ground, tip, Pix.RAMPS.bleed[1], 2)  # agarrado ao chão
	Pix.orb(ground, at, 3, "bleed")


## Os traços da teia em at com n fios, como os do Pix.line (de célula a célula), juntos por cor, de baixo para cima: os fios
## de lado a lado, as sombras dos tendões, os tendões, o lado claro e o brilho; e onde fica a ponta de cada fio.
func _web_shape(at: Vector2, n: int) -> Array:
	var sd: int = int(at.x) * 31 + int(at.y)
	var bend := []  # [o joelho, a ponta] de cada fio
	for k in n:
		var a: float = TAU * (k + 0.55 * Pix.hashf(sd, k)) / n
		var tip: Vector2 = Vector2.from_angle(a) * WEB_R * (0.7 + 0.3 * Pix.hashf(sd, k + 20))
		bend.append([tip * (0.4 + 0.2 * Pix.hashf(sd, k + 40)) + tip.orthogonal().normalized() * (Pix.hashf(sd, k + 60) - 0.5) * 18.0, tip])
	var by := [[], [], [], [], []]
	var seg := func(i: int, a: Vector2, b: Vector2) -> void:
		by[i].append(Pix.cell(at + a) + Vector2.ONE)
		by[i].append(Pix.cell(at + b) + Vector2.ONE)
	for k in n:  # os de lado a lado, por baixo dos fios grandes: de um ponto de um fio a um do vizinho, a descair para o nó
		var b: Array = bend[k]
		var c: Array = bend[(k + 1) % n]
		var p: Vector2 = b[0].lerp(b[1], 0.3 + 0.5 * Pix.hashf(sd, k + 80))
		var q: Vector2 = c[0].lerp(c[1], 0.2 + 0.5 * Pix.hashf(sd, k + 90))
		var sag: Vector2 = (p + q) * 0.42
		seg.call(0, p, sag)
		seg.call(0, sag, q)
	var tips := []
	for b in bend:  # cada tendão com a sombra por baixo; do nó ao joelho, a dobrar de grossura
		for s in [[Vector2.ZERO, b[0]], [b[0], b[1]]]:
			seg.call(1, s[0] + Vector2(0, Pix.S), s[1] + Vector2(0, Pix.S))
			seg.call(2, s[0], s[1])
		seg.call(3, Vector2(Pix.S, 0), b[0] + Vector2(Pix.S, 0))
		seg.call(4, b[0] * 0.5, b[0])  # o brilho do tendão esticado
		tips.append(at + b[1] - Vector2(Pix.S, Pix.S))
	var cols := [Pix.RAMPS.bleed[3], Pix.RAMPS.bleed[5], Pix.RAMPS.bleed[2], Pix.RAMPS.bleed[1], Pix.RAMPS.bleed[0]]
	return [range(5).map(func(i): return [cols[i], PackedVector2Array(by[i])]), tips]


## Lote 7: as poças (S11), os buracos (S12) e as teias (#36) que a câmara apanha, em píxeis. O ácido borbulha a verde, a névoa
## anda devagar, o piche brilha a negro e, a arder, tem 3 chamas; a laje rachada é pedra com fendas, avisa como os golpes dos
## chefes e abre num buraco negro com borda; a teia são tendões vermelhos em raios e dois anéis de osso (menos raios a cada corte).
func _draw_ground(view: Rect2) -> void:
	warned["pools"] = warned.size()  # quantos tipos de aviso já estavam desenhados por baixo das poças (o teste: nenhum)
	for q in pools:
		var at: Vector2 = q[0]
		var r: float = q[1]
		if not view.has_point(at):
			continue
		var fade: float = clampf(q[2] - time, 0.0, 1.0) if q[2] < INF else 1.0
		match q[3]:
			"acido":
				Pix.haze(ground, at, r, r, Pix.RAMPS.rot[5], 0.7 * fade)
				Pix.haze(ground, at, r * 0.7, r * 0.7, Pix.RAMPS.rot[2], 0.4 * fade)
				for k in 5:  # bolhas que rebentam
					if Pix.hashf(int(time * 3.0) + k * 7, k) < 0.5:
						Pix.px(ground, at + Vector2((Pix.hashf(k, 1) - 0.5) * r * 1.2, (Pix.hashf(k, 2) - 0.5) * r * 1.2), Pix.RAMPS.rot[0], 2, 2)
			"nevoa":
				for k in 3:
					var drift := Vector2(sin(time * 0.7 + k * 2.1), cos(time * 0.5 + k)) * r * 0.25
					Pix.haze(ground, at + drift, r * 0.8, r * 0.8, Color(0.6, 0.66, 0.46), 0.35 * fade)
			"piche":  # óleo negro-castanho, mais escuro ao meio, com a borda e o reflexo (liso e todo negro parecia um buraco)
				if old_ground:  # Lote 7: um disco pontilhado; só para a captura de antes e depois
					Pix.haze(ground, at, r, r, Color(0.16, 0.11, 0.07), 0.8, false)
					Pix.haze(ground, at, r * 0.75, r * 0.75, Color(0.05, 0.03, 0.02), 0.6)
					Pix.loop(ground, at, r, r, Color(0.3, 0.2, 0.12), 1)
					for k in 4:  # o brilho do piche
						Pix.px(ground, at + Vector2(-r * 0.35 + k * 10.0, -r * 0.3 + k * 3.0), Color(0.62, 0.55, 0.48), 2 if k % 2 == 0 else 1, 1)
				else:  # Revisão das capturas do Lote 8: a borda aos gomos, com gotas e reflexos (Pix.tar_tex)
					var v := int(absf(at.x * 7.0 + at.y * 13.0)) % 4
					Pix.stamp(ground, Pix.tar_tex(r, v, false), at)
					Pix.tar_tex(r, v, true)  # a acesa coze-se já: no frame em que pega fogo, a meio da luta, era uma paragem
				if q[2] < INF:  # vai pegar fogo
					Pix.haze(ground, at, r * 0.5, r * 0.5, Pix.RAMPS.loot_ash[2], 0.5)
			"fogo":
				if old_ground:  # Lote 7: o disco liso e 3 línguas soltas (pareciam velas); só para a captura de antes e depois
					Pix.haze(ground, at, r, r, Color(0.3, 0.06, 0.02), 0.9 * fade, false)
					Pix.haze(ground, at, r * 0.7, r * 0.7, Pix.RAMPS.loot_ash[3], 0.5 * fade)
					for k in 3:
						Pix.stand(ground, Pix.flame_tex("loot_ash", (int(time * 8.0) + k) % 4, 1.4), at + Vector2(-r * 0.4 + k * r * 0.4, (k % 2) * 10.0 - 4.0))
					continue
				Pix.stamp(ground, Pix.tar_tex(r, int(absf(at.x * 7.0 + at.y * 13.0)) % 4, true), at, Color(1, 1, 1, fade))
				# Lote 8 C (c): 3 fogos de línguas juntas no meio da poça e (revisão das capturas) 5 línguas soltas até à beira, de trás
				# para a frente, e faíscas a subir; só no meio, a poça lia-se como um disco liso
				var spots := []
				for k in 8:
					var a: float = TAU * (k % 5 + 0.6 * Pix.hashf(int(at.x) + k, int(at.y))) / (3.0 if k < 3 else 5.0) + 0.4
					var far: float = 0.3 if k < 3 else 0.72
					spots.append([at + Vector2(cos(a) * r * far, sin(a) * r * far * 0.7 + 8.0), k < 3, k])
				spots.sort_custom(func(u, v): return u[0].y < v[0].y)
				for s in spots:
					var f: int = (int(time * 8.0) + s[2] * 3) % 4
					Pix.stand(ground, Pix.blaze_tex("loot_ash", f) if s[1] else Pix.flame_tex("loot_ash", f, 0.8), s[0], Color(1, 1, 1, fade))
				if effects_level() > 0:
					Pix.motes(ground, at + Vector2(0, -20), r * 0.5, 80.0, 5, time + at.x, Pix.RAMPS.loot_ash)
	var baked := false  # Lote 9 C (a): no máximo um buraco cozido por frame (os 4 da sala do chefe eram 40-65 ms num telemóvel)
	for h in holes:
		var at: Vector2 = h[0]
		var r: float = h[1]
		if not view.has_point(at):
			continue
		var v: int = int(absf(at.x * 7.0 + at.y * 13.0)) % 4
		var has_tex: bool = Pix.pit_ready(r, v)
		if h[2] > 0.0 and time >= h[2]:  # aberto (Lote 8 C (c)): a boca recortada, a parede a descer em pontilhado até ao negro e as lascas da laje à volta
			if old_ground:  # Lote 7: um disco negro liso; só para a captura de antes e depois
				Pix.haze(ground, at, r, r, Color.BLACK, 1.0, false)
				Pix.haze(ground, at, r * 0.7, r * 0.7, Color(0.16, 0.06, 0.22), 0.6)
				Pix.loop(ground, at, r, r, Color(0.42, 0.38, 0.34), 2, true)
			elif has_tex or not baked:  # Lote 9: aberto já fora da vista (a câmara chega depois, o convidado entra a meio): coze-se ao aparecer, um por frame
				baked = baked or not has_tex
				Pix.pit(ground, at, r, v)
			else:  # os outros esperam um frame com a boca negra
				Pix.haze(ground, at, r, r, Color.BLACK, 1.0, false)
			continue
		if not baked and not has_tex:  # o buraco coze-se já com a laje fechada: no frame em que abre debaixo dos heróis era uma paragem
			Pix.pit_tex(r, v)
			baked = true
		Pix.haze(ground, at, r, r, Color(0.36, 0.34, 0.32), 1.0, false)
		Pix.loop(ground, at, r, r, Color(0.2, 0.18, 0.17), 2, true)
		for k in 5:  # as fendas, das mesmas em todos os telemóveis
			var a: float = Pix.hashf(int(at.x) + k, int(at.y)) * TAU
			var mid: Vector2 = at + Vector2.from_angle(a + 0.4) * r * 0.45
			Pix.line(ground, at + Vector2.from_angle(a) * r * 0.1, mid, Pix.SOOT)
			Pix.line(ground, mid, at + Vector2.from_angle(a - 0.2) * r * 0.9, Pix.SOOT)
		if h[2] > 0.0:  # vai abrir: o aviso dos golpes dos chefes
			Pix.warn(ground, at, r, 1.0 - (h[2] - time) / HOLE_WARN, "necro")
	for w in webs:
		var at: Vector2 = w[0]
		if not view.has_point(at):
			continue
		var n: int = 2 * int(w[1])
		Pix.haze(ground, at, WEB_R, WEB_R, Pix.RAMPS.bleed[4], 0.3)  # a área que prende, ténue
		if old_ground:  # Lote 7: raios a direito e dois anéis (pareciam hexágonos de arame); só para a captura de antes e depois
			var tips := []
			for k in n:
				tips.append(Vector2.from_angle(TAU * k / n + Pix.hashf(int(at.x), k) * 0.3))
			for t in tips:
				Pix.line(ground, at + Vector2(0, Pix.S), at + t * WEB_R + Vector2(0, Pix.S), Pix.RAMPS.bleed[4])
				Pix.line(ground, at, at + t * WEB_R, Pix.RAMPS.bleed[1])
			for ring in [0.45, 0.85]:
				for k in n:
					Pix.line(ground, at + tips[k] * WEB_R * ring, at + tips[(k + 1) % n] * WEB_R * ring, Pix.RAMPS.bone[3])
			Pix.orb(ground, at, 3, "bleed")
			continue
		_draw_web(at, n)


## S10: a porta i. Costelas de osso de lado a lado do corredor: no chão abertas, a meia altura no aviso (#28) e de pé
## fechadas; selos de pedra (#219); e a do Cofre (#32), com o recipiente e o canal que acende a cada pagamento.
func _draw_gate(i: int, g: Array) -> void:
	var band: Rect2 = g[2]
	var cross: Vector2 = g[4].orthogonal().abs()
	var span: float = band.size.dot(cross)
	var mid := band.get_center()
	var open := gate_open(i)
	var lv: int = gates[i] if i < gates.size() else 0
	if g[1] == "sangue":  # o recipiente de pedra, com sombra, borda e a boca escura; o sangue vê-se na boca e a subir na fresta da frente
		var a: Vector2 = g[3] + Vector2(0, -4)
		_groove(a, mid + cross * clampf((a - mid).dot(cross), -span / 2.0 + 16.0, span / 2.0 - 16.0) + g[4] * signf((a - mid).dot(g[4])) * 12.0, Pix.RAMPS.bleed[1] if open else Pix.RAMPS.bleed[3] if lv > 0 else Color(0.2, 0.16, 0.16))
		Pix.haze(ground, g[3] + Vector2(0, -2), 34.0, 9.0, Color.BLACK, 0.55)
		Pix.solid(ground, g[3], VESSEL_FOOT, "ash", 4)
		Pix.solid(ground, g[3], VESSEL, "ash", 4)
		Pix.solid(ground, g[3], VESSEL_SHADE, "ash", 5, Color.WHITE, false)  # o lado da sombra
		Pix.solid(ground, g[3], VESSEL_LIP, "ash", 2)
		Pix.solid(ground, g[3], VESSEL_MOUTH, "ash", 5, Color.WHITE, false)
		if lv > 0 or open:
			Pix.solid(ground, g[3], VESSEL_MOUTH if open else VESSEL_HALF, "bleed", 1 if open else 3, Color.WHITE, false)
			for q in [Vector2(-24, -34), Vector2(18, -34), Vector2(26, -32)]:  # a escorrer pela borda
				Pix.px(ground, g[3] + q, Pix.RAMPS.bleed[2], 1, 2 + int(absf(q.x)) % 3)
	if open and g[1] in ["sangue", "selo"]:
		return
	if g[1] in ["sangue", "selo"]:  # lajes de pedra de pé, de lado a lado da boca do corredor, com runas gravadas (deitadas eram anéis violeta, como os abrigos)
		var m: int = maxi(1, ceili(span / 200.0))
		var t: Vector2 = g[4] * 12.0  # a grossura
		for k in m:
			var at: Vector2 = mid + cross * (-span / 2.0 + (k + 0.5) * span / m)
			var w: Vector2 = cross * (span / m / 2.0 - 4.0)
			var up := Vector2(0, -roundf(SLAB_H + (Pix.hashf(i * 31 + k) - 0.5) * 20.0))  # cada laje da sua altura, mais estreita em cima
			var v: Vector2 = w * 0.9
			Pix.haze(ground, at + Vector2(0, 4), absf(w.x) + absf(t.x) + 8.0, absf(w.y) + absf(t.y) + 4.0, Color.BLACK, 0.5)
			Pix.solid(ground, at, Array(Geometry2D.convex_hull(PackedVector2Array([-w - t, w - t, w + t, -w + t, -v - t + up, v - t + up, v + t + up, -v + t + up]))), "ash", 4)
			Pix.solid(ground, at + up, [-v - t, v - t, v + t, -v + t], "ash", 3)  # o cimo, mais claro
			var s: Vector2 = at + w * (Pix.hashf(i * 31 + k, 1) * 1.2 - 0.6) + t + up * 0.8
			for q in [[s, s + Vector2(4, 10)], [s + Vector2(4, 10), s + Vector2(-2, 22)]]:  # uma racha
				Pix.line(ground, q[0], q[1], Pix.SOOT)
			for f in ([-0.55, 0.0, 0.55] if w.length() > 50.0 else [0.0]):
				Pix.stamp(ground, Pix._rune_tex(k * 3 + roundi(f * 2.0) + 1, "ash"), at + w * f + Vector2(0, 12.0 - SLAB_H * 0.5), Color(0.75, 0.2, 0.18) if g[1] == "sangue" else Color(0.32, 0.3, 0.34))
		return
	var h := 12.0  # aberta (ou partida, nas carcaças): só os tocos
	if not open:
		h = 120.0
	elif g[1] == "costela" and fposmod(time + i * 2.5, GATE_TICK) > GATE_WARN and sep_done == 0 and not guardian_met:
		h = 60.0
	if cross.y > 0.5:  # C (i): corredor de este para oeste (a faixa vai de cima a baixo no ecrã): pares de costelas que se curvam uma para a outra (_ew_ribs)
		for r in _ew_ribs(i, g, h):
			Pix.haze(ground, r[0] + Vector2(0, 2), 26.0, 6.0, Color.BLACK, 0.6)  # o buraco de onde sai o par
			for s in [-1.0, 1.0]:
				var lean: float = -s * r[1] * 0.24
				Pix.solid(ground, r[0] + g[4] * s * 13.0, [Vector2(-5, 0), Vector2(-6 + lean * 0.35, -r[1] * 0.55), Vector2(lean - 2, -r[1]), Vector2(lean + 3, -r[1] * 0.93), Vector2(5 + lean * 0.35, -r[1] * 0.5), Vector2(5, 0)], "bone", 4 if s < 0.0 else 3)
		return
	var n: int = maxi(3, int(span / 45.0))
	for row in 2:  # duas filas, a de trás mais baixa e mais escura, em arco (mais altas ao meio), cada costela do seu tamanho e no seu sítio; só no chão (a ponta saía por cima do vazio)
		for k in n:
			var u: float = (k + 0.5 + 0.25 * row + (Pix.hashf(i * 97 + k, row) - 0.5) * 0.4) / n
			var at: Vector2 = mid + cross * (-span / 2.0 + u * span) - g[4] * 18.0 * (1 - row)
			if _sep_byte(at) == 0:
				continue
			var hk: float = roundf(h * (0.62 + 0.38 * sin(PI * clampf(u, 0.0, 1.0))) * (0.88 + 0.24 * Pix.hashf(i * 97 + k, row + 2)) * (0.85 if row == 0 else 1.0) / 2.0) * 2.0
			var lean: float = hk * 0.22 * signf(mid.x - at.x)  # de lado a lado curvam para o meio, como um peito
			if row == 1:
				Pix.haze(ground, at + Vector2(0, 2), 10.0, 4.0, Color.BLACK, 0.6)  # o buraco de onde sai
			Pix.solid(ground, at, [Vector2(-6, 0), Vector2(-7 + lean * 0.35, -hk * 0.55), Vector2(lean - 2, -hk), Vector2(lean + 3, -hk * 0.93), Vector2(6 + lean * 0.35, -hk * 0.5), Vector2(6, 0)], "bone", 4 if row == 0 else 3 if k % 2 == 0 else 2)


## C (i): os pares de costelas de uma porta de este para oeste, [pé, altura], de trás para a frente: cerrados (cada par tapa
## o espaço até ao de trás: soltos, liam-se como adereços), desencontrados ao longo do corredor (a direito eram um só molho)
## e só no chão, com pé de chão por baixo. Junto à parede de cima ficam mais baixos: a parede desenha-se por cima do chão e
## cortava-lhes as pontas.
func _ew_ribs(i: int, g: Array, h: float) -> Array:
	var cross: Vector2 = g[4].orthogonal().abs()
	var span: float = g[2].size.dot(cross)
	var mid: Vector2 = g[2].get_center()
	var pairs: int = maxi(4, int(span / 30.0))
	var out := []
	for j in pairs:
		var at: Vector2 = mid + cross * (-span / 2.0 + (j + 0.5) / pairs * span) + g[4] * (18.0 if j % 2 == 0 else -18.0)
		if _sep_byte(at) == 0 or _sep_byte(at + Vector2(0, 30)) == 0:
			continue
		var hk: float = h * 0.72 * (0.9 + 0.2 * Pix.hashf(i * 97 + j, 5))
		var top: float = SEP_ORIGIN.y + floorf((at.y - SEP_ORIGIN.y) / SEP_CELL.y) * SEP_CELL.y  # o cimo da casa do pé
		if _sep_byte(Vector2(at.x, top - 1.0)) == 0:
			hk = minf(hk, at.y - top - 6.0)
		out.append([at, maxf(4.0, roundf(hk / 2.0) * 2.0)])
	return out


## O canal do Recipiente de Sangue (#32) até à laje da porta à frente dele: um sulco escuro com o sangue ao meio (um risco de
## 2 px até ao meio da porta parecia uma linha de mira).
func _groove(a: Vector2, b: Vector2, c: Color) -> void:
	var n: Vector2 = (b - a).orthogonal().normalized() * Pix.S
	Pix.line(ground, a + n, b + n, Pix.SOOT)
	Pix.line(ground, a - n, b - n, Pix.SOOT)
	Pix.line(ground, a, b, c)


## O mundo que a câmara apanha agora.
func _view_rect() -> Rect2:
	var half := get_viewport_rect().size / 2.0 / cam.zoom
	return Rect2(cam.get_screen_center_position() - half, half * 2.0)


## Nevoeiro do cemitério (o fog, num shader): um banco por baixo das personagens, mais denso e lento nos efeitos altos;
## efeitos baixos sem nevoeiro. Nenhum por cima delas: acinzentava o ecrã e os monstros liam-se mal.
## Um quadro do tamanho da vista; o ruído lê-se no mundo e não escorrega.
func _draw_fog() -> void:
	var lvl := effects_level()
	if zone != "world" or lvl == 0:
		return
	fog.material.set_shader_parameter("depth", 0.5 if lvl == 1 else 1.0)
	var half := get_viewport_rect().size / 2.0 / cam.zoom + Vector2(64, 64)
	fog.draw_rect(Rect2(cam.get_screen_center_position() - half, half * 2.0), Color.WHITE)


## Catacumbas Cegas (#26): o escuro, um quadro do tamanho da vista com as luzes de lights() (só com dark_on()).
func _draw_dark() -> void:
	var ls := lights()
	var arr := PackedVector3Array(ls)
	arr.resize(16)  # o shader tem sempre 16; count diz quantas valem
	dark.material.set_shader_parameter("lights", arr)
	dark.material.set_shader_parameter("count", ls.size())
	var half := get_viewport_rect().size / 2.0 / cam.zoom + Vector2(64, 64)
	dark.draw_rect(Rect2(cam.get_screen_center_position() - half, half * 2.0), Color.WHITE)


## Silhueta atrás das paredes (#92): quem fica tapado por um adereço alto desenha-se outra vez por cima dele, numa cor
## só (a do herói; vermelho nos monstros). Só entram na conta os adereços que a câmara apanha.
func _draw_xray() -> void:
	var half := get_viewport_rect().size / 2.0 / cam.zoom
	var view := Rect2(cam.get_screen_center_position() - half, half * 2.0)
	var near := (sep_tall if zone == "sep" else tall).filter(func(r): return view.intersects(r))
	if near.is_empty():
		return
	for c in players + enemies():
		# quem ainda sai do chão ou já está a morrer não tem silhueta (o desenho dele ainda/já não se vê), nem quem está escondido (o herói à espera da ligação, #91)
		if c.visible and (c in players or (c.rise_t <= 0.0 and not c.dying)) and behind_prop(c, near):
			xray.draw_set_transform_matrix(c.transform * c.pose)
			xray.draw_texture(c.pose_tex, Vector2.ZERO, Color(c.tint, 0.55) if c in players else Color(1.0, 0.25, 0.25, 0.45))


## O meio do desenho de c fica dentro de um adereço alto e os pés dele estão acima da base do adereço
## (o y-sort desenha o adereço depois dele). rects = tall, ou só os que estão à vista.
func behind_prop(c, rects: Array) -> bool:
	if c.pose_tex == null:
		return false
	var mid: Vector2 = c.transform * c.pose * (c.pose_tex.get_size() / 2.0)
	for r in rects:
		if r.end.y > c.position.y and r.has_point(mid):
			return true
	return false
