extends Node2D
## Soulstrider: Necro-Dominion — protótipo. Mundo, loot, moedas, arma, co-op e o Cortejo Fúnebre.

const MAP := Rect2(-1600, -1600, 3200, 3200)
const Enemy := preload("res://enemy.gd")
const Loot := preload("res://loot.gd")
const Decoy := preload("res://decoy.gd")
const Fx := preload("res://fx.gd")
const Bolt := preload("res://bolt.gd")
const Player := preload("res://player.gd")
const Hud := preload("res://hud.gd")
const Chest := preload("res://chest.gd")
const Ally := preload("res://ally.gd")
const Tomb := preload("res://tomb.gd")
const SILHOUETTE := preload("res://silhouette.gdshader")
const MAX_ALLIES := 4

const SUFFIXES := {
	"do Sangramento": {"bleed": 0.5},
	"da Ossada": {"dmg": 0.25},
	"da Vigília": {"regen": 3.0},
	"do Tutano": {"leech": 0.04},
	"do Coveiro Veloz": {"speed": 0.15},
	"da Podridão": {"rot": 1.0},  # #148: dano contínuo que pega a quem estiver encostado
	"da Calcificação": {"calcify": 1.0},  # #150: à 10.ª camada o inimigo vira estátua
	"da Necrose": {"necro": 1.0},  # #154: cada golpe uma camada (até 10), +5% de dano recebido por camada
}
const HIDDEN := {
	"Ruína dos Colossos: +60% dano a chefes": {"boss": 0.6},
	"Banquete Fúnebre: +5 vida por abate": {"kill_heal": 5.0},
	"Alma Faminta: +35% dano de feitiços": {"spell": 0.35},
}
const AFFIXES := {
	"blindados": ["Ossos Blindados", "inimigos +60% vida"],
	"furia": ["Fúria Espectral", "inimigos +35% velocidade"],
	"laminas": ["Lâminas Envenenadas", "inimigos +50% dano"],
	"legiao": ["Legião", "+60% escoltas"],
	"gemeo": ["Colosso Gémeo", "um colosso a mais em cada onda"],
}
const WAVES := 3
const REVIVE_T := 2.5
const CRIT := 0.12
const CRIT_MULT := 1.8
const ARENA_R := 620.0
const SFX := {
	"hit": preload("res://sfx/hit.wav"), "crit": preload("res://sfx/crit.wav"), "hurt": preload("res://sfx/hurt.wav"),
	"bell": preload("res://sfx/bell.wav"), "roar": preload("res://sfx/roar.wav"), "chest": preload("res://sfx/chest.wav"),
	"levelup": preload("res://sfx/levelup.wav"), "potion": preload("res://sfx/potion.wav"),
}
const BOSS_MUSIC := preload("res://sfx/boss.wav")
const XP := {"skeleton": 5, "specter": 4, "colossus": 60, "herald": 150}
## Jogo gravado (no Android fica nos dados da app e passa de versão para versão).
const SAVE_PATH := "user://save.json"
const SETTINGS_PATH := "user://settings.cfg"
## Configurações: ficam fora do jogo gravado (um Novo jogo não as apaga). Escolhas = índice da lista no menu.
const SETTINGS := {
	"master": 1.0, "music": 0.8, "sfx": 1.0,
	"fps": 1, "res": 0, "effects": 2, "show_fps": false,
	"shake": true, "flash": true, "numbers": true,
	"ui": 0, "opacity": 0,
	"vibe": 2,  # vibração: 0 desligada, 1 fraca, 2 média, 3 forte
	"thermal": true,  # preservação térmica: baixa os efeitos e os FPS sozinha quando o telemóvel aquece
	"lang": 0,  # 0 = português de Portugal, 1 = inglês britânico (sem ficheiro: o idioma do telemóvel)
	"pixel32": true,  # personagens em 32-bit (falso = os desenhos pintados antigos)
	"intro_seen": false,  # a intro aparece sozinha só da primeira vez (depois, no Sobre)
	"lefty": false,  # canhoto: botões de habilidade à esquerda e joystick à direita
	"joy_fixed": false,  # joystick fixo no canto (de origem aparece onde o polegar toca)
	"deadzone": 1,
	"colorblind": 0,  # 0 desligado, 1 protanopia, 2 deuteranopia, 3 tritanopia
	"comfort": 0,  # conforto ocular: 0 desligado, 1 suave, 2 forte
	"minimap": true,
	"auto_attack": false,  # um polegar: o 1.º golpe sai sozinho com um inimigo ao alcance
	"boss_aim": false,  # a mira automática prefere os chefes
	"potion_ui": 2,  # botões de poção a 100%, 125% ou 150% (de origem os maiores: acertar no meio da luta)
	"hud_fade": false,  # longe de combate, o HUD fica quase transparente
	"loot_names": 0,  # 0 todos os nomes no chão, 1 só os raros (um Osso sozinho não diz nada)
}
const CHOICES := {"vibe": 4, "fps": 3, "res": 2, "effects": 3, "ui": 3, "opacity": 3, "lang": 2, "deadzone": 3, "colorblind": 4, "comfort": 3, "potion_ui": 3, "loot_names": 2}  # quantas escolhas tem cada uma
const DEADZONES := [0.15, 0.25, 0.4]  # zona morta do stick e dos gatilhos (comandos com "drift" precisam da maior)
const I18n := preload("res://i18n.gd")
const FPS_CAPS := [30, 60, 0]  # 0 = o que o ecrã der
const OPACITY := [1.0, 0.75, 0.5]
const VIBE := [0.0, 0.5, 1.0, 1.6]  # força da vibração de cada escolha
const DUMMY_AT := Vector2(260, 140)  # boneco de treino (#287), ao lado do monumento
const BLOOD_R := 30.0  # Sangue no Solo (#23): raio de cada poça
const EFFECTS := [0.35, 0.65, 1.0]  # parte das partículas que se desenha
## Comando com esquema Xbox (A em baixo, B à direita, X à esquerda, Y em cima), como o GameSir G8 Plus.
## Sem teclado: o jogo é para telemóvel (comando ou ecrã tátil).
const PAD_BUTTONS := {
	"move_left": [JOY_BUTTON_DPAD_LEFT], "move_right": [JOY_BUTTON_DPAD_RIGHT],
	"move_up": [JOY_BUTTON_DPAD_UP], "move_down": [JOY_BUTTON_DPAD_DOWN],
	"skill_1": [JOY_BUTTON_A], "skill_2": [JOY_BUTTON_X], "skill_3": [JOY_BUTTON_Y],
	"interact": [JOY_BUTTON_B], "menu": [JOY_BUTTON_START], "tree": [JOY_BUTTON_BACK], "stance": [JOY_BUTTON_RIGHT_STICK],
	"arsenal": [JOY_BUTTON_LEFT_STICK],
	"potion_hp": [JOY_BUTTON_LEFT_SHOULDER], "potion_mp": [JOY_BUTTON_RIGHT_SHOULDER],
}
const PAD_AXES := {
	"move_left": [JOY_AXIS_LEFT_X, -1.0], "move_right": [JOY_AXIS_LEFT_X, 1.0],
	"move_up": [JOY_AXIS_LEFT_Y, -1.0], "move_down": [JOY_AXIS_LEFT_Y, 1.0],
	"skill_1": [JOY_AXIS_TRIGGER_RIGHT, 1.0], "skill_2": [JOY_AXIS_TRIGGER_LEFT, 1.0],  # gatilhos RT/LT (Kishi, Backbone, DualSense)
}

## Chão: tiles isométricos 32-bit da folha SC-W1 (SpriteCook). LV = altura do vértice esquerdo do losango na textura;
## HH = meia altura da face de cima. Medido nas texturas cortadas (256 px de largura).
const TILES := {
	"cobble": preload("res://art/tiles/cobble.png"), "cobble_moss": preload("res://art/tiles/cobble_moss.png"),
	"grass": preload("res://art/tiles/grass.png"), "mud": preload("res://art/tiles/mud.png"),
	"slab": preload("res://art/tiles/slab.png"), "slab_roots": preload("res://art/tiles/slab_roots.png"),
	"bones": preload("res://art/tiles/bones.png"), "water": preload("res://art/tiles/water.png"),
}
const TILE_LV := {"cobble": 90.0, "cobble_moss": 90.0, "grass": 96.0, "mud": 90.0, "slab": 91.0, "slab_roots": 92.0, "bones": 90.0, "water": 93.0}
const TILE_HH := 90.5
const TILE_SCALE := 0.55
## Praça central 32-bit (PX-33, redesenhada do MAP-01); o poço do meio fica debaixo do monumento.
const HUB := preload("res://art/bg/hub.webp")
const HUB_SPOT := Vector2(1376, 754)
const MON := preload("res://art/props/monument.png")
const MON_ON := preload("res://art/props/monument_on.png")
## Cripta dos Condenados: o mapa PX-34 (o MAP-02 em 32-bit, igual de sítio) fica numa zona à parte, por baixo do cemitério.
## Coordenadas medidas na imagem (2752x1536): o chão caminhável, a entrada, a porta do fundo e o Carcereiro.
const CRYPT := preload("res://art/bg/crypt.webp")
const CRYPT_ORIGIN := Vector2(-1376, 3400)
const CRYPT_FLOOR := [Vector2(1950, 520), Vector2(2230, 560), Vector2(2150, 830), Vector2(1750, 1000), Vector2(1450, 1180),
	Vector2(1150, 1250), Vector2(800, 1430), Vector2(300, 1450), Vector2(150, 1250), Vector2(500, 1120), Vector2(850, 940),
	Vector2(1350, 690), Vector2(1650, 570), Vector2(1800, 510)]
const CRYPT_IN := Vector2(450, 1300)
const CRYPT_OUT := Vector2(2040, 540)
const CRYPT_BOSS := Vector2(1880, 660)
const CRYPT_GLOWS := [Vector2(470, 960), Vector2(1270, 560), Vector2(1770, 400), Vector2(2290, 640)]
const CRYPT_DOOR := Vector2(-700, 900)  # escadas para a cripta, no cemitério
const CRYPT_DOOR_TEX := preload("res://art/props/crypt_door.png")
## Adereços: textura, altura no ecrã, peso no sorteio.
const PROPS := {
	"grave_broken": [preload("res://art/props/grave_broken.png"), 72.0, 14],
	"graves3": [preload("res://art/props/graves3.png"), 62.0, 8],
	"tomb": [preload("res://art/tomb.png"), 66.0, 10],
	"fence": [preload("res://art/props/fence.png"), 70.0, 5],
	"fence_gate": [preload("res://art/props/fence_gate.png"), 76.0, 3],
	"coffin": [preload("res://art/props/coffin.png"), 46.0, 4],
	"coffin_open": [preload("res://art/props/coffin_open.png"), 46.0, 3],
	"candles": [preload("res://art/props/candles.png"), 52.0, 4],
	"skulls": [preload("res://art/props/skulls.png"), 46.0, 4],
	"roots": [preload("res://art/props/roots.png"), 56.0, 5],
	"bush": [preload("res://art/props/bush.png"), 62.0, 6],
	"statue": [preload("res://art/props/statue.png"), 112.0, 3],
	"lantern": [preload("res://art/props/lantern.png"), 122.0, 3],
	"tree": [preload("res://art/tree.png"), 150.0, 8],
	"cage_tree": [preload("res://art/props/cage_tree.png"), 230.0, 2],
	"crypt": [preload("res://art/crypt.png"), 140.0, 2],
	"chapel": [preload("res://art/props/chapel.png"), 230.0, 1],
	"gatehouse": [preload("res://art/props/gatehouse.png"), 220.0, 1],
	"rubble": [preload("res://art/props/rubble.png"), 150.0, 1],
	"cliff": [preload("res://art/props/cliff.png"), 160.0, 1],
}

## Árvore dos Condenados: raízes que crescem da "raiz". pos = lugar no ecrã da árvore (640x380).
const PASSIVES := {
	"raiz": {"name": "Raiz", "desc": "Onde todos os condenados começam.", "req": "", "pos": Vector2(320, 340), "stats": {}},
	"densos": {"name": "Ossos Densos", "desc": "+30 vida máxima", "req": "raiz", "pos": Vector2(170, 280), "stats": {"hp_max": 30.0}},
	"tutano": {"name": "Tutano Faminto", "desc": "+3% do dano vira vida", "req": "densos", "pos": Vector2(90, 180), "stats": {"leech": 0.03}},
	"medula": {"name": "Medula Sacrificial", "desc": "20% do dano recebido vira barreira de ossos", "req": "densos", "pos": Vector2(70, 300), "stats": {"bone_barrier": 0.2}},
	"ossada": {"name": "Ossada Pesada", "desc": "+25% dano", "req": "tutano", "pos": Vector2(110, 60), "stats": {"dmg": 0.25}},
	"veias": {"name": "Veias Abertas", "desc": "+30% sangramento", "req": "raiz", "pos": Vector2(320, 240), "stats": {"bleed": 0.3}},
	"hemorragia": {"name": "Hemorragia", "desc": "+40% sangramento", "req": "veias", "pos": Vector2(320, 150), "stats": {"bleed": 0.4}},
	"bleedbone": {"name": "Bleed & Bone", "desc": "CHAVE: +80% sangramento e +15% dano, mas -30% dano de feitiços", "req": "hemorragia", "pos": Vector2(320, 50), "stats": {"bleed": 0.8, "dmg": 0.15, "spell": -0.3}},
	"mente": {"name": "Mente Sepulcral", "desc": "+30 mana máxima", "req": "raiz", "pos": Vector2(470, 280), "stats": {"mana_max": 30.0}},
	"faminta": {"name": "Alma Faminta", "desc": "+25% dano de feitiços", "req": "mente", "pos": Vector2(550, 180), "stats": {"spell": 0.25}},
	"eco": {"name": "Eco Espectral", "desc": "+4 mana por segundo", "req": "faminta", "pos": Vector2(530, 60), "stats": {"regen": 4.0}},
	"coveiro": {"name": "Passo do Coveiro", "desc": "+12% velocidade", "req": "veias", "pos": Vector2(215, 170), "stats": {"speed": 0.12}},
	"dentes": {"name": "Dentes de Sepultura", "desc": "A esquiva deixa dentes no chão que abrandam os monstros em 40%", "req": "coveiro", "pos": Vector2(232, 96), "stats": {"teeth": 1.0}},
}

var player  # jogador 1 (o HUD e os controlos de toque são dele)
var players := []
var cam := Camera2D.new()
var level := 1
var xp := 0
var shake := 0.0
var zoom_kick := 0.0
var cam_zoom := 1.0
var focus_t := 0.0
var focus_pos := Vector2.ZERO
var rumble := 0.0  # o sino dobra antes de o Arauto aparecer
var arena_r := 0.0  # > 0: os jogadores ficam presos no círculo do monumento até o Arauto cair
var pad_of := [-1, -1]  # comando (device) de cada jogador; -1 = ainda nenhum
var raise_by = null  # herói cuja Alma Tumular está a bater agora (quem morrer ergue-se para ele)
var flasks := ["", "parasita", "titanica"]  # Frascos de Alma que o grupo já tem
var tomb := {}  # {"pos": Vector2, "lost": {moeda: quantidade}} enquanto houver um túmulo por recuperar
var tomb_node
var saved := {}  # o que veio do ficheiro (o Guardião usa a parte dele quando entrar)
var saved_json := ""
var save_t := 2.0
var zone := "world"  # "world" = cemitério, "crypt" = cripta
var bounds := MAP
var crypt_floor := PackedVector2Array()
var guardian  # o Carcereiro da Cripta, enquanto vivo
var guardian_met := false
var tint := CanvasModulate.new()  # a cripta é mais escura
var sfx_last := {}
var hud
var music := AudioStreamPlayer.new()
var settings := SETTINGS.duplicate()
var wiping := false  # Novo jogo: o jogo gravado foi apagado e nada o volta a escrever antes de recomeçar
var chest
var rng := RandomNumberGenerator.new()
var currency := {"bone": 0, "ink": 0, "ash": 0}
var kills := {}  # mortes de cada monstro (o Bestiário revela-os com elas)
var weapon := {"tier": 0, "suffixes": [], "hidden": "", "sealed": true}
var cortejo := {"active": false, "wave": 0, "affixes": [], "alive": 0}
var monument_pos := Vector2(0, -300)
var thermal := 0  # preservação térmica: 0 nada, 1 menos efeitos, 2 também 30 FPS (até fechar o jogo)
var thermal_t := 0.0
var monument: Sprite2D
var fog := []
var glows := []
var tile_list := []
var teeth := []  # Dentes de Sepultura: [posição, tempo que falta] deixados pela esquiva
var blood := []  # Sangue no Solo (#23): [posição, quando seca (em time)] das poças dos monstros a sangrar
var spawn_t := 0.0
var time := 0.0
var tiles := Node2D.new()
var ground := Node2D.new()
var xray := Node2D.new()  # silhuetas de quem fica tapado por um adereço alto (#92), por cima de tudo
var tall := []  # Rect2 do meio de cada adereço alto (feitos em _prop)


func _ready() -> void:
	I18n.setup()
	rng.seed = 6661
	for p in CRYPT_FLOOR:
		crypt_floor.append(CRYPT_ORIGIN + p)
	add_child(tint)
	_setup_input()
	for b in ["Musica", "Efeitos"]:  # canais de som com volume próprio nas Configurações
		if AudioServer.get_bus_index(b) == -1:
			AudioServer.add_bus()
			AudioServer.set_bus_name(AudioServer.bus_count - 1, b)
			AudioServer.set_bus_send(AudioServer.bus_count - 1, "Master")
	Input.joy_connection_changed.connect(_on_joy)
	_gen_world()
	rng.randomize()
	_reroll_weapon()
	if not Net.is_guest():  # o convidado joga o jogo do anfitrião
		saved = _read_save()
		_apply_save()
	load_settings()
	# y-sort ordena o desenho do pai junto com os filhos; o chão vai em filhos atrás de tudo.
	# tiles = desenhado uma vez; ground = nevoeiro e brilhos, redesenhado a cada frame.
	tiles.z_index = -12
	tiles.draw.connect(_draw_tiles)
	add_child(tiles)
	ground.z_index = -10
	ground.draw.connect(_draw_world)
	add_child(ground)
	xray.z_index = 3  # por cima dos adereços e das personagens (z 0), debaixo dos efeitos (4 e mais)
	xray.material = ShaderMaterial.new()
	xray.material.shader = SILHOUETTE
	xray.draw.connect(_draw_xray)
	add_child(xray)
	player = add_player()
	cam.limit_left = int(MAP.position.x)
	cam.limit_top = int(MAP.position.y)
	cam.limit_right = int(MAP.end.x)
	cam.limit_bottom = int(MAP.end.y)
	cam.position_smoothing_enabled = true
	cam.position = player.position
	add_child(cam)
	var song: AudioStreamWAV = BOSS_MUSIC
	song.loop_mode = AudioStreamWAV.LOOP_FORWARD
	song.loop_end = song.data.size() / 2  # 16 bits mono: 2 bytes por amostra
	music.stream = song
	music.volume_db = -6.0
	music.bus = "Musica"
	add_child(music)
	hud = Hud.new()
	hud.main = self
	add_child(hud)
	apply_settings()
	if Net.is_guest():
		_as_guest()
	else:
		_spawn_tomb()
		_spawn_dummy()
		for i in 14:
			spawn_enemy("skeleton", Vector2(rng.randf_range(-900, 900), rng.randf_range(-1500, -1000)), {}, false)
	if Engine.has_meta("play_now"):
		Engine.remove_meta("play_now")  # Novo jogo / Erguer-se / entrar numa sala: entra direto no jogo
	else:
		hud.open_opening(hud.open_title if settings.intro_seen else hud.open_intro)
	Net.attach(self)


## Co-op por Wi-Fi, no convidado: os dois heróis só desenham o que o anfitrião manda; este telemóvel é o Guardião.
func _as_guest() -> void:
	player = add_player(-2)
	players.reverse()
	for p in players:
		p.set_process(false)
	hud.skills_for_player()


## O Guardião da Wi-Fi saiu da sala: o anfitrião continua sozinho.
func drop_player() -> void:
	if players.size() < 2:
		return
	var p = players.pop_back()
	if raise_by == p:
		raise_by = null
	p.queue_free()
	pad_of[1] = -1
	_rebind()
	hud.toast("O Guardião saiu da sala.")


## Jogador 1 é o Strider; o jogador 2 é o Guardião e entra a qualquer momento (Menu no 2.º comando).
## pad = o comando dele (-1: fica com o próximo comando que carregar num botão).
func add_player(pad := -1) -> Node2D:
	var p := Player.new()
	p.main = self
	p.setup("strider" if players.is_empty() else "warden", players.size())
	p.position = Vector2(0, 300) if players.is_empty() else players[0].position + Vector2(60, 0)
	p.points = level - 1
	_apply_hero(p)
	p.refresh_stats()
	p.hp = p.max_hp
	p.hp_chunk = p.max_hp
	p.died.connect(_on_player_down.bind(p))
	players.append(p)
	add_child(p)
	pad_of[players.size() - 1] = pad
	_rebind()
	if players.size() > 1:
		hud.toast("O Guardião entrou no Cortejo!" if pad != -1 else "O Guardião entrou — carrega num botão do 2.º comando.")
	return p


## Quem os monstros perseguem: um clone de osso perto (Esquiva Espectral) ou o herói mais perto.
func lure(pos: Vector2):
	for d in get_tree().get_nodes_in_group("decoys"):
		if pos.distance_to(d.position) < 420.0:
			return d
	return nearest_player(pos)


func spawn_decoy(p) -> void:
	var d := Decoy.new()
	d.main = self
	d.position = p.position
	d.hero = p.hero
	d.frame = p._frame()
	d.frame32 = p._frame32()
	d.flip = p.flip_s
	add_child(d)


func nearest_player(pos: Vector2):
	var best = null
	for p in players:
		if not p.dead and (best == null or pos.distance_squared_to(p.position) < pos.distance_squared_to(best.position)):
			best = p
	return best


func _on_player_down(p) -> void:
	if nearest_player(p.position) == null:
		var info := die(p.position)
		info.by = p.killed_by
		hud.open_death(info)
	else:
		hud.toast(tr("%s caiu! Fica perto dele para o reanimar.") % tr(p.hero_name))


## Todos caíram: metade de cada recurso fica num túmulo no cemitério (onde se morreu ou, na cripta,
## ao pé das escadas). Um túmulo antigo por recuperar desfaz-se. Grava logo: fechar a app não salva nada.
func die(at: Vector2) -> Dictionary:
	var lost := {}
	for k in currency:
		lost[k] = currency[k] / 2
		currency[k] -= lost[k]
	var had_old := not tomb.is_empty()
	tomb = {}
	if lost.values().any(func(v): return v > 0):
		var pos := at if zone == "world" else CRYPT_DOOR + Vector2(0, 150)
		tomb = {"pos": pos.clamp(MAP.position + Vector2(80, 80), MAP.end - Vector2(80, 80)), "lost": lost}
	save_game()
	return {"lost": lost if not tomb.is_empty() else {}, "had_old": had_old}


func _spawn_tomb() -> void:
	if tomb.is_empty():
		return
	tomb_node = Tomb.new()
	tomb_node.main = self
	tomb_node.position = tomb.pos
	add_child(tomb_node)


func recover_tomb() -> void:
	if tomb.is_empty():
		return
	var got := []
	for k in tomb.lost:
		currency[k] += tomb.lost[k]
		if tomb.lost[k] > 0:
			got.append("%d %s" % [tomb.lost[k], tr(Loot.INFO[k][0])])
	hud.toast(tr("Recuperaste do túmulo: %s") % ", ".join(got))
	spawn_fx("ring", tomb_node.position, 130.0, Color(0.4, 1.0, 0.65))
	sfx("chest")
	tomb_node.queue_free()
	tomb_node = null
	tomb = {}
	save_game()


func _process(delta: float) -> void:
	time += delta
	thermal_check(delta, Engine.get_frames_per_second())
	ground.queue_redraw()
	xray.queue_redraw()
	monument.texture = MON_ON if cortejo.active else MON
	if Net.is_guest():  # quem simula é o anfitrião; aqui só a câmara
		_coop(delta)
		return
	for i in range(teeth.size() - 1, -1, -1):
		teeth[i][1] -= delta
		if teeth[i][1] <= 0.0:
			teeth.remove_at(i)
	# guarda a hora a que seca, não um contador: assim a lista só muda (e só vai ao convidado) quando entra ou sai uma poça
	while not blood.is_empty() and blood[0][1] <= time:
		blood.pop_front()
	if not teeth.is_empty():
		for e in enemies():
			for tooth in teeth:
				if e.position.distance_squared_to(tooth[0]) < 45.0 * 45.0:
					e.slow_t = 0.4
					break
	save_t -= delta
	if save_t <= 0.0:
		save_t = 2.0
		save_game()
	if rumble > 0.0:
		rumble -= delta
		shake = maxf(shake, (2.6 - rumble) * 2.4)
	_coop(delta)
	# Carcereiro: ao chegarem perto, ruge e aparece o cartão do chefe
	if zone == "crypt" and is_instance_valid(guardian) and not guardian_met:
		var q = nearest_player(guardian.position)
		if q != null and q.position.distance_to(guardian.position) < guardian.aggro:
			guardian_met = true
			hud.name_card(guardian.title, "Guarda os mortos que não descansam")
			guardian.bar_fill = 0.0
			sfx("roar")
			shake = 12.0
	spawn_t -= delta
	if zone == "world" and spawn_t <= 0.0 and not cortejo.active and nearest_player(player.position) != null:
		spawn_t = 0.9
		if enemies().size() < 35:
			var p: Vector2 = player.position + Vector2.from_angle(rng.randf() * TAU) * 700.0
			p = p.clamp(MAP.position + Vector2(40, 40), MAP.end - Vector2(40, 40))
			spawn_enemy("specter" if rng.randf() < 0.25 else "skeleton", p, {}, false)


## Câmara no meio do grupo (com tremor e zoom de impacto); ninguém sai do ecrã nem da arena do chefe.
## Reanimar: aliado vivo perto de quem caiu.
func _coop(delta: float) -> void:
	var mid := Vector2.ZERO
	for p in players:
		mid += p.position
	mid /= players.size()
	# na arena do chefe a câmara fica entre o grupo e o monumento e afasta-se um pouco;
	# enquanto o Arauto se ergue e ruge, a câmara olha para ele (a revelação)
	cam.position = (mid + monument_pos) / 2.0 if arena_r > 0.0 else mid
	if focus_t > 0.0:
		focus_t -= delta
		cam.position = focus_pos
	cam_zoom = lerpf(cam_zoom, 0.85 if arena_r > 0.0 else 1.0, 1.0 - exp(-2.0 * delta))
	cam.offset = Vector2(randf_range(-1, 1), randf_range(-1, 1)) * shake * (1.0 if settings.shake else 0.0)
	cam.zoom = Vector2.ONE * (cam_zoom + zoom_kick)
	shake = move_toward(shake, 0.0, 45.0 * delta)
	zoom_kick = move_toward(zoom_kick, 0.0, 0.4 * delta)
	if arena_r > 0.0:
		for p in players:
			var v: Vector2 = p.position - monument_pos
			if v.length() > arena_r - 30.0:
				p.position = monument_pos + v.normalized() * (arena_r - 30.0)
	if players.size() < 2 or Net.is_guest():
		return
	var half := get_viewport_rect().size / 2.0 / cam.zoom - Vector2(60, 90)
	for p in players:
		p.position = p.position.clamp(cam.position - half, cam.position + half)
		if p.dead:
			var ally = nearest_player(p.position)
			var near: bool = ally != null and ally.position.distance_to(p.position) < 80.0
			p.revive_t = p.revive_t + delta if near else maxf(0.0, p.revive_t - delta)
			if p.revive_t >= REVIVE_T:
				p.revive()
				spawn_fx("ring", p.position, 90.0, Color(0.4, 1.0, 0.65))
				hud.toast(tr("%s voltou à luta!") % tr(p.hero_name))
			p.queue_redraw()


## Subir de nível: cada jogador ganha um ponto na árvore e +8 de vida máxima, com explosão de luz.
func gain_xp(amount: int) -> void:
	xp += amount
	while xp >= xp_needed():
		xp -= xp_needed()
		level += 1
		for p in players:
			p.points += 1
			p.refresh_stats()
			p.heal(8.0)
			spawn_fx("burst", p.position + Vector2(0, -40), 0.0, Color(1.0, 0.85, 0.4))
			spawn_fx("glow", p.position + Vector2(0, -40), 90.0, Color(1.0, 0.85, 0.4))
		sfx("levelup")
		hud.level_up()


func xp_needed() -> int:
	return 40 * level


func _setup_input() -> void:
	for pfx in ["", "p2_"]:
		for name in PAD_BUTTONS:
			if not InputMap.has_action(pfx + name):
				InputMap.add_action(pfx + name, 0.25)
	_rebind()
	# Menus: o Godot já navega com a cruz e o stick, mas não traz o A (escolher) nem o B (voltar)
	for pair in [["ui_accept", JOY_BUTTON_A], ["ui_cancel", JOY_BUTTON_B]]:
		var ev := InputEventJoypadButton.new()
		ev.button_index = pair[1]
		ev.device = -1
		if not InputMap.action_has_event(pair[0], ev):
			InputMap.action_add_event(pair[0], ev)


## Liga as ações de um jogador a um comando: device >= 0 = só esse, -1 = qualquer comando, -2 = nenhum.
func _bind(pfx: String, device: int) -> void:
	for name in PAD_BUTTONS:
		var action: String = pfx + name
		InputMap.action_erase_events(action)
		if device == -2:
			continue
		for b in PAD_BUTTONS[name]:
			var ev := InputEventJoypadButton.new()
			ev.button_index = b
			ev.device = device
			InputMap.action_add_event(action, ev)
		if PAD_AXES.has(name):
			var ev := InputEventJoypadMotion.new()
			ev.axis = PAD_AXES[name][0]
			ev.axis_value = PAD_AXES[name][1]
			ev.device = device
			InputMap.action_add_event(action, ev)


## Jogador 1: o seu comando, ou qualquer um enquanto não se sabe qual é. Jogador 2: só o seu comando.
func _rebind() -> void:
	_bind("", pad_of[0] if pad_of[0] != -1 else (-1 if pad_of[1] == -1 else -2))
	_bind("p2_", pad_of[1] if pad_of[1] != -1 else -2)


## Quem é quem (o HUD chama isto a cada toque num comando, mesmo em pausa): o 1.º comando que mexe é do
## jogador 1; um comando novo que carregue em Menu ou A faz entrar o Guardião; se o Guardião entrou pelo
## ecrã de título, o 1.º botão de um comando novo fica para ele.
func on_pad_input(event: InputEvent) -> void:
	var press: bool = event is InputEventJoypadButton and event.pressed
	if not press and not (event is InputEventJoypadMotion and absf(event.axis_value) > 0.6):
		return
	var d: int = event.device
	if d in pad_of:
		return
	if pad_of[0] == -1:
		pad_of[0] = d
		_rebind()
	elif players.size() == 1:
		if press and event.button_index in [JOY_BUTTON_START, JOY_BUTTON_A]:
			add_player(d)
	elif pad_of[1] == -1 and press:
		pad_of[1] = d
		_rebind()
		hud.toast("2.º comando ligado ao Guardião.")


func _on_joy(device: int, connected: bool) -> void:
	var i: int = pad_of.find(device)
	if connected or i == -1:
		return
	pad_of[i] = -1
	_rebind()
	if i < players.size():
		hud.pad_lost(players[i].hero_name, i == 0)


# ---------- Jogo gravado ----------

## Nível, moedas, arma e, por herói, a Árvore e os Frascos de Alma (as configurações vão à parte).
## O sítio onde se está e os inimigos não: abre-se sempre no cemitério.
func _save_data() -> Dictionary:
	var heroes: Dictionary = saved.get("heroes", {}).duplicate() if saved.get("heroes") is Dictionary else {}
	for p in players:
		var sup := {}
		for id in p.order:
			sup[id] = p.skills[id].support
		heroes[p.hero] = {"passives": p.passives, "points": p.points, "supports": sup}
	var t := {} if tomb.is_empty() else {"pos": [tomb.pos.x, tomb.pos.y], "lost": tomb.lost}
	return {"v": 1, "level": level, "xp": xp, "currency": currency, "weapon": weapon, "heroes": heroes,
		"flasks": flasks, "tomb": t, "kills": kills}


## Só escreve quando algo mudou. Escreve num ficheiro à parte e depois troca-o pelo verdadeiro:
## se a app morrer a meio da escrita, o jogo gravado antigo fica inteiro.
func save_game() -> void:
	if hud == null or wiping or Net.is_guest():
		return
	var d := _save_data()
	var s := JSON.stringify(d)
	if s == saved_json:
		return
	var tmp := SAVE_PATH + ".tmp"
	var f := FileAccess.open(tmp, FileAccess.WRITE)
	if f == null:
		return
	f.store_string(s)
	f.close()
	if DirAccess.rename_absolute(tmp, SAVE_PATH) == OK:
		saved_json = s
		saved = d


## A app vai para segundo plano ou fecha: o Android pode matá-la a seguir sem avisar.
func _notification(what: int) -> void:
	if what in [NOTIFICATION_APPLICATION_PAUSED, NOTIFICATION_APPLICATION_FOCUS_OUT, NOTIFICATION_WM_CLOSE_REQUEST]:
		save_game()


func has_save() -> bool:
	return FileAccess.file_exists(SAVE_PATH)


## Novo jogo: apaga o jogo gravado e recomeça já a jogar (as configurações ficam).
func new_game() -> void:
	wiping = true
	DirAccess.remove_absolute(ProjectSettings.globalize_path(SAVE_PATH))
	restart()


## Recomeça a cena: para o ecrã de título, ou direto para o jogo (Novo jogo, Erguer-se).
func restart(to_title := false) -> void:
	if not to_title:
		Engine.set_meta("play_now", true)
	else:
		Net.close()  # voltar ao título fecha a sala (ou sai dela)
	get_tree().paused = false
	get_tree().reload_current_scene()


# ---------- Configurações ----------

func load_settings() -> void:
	var cf := ConfigFile.new()
	if cf.load(SETTINGS_PATH) == OK:
		for k in SETTINGS:
			var v = cf.get_value("opcoes", k, SETTINGS[k])
			if typeof(v) == typeof(SETTINGS[k]) or (SETTINGS[k] is float and v is int):
				settings[k] = v
		if cf.get_value("opcoes", "vibrate", true) == false and not cf.has_section_key("opcoes", "vibe"):
			settings.vibe = 0  # até à 0.3.2 a vibração era só ligada / desligada
	else:
		settings.ui = int(_num(saved.get("ui"), 0))  # até à 0.2.0 o tamanho dos botões ia no jogo gravado
		settings.lang = 0 if OS.get_locale_language() == "pt" else 1
	for k in ["master", "music", "sfx"]:
		settings[k] = clampf(float(settings[k]), 0.0, 1.0)
	for k in CHOICES:
		settings[k] = clampi(int(settings[k]), 0, CHOICES[k] - 1)


func save_settings() -> void:
	var cf := ConfigFile.new()
	for k in settings:
		cf.set_value("opcoes", k, settings[k])
	cf.save(SETTINGS_PATH)


func set_setting(key: String, v) -> void:
	settings[key] = v
	apply_settings()
	save_settings()


func reset_settings() -> void:
	var seen: bool = settings.intro_seen  # repor não volta a mostrar a intro
	settings = SETTINGS.duplicate()
	settings.intro_seen = seen
	apply_settings()
	save_settings()


## Som por canal, FPS, resolução e botões no ecrã. Tremor, clarão, números e partículas leem-se na hora.
## Efeitos visuais de agora: os das Configurações, um degrau abaixo se a preservação térmica atuou.
func effects_level() -> int:
	return maxi(0, settings.effects - (1 if thermal >= 1 else 0))


## Preservação térmica (#313): o Godot não lê a temperatura, mas um telemóvel quente baixa o relógio do
## processador e os FPS caem. 12 s abaixo de 75% do limite: primeiro menos efeitos, depois 30 FPS.
func thermal_check(delta: float, fps: float) -> void:
	if not settings.thermal or thermal >= 2:
		return
	var cap: float = Engine.max_fps if Engine.max_fps > 0 else 60.0
	thermal_t = thermal_t + delta if fps < cap * 0.75 else maxf(0.0, thermal_t - delta * 2.0)
	if thermal_t >= 12.0:
		thermal_t = 0.0
		thermal += 1
		apply_settings()
		hud.toast("Preservação térmica: menos efeitos para o telemóvel não aquecer." if thermal == 1 else "Preservação térmica: 30 FPS para o telemóvel não aquecer.")


func apply_settings() -> void:
	for b in [["Master", "master"], ["Musica", "music"], ["Efeitos", "sfx"]]:
		var i := AudioServer.get_bus_index(b[0])
		var v: float = settings[b[1]]
		AudioServer.set_bus_volume_db(i, linear_to_db(maxf(v, 0.001)))
		AudioServer.set_bus_mute(i, v <= 0.0)
	TranslationServer.set_locale("en_GB" if settings.lang == 1 else "pt_PT")
	Engine.max_fps = FPS_CAPS[settings.fps]
	if thermal >= 2 and (Engine.max_fps == 0 or Engine.max_fps > 30):
		Engine.max_fps = 30
	# Poupança: desenha a 720p e estica (muito menos píxeis nos ecrãs grandes)
	get_tree().root.content_scale_mode = Window.CONTENT_SCALE_MODE_VIEWPORT if settings.res == 1 else Window.CONTENT_SCALE_MODE_CANVAS_ITEMS
	if hud != null:
		hud.set_ui_scale(settings.ui)
		hud.pad.modulate.a = OPACITY[settings.opacity]
		hud.set_lefty(settings.lefty)
		hud.set_filter(settings.colorblind, settings.comfort * 0.5)
		hud.set_potion_scale(settings.potion_ui)
	if player != null:
		player.boss_first = settings.boss_aim
	for pfx in ["", "p2_"]:
		for a in PAD_AXES:
			InputMap.action_set_deadzone(pfx + a, DEADZONES[settings.deadzone])


## Menu → Desbloquear personagem: quem ficou preso numa parede volta ao sítio de partida da zona.
func unstuck() -> void:
	var at: Vector2 = CRYPT_ORIGIN + CRYPT_IN if zone == "crypt" else Vector2(0, 300)
	for i in players.size():
		players[i].position = at + Vector2(50 * i, 0)
	cam.position = at
	cam.reset_smoothing()


## Vibração no telemóvel e nos comandos (se estiver ligada nas Configurações).
## who = o herói a quem aconteceu (só vibra o telemóvel dele); sem who vibra em todos.
func vibrate(ms: int, strength := 0.6, who = null) -> void:
	if who != null and Net.role == "host" and who.slot == 1:
		Net.echo("main", "vibrate", [ms, strength])  # o Guardião da Wi-Fi sente-o no telemóvel dele
		return
	if who == null:
		Net.echo("main", "vibrate", [ms, strength])
	if settings.vibe == 0:
		return
	var k: float = VIBE[settings.vibe]
	strength = clampf(strength * k, 0.05, 1.0)
	ms = int(ms * minf(k, 1.3))
	Input.vibrate_handheld(ms, strength)
	for d in pad_of:
		if d >= 0:
			Input.start_joy_vibration(d, strength * 0.6, strength, ms / 1000.0)


## Lê o jogo gravado. Ficheiro em falta ou estragado: começa do zero, sem rebentar.
func _read_save() -> Dictionary:
	if not FileAccess.file_exists(SAVE_PATH):
		return {}
	var d = JSON.parse_string(FileAccess.get_file_as_string(SAVE_PATH))
	return d if d is Dictionary else {}


static func _num(v, default: float) -> float:
	return float(v) if v is int or v is float else default


## Cada valor é conferido: o que não fizer sentido fica como num jogo novo.
func _apply_save() -> void:
	level = clampi(int(_num(saved.get("level"), 1)), 1, 999)
	xp = clampi(int(_num(saved.get("xp"), 0)), 0, 1000000)
	var kl = saved.get("kills")
	if kl is Dictionary:
		for k in XP:
			if kl.has(k):
				kills[k] = clampi(int(_num(kl[k], 0)), 0, 100000000)
	var c = saved.get("currency")
	if c is Dictionary:
		for k in currency:
			currency[k] = clampi(int(_num(c.get(k), 0)), 0, 1000000)
	var w = saved.get("weapon")
	if w is Dictionary and w.get("suffixes") is Array and String(w.get("hidden", "")) in HIDDEN:
		var suf: Array = w.suffixes.filter(func(s): return s is String and s in SUFFIXES)
		if suf.size() == 2:
			weapon = {"tier": clampi(int(_num(w.get("tier"), 0)), 0, 999), "suffixes": suf, "hidden": String(w.hidden), "sealed": w.get("sealed") != false}
	if saved.get("flasks") is Array:
		for f in saved.flasks:
			if f is String and f in Player.SUPPORTS and not f in flasks:
				flasks.append(f)
	var t = saved.get("tomb")
	if t is Dictionary and t.get("pos") is Array and t.pos.size() == 2 and t.get("lost") is Dictionary:
		var lost := {}
		for k in currency:
			lost[k] = clampi(int(_num(t.lost.get(k), 0)), 0, 1000000)
		var pos := Vector2(_num(t.pos[0], 0.0), _num(t.pos[1], 0.0))
		if MAP.has_point(pos) and lost.values().any(func(v): return v > 0):
			tomb = {"pos": pos, "lost": lost}


func _apply_hero(p) -> void:
	var heroes = saved.get("heroes")
	var h = heroes.get(p.hero) if heroes is Dictionary else null
	if not h is Dictionary:
		return
	p.points = clampi(int(_num(h.get("points"), level - 1)), 0, 999)
	if h.get("passives") is Array:
		for id in h.passives:  # pela ordem gravada: cada nó só entra se a raiz dele já entrou
			if id is String and PASSIVES.has(id) and not id in p.passives and PASSIVES[id].req in p.passives:
				p.passives.append(id)
	if h.get("supports") is Dictionary:
		for id in p.order:
			if h.supports.get(id) in p.SUPPORTS:
				p.skills[id].support = h.supports[id]


# ---------- Arma & moedas ----------

func stat(key: String) -> float:
	var v := 0.0
	for s in weapon.suffixes:
		v += SUFFIXES[s].get(key, 0.0)
	if not weapon.sealed:
		v += HIDDEN[weapon.hidden].get(key, 0.0)
	if key == "dmg":
		v += weapon.tier * 0.1
	return v


func weapon_text() -> String:
	# os sufixos e a propriedade oculta gravam-se em português: só se traduzem aqui, ao mostrar
	var hid: String = tr("[SELADO — usa Cinzas]") if weapon.sealed else tr(weapon.hidden)
	return tr("Gadanha do Coveiro +%d  %s\nOculto: %s") % [weapon.tier, ", ".join(weapon.suffixes.map(func(s): return tr(s))), hid]


func _reroll_weapon() -> void:
	var keys := SUFFIXES.keys()
	keys.shuffle()
	weapon.suffixes = keys.slice(0, 2)
	weapon.hidden = HIDDEN.keys()[rng.randi() % HIDDEN.size()]
	weapon.sealed = true


func use_currency(kind: String) -> String:
	match kind:
		"ink":
			if currency.ink < 1:
				return "Sem Tinteiros de Sangue Negro."
			currency.ink -= 1
			_reroll_weapon()
			return "Sufixos rerrolados — a propriedade oculta foi selada de novo."
		"ash":
			if not weapon.sealed:
				return "Nada selado para revelar."
			if currency.ash < 1:
				return "Sem Cinzas do Purgatório."
			currency.ash -= 1
			weapon.sealed = false
			return tr("Revelado: %s") % tr(weapon.hidden)
		"bone":
			if currency.bone < 5:
				return "Precisa de 5 Ossos Ancestrais."
			currency.bone -= 5
			weapon.tier += 1
			return tr("Gadanha reforjada: +%d") % weapon.tier
	return ""


## kind "flask" com flask = o Frasco de Alma (veloz, eco, tumular, colerica).
func drop(kind: String, pos: Vector2, amount := 1, pop := Vector2.ZERO, flask := ""):
	var l := Loot.new()
	l.main = self
	l.kind = kind
	l.amount = amount
	l.pop = pop
	l.flask = flask
	l.position = pos + Vector2(rng.randf_range(-30, 30), rng.randf_range(-20, 20))
	add_child(l)
	return l


func collect(l) -> void:
	if l.is_queued_for_deletion():
		return  # já apanhada neste frame (ao mudar de zona e por estar perto)
	if l.kind != "flask":
		currency[l.kind] += l.amount
	elif l.flask in flasks:
		currency.bone += 5  # repetido: vale ossos
	else:
		flasks.append(l.flask)
		hud.toast(tr("Encontraste a %s! Põe-na numa habilidade no Arsenal.") % tr(Player.SUPPORT_NAMES[l.flask]))
		sfx("chest")
		save_game()
	l.queue_free()


## Alma Tumular: o inimigo ergue-se como esqueleto do herói. No máximo 4; o mais antigo desfaz-se.
func spawn_ally(pos: Vector2, by) -> void:
	var allies := get_tree().get_nodes_in_group("allies")
	if allies.size() >= MAX_ALLIES:
		allies[0].life = 0.0
	var a := Ally.new()
	a.main = self
	a.owner_p = by
	a.position = pos
	add_child(a)


# ---------- Combate ----------

func enemies() -> Array:
	return get_tree().get_nodes_in_group("enemies")


func spawn_enemy(kind: String, pos: Vector2, mods: Dictionary, in_cortejo: bool):
	var e := Enemy.new()
	e.main = self
	e.cortejo = in_cortejo
	e.position = pos
	e.setup(kind, mods)
	e.killed.connect(_on_enemy_killed)
	add_child(e)
	return e


func spawn_fx(kind: String, pos: Vector2, radius: float, color: Color, dir := Vector2.RIGHT) -> void:
	var f := Fx.new()
	f.kind = kind
	f.radius = radius
	f.color = color
	f.dir = dir
	f.position = pos
	f.amount = EFFECTS[effects_level()]
	add_child(f)


func spawn_bolt(pos: Vector2, dir: Vector2, dmg: float, r: float, by, raise := false) -> void:
	var b := Bolt.new()
	b.main = self
	b.by = by
	b.raise = raise
	b.dir = dir
	b.dmg = dmg
	b.r = r
	b.position = pos + dir * 20.0
	add_child(b)


## Devolve [dano, crítico]. O inimigo trata do flash, número, faíscas e recuo.
func _damage(e, dmg: float, by, from: Vector2) -> Array:
	if e.is_boss:
		dmg *= 1.0 + by.stat("boss")
	if e.exposed_t > 0.0:
		dmg *= 3.0
	if e.stagger_t > 0.0:
		dmg *= 1.5
	if e.necro > 0:  # Necrose Galopante (#154): cada camada já posta faz levar +5%
		dmg *= 1.0 + e.necro * 0.05
	if by.stat("rot") > 0.0:
		e.apply_rot(dmg * 0.3 * by.stat("rot"))
	if by.stat("calcify") > 0.0:
		e.add_calc()
	if by.stat("necro") > 0.0:
		e.add_necro()
	var crit := rng.randf() < CRIT + (0.35 if by.overload_t > 0.0 else 0.0)  # Sobrecarga de Alma: +35% de crítico
	if crit:
		dmg *= CRIT_MULT
	var dir: Vector2 = from.direction_to(e.position) if from.distance_to(e.position) > 1.0 else Vector2.from_angle(rng.randf() * TAU)
	e.raise_owner = raise_by  # o último golpe decide se ele se ergue como aliado
	e.take_damage(dmg, true, dir, crit)
	return [dmg, crit]


func hit_circle(origin: Vector2, radius: float, dmg: float, by, bleeds := false) -> void:
	var hits := []
	for e in enemies():
		if e.position.distance_to(origin) <= radius + e.radius:
			hits.append(_damage(e, dmg, by, origin))
			if bleeds:
				e.apply_bleed(dmg * (0.35 + by.stat("bleed")), 3.0)
	_impact(hits, by)


## "Bleed & Bone": cada golpe corpo a corpo amaldiçoa com sangramento.
func hit_arc(origin: Vector2, dir: Vector2, radius: float, dmg: float, by) -> void:
	var hits := []
	for e in enemies():
		var v: Vector2 = e.position - origin
		if v.length() <= radius + e.radius and (v.length() < 24.0 or absf(dir.angle_to(v)) < 1.3):
			hits.append(_damage(e, dmg, by, origin))
			e.apply_bleed(dmg * (0.35 + by.stat("bleed")), 3.0)
	_impact(hits, by)


## Um golpe = um tremor, um congelar e um som, mesmo que acerte em 20 inimigos.
## Crítico: congela mais, zoom de impacto e flash no ecrã.
func _impact(hits: Array, by) -> void:
	if hits.is_empty():
		return
	var dealt := 0.0
	var crit := false
	for h in hits:
		dealt += h[0]
		crit = crit or h[1]
	by.heal(dealt * by.stat("leech"))
	shake = maxf(shake, 9.0 if crit else 4.0)
	hitstop(0.08 if crit else 0.045)
	sfx("crit" if crit else "hit")
	if crit:
		zoom_kick = maxf(zoom_kick, 0.06)
		hud.flash(0.22)
		vibrate(35, 0.5, by)


func hitstop(dur: float) -> void:
	if Engine.time_scale < 1.0:
		return
	Engine.time_scale = 0.05
	await get_tree().create_timer(dur, true, false, true).timeout
	Engine.time_scale = 1.0


func sfx(name: String) -> void:
	Net.echo("main", "sfx", [name])
	var now := Time.get_ticks_msec()
	if now - sfx_last.get(name, -1000) < 40:
		return
	sfx_last[name] = now
	var a := AudioStreamPlayer.new()
	a.stream = SFX[name]
	a.pitch_scale = randf_range(0.9, 1.12)
	a.volume_db = -4.0
	a.bus = "Efeitos"
	a.finished.connect(a.queue_free)
	add_child(a)
	a.play()


func number(pos: Vector2, text: String, size: float, color: Color):
	var f := Fx.new()
	f.kind = "num"
	f.text = text
	f.radius = size
	f.color = color
	f.position = pos
	f.visible = settings.numbers
	add_child(f)
	return f


func _on_enemy_killed(e) -> void:
	gain_xp(XP[e.kind])
	kills[e.kind] = kills.get(e.kind, 0) + 1
	if e.is_boss:
		shake = 16.0
		hitstop(0.18)
	if e.kind == "herald":
		music.stop()
		arena_r = 0.0
		hud.card_t = minf(hud.card_t, 0.4)
		hud.toast("O Arauto Fúnebre caiu! O Cortejo vacila...")
	if e == guardian:
		guardian = null
		var m := 1.0 + 0.2 * (level - 1)
		_spawn_chest([["bone", int(6 * m)], ["ink", 2 + level / 3], ["ash", 1 + level / 4]], e.position + Vector2(0, 40))
		hud.card_t = minf(hud.card_t, 0.4)
		hud.toast("O Carcereiro caiu! O relicário da cripta está livre.")
	for p in players:
		if not p.dead:
			p.heal(p.stat("kill_heal"))
			p.fill_potions(1.0 if e.is_boss else 0.25)  # 4 mortes = 1 poção
	if e.raise_owner != null and is_instance_valid(e.raise_owner) and not e.is_boss:
		spawn_ally(e.position, e.raise_owner)
	# Frascos de Alma: os chefes deixam sempre um que o grupo ainda não tenha; os outros, muito raramente
	var missing: Array = Player.SUPPORTS.filter(func(f): return not f in flasks)
	if not missing.is_empty() and (e.is_boss or rng.randf() < 0.006):
		drop("flask", e.position, 1, Vector2.from_angle(rng.randf() * TAU) * 120.0, missing[rng.randi() % missing.size()])
	if e.is_boss:
		for k in ["bone", "bone", "ink", "ash"]:
			drop(k, e.position, 1, Vector2.from_angle(rng.randf() * TAU) * 160.0)
	else:
		var r := rng.randf()
		if r < 0.04:
			drop("ash", e.position)
		elif r < 0.10:
			drop("ink", e.position)
		elif r < 0.38:
			drop("bone", e.position)
	if e.cortejo and cortejo.active:
		cortejo.alive -= 1
		if cortejo.alive <= 0:
			_wave_cleared()


# ---------- O Arauto Fúnebre ----------

## Entrada do chefe: fecha a arena, o sino dobra duas vezes (o mundo escurece e treme),
## e só então o Arauto sobe do chão; quando acaba de subir, ruge (boss_roar).
func _boss_intro(mods: Dictionary) -> void:
	arena_r = ARENA_R
	rumble = 2.6
	sfx("bell")
	hud.toast("O sino dobra... o Arauto Fúnebre aproxima-se.")
	await get_tree().create_timer(1.3, false).timeout
	if not is_inside_tree() or not cortejo.active:
		return
	sfx("bell")
	await get_tree().create_timer(1.3, false).timeout
	if not is_inside_tree() or not cortejo.active:
		return
	var h = spawn_enemy("herald", monument_pos + Vector2(280, -60), mods, true)  # ao lado do obelisco, à vista
	h.rise_t = 1.4
	spawn_fx("dust", h.position, 140.0, Color.WHITE)
	focus_pos = h.position + Vector2(0, -40)
	focus_t = 3.2


func boss_roar(e) -> void:
	shake = 18.0
	vibrate(350, 1.0)
	zoom_kick = maxf(zoom_kick, 0.06)
	sfx("roar")
	sfx("bell")
	spawn_fx("ring", e.position, 320.0, Color(0.4, 1.0, 0.6))
	spawn_fx("dust", e.position, 120.0, Color.WHITE)
	hud.name_card(e.NAMES[e.kind], "Pregoeiro do Cortejo Fúnebre")
	e.bar_fill = 0.0
	music.play()


## Sino no chão: dano em área a quem estiver perto.
func boss_slam(pos: Vector2, r: float, dmg: float, by := "", src = null, sound := "bell") -> void:
	for p in players:
		if not p.dead and p.position.distance_to(pos) < r:
			p.take_damage(dmg, by, src)
	spawn_fx("ring", pos, r, Color(0.4, 1.0, 0.6))
	spawn_fx("dust", pos, 90.0, Color.WHITE)
	shake = maxf(shake, 11.0)
	sfx(sound)


func summon_minions(e, n: int) -> void:
	for i in n:
		var pos: Vector2 = e.position + Vector2.from_angle(TAU * i / n + 0.4) * 110.0
		spawn_enemy("skeleton", pos, e.mods, e.cortejo)
		spawn_fx("dust", pos, 40.0, Color.WHITE)
		if e.cortejo and cortejo.active:
			cortejo.alive += 1


# ---------- Liga "Cortejo Fúnebre" ----------

func near_monument() -> bool:
	for p in players:
		if not cortejo.active and not p.dead and p.position.distance_to(monument_pos) < 130.0:
			return true
	return false


func near_chest() -> bool:
	if chest == null or chest.opening >= 0.0:
		return false
	for p in players:
		if not p.dead and p.position.distance_to(chest.position) < 110.0:
			return true
	return false


func interact() -> void:
	if Net.is_guest():
		Net.tap(0)
		return
	for p in players:
		var e = soul_target(p)
		if e != null:
			soul_strike(e, p)
			return
	var door := near_door()
	if near_chest():
		chest.open()
	elif door == "down":
		enter_crypt()
	elif door == "up":
		leave_crypt()
	elif near_monument() and hud.panel == null:
		hud.open_cortejo()


## Execução Espectral (#12) ou extração da Alma Ancestral (#16): o inimigo ao alcance de p (ou null).
func soul_target(p):
	if p.dead:
		return null
	for e in enemies():
		if (e.executable() or e.extractable()) and p.position.distance_to(e.position) < e.radius + 120.0:
			return e
	return null


func soul_strike(e, p) -> void:
	hitstop(0.14)
	hud.flash(0.3)
	shake = maxf(shake, 14.0)
	zoom_kick = maxf(zoom_kick, 0.08)
	vibrate(70, 0.8, p)
	var mid: Vector2 = e.position + Vector2(0, e._top() * 0.5)
	if e.extractable():  # a Alma Ancestral sai do peito do chefe quebrado
		e.extracted = true
		currency.bone += 3
		p.mana = minf(p.max_mana, p.mana + 30.0)
		number(mid + Vector2(0, -30), tr("Alma extraída! +3 Ossos"), 22.0, Color(0.6, 1.0, 0.75))
		spawn_fx("ring", e.position, e.radius * 3.0, Color(0.4, 1.0, 0.6))
		spawn_fx("glow", mid, 120.0, Color(0.5, 1.0, 0.7))
		e.take_damage(e.max_hp * 0.06, true, p.position.direction_to(e.position), true)
		sfx("chest")
		return
	number(mid + Vector2(0, -30), tr("Executado!"), 26.0, Color(0.75, 1.0, 0.95))
	spawn_fx("ring", e.position, 110.0, Color(0.75, 1.0, 0.95))
	spawn_fx("glow", mid, 90.0, Color(0.75, 1.0, 0.95))
	e.take_damage(e.hp + 1.0, true, p.position.direction_to(e.position), true)
	p.mana = minf(p.max_mana, p.mana + 15.0)
	p.heal(p.max_hp * 0.05)
	sfx("crit")


## Cólera Póstuma (#17): o esqueleto erguido desfaz-se num miasma que cega quem está perto e cura o dono.
func miasma(pos: Vector2, by) -> void:
	for e in enemies():
		if e.position.distance_to(pos) < 130.0 + e.radius:
			e.blind_t = 2.5
	spawn_fx("ring", pos, 130.0, Color(0.45, 0.3, 0.5))
	spawn_fx("dust", pos, 90.0, Color(0.5, 0.4, 0.55))
	if is_instance_valid(by) and not by.dead:
		by.heal(by.max_hp * 0.06)


## Sangue no Solo (#23): em cima de uma poça de sangue, heróis e lacaios andam +25%.
func blood_speed(pos: Vector2) -> float:
	for pool in blood:
		if pos.distance_squared_to(pool[0]) < BLOOD_R * BLOOD_R:
			return 1.25
	return 1.0


## Boneco de treino (#287): ao lado do monumento, sempre que se está no cemitério.
func _spawn_dummy() -> void:
	var d = spawn_enemy("skeleton", monument_pos + DUMMY_AT, {}, false)
	d.dummy = true
	d.title = "Boneco de treino"


# ---------- Cripta dos Condenados ----------

## "down" ao pé das escadas no cemitério, "up" ao pé da porta do fundo da cripta, "" longe das duas.
func near_door() -> String:
	var at := CRYPT_DOOR if zone == "world" else CRYPT_ORIGIN + CRYPT_OUT
	for p in players:
		if not p.dead and p.position.distance_to(at) < 130.0:
			return "down" if zone == "world" else "up"
	return ""


## Para onde aponta a seta do HUD: o túmulo por recuperar vem primeiro.
func objective() -> Vector2:
	if zone == "crypt":
		return guardian.position if is_instance_valid(guardian) else CRYPT_ORIGIN + CRYPT_OUT
	return tomb.pos if not tomb.is_empty() else monument_pos


## Paredes da cripta: o passo só vale se ficar no chão; senão desliza ao longo da parede ou fica parado.
func walk(from: Vector2, to: Vector2) -> Vector2:
	if zone != "crypt" or Geometry2D.is_point_in_polygon(to, crypt_floor):
		return to
	for p in [Vector2(to.x, from.y), Vector2(from.x, to.y)]:
		if Geometry2D.is_point_in_polygon(p, crypt_floor):
			return p
	return from


## Descer: o grupo inteiro vai para a entrada da cripta, que se enche de mortos e do Carcereiro.
func enter_crypt() -> void:
	if cortejo.active:
		hud.toast("O Cortejo Fúnebre ainda não acabou.")
		return
	_change_zone("crypt", CRYPT_ORIGIN + CRYPT_IN)
	guardian_met = false
	var mods := {"hp": 1.0 + 0.15 * (level - 1), "dmg": 1.0 + 0.08 * (level - 1)}
	guardian = spawn_enemy("colossus", CRYPT_ORIGIN + CRYPT_BOSS, {"hp": mods.hp * 1.8, "dmg": mods.dmg * 1.2}, false)
	guardian.title = "Carcereiro da Cripta"
	guardian.aggro = 480.0
	var n := 0
	for i in 600:
		if n >= 20:
			break
		var p := Vector2(rng.randf_range(bounds.position.x, bounds.end.x), rng.randf_range(bounds.position.y, bounds.end.y))
		if Geometry2D.is_point_in_polygon(p, crypt_floor) and p.distance_to(CRYPT_ORIGIN + CRYPT_IN) > 620.0:
			var e = spawn_enemy("specter" if rng.randf() < 0.3 else "skeleton", p, mods, false)
			e.aggro = 520.0
			n += 1
	hud.toast("Cripta dos Condenados — derrota o Carcereiro e abre o relicário.")


func leave_crypt() -> void:
	guardian = null
	_change_zone("world", CRYPT_DOOR + Vector2(0, 80))
	hud.toast("De volta ao cemitério.")


## Cada zona tem os seus inimigos e o seu baú; muda limites da câmara, escuridão e faz a transição a negro.
func _change_zone(z: String, at: Vector2) -> void:
	zone = z
	for e in enemies():
		e.queue_free()
	# O que ficou para trás vem connosco: moedas no chão e o relicário por abrir
	for l in get_tree().get_nodes_in_group("loot"):
		collect(l)
	if chest:
		if not chest.opened:
			for r in chest.rewards:
				currency[r[0]] += r[1]
			hud.toast("Levaste o relicário contigo.")
		chest.queue_free()
		chest = null
	for i in players.size():
		players[i].position = at + Vector2(50 * i, 0)
		players[i].held.clear()
	zone_view(at)
	spawn_t = 2.0
	sfx("hit")
	if z == "world":
		_spawn_dummy()


## A parte que se vê de mudar de zona (o convidado também a faz quando a zona do anfitrião muda).
func zone_view(at: Vector2) -> void:
	bounds = MAP if zone == "world" else Rect2(CRYPT_ORIGIN, CRYPT.get_size())
	cam.limit_left = int(bounds.position.x)
	cam.limit_top = int(bounds.position.y)
	cam.limit_right = int(bounds.end.x)
	cam.limit_bottom = int(bounds.end.y)
	cam.position = at
	cam.reset_smoothing()
	tint.color = Color(0.74, 0.8, 0.78) if zone == "crypt" else Color.WHITE
	hud.fade()


func reward_mult(affixes: Array) -> float:
	return 1.0 + 0.5 * affixes.size()


func start_wave(affixes: Array) -> void:
	cortejo.active = true
	cortejo.affixes = affixes
	cortejo.wave += 1
	if chest:
		chest.queue_free()
		chest = null
	var w: int = cortejo.wave
	var mods := {"hp": 1.0 + 0.45 * (w - 1), "speed": 1.0, "dmg": 1.0 + 0.15 * (w - 1)}
	if "blindados" in affixes: mods.hp *= 1.6
	if "furia" in affixes: mods.speed *= 1.35
	if "laminas" in affixes: mods.dmg *= 1.5
	var escorts := int((6 + 4 * w) * (1.6 if "legiao" in affixes else 1.0))
	var colossi := (0 if w == WAVES else 1) + (1 if "gemeo" in affixes else 0)
	for e in enemies():
		if not e.cortejo:
			e.queue_free()
	for i in colossi:
		spawn_enemy("colossus", monument_pos + Vector2(-120 + 240 * i, -160), mods, true)
	for i in escorts:
		var p := monument_pos + Vector2.from_angle(rng.randf() * TAU) * rng.randf_range(220, 380)
		spawn_enemy("specter" if rng.randf() < 0.3 else "skeleton", p, mods, true)
	# na última onda o Arauto conta já, embora só apareça depois do sino
	cortejo.alive = colossi + escorts + (1 if w == WAVES else 0)
	spawn_fx("ring", monument_pos, 400.0, Color(0.9, 0.2, 0.25))
	hud.toast(tr("Cortejo Fúnebre — onda %d/%d   (recompensa x%.1f)") % [w, WAVES, reward_mult(affixes)])
	if w == WAVES:
		_boss_intro(mods)


## O que uma onda dá; o menu do Cortejo mostra exatamente isto antes de a invocar.
## A última onda soma o tesouro final, que vai para o Relicário selado.
func wave_rewards(w: int, affixes: Array) -> Dictionary:
	var m := reward_mult(affixes)
	var r := {"bone": int(4 * w * m), "ink": int(ceil(w * m * 0.6)), "ash": int(ceil((w - 1) * m * 0.6))}
	if w >= WAVES:
		r.ink += int(3 * m)
		r.ash += int(3 * m)
	return r


func _wave_cleared() -> void:
	var w: int = cortejo.wave
	var r := wave_rewards(w, cortejo.affixes)
	cortejo.active = false
	if w >= WAVES:
		_spawn_chest(r.keys().filter(func(k): return r[k] > 0).map(func(k): return [k, r[k]]))
		end_cortejo()
		hud.toast("O Cortejo foi quebrado! Um Relicário selado ergue-se no monumento.")
		return
	for k in r:
		if r[k] > 0:
			drop(k, monument_pos, r[k])
	hud.open_cortejo()


func _spawn_chest(rewards: Array, pos := Vector2.INF) -> void:
	chest = Chest.new()
	chest.main = self
	chest.rewards = rewards
	chest.position = monument_pos + Vector2(0, 150) if pos == Vector2.INF else pos
	add_child(chest)
	spawn_fx("dust", chest.position, 70.0, Color.WHITE)
	spawn_fx("ring", chest.position, 120.0, Color(1.0, 0.85, 0.4))
	shake = maxf(shake, 8.0)
	sfx("hit")


func end_cortejo() -> void:
	cortejo = {"active": false, "wave": 0, "affixes": [], "alive": 0}
	arena_r = 0.0
	music.stop()


# ---------- Cenário ----------

## Adereços são Sprite2D com os pés na origem, para o y-sort pôr os heróis atrás deles.
func _prop(tex: Texture2D, pos: Vector2, sc: float, flip := false) -> Sprite2D:
	var sp := Sprite2D.new()
	sp.texture = tex
	sp.offset = Vector2(0, -tex.get_height() / 2.0)
	sp.scale = Vector2(sc, sc)
	sp.flip_h = flip
	sp.position = pos
	add_child(sp)
	# Os altos (estátuas, lanternas, árvores, capelas, o monumento, as escadas da cripta) tapam quem passa atrás (#92);
	# guarda-se só o meio do desenho: as pontas são quase só vazio
	var box := tex.get_size() * sc
	if box.y >= 100.0:
		tall.append(Rect2(pos.x - box.x * 0.3, pos.y - box.y, box.x * 0.6, box.y))
	return sp


func _hub_rect() -> Rect2:
	return Rect2(monument_pos - HUB_SPOT, HUB.get_size())


func _gen_world() -> void:
	# Chão: losangos em fila, cada fila meia célula ao lado da anterior
	var noise := FastNoiseLite.new()
	noise.seed = 7
	noise.frequency = 0.0012
	var noise2 := FastNoiseLite.new()
	noise2.seed = 13
	noise2.frequency = 0.004
	var w := 256.0 * TILE_SCALE
	var hh := TILE_HH * TILE_SCALE
	for r in int(MAP.size.y / hh) + 6:
		var y := MAP.position.y - hh * 2.0 + r * hh
		for c in int(MAP.size.x / w) + 4:
			var pos := Vector2(MAP.position.x - w + c * w + (w / 2.0 if r % 2 == 1 else 0.0), y)
			tile_list.append([_tile_at(pos, noise.get_noise_2d(pos.x, pos.y), noise2.get_noise_2d(pos.x, pos.y)), pos])
	# Adereços fora da praça pintada, sem se atropelarem
	var inner := _hub_rect().grow(-260.0)
	var names := PROPS.keys()
	var total := 0
	for n in names:
		total += PROPS[n][2]
	# Escadas para a cripta: lugar fixo, com brilho e nome por cima
	var placed := [[CRYPT_DOOR, 170.0]]
	_prop(CRYPT_DOOR_TEX, CRYPT_DOOR, 200.0 / CRYPT_DOOR_TEX.get_height())
	glows.append([CRYPT_DOOR + Vector2(0, 10), 100.0])
	var door_name := Label.new()
	door_name.text = "Cripta dos Condenados"
	door_name.position = CRYPT_DOOR + Vector2(-200, -248)
	door_name.size = Vector2(400, 32)
	door_name.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	door_name.add_theme_font_size_override("font_size", 32)
	door_name.add_theme_color_override("font_color", Color(0.55, 1.0, 0.7))
	door_name.add_theme_color_override("font_outline_color", Color.BLACK)
	door_name.add_theme_constant_override("outline_size", 6)
	add_child(door_name)
	for i in 900:
		if placed.size() >= 240:
			break
		var pos := Vector2(rng.randf_range(MAP.position.x + 40, MAP.end.x - 40), rng.randf_range(MAP.position.y + 40, MAP.end.y - 40))
		if inner.has_point(pos) or absf(pos.x) < 90.0 and pos.y > 0.0:
			continue
		var roll := rng.randi() % total
		var kind: String = names[0]
		for n in names:
			roll -= PROPS[n][2]
			if roll < 0:
				kind = n
				break
		var h: float = PROPS[kind][1] * rng.randf_range(0.9, 1.1)
		var rad := h * 0.4
		var free := true
		for q in placed:
			if pos.distance_to(q[0]) < rad + q[1]:
				free = false
				break
		if not free:
			continue
		placed.append([pos, rad])
		var tex: Texture2D = PROPS[kind][0]
		var sp := _prop(tex, pos, h / tex.get_height(), rng.randf() < 0.5)
		sp.modulate = Color(0.8, 0.88, 0.84).darkened(rng.randf() * 0.2)
		if kind in ["lantern", "candles"]:
			glows.append([pos, 70.0 if kind == "lantern" else 50.0])
	monument = _prop(MON, monument_pos, 230.0 / MON.get_height())
	var deco := [[preload("res://art/props/waypoint_on.png"), Vector2(-150, 420), 80.0], [preload("res://art/props/shrine_on.png"), Vector2(330, 120), 90.0]]
	for d in deco:
		_prop(d[0], d[1], d[2] / d[0].get_height())
		glows.append([d[1], 80.0])
	for i in 50:
		fog.append([Vector2(rng.randf_range(-1600, 1600), rng.randf_range(-1600, 1600)), rng.randf()])


func _tile_at(pos: Vector2, n: float, n2: float) -> String:
	if absf(pos.x) < 110.0 and pos.y > 300.0:
		return "cobble_moss" if rng.randf() < 0.35 else "cobble"
	if n2 > 0.55:
		return "water"
	if n < -0.38:
		return "slab_roots" if rng.randf() < 0.3 else "slab"
	if rng.randf() < 0.05:
		return "bones"
	return "mud" if n > 0.2 else "grass"


func _draw_tiles() -> void:
	tiles.draw_rect(MAP.grow(200.0), Color(0.05, 0.07, 0.06))
	var s := TILE_SCALE * 1.03  # um pouco maior para não haver frestas entre losangos
	for t in tile_list:
		var tex: Texture2D = TILES[t[0]]
		var pos: Vector2 = t[1]
		tiles.draw_texture_rect(tex, Rect2(pos.x - 128.0 * s, pos.y - TILE_LV[t[0]] * s, 256.0 * s, tex.get_height() * s), false, Color(0.6, 0.66, 0.62))
	tiles.draw_texture_rect(HUB, _hub_rect(), false)
	tiles.draw_texture_rect(CRYPT, Rect2(CRYPT_ORIGIN, CRYPT.get_size()), false)
	for g in glows + CRYPT_GLOWS.map(func(p): return [CRYPT_ORIGIN + p, 140.0]):
		for i in 4:
			tiles.draw_circle(g[0], g[1] * (1.0 - i * 0.22), Color(0.35, 1.0, 0.6, 0.05))


func _draw_world() -> void:
	for pool in blood:  # Sangue no Solo (#23): poça escura que seca no último segundo
		var a: float = clampf(pool[1] - time, 0.0, 1.0)
		ground.draw_circle(pool[0], BLOOD_R, Color(0.32, 0.0, 0.03, 0.6 * a))
		ground.draw_circle(pool[0] + Vector2(6, -4), BLOOD_R * 0.5, Color(0.5, 0.02, 0.06, 0.55 * a))
	for tooth in teeth:  # Dentes de Sepultura: três pontas de osso que se desfazem
		var a: float = minf(1.0, tooth[1])
		for k in 3:
			var b: Vector2 = tooth[0] + Vector2((k - 1) * 9.0, (k % 2) * 4.0)
			ground.draw_colored_polygon(PackedVector2Array([b + Vector2(-4, 2), b + Vector2(4, 2), b + Vector2(0, -12)]), Color(0.9, 0.86, 0.75, 0.85 * a))
	for pr in fog if effects_level() > 0 else []:  # efeitos baixos: sem nevoeiro (círculos grandes a cada frame)
		var s: float = pr[1]
		var drift := Vector2(sin(time * 0.2 + s * 9.0), cos(time * 0.15 + s * 7.0)) * 40.0
		ground.draw_circle(pr[0] + drift, 160.0 + s * 140.0, Color(0.35, 0.8, 0.55, 0.03))
	# Brilho do monumento: verde em repouso, vermelho durante o Cortejo
	var glow := Color(0.9, 0.15, 0.2) if cortejo.active else Color(0.3, 1.0, 0.6)
	ground.draw_circle(monument_pos, 110.0 + sin(time * 3.0) * 12.0, Color(glow, 0.13))
	# Arena do chefe: muro de chamas de alma que não deixa ninguém fugir
	if arena_r > 0.0:
		ground.draw_arc(monument_pos, arena_r, 0, TAU, 96, Color(0.3, 1.0, 0.6, 0.35), 10.0)
		for i in 72:
			var b := monument_pos + Vector2.from_angle(TAU * i / 72.0) * arena_r
			var h := 34.0 + 20.0 * sin(time * 6.0 + i * 1.7)
			ground.draw_line(b, b + Vector2(0, -h), Color(0.4, 1.0, 0.65, 0.4), 5.0)
	ground.draw_rect(MAP, Color(0.2, 0.18, 0.15), false, 10.0)


## Silhueta atrás das paredes (#92): quem fica tapado por um adereço alto desenha-se outra vez por cima dele, numa cor
## só (a do herói; vermelho nos monstros). Só entram na conta os adereços que a câmara apanha.
func _draw_xray() -> void:
	var half := get_viewport_rect().size / 2.0 / cam.zoom
	var view := Rect2(cam.get_screen_center_position() - half, half * 2.0)
	var near := tall.filter(func(r): return view.intersects(r))
	if near.is_empty():
		return
	for c in players + enemies():
		# quem ainda sai do chão ou já está a morrer não tem silhueta (o desenho dele ainda/já não se vê)
		if (c in players or (c.rise_t <= 0.0 and not c.dying)) and behind_prop(c, near):
			xray.draw_set_transform_matrix(c.transform * c.pose)
			xray.draw_texture(c.pose_tex, Vector2.ZERO, Color(c.tint, 0.55) if c in players else Color(1.0, 0.25, 0.25, 0.45))


## O meio do desenho de c fica dentro de um adereço alto e os pés dele estão acima da base do adereço
## (o y-sort desenha o adereço depois dele). rects = tall, ou só os que estão à vista.
func behind_prop(c, rects: Array) -> bool:
	if c.pose_tex == null:
		return false
	var mid: Vector2 = c.transform * c.pose * (c.pose_tex.get_size() / 2.0)
	for r in rects:
		if r.end.y > c.position.y and r.has_point(mid):
			return true
	return false
