shader_type canvas_item;
// Fantasmas da esquiva: o desenho do herói em três tons da cor com que player o desenha (pela luz de cada texel)
// e, a desvanecer, um pontilhado de Bayer em células de 2 px em vez de transparência (o alfa da cor é o limiar).
// Efeitos adaptados de Sprite Fusion Pixel Art VFX (MIT, (c) 2026 Hugo Duprez)

const float BAYER[16] = {0.0, 8.0, 2.0, 10.0, 12.0, 4.0, 14.0, 6.0, 3.0, 11.0, 1.0, 9.0, 15.0, 7.0, 13.0, 5.0};

varying vec4 tint;

void vertex() {
	tint = COLOR;
}

void fragment() {
	vec4 tex = texture(TEXTURE, UV);
	float lum = dot(tex.rgb, vec3(0.299, 0.587, 0.114));
	vec3 c = lum > 0.55 ? min(tint.rgb * 1.35, vec3(1.0)) : lum > 0.25 ? tint.rgb : tint.rgb * 0.55;
	ivec2 g = ivec2(mod(floor(FRAGCOORD.xy / 2.0), 4.0));
	float th = (BAYER[g.y * 4 + g.x] + 0.5) / 16.0;
	COLOR = vec4(c, tex.a > 0.5 && tint.a > th ? 1.0 : 0.0);
}
