extends Node2D
## Esqueletos, espectros, colossos esqueléticos e o Arauto Fúnebre (chefe final do Cortejo).

signal killed(enemy)

const TEX := {
	"skeleton": preload("res://art/skeleton.png"),
	"specter": preload("res://art/specter.png"),
	"colossus": preload("res://art/colossus.png"),
	"herald": preload("res://art/anim/herald_0.png"),
}
const SCALES := {"skeleton": 0.3, "specter": 0.32, "colossus": 0.7, "herald": 0.47}
const NAMES := {"colossus": "Colosso Esquelético", "herald": "Arauto Fúnebre"}
const ATTACK_T := 0.4
const ACT_T := 0.9  # duração do sino no chão / da invocação do Arauto
const Feet := preload("res://art/anim/feet.gd")
## Duas folhas 4x2 por inimigo: 0-3 andar, 4-7 atacar, 8-9 parado, 10-11 ferido, 12-15 morrer; o Arauto
## usa 8-11 para invocar. Só usamos as mortes da 2.ª folha: nela o Gemini desenhou o esqueleto com armadura,
## o colosso sem ela e o espectro sem capuz, e trocar a cada golpe parecia outro monstro.
static var FRAMES := {
	"skeleton": range(16).map(func(i): return load("res://art/anim/skeleton_%d.png" % i)),
	"specter": range(16).map(func(i): return load("res://art/anim/specter_%d.png" % i)),
	"colossus": range(16).map(func(i): return load("res://art/anim/colossus_%d.png" % i)),
	"herald": range(16).map(func(i): return load("res://art/anim/herald_%d.png" % i)),
}

var main
var kind := "skeleton"
var cortejo := false
var is_boss := false
var title := ""  # nome próprio na barra do chefe (ex.: "Carcereiro da Cripta")
var aggro := INF  # na cripta os mortos só acordam quando um herói chega perto
var awake := false
var max_hp := 30.0
var hp := 30.0
var speed := 85.0
var dmg := 7.0
var mods := {}
var radius := 13.0
var bleed_dps := 0.0
var bleed_t := 0.0
var flash := 0.0
var attack_cd := 0.0
var attack_t := 0.0
var target
var knock := Vector2.ZERO
var lift := 0.0  # crítico atira o inimigo ao ar
var lift_v := 0.0
var hp_chunk := 30.0  # pedaço claro na barra que fica para trás e só depois escoa
var chunk_wait := 0.0
var bleed_acc := 0.0
var bleed_num_t := 0.0
var num_t := 9.0
var num_i := 0
var t := 0.0
var dying := false
var death_t := 0.0
var bar_fill := 0.0  # a barra do chefe enche do zero quando ele aparece
# Arauto
var rise_t := 0.0
var act := ""  # "slam" ou "summon"
var act_t := 0.0
var act_done := false
var slam_cd := 1.5
var summon_cd := 6.0
var last_step := 0


func setup(k: String, m: Dictionary) -> void:
	kind = k
	mods = m
	match k:
		"skeleton":
			max_hp = 30.0; speed = 85.0; dmg = 7.0; radius = 13.0
		"specter":
			max_hp = 18.0; speed = 135.0; dmg = 5.0; radius = 12.0
		"colossus":
			max_hp = 650.0; speed = 55.0; dmg = 24.0; radius = 50.0; is_boss = true
		"herald":
			max_hp = 1500.0; speed = 42.0; dmg = 30.0; radius = 55.0; is_boss = true
	max_hp *= m.get("hp", 1.0)
	speed *= m.get("speed", 1.0)
	dmg *= m.get("dmg", 1.0)
	hp = max_hp
	hp_chunk = max_hp
	t = randf() * 10.0


func _ready() -> void:
	add_to_group("enemies")


func _process(delta: float) -> void:
	t += delta
	flash = maxf(0.0, flash - delta)
	bar_fill = minf(1.0, bar_fill + delta / 1.2)
	queue_redraw()
	if dying:
		death_t += delta
		lift = maxf(0.0, lift - 700.0 * delta)  # quem morre no ar cai ao chão
		if death_t > _death_len():
			queue_free()
		return
	if rise_t > 0.0:  # o Arauto ergue-se do chão: parado e invulnerável
		rise_t -= delta
		if rise_t <= 0.0:
			main.boss_roar(self)
		return
	var start := position
	_move(delta)
	position = main.walk(start, position)


func _move(delta: float) -> void:
	attack_cd = maxf(0.0, attack_cd - delta)
	attack_t = maxf(0.0, attack_t - delta)
	num_t += delta
	chunk_wait -= delta
	if chunk_wait <= 0.0:
		hp_chunk = move_toward(hp_chunk, hp, max_hp * 1.2 * delta)
	position += knock * delta
	knock *= exp(-12.0 * delta)
	if lift > 0.0 or lift_v > 0.0:
		lift += lift_v * delta
		lift_v -= 1500.0 * delta
		if lift <= 0.0:
			lift = 0.0
			lift_v = 0.0
			main.spawn_fx("dust", position, 30.0, Color.WHITE)
	if bleed_t > 0.0:
		bleed_t -= delta
		take_damage(bleed_dps * delta, false)
		if dying:
			return
		bleed_num_t -= delta
		if bleed_num_t <= 0.0 and bleed_acc >= 1.0:
			bleed_num_t = 0.5
			_number(str(int(bleed_acc)), 13.0, Color(0.85, 0.12, 0.18))
			bleed_acc = 0.0
	target = main.nearest_player(position)
	if target == null:
		return
	if not awake:
		if position.distance_to(target.position) > aggro:
			return
		awake = true
	if kind == "herald":
		_herald(delta)
	else:
		var to: Vector2 = target.position - position
		var d := to.length()
		if d > radius + 14.0:
			position += to / d * speed * delta
		elif attack_cd <= 0.0 and lift <= 0.0:
			target.take_damage(dmg)
			attack_cd = 1.0
			attack_t = ATTACK_T
	for o in main.enemies():
		if o == self:
			continue
		var away: Vector2 = position - o.position
		var min_d: float = radius + o.radius
		if away.length_squared() < min_d * min_d and away != Vector2.ZERO:
			position += away.normalized() * (min_d - away.length()) * 0.5


## Arauto: anda devagar (cada passo treme o chão), bate o sino no chão perto dos jogadores
## e de tempos a tempos abre o caixão e invoca esqueletos.
func _herald(delta: float) -> void:
	slam_cd -= delta
	summon_cd -= delta
	if act != "":
		act_t += delta
		if act_t >= ACT_T * 0.5 and not act_done:
			act_done = true
			if act == "slam":
				main.boss_slam(position + Vector2(0, 10), 170.0, dmg)
			else:
				main.summon_minions(self, 4)
		if act_t >= ACT_T:
			act = ""
		return
	var to: Vector2 = target.position - position
	if summon_cd <= 0.0:
		_start("summon")
		summon_cd = 11.0
	elif to.length() < 150.0 and slam_cd <= 0.0:
		_start("slam")
		slam_cd = 2.6
	elif to.length() > radius + 20.0:
		position += to.normalized() * speed * delta
		var step := int(t * 4.0) % 2
		if step != last_step:
			last_step = step
			main.shake = maxf(main.shake, 2.5)
			main.spawn_fx("dust", position + Vector2(18 * (step * 2 - 1), 0), 40.0, Color.WHITE)


func _start(a: String) -> void:
	act = a
	act_t = 0.0
	act_done = false


func apply_bleed(dps: float, dur: float) -> void:
	bleed_dps = maxf(bleed_dps if bleed_t > 0.0 else 0.0, dps)
	bleed_t = dur


## flashes=false é o sangramento: sem flash nem recuo, e os números saem agrupados.
func take_damage(amount: float, flashes := true, dir := Vector2.ZERO, crit := false) -> void:
	if dying or rise_t > 0.0:
		return
	hp -= amount
	if flashes:
		flash = 0.12
		chunk_wait = 0.4
		knock =dir * (60.0 if is_boss else 320.0) * (1.5 if crit else 1.0)
		# Número: maior quanto maior o dano; crítico laranja, com "CRÍTICO!" e brilho, e atira ao ar
		var size := 15.0 + clampf(amount / 3.0, 0.0, 20.0)
		var mid := position + Vector2(0, _top() * 0.5 - lift)
		if crit:
			_number("%d!" % roundi(amount), size * 1.45, Color(1.0, 0.6, 0.15), "Crítico!")
			main.spawn_fx("glow", mid, 70.0, Color(1.0, 0.75, 0.35))
			if not is_boss:
				lift_v = 330.0
		else:
			_number(str(roundi(amount)), size, Color(0.95, 0.92, 0.82))
		main.spawn_fx("sparks", mid, 0.0, Color(1.0, 0.75, 0.3) if crit else Color(0.55, 1.0, 0.7), dir)
		main.spawn_fx("hit", mid, 70.0 if crit else 52.0, Color(1.0, 0.75, 0.3) if crit else Color.WHITE)
	else:
		bleed_acc += amount
	if hp <= 0.0:
		# Morre a animar (frames 12-15) e só depois desaparece, em _process
		dying = true
		remove_from_group("enemies")
		killed.emit(self)
		if kind != "herald":
			main.spawn_fx("ring", position, radius * 1.8, Color(0.4, 1.0, 0.65))
			main.spawn_fx("dust", position, 40.0, Color.WHITE)


func _death_len() -> float:
	return 2.6 if kind == "herald" else 1.3


func _top() -> float:
	return -TEX[kind].get_height() * SCALES[kind]


## Golpes rápidos não se sobrepõem: cada número novo sobe um degrau.
func _number(text: String, size: float, color: Color, sub := "") -> void:
	num_i = num_i + 1 if num_t < 0.3 else 0
	num_t = 0.0
	var f = main.number(position + Vector2(randf_range(-12, 12), _top() - lift - 14.0 - (num_i % 4) * 18.0), text, size, color)
	f.sub = sub


func _frame() -> int:
	if dying:
		return 12 + mini(3, int(death_t / (0.35 if kind == "herald" else 0.12)))
	if kind == "herald":
		if rise_t > 0.0:
			return 8
		if act != "":
			return (4 if act == "slam" else 8) + mini(3, int(act_t / ACT_T * 4.0))
		return int(t * 4.0) % 4
	if attack_t > 0.0:
		return 4 + mini(3, int((1.0 - attack_t / ATTACK_T) * 4.0))
	if not awake and aggro < INF:
		return 0  # ainda a dormir: parado
	return int(t * (6.0 if kind == "specter" else 7.0)) % 4


func _draw() -> void:
	draw_set_transform(Vector2.ZERO, 0.0, Vector2(1.0, 0.4))
	draw_circle(Vector2.ZERO, radius * 1.2, Color(0, 0, 0, 0.4 if kind != "specter" else 0.2))
	var f := _frame()
	var tex: Texture2D = FRAMES[kind][f]
	var sc: float = SCALES[kind]
	# Flash branco: multiplicar por 200 satura o sprite (e o resto rosa do recorte) para branco
	var tint := Color(200, 200, 200) if flash > 0.07 else (Color(1.8, 1.8, 1.8) if flash > 0.0 else Color.WHITE)
	var off := -lift
	if kind == "specter":
		tint.a = 0.85
		off += -8.0 + sin(t * 3.0) * 5.0
	if rise_t > 0.0:  # sobe do chão a desvanecer para dentro
		var k := clampf(1.0 - rise_t / 1.4, 0.0, 1.0)
		off += (1.0 - k) * 120.0
		tint.a = k
	if dying:
		tint.a *= clampf((_death_len() - death_t) / 0.5, 0.0, 1.0)
	# O esqueleto e o espectro olham para a direita nas folhas; o Arauto olha para a esquerda.
	var flip := 1.0
	if target != null and kind != "colossus":
		var right: bool = target.position.x > position.x
		flip = 1.0 if right == (kind != "herald") else -1.0
	draw_set_transform(Vector2(0, off), 0.0, Vector2(sc * flip, sc))
	draw_texture(tex, Vector2(-tex.get_width() / 2.0, -tex.get_height() + Feet.FEET[kind][f]), tint)
	draw_set_transform(Vector2.ZERO)
	if dying or rise_t > 0.0:
		return
	var top := _top() - lift
	if bleed_t > 0.0:
		draw_circle(Vector2(8, top * 0.55 + fmod(t * 30.0, 12.0)), 3.0, Color(0.75, 0.0, 0.05))
	if hp < max_hp and not is_boss:
		var wbar := maxf(radius * 2.0, 34.0)
		draw_rect(Rect2(-wbar / 2, top - 10, wbar, 5), Color(0, 0, 0, 0.7))
		draw_rect(Rect2(-wbar / 2, top - 10, wbar * hp_chunk / max_hp, 5), Color(1.0, 0.85, 0.55))
		draw_rect(Rect2(-wbar / 2, top - 10, wbar * maxf(hp, 0.0) / max_hp, 5), Color(0.8, 0.1, 0.15))
