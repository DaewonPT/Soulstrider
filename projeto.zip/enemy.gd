extends Node2D
## Esqueletos, espectros, colossos esqueléticos e o Arauto Fúnebre (chefe final do Cortejo).

signal killed(enemy)

const TEX := {
	"skeleton": preload("res://art/skeleton.png"),
	"specter": preload("res://art/specter.png"),
	"colossus": preload("res://art/colossus.png"),
	"herald": preload("res://art/anim/herald_0.png"),
}
const STATS := {  # [vida, velocidade, dano, raio] antes dos modificadores (o Bestiário mostra-os)
	"skeleton": [30.0, 85.0, 7.0, 13.0],
	"specter": [18.0, 135.0, 5.0, 12.0],
	"colossus": [650.0, 55.0, 24.0, 50.0],
	"herald": [1500.0, 42.0, 30.0, 55.0],
}
## Monstros em 32-bit (tools/cut_pixel.py), 8 desenhos por movimento, todos virados para a direita:
## 0-7 andar, 8-15 ataque, 16-19 parado, 20-23 ferido, 24-31 a morrer. O Arauto: 0-7 andar, 8-15 o sino no
## chão, 16-23 a invocar (e a erguer-se), 24-31 a morrer.
static var FRAMES32 := {
	"skeleton": range(32).map(func(i): return load("res://art/anim/skeleton32_%d.png" % i)),
	"specter": range(32).map(func(i): return load("res://art/anim/specter32_%d.png" % i)),
	"colossus": range(32).map(func(i): return load("res://art/anim/colossus32_%d.png" % i)),
	"herald": range(32).map(func(i): return load("res://art/anim/herald32_%d.png" % i)),
}
const Feet32 := preload("res://art/anim/feet32.gd")
const SCALES := {"skeleton": 0.3, "specter": 0.32, "colossus": 0.7, "herald": 0.47}
const NAMES := {"skeleton": "Esqueleto", "specter": "Espectro", "colossus": "Colosso Esquelético", "herald": "Arauto Fúnebre"}
const ATTACK_T := 0.4
const EXPOSE_T := 2.0  # depois de uma esquiva perfeita: leva o triplo do dano (#145, #163)
const ACT_T := 0.9  # duração do sino no chão / da invocação do Arauto
const EXECUTE_AT := 0.12  # Execução Espectral (#12): abaixo desta fração de vida a alma fica exposta
const POSTURE_HITS := 0.22  # Stagger de Titãs (#16): dano (fração da vida) que parte a postura de um chefe
const STAGGER_T := 3.0
const WINDUP := 0.55  # o Colosso prepara o murro no chão (com aviso no chão) antes de bater
const CALC_MAX := 10  # Calcificação Óssea (#150): camadas até virar estátua
const NECRO_MAX := 10  # Necrose Galopante (#154): camadas, cada uma +5% de dano recebido
const Feet := preload("res://art/anim/feet.gd")
const Gothic := preload("res://gothic.gd")
## Duas folhas 4x2 por inimigo: 0-3 andar, 4-7 atacar, 8-9 parado, 10-11 ferido, 12-15 morrer; o Arauto
## usa 8-11 para invocar. Só usamos as mortes da 2.ª folha: nela o Gemini desenhou o esqueleto com armadura,
## o colosso sem ela e o espectro sem capuz, e trocar a cada golpe parecia outro monstro.
static var FRAMES := {
	"skeleton": range(16).map(func(i): return load("res://art/anim/skeleton_%d.png" % i)),
	"specter": range(16).map(func(i): return load("res://art/anim/specter_%d.png" % i)),
	"colossus": range(16).map(func(i): return load("res://art/anim/colossus_%d.png" % i)),
	"herald": range(16).map(func(i): return load("res://art/anim/herald_%d.png" % i)),
}

var main
var kind := "skeleton"
var cortejo := false
var is_boss := false
var title := ""  # nome próprio na barra do chefe (ex.: "Carcereiro da Cripta")
var raise_owner = null  # herói da Alma Tumular que lhe deu o último golpe: ao morrer ergue-se para ele
var aggro := INF  # na cripta os mortos só acordam quando um herói chega perto
var awake := false
var max_hp := 30.0
var hp := 30.0
var speed := 85.0
var dmg := 7.0
var mods := {}
var radius := 13.0
var bleed_dps := 0.0
var bleed_t := 0.0
var flash := 0.0
var attack_cd := 0.0
var attack_t := 0.0
var target
var knock := Vector2.ZERO
var lift := 0.0  # crítico atira o inimigo ao ar
var lift_v := 0.0
var squash_t := 9.0  # desde o último golpe: achata e volta como uma mola
var tilt := 0.0  # inclina-se para onde anda (e para trás quando leva com um golpe)
var pose := Transform2D()  # o desenho deste frame, para main o redesenhar como silhueta atrás de um adereço alto (#92)
var pose_tex: Texture2D
var stride := 0.0  # 0 parado .. 1 a andar: a força do salto de cada passo
var hp_chunk := 30.0  # pedaço claro na barra que fica para trás e só depois escoa
var chunk_wait := 0.0
var bleed_acc := 0.0
var bleed_num_t := 0.0
var num_t := 9.0
var num_i := 0
var t := 0.0
var dying := false
var death_t := 0.0
var exposed_t := 0.0  # alma exposta (esquiva perfeita): leva o triplo do dano
var slow_t := 0.0  # Dentes de Sepultura: anda a 60%
var bar_fill := 0.0  # a barra do chefe enche do zero quando ele aparece
var posture := 0.0  # 0..1: cheia, o chefe fica quebrado (stagger_t)
var posture_wait := 0.0
var stagger_t := 0.0  # quebrado: não se mexe, leva +50% e deixa extrair a alma (uma vez)
var extracted := false
var windup_t := 0.0
var rot_t := 0.0  # Podridão Gangrenosa (#148): dano contínuo que pega a quem estiver encostado
var rot_dps := 0.0
var rot_acc := 0.0
var rot_spread := 0.0
var calc := 0  # camadas de Calcificação Óssea
var calc_wait := 0.0
var necro := 0  # camadas de Necrose Galopante
var necro_wait := 0.0
var statue_t := 0.0  # estátua: parado, cinzento
var blind_t := 0.0  # Cólera Póstuma (#17): cego pelo miasma, não ataca
var dummy := false  # boneco de treino (#287): vida infinita e dano por segundo
var dps_log := []  # [tempo, dano] dos últimos segundos
# Arauto
var rise_t := 0.0
var act := ""  # "slam" ou "summon"
var act_t := 0.0
var act_done := false
var slam_cd := 1.5
var summon_cd := 6.0
var last_step := 0


func setup(k: String, m: Dictionary) -> void:
	kind = k
	mods = m
	var st: Array = STATS[k]
	max_hp = st[0]
	speed = st[1]
	dmg = st[2]
	radius = st[3]
	is_boss = k in ["colossus", "herald"]
	max_hp *= m.get("hp", 1.0)
	speed *= m.get("speed", 1.0)
	dmg *= m.get("dmg", 1.0)
	hp = max_hp
	hp_chunk = max_hp
	t = randf() * 10.0


func _ready() -> void:
	add_to_group("enemies")


## O nome dele (o do chefe, se tiver; senão o do bicho): o ecrã de morte diz quem te matou.
func who() -> String:
	return title if title != "" else NAMES[kind]


func _process(delta: float) -> void:
	if statue_t <= 0.0:
		t += delta
	exposed_t = maxf(0.0, exposed_t - delta)
	slow_t = maxf(0.0, slow_t - delta)
	squash_t += delta
	flash = maxf(0.0, flash - delta)
	bar_fill = minf(1.0, bar_fill + delta / 1.2)
	queue_redraw()
	if dying:
		death_t += delta
		lift = maxf(0.0, lift - 700.0 * delta)  # quem morre no ar cai ao chão
		if death_t > _death_len():
			queue_free()
		return
	if rise_t > 0.0:  # o Arauto ergue-se do chão: parado e invulnerável
		rise_t -= delta
		if rise_t <= 0.0:
			main.boss_roar(self)
		return
	var start := position
	_move(delta)
	position = main.walk(start, position)
	var v := (position - start) / maxf(delta, 0.0001) / speed
	var k := 1.0 - exp(-8.0 * delta)
	tilt = lerpf(tilt, clampf(v.x, -1.0, 1.0) * 0.07, k)
	stride = lerpf(stride, minf(v.length(), 1.0), k)


func _move(delta: float) -> void:
	attack_cd = maxf(0.0, attack_cd - delta)
	attack_t = maxf(0.0, attack_t - delta)
	num_t += delta
	chunk_wait -= delta
	if chunk_wait <= 0.0:
		hp_chunk = move_toward(hp_chunk, hp, max_hp * 1.2 * delta)
	if dummy:
		knock = Vector2.ZERO
		dps_log = dps_log.filter(func(d): return t - d[0] < 6.0)
	position += knock * delta
	knock *= exp(-12.0 * delta)
	if lift > 0.0 or lift_v > 0.0:
		lift += lift_v * delta
		lift_v -= 1500.0 * delta
		if lift <= 0.0:
			lift = 0.0
			lift_v = 0.0
			main.spawn_fx("dust", position, 30.0, Color.WHITE)
	if bleed_t > 0.0:
		bleed_t -= delta
		take_damage(bleed_dps * delta, false)
		if dying:
			return
		bleed_num_t -= delta
		if bleed_num_t <= 0.0 and bleed_acc >= 1.0:
			bleed_num_t = 0.5
			_number(str(int(bleed_acc)), 13.0, Color(0.85, 0.12, 0.18))
			bleed_acc = 0.0
			main.blood.append([position, main.time + 4.0])  # Sangue no Solo (#23): cada número do sangramento deixa uma poça
			if main.blood.size() > 12:  # poucas poças: baratas de desenhar e de mandar ao convidado
				main.blood.pop_front()
	if rot_t > 0.0:
		rot_t -= delta
		rot_acc += rot_dps * delta
		take_damage(rot_dps * delta, false)
		if dying:
			return
		rot_spread -= delta
		if rot_spread <= 0.0:  # pega a quem estiver encostado, e o número sai de meio em meio segundo
			rot_spread = 0.5
			if rot_acc >= 1.0:
				_number(str(int(rot_acc)), 13.0, Color(0.45, 0.85, 0.25))
				rot_acc = 0.0
			for o in main.enemies():
				if o != self and o.rot_t <= 0.0 and o.position.distance_to(position) < radius + o.radius + 40.0:
					o.apply_rot(rot_dps * 0.8)
	posture_wait -= delta
	if posture_wait <= 0.0:
		posture = maxf(0.0, posture - 0.12 * delta)
	calc_wait -= delta
	if calc_wait <= 0.0:
		calc = 0
	necro_wait = maxf(0.0, necro_wait - delta)  # parado no 0: não viaja para o convidado a cada frame
	if necro_wait <= 0.0:
		necro = 0
	blind_t = maxf(0.0, blind_t - delta)
	if stagger_t > 0.0 or statue_t > 0.0 or dummy:  # quebrado, estátua ou boneco: não se mexe nem ataca
		stagger_t = maxf(0.0, stagger_t - delta)
		statue_t = maxf(0.0, statue_t - delta)
		return
	if windup_t > 0.0:  # o Colosso com os punhos no ar: o aviso no chão enche e o murro cai
		windup_t -= delta
		if windup_t <= 0.0:
			attack_t = ATTACK_T
			main.boss_slam(position, slam_r(), dmg, who(), self, "hit")
		return
	target = main.lure(position)
	if target == null:
		return
	if not awake:
		if position.distance_to(target.position) > aggro:
			return
		awake = true
	if kind == "herald":
		_herald(delta)
	else:
		var to: Vector2 = target.position - position
		var d := to.length()
		if d > radius + 14.0:
			position += to / d * speed * (0.6 if slow_t > 0.0 else 1.0) * (0.4 if blind_t > 0.0 else 1.0) * delta
		elif attack_cd <= 0.0 and lift <= 0.0 and blind_t <= 0.0:
			if kind == "colossus":  # ataque telegrafado: dá tempo de sair da área ou esquivar
				windup_t = WINDUP
				attack_cd = 1.8
			else:
				target.take_damage(dmg, who(), self)
				attack_cd = 1.0
				attack_t = ATTACK_T
	for o in main.enemies():
		if o == self:
			continue
		var away: Vector2 = position - o.position
		var min_d: float = radius + o.radius
		if away.length_squared() < min_d * min_d and away != Vector2.ZERO:
			position += away.normalized() * (min_d - away.length()) * 0.5


## Arauto: anda devagar (cada passo treme o chão), bate o sino no chão perto dos jogadores
## e de tempos a tempos abre o caixão e invoca esqueletos.
func _herald(delta: float) -> void:
	slam_cd -= delta
	summon_cd -= delta
	if act != "":
		act_t += delta
		if act_t >= ACT_T * 0.5 and not act_done:
			act_done = true
			if act == "slam":
				main.boss_slam(position + Vector2(0, 10), 170.0, dmg, who(), self)
			else:
				main.summon_minions(self, 4)
		if act_t >= ACT_T:
			act = ""
		return
	var to: Vector2 = target.position - position
	if summon_cd <= 0.0:
		_start("summon")
		summon_cd = 11.0
	elif to.length() < 150.0 and slam_cd <= 0.0:
		_start("slam")
		slam_cd = 2.6
	elif to.length() > radius + 20.0:
		position += to.normalized() * speed * delta
		var step := int(t * 4.0) % 2
		if step != last_step:
			last_step = step
			main.shake = maxf(main.shake, 2.5)
			main.spawn_fx("dust", position + Vector2(18 * (step * 2 - 1), 0), 40.0, Color.WHITE)


## Área do murro do Colosso (o aviso no chão mostra-a).
func slam_r() -> float:
	return radius + 60.0


## Execução Espectral (#12): à beira da morte, a alma fica exposta (não nos chefes com nome nem no Arauto).
func executable() -> bool:
	return not dummy and not dying and title == "" and kind != "herald" and hp <= max_hp * EXECUTE_AT


## Stagger de Titãs (#16): quebrado, deixa extrair a Alma Ancestral (uma vez por quebra).
func extractable() -> bool:
	return stagger_t > 0.0 and not extracted and not dying


func apply_rot(dps: float) -> void:
	rot_dps = maxf(rot_dps if rot_t > 0.0 else 0.0, dps)
	rot_t = 4.0


## Uma camada de Calcificação Óssea; à 10.ª vira estátua (os chefes só metade do tempo).
func add_calc() -> void:
	if statue_t > 0.0 or dying:
		return
	calc += 1
	calc_wait = 4.0
	if calc >= CALC_MAX:
		calc = 0
		statue_t = 1.5 if is_boss else 3.0
		windup_t = 0.0
		act = ""
		_number(tr("Petrificado!"), 20.0, Color(0.85, 0.85, 0.8))
		main.spawn_fx("dust", position, 60.0, Color(0.8, 0.8, 0.75))


## Uma camada de Necrose Galopante (até 10); somem todas 4 s depois do último golpe.
func add_necro() -> void:
	necro = mini(necro + 1, NECRO_MAX)
	necro_wait = 4.0


func _start(a: String) -> void:
	act = a
	act_t = 0.0
	act_done = false


func apply_bleed(dps: float, dur: float) -> void:
	bleed_dps = maxf(bleed_dps if bleed_t > 0.0 else 0.0, dps)
	bleed_t = dur


## flashes=false é o sangramento: sem flash nem recuo, e os números saem agrupados.
func take_damage(amount: float, flashes := true, dir := Vector2.ZERO, crit := false) -> void:
	if dying or rise_t > 0.0:
		return
	if dummy:
		dps_log.append([t, amount])
	elif is_boss and flashes and stagger_t <= 0.0:
		posture_wait = 2.0
		posture += amount / (max_hp * POSTURE_HITS) * (1.5 if crit else 1.0)
		if posture >= 1.0:
			_stagger()
	hp = max_hp if dummy else hp - amount  # o boneco nunca cai
	if flashes:
		flash = 0.12
		squash_t = 0.0
		chunk_wait = 0.4
		knock =dir * (60.0 if is_boss else 320.0) * (1.5 if crit else 1.0)
		# Número: maior quanto maior o dano; crítico laranja, com "CRÍTICO!" e brilho, e atira ao ar
		var size := 15.0 + clampf(amount / 3.0, 0.0, 20.0)
		var mid := position + Vector2(0, _top() * 0.5 - lift)
		if crit:
			_number("%d!" % roundi(amount), size * 1.45, Color(1.0, 0.6, 0.15), "Crítico!")
			main.spawn_fx("glow", mid, 70.0, Color(1.0, 0.75, 0.35))
			if not is_boss:
				lift_v = 330.0
		else:
			_number(str(roundi(amount)), size, Color(0.95, 0.92, 0.82))
		main.spawn_fx("sparks", mid, 0.0, Color(1.0, 0.75, 0.3) if crit else Color(0.55, 1.0, 0.7), dir)
		main.spawn_fx("hit", mid, 70.0 if crit else 52.0, Color(1.0, 0.75, 0.3) if crit else Color.WHITE)
	else:
		bleed_acc += amount
	if hp <= 0.0:
		# Morre a animar (frames 12-15) e só depois desaparece, em _process
		dying = true
		remove_from_group("enemies")
		killed.emit(self)
		if kind != "herald":
			main.spawn_fx("ring", position, radius * 1.8, Color(0.4, 1.0, 0.65))
			main.spawn_fx("dust", position, 40.0, Color.WHITE)


func _stagger() -> void:
	posture = 0.0
	stagger_t = STAGGER_T
	extracted = false
	windup_t = 0.0
	act = ""
	_number(tr("Quebrado!"), 24.0, Color(1.0, 0.9, 0.5))
	main.spawn_fx("ring", position, radius * 2.4, Color(1.0, 0.9, 0.5))
	main.shake = maxf(main.shake, 10.0)
	main.sfx("crit")


## Boneco de treino: dano por segundo nos últimos segundos (0 quando ninguém lhe bate).
func dps() -> float:
	if dps_log.is_empty() or t - dps_log[-1][0] > 3.0:
		return 0.0
	var total := 0.0
	for d in dps_log:
		total += d[1]
	return total / maxf(1.0, t - dps_log[0][0])


func _death_len() -> float:
	return 2.6 if kind == "herald" else 1.3


func _top() -> float:
	return -TEX[kind].get_height() * SCALES[kind]


## Golpes rápidos não se sobrepõem: cada número novo sobe um degrau.
func _number(text: String, size: float, color: Color, sub := "") -> void:
	num_i = num_i + 1 if num_t < 0.3 else 0
	num_t = 0.0
	var f = main.number(position + Vector2(randf_range(-12, 12), _top() - lift - 14.0 - (num_i % 4) * 18.0), text, size, color)
	f.sub = sub


func _frame() -> int:
	if dying:
		return 12 + mini(3, int(death_t / (0.35 if kind == "herald" else 0.12)))
	if kind == "herald":
		if rise_t > 0.0:
			return 8
		if act != "":
			return (4 if act == "slam" else 8) + mini(3, int(act_t / ACT_T * 4.0))
		return int(t * 4.0) % 4
	if windup_t > 0.0:
		return 4
	if attack_t > 0.0:
		return 4 + mini(3, int((1.0 - attack_t / ATTACK_T) * 4.0))
	if dummy or (not awake and aggro < INF):
		return 0  # ainda a dormir: parado
	return int(t * (6.0 if kind == "specter" else 7.0)) % 4


## O desenho 32-bit deste momento (8 por movimento); -1 = usar os pintados.
func _frame32() -> int:
	if not main.settings.pixel32 or not FRAMES32.has(kind):
		return -1
	if dying:
		return 24 + mini(7, int(death_t / (0.18 if kind == "herald" else 0.09)))
	if kind == "herald":
		if rise_t > 0.0:
			return 16
		if act != "":
			return (8 if act == "slam" else 16) + mini(7, int(act_t / ACT_T * 8.0))
		return int(t * 8.0) % 8
	if windup_t > 0.0:
		return 8 + mini(2, int((1.0 - windup_t / WINDUP) * 3.0))
	if attack_t > 0.0:
		if kind == "colossus":
			return 11 + mini(4, int((1.0 - attack_t / ATTACK_T) * 5.0))
		return 8 + mini(7, int((1.0 - attack_t / ATTACK_T) * 8.0))
	if dummy:
		return 16
	if squash_t < 0.24:  # acabou de levar um golpe: recua e os ossos chocalham
		return 20 + mini(3, int(squash_t / 0.06))
	if stride < 0.3:
		return 16 + int(t * 5.0) % 4
	return int(t * 13.0) % 8


func _draw() -> void:
	# Ataques telegrafados: o círculo do golpe enche até ao impacto (a área é a mesma do dano)
	var warn := -1.0
	var warn_r := 0.0
	var warn_at := Vector2.ZERO
	if windup_t > 0.0:
		warn = 1.0 - windup_t / WINDUP
		warn_r = slam_r()
	elif kind == "herald" and act == "slam" and not act_done:
		warn = act_t / (ACT_T * 0.5)
		warn_r = 170.0
		warn_at = Vector2(0, 10)
	if warn >= 0.0:
		draw_circle(warn_at, warn_r * clampf(warn, 0.0, 1.0), Color(0.9, 0.1, 0.08, 0.28))
		draw_arc(warn_at, warn_r, 0, TAU, 48, Color(1.0, 0.25, 0.15, 0.75), 3.0)
	if dummy:  # o poste de madeira do boneco
		draw_rect(Rect2(-4, -70, 8, 74), Color(0.36, 0.24, 0.14))
		draw_rect(Rect2(-26, -58, 52, 7), Color(0.36, 0.24, 0.14))
	if exposed_t > 0.0:
		draw_circle(Vector2(0, -radius * 1.6), radius * 1.4, Color(0.5, 1.0, 0.9, 0.18 + 0.1 * sin(t * 18.0)))
	draw_set_transform(Vector2.ZERO, 0.0, Vector2(1.0, 0.4))
	draw_circle(Vector2.ZERO, radius * 1.2, Color(0, 0, 0, 0.4 if kind != "specter" else 0.2))
	var f := _frame()
	var tex: Texture2D = FRAMES[kind][f]
	var sc: float = SCALES[kind]
	var feet: float = Feet.FEET[kind][f]
	var f32 := _frame32()
	if f32 >= 0:  # o dobro da resolução do ecrã base: nítido no telemóvel
		tex = FRAMES32[kind][f32]
		sc = Feet32.SCALE[kind + "32"]
		feet = Feet32.FEET[kind + "32"][f32]
	# Flash branco: multiplicar por 200 satura o sprite (e o resto rosa do recorte) para branco
	var tint := Color(200, 200, 200) if flash > 0.07 else (Color(1.8, 1.8, 1.8) if flash > 0.0 else Color.WHITE)
	if statue_t > 0.0:
		tint = Color(0.62, 0.62, 0.6)
	elif calc > 0:  # a calcificar: cada vez mais cinzento
		tint = tint.lerp(Color(0.7, 0.7, 0.68), calc / float(CALC_MAX) * 0.7)
	if necro > 0:  # a necrosar: cada vez mais roxo
		tint = tint.lerp(Color(0.62, 0.36, 0.85), necro / float(NECRO_MAX) * 0.6)
	if rot_t > 0.0:
		tint *= Color(0.75, 1.0, 0.6)
	if dummy:
		tint *= Color(0.9, 0.78, 0.6)
	var off := -lift
	if kind == "specter":
		tint.a = 0.85
		off += -8.0 + sin(t * 3.0) * 5.0
	if rise_t > 0.0:  # sobe do chão a desvanecer para dentro
		var k := clampf(1.0 - rise_t / 1.4, 0.0, 1.0)
		off += (1.0 - k) * 120.0
		tint.a = k
	if dying:
		tint.a *= clampf((_death_len() - death_t) / 0.5, 0.0, 1.0)
	# O esqueleto e o espectro olham para a direita nas folhas; o Arauto olha para a esquerda.
	# Os 32-bit olham todos para a direita; nos pintados o Arauto olha para a esquerda e o Colosso de frente
	var flip := 1.0
	if target != null and (f32 >= 0 or kind != "colossus"):
		var right: bool = target.position.x > position.x
		flip = 1.0 if right == (f32 >= 0 or kind != "herald") else -1.0
	# Esmagar e esticar: cada golpe achata-o contra o chão e ele volta como uma mola
	var sq := exp(-squash_t * 9.0) * cos(squash_t * 26.0) * (0.08 if is_boss else 0.2)
	# Fluidez: um pequeno salto a cada passo, no ritmo dos frames de andar (o espectro já flutua)
	if kind != "specter":
		off -= absf(sin(t * PI * (2.0 if kind == "herald" else 3.5))) * 3.0 * stride * (1.6 if kind == "colossus" else 1.0)
	# A pose fica guardada para a silhueta atrás das paredes (#92); é o mesmo que draw_set_transform(posição, rotação, escala)
	pose_tex = tex
	# Transform2D(rotação, escala, inclinação, posição): escala local, como o draw_set_transform (o .scaled() escalaria no global e a inclinação ia ao contrário)
	pose = Transform2D(tilt, Vector2(sc * flip * (1.0 + sq), sc * (1.0 - sq)), 0.0, Vector2(0, off)).translated_local(Vector2(-tex.get_width() / 2.0, -tex.get_height() + feet))
	draw_set_transform_matrix(pose)
	draw_texture(tex, Vector2.ZERO, tint)
	draw_set_transform(Vector2.ZERO)
	if dying or rise_t > 0.0:
		return
	var top := _top() - lift
	if bleed_t > 0.0:
		draw_circle(Vector2(8, top * 0.55 + fmod(t * 30.0, 12.0)), 3.0, Color(0.75, 0.0, 0.05))
	if rot_t > 0.0:  # bolhas verdes a subir
		for i in 2:
			draw_circle(Vector2(-8 + i * 14, top * 0.4 - fmod(t * 24.0 + i * 9.0, 18.0)), 2.5, Color(0.45, 0.85, 0.25, 0.8))
	if blind_t > 0.0:
		draw_circle(Vector2(0, top * 0.75), radius * 1.1, Color(0.3, 0.2, 0.35, 0.35))
	if executable():  # ponto de rutura da alma: um losango a pulsar
		var c := Vector2(0, top * 0.5)
		var s := 7.0 + 2.0 * sin(t * 10.0)
		draw_colored_polygon(PackedVector2Array([c + Vector2(0, -s), c + Vector2(s * 0.7, 0), c + Vector2(0, s), c + Vector2(-s * 0.7, 0)]), Color(0.75, 1.0, 0.95, 0.9))
		draw_arc(c, s * 1.8, 0, TAU, 20, Color(0.5, 1.0, 0.8, 0.5), 2.0)
	if extractable():  # a Alma Ancestral exposta no peito do chefe quebrado
		draw_circle(Vector2(0, top * 0.5), 18.0 + 4.0 * sin(t * 8.0), Color(0.4, 1.0, 0.6, 0.35))
		draw_circle(Vector2(0, top * 0.5), 8.0, Color(0.85, 1.0, 0.9, 0.9))
	if dummy and dps() > 0.0:
		Gothic.draw_centered(self, 0.0, top - 18.0, tr("%d de dano por segundo") % roundi(dps()), 16, Color(1.0, 0.9, 0.6), 4)
	if hp < max_hp and not is_boss:
		var wbar := maxf(radius * 2.0, 34.0)
		draw_rect(Rect2(-wbar / 2, top - 10, wbar, 5), Color(0, 0, 0, 0.7))
		draw_rect(Rect2(-wbar / 2, top - 10, wbar * hp_chunk / max_hp, 5), Color(1.0, 0.85, 0.55))
		draw_rect(Rect2(-wbar / 2, top - 10, wbar * maxf(hp, 0.0) / max_hp, 5), Color(0.8, 0.1, 0.15))
