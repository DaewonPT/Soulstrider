extends Node2D
## Esqueletos, espectros, colossos esqueléticos e o Arauto Fúnebre (chefe final do Cortejo).

signal killed(enemy)

## Altura de cada monstro (px no mundo): onde nascem os números de dano e o meio dos golpes
const TOP := {"skeleton": 63.6, "specter": 61.8, "colossus": 185.5, "herald": 208.2}
## [vida, velocidade, dano, raio, armadura] antes dos modificadores (o Bestiário mostra-os). A armadura (#141) tira essa
## parte a cada golpe; os Colossos e o Arauto, com 40%, ficaram com 60% da vida (390 e 900 em vez de 650 e 1500): custam
## o mesmo a matar com golpes diretos, e a Alma Voraz fura-lhes a armadura.
const STATS := {
	"skeleton": [30.0, 85.0, 7.0, 13.0, 0.0],
	"specter": [18.0, 135.0, 5.0, 12.0, 0.0],
	"colossus": [390.0, 55.0, 24.0, 50.0, 0.4],
	"herald": [900.0, 42.0, 30.0, 55.0, 0.4],
}
## Monstros em 32-bit (tools/cut_pixel.py), 8 desenhos por movimento, todos virados para a direita:
## 0-7 andar, 8-15 ataque, 16-19 parado, 20-23 ferido, 24-31 a morrer. O Arauto: 0-7 andar, 8-15 o sino no
## chão, 16-23 a invocar (e a erguer-se), 24-31 a morrer.
static var FRAMES32 := {
	"skeleton": range(32).map(func(i): return load("res://art/anim/skeleton32_%d.png" % i)),
	"specter": range(32).map(func(i): return load("res://art/anim/specter32_%d.png" % i)),
	"colossus": range(32).map(func(i): return load("res://art/anim/colossus32_%d.png" % i)),
	"herald": range(32).map(func(i): return load("res://art/anim/herald32_%d.png" % i)),
}
const Feet32 := preload("res://art/anim/feet32.gd")
const Pix := preload("res://fx_pix.gd")
const NAMES := {"skeleton": "Esqueleto", "specter": "Espectro", "colossus": "Colosso Esquelético", "herald": "Arauto Fúnebre"}
const ATTACK_T := 0.4
const EXPOSE_T := 2.0  # depois de uma esquiva perfeita: leva o triplo do dano (#145, #163)
const ACT_T := 0.9  # duração do sino no chão / da invocação do Arauto
const EXECUTE_AT := 0.12  # Execução Espectral (#12): abaixo desta fração de vida a alma fica exposta
const POSTURE_HITS := 0.22  # Stagger de Titãs (#16): dano (fração da vida) que parte a postura de um chefe
const STAGGER_T := 3.0
const WINDUP := 0.55  # o Colosso prepara o murro no chão (com aviso no chão) antes de bater
const CALC_MAX := 10  # Calcificação Óssea (#150): camadas até virar estátua
const NECRO_MAX := 10  # Necrose Galopante (#154): camadas, cada uma +5% de dano recebido
const DOT_T := 1.0  # o número do dano contínuo (#261) fica à vista este tempo depois do último tique
const MARK_T := 1.2  # Marca da Cova (#277): o aviso no chão enche durante isto e rebenta
const MARK_R := 80.0
const Gothic := preload("res://gothic.gd")
const Bosses := preload("res://bosses.gd")
const STONE := Color(1.0, 1.1, 1.35)  # pedra (as gárgulas, #208, e as Estátuas Funerárias, #204): mais clara e cinzenta do que o osso

var main
var kind := "skeleton"
var cortejo := false
var is_boss := false
var title := ""  # nome próprio na barra do chefe (ex.: "Carcereiro da Cripta")
var raise_owner = null  # herói da Alma Tumular que lhe deu o último golpe: ao morrer ergue-se para ele
var raise_n := 1  # quantos se erguem dele (2 com a Alma Mitótica)
var hit_by = null  # herói do último golpe e o frasco com que bateu (main._damage): decide no abate (Alma Mártir)
var hit_support := ""
var hit_phys := false  # e se foi um golpe físico (Exumação Espontânea, #102)
var armor := 0.0  # parte do dano que a armadura tira (STATS); a Alma Voraz (#141) fura 40% dela
var pin_t := 0.0  # preso por uma estaca (#103) ou pelo punho do Carcereiro (#21): não se mexe nem ataca
var elite := false  # Elites (#277): mais fortes e dourados, marcam o chão à distância (viaja ao convidado)
var mark_at := Vector2.ZERO  # Marca da Cova: onde o chão vai rebentar
var mark_end := 0.0  # e quando (em main.time: o convidado desenha o aviso a encher); 0 = nenhuma
var mark_next := 0.0  # a marca seguinte só a partir daqui (em main.time)
var size := 1.0  # S5: o tamanho (grow) e a cor por cima do desenho (elites, gigantes); viajam ao convidado
var paint := Color.WHITE
var gargoyle := false  # Jardins de Pedras Funerárias (#208): de pedra, só anda e bate quando ninguém olha para ela (viaja ao convidado)
# S7: os chefes com nome (bosses.gd). Os campos com tipo viajam ao convidado, que os desenha
var boss := ""  # suturado, monge, carrasco, guardiao, tita ("" nos outros, o Carcereiro e o Arauto também)
var anchor := false  # preso ao chão (as Estátuas Funerárias do Guardião): não anda nem bate
var limbs := []  # Colosso Suturado (#31): o que resta de cada membro (braço esq., braço dir., perna esq., perna dir.)
var chain_from := Vector2.ZERO  # Carrasco Sem Rosto (#44): a corrente, de onde a onde, e quando cai (em main.time)
var chain_to := Vector2.ZERO
var chain_at := 0.0
var blade_from := Vector2.ZERO  # e a guilhotina: de onde parte, para onde varre e quando começa a varrer (em main.time)
var blade_dir := Vector2.ZERO
var blade_at := 0.0
var rain := []  # Titã Petrificado (#70) e a Pisada do Guardião (#204): [onde, raio] do que cai em rain_at (em main.time)
var rain_at := 0.0
var boss_t = 0.0  # a próxima jogada do chefe (corrente, Pisada, pedras) e quantas já fez; sem tipo: só o anfitrião
var boss_n = 0
var heard = 0.0  # Monge (#193): a hora do último barulho a que reagiu, e para onde vai
var goal = Vector2.ZERO
var cut = []  # Carrasco: quem a guilhotina já apanhou nesta passagem
# Afixos do Cortejo (S8), com tipo: viajam ao convidado
var expire_at := 0.0  # Almas Rebeldes (#196): o fantasma rebenta a esta hora (em main.time; 0 = não é um)
var ringer_at := 0.0  # Sineiros (#206): -1 à espera de um herói a 500 px, depois a hora em que chega o colosso (0 = não toca)
var reaper := false  # O Ceifador Ambulante (#216): fora do grupo dos inimigos (ninguém lhe bate) e ceifa quem toca
# Eventos do cemitério (S9), com tipo: viajam ao convidado
var ev := 0  # 1 nos mortos de um evento: a morte deles conta em main.event.alive
var feast_to := Vector2.INF  # Banquete dos Espectros (#47): a carcaça para onde o espectro vai comer (INF = nenhuma)
var wander = null  # Gigante Errante (#39): para onde anda à toa antes de acordar (sem tipo: só o anfitrião)
var wander_t = 0.0
var wild = false  # sem tipo: só o anfitrião, sem tráfego. Do mundo aberto (sai quando fica longe de todos), a tier da distância à praça e o acampamento (-1 nenhum)
var tier = 0
var camp = -1
var aggro := INF  # na cripta os mortos só acordam quando um herói chega perto
var awake := false
var max_hp := 30.0
var hp := 30.0
var speed := 85.0
var dmg := 7.0
var mods := {}
var radius := 13.0
var bleed_dps := 0.0
var bleed_t := 0.0
var drain_t := 0.0  # Sede Ancestral (#135): segundos que ainda lhe bebem a vida
var drain_by = null  # e o herói que a bebe (sem tipo: não vai ao convidado, só o anfitrião o usa)
var flash := 0.0
var attack_cd := 0.0
var attack_t := 0.0
var target
var knock := Vector2.ZERO
var lift := 0.0  # crítico atira o inimigo ao ar
var lift_v := 0.0
var squash_t := 9.0  # desde o último golpe: achata e volta como uma mola
var tilt := 0.0  # inclina-se para onde anda (e para trás quando leva com um golpe)
var pose := Transform2D()  # o desenho deste frame, para main o redesenhar como silhueta atrás de um adereço alto (#92)
var pose_tex: Texture2D
var stride := 0.0  # 0 parado .. 1 a andar: a força do salto de cada passo
var hp_chunk := 30.0  # pedaço claro na barra que fica para trás e só depois escoa
var chunk_wait := 0.0
var bleed_acc := 0.0  # dano contínuo (sangramento, dreno, podridão) desde o último tique do número
var bleed_num_t := 0.0
var num_t := 9.0
var num_i := 0
var t := 0.0
var dying := false
var death_t := 0.0
var exposed_t := 0.0  # alma exposta (esquiva perfeita): leva o triplo do dano
var slow_t := 0.0  # Dentes de Sepultura: anda a 60%
var bar_fill := 0.0  # a barra do chefe enche do zero quando ele aparece
var posture := 0.0  # 0..1: cheia, o chefe fica quebrado (stagger_t)
var posture_wait := 0.0
var stagger_t := 0.0  # quebrado: não se mexe, leva +50% e deixa extrair a alma (uma vez)
var extracted := false
var windup_t := 0.0
var rot_t := 0.0  # Podridão Gangrenosa (#148): dano contínuo que pega a quem estiver encostado
var rot_dps := 0.0
var rot_spread := 0.0
var calc := 0  # camadas de Calcificação Óssea
var calc_wait := 0.0
var necro := 0  # camadas de Necrose Galopante
var necro_wait := 0.0
var statue_t := 0.0  # estátua: parado, cinzento
var blind_t := 0.0  # Cólera Póstuma (#17): cego pelo miasma, não ataca
var panic_t := 0.0  # Grito de Guerra Fúnebre (#20): em pânico ataca os outros mortos
var panic_target = null  # quem está a atacar em pânico (sem tipo: não vai ao convidado, só o anfitrião o usa)
var dummy := false  # boneco de treino (#287): vida infinita e dano por segundo
var dps_log := []  # [tempo, dano] dos últimos segundos
var dot_sum := 0.0  # Números agrupados (#261): o dano contínuo num só número ao lado do corpo, que cresce a cada tique
var dot_until := 0.0  # até quando se vê (em main.time: o convidado também o lê)
var dot_rot := false  # verde: já só resta a podridão
# Arauto
var rise_t := 0.0
var act := ""  # "slam" ou "summon"
var act_t := 0.0
var act_done := false
var slam_cd := 1.5
var summon_cd := 6.0
var haste := 1.0  # Arauto por Círculo: do IV em diante bate e invoca mais depressa
var reach := 1.0  # e o sino no chão chega mais longe
var rage_at := 0.0  # do II em diante: abaixo desta parte da vida entra na 2.ª fase (0 = nunca)
var raged := false
var last_step := 0


func setup(k: String, m: Dictionary) -> void:
	kind = k
	mods = m
	var st: Array = STATS[k]
	max_hp = st[0]
	speed = st[1]
	dmg = st[2]
	radius = st[3]
	armor = st[4]
	is_boss = k in ["colossus", "herald"]
	max_hp *= m.get("hp", 1.0)
	speed *= m.get("speed", 1.0)
	dmg *= m.get("dmg", 1.0)
	hp = max_hp
	hp_chunk = max_hp
	t = randf() * 10.0


func _ready() -> void:
	if not reaper:  # o Ceifador (#216) fica de fora (no convidado o campo já vem certo antes do _ready, net._spawn)
		add_to_group("enemies")


## O nome dele (o do chefe, se tiver; senão o do bicho): o ecrã de morte diz quem te matou.
func who() -> String:
	if title != "":
		return title
	return tr("%s de Elite") % tr(NAMES[kind]) if elite else NAMES[kind]


## S5: k vezes maior (o desenho, o corpo e a altura dos números).
func grow(k: float) -> void:
	size = k
	radius *= k


## Elites (#277): o quádruplo da vida, +50% de dano, +10% de velocidade e 1,3 vezes maior.
func make_elite() -> void:
	elite = true
	max_hp *= 4.0
	hp = max_hp
	hp_chunk = max_hp
	dmg *= 1.5
	speed *= 1.1
	grow(1.3)


func _process(delta: float) -> void:
	if statue_t <= 0.0:
		t += delta
	exposed_t = maxf(0.0, exposed_t - delta)
	slow_t = maxf(0.0, slow_t - delta)
	squash_t += delta
	flash = maxf(0.0, flash - delta)
	bar_fill = minf(1.0, bar_fill + delta / 1.2)
	queue_redraw()
	if dying:
		death_t += delta
		lift = maxf(0.0, lift - 700.0 * delta)  # quem morre no ar cai ao chão
		if death_t > _death_len():
			queue_free()
		return
	if rise_t > 0.0:  # o Arauto ergue-se do chão: parado e invulnerável
		rise_t -= delta
		if rise_t <= 0.0:
			main.boss_roar(self)
		return
	var start := position
	_move(delta)
	position += main.belt_push(position) * delta  # Moinho de Carne (#202): as passadeiras levam-nos para a serra
	position = main.walk(start, position)
	var v := (position - start) / maxf(delta, 0.0001) / speed
	var k := 1.0 - exp(-8.0 * delta)
	tilt = lerpf(tilt, clampf(v.x, -1.0, 1.0) * 0.07, k)
	stride = lerpf(stride, minf(v.length(), 1.0), k)


func _move(delta: float) -> void:
	if reaper:
		_reap(delta)
		return
	attack_cd = maxf(0.0, attack_cd - delta)
	attack_t = maxf(0.0, attack_t - delta)
	if mark_end > 0.0 and main.time >= mark_end:  # a Marca da Cova rebenta (também com ele preso ou quebrado)
		mark_end = 0.0
		main.boss_slam(mark_at, MARK_R, dmg * 2.0 * frenzy(), who(), self, "hit")
	# Almas Rebeldes (#196): rebenta ao fim de 4 s ou ao tocar num herói, mas o toque só conta 0,5 s depois de nascer (nasce
	# onde o morto caiu, muitas vezes já colado ao herói: assim vê-se e ainda dá para fugir ou matá-lo)
	if expire_at > 0.0 and (main.time >= expire_at or (main.time >= expire_at - 3.5 and main.players.any(func(p): return not p.dead and p.position.distance_to(position) < radius + 20.0))):
		main.boss_slam(position, 90.0, 18.0 * main.lvl_mods(main.circle_level()).dmg, who(), self, "hit")
		queue_free()
		return
	if ringer_at < 0.0 and main.players.any(func(p): return not p.dead and p.position.distance_to(position) < 500.0):
		ringer_at = main.time + 4.0  # Sineiros (#206): começa a tocar; quem não o calar em 4 s tem um colosso em cima
	elif ringer_at > 0.0 and main.time >= ringer_at:
		ringer_at = 0.0
		main.ring_bell(self)
	num_t += delta
	chunk_wait -= delta
	if chunk_wait <= 0.0:
		hp_chunk = move_toward(hp_chunk, hp, max_hp * 1.2 * delta)
	if dummy or anchor:  # o boneco e as Estátuas Funerárias (S7) não recuam
		knock = Vector2.ZERO
		dps_log = dps_log.filter(func(d): return t - d[0] < 6.0)
	position += knock * delta
	knock *= exp(-12.0 * delta)
	if lift > 0.0 or lift_v > 0.0:
		lift += lift_v * delta
		lift_v -= 1500.0 * delta
		if lift <= 0.0:
			lift = 0.0
			lift_v = 0.0
			main.spawn_fx("dust", position, 30.0, Color.WHITE)
	if bleed_t > 0.0:
		bleed_t -= delta
		take_damage(bleed_dps * delta, false)
		# Mártir do Aço Fúnebre (#107): 15% do sangramento volta como barreira de ossos a quem bateu por último (o tecto da #15)
		if not dummy and is_instance_valid(hit_by) and not hit_by.dead and hit_by.stat("aco") > 0.0 and not hit_by.wears("martir"):
			hit_by.barrier = minf(hit_by.barrier + bleed_dps * delta * 0.15, hit_by.max_hp * 0.25)
		if dying:
			return
	if drain_t > 0.0:  # Sede Ancestral (#135): 1,5% da vida máxima por segundo; quem a bebe cura, por alvo, até 3% da dele
		drain_t -= delta
		var gole := max_hp * 0.015 * delta
		take_damage(gole, false)  # sem flash: entra nos números vermelhos do sangramento
		if dying:
			return
		if is_instance_valid(drain_by):
			drain_by.heal(minf(gole, drain_by.max_hp * 0.03 * delta))
	if rot_t > 0.0:
		rot_t -= delta
		take_damage(rot_dps * delta, false)  # entra no bleed_acc, como o resto do dano contínuo (só uma vez)
		if dying:
			return
		rot_spread -= delta
		if rot_spread <= 0.0:  # pega a quem estiver encostado, de meio em meio segundo
			rot_spread = 0.5
			for o in main.enemies():
				if o != self and o.rot_t <= 0.0 and o.position.distance_to(position) < radius + o.radius + 40.0:
					o.apply_rot(rot_dps * 0.8)
	# O tique do número (#261): de meio em meio segundo o dano contínuo junta-se ao número que já lá está
	bleed_num_t = maxf(0.0, bleed_num_t - delta)  # parado no 0: não viaja ao convidado a cada frame
	if bleed_num_t <= 0.0 and bleed_acc >= 1.0:
		bleed_num_t = 0.5
		_dot(bleed_acc)
		bleed_acc = 0.0
		if bleed_t > 0.0:
			main.blood.append([position, main.time + 4.0])  # Sangue no Solo (#23): cada tique do sangramento deixa uma poça
			if main.blood.size() > 12:  # poucas poças: baratas de desenhar e de mandar ao convidado
				main.blood.pop_front()
	posture_wait -= delta
	if posture_wait <= 0.0:
		posture = maxf(0.0, posture - 0.12 * delta)
	calc_wait -= delta
	if calc_wait <= 0.0:
		calc = 0
	necro_wait = maxf(0.0, necro_wait - delta)  # parado no 0: não viaja para o convidado a cada frame
	if necro_wait <= 0.0:
		necro = 0
	blind_t = maxf(0.0, blind_t - delta)
	panic_t = maxf(0.0, panic_t - delta)
	if boss != "" and Bosses.tick(self, delta):  # S7: o que o chefe já avisou cai sempre; o Monge mexe-se sozinho
		return
	if stagger_t > 0.0 or statue_t > 0.0 or pin_t > 0.0 or dummy or anchor:  # quebrado, estátua, preso, boneco ou preso ao chão: não se mexe nem ataca
		stagger_t = maxf(0.0, stagger_t - delta)
		statue_t = maxf(0.0, statue_t - delta)
		pin_t = maxf(0.0, pin_t - delta)
		return
	if feast_to != Vector2.INF:  # Banquete dos Espectros (#47): vai direito à carcaça, sem atacar ninguém
		var way := feast_to - position
		if way.length() < 60.0:
			main.feast(self)
		else:
			position += way.normalized() * speed * (0.6 if slow_t > 0.0 else 1.0) * delta
		return
	if windup_t > 0.0:  # o Colosso com os punhos no ar: o aviso no chão enche e o murro cai
		windup_t -= delta
		if windup_t <= 0.0:
			attack_t = ATTACK_T
			main.boss_slam(position, slam_r(), dmg, who(), self, "hit")
		return
	target = main.lure(position, not is_boss)  # os Guardiões de Tórax (#11) atraem os mortos menores
	if target == null:
		return
	if not awake:
		if position.distance_to(target.position) > aggro:
			if wander != null:  # Gigante Errante (#39): anda à toa, devagar, e muda de rumo a cada 4 s
				wander_t -= delta
				if wander_t <= 0.0:
					wander_t = 4.0
					wander = Vector2.from_angle(randf() * TAU)
				position = (position + wander * speed * 0.4 * delta).clamp(main.MAP.position + Vector2(100, 100), main.MAP.end - Vector2(100, 100))
			return
		awake = true
	if panic_t > 0.0:  # Grito de Guerra Fúnebre (#20): em pânico não persegue o herói (a separação continua em baixo)
		_panic(delta)
	elif kind == "herald":
		_herald(delta)
	else:
		if gargoyle and gazed():  # Jardins (#208): com um herói a olhar para ela é só pedra (não anda nem bate)
			return
		var to: Vector2 = target.position - position
		var d := to.length()
		if elite and blind_t <= 0.0 and main.time >= mark_next and d > 160.0 and d < 520.0:  # Marca da Cova (#277): marca o chão onde o alvo está
			mark_at = target.position
			mark_end = main.time + MARK_T
			mark_next = main.time + 6.0
		if d > radius + 14.0:
			position += to / d * speed * frenzy() * (2.2 if gargoyle else 1.0) * (0.6 if slow_t > 0.0 else 1.0) * (0.4 if blind_t > 0.0 else 1.0) * delta
		elif attack_cd <= 0.0 and lift <= 0.0 and blind_t <= 0.0:
			if kind == "colossus":  # ataque telegrafado: dá tempo de sair da área ou esquivar
				windup_t = WINDUP
				attack_cd = 1.8
			else:
				target.take_damage(dmg * frenzy(), who(), self)
				attack_cd = 1.0
				attack_t = ATTACK_T
	for o in main.enemies():
		if o == self:
			continue
		var away: Vector2 = position - o.position
		var min_d: float = radius + o.radius
		if away.length_squared() < min_d * min_d and away != Vector2.ZERO:
			position += away.normalized() * (min_d - away.length()) * 0.5


## Arauto: anda devagar (cada passo treme o chão), bate o sino no chão perto dos jogadores
## e de tempos a tempos abre o caixão e invoca esqueletos.
func _herald(delta: float) -> void:
	slam_cd -= delta
	summon_cd -= delta
	if not raged and hp <= max_hp * rage_at:
		raged = true
		summon_cd = minf(summon_cd, 6.0 / haste)
		main.herald_rage(self)
	if act != "":
		act_t += delta
		if act_t >= ACT_T * 0.5 and not act_done:
			act_done = true
			if act == "slam":
				main.boss_slam(position + Vector2(0, 10), 170.0 * reach, dmg, who(), self)
			else:
				main.summon_minions(self, 4)
		if act_t >= ACT_T:
			act = ""
		return
	var to: Vector2 = target.position - position
	if summon_cd <= 0.0:
		_start("summon")
		summon_cd = (6.0 if raged else 11.0) / haste
	elif to.length() < 150.0 and slam_cd <= 0.0:
		_start("slam")
		slam_cd = (1.8 if raged else 2.6) / haste
	elif to.length() > radius + 20.0:
		position += to.normalized() * speed * delta
		var step := int(t * 4.0) % 2
		if step != last_step:
			last_step = step
			main.shake = maxf(main.shake, 2.5)
			main.spawn_fx("dust", position + Vector2(18 * (step * 2 - 1), 0), 40.0, Color.WHITE)


## Grito de Guerra Fúnebre (#20): em pânico bate no morto mais perto; sem ninguém a 260 px, foge do herói.
func _panic(delta: float) -> void:
	if not is_instance_valid(panic_target) or panic_target.dying:
		panic_target = null
		var best := 260.0
		for o in main.enemies():
			var d: float = position.distance_to(o.position)
			if o != self and not o.dummy and d < best:
				best = d
				panic_target = o
	if panic_target == null:
		var away: Vector2 = position - target.position
		if away != Vector2.ZERO:
			position += away.normalized() * speed * 0.8 * delta
		return
	var to: Vector2 = panic_target.position - position
	var dist := to.length()
	if dist > radius + panic_target.radius + 6.0:
		position += to / dist * speed * 1.2 * delta
	elif attack_cd <= 0.0 and lift <= 0.0 and blind_t <= 0.0:
		panic_target.take_damage(dmg, true, to / maxf(dist, 0.001))
		attack_cd = 1.0
		attack_t = ATTACK_T


## Eclipse Fúnebre (#182): enquanto dura, os elites andam e batem 30% mais.
func frenzy() -> float:
	return 1.3 if elite and main.time < main.eclipse_end else 1.0


## O Ceifador Ambulante (#216): anda a 104 px/s para o herói vivo mais perto e, a 40 px, ceifa-o (só a esquiva safa).
func _reap(delta: float) -> void:
	target = main.nearest_player(position)
	if target == null:
		return
	var to: Vector2 = target.position - position
	if to.length() >= 40.0:
		position += to.normalized() * 104.0 * delta
		return
	if target.dash_t <= 0.0:
		main.number(target.position + Vector2(0, -130), tr("Ceifado!"), 24.0, Color(0.75, 0.45, 1.0))
	target.slay(who())


## Jardins de Pedras Funerárias (#208): um herói vivo a menos de 700 px está virado para ela (em co-op, o olhar do outro
## também protege).
func gazed() -> bool:
	return main.players.any(func(p): return not p.dead and p.position.distance_to(position) < 700.0 and p.facing.dot(p.position.direction_to(position)) > 0.3)


## Área do murro do Colosso (o aviso no chão mostra-a); o Colosso Suturado (#31) perde 25% por cada braço cortado.
func slam_r() -> float:
	var k := 1.0
	for a in limbs.slice(0, 2):
		if a <= 0.0:
			k *= 0.75
	return (radius + 60.0) * k


## Execução Espectral (#12): à beira da morte, a alma fica exposta (não nos chefes com nome nem no Arauto); com o
## Carrasco de Sangue Negro (#124), quem bate (by) vê-a já abaixo de 20%.
func executable(by = null) -> bool:
	if dummy or dying or (title != "" and not gargoyle and not elite) or kind == "herald" or hp > max_hp * 0.2:  # a gárgula (#208) e o elite de um acampamento têm nome mas não são chefes
		return false
	return hp <= max_hp * EXECUTE_AT or (by != null and by.stat("carrasco") > 0.0)


## Stagger de Titãs (#16): quebrado, deixa extrair a Alma Ancestral (uma vez por quebra).
func extractable() -> bool:
	return stagger_t > 0.0 and not extracted and not dying


func apply_rot(dps: float) -> void:
	rot_dps = maxf(rot_dps if rot_t > 0.0 else 0.0, dps)
	rot_t = 4.0


## Uma camada de Calcificação Óssea; à 10.ª vira estátua (os chefes só metade do tempo).
func add_calc() -> void:
	if statue_t > 0.0 or dying:
		return
	calc += 1
	calc_wait = 4.0
	if calc >= CALC_MAX:
		calc = 0
		statue_t = 1.5 if is_boss else 3.0
		windup_t = 0.0
		act = ""
		_number(tr("Petrificado!"), 20.0, Color(0.85, 0.85, 0.8))
		main.spawn_fx("dust", position, 60.0, Color(0.8, 0.8, 0.75))


## Uma camada de Necrose Galopante (até 10); somem todas 4 s depois do último golpe.
func add_necro() -> void:
	necro = mini(necro + 1, NECRO_MAX)
	necro_wait = 4.0


func _start(a: String) -> void:
	act = a
	act_t = 0.0
	act_done = false


func apply_bleed(dps: float, dur: float) -> void:
	if bleed_t <= 0.0:  # começa a sangrar: o jorro
		_blood(0.5)
	bleed_dps = maxf(bleed_dps if bleed_t > 0.0 else 0.0, dps)
	bleed_t = dur


## flashes=false é o sangramento: sem flash nem recuo, e os números saem agrupados.
func take_damage(amount: float, flashes := true, dir := Vector2.ZERO, crit := false) -> void:
	if dying or rise_t > 0.0:
		return
	if boss != "":  # S7: os membros do Suturado e as estátuas do Guardião aguentam o golpe; sem membros o núcleo leva +25%
		amount *= Bosses.hurt(self, amount, dir, flashes)
		if amount <= 0.0:
			if flashes:
				flash = 0.12
				squash_t = 0.0
			return
	if dummy:
		dps_log.append([t, amount])
	elif is_boss and flashes and stagger_t <= 0.0 and not anchor:  # as estátuas não quebram
		posture_wait = 2.0
		posture += amount / (max_hp * POSTURE_HITS) * (1.5 if crit else 1.0)
		if posture >= 1.0:
			_stagger()
	hp = max_hp if dummy else hp - amount  # o boneco nunca cai
	if flashes:
		flash = 0.12
		squash_t = 0.0
		chunk_wait = 0.4
		knock =dir * (60.0 if is_boss else 320.0) * (1.5 if crit else 1.0)
		# Número: maior quanto maior o dano; crítico laranja, com "CRÍTICO!" e brilho, e atira ao ar
		var size := 15.0 + clampf(amount / 3.0, 0.0, 20.0)
		var mid := position + Vector2(0, _top() * 0.5 - lift)
		var pixel: bool = main.fx_budget("impact", 3, 9)  # impacto em píxeis (osso; crítico maior e dourado, sem o brilho antigo)
		if crit:
			_number("%d!" % roundi(amount), size * 1.45, Color(1.0, 0.6, 0.15), "Crítico!")
			if not pixel:
				main.spawn_fx("glow", mid, 70.0, Color(1.0, 0.75, 0.35))
			if bleed_t > 0.0 and hp > 0.0:  # crítico em quem já sangra: jorra mais
				_blood(1.0)
			if not is_boss:
				lift_v = 330.0
		else:
			_number(str(roundi(amount)), size, Color(0.95, 0.92, 0.82))
		if pixel:
			main.spawn_fx("impact", mid, 1.4 if crit else 1.0, Color.WHITE, dir, "gold" if crit else "bone", position.y - mid.y)
		else:
			main.spawn_fx("sparks", mid, 0.0, Color(1.0, 0.75, 0.3) if crit else Color(0.55, 1.0, 0.7), dir)
			main.spawn_fx("hit", mid, 70.0 if crit else 52.0, Color(1.0, 0.75, 0.3) if crit else Color.WHITE)
	else:
		bleed_acc += amount
	if hp <= 0.0:
		# Morre a animar (frames 12-15) e só depois desaparece, em _process
		dying = true
		mark_end = 0.0  # a Marca da Cova morre com ele: o convidado ainda o desenha a cair e não a apagava
		remove_from_group("enemies")
		if bleed_t > 0.0:  # morre a sangrar: o jorro maior
			_blood(1.5)
		killed.emit(self)
		if kind != "herald":
			main.spawn_fx("ring", position, radius * 1.8, Color(0.4, 1.0, 0.65))
			main.spawn_fx("dust", position, 40.0, Color.WHITE)
			main.sfx("die")


## Sangue em píxeis (fx "blood") da ferida para onde o golpe empurrou; as manchas secam como as poças do Sangue no Solo.
## Com efeitos baixos (ou já 3 neste frame) fica só o pingo de sempre (_draw). Vivos ao mesmo tempo: 8 nos efeitos altos,
## 4 nos médios (cada um fica 5 s no chão).
func _blood(n: float) -> void:
	if main.fx_budget("blood", 3, 8 if main.effects_level() == 2 else 4):
		var mid := position + Vector2(0, _top() * 0.5 - lift)
		main.spawn_fx("blood", mid, n, Color.WHITE, knock.normalized() if knock != Vector2.ZERO else Vector2.from_angle(randf() * TAU), "bleed", position.y - mid.y)


func _stagger() -> void:
	posture = 0.0
	stagger_t = STAGGER_T
	extracted = false
	windup_t = 0.0
	act = ""
	_number(tr("Quebrado!"), 24.0, Color(1.0, 0.9, 0.5))
	main.spawn_fx("ring", position, radius * 2.4, Color(1.0, 0.9, 0.5))
	main.shake = maxf(main.shake, 10.0)
	main.sfx("crit")


## Boneco de treino: dano por segundo nos últimos segundos (0 quando ninguém lhe bate).
func dps() -> float:
	if dps_log.is_empty() or t - dps_log[-1][0] > 3.0:
		return 0.0
	var total := 0.0
	for d in dps_log:
		total += d[1]
	return total / maxf(1.0, t - dps_log[0][0])


func _death_len() -> float:
	return 2.6 if kind == "herald" else 1.3


func _top() -> float:
	return -TOP[kind] * size


## Dano contínuo (#261): o sangramento, o dreno da Sede e a podridão somam-se num só número, que recomeça do zero
## quando o anterior já se apagou.
func _dot(v: float) -> void:
	if main.time > dot_until:
		dot_sum = 0.0
	dot_sum += v
	dot_until = main.time + DOT_T
	dot_rot = rot_t > 0.0 and bleed_t <= 0.0 and drain_t <= 0.0


## Golpes rápidos não se sobrepõem: cada número novo sobe um degrau.
func _number(text: String, size: float, color: Color, sub := "") -> void:
	num_i = num_i + 1 if num_t < 0.3 else 0
	num_t = 0.0
	var f = main.number(position + Vector2(randf_range(-12, 12), _top() - lift - 14.0 - (num_i % 4) * 18.0), text, size, color)
	f.sub = sub


## A vida por cima dele: a dos mortos menores feridos; a do elite (#277), a do Gigante Errante (#39, que não tem barra de
## chefe), a da gárgula (#208) e a das Estátuas Funerárias (#204) sempre à vista, com o nome por cima.
func life_bar() -> bool:
	if title == "Gigante Errante" or gargoyle or anchor:
		return true
	return (hp < max_hp or elite) and not is_boss


## O desenho 32-bit deste momento (8 por movimento).
func _frame32() -> int:
	if dying:
		return 24 + mini(7, int(death_t / (0.18 if kind == "herald" else 0.09)))
	if kind == "herald":
		if rise_t > 0.0:
			return 16
		if act == "dash":  # o Monge (#193) a correr para o barulho
			return int(t * 16.0) % 8
		if act != "":
			return (8 if act == "slam" else 16) + mini(7, int(act_t / ACT_T * 8.0))
		return int(t * 8.0) % 8
	if windup_t > 0.0:
		return 8 + mini(2, int((1.0 - windup_t / WINDUP) * 3.0))
	if attack_t > 0.0:
		if kind == "colossus":
			return 11 + mini(4, int((1.0 - attack_t / ATTACK_T) * 5.0))
		return 8 + mini(7, int((1.0 - attack_t / ATTACK_T) * 8.0))
	if dummy or anchor or (gargoyle and gazed()):  # o boneco, as estátuas (S7) e a gárgula olhada (#208): parados
		return 16
	if squash_t < 0.24:  # acabou de levar um golpe: recua e os ossos chocalham
		return 20 + mini(3, int(squash_t / 0.06))
	if stride < 0.3:
		return 16 + int(t * 5.0) % 4
	return int(t * 13.0) % 8


func _draw() -> void:
	# Ataques telegrafados: o círculo do golpe enche até ao impacto (a área é a mesma do dano)
	var warn := -1.0
	var warn_r := 0.0
	var warn_at := Vector2.ZERO
	if windup_t > 0.0:
		warn = 1.0 - windup_t / WINDUP
		warn_r = slam_r()
	elif kind == "herald" and act == "slam" and not act_done:
		warn = act_t / (ACT_T * 0.5)
		warn_r = 150.0 if boss == "monge" else 170.0 * reach
		warn_at = Vector2(0, 10)
	if warn >= 0.0:
		Pix.warn(self, warn_at, warn_r, warn)
	if boss != "":
		Bosses.draw(self, false)
	if dummy:  # o poste de madeira do boneco
		Pix.solid(self, Vector2.ZERO, [Vector2(-4, -70), Vector2(4, -70), Vector2(4, 4), Vector2(-4, 4)], "loot_ash", 4)
		Pix.solid(self, Vector2.ZERO, [Vector2(-26, -58), Vector2(26, -58), Vector2(26, -50), Vector2(-26, -50)], "loot_ash", 4)
	if exposed_t > 0.0:
		Pix.haze(self, Vector2(0, -radius * 1.6), radius * 1.4, radius * 1.4, Color(0.5, 1.0, 0.9), 0.45 + 0.25 * sin(t * 18.0))
	Pix.haze(self, Vector2.ZERO, radius * 1.2, radius * 0.48, Color.BLACK, 0.65 if kind != "specter" else 0.35)
	if elite:  # o anel dourado do elite, no chão
		var er := maxf(radius * 1.6, 44.0)  # nos pequenos, do tamanho que se lê no telemóvel
		Pix.elite(self, Vector2.ZERO, er, er * 0.4)
	var f32 := _frame32()  # o dobro da resolução do ecrã base: nítido no telemóvel
	var tex: Texture2D = FRAMES32[kind][f32]
	var sc: float = Feet32.SCALE[kind + "32"] * size
	var feet: float = Feet32.FEET[kind + "32"][f32]
	# Flash branco: multiplicar por 200 satura o sprite (e o resto rosa do recorte) para branco
	var tint := Color(200, 200, 200) if flash > 0.07 else (Color(1.8, 1.8, 1.8) if flash > 0.0 else Color.WHITE)
	if statue_t > 0.0:
		tint = Color(0.62, 0.62, 0.6)
	elif calc > 0:  # a calcificar: cada vez mais cinzento
		tint = tint.lerp(Color(0.7, 0.7, 0.68), calc / float(CALC_MAX) * 0.7)
	if necro > 0:  # a necrosar: cada vez mais roxo
		tint = tint.lerp(Color(0.62, 0.36, 0.85), necro / float(NECRO_MAX) * 0.6)
	if rot_t > 0.0:
		tint *= Color(0.75, 1.0, 0.6)
	if panic_t > 0.0:  # em pânico (#20): amarelado e a tremer
		tint = tint.lerp(Color(1.0, 0.8, 0.4), 0.4)
	if dummy:
		tint *= Color(0.9, 0.78, 0.6)
	tint *= paint  # S5: a cor por cima (os gigantes cor de terra)
	if raged:  # o Arauto na 2.ª fase: vermelho
		tint *= Color(1.0, 0.55, 0.55)
	var off := -lift
	if kind == "specter":
		tint.a = 0.85
		off += -8.0 + sin(t * 3.0) * 5.0
	if rise_t > 0.0:  # sobe do chão a desvanecer para dentro
		var k := clampf(1.0 - rise_t / 1.4, 0.0, 1.0)
		off += (1.0 - k) * 120.0
		tint.a = k
	if dying:
		tint.a *= clampf((_death_len() - death_t) / 0.5, 0.0, 1.0)
	# Os desenhos olham todos para a direita: espelha quando o alvo está à esquerda
	var flip := 1.0
	if target != null:
		flip = 1.0 if target.position.x > position.x else -1.0
	# Esmagar e esticar: cada golpe achata-o contra o chão e ele volta como uma mola
	var sq := exp(-squash_t * 9.0) * cos(squash_t * 26.0) * (0.08 if is_boss else 0.2)
	# Fluidez: um pequeno salto a cada passo, no ritmo dos frames de andar (o espectro já flutua)
	if kind != "specter":
		off -= absf(sin(t * PI * (2.0 if kind == "herald" else 3.5))) * 3.0 * stride * (1.6 if kind == "colossus" else 1.0)
	# A pose fica guardada para a silhueta atrás das paredes (#92); é o mesmo que draw_set_transform(posição, rotação, escala)
	pose_tex = tex
	# Transform2D(rotação, escala, inclinação, posição): escala local, como o draw_set_transform (o .scaled() escalaria no global e a inclinação ia ao contrário)
	pose = Transform2D(tilt + (sin(Time.get_ticks_msec() * 0.03) * 0.12 if panic_t > 0.0 else 0.0), Vector2(sc * flip * (1.0 + sq), sc * (1.0 - sq)), 0.0, Vector2(0, off)).translated_local(Vector2(-tex.get_width() / 2.0, -tex.get_height() + feet))
	draw_set_transform_matrix(pose)
	if gargoyle or anchor or reaper or boss == "carrasco":  # de pedra (#208, #204) e os escuros (#216, #44): um contorno claro, para se verem no chão escuro
		for o in [Vector2(-2, 0), Vector2(2, 0), Vector2(0, -2), Vector2(0, 2)]:
			draw_texture(tex, o / sc, Color(200, 200, 200, 0.35 * tint.a))
	draw_texture(tex, Vector2.ZERO, tint)
	draw_set_transform(Vector2.ZERO)
	if dying or rise_t > 0.0:
		return
	var top := _top() - lift
	if bleed_t > 0.0:
		Pix.orb(self, Vector2(8, top * 0.55 + fmod(t * 30.0, 12.0)), 1, "bleed")
	if rot_t > 0.0:  # bolhas verdes a subir
		for i in 2:
			Pix.orb(self, Vector2(-8 + i * 14, top * 0.4 - fmod(t * 24.0 + i * 9.0, 18.0)), 1, "rot")
	if blind_t > 0.0:
		Pix.haze(self, Vector2(0, top * 0.75), radius * 1.1, radius * 1.1, Color(0.3, 0.2, 0.35), 0.75)
	if pin_t > 0.0:  # preso (#103, #21): uma estaca de osso atravessada no corpo
		var ka := Vector2(-radius - 10.0, _top() * 0.6 - 6.0)  # sem o lift, que muda a cada frame: a forma coze uma vez
		var kb := Vector2(radius + 14.0, _top() * 0.4 + 6.0)
		var kn := (kb - ka).orthogonal().normalized() * 2.0
		Pix.solid(self, Vector2(0, -lift * 0.5), [ka - kn, kb - kn, kb + kn, ka + kn], "bone")
	if executable(main.player):  # ponto de rutura da alma: um losango a pulsar (com o Carrasco, #124, já abaixo de 20%)
		var c := Vector2(0, top * 0.5)
		var s := 7.0 + 2.0 * sin(t * 10.0)
		var dm := snappedf(s, 2.0)  # o losango aos degraus
		Pix.solid(self, c, [Vector2(0, -dm), Vector2(dm * 0.7, 0), Vector2(0, dm), Vector2(-dm * 0.7, 0)], "soul", 1)
		Pix.loop(self, c, s * 1.8, s * 1.8, Color(0.5, 1.0, 0.8), 1, false, 3)
	if extractable():  # a Alma Ancestral exposta no peito do chefe quebrado
		var er := 18.0 + 4.0 * sin(t * 8.0)
		Pix.haze(self, Vector2(0, top * 0.5), er, er, Color(0.4, 1.0, 0.6), 0.7)
		Pix.orb(self, Vector2(0, top * 0.5), 4, "soul")
	if dummy:  # boneco de treino (#287): o nome sempre à vista (sem ele parecia um esqueleto que não morre) e, a bater, o dano por segundo
		var hit := dps() > 0.0
		if title != "":
			Gothic.draw_centered(self, 0.0, top - (38.0 if hit else 18.0), tr(title), 18, Color(0.85, 0.95, 0.85), 4)
		if hit:
			Gothic.draw_centered(self, 0.0, top - 18.0, tr("%d de dano por segundo") % roundi(dps()), 16, Color(1.0, 0.9, 0.6), 4)
	if life_bar():
		var wbar := maxf(radius * 2.0, 34.0)
		if elite or title != "":
			Gothic.draw_centered(self, 0.0, top - 16.0, who(), 16, Color(1.0, 0.8, 0.3) if elite else Color(0.82, 0.86, 0.92) if gargoyle or anchor else Color(0.95, 0.88, 0.75), 4)
		draw_rect(Rect2(-wbar / 2, top - 10, wbar, 5), Color(0, 0, 0, 0.7))
		draw_rect(Rect2(-wbar / 2, top - 10, wbar * hp_chunk / max_hp, 5), Color(1.0, 0.85, 0.55))
		draw_rect(Rect2(-wbar / 2, top - 10, wbar * maxf(hp, 0.0) / max_hp, 5), Color(0.8, 0.1, 0.15))
	if ringer_at != 0.0:  # Sineiros (#206): o sino dourado por cima e, a tocar, um anel que se fecha até chegar o colosso
		var b := Vector2(0, top - (34.0 if life_bar() else 14.0))
		Pix.solid(self, b, [Vector2(-9, 0), Vector2(-6, -13), Vector2(0, -17), Vector2(6, -13), Vector2(9, 0)], "gold")
		Pix.orb(self, b + Vector2(0, 3), 1, "gold")
		if ringer_at > 0.0:
			var rr := radius + 140.0 * clampf((ringer_at - main.time) / 4.0, 0.0, 1.0)
			Pix.loop(self, Vector2.ZERO, rr, rr, Color(1.0, 0.82, 0.3), 2, true)
	if dot_sum >= 1.0 and main.time < dot_until and main.settings.numbers:  # o dano contínuo (#261), ao lado da barra
		var big: bool = dot_until - main.time > DOT_T - 0.15  # cada tique salta para 32 e assenta nos 16
		Gothic.draw(self, Vector2(maxf(radius, 17.0) + 6.0, top - 2.0), str(int(dot_sum)), 32 if big else 16, Color(0.45, 0.85, 0.25) if dot_rot else Color(0.85, 0.12, 0.18), 5)
	if boss != "":
		Bosses.draw(self, true)
